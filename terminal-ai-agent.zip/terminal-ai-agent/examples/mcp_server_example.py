"""MCP server — expose your tools via Model Context Protocol.

Demonstrates creating an MCP server that other AI agents can connect to.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

logger = logging.getLogger(__name__)


# ─── Server Setup ───────────────────────────────────────────────────

from terminal_agent.mcp.server import MCPServer

server = MCPServer(name="my-project-tools", version="1.0.0")


# ─── Tool Definitions ───────────────────────────────────────────────

@server.tool("greet")
async def greet(name: str, formal: bool = False) -> str:
    """Greet someone by name.

    Args:
        name: Person's name.
        formal: Use formal greeting.

    Returns:
        Greeting message.
    """
    if formal:
        return f"Good day, {name}. It is a pleasure to make your acquaintance."
    return f"Hey {name}! 👋"


@server.tool("calculate")
async def calculate(expression: str) -> dict[str, Any]:
    """Safely evaluate a math expression.

    Args:
        expression: Math expression (e.g., "2 + 3 * 4").

    Returns:
        Result with the expression and value.
    """
    import ast
    import operator

    ops = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.Mod: operator.mod,
        ast.Pow: operator.pow,
    }

    def _eval(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.BinOp):
            left = _eval(node.left)
            right = _eval(node.right)
            return ops[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp):
            return -_eval(node.operand)
        raise ValueError(f"Unsupported operation: {type(node).__name__}")

    try:
        tree = ast.parse(expression, mode="eval")
        result = _eval(tree.body)
        return {"expression": expression, "result": result}
    except Exception as exc:
        return {"expression": expression, "error": str(exc)}


@server.tool("read_json")
async def read_json(path: str) -> Any:
    """Read and parse a JSON file.

    Args:
        path: Path to JSON file.

    Returns:
        Parsed JSON content.
    """
    with open(path) as f:
        return json.load(f)


@server.tool("write_json")
async def write_json(path: str, data: Any, indent: int = 2) -> str:
    """Write data to a JSON file.

    Args:
        path: Output file path.
        data: Data to serialize.
        indent: JSON indentation.

    Returns:
        Confirmation message.
    """
    with open(path, "w") as f:
        json.dump(data, f, indent=indent, default=str)
    return f"Wrote {path}"


@server.tool("list_directory")
async def list_directory(path: str = ".", pattern: str = "*") -> list[dict[str, Any]]:
    """List files in a directory.

    Args:
        path: Directory path.
        pattern: Glob pattern filter.

    Returns:
        List of file info dicts.
    """
    from pathlib import Path

    directory = Path(path)
    entries = []

    for item in sorted(directory.glob(pattern)):
        stat = item.stat()
        entries.append({
            "name": item.name,
            "path": str(item),
            "type": "dir" if item.is_dir() else "file",
            "size": stat.st_size if item.is_file() else None,
        })

    return entries


# ─── Resource Definitions ───────────────────────────────────────────

@server.resource("config://app")
async def get_app_config() -> dict[str, Any]:
    """Provide application configuration as a resource."""
    return {
        "name": "my-project-tools",
        "version": "1.0.0",
        "capabilities": ["greet", "calculate", "json", "filesystem"],
    }


@server.resource("info://server")
async def get_server_info() -> dict[str, Any]:
    """Provide server information."""
    import platform
    return {
        "name": "my-project-tools",
        "version": "1.0.0",
        "python": platform.python_version(),
        "platform": platform.system(),
    }


# ─── Prompt Definitions ─────────────────────────────────────────────

@server.prompt("math_helper")
def math_helper_prompt(topic: str = "algebra") -> str:
    """Generate a math helper system prompt."""
    return f"""You are a helpful math tutor specializing in {topic}.
Use the 'calculate' tool to verify computations.
Show your work step by step."""


# ─── Run Server ─────────────────────────────────────────────────────

async def run_stdio() -> None:
    """Run the server over stdio (for subprocess-based connections)."""
    await server.serve_stdio()


async def run_sse(host: str = "0.0.0.0", port: int = 3000) -> None:
    """Run the server over SSE (for HTTP-based connections)."""
    await server.serve_sse(host=host, port=port)


if __name__ == "__main__":
    import sys

    mode = sys.argv[1] if len(sys.argv) > 1 else "stdio"

    if mode == "sse":
        port = int(sys.argv[2]) if len(sys.argv) > 2 else 3000
        print(f"Starting MCP server on http://0.0.0.0:{port}/mcp")
        asyncio.run(run_sse(port=port))
    else:
        print("Starting MCP server on stdio", file=sys.stderr)
        asyncio.run(run_stdio())
