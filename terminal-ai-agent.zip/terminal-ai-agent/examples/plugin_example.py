"""Plugin example — full plugin with tools, hooks, config, and lifecycle.

Demonstrates building a production plugin that registers tools,
lifecycle hooks, and configuration validation.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from terminal_agent.plugins.api import PluginBase, PluginContext

logger = logging.getLogger(__name__)


class CodeAnalysisPlugin(PluginBase):
    """Plugin that provides code analysis tools.

    Tools:
        - analyze_complexity: Calculate cyclomatic complexity
        - find_todos: Find TODO/FIXME comments
        - count_lines: Count lines of code by type

    Hooks:
        - before_tool: Log tool calls
        - after_tool: Track tool usage metrics
    """

    name = "code-analysis"
    version = "1.0.0"
    description = "Code analysis tools for complexity, TODOs, and LOC counting"

    def __init__(self) -> None:
        self._context: PluginContext | None = None
        self._tool_usage: dict[str, int] = {}
        self._start_time: float | None = None

    def activate(self, context: PluginContext | None = None) -> None:
        """Initialize the plugin.

        Args:
            context: Plugin context with config, logging, and data store.
        """
        self._context = context or PluginContext()
        self._start_time = time.time()
        self._context.log.info("Code Analysis Plugin v%s activated", self.version)

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions."""
        return [
            {
                "name": "analyze_complexity",
                "description": "Calculate cyclomatic complexity of Python functions",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to Python file",
                        },
                        "function_name": {
                            "type": "string",
                            "description": "Specific function to analyze (optional)",
                        },
                    },
                    "required": ["file_path"],
                },
                "returns": "Complexity metrics per function",
            },
            {
                "name": "find_todos",
                "description": "Find TODO, FIXME, HACK, and XXX comments in source files",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "directory": {
                            "type": "string",
                            "description": "Directory to scan",
                        },
                        "patterns": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Comment patterns to find",
                            "default": ["TODO", "FIXME", "HACK", "XXX"],
                        },
                        "file_extensions": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "File extensions to scan",
                            "default": [".py", ".js", ".ts"],
                        },
                    },
                    "required": ["directory"],
                },
                "returns": "List of TODO comments with file and line info",
            },
            {
                "name": "count_lines",
                "description": "Count lines of code, comments, and blanks",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to source file",
                        },
                    },
                    "required": ["file_path"],
                },
                "returns": "Line count breakdown",
            },
        ]

    def get_hooks(self) -> dict[str, Any]:
        """Return hook handlers."""
        return {
            "before_tool": self._before_tool,
            "after_tool": self._after_tool,
            "on_error": self._on_error,
        }

    def get_config_schema(self) -> dict[str, Any]:
        """Return configuration schema."""
        return {
            "type": "object",
            "properties": {
                "max_complexity": {
                    "type": "integer",
                    "description": "Maximum acceptable complexity",
                    "default": 10,
                },
                "scan_hidden": {
                    "type": "boolean",
                    "description": "Include hidden files",
                    "default": False,
                },
            },
        }

    async def handle_tool(self, tool_name: str, parameters: dict[str, Any]) -> Any:
        """Dispatch tool call to handler.

        Args:
            tool_name: Tool to invoke.
            parameters: Tool parameters.

        Returns:
            Tool result.

        Raises:
            ValueError: Unknown tool.
        """
        handlers = {
            "analyze_complexity": self._analyze_complexity,
            "find_todos": self._find_todos,
            "count_lines": self._count_lines,
        }

        handler = handlers.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")

        return await handler(**parameters)

    def cleanup(self) -> None:
        """Release resources and log stats."""
        if self._context:
            uptime = time.time() - (self._start_time or time.time())
            self._context.log.info(
                "Plugin shutting down. Uptime: %.0fs, Tool calls: %s",
                uptime,
                self._tool_usage,
            )
        self._context = None

    # --- Tool implementations ---

    async def _analyze_complexity(
        self, file_path: str, function_name: str | None = None
    ) -> dict[str, Any]:
        """Calculate cyclomatic complexity."""
        import ast

        with open(file_path) as f:
            tree = ast.parse(f.read())

        results = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if function_name and node.name != function_name:
                    continue

                complexity = 1  # Base complexity
                for child in ast.walk(node):
                    if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                        complexity += 1
                    elif isinstance(child, ast.BoolOp):
                        complexity += len(child.values) - 1

                results.append({
                    "function": node.name,
                    "line": node.lineno,
                    "complexity": complexity,
                    "rating": self._complexity_rating(complexity),
                })

        max_allowed = 10
        if self._context:
            max_allowed = self._context.config.get("max_complexity", 10)

        return {
            "file": file_path,
            "functions": results,
            "max_complexity": max(r["complexity"] for r in results) if results else 0,
            "warnings": [
                r for r in results if r["complexity"] > max_allowed
            ],
        }

    async def _find_todos(
        self,
        directory: str,
        patterns: list[str] | None = None,
        file_extensions: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Find TODO comments."""
        import os
        import re

        patterns = patterns or ["TODO", "FIXME", "HACK", "XXX"]
        file_extensions = file_extensions or [".py", ".js", ".ts"]

        regex = re.compile(
            r"#\s*(" + "|".join(patterns) + r")\s*:?\s*(.*)",
            re.IGNORECASE,
        )

        findings = []
        for root, dirs, files in os.walk(directory):
            # Skip hidden dirs
            dirs[:] = [d for d in dirs if not d.startswith(".")]

            for fname in files:
                if not any(fname.endswith(ext) for ext in file_extensions):
                    continue

                fpath = os.path.join(root, fname)
                try:
                    with open(fpath) as f:
                        for line_num, line in enumerate(f, 1):
                            match = regex.search(line)
                            if match:
                                findings.append({
                                    "file": fpath,
                                    "line": line_num,
                                    "type": match.group(1).upper(),
                                    "text": match.group(2).strip(),
                                })
                except (OSError, UnicodeDecodeError):
                    continue

        return findings

    async def _count_lines(self, file_path: str) -> dict[str, int]:
        """Count lines of code."""
        with open(file_path) as f:
            lines = f.readlines()

        total = len(lines)
        blank = sum(1 for l in lines if not l.strip())
        comment = 0
        in_docstring = False

        for line in lines:
            stripped = line.strip()
            if stripped.startswith('"""') or stripped.startswith("'''"):
                comment += 1
                in_docstring = not in_docstring
            elif in_docstring:
                comment += 1
            elif stripped.startswith("#"):
                comment += 1

        code = total - blank - comment

        return {
            "file": file_path,
            "total": total,
            "code": code,
            "comments": comment,
            "blank": blank,
            "code_ratio": round(code / max(total, 1), 2),
        }

    # --- Hook implementations ---

    def _before_tool(self, tool_name: str, parameters: dict[str, Any]) -> dict[str, Any]:
        """Hook: log and validate before tool execution."""
        if self._context:
            self._context.log.debug("Tool call: %s(%s)", tool_name, list(parameters.keys()))
        self._tool_usage[tool_name] = self._tool_usage.get(tool_name, 0) + 1
        return parameters

    def _after_tool(
        self, tool_name: str, parameters: dict[str, Any], result: Any
    ) -> Any:
        """Hook: track metrics after tool execution."""
        return result

    def _on_error(self, tool_name: str, error: Exception) -> None:
        """Hook: log errors."""
        if self._context:
            self._context.log.error("Tool %s failed: %s", tool_name, error)

    # --- Helpers ---

    @staticmethod
    def _complexity_rating(complexity: int) -> str:
        """Rate complexity score."""
        if complexity <= 5:
            return "low"
        if complexity <= 10:
            return "moderate"
        if complexity <= 20:
            return "high"
        return "very_high"


async def main() -> None:
    """Run the plugin standalone."""
    plugin = CodeAnalysisPlugin()
    plugin.activate()

    # Analyze this file itself
    result = await plugin.handle_tool("analyze_complexity", {
        "file_path": __file__,
    })
    print("Complexity Analysis:")
    for func in result["functions"]:
        print(f"  {func['function']}: {func['complexity']} ({func['rating']})")

    # Count lines
    lines = await plugin.handle_tool("count_lines", {"file_path": __file__})
    print(f"\nLine counts: {lines}")

    plugin.cleanup()


if __name__ == "__main__":
    asyncio.run(main())
