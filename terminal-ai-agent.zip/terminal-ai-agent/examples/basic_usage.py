"""Basic usage — core Terminal Agent API examples.

Demonstrates creating an agent, running tasks, streaming responses,
working with sessions, and handling results.
"""

from __future__ import annotations

import asyncio
from terminal_agent import Agent, AgentConfig


async def simple_task() -> None:
    """Run a one-shot task and print the result."""
    agent = Agent(config=AgentConfig())

    result = await agent.run("List all Python files in the current directory")

    print(f"Status: {result.status}")
    print(f"Output:\n{result.output}")
    print(f"Steps taken: {result.steps}")
    print(f"Duration: {result.duration_ms:.0f}ms")
    print(f"Tokens used: {result.tokens_total}")


async def task_with_context() -> None:
    """Run a task with additional context."""
    agent = Agent(config=AgentConfig())

    result = await agent.run(
        "Refactor the authentication module to use JWT tokens",
        context={
            "project_type": "fastapi",
            "python_version": "3.12",
            "existing_auth": "session-based",
        },
        working_dir="/path/to/project",
    )

    if result.success:
        print(f"✅ Task completed in {result.steps} steps")
    else:
        print(f"❌ Task failed: {result.error}")


async def streaming_task() -> None:
    """Stream agent thoughts and actions in real-time."""
    agent = Agent(config=AgentConfig())

    async for event in agent.stream("Create a README.md for this project"):
        match event.type:
            case "thinking":
                print(f"💭 {event.content}")
            case "tool_call":
                print(f"🔧 Calling {event.tool}({event.params})")
            case "tool_result":
                print(f"📥 Result: {event.content[:100]}...")
            case "step":
                print(f"📍 Step {event.step_number}: {event.content}")
            case "complete":
                print(f"\n✅ Done: {event.content}")


async def session_management() -> None:
    """Work with persistent sessions."""
    agent = Agent(config=AgentConfig())

    # Create a session
    session = await agent.create_session(name="my-project")

    # Run tasks within the session (context carries over)
    await session.run("Analyze the project structure")
    await session.run("Identify the main entry point")
    result = await session.run("Suggest architectural improvements")

    # Session history is available
    history = session.get_history()
    for entry in history:
        print(f"[{entry.timestamp}] {entry.role}: {entry.content[:80]}")

    # Resume later
    resumed = await agent.resume_session(session.id)
    await resumed.run("Continue with the improvements")


async def error_handling() -> None:
    """Demonstrate error handling patterns."""
    agent = Agent(config=AgentConfig())

    try:
        result = await agent.run(
            "Deploy to production",
            max_steps=50,
            timeout=300,
        )

        if not result.success:
            print(f"Task failed after {result.steps} steps")
            print(f"Error: {result.error}")
            print(f"Last tool: {result.last_tool}")
            print(f"Recovery attempts: {result.recovery_attempts}")

    except TimeoutError:
        print("Task timed out after 5 minutes")
    except Exception as exc:
        print(f"Unexpected error: {exc}")


async def tool_listing() -> None:
    """List available tools and their schemas."""
    agent = Agent(config=AgentConfig())

    tools = agent.get_tools()

    for tool in tools:
        print(f"\n{'='*60}")
        print(f"Tool: {tool.name}")
        print(f"Category: {tool.category}")
        print(f"Safety: {tool.safety_level}")
        print(f"Description: {tool.description}")


async def configuration() -> None:
    """Demonstrate configuration options."""
    # From config file
    agent = Agent(config=AgentConfig.from_file("terminal-agent.toml"))

    # Programmatic overrides
    config = AgentConfig(
        primary_provider="openai",
        primary_model="gpt-4o",
        temperature=0.1,
        max_tokens=4096,
        safety_level="moderate",
        verbose=True,
    )
    agent = Agent(config=config)

    # Environment variables are also respected:
    # TERMINAL_AGENT_PROVIDER=openai
    # OPENAI_API_KEY=sk-...

    print(f"Provider: {config.primary_provider}")
    print(f"Model: {config.primary_model}")


async def main() -> None:
    """Run all examples."""
    examples = [
        ("Simple Task", simple_task),
        ("Task with Context", task_with_context),
        ("Streaming", streaming_task),
        ("Sessions", session_management),
        ("Error Handling", error_handling),
        ("Tool Listing", tool_listing),
        ("Configuration", configuration),
    ]

    for name, func in examples:
        print(f"\n{'='*60}")
        print(f"Example: {name}")
        print("=" * 60)
        try:
            await func()
        except Exception as exc:
            print(f"Error: {exc}")


if __name__ == "__main__":
    asyncio.run(main())
