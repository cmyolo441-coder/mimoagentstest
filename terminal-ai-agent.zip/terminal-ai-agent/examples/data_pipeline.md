# Data Pipeline Workflow

Build an ETL data pipeline with Terminal Agent.

## Overview

Create a data pipeline that extracts, transforms, and loads data
with proper error handling, monitoring, and idempotency.

## Step 1: Pipeline Architecture

```bash
terminal-agent run "Design a data pipeline architecture:
- Sources: CSV files, REST API, PostgreSQL database
- Staging: Raw data landing zone
- Transform: Data cleaning, dedup, enrichment
- Target: Data warehouse (PostgreSQL star schema)
- Schedule: Daily at 2 AM, with backfill support

Output the directory structure and module plan."
```

## Step 2: Extractors

```bash
terminal-agent run "Create data extractors:
- CSVExtractor: Read CSV files with schema validation
- APIExtractor: Paginated REST API client with retry
- DBExtractor: Incremental extraction with watermark
- Base class with common logging and metrics
- All extractors return Arrow/Polars DataFrames"
```

## Step 3: Transformers

```bash
terminal-agent run "Create data transformers:
- CleanTransformer: Remove nulls, fix types, deduplicate
- EnrichTransformer: Add computed columns, lookups
- ValidateTransformer: Schema validation, business rules
- Chainable transformer pipeline
- Error rows go to quarantine table"
```

## Step 4: Loaders

```bash
terminal-agent run "Create data loaders:
- WarehouseLoader: Upsert to star schema
- FileLoader: Write to Parquet/CSV
- Idempotent loads (can re-run safely)
- Batch inserts with COPY for performance
- Load audit log (rows loaded, errors, duration)"
```

## Step 5: Orchestration

```bash
terminal-agent run "Create pipeline orchestrator:
- DAG-based execution with dependencies
- Parallel execution of independent stages
- Retry on failure with exponential backoff
- Progress tracking and logging
- Dry-run mode for testing"
```

## Step 6: Monitoring

```bash
terminal-agent run "Add pipeline monitoring:
- Row counts per stage
- Data quality metrics
- Execution duration tracking
- Alert on failure or data anomalies
- Dashboard-ready metrics export"
```

## Pipeline Pattern

```python
pipeline = Pipeline("daily-etl")

pipeline.add_stage("extract", ExtractStage([
    CSVExtractor("data/orders.csv"),
    APIExtractor("https://api.example.com/customers"),
]))

pipeline.add_stage("transform", TransformStage([
    CleanTransformer(),
    EnrichTransformer(lookup=customer_lookup),
    ValidateTransformer(schema=order_schema),
]))

pipeline.add_stage("load", LoadStage([
    WarehouseLoader(connection_string),
]))

# Run
result = await pipeline.run(date="2024-01-15")
print(f"Loaded {result.rows_loaded} rows in {result.duration}s")
```
