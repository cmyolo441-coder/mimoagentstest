# Refactoring Workflow

Safely refactor code with Terminal Agent.

## Overview

Refactor code iteratively: analyze, plan, execute, verify.
Each step maintains test coverage and code quality.

## Step 1: Analyze Code Quality

```bash
terminal-agent run "Analyze src/ for code quality issues:
- Run ruff and report all violations
- Run mypy and report type errors
- Identify code smells (long functions, deep nesting, duplication)
- Calculate cyclomatic complexity per function
- Rank files by technical debt"
```

## Step 2: Plan Refactoring

```bash
terminal-agent run "Create a refactoring plan for src/services/payment.py:
- Identify specific issues (god class, tight coupling, no error handling)
- Propose refactoring steps in order of risk (lowest first)
- Estimate effort per step
- Identify dependencies between steps
- Define success criteria"
```

## Step 3: Extract Classes

```bash
terminal-agent run "Refactor the PaymentService class:
- Extract PaymentValidator (validation logic)
- Extract PaymentGateway (external API calls)
- Extract PaymentRepository (database operations)
- Keep PaymentService as orchestrator
- Update all imports and tests
- Run tests after each extraction"
```

## Step 4: Improve Type Safety

```bash
terminal-agent run "Add type hints to src/:
- Add type annotations to all function signatures
- Add return type annotations
- Use proper generic types (list[str] not List[str])
- Add type aliases for complex types
- Fix any mypy errors
- Run mypy --strict to verify"
```

## Step 5: Error Handling

```bash
terminal-agent run "Improve error handling in src/:
- Replace bare except with specific exceptions
- Create custom exception hierarchy
- Add error context (what was being done when it failed)
- Add structured logging for errors
- Ensure all external calls have timeout and retry"
```

## Step 6: Performance

```bash
terminal-agent run "Optimize performance in src/:
- Profile with cProfile to find bottlenecks
- Add database query optimization (N+1 detection)
- Add caching where appropriate
- Replace sync I/O with async where beneficial
- Measure before and after"
```

## Step 7: Verify

```bash
terminal-agent run "Verify the refactoring:
- Run full test suite
- Compare coverage before/after
- Run benchmarks and compare
- Check for regressions
- Generate refactoring summary report"
```

## Refactoring Principles

1. **Small steps** — One change at a time
2. **Tests first** — Ensure tests pass before and after
3. **Commit often** — Every passing state gets committed
4. **Measure** — Use metrics to verify improvement
5. **Review** — Each change should be reviewable

## Common Patterns

### Extract Method
```python
# Before
def process_order(order):
    # 50 lines of validation
    # 30 lines of calculation
    # 20 lines of persistence

# After
def process_order(order):
    validated = validate_order(order)
    totals = calculate_totals(validated)
    return persist_order(validated, totals)
```

### Replace Conditional with Polymorphism
```python
# Before
def calculate_shipping(order, method):
    if method == "standard":
        return order.weight * 0.5
    elif method == "express":
        return order.weight * 1.5
    elif method == "overnight":
        return order.weight * 3.0

# After
class ShippingMethod(Protocol):
    def calculate(self, order: Order) -> Decimal: ...

class StandardShipping:
    def calculate(self, order): return order.weight * 0.5
```
