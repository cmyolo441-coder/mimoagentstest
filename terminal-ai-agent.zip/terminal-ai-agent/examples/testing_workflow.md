# Testing Workflow

Generate and run comprehensive tests with Terminal Agent.

## Overview

Use Terminal Agent to analyze code, generate tests, run them,
and iteratively fix failures until all tests pass.

## Step 1: Analyze Code Coverage

```bash
terminal-agent run "Run pytest with coverage on the src/ directory.
Report:
- Overall coverage percentage
- Files below 80% coverage
- Untested functions and branches
- Coverage by module"
```

## Step 2: Generate Unit Tests

```bash
terminal-agent run "Generate unit tests for src/services/order_service.py:
- Test all public methods
- Cover happy path and edge cases
- Mock external dependencies (database, payment API)
- Use pytest fixtures for common setup
- Include parametrized tests for input validation"
```

## Step 3: Generate Integration Tests

```bash
terminal-agent run "Create integration tests for the API:
- Test full request/response cycle
- Use test database (SQLite in memory)
- Test authentication flow
- Test error responses (400, 401, 403, 404, 500)
- Test pagination and filtering"
```

## Step 4: Run and Fix

```bash
terminal-agent run "Run the test suite. For each failure:
1. Read the error message
2. Find the source of the bug
3. Fix the code (not the test, unless the test is wrong)
4. Re-run to confirm the fix

Continue until all tests pass."
```

## Step 5: Property-Based Testing

```bash
terminal-agent run "Add property-based tests using Hypothesis:
- Test that serialization round-trips preserve data
- Test that validators reject invalid inputs
- Test that sort functions maintain ordering
- Test that search returns matching results"
```

## Step 6: Performance Tests

```bash
terminal-agent run "Create performance tests:
- Benchmark critical paths with pytest-benchmark
- Load test the API with locust (100 concurrent users)
- Memory leak detection for long-running operations
- Compare performance before/after changes"
```

## Step 7: Test Report

```bash
terminal-agent run "Generate a test report:
- Test summary (passed, failed, skipped)
- Coverage report with HTML
- Performance benchmarks
- Risk assessment of untested code
- Recommendations for improving coverage"
```

## Test Patterns

### Fixture Pattern
```python
@pytest.fixture
def order_service(db_session, mock_payment):
    return OrderService(db=db_session, payment=mock_payment)

@pytest.fixture
def sample_user(db_session):
    user = User(email="test@example.com", name="Test")
    db_session.add(user)
    db_session.commit()
    return user
```

### Parametrized Tests
```python
@pytest.mark.parametrize("email,valid", [
    ("user@example.com", True),
    ("invalid", False),
    ("@no-user.com", False),
    ("user@.com", False),
])
def test_email_validation(email, valid):
    assert User(email=email).is_valid_email() == valid
```

### Mock Pattern
```python
async def test_payment_failure(order_service, mock_payment):
    mock_payment.charge.side_effect = PaymentError("Card declined")

    with pytest.raises(OrderError, match="payment failed"):
        await order_service.create_order(cart, user)
```
