"""Custom memory backend — implement a memory store for Terminal Agent.

Demonstrates creating a custom memory backend using Redis as the
storage layer, with vector search capabilities.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from typing import Any

from terminal_agent.memory.base_memory import BaseMemory, MemoryEntry, MemorySearchResult

logger = logging.getLogger(__name__)


class RedisMemory(BaseMemory):
    """Redis-backed memory store with optional vector search.

    Stores memories in Redis hashes with TTL support and
    approximate nearest-neighbor search via Redis modules.
    """

    name = "redis"

    def __init__(
        self,
        redis_url: str = "redis://localhost:6379",
        prefix: str = "terminal-agent:memory",
        default_ttl: int | None = None,
    ) -> None:
        self._redis_url = redis_url
        self._prefix = prefix
        self._default_ttl = default_ttl
        self._client = None

    async def connect(self) -> None:
        """Establish Redis connection."""
        try:
            import redis.asyncio as aioredis

            self._client = aioredis.from_url(
                self._redis_url,
                decode_responses=True,
            )
            await self._client.ping()
            logger.info("Connected to Redis at %s", self._redis_url)
        except ImportError:
            raise ImportError("Install redis: pip install redis[hiredis]")

    async def disconnect(self) -> None:
        """Close Redis connection."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def store(self, entry: MemoryEntry) -> str:
        """Store a memory entry.

        Args:
            entry: Memory entry to store.

        Returns:
            Entry ID.
        """
        self._ensure_connected()

        entry_id = entry.id or self._generate_id(entry.content)
        entry.id = entry_id

        key = f"{self._prefix}:entry:{entry_id}"

        data = {
            "id": entry_id,
            "content": entry.content,
            "category": entry.category or "general",
            "importance": str(entry.importance or 0.5),
            "metadata": json.dumps(entry.metadata or {}),
            "created_at": str(time.time()),
            "access_count": "0",
        }

        pipe = self._client.pipeline()
        pipe.hset(key, mapping=data)

        if self._default_ttl:
            pipe.expire(key, self._default_ttl)

        # Add to category index
        pipe.sadd(f"{self._prefix}:category:{entry.category or 'general'}", entry_id)

        # Add to sorted set by importance
        pipe.zadd(
            f"{self._prefix}:by_importance",
            {entry_id: entry.importance or 0.5},
        )

        await pipe.execute()

        logger.debug("Stored memory entry %s", entry_id)
        return entry_id

    async def retrieve(self, entry_id: str) -> MemoryEntry | None:
        """Retrieve a memory entry by ID.

        Args:
            entry_id: Entry ID.

        Returns:
            Memory entry or None if not found.
        """
        self._ensure_connected()

        key = f"{self._prefix}:entry:{entry_id}"
        data = await self._client.hgetall(key)

        if not data:
            return None

        # Increment access count
        await self._client.hincrby(key, "access_count", 1)

        return MemoryEntry(
            id=data["id"],
            content=data["content"],
            category=data.get("category"),
            importance=float(data.get("importance", 0.5)),
            metadata=json.loads(data.get("metadata", "{}")),
        )

    async def search(
        self,
        query: str,
        limit: int = 10,
        category: str | None = None,
        min_importance: float = 0.0,
    ) -> list[MemorySearchResult]:
        """Search memories by content similarity.

        Uses keyword matching as a fallback when vector search
        is not available.

        Args:
            query: Search query.
            limit: Maximum results.
            category: Filter by category.
            min_importance: Minimum importance threshold.

        Returns:
            List of search results ranked by relevance.
        """
        self._ensure_connected()

        # Get candidate IDs
        if category:
            key = f"{self._prefix}:category:{category}"
            candidate_ids = await self._client.smembers(key)
        else:
            # Get all entries by importance
            candidate_ids = await self._client.zrangebyscore(
                f"{self._prefix}:by_importance",
                min=min_importance,
                max="+inf",
            )

        # Score candidates by keyword overlap
        query_words = set(query.lower().split())
        scored: list[tuple[str, float]] = []

        for entry_id in candidate_ids:
            data = await self._client.hgetall(f"{self._prefix}:entry:{entry_id}")
            if not data:
                continue

            importance = float(data.get("importance", 0.5))
            if importance < min_importance:
                continue

            content_words = set(data.get("content", "").lower().split())
            overlap = len(query_words & content_words)

            if overlap > 0:
                # Score = keyword overlap * importance
                score = (overlap / max(len(query_words), 1)) * importance
                scored.append((entry_id, score))

        # Sort by score and take top results
        scored.sort(key=lambda x: x[1], reverse=True)
        results: list[MemorySearchResult] = []

        for entry_id, score in scored[:limit]:
            entry = await self.retrieve(entry_id)
            if entry:
                results.append(MemorySearchResult(entry=entry, score=score))

        return results

    async def delete(self, entry_id: str) -> bool:
        """Delete a memory entry.

        Args:
            entry_id: Entry ID.

        Returns:
            True if deleted, False if not found.
        """
        self._ensure_connected()

        key = f"{self._prefix}:entry:{entry_id}"
        data = await self._client.hgetall(key)

        if not data:
            return False

        pipe = self._client.pipeline()
        pipe.delete(key)
        pipe.srem(f"{self._prefix}:category:{data.get('category', 'general')}", entry_id)
        pipe.zrem(f"{self._prefix}:by_importance", entry_id)

        await pipe.execute()
        return True

    async def list_entries(
        self,
        category: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[MemoryEntry]:
        """List memory entries.

        Args:
            category: Filter by category.
            limit: Maximum entries.
            offset: Pagination offset.

        Returns:
            List of memory entries.
        """
        self._ensure_connected()

        if category:
            key = f"{self._prefix}:category:{category}"
            ids = await self._client.smembers(key)
        else:
            ids = await self._client.zrevrange(
                f"{self._prefix}:by_importance",
                start=offset,
                end=offset + limit - 1,
            )

        entries = []
        for entry_id in ids:
            entry = await self.retrieve(entry_id)
            if entry:
                entries.append(entry)

        return entries[:limit]

    async def clear(self, category: str | None = None) -> int:
        """Clear memory entries.

        Args:
            category: Clear only this category, or all if None.

        Returns:
            Number of entries cleared.
        """
        self._ensure_connected()

        if category:
            key = f"{self._prefix}:category:{category}"
            ids = await self._client.smembers(key)
            count = 0
            for entry_id in ids:
                if await self.delete(entry_id):
                    count += 1
            return count

        # Clear all
        pattern = f"{self._prefix}:entry:*"
        count = 0
        async for key in self._client.scan_iter(match=pattern):
            entry_id = key.split(":")[-1]
            if await self.delete(entry_id):
                count += 1
        return count

    def _ensure_connected(self) -> None:
        """Check that the client is connected."""
        if self._client is None:
            raise RuntimeError("Not connected. Call connect() first.")

    def _generate_id(self, content: str) -> str:
        """Generate a deterministic ID from content."""
        return hashlib.sha256(content.encode()).hexdigest()[:16]


async def main() -> None:
    """Example: use Redis memory with the agent."""
    from terminal_agent import Agent, AgentConfig

    # Create Redis memory backend
    memory = RedisMemory(
        redis_url="redis://localhost:6379",
        prefix="my-agent:memory",
        default_ttl=86400 * 7,  # 7 days
    )

    # Store some memories directly
    await memory.connect()

    await memory.store(MemoryEntry(
        content="User prefers Python over JavaScript",
        category="preferences",
        importance=0.8,
    ))

    await memory.store(MemoryEntry(
        content="Project uses FastAPI with PostgreSQL",
        category="project",
        importance=0.9,
    ))

    # Search
    results = await memory.search("What language does the user prefer?")
    for r in results:
        print(f"[{r.score:.2f}] {r.entry.content}")

    # Use with agent
    agent_config = AgentConfig()
    agent = Agent(config=agent_config)
    agent.register_memory_backend(memory)

    result = await agent.run("What framework does the project use?")
    print(result.output)

    await memory.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
