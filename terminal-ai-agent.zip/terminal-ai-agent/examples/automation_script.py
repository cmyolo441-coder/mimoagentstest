"""Automation script — multi-step workflow automation.

Demonstrates chaining tasks, conditional logic, parallel execution,
and error recovery in automated workflows.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from terminal_agent import Agent, AgentConfig

logger = logging.getLogger(__name__)


@dataclass
class WorkflowStep:
    """A single step in an automation workflow."""

    name: str
    task: str
    depends_on: list[str] = field(default_factory=list)
    max_retries: int = 2
    timeout: int = 120
    continue_on_failure: bool = False


@dataclass
class WorkflowResult:
    """Result of running a workflow."""

    steps_completed: list[str] = field(default_factory=list)
    steps_failed: list[str] = field(default_factory=list)
    outputs: dict[str, str] = field(default_factory=dict)
    success: bool = True


class Workflow:
    """Multi-step workflow engine with dependency resolution."""

    def __init__(self, name: str, agent: Agent) -> None:
        self.name = name
        self._agent = agent
        self._steps: dict[str, WorkflowStep] = {}

    def add_step(self, step: WorkflowStep) -> None:
        """Add a step to the workflow."""
        self._steps[step.name] = step

    async def run(self, context: dict[str, Any] | None = None) -> WorkflowResult:
        """Execute the workflow.

        Resolves dependencies and runs steps in topological order.
        Independent steps run in parallel.
        """
        result = WorkflowResult()
        completed: set[str] = set()
        context = context or {}

        while len(completed) < len(self._steps):
            # Find steps whose dependencies are met
            ready = [
                step for name, step in self._steps.items()
                if name not in completed
                and all(d in completed for d in step.depends_on)
                and name not in result.steps_failed
            ]

            if not ready:
                # Deadlock or all remaining steps failed
                remaining = set(self._steps.keys()) - completed - set(result.steps_failed)
                for name in remaining:
                    result.steps_failed.append(name)
                    result.outputs[name] = "Skipped: dependency not met"
                break

            # Run ready steps in parallel
            tasks = [
                self._run_step(step, context, result)
                for step in ready
            ]
            await asyncio.gather(*tasks)

            for step in ready:
                if step.name in result.steps_completed:
                    completed.add(step.name)

        result.success = len(result.steps_failed) == 0
        return result

    async def _run_step(
        self,
        step: WorkflowStep,
        context: dict[str, Any],
        result: WorkflowResult,
    ) -> None:
        """Run a single step with retry logic."""
        # Build task prompt with context from previous steps
        prompt = step.task
        for dep in step.depends_on:
            if dep in result.outputs:
                prompt += f"\n\nPrevious step '{dep}' output:\n{result.outputs[dep][:500]}"

        for attempt in range(step.max_retries + 1):
            try:
                task_result = await asyncio.wait_for(
                    self._agent.run(prompt, context=context),
                    timeout=step.timeout,
                )

                if task_result.success:
                    result.steps_completed.append(step.name)
                    result.outputs[step.name] = task_result.output
                    logger.info("Step '%s' completed", step.name)
                    return
                else:
                    logger.warning(
                        "Step '%s' failed (attempt %d/%d): %s",
                        step.name, attempt + 1, step.max_retries + 1,
                        task_result.error,
                    )

            except TimeoutError:
                logger.warning("Step '%s' timed out (attempt %d)", step.name, attempt + 1)
            except Exception as exc:
                logger.error("Step '%s' error: %s", step.name, exc)

        # All retries exhausted
        if step.continue_on_failure:
            result.steps_completed.append(step.name)
            result.outputs[step.name] = "(failed but continuing)"
            logger.warning("Step '%s' failed but continuing", step.name)
        else:
            result.steps_failed.append(step.name)
            result.outputs[step.name] = "Failed after retries"
            logger.error("Step '%s' failed", step.name)


# ─── Example Workflows ─────────────────────────────────────────────

async def project_setup_workflow() -> None:
    """Automate project setup and initial configuration."""
    agent = Agent(config=AgentConfig())
    workflow = Workflow("project-setup", agent)

    # Step 1: Initialize project
    workflow.add_step(WorkflowStep(
        name="init",
        task="Create a new Python project with pyproject.toml, src layout, and git init",
        timeout=60,
    ))

    # Step 2: Set up dependencies (depends on init)
    workflow.add_step(WorkflowStep(
        name="deps",
        task="Add dependencies: fastapi, uvicorn, sqlalchemy, alembic, pytest, ruff",
        depends_on=["init"],
    ))

    # Step 3: Create config (depends on init)
    workflow.add_step(WorkflowStep(
        name="config",
        task="Create config.py with Pydantic Settings for environment-based configuration",
        depends_on=["init"],
    ))

    # Step 4: Create main app (depends on deps and config)
    workflow.add_step(WorkflowStep(
        name="app",
        task="Create the main FastAPI application with health check endpoint",
        depends_on=["deps", "config"],
    ))

    # Step 5: Tests (depends on app)
    workflow.add_step(WorkflowStep(
        name="tests",
        task="Create pytest tests for the health check endpoint",
        depends_on=["app"],
    ))

    # Step 6: CI config (independent)
    workflow.add_step(WorkflowStep(
        name="ci",
        task="Create GitHub Actions CI workflow for testing and linting",
        continue_on_failure=True,
    ))

    result = await workflow.run(context={"project_name": "my-api"})

    print(f"\nWorkflow: {workflow.name}")
    print(f"Success: {result.success}")
    print(f"Completed: {result.steps_completed}")
    print(f"Failed: {result.steps_failed}")


async def code_review_workflow() -> None:
    """Automated code review and fix cycle."""
    agent = Agent(config=AgentConfig())
    workflow = Workflow("code-review", agent)

    # Step 1: Lint
    workflow.add_step(WorkflowStep(
        name="lint",
        task="Run ruff check on the project and list all issues",
    ))

    # Step 2: Fix lint issues
    workflow.add_step(WorkflowStep(
        name="fix-lint",
        task="Fix all lint issues found. Apply auto-fixes where possible.",
        depends_on=["lint"],
    ))

    # Step 3: Type check
    workflow.add_step(WorkflowStep(
        name="typecheck",
        task="Run mypy and report type errors",
        depends_on=["fix-lint"],
    ))

    # Step 4: Tests
    workflow.add_step(WorkflowStep(
        name="tests",
        task="Run the test suite and report results",
        depends_on=["typecheck"],
    ))

    # Step 5: Security scan (independent of type check)
    workflow.add_step(WorkflowStep(
        name="security",
        task="Run bandit security scan and report vulnerabilities",
        depends_on=["fix-lint"],
    ))

    # Step 6: Summary
    workflow.add_step(WorkflowStep(
        name="summary",
        task="Summarize all findings and create a review report",
        depends_on=["tests", "security"],
    ))

    result = await workflow.run()
    print(f"\nReview complete: {'✅' if result.success else '❌'}")


async def simple_automation() -> None:
    """Simple sequential automation."""
    agent = Agent(config=AgentConfig())

    tasks = [
        "Check git status and report any uncommitted changes",
        "Run the test suite and report failures",
        "Check for outdated dependencies",
        "Generate a project health report",
    ]

    results = []
    for task in tasks:
        result = await agent.run(task)
        results.append((task, result.success, result.output[:200]))

    for task, success, output in results:
        status = "✅" if success else "❌"
        print(f"\n{status} {task}")
        print(f"   {output}")


async def main() -> None:
    """Run automation examples."""
    print("=== Automation Script Examples ===\n")

    # Uncomment to run:
    # await simple_automation()
    # await project_setup_workflow()
    # await code_review_workflow()


if __name__ == "__main__":
    asyncio.run(main())
