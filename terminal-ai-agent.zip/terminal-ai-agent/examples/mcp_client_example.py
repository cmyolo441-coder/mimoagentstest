"""MCP client — connect to external MCP servers from Terminal Agent.

Demonstrates discovering tools from MCP servers and using them
through the Terminal Agent interface.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

logger = logging.getLogger(__name__)


async def connect_to_mcp_server() -> None:
    """Connect to an MCP server and use its tools."""
    from terminal_agent.mcp.client import MCPClient

    # Connect to a running MCP server
    client = MCPClient(
        name="my-tools",
        transport="stdio",  # or "sse" for HTTP
        command=["python", "-m", "my_mcp_server"],
    )

    await client.connect()

    try:
        # List available tools
        tools = await client.list_tools()
        print(f"Server provides {len(tools)} tools:")
        for tool in tools:
            print(f"  - {tool['name']}: {tool['description'][:60]}...")

        # Call a tool
        result = await client.call_tool("greet", {"name": "World"})
        print(f"\nResult: {result}")

    finally:
        await client.disconnect()


async def use_mcp_with_agent() -> None:
    """Register MCP servers with the agent."""
    from terminal_agent import Agent, AgentConfig

    config = AgentConfig()
    agent = Agent(config=config)

    # Register MCP servers
    agent.add_mcp_server(
        name="filesystem-tools",
        transport="stdio",
        command=["npx", "-y", "@modelcontextprotocol/server-filesystem", "/home/user"],
    )

    agent.add_mcp_server(
        name="database-tools",
        transport="sse",
        url="http://localhost:3000/mcp",
    )

    # The agent can now use tools from all registered MCP servers
    result = await agent.run("Read the contents of config.json in my home directory")
    print(result.output)


async def multi_server_setup() -> None:
    """Connect to multiple MCP servers."""
    from terminal_agent.mcp.client import MCPClient, MCPClientPool

    pool = MCPClientPool()

    # Add servers
    pool.add(MCPClient(
        name="web-search",
        transport="stdio",
        command=["npx", "-y", "@modelcontextprotocol/server-brave-search"],
        env={"BRAVE_API_KEY": "your-key"},
    ))

    pool.add(MCPClient(
        name="github",
        transport="stdio",
        command=["npx", "-y", "@modelcontextprotocol/server-github"],
        env={"GITHUB_TOKEN": "your-token"},
    ))

    pool.add(MCPClient(
        name="custom",
        transport="sse",
        url="http://localhost:8080/mcp",
    ))

    # Connect all
    await pool.connect_all()

    # List all tools across servers
    all_tools = await pool.list_all_tools()
    for server_name, tools in all_tools.items():
        print(f"\n{server_name}:")
        for tool in tools:
            print(f"  - {tool['name']}")

    # Call tool by name (pool routes to correct server)
    result = await pool.call_tool("brave_web_search", {"query": "Python async"})
    print(result)

    await pool.disconnect_all()


async def stdio_server_example() -> None:
    """Connect to an MCP server via stdio (subprocess)."""
    from terminal_agent.mcp.client import MCPClient

    # This spawns the server as a subprocess
    client = MCPClient(
        name="local-tools",
        transport="stdio",
        command=["python", "my_mcp_server.py"],
        env={"DEBUG": "1"},
    )

    await client.connect()

    # Discover tools
    tools = await client.list_tools()
    print(f"Discovered {len(tools)} tools")

    # Use them
    for tool in tools:
        print(f"\nTool: {tool['name']}")
        print(f"  Description: {tool['description']}")
        print(f"  Parameters: {json.dumps(tool.get('inputSchema', {}), indent=2)}")

    await client.disconnect()


async def sse_server_example() -> None:
    """Connect to an MCP server via SSE (HTTP)."""
    from terminal_agent.mcp.client import MCPClient

    client = MCPClient(
        name="remote-tools",
        transport="sse",
        url="http://localhost:3000/mcp",
        headers={"Authorization": "Bearer token123"},
    )

    await client.connect()

    # Use tools
    result = await client.call_tool("query_database", {
        "sql": "SELECT * FROM users LIMIT 5",
    })
    print(f"Query result: {result}")

    await client.disconnect()


async def main() -> None:
    """Run examples."""
    print("=== MCP Client Examples ===\n")
    print("1. Connect to stdio server")
    print("2. Use MCP with agent")
    print("3. Multi-server setup")
    print()

    # Uncomment to run:
    # await connect_to_mcp_server()
    # await use_mcp_with_agent()
    # await multi_server_setup()


if __name__ == "__main__":
    asyncio.run(main())
