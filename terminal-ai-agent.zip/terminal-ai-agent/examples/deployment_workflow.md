# Deployment Workflow

Containerize and deploy applications with Terminal Agent.

## Overview

Build Docker images, set up orchestration, configure CI/CD,
and deploy to production environments.

## Step 1: Dockerize

```bash
terminal-agent run "Create a production Dockerfile:
- Multi-stage build (builder + runtime)
- Non-root user
- Health check
- Minimal image size (python:3.12-slim)
- Proper signal handling for graceful shutdown
- .dockerignore for the project"
```

## Step 2: Docker Compose

```bash
terminal-agent run "Create docker-compose.yml:
- App service with build context
- PostgreSQL with health check and init script
- Redis with persistence
- Nginx reverse proxy with SSL
- Volume mounts for development
- Network isolation between services"
```

## Step 3: Kubernetes Manifests

```bash
terminal-agent run "Create Kubernetes manifests:
- Deployment with 3 replicas, resource limits, readiness/liveness probes
- Service (ClusterIP) and Ingress with TLS
- ConfigMap for non-sensitive config
- Secret for database credentials
- HorizontalPodAutoscaler (CPU-based)
- PersistentVolumeClaim for uploads"
```

## Step 4: CI/CD Pipeline

```bash
terminal-agent run "Create GitHub Actions deployment pipeline:
- Build and push Docker image to registry
- Run tests before deploy
- Deploy to staging on push to main
- Deploy to production on tag (manual approval)
- Rollback capability
- Slack notifications"
```

## Step 5: Monitoring Setup

```bash
terminal-agent run "Set up monitoring:
- Prometheus metrics endpoint (/metrics)
- Grafana dashboard JSON for request rate, latency, errors
- Alert rules for error rate > 1%, latency > 500ms
- Log aggregation with structured JSON logs
- Distributed tracing setup"
```

## Step 6: Database Migrations

```bash
terminal-agent run "Create deployment-safe migration workflow:
- Pre-deploy migration script (backward compatible)
- Migration job in Kubernetes (runs before app deploy)
- Rollback script
- Migration validation step
- Zero-downtime migration patterns"
```

## Dockerfile Pattern

```dockerfile
# Build stage
FROM python:3.12-slim AS builder
WORKDIR /app
COPY pyproject.toml .
RUN pip install --no-cache-dir --target=/deps .

# Runtime stage
FROM python:3.12-slim
RUN useradd --create-home appuser
COPY --from=builder /deps /usr/local/lib/python3.12/site-packages
COPY src/ /app/src/
WORKDIR /app
USER appuser
HEALTHCHECK CMD curl -f http://localhost:8000/health || exit 1
CMD ["uvicorn", "src.app.main:app", "--host", "0.0.0.0"]
```

## Deployment Checklist

- [ ] Docker image builds successfully
- [ ] Health checks pass
- [ ] Database migrations applied
- [ ] Environment variables set
- [ ] SSL certificates configured
- [ ] Monitoring dashboards ready
- [ ] Alert rules configured
- [ ] Rollback plan documented
- [ ] Load test passed
- [ ] Security scan clean
