# Debugging Workflow

Debug and fix complex issues with Terminal Agent.

## Overview

Systematic debugging approach: reproduce, isolate, diagnose,
fix, and verify. Terminal Agent helps at every step.

## Step 1: Understand the Bug

```bash
terminal-agent run "A user reported: 'The app crashes when uploading
a CSV file larger than 10MB.' Investigate:
- Read the error logs
- Find the upload endpoint
- Trace the code path for file uploads
- Identify where the crash likely occurs"
```

## Step 2: Reproduce

```bash
terminal-agent run "Create a test that reproduces the large file upload crash:
- Generate a 15MB CSV file
- Upload it via the API
- Capture the full traceback
- Verify it fails consistently"
```

## Step 3: Isolate

```bash
terminal-agent run "The upload crash happens in file processing.
Isolate the issue:
- Check if the file is received completely
- Check the CSV parser for memory issues
- Check if there's a file size limit in the config
- Check the streaming vs buffering logic
- Add logging at each processing stage"
```

## Step 4: Diagnose

```bash
terminal-agent run "The crash is a MemoryError in the CSV parser.
Diagnose:
- The file is being loaded entirely into memory
- Check pandas read_csv vs chunked reading
- Check if the server has memory limits
- Profile memory usage during upload
- Find the exact line causing the OOM"
```

## Step 5: Fix

```bash
terminal-agent run "Fix the large file upload:
- Switch to chunked/streaming CSV processing
- Add file size validation before processing
- Set reasonable memory limits
- Add progress tracking for large uploads
- Update the test to verify the fix"
```

## Step 6: Verify

```bash
terminal-agent run "Verify the fix:
- Run the reproduction test (should pass now)
- Test with various file sizes (1MB, 10MB, 50MB, 100MB)
- Check memory usage stays bounded
- Verify error handling for corrupt files
- Run existing tests to check for regressions"
```

## Step 7: Prevent

```bash
terminal-agent run "Prevent similar issues:
- Add file size limits to the API config
- Add memory usage monitoring
- Create a load test for file uploads
- Document the file size limits
- Add a pre-upload size check endpoint"
```

## Debugging Techniques

### Binary Search
```bash
# Isolate the problematic commit
git bisect start
git bisect bad HEAD
git bisect good v1.0.0
# Agent runs tests at each step
```

### Rubber Duck
```bash
terminal-agent run "Explain step by step what happens when
a user uploads a CSV file, from HTTP request to database insert.
Include every function call and data transformation."
```

### Hypothesis Testing
```bash
terminal-agent run "Test these hypotheses for the crash:
1. File size limit → Upload 5MB (works) vs 15MB (fails)
2. Encoding → Upload UTF-8 CSV vs Latin-1 CSV
3. Column count → Upload 5 columns vs 500 columns
4. Row count → Upload 1000 rows vs 1M rows
Report which hypothesis is confirmed."
```

## Common Bug Patterns

| Pattern | Symptom | Fix |
|---------|---------|-----|
| OOM | MemoryError on large data | Stream/chunk processing |
| Race condition | Intermittent failures | Add locks/atomic ops |
| N+1 query | Slow endpoints | Eager loading/batching |
| Unclosed resource | Connection leaks | Context managers |
| Encoding error | Garbled text | Explicit encoding |
| Off-by-one | Wrong counts/ranges | Check boundary conditions |
