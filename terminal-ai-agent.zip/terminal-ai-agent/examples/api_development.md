# API Development Workflow

Design and implement a REST API with Terminal Agent.

## Overview

Build a production REST API with proper design patterns, validation,
error handling, rate limiting, and documentation.

## Step 1: API Design

```bash
terminal-agent run "Design a REST API for a task management system:
- Resources: users, projects, tasks, tags
- CRUD for each resource
- Filtering, pagination, sorting
- Proper HTTP methods and status codes
- Error response format

Output an OpenAPI 3.0 specification."
```

## Step 2: Schema & Validation

```bash
terminal-agent run "Create Pydantic models for the task management API:
- Request/response schemas
- Input validation (email format, string lengths, enums)
- Pagination schema (limit, offset, total)
- Error schema with detail, code, and fields
- Example values for each schema"
```

## Step 3: Implementation

```bash
terminal-agent run "Implement the task management API endpoints:
- Use FastAPI with dependency injection
- Service layer pattern (routes → services → repositories)
- Async database operations
- Proper error handling with custom exceptions
- Request ID tracking in responses"
```

## Step 4: Authentication & Authorization

```bash
terminal-agent run "Add auth to the API:
- OAuth2 with password flow
- Role-based access (admin, member, viewer)
- Project-level permissions
- API key authentication for service accounts
- Scope-based endpoint protection"
```

## Step 5: Rate Limiting

```bash
terminal-agent run "Implement rate limiting:
- Per-user rate limits (100 req/min for free, 1000 for premium)
- Per-endpoint limits (stricter for auth endpoints)
- Rate limit headers (X-RateLimit-Remaining, X-RateLimit-Reset)
- Redis-backed sliding window
- 429 responses with retry-after header"
```

## Step 6: Caching

```bash
terminal-agent run "Add caching layer:
- Cache-aside pattern for GET endpoints
- ETag support for conditional requests
- Cache invalidation on writes
- Redis cache with TTL
- Cache-Control headers"
```

## Step 7: Testing

```bash
terminal-agent run "Create API test suite:
- Contract tests against OpenAPI spec
- Integration tests with test database
- Load test scripts with locust
- Error scenario coverage
- Auth flow tests"
```

## Step 8: Documentation

```bash
terminal-agent run "Generate API documentation:
- Interactive Swagger UI setup
- Example curl commands for each endpoint
- Postman collection export
- Rate limit documentation
- Error code reference"
```

## Key Patterns

### Service Layer
```python
class TaskService:
    async def create_task(self, data: TaskCreate, user: User) -> Task:
        project = await self.project_repo.get(data.project_id)
        if not project or not user.can_access(project):
            raise ForbiddenError()
        return await self.task_repo.create(data, owner=user)
```

### Error Handling
```python
@app.exception_handler(AppError)
async def app_error_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": {"code": exc.code, "message": exc.message}},
    )
```
