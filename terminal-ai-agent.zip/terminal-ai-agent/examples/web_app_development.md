# Web App Development Workflow

Build a complete web application from scratch using Terminal Agent.

## Overview

This workflow demonstrates building a full-stack web application with:
- FastAPI backend with authentication
- SQLAlchemy ORM with migrations
- Pytest test suite
- Docker deployment

## Step 1: Project Initialization

```bash
terminal-agent run "Create a new FastAPI project with:
- src layout (src/app/)
- pyproject.toml with fastapi, uvicorn, sqlalchemy, alembic, pydantic, pytest, httpx, ruff, mypy
- .gitignore for Python
- Basic README.md"
```

## Step 2: Database Models

```bash
terminal-agent run "Create SQLAlchemy models for a blog application:
- User (id, email, hashed_password, name, created_at)
- Post (id, title, body, author_id FK, published_at, created_at)
- Comment (id, body, author_id FK, post_id FK, created_at)
Include __init__.py and proper relationships."
```

## Step 3: API Endpoints

```bash
terminal-agent run "Create FastAPI routes for:
- POST /auth/register — create user
- POST /auth/login — JWT token
- GET /posts — list posts with pagination
- POST /posts — create post (auth required)
- GET /posts/{id} — single post with comments
- POST /posts/{id}/comments — add comment (auth required)

Include Pydantic schemas, dependency injection for auth, and proper error handling."
```

## Step 4: Authentication

```bash
terminal-agent run "Implement JWT authentication:
- Password hashing with bcrypt
- JWT token creation/validation
- FastAPI dependency for current_user
- Token refresh endpoint
- Rate limiting on login attempts"
```

## Step 5: Database Migrations

```bash
terminal-agent run "Set up Alembic migrations:
- Initialize alembic with async support
- Create initial migration from models
- Add migration for indexes on email and post title"
```

## Step 6: Testing

```bash
terminal-agent run "Create comprehensive tests:
- Unit tests for models and schemas
- Integration tests for API endpoints
- Test fixtures for database, users, and auth tokens
- conftest.py with async test client
- Test for authentication flow"
```

## Step 7: Docker Setup

```bash
terminal-agent run "Create Docker configuration:
- Dockerfile with multi-stage build
- docker-compose.yml with app, postgres, and redis
- Health checks for all services
- Volume mounts for development"
```

## Step 8: CI/CD

```bash
terminal-agent run "Create GitHub Actions workflow:
- Run tests on push/PR
- Lint with ruff
- Type check with mypy
- Build and push Docker image on main
- Deploy to staging on main, production on tag"
```

## Expected Outcome

A production-ready FastAPI application with:
- ✅ Clean project structure
- ✅ Database with migrations
- ✅ JWT authentication
- ✅ Full test coverage
- ✅ Docker deployment
- ✅ CI/CD pipeline
