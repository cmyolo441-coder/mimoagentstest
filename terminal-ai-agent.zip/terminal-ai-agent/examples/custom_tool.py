"""Custom tool — build and register a tool for Terminal Agent.

Demonstrates creating a custom tool with validation, schema definition,
safety levels, and proper error handling.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from terminal_agent.tools.base_tool import BaseTool
from terminal_agent.tools.result import ToolResult
from terminal_agent.tools.registry import ToolRegistry


class DatabaseQueryTool(BaseTool):
    """Execute read-only SQL queries against a SQLite database.

    This tool only allows SELECT queries to prevent accidental data modification.
    Results are returned as formatted JSON.
    """

    name = "db_query"
    description = "Execute a read-only SQL query against a SQLite database"
    category = "database"
    safety_level = "moderate"

    def __init__(self, db_path: str = ":memory:") -> None:
        self._db_path = db_path

    def get_schema(self) -> dict[str, Any]:
        """Return the JSON Schema for this tool's parameters."""
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "SQL SELECT query to execute",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum rows to return",
                    "default": 100,
                    "minimum": 1,
                    "maximum": 10000,
                },
                "format": {
                    "type": "string",
                    "enum": ["json", "table", "csv"],
                    "description": "Output format",
                    "default": "json",
                },
            },
            "required": ["query"],
        }

    async def execute(
        self,
        query: str,
        limit: int = 100,
        format: str = "json",
    ) -> ToolResult:
        """Execute a read-only SQL query.

        Args:
            query: SQL SELECT query.
            limit: Maximum rows to return.
            format: Output format.

        Returns:
            ToolResult with query results.
        """
        import time

        start = time.monotonic()

        # Safety: only allow SELECT queries
        normalized = query.strip().upper()
        if not normalized.startswith("SELECT"):
            return ToolResult(
                output="",
                exit_code=1,
                error="Only SELECT queries are allowed. INSERT/UPDATE/DELETE are blocked.",
                duration_ms=(time.monotonic() - start) * 1000,
            )

        # Block dangerous keywords
        dangerous = ["DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "TRUNCATE"]
        for keyword in dangerous:
            if keyword in normalized:
                return ToolResult(
                    output="",
                    exit_code=1,
                    error=f"Blocked keyword: {keyword}. Only read queries allowed.",
                    duration_ms=(time.monotonic() - start) * 1000,
                )

        try:
            import sqlite3

            conn = sqlite3.connect(self._db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # Append limit if not present
            if "LIMIT" not in normalized:
                query = f"{query.rstrip(';')} LIMIT {limit}"

            cursor.execute(query)
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            conn.close()

            # Format output
            data = [dict(zip(columns, row)) for row in rows]
            output = self._format_output(data, columns, format)

            duration_ms = (time.monotonic() - start) * 1000
            return ToolResult(
                output=output,
                exit_code=0,
                duration_ms=duration_ms,
                metadata={"row_count": len(data), "columns": columns},
            )

        except Exception as exc:
            return ToolResult(
                output="",
                exit_code=1,
                error=f"Query failed: {exc}",
                duration_ms=(time.monotonic() - start) * 1000,
            )

    def _format_output(
        self, data: list[dict], columns: list[str], format: str
    ) -> str:
        """Format query results."""
        if format == "json":
            return json.dumps(data, indent=2, default=str)

        if format == "csv":
            lines = [",".join(columns)]
            for row in data:
                lines.append(",".join(str(row.get(c, "")) for c in columns))
            return "\n".join(lines)

        if format == "table":
            if not data:
                return "(no results)"

            # Calculate column widths
            widths = {c: len(c) for c in columns}
            for row in data:
                for c in columns:
                    widths[c] = max(widths[c], len(str(row.get(c, ""))))

            # Build table
            header = " | ".join(c.ljust(widths[c]) for c in columns)
            separator = "-+-".join("-" * widths[c] for c in columns)
            lines = [header, separator]
            for row in data:
                lines.append(" | ".join(str(row.get(c, "")).ljust(widths[c]) for c in columns))

            return "\n".join(lines)

        return json.dumps(data, indent=2, default=str)


class WeatherTool(BaseTool):
    """Fetch current weather for a location using a public API."""

    name = "weather"
    description = "Get current weather for a location"
    category = "network"
    safety_level = "safe"

    def get_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "City name or coordinates (lat,lon)",
                },
                "units": {
                    "type": "string",
                    "enum": ["metric", "imperial"],
                    "default": "metric",
                },
            },
            "required": ["location"],
        }

    async def execute(self, location: str, units: str = "metric") -> ToolResult:
        """Fetch weather data."""
        import time

        start = time.monotonic()

        try:
            import httpx

            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(
                    "https://wttr.in/{location}",
                    params={"format": "j1"},
                )
                resp.raise_for_status()
                data = resp.json()

            current = data.get("current_condition", [{}])[0]
            temp_key = "temp_C" if units == "metric" else "temp_F"
            unit_label = "°C" if units == "metric" else "°F"

            result = {
                "location": location,
                "temperature": f"{current.get(temp_key, 'N/A')}{unit_label}",
                "description": current.get("weatherDesc", [{}])[0].get("value", "Unknown"),
                "humidity": f"{current.get('humidity', 'N/A')}%",
                "wind_speed": current.get("windspeedKmph", "N/A") + " km/h",
            }

            return ToolResult(
                output=json.dumps(result, indent=2),
                exit_code=0,
                duration_ms=(time.monotonic() - start) * 1000,
            )

        except Exception as exc:
            return ToolResult(
                output="",
                exit_code=1,
                error=f"Weather fetch failed: {exc}",
                duration_ms=(time.monotonic() - start) * 1000,
            )


async def register_custom_tools() -> None:
    """Register custom tools with the agent."""
    from terminal_agent import Agent, AgentConfig

    # Create tools
    db_tool = DatabaseQueryTool(db_path="my_app.db")
    weather_tool = WeatherTool()

    # Register with agent
    config = AgentConfig()
    agent = Agent(config=config)

    agent.register_tool(db_tool)
    agent.register_tool(weather_tool)

    # Now the agent can use these tools
    result = await agent.run("What's the weather in Tokyo?")
    print(result.output)


async def standalone_usage() -> None:
    """Use a tool directly without the agent."""
    tool = DatabaseQueryTool(db_path=":memory:")

    # Create a test table
    import sqlite3

    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)")
    conn.executemany(
        "INSERT INTO users (name, age) VALUES (?, ?)",
        [("Alice", 30), ("Bob", 25), ("Charlie", 35)],
    )
    conn.commit()
    conn.close()

    tool = DatabaseQueryTool(db_path=":memory:")
    result = await tool.execute("SELECT * FROM users", format="table")
    print(result.output)


if __name__ == "__main__":
    asyncio.run(standalone_usage())
