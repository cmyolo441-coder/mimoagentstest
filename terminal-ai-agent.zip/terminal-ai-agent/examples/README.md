# Terminal Agent Examples

Practical examples and workflow guides for using Terminal Agent programmatically and via CLI.

## Python API Examples

| File | Description |
|------|-------------|
| `basic_usage.py` | Core API: create agent, run tasks, handle results |
| `custom_tool.py` | Build and register a custom tool |
| `custom_provider.py` | Add a new LLM provider |
| `custom_memory.py` | Implement a custom memory backend |
| `plugin_example.py` | Full plugin with tools, hooks, and config |
| `mcp_client_example.py` | Connect to external MCP servers |
| `mcp_server_example.py` | Expose your tools via MCP |
| `automation_script.py` | Automate multi-step workflows |
| `batch_processing.py` | Process multiple tasks concurrently |
| `multi_model_example.py` | Route tasks to different models |

## Workflow Guides

| File | Description |
|------|-------------|
| `web_app_development.md` | Build a web application from scratch |
| `api_development.md` | Design and implement a REST API |
| `data_pipeline.md` | Build an ETL data pipeline |
| `testing_workflow.md` | Generate and run comprehensive tests |
| `deployment_workflow.md` | Containerize and deploy applications |
| `refactoring_example.md` | Refactor legacy code safely |
| `debugging_example.md` | Debug and fix complex issues |

## Running the Examples

```bash
# Install terminal-agent first
pip install terminal-agent

# Set your API key
export OPENAI_API_KEY="sk-..."

# Run an example
python examples/basic_usage.py
```

## Prerequisites

- Python 3.10+
- `terminal-agent` installed (`pip install terminal-agent`)
- At least one LLM provider configured
