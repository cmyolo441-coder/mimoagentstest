"""Multi-model — route tasks to different models.

Demonstrates configuring multiple LLM providers and routing
different task types to the optimal model.
"""

from __future__ import annotations

import asyncio
from typing import Any

from terminal_agent import Agent, AgentConfig
from terminal_agent.llm.router import ModelRouter, RoutingRule


async def basic_routing() -> None:
    """Route tasks based on type."""
    config = AgentConfig(
        primary_provider="openai",
        primary_model="gpt-4o",
    )

    agent = Agent(config=config)

    # Register additional providers
    agent.register_provider("fast", provider_config={
        "provider": "anthropic",
        "model": "claude-3-haiku-20240307",
    })

    agent.register_provider("reasoning", provider_config={
        "provider": "openai",
        "model": "o1-preview",
    })

    # Define routing rules
    router = ModelRouter()
    router.add_rule(RoutingRule(
        name="quick-tasks",
        condition=lambda task: task.estimated_tokens < 500,
        provider="fast",
        reason="Short tasks use fast model",
    ))
    router.add_rule(RoutingRule(
        name="complex-reasoning",
        condition=lambda task: any(
            kw in task.prompt.lower()
            for kw in ["analyze", "debug", "architect", "design", "review"]
        ),
        provider="reasoning",
        reason="Complex tasks use reasoning model",
    ))

    agent.set_router(router)

    # These will use different models automatically
    await agent.run("What time is it?")  # → fast (short)
    await agent.run("Design a microservices architecture for...")  # → reasoning


async def cost_optimized_routing() -> None:
    """Route to minimize cost while maintaining quality."""
    config = AgentConfig()
    agent = Agent(config=config)

    # Cheap model for simple tasks
    agent.register_provider("cheap", provider_config={
        "provider": "deepseek",
        "model": "deepseek-chat",
    })

    # Mid-tier for most tasks
    agent.register_provider("balanced", provider_config={
        "provider": "anthropic",
        "model": "claude-3-5-sonnet-20241022",
    })

    # Premium for critical tasks
    agent.register_provider("premium", provider_config={
        "provider": "openai",
        "model": "gpt-4o",
    })

    router = ModelRouter()
    router.add_rule(RoutingRule(
        name="simple",
        condition=lambda t: t.complexity == "low",
        provider="cheap",
    ))
    router.add_rule(RoutingRule(
        name="standard",
        condition=lambda t: t.complexity == "medium",
        provider="balanced",
    ))
    router.add_rule(RoutingRule(
        name="complex",
        condition=lambda t: t.complexity == "high",
        provider="premium",
    ))

    agent.set_router(router)

    # Check estimated costs
    costs = agent.get_cost_summary()
    print(f"Total cost: ${costs.total:.4f}")
    for provider, cost in costs.by_provider.items():
        print(f"  {provider}: ${cost:.4f}")


async def fallback_chain() -> None:
    """Set up provider fallback chain."""
    config = AgentConfig(
        primary_provider="openai",
        primary_model="gpt-4o",
    )

    agent = Agent(config=config)

    # Configure fallbacks
    agent.set_fallback_chain([
        {"provider": "anthropic", "model": "claude-3-5-sonnet-20241022"},
        {"provider": "deepseek", "model": "deepseek-chat"},
        {"provider": "ollama", "model": "llama3"},
    ])

    # Agent will try each provider in order on failure
    result = await agent.run("Summarize this codebase")
    print(f"Used provider: {result.provider_used}")


async def task_specific_models() -> None:
    """Use different models for different task types."""
    config = AgentConfig()
    agent = Agent(config=config)

    # Code tasks → Claude
    code_result = await agent.run(
        "Write a Python function to merge sorted arrays",
        preferred_provider="anthropic",
        preferred_model="claude-3-5-sonnet-20241022",
    )
    print(f"Code (Claude): {code_result.output[:100]}...")

    # Creative tasks → GPT-4o
    creative_result = await agent.run(
        "Write a catchy tagline for a developer tool",
        preferred_provider="openai",
        preferred_model="gpt-4o",
    )
    print(f"Creative (GPT-4o): {creative_result.output[:100]}...")

    # Quick tasks → Haiku
    quick_result = await agent.run(
        "What's the Python syntax for list comprehension?",
        preferred_provider="anthropic",
        preferred_model="claude-3-haiku-20240307",
    )
    print(f"Quick (Haiku): {quick_result.output[:100]}...")


async def local_and_cloud() -> None:
    """Mix local and cloud models."""
    config = AgentConfig()
    agent = Agent(config=config)

    # Local model for development (free, private)
    agent.register_provider("local", provider_config={
        "provider": "ollama",
        "model": "codellama",
        "base_url": "http://localhost:11434",
    })

    # Cloud model for production quality
    agent.register_provider("cloud", provider_config={
        "provider": "openai",
        "model": "gpt-4o",
    })

    # Use local for drafts, cloud for final
    draft = await agent.run(
        "Write a draft API endpoint for user registration",
        preferred_provider="local",
    )

    final = await agent.run(
        f"Polish this code:\n{draft.output}",
        preferred_provider="cloud",
    )

    print(f"Final:\n{final.output}")


async def main() -> None:
    """Run multi-model examples."""
    print("=== Multi-Model Examples ===\n")

    # Uncomment to run:
    # await basic_routing()
    # await cost_optimized_routing()
    # await fallback_chain()
    # await task_specific_models()
    # await local_and_cloud()


if __name__ == "__main__":
    asyncio.run(main())
