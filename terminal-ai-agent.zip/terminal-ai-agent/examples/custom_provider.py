"""Custom provider — add a new LLM provider to Terminal Agent.

Demonstrates implementing the BaseProvider interface with both
synchronous and streaming completion support.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.llm.base_provider import BaseProvider, LLMResponse, StreamChunk
from terminal_agent.config.schema import LLMConfig

logger = logging.getLogger(__name__)


class MyCustomProvider(BaseProvider):
    """Custom LLM provider for an OpenAI-compatible API.

    Works with any API that implements the OpenAI chat completions format,
    including local servers (vLLM, llama.cpp, text-generation-inference).
    """

    name = "custom"
    supported_models = ["custom-model-1", "custom-model-2"]

    def __init__(self, config: LLMConfig) -> None:
        super().__init__(config)
        self.api_key = config.api_key or "no-key"
        self.base_url = (config.base_url or "https://api.example.com/v1").rstrip("/")
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(config.timeout or 120.0, connect=10.0),
        )

    async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> LLMResponse:
        """Send a completion request.

        Args:
            messages: Chat messages with 'role' and 'content'.
            **kwargs: Override parameters (model, temperature, max_tokens, tools).

        Returns:
            LLMResponse with the completion.
        """
        payload = self._build_payload(messages, stream=False, **kwargs)

        response = await self.client.post("/chat/completions", json=payload)
        response.raise_for_status()
        data = response.json()

        return self._parse_response(data)

    async def stream(
        self, messages: list[dict[str, Any]], **kwargs: Any
    ) -> AsyncIterator[StreamChunk]:
        """Stream a completion response.

        Args:
            messages: Chat messages.
            **kwargs: Override parameters.

        Yields:
            StreamChunk objects as tokens arrive.
        """
        payload = self._build_payload(messages, stream=True, **kwargs)

        async with self.client.stream("POST", "/chat/completions", json=payload) as response:
            response.raise_for_status()

            buffer = ""
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue

                data = line[6:]
                if data.strip() == "[DONE]":
                    break

                try:
                    chunk_data = json.loads(data)
                    chunk = self._parse_stream_chunk(chunk_data)
                    if chunk:
                        yield chunk
                except json.JSONDecodeError:
                    logger.warning("Failed to parse stream chunk: %s", data[:100])

    async def list_models(self) -> list[str]:
        """List available models.

        Returns:
            List of model identifiers.
        """
        try:
            response = await self.client.get("/models")
            response.raise_for_status()
            data = response.json()
            return [m["id"] for m in data.get("data", [])]
        except Exception:
            return list(self.supported_models)

    async def close(self) -> None:
        """Close the HTTP client."""
        await self.client.aclose()

    def _build_payload(
        self,
        messages: list[dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Build the request payload."""
        payload: dict[str, Any] = {
            "model": kwargs.get("model", self.config.primary_model),
            "messages": messages,
            "stream": stream,
        }

        # Optional parameters
        if "temperature" in kwargs or self.config.temperature is not None:
            payload["temperature"] = kwargs.get("temperature", self.config.temperature)
        if "max_tokens" in kwargs or self.config.max_tokens is not None:
            payload["max_tokens"] = kwargs.get("max_tokens", self.config.max_tokens)
        if "tools" in kwargs:
            payload["tools"] = kwargs["tools"]
        if "response_format" in kwargs:
            payload["response_format"] = kwargs["response_format"]

        return payload

    def _parse_response(self, data: dict[str, Any]) -> LLMResponse:
        """Parse a complete response."""
        choice = data["choices"][0]
        message = choice["message"]
        usage = data.get("usage", {})

        return LLMResponse(
            content=message.get("content") or "",
            tool_calls=self._parse_tool_calls(message.get("tool_calls", [])),
            tokens_in=usage.get("prompt_tokens", 0),
            tokens_out=usage.get("completion_tokens", 0),
            cost=self._calculate_cost(usage),
            model=data.get("model", ""),
            finish_reason=choice.get("finish_reason", "stop"),
        )

    def _parse_stream_chunk(self, data: dict[str, Any]) -> StreamChunk | None:
        """Parse a streaming chunk."""
        choices = data.get("choices", [])
        if not choices:
            return None

        delta = choices[0].get("delta", {})
        return StreamChunk(
            content=delta.get("content", ""),
            tool_calls=self._parse_tool_calls(delta.get("tool_calls", [])),
            finish_reason=choices[0].get("finish_reason"),
        )

    def _parse_tool_calls(self, raw_calls: list[dict]) -> list[dict[str, Any]]:
        """Parse tool call objects."""
        result = []
        for tc in raw_calls:
            func = tc.get("function", {})
            result.append({
                "id": tc.get("id", ""),
                "name": func.get("name", ""),
                "arguments": func.get("arguments", ""),
            })
        return result

    def _calculate_cost(self, usage: dict[str, Any]) -> float:
        """Calculate cost from token usage."""
        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)

        # Example pricing — adjust per your model
        prompt_cost = prompt_tokens * 0.000003
        completion_cost = completion_tokens * 0.000015

        return prompt_cost + completion_cost


async def main() -> None:
    """Register and use the custom provider."""
    from terminal_agent import Agent, AgentConfig

    # Configure
    config = LLMConfig(
        provider="custom",
        api_key="your-api-key",
        base_url="http://localhost:8000/v1",
        primary_model="custom-model-1",
        temperature=0.7,
        max_tokens=4096,
    )

    # Register with agent
    agent_config = AgentConfig(primary_provider="custom")
    agent = Agent(config=agent_config)
    agent.register_provider("custom", MyCustomProvider(config))

    # Use it
    result = await agent.run("Explain quantum computing in simple terms")
    print(result.output)


if __name__ == "__main__":
    asyncio.run(main())
