"""Batch processing — process multiple tasks concurrently.

Demonstrates parallel task execution, rate limiting, progress tracking,
and result aggregation for large-scale batch operations.
"""

from __future__ import annotations

import asyncio
import csv
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from terminal_agent import Agent, AgentConfig


@dataclass
class BatchTask:
    """A task to process in a batch."""

    id: str
    prompt: str
    context: dict[str, Any] = field(default_factory=dict)


@dataclass
class BatchResult:
    """Result of a single batch task."""

    task_id: str
    success: bool
    output: str
    duration_ms: float
    tokens_used: int = 0
    error: str | None = None


@dataclass
class BatchSummary:
    """Summary of a batch run."""

    total: int = 0
    succeeded: int = 0
    failed: int = 0
    total_duration_ms: float = 0.0
    total_tokens: int = 0
    results: list[BatchResult] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        return self.succeeded / max(self.total, 1)


class BatchProcessor:
    """Process multiple tasks concurrently with rate limiting.

    Features:
        - Configurable concurrency limit
        - Per-task timeout
        - Progress callbacks
        - Result aggregation
        - Error isolation
    """

    def __init__(
        self,
        max_concurrency: int = 5,
        timeout_per_task: int = 120,
        rate_limit_per_second: float | None = None,
    ) -> None:
        self._max_concurrency = max_concurrency
        self._timeout = timeout_per_task
        self._rate_limit = rate_limit_per_second
        self._semaphore = asyncio.Semaphore(max_concurrency)
        self._progress_callback: Any = None
        self._completed = 0
        self._total = 0

    def on_progress(self, callback: Any) -> None:
        """Set a progress callback.

        Args:
            callback: Called with (completed, total, current_task_id).
        """
        self._progress_callback = callback

    async def process(
        self,
        tasks: list[BatchTask],
        agent: Agent | None = None,
    ) -> BatchSummary:
        """Process a batch of tasks.

        Args:
            tasks: List of tasks to process.
            agent: Agent instance (creates new one if None).

        Returns:
            BatchSummary with all results.
        """
        if agent is None:
            agent = Agent(config=AgentConfig())

        self._total = len(tasks)
        self._completed = 0
        summary = BatchSummary(total=len(tasks))

        start = time.monotonic()

        # Process with concurrency control
        async def run_task(task: BatchTask) -> BatchResult:
            async with self._semaphore:
                if self._rate_limit:
                    await asyncio.sleep(1.0 / self._rate_limit)

                return await self._execute_task(task, agent)

        coros = [run_task(task) for task in tasks]
        results = await asyncio.gather(*coros, return_exceptions=True)

        for result in results:
            if isinstance(result, Exception):
                summary.failed += 1
                summary.results.append(BatchResult(
                    task_id="unknown",
                    success=False,
                    output="",
                    duration_ms=0,
                    error=str(result),
                ))
            else:
                summary.results.append(result)
                if result.success:
                    summary.succeeded += 1
                else:
                    summary.failed += 1
                summary.total_tokens += result.tokens_used

        summary.total_duration_ms = (time.monotonic() - start) * 1000
        return summary

    async def _execute_task(self, task: BatchTask, agent: Agent) -> BatchResult:
        """Execute a single task."""
        start = time.monotonic()

        try:
            result = await asyncio.wait_for(
                agent.run(task.prompt, context=task.context),
                timeout=self._timeout,
            )

            self._completed += 1
            if self._progress_callback:
                self._progress_callback(self._completed, self._total, task.id)

            return BatchResult(
                task_id=task.id,
                success=result.success,
                output=result.output,
                duration_ms=(time.monotonic() - start) * 1000,
                tokens_used=result.tokens_total,
                error=result.error if not result.success else None,
            )

        except TimeoutError:
            self._completed += 1
            return BatchResult(
                task_id=task.id,
                success=False,
                output="",
                duration_ms=(time.monotonic() - start) * 1000,
                error="Task timed out",
            )
        except Exception as exc:
            self._completed += 1
            return BatchResult(
                task_id=task.id,
                success=False,
                output="",
                duration_ms=(time.monotonic() - start) * 1000,
                error=str(exc),
            )


def load_tasks_from_csv(path: str) -> list[BatchTask]:
    """Load batch tasks from a CSV file.

    Expected columns: id, prompt, and optional context columns.
    """
    tasks = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            context = {k: v for k, v in row.items() if k not in ("id", "prompt")}
            tasks.append(BatchTask(
                id=row["id"],
                prompt=row["prompt"],
                context=context,
            ))
    return tasks


def load_tasks_from_json(path: str) -> list[BatchTask]:
    """Load batch tasks from a JSON file."""
    with open(path) as f:
        data = json.load(f)

    return [
        BatchTask(
            id=item.get("id", str(i)),
            prompt=item["prompt"],
            context=item.get("context", {}),
        )
        for i, item in enumerate(data)
    ]


# ─── Example Usage ──────────────────────────────────────────────────

async def review_files_batch() -> None:
    """Review multiple files in parallel."""
    files = [
        "src/main.py",
        "src/config.py",
        "src/models.py",
        "src/routes.py",
        "src/utils.py",
    ]

    tasks = [
        BatchTask(
            id=f"review-{f}",
            prompt=f"Review {f} for bugs, style issues, and improvements. Provide a summary.",
            context={"file": f},
        )
        for f in files
    ]

    processor = BatchProcessor(max_concurrency=3, timeout_per_task=60)
    processor.on_progress(lambda done, total, tid: print(f"  [{done}/{total}] {tid}"))

    print("Reviewing files...")
    summary = await processor.process(tasks)

    print(f"\n{'='*60}")
    print(f"Results: {summary.succeeded}/{summary.total} succeeded")
    print(f"Duration: {summary.total_duration_ms:.0f}ms")
    print(f"Tokens: {summary.total_tokens}")

    for result in summary.results:
        status = "✅" if result.success else "❌"
        print(f"\n{status} {result.task_id}")
        if result.success:
            print(f"   {result.output[:150]}...")
        else:
            print(f"   Error: {result.error}")


async def generate_docs_batch() -> None:
    """Generate documentation for multiple modules."""
    modules = [
        ("terminal_agent.tools", "Generate API documentation for the tools module"),
        ("terminal_agent.memory", "Generate API documentation for the memory module"),
        ("terminal_agent.llm", "Generate API documentation for the LLM module"),
        ("terminal_agent.plugins", "Generate API documentation for the plugins module"),
    ]

    tasks = [
        BatchTask(id=name, prompt=prompt, context={"module": name})
        for name, prompt in modules
    ]

    processor = BatchProcessor(max_concurrency=2)

    def progress(done, total, task_id):
        pct = (done / total) * 100
        print(f"  [{pct:5.1f}%] {task_id}")

    processor.on_progress(progress)

    summary = await processor.process(tasks)

    # Save results
    for result in summary.results:
        if result.success:
            out_path = Path(f"docs/api/{result.task_id.replace('.', '/')}.md")
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(result.output)
            print(f"  Saved: {out_path}")


async def main() -> None:
    """Run batch processing examples."""
    print("=== Batch Processing Examples ===\n")

    # Uncomment to run:
    # await review_files_batch()
    # await generate_docs_batch()

    print("Edit the main() function to uncomment an example to run.")


if __name__ == "__main__":
    asyncio.run(main())
