# Changelog

All notable changes to Terminal Agent will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Complete documentation suite (user guide, developer guide, architecture docs, API reference, tutorials)
- Community guidelines (contributing guide, code of conduct, security policy)

## [0.1.0] - 2025-01-15

### Added
- Initial release of Terminal Agent
- Core agent loop with Think-Act-Observe-Verify cycle
- CLI interface with subcommands: `run`, `chat`, `config`, `sessions`, `history`, `plugins`, `mcp`, `tools`, `models`, `health`, `update`, `export`, `import`
- TUI interface with interactive terminal UI (Textual-based)
- Configuration system with TOML files, environment variables, and CLI overrides
- LLM Engine with provider abstraction layer
- LLM providers: OpenAI, Anthropic, Google Gemini, Ollama, LiteLLM, Azure OpenAI, AWS Bedrock, Cohere, Together AI, Groq, DeepSeek, Mistral, xAI, custom OpenAI-compatible
- Streaming response support for all providers
- Token counting and cost tracking per request and cumulative
- Provider fallback chains for automatic failover
- Three-tier memory system:
  - Short-term memory (conversation turns)
  - Working memory (active file contents, current state)
  - Long-term memory (persistent with vector embeddings)
- Vector store backends: ChromaDB (default), FAISS, Pinecone, Qdrant, Weaviate, Milvus, in-memory
- Memory consolidation, decay, and semantic search
- Context manager with token budget management and intelligent assembly
- Prompt manager with template library and optimization
- Orchestrator with multi-step planning, execution, and re-planning
- Session management (start, pause, resume, end)
- 40+ built-in tools across 13 categories:
  - Shell tools: command execution, background processes, pipelines, SSH, Docker exec
  - Filesystem tools: read, write, edit, search, move, copy, delete, metadata, compression
  - Code tools: AST parsing, symbol extraction, refactoring, formatting, linting, complexity analysis
  - Git tools: full git integration (status, commit, branch, merge, rebase, stash, history, tags, bisect)
  - Package manager tools: 25+ package managers (npm, pip, cargo, go, maven, etc.)
  - Database tools: PostgreSQL, MySQL, SQLite, MongoDB, Redis, Elasticsearch
  - Docker tools: images, containers, compose, volumes, networks
  - Network tools: HTTP client, DNS, SSL, port checking, WebSocket, gRPC, GraphQL
  - Search tools: regex, semantic, fuzzy, symbol, web, documentation search
  - Testing tools: run, parse, generate for 15+ frameworks
  - Code generation tools: project scaffolding, boilerplate, templates for 20+ frameworks
  - Documentation tools: README, API docs, changelog, docstrings generation
  - DevOps tools: Kubernetes, Terraform, Ansible, CI/CD, cloud resources
- Safety system with 6 levels (Unrestricted, Minimal, Standard, Moderate, Strict, Review)
- Command pattern blocking for dangerous operations
- Path access control for sensitive directories
- Confirmation prompts for destructive actions
- Verification engine: syntax, runtime, type, schema, file, test, build, regression, semantic checks
- Error recovery with 6 levels: retry, modified retry, alternative approach, re-plan, ask user, graceful abort
- Self-improvement engine: trace recording, pattern learning, prompt optimization, A/B testing
- Plugin system with discovery, loading, sandboxing, lifecycle management
- MCP client and server implementation
- Logging system with structured JSON and console output
- Tracing system for complete execution replay
- Metrics collection (counters, gauges, histograms, timers)
- Rate limiting (token bucket, sliding window, per-provider)
- Caching layer (memory, disk, database backends)
- Diff engine for file change tracking
- Notification system (console, desktop, webhook)
- Shell completion scripts (bash, zsh, fish)
- Docker and Docker Compose support
- GitHub Actions CI/CD pipelines
- Pre-commit hooks configuration

[Unreleased]: https://github.com/terminal-agent/terminal-agent/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/terminal-agent/terminal-agent/releases/tag/v0.1.0
