"""Test detector — identify test frameworks and test configuration.

Detects testing frameworks, test directories, and test
configuration patterns in a project.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

TEST_FRAMEWORKS: dict[str, dict[str, Any]] = {
    # Python
    "pytest": {
        "files": ["pytest.ini", "conftest.py", "pyproject.toml"],
        "content": ["[tool.pytest", "pytest"],
        "dirs": ["tests", "test"],
        "extensions": ["_test.py", "test_"],
    },
    "unittest": {
        "content": ["import unittest", "from unittest"],
        "extensions": ["_test.py", "test_"],
    },
    "nose2": {
        "files": ["unittest.cfg", "nose2.cfg"],
        "content": ["import nose2"],
    },
    # JavaScript/TypeScript
    "jest": {
        "files": ["jest.config.js", "jest.config.ts", "jest.config.mjs", "jest.config.json"],
        "package_dep": "jest",
        "extensions": [".test.js", ".test.ts", ".test.jsx", ".test.tsx", ".spec.js", ".spec.ts"],
    },
    "vitest": {
        "files": ["vitest.config.js", "vitest.config.ts"],
        "package_dep": "vitest",
        "extensions": [".test.js", ".test.ts", ".spec.js", ".spec.ts"],
    },
    "mocha": {
        "files": [".mocharc.yml", ".mocharc.js"],
        "package_dep": "mocha",
        "extensions": [".test.js", ".spec.js"],
    },
    "jasmine": {
        "files": ["jasmine.json", "spec/support/jasmine.json"],
        "package_dep": "jasmine",
    },
    "cypress": {
        "files": ["cypress.config.js", "cypress.config.ts"],
        "package_dep": "cypress",
        "dirs": ["cypress"],
    },
    "playwright": {
        "files": ["playwright.config.js", "playwright.config.ts"],
        "package_dep": "@playwright/test",
    },
    # Go
    "go-test": {
        "extensions": ["_test.go"],
    },
    # Rust
    "cargo-test": {
        "content": ["#[test]", "#[cfg(test)]"],
    },
    # Java
    "junit": {
        "files": [],
        "content": ["import org.junit", "import org.junit.jupiter"],
    },
    "testng": {
        "files": ["testng.xml"],
        "content": ["import org.testng"],
    },
    # Ruby
    "rspec": {
        "files": [".rspec", "spec/spec_helper.rb"],
        "dirs": ["spec"],
    },
    "minitest": {
        "content": ["require 'minitest'"],
    },
    # PHP
    "phpunit": {
        "files": ["phpunit.xml", "phpunit.xml.dist"],
        "content": ["use PHPUnit"],
    },
    # Elixir
    "exunit": {
        "content": ["use ExUnit.Case"],
    },
}


class TestDetector:
    """Detects test frameworks and test configuration in a project.

    Identifies test frameworks by checking configuration files,
    dependency declarations, source patterns, and directory structure.
    """

    def detect(self, path: Path, languages: list[str] | None = None) -> str | None:
        """Detect the primary test framework.

        Args:
            path: Project root directory.
            languages: Detected languages for context.

        Returns:
            Name of the primary test framework, or None.
        """
        all_detected = self.detect_all(path, languages)
        return all_detected[0] if all_detected else None

    def detect_all(self, path: Path, languages: list[str] | None = None) -> list[str]:
        """Detect all test frameworks in use.

        Args:
            path: Project root directory.
            languages: Detected languages.

        Returns:
            List of detected test frameworks.
        """
        results: list[str] = []

        for fw_name, indicators in TEST_FRAMEWORKS.items():
            score = 0

            for filename in indicators.get("files", []):
                filepath = path / filename
                if filepath.is_file():
                    score += 2

            for content_marker in indicators.get("content", []):
                if self._search_content(path, content_marker):
                    score += 2
                    break

            for dirname in indicators.get("dirs", []):
                if (path / dirname).is_dir():
                    score += 1

            pkg_dep = indicators.get("package_dep")
            if pkg_dep and self._check_package_dep(path, pkg_dep):
                score += 3

            extensions = indicators.get("extensions", [])
            if extensions and self._check_test_files(path, extensions):
                score += 2

            if score >= 2:
                results.append(fw_name)

        logger.debug("Detected test frameworks: %s", results)
        return results

    def _search_content(self, path: Path, marker: str) -> bool:
        """Search for a content marker in config files."""
        config_files = [
            "pyproject.toml", "setup.cfg", "setup.py",
            "package.json", "Cargo.toml", "go.mod",
        ]
        for filename in config_files:
            filepath = path / filename
            if filepath.is_file():
                try:
                    content = filepath.read_text(encoding="utf-8")
                    if marker in content:
                        return True
                except OSError:
                    continue
        return False

    def _check_package_dep(self, path: Path, dep_name: str) -> bool:
        """Check if a package dependency exists."""
        pkg_json = path / "package.json"
        if pkg_json.is_file():
            try:
                import json
                data = json.loads(pkg_json.read_text(encoding="utf-8"))
                all_deps: dict[str, str] = {}
                all_deps.update(data.get("dependencies", {}))
                all_deps.update(data.get("devDependencies", {}))
                return dep_name in all_deps
            except (OSError, json.JSONDecodeError):
                pass
        return False

    def _check_test_files(self, path: Path, extensions: list[str]) -> bool:
        """Check if test files exist with given extensions/patterns."""
        skip_dirs = {"node_modules", ".git", "__pycache__", "vendor", "dist", "build"}
        for ext in extensions:
            for file_path in path.rglob(f"*{ext}*"):
                if any(skip in str(file_path) for skip in skip_dirs):
                    continue
                if file_path.is_file():
                    return True
        return False
