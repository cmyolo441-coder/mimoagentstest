"""Project analysis — detect and understand project characteristics.

Provides automatic detection of languages, frameworks, build systems,
test frameworks, CI/CD, and other project attributes.
"""

from __future__ import annotations

from terminal_agent.project.analyzer import ProjectAnalyzer
from terminal_agent.project.language_detector import LanguageDetector
from terminal_agent.project.framework_detector import FrameworkDetector
from terminal_agent.project.build_detector import BuildDetector
from terminal_agent.project.test_detector import TestDetector
from terminal_agent.project.package_detector import PackageDetector
from terminal_agent.project.cicd_detector import CICDDetector
from terminal_agent.project.entry_point_detector import EntryPointDetector
from terminal_agent.project.convention_detector import ConventionDetector
from terminal_agent.project.architecture_detector import ArchitectureDetector
from terminal_agent.project.dependency_analyzer import DependencyAnalyzer
from terminal_agent.project.complexity_estimator import ComplexityEstimator

__all__ = [
    "ProjectAnalyzer",
    "LanguageDetector",
    "FrameworkDetector",
    "BuildDetector",
    "TestDetector",
    "PackageDetector",
    "CICDDetector",
    "EntryPointDetector",
    "ConventionDetector",
    "ArchitectureDetector",
    "DependencyAnalyzer",
    "ComplexityEstimator",
]
