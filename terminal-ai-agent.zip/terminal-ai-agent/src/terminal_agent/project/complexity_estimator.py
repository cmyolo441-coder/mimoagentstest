"""Complexity estimator — estimate project size and complexity.

Provides metrics on project complexity including file counts,
code volume, dependency depth, and structural complexity.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

SKIP_DIRS = frozenset({
    "node_modules", ".git", "__pycache__", "vendor", "dist", "build",
    ".tox", ".venv", "venv", ".mypy_cache", ".pytest_cache",
    "target", ".next", ".nuxt", "coverage", "htmlcov",
})

CODE_EXTENSIONS = frozenset({
    ".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs", ".java", ".kt",
    ".scala", ".c", ".cpp", ".cc", ".cxx", ".h", ".hpp", ".cs", ".rb",
    ".php", ".swift", ".dart", ".lua", ".r", ".hs", ".ex", ".exs",
    ".zig", ".nim", ".jl", ".clj", ".vue", ".svelte",
})


@dataclass
class ComplexityMetrics:
    """Project complexity metrics."""
    total_files: int = 0
    code_files: int = 0
    total_lines: int = 0
    code_lines: int = 0
    comment_lines: int = 0
    blank_lines: int = 0
    directories: int = 0
    max_depth: int = 0
    avg_file_size: float = 0.0
    largest_files: list[tuple[str, int]] = field(default_factory=list)
    complexity_score: float = 0.0
    size_category: str = ""  # tiny, small, medium, large, huge


class ComplexityEstimator:
    """Estimates project complexity based on file metrics.

    Analyzes file counts, line counts, directory depth, and
    other structural metrics to produce a complexity estimate.
    """

    def __init__(self, max_files: int = 5000):
        self._max_files = max_files

    def estimate(self, path: Path, languages: list[str] | None = None) -> dict[str, Any]:
        """Estimate project complexity.

        Args:
            path: Project root directory.
            languages: Detected languages.

        Returns:
            Dictionary with complexity metrics.
        """
        metrics = self._compute_metrics(path)
        return {
            "total_files": metrics.total_files,
            "code_files": metrics.code_files,
            "total_lines": metrics.total_lines,
            "code_lines": metrics.code_lines,
            "comment_lines": metrics.comment_lines,
            "blank_lines": metrics.blank_lines,
            "directories": metrics.directories,
            "max_depth": metrics.max_depth,
            "avg_file_size": round(metrics.avg_file_size, 1),
            "complexity_score": round(metrics.complexity_score, 2),
            "size_category": metrics.size_category,
            "largest_files": metrics.largest_files[:5],
        }

    def quick_estimate(self, path: Path) -> str:
        """Quick complexity estimate (just category).

        Args:
            path: Project root directory.

        Returns:
            Size category string.
        """
        file_count = 0
        for _ in self._walk_files(path):
            file_count += 1
            if file_count > 1000:
                return "large"

        if file_count < 10:
            return "tiny"
        if file_count < 50:
            return "small"
        if file_count < 200:
            return "medium"
        return "large"

    def _compute_metrics(self, path: Path) -> ComplexityMetrics:
        """Compute all complexity metrics."""
        metrics = ComplexityMetrics()
        file_sizes: list[tuple[str, int]] = []
        total_size = 0

        try:
            for file_path in self._walk_files(path):
                metrics.total_files += 1

                if file_path.suffix in CODE_EXTENSIONS:
                    metrics.code_files += 1

                try:
                    size = file_path.stat().st_size
                    total_size += size
                    file_sizes.append((str(file_path.relative_to(path)), size))

                    if file_path.suffix in CODE_EXTENSIONS:
                        lines = self._count_lines(file_path)
                        metrics.total_lines += lines["total"]
                        metrics.code_lines += lines["code"]
                        metrics.comment_lines += lines["comment"]
                        metrics.blank_lines += lines["blank"]

                except OSError:
                    continue

            for dirpath in path.rglob("*"):
                if dirpath.is_dir() and not any(skip in str(dirpath) for skip in SKIP_DIRS):
                    metrics.directories += 1
                    depth = len(dirpath.relative_to(path).parts)
                    metrics.max_depth = max(metrics.max_depth, depth)

        except PermissionError:
            logger.warning("Permission denied during complexity estimation")

        if metrics.total_files > 0:
            metrics.avg_file_size = total_size / metrics.total_files

        file_sizes.sort(key=lambda x: x[1], reverse=True)
        metrics.largest_files = file_sizes[:10]

        metrics.complexity_score = self._calculate_score(metrics)
        metrics.size_category = self._categorize(metrics)

        return metrics

    def _count_lines(self, file_path: Path) -> dict[str, int]:
        """Count lines in a file."""
        result = {"total": 0, "code": 0, "comment": 0, "blank": 0}
        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            for line in content.splitlines():
                result["total"] += 1
                stripped = line.strip()
                if not stripped:
                    result["blank"] += 1
                elif stripped.startswith("#") or stripped.startswith("//") or stripped.startswith("/*"):
                    result["comment"] += 1
                else:
                    result["code"] += 1
        except OSError:
            pass
        return result

    def _calculate_score(self, metrics: ComplexityMetrics) -> float:
        """Calculate a complexity score (0-100)."""
        score = 0.0
        score += min(30, metrics.code_files / 10)
        score += min(30, metrics.code_lines / 1000)
        score += min(20, metrics.directories / 5)
        score += min(10, metrics.max_depth / 2)
        score += min(10, len(metrics.largest_files) / 2)
        return min(100.0, score)

    def _categorize(self, metrics: ComplexityMetrics) -> str:
        """Categorize project size."""
        if metrics.code_files < 5:
            return "tiny"
        if metrics.code_files < 30:
            return "small"
        if metrics.code_files < 150:
            return "medium"
        if metrics.code_files < 500:
            return "large"
        return "huge"

    def _walk_files(self, path: Path):
        """Walk project files."""
        try:
            for file_path in path.rglob("*"):
                if not file_path.is_file():
                    continue
                if any(skip in str(file_path) for skip in SKIP_DIRS):
                    continue
                if file_path.name.startswith("."):
                    continue
                yield file_path
        except PermissionError:
            pass
