"""Language detector — identify programming languages used in a project.

Analyzes file extensions, shebang lines, and content patterns
to determine which languages a project uses.
"""

from __future__ import annotations

import logging
from collections import Counter
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

EXTENSION_MAP: dict[str, str] = {
    ".py": "python",
    ".pyi": "python",
    ".pyw": "python",
    ".js": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".mts": "typescript",
    ".cts": "typescript",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".kt": "kotlin",
    ".kts": "kotlin",
    ".scala": "scala",
    ".sc": "scala",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".cxx": "cpp",
    ".cc": "cpp",
    ".hpp": "cpp",
    ".hxx": "cpp",
    ".cs": "csharp",
    ".rb": "ruby",
    ".php": "php",
    ".swift": "swift",
    ".dart": "dart",
    ".lua": "lua",
    ".r": "r",
    ".R": "r",
    ".hs": "haskell",
    ".ex": "elixir",
    ".exs": "elixir",
    ".erl": "erlang",
    ".zig": "zig",
    ".nim": "nim",
    ".jl": "julia",
    ".clj": "clojure",
    ".cljs": "clojure",
    ".ml": "ocaml",
    ".mli": "ocaml",
    ".vue": "vue",
    ".svelte": "svelte",
    ".astro": "astro",
    ".sh": "shell",
    ".bash": "shell",
    ".zsh": "shell",
    ".fish": "shell",
    ".ps1": "powershell",
    ".sql": "sql",
    ".html": "html",
    ".htm": "html",
    ".css": "css",
    ".scss": "scss",
    ".sass": "sass",
    ".less": "less",
    ".toml": "toml",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".json": "json",
    ".xml": "xml",
    ".md": "markdown",
    ".rst": "rst",
    ".tf": "terraform",
    ".hcl": "hcl",
    ".dockerfile": "dockerfile",
}

SHEBANG_MAP: dict[str, str] = {
    "python": "python",
    "python3": "python",
    "node": "javascript",
    "deno": "typescript",
    "bun": "javascript",
    "bash": "shell",
    "sh": "shell",
    "zsh": "shell",
    "fish": "shell",
    "ruby": "ruby",
    "php": "php",
    "perl": "perl",
    "lua": "lua",
    "Rscript": "r",
}

SKIP_DIRS = frozenset({
    "node_modules", ".git", "__pycache__", ".tox", ".venv", "venv",
    "env", ".env", ".mypy_cache", ".pytest_cache", "dist", "build",
    ".next", ".nuxt", "target", "vendor", ".gradle", ".idea", ".vscode",
    "coverage", ".coverage", "htmlcov", ".eggs", "*.egg-info",
})


class LanguageDetector:
    """Detects programming languages used in a project.

    Uses file extension analysis, shebang detection, and content
    pattern matching to identify languages with confidence scores.
    """

    def __init__(self, min_file_count: int = 1):
        self._min_file_count = min_file_count

    def detect(self, path: Path) -> list[str]:
        """Detect languages used in a project directory.

        Args:
            path: Project root directory.

        Returns:
            List of detected languages sorted by prevalence.
        """
        counts: Counter[str] = Counter()
        total_scanned = 0

        try:
            for file_path in self._walk_files(path):
                ext = file_path.suffix.lower()
                if ext in EXTENSION_MAP:
                    lang = EXTENSION_MAP[ext]
                    counts[lang] += 1
                    total_scanned += 1
                elif file_path.name in ("Dockerfile", "Containerfile", "Makefile", "CMakeLists.txt"):
                    lang = file_path.name.lower().replace("file", "").replace("lists.txt", "")
                    counts[lang] += 1
                    total_scanned += 1

                if total_scanned > 10000:
                    break
        except PermissionError:
            logger.warning("Permission denied scanning %s", path)

        if not counts:
            return []

        sorted_langs = [
            lang
            for lang, count in counts.most_common()
            if count >= self._min_file_count
        ]

        logger.debug("Detected languages: %s (%d files scanned)", sorted_langs, total_scanned)
        return sorted_langs

    def detect_file(self, file_path: Path) -> str | None:
        """Detect the language of a single file.

        Args:
            file_path: Path to the file.

        Returns:
            Detected language or None.
        """
        ext = file_path.suffix.lower()
        if ext in EXTENSION_MAP:
            return EXTENSION_MAP[ext]

        shebang = self._read_shebang(file_path)
        if shebang:
            return shebang

        return None

    def _walk_files(self, path: Path):
        """Walk directory tree yielding files, skipping ignored dirs."""
        try:
            for entry in sorted(path.iterdir()):
                if entry.name.startswith(".") and entry.name not in (".env",):
                    continue
                if entry.name in SKIP_DIRS:
                    continue
                if entry.is_file():
                    yield entry
                elif entry.is_dir():
                    yield from self._walk_files(entry)
        except PermissionError:
            pass

    def _read_shebang(self, file_path: Path) -> str | None:
        """Read shebang line and map to language."""
        try:
            with open(file_path, "rb") as f:
                first_line = f.readline(100)
            if first_line.startswith(b"#!"):
                shebang = first_line.decode("utf-8", errors="ignore").strip()
                for pattern, lang in SHEBANG_MAP.items():
                    if pattern in shebang:
                        return lang
        except (OSError, UnicodeDecodeError):
            pass
        return None
