"""Architecture detector — identify project architecture patterns.

Analyzes directory structure, module organization, and code patterns
to determine the architectural style of a project.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class ArchitectureDetector:
    """Detects project architecture patterns.

    Identifies patterns like MVC, microservices, monorepo,
    hexagonal, clean architecture, and more.
    """

    def detect(self, path: Path, frameworks: list[str] | None = None) -> str:
        """Detect the project architecture pattern.

        Args:
            path: Project root directory.
            frameworks: Detected frameworks for context.

        Returns:
            Detected architecture pattern name.
        """
        frameworks_set = set(frameworks or [])
        scores: dict[str, int] = {}

        # Check for monorepo
        if self._is_monorepo(path):
            scores["monorepo"] = 5

        # Check for MVC
        if self._has_mvc_structure(path):
            scores["mvc"] = 4

        # Check for microservices
        if self._is_microservices(path, frameworks_set):
            scores["microservices"] = 4

        # Check for hexagonal/clean architecture
        if self._is_hexagonal(path):
            scores["hexagonal"] = 4

        # Check for layered architecture
        if self._is_layered(path):
            scores["layered"] = 3

        # Check for flat/simple structure
        if self._is_flat(path):
            scores["flat"] = 2

        # Check for package-based
        if self._is_package_based(path):
            scores["package-based"] = 3

        if not scores:
            return "unknown"

        return max(scores, key=scores.get)  # type: ignore[arg-type]

    def _is_monorepo(self, path: Path) -> bool:
        """Check if this is a monorepo."""
        monorepo_indicators = [
            "packages", "apps", "libs", "modules",
            "pnpm-workspace.yaml", "lerna.json", "nx.json",
            "turbo.json", "rush.json",
        ]
        for indicator in monorepo_indicators:
            if (path / indicator).exists():
                return True

        # Check for multiple package.json files
        pkg_files = list(path.glob("*/package.json"))
        if len(pkg_files) >= 3:
            return True

        return False

    def _has_mvc_structure(self, path: Path) -> bool:
        """Check for MVC structure."""
        mvc_dirs = {"models", "views", "controllers"}
        existing = {d.name for d in path.iterdir() if d.is_dir()}
        return len(mvc_dirs & existing) >= 2

    def _is_microservices(self, path: Path, frameworks: set[str]) -> bool:
        """Check for microservices architecture."""
        if "docker-compose" in frameworks or "kubernetes" in frameworks:
            return True

        docker_files = list(path.glob("*/Dockerfile"))
        if len(docker_files) >= 2:
            return True

        svc_dirs = {"services", "microservices", "apps"}
        existing = {d.name for d in path.iterdir() if d.is_dir()}
        if svc_dirs & existing:
            return True

        return False

    def _is_hexagonal(self, path: Path) -> bool:
        """Check for hexagonal/clean architecture."""
        hex_dirs = {"ports", "adapters", "domain", "application", "infrastructure"}
        existing = set()
        for d in path.rglob("*"):
            if d.is_dir() and d.parent == path:
                existing.add(d.name.lower())
        return len(hex_dirs & existing) >= 3

    def _is_layered(self, path: Path) -> bool:
        """Check for layered architecture."""
        layer_dirs = {
            "presentation", "business", "data",
            "service", "repository", "controller",
            "dto", "entity", "model",
        }
        existing = set()
        for d in path.rglob("*"):
            if d.is_dir() and d.parent == path:
                existing.add(d.name.lower())
        return len(layer_dirs & existing) >= 3

    def _is_flat(self, path: Path) -> bool:
        """Check for flat/simple structure."""
        dirs = [d for d in path.iterdir() if d.is_dir() and not d.name.startswith(".")]
        files = [f for f in path.iterdir() if f.is_file()]
        return len(dirs) <= 2 and len(files) <= 10

    def _is_package_based(self, path: Path) -> bool:
        """Check for package-based structure."""
        src = path / "src"
        if src.is_dir():
            subdirs = [d for d in src.iterdir() if d.is_dir()]
            if len(subdirs) >= 3:
                init_files = list(src.glob("*/__init__.py"))
                go_files = list(src.glob("*/go.mod"))
                if len(init_files) >= 2 or len(go_files) >= 2:
                    return True
        return False
