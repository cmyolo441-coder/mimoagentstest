"""Framework detector — identify frameworks and libraries used in a project.

Analyzes configuration files, dependencies, and source patterns
to detect web frameworks, UI libraries, and other frameworks.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

FRAMEWORK_INDICATORS: dict[str, dict[str, Any]] = {
    # Python frameworks
    "django": {
        "files": ["manage.py", "wsgi.py", "asgi.py"],
        "dirs": ["django"],
        "package_indicators": {"requirements.txt": ["Django"], "pyproject.toml": ["django"]},
    },
    "flask": {
        "files": [],
        "package_indicators": {"requirements.txt": ["Flask"], "pyproject.toml": ["flask"]},
    },
    "fastapi": {
        "files": [],
        "package_indicators": {"requirements.txt": ["fastapi", "FastAPI"], "pyproject.toml": ["fastapi"]},
    },
    "tornado": {
        "package_indicators": {"requirements.txt": ["tornado"], "pyproject.toml": ["tornado"]},
    },
    # JavaScript/TypeScript frameworks
    "react": {
        "package_indicators": {"package.json": ["react"]},
    },
    "next": {
        "files": ["next.config.js", "next.config.mjs", "next.config.ts"],
        "package_indicators": {"package.json": ["next"]},
    },
    "vue": {
        "files": ["vue.config.js"],
        "package_indicators": {"package.json": ["vue"]},
    },
    "nuxt": {
        "files": ["nuxt.config.js", "nuxt.config.ts"],
        "package_indicators": {"package.json": ["nuxt"]},
    },
    "angular": {
        "files": ["angular.json", ".angular-cli.json"],
        "package_indicators": {"package.json": ["@angular/core"]},
    },
    "svelte": {
        "files": ["svelte.config.js"],
        "package_indicators": {"package.json": ["svelte"]},
    },
    "express": {
        "package_indicators": {"package.json": ["express"]},
    },
    "fastify": {
        "package_indicators": {"package.json": ["fastify"]},
    },
    "nest": {
        "files": ["nest-cli.json"],
        "package_indicators": {"package.json": ["@nestjs/core"]},
    },
    "remix": {
        "files": ["remix.config.js"],
        "package_indicators": {"package.json": ["@remix-run/react"]},
    },
    # Go frameworks
    "gin": {
        "go_import": "github.com/gin-gonic/gin",
    },
    "echo": {
        "go_import": "github.com/labstack/echo",
    },
    "fiber": {
        "go_import": "github.com/gofiber/fiber",
    },
    # Rust frameworks
    "actix-web": {
        "cargo_dep": "actix-web",
    },
    "axum": {
        "cargo_dep": "axum",
    },
    "rocket": {
        "cargo_dep": "rocket",
    },
    # Java frameworks
    "spring": {
        "files": ["pom.xml", "build.gradle", "build.gradle.kts"],
        "content_markers": ["@SpringBootApplication", "spring-boot"],
    },
    # Ruby frameworks
    "rails": {
        "files": ["Gemfile", "config.ru"],
        "dirs": ["app/controllers", "app/models"],
    },
    "sinatra": {
        "content_markers": ["require 'sinatra'", "require \"sinatra\""],
    },
    # PHP frameworks
    "laravel": {
        "files": ["artisan"],
        "dirs": ["app/Http"],
    },
    "symfony": {
        "files": ["symfony.lock"],
        "dirs": ["src/Controller"],
    },
}


class FrameworkDetector:
    """Detects frameworks used in a project.

    Uses multiple detection strategies: configuration files,
    dependency declarations, directory patterns, and source markers.
    """

    def detect(self, path: Path, languages: list[str] | None = None) -> list[str]:
        """Detect frameworks in a project.

        Args:
            path: Project root directory.
            languages: Previously detected languages (for context).

        Returns:
            List of detected framework names.
        """
        detected: list[str] = []
        lang_set = set(languages or [])

        for framework, indicators in FRAMEWORK_INDICATORS.items():
            score = 0

            for filename in indicators.get("files", []):
                if (path / filename).is_file():
                    score += 2

            for dirname in indicators.get("dirs", []):
                if (path / dirname).is_dir():
                    score += 1

            for pkg_file, packages in indicators.get("package_indicators", {}).items():
                if self._check_packages(path / pkg_file, packages):
                    score += 3

            if "go_import" in indicators:
                if self._check_go_import(path, indicators["go_import"]):
                    score += 3

            if "cargo_dep" in indicators:
                if self._check_cargo_dep(path, indicators["cargo_dep"]):
                    score += 3

            for marker in indicators.get("content_markers", []):
                if self._check_content_marker(path, marker):
                    score += 2

            if score >= 2:
                detected.append(framework)

        logger.debug("Detected frameworks: %s", detected)
        return detected

    def _check_packages(self, pkg_file: Path, packages: list[str]) -> bool:
        """Check if packages are declared in a dependency file."""
        if not pkg_file.is_file():
            return False

        try:
            content = pkg_file.read_text(encoding="utf-8")
            if pkg_file.name == "package.json":
                data = json.loads(content)
                all_deps: dict[str, str] = {}
                all_deps.update(data.get("dependencies", {}))
                all_deps.update(data.get("devDependencies", {}))
                return any(pkg in all_deps for pkg in packages)
            else:
                content_lower = content.lower()
                return any(pkg.lower() in content_lower for pkg in packages)
        except (OSError, json.JSONDecodeError):
            return False

    def _check_go_import(self, path: Path, import_path: str) -> bool:
        """Check for Go module dependency."""
        go_mod = path / "go.mod"
        if not go_mod.is_file():
            return False
        try:
            content = go_mod.read_text(encoding="utf-8")
            return import_path in content
        except OSError:
            return False

    def _check_cargo_dep(self, path: Path, dep_name: str) -> bool:
        """Check for Cargo dependency."""
        cargo_toml = path / "Cargo.toml"
        if not cargo_toml.is_file():
            return False
        try:
            content = cargo_toml.read_text(encoding="utf-8")
            return dep_name in content
        except OSError:
            return False

    def _check_content_marker(self, path: Path, marker: str) -> bool:
        """Check for content markers in source files."""
        for ext in (".py", ".rb", ".js", ".ts", ".go", ".java", ".php"):
            for file_path in path.rglob(f"*{ext}"):
                if any(skip in str(file_path) for skip in ("node_modules", ".git", "vendor", "__pycache__")):
                    continue
                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    if marker in content:
                        return True
                except OSError:
                    continue
                break
        return False
