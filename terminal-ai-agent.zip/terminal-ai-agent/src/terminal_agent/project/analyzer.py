"""Main project analyzer — orchestrates all project detection modules.

Combines results from all individual detectors to produce a
comprehensive project profile.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from terminal_agent.project.language_detector import LanguageDetector
from terminal_agent.project.framework_detector import FrameworkDetector
from terminal_agent.project.build_detector import BuildDetector
from terminal_agent.project.test_detector import TestDetector
from terminal_agent.project.package_detector import PackageDetector
from terminal_agent.project.cicd_detector import CICDDetector
from terminal_agent.project.entry_point_detector import EntryPointDetector
from terminal_agent.project.convention_detector import ConventionDetector
from terminal_agent.project.architecture_detector import ArchitectureDetector
from terminal_agent.project.dependency_analyzer import DependencyAnalyzer
from terminal_agent.project.complexity_estimator import ComplexityEstimator
from terminal_agent.types import ProjectInfo

logger = logging.getLogger(__name__)


@dataclass
class ProjectProfile:
    """Complete project analysis profile."""
    root_dir: str = ""
    languages: list[str] = field(default_factory=list)
    primary_language: str = ""
    frameworks: list[str] = field(default_factory=list)
    build_system: str | None = None
    test_framework: str | None = None
    package_manager: str | None = None
    cicd: str | None = None
    entry_points: list[str] = field(default_factory=list)
    conventions: dict[str, Any] = field(default_factory=dict)
    architecture: str = ""
    dependencies: dict[str, Any] = field(default_factory=dict)
    complexity: dict[str, Any] = field(default_factory=dict)
    structure: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_project_info(self) -> ProjectInfo:
        """Convert to the standard ProjectInfo type."""
        return ProjectInfo(
            languages=self.languages,
            frameworks=self.frameworks,
            build_system=self.build_system,
            test_framework=self.test_framework,
            package_manager=self.package_manager,
            cicd=self.cicd,
            entry_points=self.entry_points,
            root_dir=self.root_dir,
            structure=self.structure,
        )

    def summary(self) -> str:
        """Generate a human-readable summary."""
        parts = [f"Project: {Path(self.root_dir).name}"]
        if self.primary_language:
            parts.append(f"Language: {self.primary_language}")
        if self.frameworks:
            parts.append(f"Frameworks: {', '.join(self.frameworks)}")
        if self.build_system:
            parts.append(f"Build: {self.build_system}")
        if self.test_framework:
            parts.append(f"Tests: {self.test_framework}")
        if self.package_manager:
            parts.append(f"Packages: {self.package_manager}")
        if self.architecture:
            parts.append(f"Architecture: {self.architecture}")
        return " | ".join(parts)


class ProjectAnalyzer:
    """Main project analyzer that coordinates all detection modules.

    Scans a project directory and produces a comprehensive profile
    including languages, frameworks, build tools, and more.
    """

    def __init__(self, root_dir: str | Path | None = None):
        self._root_dir = Path(root_dir) if root_dir else Path.cwd()
        self._language_detector = LanguageDetector()
        self._framework_detector = FrameworkDetector()
        self._build_detector = BuildDetector()
        self._test_detector = TestDetector()
        self._package_detector = PackageDetector()
        self._cicd_detector = CICDDetector()
        self._entry_point_detector = EntryPointDetector()
        self._convention_detector = ConventionDetector()
        self._architecture_detector = ArchitectureDetector()
        self._dependency_analyzer = DependencyAnalyzer()
        self._complexity_estimator = ComplexityEstimator()

    @property
    def root_dir(self) -> Path:
        return self._root_dir

    def analyze(self, path: str | Path | None = None) -> ProjectProfile:
        """Run a full project analysis.

        Args:
            path: Project root path (uses default if None).

        Returns:
            Complete ProjectProfile.
        """
        root = Path(path) if path else self._root_dir
        if not root.is_dir():
            logger.error("Project path is not a directory: %s", root)
            return ProjectProfile(root_dir=str(root))

        logger.info("Analyzing project at %s", root)

        languages = self._language_detector.detect(root)
        primary = languages[0] if languages else ""

        frameworks = self._framework_detector.detect(root, languages)
        build_system = self._build_detector.detect(root)
        test_framework = self._test_detector.detect(root, languages)
        package_manager = self._package_detector.detect(root, languages)
        cicd = self._cicd_detector.detect(root)
        entry_points = self._entry_point_detector.detect(root, languages)
        conventions = self._convention_detector.detect(root, languages)
        architecture = self._architecture_detector.detect(root, frameworks)
        dependencies = self._dependency_analyzer.analyze(root, package_manager)
        complexity = self._complexity_estimator.estimate(root, languages)
        structure = self._analyze_structure(root)

        profile = ProjectProfile(
            root_dir=str(root),
            languages=languages,
            primary_language=primary,
            frameworks=frameworks,
            build_system=build_system,
            test_framework=test_framework,
            package_manager=package_manager,
            cicd=cicd,
            entry_points=entry_points,
            conventions=conventions,
            architecture=architecture,
            dependencies=dependencies,
            complexity=complexity,
            structure=structure,
        )

        logger.info("Analysis complete: %s", profile.summary())
        return profile

    def quick_detect(self, path: str | Path | None = None) -> dict[str, Any]:
        """Run a quick detection (languages and package manager only).

        Args:
            path: Project root path.

        Returns:
            Quick detection results.
        """
        root = Path(path) if path else self._root_dir
        languages = self._language_detector.detect(root)
        package_manager = self._package_detector.detect(root, languages)
        return {
            "languages": languages,
            "package_manager": package_manager,
        }

    def _analyze_structure(self, root: Path) -> dict[str, Any]:
        """Analyze project directory structure."""
        structure: dict[str, Any] = {
            "directories": [],
            "total_files": 0,
            "total_dirs": 0,
            "file_types": {},
        }

        try:
            for entry in root.rglob("*"):
                if entry.name.startswith(".") or "node_modules" in str(entry):
                    continue
                if entry.is_file():
                    structure["total_files"] += 1
                    ext = entry.suffix.lower()
                    structure["file_types"][ext] = structure["file_types"].get(ext, 0) + 1
                elif entry.is_dir():
                    structure["total_dirs"] += 1
                    depth = len(entry.relative_to(root).parts)
                    if depth <= 2:
                        structure["directories"].append(str(entry.relative_to(root)))
        except PermissionError:
            logger.warning("Permission denied analyzing structure")

        return structure
