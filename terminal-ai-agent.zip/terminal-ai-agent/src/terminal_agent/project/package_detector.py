"""Package detector — identify package managers used in a project.

Detects package managers by checking for lock files, configuration
files, and dependency declaration files.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

PACKAGE_MANAGERS: dict[str, dict[str, Any]] = {
    # JavaScript/TypeScript
    "npm": {"lock": ["package-lock.json"], "config": ["package.json"]},
    "yarn": {"lock": ["yarn.lock"], "config": ["package.json", ".yarnrc.yml"]},
    "pnpm": {"lock": ["pnpm-lock.yaml"], "config": ["package.json", "pnpm-workspace.yaml"]},
    "bun": {"lock": ["bun.lockb", "bun.lock"], "config": ["package.json"]},
    # Python
    "pip": {"lock": [], "config": ["requirements.txt", "requirements.in"]},
    "pipenv": {"lock": ["Pipfile.lock"], "config": ["Pipfile"]},
    "poetry": {"lock": ["poetry.lock"], "config": ["pyproject.toml"], "content": "poetry-core"},
    "conda": {"lock": ["conda-lock.yml"], "config": ["environment.yml", "environment.yaml"]},
    "uv": {"lock": ["uv.lock"], "config": ["pyproject.toml"], "content": "uv"},
    "pdm": {"lock": ["pdm.lock"], "config": ["pyproject.toml"], "content": "pdm-backend"},
    # Go
    "go-mod": {"lock": ["go.sum"], "config": ["go.mod"]},
    # Rust
    "cargo": {"lock": ["Cargo.lock"], "config": ["Cargo.toml"]},
    # Java/Kotlin
    "maven": {"lock": [], "config": ["pom.xml"]},
    "gradle": {"lock": ["gradle.lockfile"], "config": ["build.gradle", "build.gradle.kts"]},
    # Ruby
    "bundler": {"lock": ["Gemfile.lock"], "config": ["Gemfile"]},
    "gem": {"lock": [], "config": ["*.gemspec"]},
    # PHP
    "composer": {"lock": ["composer.lock"], "config": ["composer.json"]},
    # Dart
    "pub": {"lock": ["pubspec.lock"], "config": ["pubspec.yaml"]},
    # Elixir
    "mix": {"lock": ["mix.lock"], "config": ["mix.exs"]},
    # C/C++
    "conan": {"lock": [], "config": ["conanfile.txt", "conanfile.py"]},
    "vcpkg": {"lock": [], "config": ["vcpkg.json"]},
    # Swift
    "spm": {"lock": ["Package.resolved"], "config": ["Package.swift"]},
    # Haskell
    "cabal": {"lock": ["cabal.project.freeze"], "config": ["*.cabal", "cabal.project"]},
    "stack": {"lock": ["stack.yaml.lock"], "config": ["stack.yaml"]},
}


class PackageDetector:
    """Detects package managers used in a project.

    Identifies package managers by checking for lock files,
    configuration files, and content markers.
    """

    def detect(self, path: Path, languages: list[str] | None = None) -> str | None:
        """Detect the primary package manager.

        Args:
            path: Project root directory.
            languages: Detected languages for context.

        Returns:
            Name of the primary package manager, or None.
        """
        all_detected = self.detect_all(path, languages)
        return all_detected[0] if all_detected else None

    def detect_all(self, path: Path, languages: list[str] | None = None) -> list[str]:
        """Detect all package managers in use.

        Args:
            path: Project root directory.
            languages: Detected languages.

        Returns:
            List of detected package managers.
        """
        results: list[str] = []

        for pm_name, indicators in PACKAGE_MANAGERS.items():
            score = 0

            for lockfile in indicators.get("lock", []):
                if (path / lockfile).is_file():
                    score += 3

            for configfile in indicators.get("config", []):
                if "*" in configfile:
                    if list(path.glob(configfile)):
                        score += 2
                elif (path / configfile).is_file():
                    score += 2

            content = indicators.get("content")
            if content:
                pyproject = path / "pyproject.toml"
                if pyproject.is_file():
                    try:
                        text = pyproject.read_text(encoding="utf-8")
                        if content in text:
                            score += 2
                    except OSError:
                        pass

            if score >= 2:
                results.append(pm_name)

        logger.debug("Detected package managers: %s", results)
        return results

    def get_lockfile(self, path: Path, pm_name: str) -> Path | None:
        """Get the lock file path for a package manager.

        Args:
            path: Project root directory.
            pm_name: Package manager name.

        Returns:
            Path to lock file, or None.
        """
        indicators = PACKAGE_MANAGERS.get(pm_name, {})
        for lockfile in indicators.get("lock", []):
            lockpath = path / lockfile
            if lockpath.is_file():
                return lockpath
        return None

    def get_config_file(self, path: Path, pm_name: str) -> Path | None:
        """Get the config file path for a package manager.

        Args:
            path: Project root directory.
            pm_name: Package manager name.

        Returns:
            Path to config file, or None.
        """
        indicators = PACKAGE_MANAGERS.get(pm_name, {})
        for configfile in indicators.get("config", []):
            if "*" in configfile:
                matches = list(path.glob(configfile))
                if matches:
                    return matches[0]
            else:
                configpath = path / configfile
                if configpath.is_file():
                    return configpath
        return None
