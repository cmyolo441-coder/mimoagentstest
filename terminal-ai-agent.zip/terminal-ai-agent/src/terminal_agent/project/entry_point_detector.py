"""Entry point detector — find main files and entry points.

Identifies application entry points, main files, and script
starting points in a project.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

ENTRY_POINT_PATTERNS: dict[str, dict[str, Any]] = {
    "python": {
        "files": ["main.py", "app.py", "manage.py", "wsgi.py", "asgi.py", "run.py", "cli.py", "__main__.py"],
        "content": ['if __name__ == "__main__"', "def main()", "def cli("],
    },
    "javascript": {
        "files": ["index.js", "main.js", "app.js", "server.js", "cli.js"],
        "package_field": "main",
    },
    "typescript": {
        "files": ["index.ts", "main.ts", "app.ts", "server.ts", "cli.ts"],
        "package_field": "main",
    },
    "go": {
        "files": ["main.go", "cmd/main.go", "cmd/server/main.go", "cmd/cli/main.go"],
        "content": ["func main()"],
    },
    "rust": {
        "files": ["src/main.rs", "src/bin/main.rs"],
    },
    "java": {
        "files": ["src/main/java/**/Main.java", "src/main/java/**/Application.java"],
        "content": ["public static void main("],
    },
    "ruby": {
        "files": ["app.rb", "main.rb", "config.ru"],
    },
    "php": {
        "files": ["index.php", "artisan", "public/index.php"],
    },
    "shell": {
        "files": ["main.sh", "run.sh", "start.sh", "entrypoint.sh"],
    },
}


class EntryPointDetector:
    """Detects application entry points in a project.

    Identifies main files, script entry points, and application
    starting points across multiple languages.
    """

    def detect(self, path: Path, languages: list[str] | None = None) -> list[str]:
        """Detect entry points in a project.

        Args:
            path: Project root directory.
            languages: Detected languages for context.

        Returns:
            List of entry point file paths (relative to project root).
        """
        entry_points: list[str] = []
        lang_set = set(languages or [])

        for lang, patterns in ENTRY_POINT_PATTERNS.items():
            if lang_set and lang not in lang_set:
                continue

            for filename in patterns.get("files", []):
                if "**" in filename:
                    matches = list(path.glob(filename))
                    for match in matches:
                        rel = str(match.relative_to(path))
                        if rel not in entry_points:
                            entry_points.append(rel)
                else:
                    filepath = path / filename
                    if filepath.is_file():
                        rel = str(filepath.relative_to(path))
                        if rel not in entry_points:
                            entry_points.append(rel)

            content_markers = patterns.get("content", [])
            if content_markers and not entry_points:
                found = self._search_content(path, content_markers)
                if found and found not in entry_points:
                    entry_points.append(found)

        pkg_field = None
        for patterns in ENTRY_POINT_PATTERNS.values():
            pf = patterns.get("package_field")
            if pf:
                pkg_field = pf
                break

        if pkg_field:
            pkg_entry = self._check_package_json(path, pkg_field)
            if pkg_entry and pkg_entry not in entry_points:
                entry_points.append(pkg_entry)

        logger.debug("Detected entry points: %s", entry_points)
        return entry_points

    def _search_content(self, path: Path, markers: list[str]) -> str | None:
        """Search for content markers in source files."""
        skip_dirs = {"node_modules", ".git", "__pycache__", "vendor", "dist", "build", ".tox"}
        for marker in markers:
            for ext in (".py", ".go", ".java", ".js", ".ts"):
                for file_path in path.rglob(f"*{ext}"):
                    if any(skip in str(file_path) for skip in skip_dirs):
                        continue
                    try:
                        content = file_path.read_text(encoding="utf-8", errors="ignore")
                        if marker in content:
                            return str(file_path.relative_to(path))
                    except OSError:
                        continue
        return None

    def _check_package_json(self, path: Path, field_name: str) -> str | None:
        """Check package.json for entry point."""
        pkg = path / "package.json"
        if not pkg.is_file():
            return None
        try:
            import json
            data = json.loads(pkg.read_text(encoding="utf-8"))
            main = data.get(field_name)
            if main and isinstance(main, str):
                return main
        except (OSError, json.JSONDecodeError):
            pass
        return None
