"""CI/CD detector — identify CI/CD configurations in a project.

Detects continuous integration and deployment pipelines by
checking for platform-specific configuration files.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

CICD_SYSTEMS: dict[str, dict[str, Any]] = {
    "github-actions": {
        "files": [".github/workflows"],
        "is_dir": True,
    },
    "gitlab-ci": {
        "files": [".gitlab-ci.yml"],
    },
    "jenkins": {
        "files": ["Jenkinsfile", "jenkins.yml"],
    },
    "circleci": {
        "files": [".circleci/config.yml"],
    },
    "travis-ci": {
        "files": [".travis.yml"],
    },
    "azure-pipelines": {
        "files": ["azure-pipelines.yml"],
    },
    "bitbucket-pipelines": {
        "files": ["bitbucket-pipelines.yml"],
    },
    "drone": {
        "files": [".drone.yml"],
    },
    "buildkite": {
        "files": [".buildkite/pipeline.yml"],
    },
    "argo-cd": {
        "files": ["argocd.yaml", "argocd.yml"],
    },
    "tekton": {
        "files": [".tekton"],
        "is_dir": True,
    },
    "woodpecker": {
        "files": [".woodpecker.yml"],
    },
}


class CICDDetector:
    """Detects CI/CD systems configured in a project.

    Checks for configuration files of popular CI/CD platforms
    and returns the detected systems.
    """

    def detect(self, path: Path) -> str | None:
        """Detect the primary CI/CD system.

        Args:
            path: Project root directory.

        Returns:
            Name of the primary CI/CD system, or None.
        """
        all_detected = self.detect_all(path)
        return all_detected[0] if all_detected else None

    def detect_all(self, path: Path) -> list[str]:
        """Detect all CI/CD systems in use.

        Args:
            path: Project root directory.

        Returns:
            List of detected CI/CD systems.
        """
        results: list[str] = []

        for system_name, indicators in CICD_SYSTEMS.items():
            is_dir = indicators.get("is_dir", False)

            for filepath in indicators.get("files", []):
                full_path = path / filepath
                if is_dir and full_path.is_dir():
                    results.append(system_name)
                    break
                elif not is_dir and full_path.is_file():
                    results.append(system_name)
                    break

        logger.debug("Detected CI/CD systems: %s", results)
        return results

    def get_config_path(self, path: Path, system_name: str) -> Path | None:
        """Get the config path for a CI/CD system.

        Args:
            path: Project root directory.
            system_name: CI/CD system name.

        Returns:
            Path to config file/directory, or None.
        """
        indicators = CICD_SYSTEMS.get(system_name, {})
        for filepath in indicators.get("files", []):
            full_path = path / filepath
            if full_path.exists():
                return full_path
        return None
