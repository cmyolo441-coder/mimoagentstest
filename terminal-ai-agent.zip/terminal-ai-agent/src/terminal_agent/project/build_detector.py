"""Build detector — identify build systems and tools used in a project.

Detects build tools, task runners, and compilation systems
based on configuration files and project structure.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

BUILD_INDICATORS: dict[str, dict[str, Any]] = {
    # JavaScript/TypeScript
    "webpack": {"files": ["webpack.config.js", "webpack.config.ts", "webpack.config.mjs"]},
    "vite": {"files": ["vite.config.js", "vite.config.ts", "vite.config.mjs"]},
    "rollup": {"files": ["rollup.config.js", "rollup.config.mjs"]},
    "esbuild": {"files": ["esbuild.config.js"]},
    "parcel": {"files": [".parcelrc"]},
    "turbopack": {"files": ["turbo.json"]},
    "nx": {"files": ["nx.json", "workspace.json"]},
    "babel": {"files": ["babel.config.js", "babel.config.json", ".babelrc", ".babelrc.json"]},
    "swc": {"files": [".swcrc"]},
    "grunt": {"files": ["Gruntfile.js"]},
    "gulp": {"files": ["gulpfile.js"]},
    # Python
    "setuptools": {"files": ["setup.py", "setup.cfg"]},
    "hatchling": {"files": ["pyproject.toml"], "content": ["hatchling"]},
    "poetry": {"files": ["pyproject.toml"], "content": ["poetry-core"]},
    "flit": {"files": ["pyproject.toml"], "content": ["flit_core"]},
    "pdm": {"files": ["pyproject.toml"], "content": ["pdm-backend"]},
    "maturin": {"files": ["pyproject.toml"], "content": ["maturin"]},
    "scikit-build": {"files": ["CMakeLists.txt"], "content": ["scikit-build"]},
    # Go
    "go-build": {"files": ["go.mod"]},
    # Rust
    "cargo": {"files": ["Cargo.toml"]},
    # Java/Kotlin
    "maven": {"files": ["pom.xml"]},
    "gradle": {"files": ["build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts"]},
    # C/C++
    "cmake": {"files": ["CMakeLists.txt"]},
    "make": {"files": ["Makefile", "makefile", "GNUmakefile"]},
    "bazel": {"files": ["BUILD", "BUILD.bazel", "WORKSPACE"]},
    "meson": {"files": ["meson.build"]},
    "ninja": {"files": ["build.ninja"]},
    # Ruby
    "rake": {"files": ["Rakefile"]},
    # PHP
    "composer": {"files": ["composer.json"]},
    # Dart/Flutter
    "pub": {"files": ["pubspec.yaml"]},
    # Elixir
    "mix": {"files": ["mix.exs"]},
    # Haskell
    "cabal": {"files": ["*.cabal"]},
    "stack": {"files": ["stack.yaml"]},
    # Task runners
    "just": {"files": ["justfile", "Justfile"]},
    "task": {"files": ["Taskfile.yml"]},
}


class BuildDetector:
    """Detects build systems used in a project.

    Identifies build tools, task runners, and compilation systems
    by checking for their configuration files and content markers.
    """

    def detect(self, path: Path) -> str | None:
        """Detect the primary build system.

        Args:
            path: Project root directory.

        Returns:
            Name of the primary build system, or None.
        """
        detected = self.detect_all(path)
        return detected[0] if detected else None

    def detect_all(self, path: Path) -> list[str]:
        """Detect all build systems in use.

        Args:
            path: Project root directory.

        Returns:
            List of detected build systems.
        """
        results: list[str] = []

        for build_name, indicators in BUILD_INDICATORS.items():
            found = False

            for filename in indicators.get("files", []):
                if "*" in filename:
                    matches = list(path.glob(filename))
                    if matches:
                        found = True
                        break
                elif (path / filename).is_file():
                    found = True
                    break

            if not found:
                continue

            content_markers = indicators.get("content", [])
            if content_markers:
                matched = False
                for filename in indicators.get("files", []):
                    filepath = path / filename
                    if filepath.is_file():
                        try:
                            content = filepath.read_text(encoding="utf-8")
                            if any(marker in content for marker in content_markers):
                                matched = True
                                break
                        except OSError:
                            continue
                if content_markers and not matched:
                    continue

            results.append(build_name)

        logger.debug("Detected build systems: %s", results)
        return results
