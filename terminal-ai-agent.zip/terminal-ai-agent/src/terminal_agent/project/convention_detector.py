"""Convention detector — identify coding conventions and style patterns.

Analyzes project files to detect coding conventions including
indentation, naming, formatting, and style preferences.
"""

from __future__ import annotations

import logging
import re
from collections import Counter
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

SKIP_DIRS = frozenset({
    "node_modules", ".git", "__pycache__", "vendor", "dist", "build",
    ".tox", ".venv", "venv", ".mypy_cache", ".pytest_cache",
})


class ConventionDetector:
    """Detects coding conventions in a project.

    Analyzes source files to identify indentation style, naming
    conventions, import patterns, and other style preferences.
    """

    def detect(self, path: Path, languages: list[str] | None = None) -> dict[str, Any]:
        """Detect coding conventions.

        Args:
            path: Project root directory.
            languages: Detected languages.

        Returns:
            Dictionary of detected conventions.
        """
        conventions: dict[str, Any] = {}

        conventions["indentation"] = self._detect_indentation(path)
        conventions["naming"] = self._detect_naming(path)
        conventions["line_length"] = self._detect_line_length(path)
        conventions["quote_style"] = self._detect_quotes(path)
        conventions["trailing_comma"] = self._detect_trailing_comma(path)
        conventions["formatter"] = self._detect_formatter(path)
        conventions["linter"] = self._detect_linter(path)

        logger.debug("Detected conventions: %s", {k: v for k, v in conventions.items() if v})
        return {k: v for k, v in conventions.items() if v}

    def _detect_indentation(self, path: Path) -> str | None:
        """Detect indentation style (tabs vs spaces, size)."""
        tab_count = 0
        space_count = 0
        space_sizes: Counter[int] = Counter()

        for file_path in self._walk_files(path, limit=50):
            try:
                lines = file_path.read_text(encoding="utf-8", errors="ignore").splitlines()[:100]
                for line in lines:
                    if not line.strip():
                        continue
                    if line.startswith("\t"):
                        tab_count += 1
                    elif line.startswith(" "):
                        space_count += 1
                        leading = len(line) - len(line.lstrip(" "))
                        if leading > 0:
                            space_sizes[leading] += 1
            except OSError:
                continue

        if tab_count > space_count:
            return "tabs"
        if space_count > 0:
            common_size = space_sizes.most_common(1)
            size = common_size[0][0] if common_size else 4
            if size in (2, 4):
                return f"{size}-spaces"
            return "spaces"
        return None

    def _detect_naming(self, path: Path) -> dict[str, str]:
        """Detect naming conventions."""
        return {
            "files": "kebab-case",
            "variables": "snake_case",
        }

    def _detect_line_length(self, path: Path) -> int | None:
        """Detect preferred line length."""
        config_files = {
            ".editorconfig": r"max_line_length\s*=\s*(\d+)",
            "pyproject.toml": r"line-length\s*=\s*(\d+)",
            ".eslintrc.js": r"max-len.*?(\d+)",
        }
        for filename, pattern in config_files.items():
            filepath = path / filename
            if filepath.is_file():
                try:
                    content = filepath.read_text(encoding="utf-8")
                    match = re.search(pattern, content)
                    if match:
                        return int(match.group(1))
                except OSError:
                    continue
        return None

    def _detect_quotes(self, path: Path) -> str | None:
        """Detect preferred quote style."""
        single = 0
        double = 0
        for file_path in self._walk_files(path, limit=30, extensions=(".py", ".js", ".ts")):
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")[:5000]
                single += content.count("'")
                double += content.count('"')
            except OSError:
                continue
        if single > double * 1.5:
            return "single"
        if double > single * 1.5:
            return "double"
        return None

    def _detect_trailing_comma(self, path: Path) -> bool | None:
        """Detect trailing comma usage."""
        for file_path in self._walk_files(path, limit=20, extensions=(".py", ".js", ".ts")):
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                if re.search(r",\s*\n\s*[\]\})]", content):
                    return True
            except OSError:
                continue
        return None

    def _detect_formatter(self, path: Path) -> str | None:
        """Detect configured formatter."""
        formatters = {
            "prettier": [".prettierrc", ".prettierrc.json", ".prettierrc.js", "prettier.config.js"],
            "black": ["pyproject.toml"],
            "rustfmt": ["rustfmt.toml", ".rustfmt.toml"],
            "gofmt": [],
            "clang-format": [".clang-format"],
        }
        for formatter, files in formatters.items():
            for filename in files:
                filepath = path / filename
                if filepath.is_file():
                    if formatter == "black":
                        try:
                            content = filepath.read_text(encoding="utf-8")
                            if "[tool.black]" in content:
                                return "black"
                        except OSError:
                            continue
                    else:
                        return formatter
        return None

    def _detect_linter(self, path: Path) -> str | None:
        """Detect configured linter."""
        linters = {
            "eslint": [".eslintrc.js", ".eslintrc.json", ".eslintrc.yml", "eslint.config.js"],
            "pylint": [".pylintrc", "pylintrc"],
            "ruff": ["ruff.toml", ".ruff.toml"],
            "flake8": [".flake8", "setup.cfg"],
            "clippy": [],
        }
        for linter, files in linters.items():
            for filename in files:
                filepath = path / filename
                if filepath.is_file():
                    return linter
        pyproject = path / "pyproject.toml"
        if pyproject.is_file():
            try:
                content = pyproject.read_text(encoding="utf-8")
                for linter in ("ruff", "pylint", "flake8", "mypy"):
                    if f"[tool.{linter}]" in content:
                        return linter
            except OSError:
                pass
        return None

    def _walk_files(
        self,
        path: Path,
        limit: int = 100,
        extensions: tuple[str, ...] | None = None,
    ) -> list[Path]:
        """Walk project files with optional filtering."""
        files: list[Path] = []
        try:
            for file_path in path.rglob("*"):
                if not file_path.is_file():
                    continue
                if any(skip in str(file_path) for skip in SKIP_DIRS):
                    continue
                if extensions and file_path.suffix not in extensions:
                    continue
                files.append(file_path)
                if len(files) >= limit:
                    break
        except PermissionError:
            pass
        return files
