"""Dependency analyzer — analyze project dependencies and their tree.

Parses dependency files, resolves dependency trees, and identifies
direct vs transitive dependencies.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class Dependency:
    """A single dependency."""
    name: str
    version: str = ""
    is_dev: bool = False
    is_direct: bool = True
    source: str = ""


class DependencyAnalyzer:
    """Analyzes project dependencies from various package managers.

    Parses dependency files (package.json, requirements.txt, Cargo.toml,
    etc.) and extracts dependency information.
    """

    def analyze(self, path: Path, package_manager: str | None = None) -> dict[str, Any]:
        """Analyze project dependencies.

        Args:
            path: Project root directory.
            package_manager: Detected package manager (for targeted parsing).

        Returns:
            Dictionary with dependency analysis results.
        """
        result: dict[str, Any] = {
            "direct": [],
            "dev": [],
            "total": 0,
            "package_manager": package_manager,
        }

        deps = self._parse_all_dependencies(path, package_manager)
        result["direct"] = [d.name for d in deps if d.is_direct and not d.is_dev]
        result["dev"] = [d.name for d in deps if d.is_dev]
        result["total"] = len(deps)
        result["dependencies"] = [
            {"name": d.name, "version": d.version, "dev": d.is_dev}
            for d in deps
        ]

        return result

    def get_direct_dependencies(self, path: Path) -> list[str]:
        """Get just the direct dependency names."""
        deps = self._parse_all_dependencies(path)
        return [d.name for d in deps if d.is_direct and not d.is_dev]

    def _parse_all_dependencies(
        self, path: Path, package_manager: str | None = None
    ) -> list[Dependency]:
        """Parse dependencies from all available dependency files."""
        deps: list[Dependency] = []
        seen: set[str] = set()

        # package.json
        pkg_deps = self._parse_package_json(path)
        for d in pkg_deps:
            if d.name not in seen:
                deps.append(d)
                seen.add(d.name)

        # Python
        for filename in ("requirements.txt", "requirements-dev.txt"):
            req_deps = self._parse_requirements_txt(path / filename)
            for d in req_deps:
                if d.name not in seen:
                    deps.append(d)
                    seen.add(d.name)

        pyproject_deps = self._parse_pyproject_toml(path / "pyproject.toml")
        for d in pyproject_deps:
            if d.name not in seen:
                deps.append(d)
                seen.add(d.name)

        # Go
        go_deps = self._parse_go_mod(path / "go.mod")
        for d in go_deps:
            if d.name not in seen:
                deps.append(d)
                seen.add(d.name)

        # Rust
        cargo_deps = self._parse_cargo_toml(path / "Cargo.toml")
        for d in cargo_deps:
            if d.name not in seen:
                deps.append(d)
                seen.add(d.name)

        # Ruby
        gem_deps = self._parse_gemfile(path / "Gemfile")
        for d in gem_deps:
            if d.name not in seen:
                deps.append(d)
                seen.add(d.name)

        # PHP
        composer_deps = self._parse_composer_json(path / "composer.json")
        for d in composer_deps:
            if d.name not in seen:
                deps.append(d)
                seen.add(d.name)

        return deps

    def _parse_package_json(self, path: Path) -> list[Dependency]:
        """Parse package.json dependencies."""
        filepath = path / "package.json"
        if not filepath.is_file():
            return []
        try:
            data = json.loads(filepath.read_text(encoding="utf-8"))
            deps: list[Dependency] = []
            for name, version in data.get("dependencies", {}).items():
                deps.append(Dependency(name=name, version=version, is_direct=True))
            for name, version in data.get("devDependencies", {}).items():
                deps.append(Dependency(name=name, version=version, is_dev=True))
            return deps
        except (OSError, json.JSONDecodeError):
            return []

    def _parse_requirements_txt(self, filepath: Path) -> list[Dependency]:
        """Parse requirements.txt."""
        if not filepath.is_file():
            return []
        try:
            content = filepath.read_text(encoding="utf-8")
            deps: list[Dependency] = []
            for line in content.splitlines():
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("-"):
                    continue
                match = re.match(r"^([a-zA-Z0-9_.-]+)\s*([>=<~!].*)?$", line)
                if match:
                    deps.append(Dependency(
                        name=match.group(1),
                        version=match.group(2) or "",
                        is_dev="dev" in filepath.name,
                    ))
            return deps
        except OSError:
            return []

    def _parse_pyproject_toml(self, filepath: Path) -> list[Dependency]:
        """Parse pyproject.toml dependencies."""
        if not filepath.is_file():
            return []
        try:
            content = filepath.read_text(encoding="utf-8")
            deps: list[Dependency] = []

            in_deps = False
            in_dev_deps = False
            for line in content.splitlines():
                stripped = line.strip()
                if stripped == "dependencies = [":
                    in_deps = True
                    continue
                if "optional-dependencies" in stripped or "dev-dependencies" in stripped:
                    in_dev_deps = True
                    in_deps = False
                    continue
                if stripped == "]":
                    in_deps = False
                    in_dev_deps = False
                    continue
                if in_deps or in_dev_deps:
                    match = re.match(r'["\']([a-zA-Z0-9_.-]+)', stripped)
                    if match:
                        deps.append(Dependency(
                            name=match.group(1),
                            is_dev=in_dev_deps,
                        ))
            return deps
        except OSError:
            return []

    def _parse_go_mod(self, filepath: Path) -> list[Dependency]:
        """Parse go.mod dependencies."""
        if not filepath.is_file():
            return []
        try:
            content = filepath.read_text(encoding="utf-8")
            deps: list[Dependency] = []
            in_require = False
            for line in content.splitlines():
                stripped = line.strip()
                if stripped.startswith("require ("):
                    in_require = True
                    continue
                if stripped == ")":
                    in_require = False
                    continue
                if in_require or stripped.startswith("require "):
                    parts = stripped.replace("require ", "").split()
                    if len(parts) >= 2:
                        deps.append(Dependency(
                            name=parts[0],
                            version=parts[1],
                        ))
            return deps
        except OSError:
            return []

    def _parse_cargo_toml(self, filepath: Path) -> list[Dependency]:
        """Parse Cargo.toml dependencies."""
        if not filepath.is_file():
            return []
        try:
            content = filepath.read_text(encoding="utf-8")
            deps: list[Dependency] = []
            in_deps = False
            in_dev_deps = False
            for line in content.splitlines():
                stripped = line.strip()
                if stripped == "[dependencies]":
                    in_deps = True
                    in_dev_deps = False
                    continue
                if stripped == "[dev-dependencies]":
                    in_dev_deps = True
                    in_deps = False
                    continue
                if stripped.startswith("["):
                    in_deps = False
                    in_dev_deps = False
                    continue
                if in_deps or in_dev_deps:
                    match = re.match(r'^(\S+)\s*=', stripped)
                    if match:
                        deps.append(Dependency(
                            name=match.group(1),
                            is_dev=in_dev_deps,
                        ))
            return deps
        except OSError:
            return []

    def _parse_gemfile(self, filepath: Path) -> list[Dependency]:
        """Parse Gemfile dependencies."""
        if not filepath.is_file():
            return []
        try:
            content = filepath.read_text(encoding="utf-8")
            deps: list[Dependency] = []
            for match in re.finditer(r"gem\s+['\"]([^'\"]+)['\"](?:\s*,\s*['\"]([^'\"]+)['\"])?", content):
                deps.append(Dependency(
                    name=match.group(1),
                    version=match.group(2) or "",
                ))
            return deps
        except OSError:
            return []

    def _parse_composer_json(self, filepath: Path) -> list[Dependency]:
        """Parse composer.json dependencies."""
        if not filepath.is_file():
            return []
        try:
            data = json.loads(filepath.read_text(encoding="utf-8"))
            deps: list[Dependency] = []
            for name, version in data.get("require", {}).items():
                deps.append(Dependency(name=name, version=version))
            for name, version in data.get("require-dev", {}).items():
                deps.append(Dependency(name=name, version=version, is_dev=True))
            return deps
        except (OSError, json.JSONDecodeError):
            return []
