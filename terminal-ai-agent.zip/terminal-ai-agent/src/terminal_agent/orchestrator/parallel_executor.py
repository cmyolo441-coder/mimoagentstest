"""Parallel executor — runs independent plan steps concurrently.

Uses asyncio task groups to execute steps in the same dependency
layer simultaneously, respecting concurrency limits.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.exceptions import ExecutionError
from terminal_agent.orchestrator.dependency_resolver import DependencyResolver
from terminal_agent.orchestrator.executor import StepExecutor
from terminal_agent.orchestrator.monitor import ProgressMonitor
from terminal_agent.types import PlanStep, SessionStatus, ToolResult, ToolResultStatus

logger = logging.getLogger(__name__)


@dataclass
class ParallelResult:
    """Result of executing a set of parallel steps."""
    completed: list[str] = field(default_factory=list)
    failed: list[str] = field(default_factory=list)
    results: dict[str, ToolResult] = field(default_factory=dict)
    errors: dict[str, str] = field(default_factory=dict)
    elapsed_ms: float = 0.0


class ParallelExecutor:
    """Executes independent plan steps concurrently.

    Given a list of steps with dependencies, uses the DependencyResolver
    to identify parallelisable groups, then executes each group
    concurrently (respecting a configurable concurrency limit).
    """

    def __init__(
        self,
        step_executor: StepExecutor,
        monitor: ProgressMonitor | None = None,
        max_concurrency: int = 5,
    ) -> None:
        """
        Args:
            step_executor: The single-step executor.
            monitor: Optional progress monitor.
            max_concurrency: Maximum concurrent step executions.
        """
        self._executor = step_executor
        self._monitor = monitor
        self._max_concurrency = max_concurrency
        self._resolver = DependencyResolver()
        self._semaphore = asyncio.Semaphore(max_concurrency)

    async def execute_plan(
        self,
        steps: list[PlanStep],
        context: str = "",
    ) -> ParallelResult:
        """Execute all steps respecting dependency order and parallelism.

        Args:
            steps: Plan steps with dependencies populated.
            context: Shared context for all steps.

        Returns:
            A ParallelResult with outcomes for all steps.
        """
        start = time.monotonic()
        result = ParallelResult()

        # Resolve execution layers
        try:
            batches = self._resolver.get_execution_order(steps)
        except Exception as exc:
            logger.error("Dependency resolution failed: %s", exc)
            # Fallback: sequential execution
            batches = [[s.id] for s in steps]

        step_map = {s.id: s for s in steps}
        completed: set[str] = set()

        for batch_idx, batch_ids in enumerate(batches):
            logger.info(
                "Executing batch %d/%d: %s",
                batch_idx + 1, len(batches), batch_ids,
            )

            # Filter to only steps whose dependencies are met
            ready = [
                sid for sid in batch_ids
                if self._resolver.can_run_now(sid, completed, steps)
            ]

            if not ready:
                # Deadlock or dependency issue — try sequential fallback
                for sid in batch_ids:
                    step = step_map[sid]
                    try:
                        tr = await self._run_single(step, context)
                        result.results[sid] = tr
                        result.completed.append(sid)
                        completed.add(sid)
                    except ExecutionError as exc:
                        result.failed.append(sid)
                        result.errors[sid] = str(exc)
                continue

            # Execute ready steps in parallel
            batch_result = await self._execute_batch(
                [step_map[sid] for sid in ready], context,
            )

            # Merge results
            for sid in batch_result.completed:
                result.completed.append(sid)
                completed.add(sid)
                if sid in batch_result.results:
                    result.results[sid] = batch_result.results[sid]

            for sid in batch_result.failed:
                result.failed.append(sid)
                if sid in batch_result.errors:
                    result.errors[sid] = batch_result.errors[sid]

            # If any critical step failed, stop
            if batch_result.failed and self._has_critical_failure(
                [step_map[sid] for sid in batch_result.failed],
            ):
                logger.warning("Critical failure in batch %d — stopping", batch_idx + 1)
                break

        result.elapsed_ms = (time.monotonic() - start) * 1000
        return result

    async def execute_batch(
        self,
        steps: list[PlanStep],
        context: str = "",
    ) -> ParallelResult:
        """Execute a single batch of steps concurrently (public interface)."""
        return await self._execute_batch(steps, context)

    # ── Private helpers ────────────────────────────────────────────────

    async def _execute_batch(
        self,
        steps: list[PlanStep],
        context: str,
    ) -> ParallelResult:
        """Execute a batch of steps concurrently with semaphore limiting."""
        result = ParallelResult()
        start = time.monotonic()

        tasks = []
        for step in steps:
            tasks.append(self._run_with_semaphore(step, context))

        outcomes = await asyncio.gather(*tasks, return_exceptions=True)

        for step, outcome in zip(steps, outcomes):
            if isinstance(outcome, Exception):
                result.failed.append(step.id)
                result.errors[step.id] = str(outcome)
                if self._monitor:
                    self._monitor.on_step_fail(step.id, str(outcome))
            else:
                result.completed.append(step.id)
                result.results[step.id] = outcome
                if self._monitor:
                    self._monitor.on_step_complete(step.id)

        result.elapsed_ms = (time.monotonic() - start) * 1000
        return result

    async def _run_with_semaphore(
        self, step: PlanStep, context: str,
    ) -> ToolResult:
        """Run a step with concurrency limiting."""
        async with self._semaphore:
            if self._monitor:
                self._monitor.on_step_start(step.id)
            return await self._run_single(step, context)

    async def _run_single(self, step: PlanStep, context: str) -> ToolResult:
        """Execute a single step and handle exceptions."""
        try:
            return await self._executor.execute(step, context)
        except ExecutionError:
            # The executor already updated step status
            raise
        except Exception as exc:
            step.status = SessionStatus.FAILED
            step.error = str(exc)
            raise ExecutionError(
                f"Unexpected error in step {step.id}: {exc}",
                details={"step_id": step.id},
            ) from exc

    @staticmethod
    def _has_critical_failure(failed_steps: list[PlanStep]) -> bool:
        """Check if any failed step is critical (blocks other steps)."""
        for step in failed_steps:
            # Steps with non-verification descriptions are considered critical
            non_critical = ["verify", "check", "test", "lint", "format"]
            if not any(kw in step.description.lower() for kw in non_critical):
                return True
        return False
