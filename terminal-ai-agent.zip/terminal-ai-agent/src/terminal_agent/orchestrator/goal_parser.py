"""Goal parser — converts natural language goals into structured representations.

Analyzes user intent, determines complexity, extracts constraints,
and produces a structured goal object suitable for planning.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from terminal_agent.types import GoalComplexity


class GoalType(str, Enum):
    """Categorized goal types."""
    FILE_OPERATION = "file_operation"
    CODE_GENERATION = "code_generation"
    CODE_MODIFICATION = "code_modification"
    DEBUGGING = "debugging"
    TESTING = "testing"
    GIT_OPERATION = "git_operation"
    PACKAGE_MANAGEMENT = "package_management"
    DATABASE_OPERATION = "database_operation"
    DOCKER_OPERATION = "docker_operation"
    DEPLOYMENT = "deployment"
    DOCUMENTATION = "documentation"
    REFACTORING = "refactoring"
    PROJECT_SETUP = "project_setup"
    SEARCH = "search"
    ANALYSIS = "analysis"
    SYSTEM_OPERATION = "system_operation"
    MULTI_STEP = "multi_step"
    UNKNOWN = "unknown"


@dataclass
class ParsedGoal:
    """Structured representation of a parsed goal."""
    raw_text: str
    goal_type: GoalType = GoalType.UNKNOWN
    complexity: GoalComplexity = GoalComplexity.MODERATE
    sub_goals: list[str] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    entities: dict[str, list[str]] = field(default_factory=dict)
    estimated_steps: int = 0
    requires_confirmation: bool = False
    working_directory: str | None = None
    language_hint: str | None = None
    framework_hint: str | None = None
    confidence: float = 0.0


# ── Pattern banks for goal classification ──────────────────────────────

_TYPE_PATTERNS: dict[GoalType, list[re.Pattern[str]]] = {
    GoalType.FILE_OPERATION: [
        re.compile(r"\b(create|write|read|edit|delete|move|copy|rename)\b.*\b(file|directory|folder)\b", re.I),
        re.compile(r"\b(save|store|output)\b.*\b(to|as|in)\b", re.I),
    ],
    GoalType.CODE_GENERATION: [
        re.compile(r"\b(write|create|generate|build|implement|scaffold)\b.*\b(function|class|module|component|api|endpoint|script|program|app)\b", re.I),
        re.compile(r"\b(code|program|script)\b.*\b(for|that|to)\b", re.I),
    ],
    GoalType.CODE_MODIFICATION: [
        re.compile(r"\b(fix|patch|update|modify|change|alter|adjust)\b.*\b(code|function|class|bug|issue|error)\b", re.I),
    ],
    GoalType.DEBUGGING: [
        re.compile(r"\b(debug|fix|resolve|troubleshoot|diagnose)\b.*\b(error|bug|issue|crash|failure|exception)\b", re.I),
        re.compile(r"\b(why|what\'s wrong|what is wrong|broken)\b", re.I),
    ],
    GoalType.TESTING: [
        re.compile(r"\b(test|spec|coverage|assert|verify)\b", re.I),
        re.compile(r"\b(write|run|generate)\b.*\b(test|tests|test suite)\b", re.I),
    ],
    GoalType.GIT_OPERATION: [
        re.compile(r"\b(git|commit|push|pull|branch|merge|rebase|stash|tag)\b", re.I),
        re.compile(r"\b(version control|repository|repo)\b", re.I),
    ],
    GoalType.PACKAGE_MANAGEMENT: [
        re.compile(r"\b(install|uninstall|update|upgrade|add|remove)\b.*\b(package|dependency|dependencies|library|lib|module)\b", re.I),
        re.compile(r"\b(npm|pip|cargo|go mod|yarn|pnpm|poetry|bundler|composer|maven|gradle)\b", re.I),
    ],
    GoalType.DATABASE_OPERATION: [
        re.compile(r"\b(database|db|sql|query|table|migration|schema|postgres|mysql|sqlite|mongo|redis)\b", re.I),
    ],
    GoalType.DOCKER_OPERATION: [
        re.compile(r"\b(docker|container|image|compose|dockerfile)\b", re.I),
    ],
    GoalType.DEPLOYMENT: [
        re.compile(r"\b(deploy|deployment|ci\/cd|pipeline|kubernetes|k8s|terraform|ansible|aws|gcp|azure)\b", re.I),
    ],
    GoalType.DOCUMENTATION: [
        re.compile(r"\b(document|documentation|readme|changelog|docstring|comment|guide)\b", re.I),
    ],
    GoalType.REFACTORING: [
        re.compile(r"\b(refactor|restructure|reorganize|clean up|simplify|optimize)\b.*\b(code|function|class|module)\b", re.I),
    ],
    GoalType.PROJECT_SETUP: [
        re.compile(r"\b(set up|setup|initialize|init|create|scaffold|bootstrap)\b.*\b(project|app|application|repo|repository)\b", re.I),
    ],
    GoalType.SEARCH: [
        re.compile(r"\b(search|find|grep|look for|locate|where)\b", re.I),
    ],
    GoalType.ANALYSIS: [
        re.compile(r"\b(analyze|analyse|review|inspect|examine|audit|check)\b", re.I),
    ],
}

# Complexity indicators
_COMPLEX_PATTERNS = [
    re.compile(r"\b(and then|after that|next|finally|also)\b", re.I),
    re.compile(r"\b(entire|whole|complete|full)\b.*\b(project|system|application)\b", re.I),
    re.compile(r"\b(multiple|several|many)\b", re.I),
    re.compile(r"\b(from scratch)\b", re.I),
]

_MULTI_SYSTEM_PATTERNS = [
    re.compile(r"\b(frontend|backend|database|api|server|client)\b.*\b(and|with)\b.*\b(frontend|backend|database|api|server|client)\b", re.I),
    re.compile(r"\b(microservice|distributed|full.?stack)\b", re.I),
    re.compile(r"\b(docker|kubernetes|terraform)\b.*\b(and|with)\b.*\b(docker|kubernetes|terraform)\b", re.I),
]

_CONFIRMATION_PATTERNS = [
    re.compile(r"\b(delete|remove|drop|destroy|rm|kill|reset|overwrite)\b", re.I),
    re.compile(r"\b(production|prod)\b", re.I),
    re.compile(r"\b(force|force-push|hard reset)\b", re.I),
]


class GoalParser:
    """Parses natural language goals into structured ParsedGoal objects."""

    def parse(self, goal_text: str) -> ParsedGoal:
        """Parse a natural language goal into a structured representation.

        Args:
            goal_text: The raw goal string from the user.

        Returns:
            A ParsedGoal with type, complexity, sub-goals, and metadata.
        """
        goal_text = goal_text.strip()
        if not goal_text:
            return ParsedGoal(raw_text="", confidence=0.0)

        parsed = ParsedGoal(raw_text=goal_text)

        # Classify goal type
        parsed.goal_type = self._classify_type(goal_text)

        # Determine complexity
        parsed.complexity = self._assess_complexity(goal_text)

        # Extract sub-goals (split on conjunctions / sequencing words)
        parsed.sub_goals = self._extract_sub_goals(goal_text)

        # Extract constraints
        parsed.constraints = self._extract_constraints(goal_text)

        # Extract entities (files, languages, tools)
        parsed.entities = self._extract_entities(goal_text)

        # Estimate steps
        parsed.estimated_steps = self._estimate_steps(parsed)

        # Check if confirmation needed
        parsed.requires_confirmation = self._needs_confirmation(goal_text)

        # Language / framework hints
        parsed.language_hint = self._detect_language(goal_text)
        parsed.framework_hint = self._detect_framework(goal_text)

        # Confidence
        parsed.confidence = self._calculate_confidence(parsed)

        return parsed

    # ── Private helpers ────────────────────────────────────────────────

    def _classify_type(self, text: str) -> GoalType:
        """Classify the goal type by pattern matching."""
        scores: dict[GoalType, int] = {}
        for gtype, patterns in _TYPE_PATTERNS.items():
            score = sum(1 for p in patterns if p.search(text))
            if score:
                scores[gtype] = score

        if not scores:
            return GoalType.UNKNOWN

        # If multiple types score equally, prefer MULTI_STEP
        max_score = max(scores.values())
        top = [g for g, s in scores.items() if s == max_score]
        if len(top) > 1:
            return GoalType.MULTI_STEP
        return top[0]

    def _assess_complexity(self, text: str) -> GoalComplexity:
        """Assess goal complexity from textual cues."""
        if any(p.search(text) for p in _MULTI_SYSTEM_PATTERNS):
            return GoalComplexity.MULTI_SYSTEM
        if any(p.search(text) for p in _COMPLEX_PATTERNS):
            return GoalComplexity.COMPLEX
        # Short goals are usually simple
        if len(text.split()) < 12:
            return GoalComplexity.SIMPLE
        return GoalComplexity.MODERATE

    def _extract_sub_goals(self, text: str) -> list[str]:
        """Break compound goals into atomic sub-goals."""
        # Split on common sequencing markers
        separators = re.compile(
            r"\b(?:then|after that|next|finally|also|and then|, then|;\s*)\b",
            re.IGNORECASE,
        )
        parts = [s.strip() for s in separators.split(text) if s.strip()]
        # If we only got one piece, try splitting on " and " with verb detection
        if len(parts) == 1:
            parts = re.split(r"\band\b", text, flags=re.IGNORECASE)
            parts = [p.strip() for p in parts if p.strip() and len(p.split()) > 2]
        return parts if len(parts) > 1 else []

    def _extract_constraints(self, text: str) -> list[str]:
        """Extract explicit constraints from the goal."""
        constraints: list[str] = []
        patterns = [
            (r"\b(without\s+[^,.]+)", "negative_constraint"),
            (r"\b(must\s+[^,.]+)", "requirement"),
            (r"\b(should\s+[^,.]+)", "preference"),
            (r"\b(using\s+[^,.]+)", "tool_constraint"),
            (r"\b(in\s+\w+\s+only)", "scope_constraint"),
        ]
        for pattern, _label in patterns:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                constraints.append(m.group(1).strip())
        return constraints

    def _extract_entities(self, text: str) -> dict[str, list[str]]:
        """Extract named entities (files, tools, languages)."""
        entities: dict[str, list[str]] = {}

        # File paths
        files = re.findall(r"[\w./\-]+\.\w+", text)
        if files:
            entities["files"] = files

        # Tools
        tool_names = re.findall(
            r"\b(git|docker|npm|pip|cargo|kubectl|terraform|ansible|make|curl|wget|ssh)\b",
            text, re.IGNORECASE,
        )
        if tool_names:
            entities["tools"] = list(set(t.lower() for t in tool_names))

        return entities

    def _estimate_steps(self, parsed: ParsedGoal) -> int:
        """Estimate the number of steps required."""
        base = {
            GoalType.FILE_OPERATION: 2,
            GoalType.CODE_GENERATION: 3,
            GoalType.CODE_MODIFICATION: 3,
            GoalType.DEBUGGING: 4,
            GoalType.TESTING: 3,
            GoalType.GIT_OPERATION: 2,
            GoalType.PACKAGE_MANAGEMENT: 2,
            GoalType.DATABASE_OPERATION: 3,
            GoalType.DOCKER_OPERATION: 3,
            GoalType.DEPLOYMENT: 5,
            GoalType.DOCUMENTATION: 3,
            GoalType.REFACTORING: 4,
            GoalType.PROJECT_SETUP: 4,
            GoalType.SEARCH: 2,
            GoalType.ANALYSIS: 3,
            GoalType.MULTI_STEP: 5,
            GoalType.UNKNOWN: 4,
        }.get(parsed.goal_type, 4)

        # Add for each sub-goal
        if parsed.sub_goals:
            base = max(base, len(parsed.sub_goals) * 2)

        complexity_multiplier = {
            GoalComplexity.SIMPLE: 0.75,
            GoalComplexity.MODERATE: 1.0,
            GoalComplexity.COMPLEX: 1.5,
            GoalComplexity.MULTI_SYSTEM: 2.0,
        }
        return max(1, int(base * complexity_multiplier.get(parsed.complexity, 1.0)))

    def _needs_confirmation(self, text: str) -> bool:
        """Check if the goal involves destructive actions."""
        return any(p.search(text) for p in _CONFIRMATION_PATTERNS)

    def _detect_language(self, text: str) -> str | None:
        """Detect programming language from goal text."""
        lang_patterns = {
            "python": r"\b(python|py|pip|pytest|django|flask|fastapi)\b",
            "javascript": r"\b(javascript|js|node|npm|react|vue|angular|express)\b",
            "typescript": r"\b(typescript|ts|tsx)\b",
            "go": r"\b(golang|go\s+mod|go\s+run)\b",
            "rust": r"\b(rust|cargo|rustc|crate)\b",
            "java": r"\b(java|maven|gradle|spring|junit)\b",
            "ruby": r"\b(ruby|rails|gem|bundler|rspec)\b",
            "php": r"\b(php|composer|laravel|symfony)\b",
            "c": r"\b(\bc\b|gcc|makefile|cmake)\b",
            "cpp": r"\b(c\+\+|cpp|g\+\+|clang)\b",
        }
        for lang, pattern in lang_patterns.items():
            if re.search(pattern, text, re.IGNORECASE):
                return lang
        return None

    def _detect_framework(self, text: str) -> str | None:
        """Detect framework from goal text."""
        frameworks = [
            "react", "vue", "angular", "next", "nuxt", "svelte",
            "django", "flask", "fastapi", "express", "koa", "nest",
            "spring", "rails", "laravel", "symfony",
            "pytest", "jest", "mocha", "cypress",
            "docker", "kubernetes", "terraform",
        ]
        text_lower = text.lower()
        for fw in frameworks:
            if fw in text_lower:
                return fw
        return None

    def _calculate_confidence(self, parsed: ParsedGoal) -> float:
        """Calculate parsing confidence (0.0 – 1.0)."""
        score = 0.5  # base
        if parsed.goal_type != GoalType.UNKNOWN:
            score += 0.2
        if parsed.sub_goals:
            score += 0.1
        if parsed.entities:
            score += 0.1
        if parsed.language_hint:
            score += 0.05
        if parsed.framework_hint:
            score += 0.05
        return min(1.0, score)
