"""Progress monitor — watches plan execution and detects stalls.

Tracks per-step and overall progress, detects when execution is
stalled, and triggers re-planning or escalation when needed.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum

from terminal_agent.types import Plan, PlanStep, SessionStatus

logger = logging.getLogger(__name__)


class MonitorEvent(str, Enum):
    """Events emitted by the progress monitor."""
    STEP_STARTED = "step_started"
    STEP_COMPLETED = "step_completed"
    STEP_FAILED = "step_failed"
    STALL_DETECTED = "stall_detected"
    PROGRESS_MADE = "progress_made"
    PLAN_COMPLETE = "plan_complete"
    PLAN_FAILED = "plan_failed"


@dataclass
class MonitorSnapshot:
    """Point-in-time snapshot of execution progress."""
    total_steps: int = 0
    completed: int = 0
    failed: int = 0
    in_progress: int = 0
    pending: int = 0
    percent_complete: float = 0.0
    elapsed_seconds: float = 0.0
    estimated_remaining: float = 0.0
    current_step: str | None = None
    stall_seconds: float = 0.0
    is_stalled: bool = False


class ProgressMonitor:
    """Monitors plan execution progress and detects stalls.

    The monitor is updated after each step transition and can report
    whether execution is making forward progress or appears stuck.
    """

    def __init__(
        self,
        stall_threshold: float = 120.0,
        check_interval: float = 10.0,
    ) -> None:
        """
        Args:
            stall_threshold: Seconds without progress before declaring stall.
            check_interval: How often (seconds) to check for stalls.
        """
        self._stall_threshold = stall_threshold
        self._check_interval = check_interval

        self._plan: Plan | None = None
        self._start_time: float = 0.0
        self._last_progress_time: float = 0.0
        self._step_start_times: dict[str, float] = {}
        self._step_durations: dict[str, float] = {}
        self._events: list[tuple[float, MonitorEvent, str]] = []
        self._listeners: list = []

    def start(self, plan: Plan) -> None:
        """Begin monitoring a plan."""
        self._plan = plan
        self._start_time = time.monotonic()
        self._last_progress_time = self._start_time
        self._step_start_times.clear()
        self._step_durations.clear()
        self._events.clear()
        logger.info("Monitoring started for plan with %d steps", len(plan.steps))

    def on_step_start(self, step_id: str) -> None:
        """Called when a step begins executing."""
        self._step_start_times[step_id] = time.monotonic()
        self._record_event(MonitorEvent.STEP_STARTED, step_id)

    def on_step_complete(self, step_id: str) -> None:
        """Called when a step completes successfully."""
        now = time.monotonic()
        if step_id in self._step_start_times:
            self._step_durations[step_id] = now - self._step_start_times[step_id]
        self._last_progress_time = now
        self._record_event(MonitorEvent.STEP_COMPLETED, step_id)
        self._emit(MonitorEvent.PROGRESS_MADE, step_id)

        # Check if plan is now complete
        if self._plan and self._is_plan_complete():
            self._emit(MonitorEvent.PLAN_COMPLETE, "all_steps_done")

    def on_step_fail(self, step_id: str, error: str = "") -> None:
        """Called when a step fails."""
        now = time.monotonic()
        if step_id in self._step_start_times:
            self._step_durations[step_id] = now - self._step_start_times[step_id]
        self._record_event(MonitorEvent.STEP_FAILED, f"{step_id}: {error}")

    def check_stall(self) -> bool:
        """Check whether execution appears stalled.

        Returns:
            True if the monitor detects a stall condition.
        """
        if self._plan is None:
            return False

        elapsed_since_progress = time.monotonic() - self._last_progress_time
        if elapsed_since_progress >= self._stall_threshold:
            self._record_event(
                MonitorEvent.STALL_DETECTED,
                f"No progress for {elapsed_since_progress:.0f}s",
            )
            return True
        return False

    def snapshot(self) -> MonitorSnapshot:
        """Get a point-in-time progress snapshot."""
        if self._plan is None:
            return MonitorSnapshot()

        now = time.monotonic()
        steps = self._plan.steps
        total = len(steps)

        completed = sum(1 for s in steps if s.status == SessionStatus.COMPLETED)
        failed = sum(1 for s in steps if s.status == SessionStatus.FAILED)
        in_progress = sum(1 for s in steps if s.status == SessionStatus.RUNNING)
        pending = sum(1 for s in steps if s.status == SessionStatus.PENDING)

        pct = (completed / total * 100) if total > 0 else 0.0
        elapsed = now - self._start_time

        # Estimate remaining time based on average step duration
        avg_duration = (
            sum(self._step_durations.values()) / len(self._step_durations)
            if self._step_durations else 0.0
        )
        remaining_steps = total - completed - failed
        estimated_remaining = avg_duration * remaining_steps

        # Current step
        current = None
        for s in steps:
            if s.status == SessionStatus.RUNNING:
                current = s.id
                break

        stall_elapsed = now - self._last_progress_time

        return MonitorSnapshot(
            total_steps=total,
            completed=completed,
            failed=failed,
            in_progress=in_progress,
            pending=pending,
            percent_complete=pct,
            elapsed_seconds=elapsed,
            estimated_remaining=estimated_remaining,
            current_step=current,
            stall_seconds=stall_elapsed,
            is_stalled=stall_elapsed >= self._stall_threshold,
        )

    def get_events(self, since: float = 0.0) -> list[tuple[float, MonitorEvent, str]]:
        """Get monitor events since a timestamp."""
        return [(t, e, d) for t, e, d in self._events if t >= since]

    def add_listener(self, callback) -> None:
        """Add a listener for monitor events."""
        self._listeners.append(callback)

    # ── Private helpers ────────────────────────────────────────────────

    def _is_plan_complete(self) -> bool:
        """Check if all steps are in a terminal state."""
        if self._plan is None:
            return False
        return all(
            s.status in (SessionStatus.COMPLETED, SessionStatus.FAILED)
            for s in self._plan.steps
        )

    def _record_event(self, event: MonitorEvent, detail: str) -> None:
        """Record a monitor event."""
        self._events.append((time.monotonic(), event, detail))
        logger.debug("Monitor event: %s — %s", event.value, detail)

    def _emit(self, event: MonitorEvent, detail: str) -> None:
        """Emit an event to all listeners."""
        for listener in self._listeners:
            try:
                listener(event, detail)
            except Exception:
                logger.exception("Monitor listener error")
