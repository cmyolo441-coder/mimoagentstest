"""Core agent loop — the heartbeat of Terminal Agent.

Implements the Think-Act-Observe-Verify paradigm:
  Accept goal → Generate plan → Execute steps → Verify results →
  Handle errors → Report completion.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Protocol

from terminal_agent.exceptions import (
    ExecutionError,
    MaxIterationsError,
    OrchestratorError,
    PlanningError,
)
from terminal_agent.orchestrator.dependency_resolver import DependencyResolver
from terminal_agent.orchestrator.executor import StepExecutor
from terminal_agent.orchestrator.goal_parser import GoalParser, ParsedGoal
from terminal_agent.orchestrator.lifecycle import LifecycleEvent, LifecycleManager
from terminal_agent.orchestrator.monitor import MonitorSnapshot, ProgressMonitor
from terminal_agent.orchestrator.parallel_executor import ParallelExecutor
from terminal_agent.orchestrator.planner import Planner
from terminal_agent.orchestrator.progress import ProgressBar, ProgressTracker, StepRecord
from terminal_agent.orchestrator.re_planner import RePlanner, ReplanStrategy
from terminal_agent.orchestrator.session_manager import SessionManager
from terminal_agent.orchestrator.termination import (
    TerminationChecker,
    TerminationDecision,
    TerminationReason,
)
from terminal_agent.types import (
    LLMResponse,
    Plan,
    PlanStep,
    Session,
    SessionStatus,
    ToolCall,
    ToolResult,
    ToolResultStatus,
    TraceEntry,
)

logger = logging.getLogger(__name__)


# ── Protocol interfaces (dependency inversion) ─────────────────────────

class ContextManager(Protocol):
    """Protocol for context assembly."""

    async def assemble(self, goal: str, plan: Plan | None, **kwargs: Any) -> str:
        """Build the prompt context for an LLM call."""
        ...


class MemoryEngine(Protocol):
    """Protocol for memory operations."""

    async def recall(self, query: str, limit: int = 5) -> list[str]:
        """Recall relevant memories."""
        ...

    async def store(self, content: str, category: str = "task") -> None:
        """Store a new memory."""
        ...


class VerificationEngine(Protocol):
    """Protocol for result verification."""

    async def verify(self, step: PlanStep, result: ToolResult) -> tuple[bool, str]:
        """Verify a step result. Returns (passed, reason)."""
        ...


class LLMEngine(Protocol):
    """Protocol for LLM interaction."""

    async def generate(self, prompt: str, **kwargs: Any) -> LLMResponse:
        """Generate a response from the LLM."""
        ...


# ── Main agent loop ───────────────────────────────────────────────────

class AgentLoop:
    """The core agent loop implementing Think-Act-Observe-Verify.

    Orchestrates the full lifecycle:
      1. Parse the goal.
      2. Generate a plan.
      3. Execute each step (via the StepExecutor or ParallelExecutor).
      4. Verify results.
      5. Handle failures (via the RePlanner).
      6. Check termination conditions.
      7. Report completion.
    """

    def __init__(
        self,
        *,
        llm: LLMEngine | None = None,
        context_manager: ContextManager | None = None,
        memory: MemoryEngine | None = None,
        verifier: VerificationEngine | None = None,
        tool_dispatcher: Any | None = None,
        max_iterations: int = 100,
        max_cost: float = 5.0,
        parallel: bool = False,
        max_concurrency: int = 5,
    ) -> None:
        # Core dependencies
        self._llm = llm
        self._context = context_manager
        self._memory = memory
        self._verifier = verifier
        self._tool_dispatcher = tool_dispatcher

        # Sub-components
        self._goal_parser = GoalParser()
        self._planner = Planner(llm=llm)
        self._step_executor = StepExecutor(
            tool_dispatcher=tool_dispatcher,
            llm_engine=llm,
        )
        self._monitor = ProgressMonitor()
        self._re_planner = RePlanner(planner=self._planner)
        self._progress = ProgressTracker()
        self._session_mgr = SessionManager()
        self._termination = TerminationChecker(
            max_iterations=max_iterations,
            max_cost=max_cost,
        )
        self._lifecycle = LifecycleManager()
        self._dependency_resolver = DependencyResolver()
        self._parallel_executor = ParallelExecutor(
            step_executor=self._step_executor,
            monitor=self._monitor,
            max_concurrency=max_concurrency,
        ) if parallel else None

        self._parallel = parallel
        self._session: Session | None = None

    # ── Public API ─────────────────────────────────────────────────────

    @property
    def lifecycle(self) -> LifecycleManager:
        """Access the lifecycle event manager."""
        return self._lifecycle

    @property
    def session(self) -> Session | None:
        """The current session (if any)."""
        return self._session

    async def run(
        self,
        goal: str,
        model: str = "",
        interactive: bool = False,
        stream: Any | None = None,
    ) -> Session:
        """Run the full agent loop for a goal.

        This is the main entry point.  It drives the entire
        Think → Act → Observe → Verify cycle until the goal is
        achieved or a termination condition is met.

        Args:
            goal: Natural-language goal from the user.
            model: LLM model identifier.
            interactive: Whether to prompt for confirmations.
            stream: Output stream for progress display.

        Returns:
            The completed Session object.
        """
        # ── Setup ──────────────────────────────────────────────────────
        session = self._session_mgr.create_session(goal, model=model)
        self._session = session
        self._lifecycle.emit(LifecycleEvent.SESSION_CREATED, session.id)
        self._termination.start()
        progress_bar = ProgressBar(stream=stream) if stream else None

        try:
            self._session_mgr.start_session(session.id)
            self._lifecycle.emit(LifecycleEvent.SESSION_STARTED, session.id)

            # ── Step 1: Parse goal ─────────────────────────────────────
            parsed = self._goal_parser.parse(goal)
            logger.info(
                "Goal parsed: type=%s complexity=%s confidence=%.2f",
                parsed.goal_type.value, parsed.complexity.value, parsed.confidence,
            )

            # ── Step 2: Generate plan ──────────────────────────────────
            context_str = await self._build_context(goal)
            plan = await self._planner.generate_plan(parsed, context=context_str)
            session.plan = plan
            self._lifecycle.emit(LifecycleEvent.PLAN_GENERATED, session.id)
            logger.info("Plan generated with %d steps", len(plan.steps))

            self._progress.set_total(len(plan.steps))
            self._monitor.start(plan)

            # ── Step 3: Execute plan ───────────────────────────────────
            if self._parallel and self._parallel_executor:
                await self._run_parallel(plan, context_str, session.id)
            else:
                await self._run_sequential(plan, context_str, session.id)

            # ── Step 4: Final status ───────────────────────────────────
            completed = sum(
                1 for s in plan.steps if s.status == SessionStatus.COMPLETED
            )
            failed = sum(
                1 for s in plan.steps if s.status == SessionStatus.FAILED
            )

            if completed == len(plan.steps):
                self._lifecycle.emit(LifecycleEvent.GOAL_ACHIEVED, session.id)
                self._session_mgr.complete_session(
                    session.id,
                    outcome=f"All {completed} steps completed successfully.",
                )
            elif completed > 0:
                self._session_mgr.complete_session(
                    session.id,
                    outcome=f"{completed}/{len(plan.steps)} steps completed, {failed} failed.",
                )
            else:
                self._lifecycle.emit(LifecycleEvent.GOAL_FAILED, session.id)
                self._session_mgr.fail_session(
                    session.id,
                    error_message=f"All {len(plan.steps)} steps failed.",
                )

        except KeyboardInterrupt:
            self._termination.set_user_interrupt()
            self._lifecycle.emit(LifecycleEvent.SESSION_CANCELLED, session.id)
            self._session_mgr.cancel_session(session.id)

        except Exception as exc:
            logger.exception("Agent loop error")
            self._lifecycle.emit(LifecycleEvent.SESSION_FAILED, session.id)
            self._session_mgr.fail_session(session.id, error_message=str(exc))
            raise

        finally:
            # Final report
            if progress_bar:
                progress_bar.finish(self._progress)
            report = self._progress.final_report()
            logger.info("Session %s finished:\n%s", session.id, report)

        return self._session_mgr.get_session(session.id) or session

    # ── Sequential execution ───────────────────────────────────────────

    async def _run_sequential(
        self,
        plan: Plan,
        context: str,
        session_id: str,
    ) -> None:
        """Execute plan steps one by one in dependency order."""
        batches = self._dependency_resolver.get_execution_order(plan.steps)
        completed_ids: set[str] = set()

        for batch in batches:
            for step_id in batch:
                # Check termination
                decision = self._termination.check(plan)
                if decision.should_stop:
                    self._handle_termination(decision, session_id)
                    return

                # Resolve step
                step = next((s for s in plan.steps if s.id == step_id), None)
                if step is None:
                    continue

                # Check dependencies
                if not self._dependency_resolver.can_run_now(
                    step_id, completed_ids, plan.steps,
                ):
                    logger.debug("Skipping %s — dependencies not met", step_id)
                    continue

                # Execute
                await self._execute_and_verify(step, context, session_id, plan)

                if step.status == SessionStatus.COMPLETED:
                    completed_ids.add(step_id)
                    self._progress.record_step(StepRecord(
                        step_id=step.id,
                        description=step.description,
                        status=step.status,
                        duration_ms=step.result.duration_ms if step.result else 0,
                        output_preview=(step.result.output[:200] if step.result else ""),
                    ))
                elif step.status == SessionStatus.FAILED:
                    # Attempt recovery
                    recovered = await self._attempt_recovery(
                        plan, step, context, session_id,
                    )
                    if recovered:
                        completed_ids.add(step_id)

                self._termination.increment_iteration()

    # ── Parallel execution ─────────────────────────────────────────────

    async def _run_parallel(
        self,
        plan: Plan,
        context: str,
        session_id: str,
    ) -> None:
        """Execute plan steps with parallelism where possible."""
        assert self._parallel_executor is not None

        result = await self._parallel_executor.execute_plan(plan.steps, context)

        for step_id in result.completed:
            step = next((s for s in plan.steps if s.id == step_id), None)
            if step and step.result:
                self._progress.record_step(StepRecord(
                    step_id=step.id,
                    description=step.description,
                    status=SessionStatus.COMPLETED,
                    duration_ms=step.result.duration_ms,
                    output_preview=step.result.output[:200],
                ))

        for step_id in result.failed:
            step = next((s for s in plan.steps if s.id == step_id), None)
            if step:
                self._progress.record_step(StepRecord(
                    step_id=step.id,
                    description=step.description,
                    status=SessionStatus.FAILED,
                    error=result.errors.get(step_id),
                ))

    # ── Execute and verify a single step ───────────────────────────────

    async def _execute_and_verify(
        self,
        step: PlanStep,
        context: str,
        session_id: str,
        plan: Plan,
    ) -> None:
        """Execute a step and verify its result."""
        self._monitor.on_step_start(step.id)
        self._lifecycle.emit(LifecycleEvent.STEP_STARTED, session_id, {"step_id": step.id})

        try:
            result = await self._step_executor.execute(step, context)

            # Verify
            if self._verifier:
                passed, reason = await self._verifier.verify(step, result)
                if passed:
                    self._lifecycle.emit(LifecycleEvent.VERIFICATION_PASSED, session_id)
                else:
                    self._lifecycle.emit(LifecycleEvent.VERIFICATION_FAILED, session_id)
                    step.status = SessionStatus.FAILED
                    step.error = f"Verification failed: {reason}"
                    self._monitor.on_step_fail(step.id, reason)
                    self._lifecycle.emit(LifecycleEvent.STEP_FAILED, session_id)
                    return

            self._monitor.on_step_complete(step.id)
            self._lifecycle.emit(LifecycleEvent.STEP_COMPLETED, session_id)
            self._session_mgr.add_trace(session_id, TraceEntry(
                timestamp=time.time(),
                entry_type="observation",
                content=result.output[:500],
                metadata={"step_id": step.id, "tool": step.tool_hint},
            ))

        except ExecutionError as exc:
            step.status = SessionStatus.FAILED
            step.error = str(exc)
            self._monitor.on_step_fail(step.id, str(exc))
            self._lifecycle.emit(LifecycleEvent.STEP_FAILED, session_id)
            logger.warning("Step %s failed: %s", step.id, exc)

    # ── Error recovery ─────────────────────────────────────────────────

    async def _attempt_recovery(
        self,
        plan: Plan,
        failed_step: PlanStep,
        context: str,
        session_id: str,
    ) -> bool:
        """Attempt to recover from a failed step.

        Returns:
            True if recovery succeeded, False otherwise.
        """
        self._lifecycle.emit(LifecycleEvent.ERROR_RECOVERY_STARTED, session_id)
        completed_ids = [
            s.id for s in plan.steps if s.status == SessionStatus.COMPLETED
        ]

        decision = await self._re_planner.handle_failure(
            plan=plan,
            failed_step=failed_step,
            error=failed_step.error or "Unknown error",
            completed_steps=completed_ids,
            context=context,
        )

        logger.info(
            "Recovery strategy for %s: %s — %s",
            failed_step.id, decision.strategy.value, decision.reason,
        )

        if decision.strategy == ReplanStrategy.RETRY_SAME:
            # Reset and retry
            failed_step.status = SessionStatus.PENDING
            failed_step.error = None
            await self._execute_and_verify(failed_step, context, session_id, plan)
            return failed_step.status == SessionStatus.COMPLETED

        if decision.strategy == ReplanStrategy.RETRY_MODIFIED:
            failed_step.status = SessionStatus.PENDING
            failed_step.error = None
            # Add error context
            mod_context = f"{context}\n\nPrevious attempt failed. Try a different approach."
            await self._execute_and_verify(failed_step, mod_context, session_id, plan)
            return failed_step.status == SessionStatus.COMPLETED

        if decision.strategy == ReplanStrategy.SUBSTITUTE_STEP and decision.recovery_step:
            plan.steps.append(decision.recovery_step)
            await self._execute_and_verify(
                decision.recovery_step, context, session_id, plan,
            )
            return decision.recovery_step.status == SessionStatus.COMPLETED

        if decision.strategy == ReplanStrategy.SKIP_STEP:
            failed_step.status = SessionStatus.COMPLETED
            failed_step.error = "Skipped after repeated failures"
            self._lifecycle.emit(LifecycleEvent.STEP_SKIPPED, session_id)
            return True

        if decision.strategy == ReplanStrategy.REGENERATE_REMAINING and decision.modified_plan:
            # Replace plan and continue
            plan.steps = decision.modified_plan.steps
            self._lifecycle.emit(LifecycleEvent.PLAN_UPDATED, session_id)
            return False  # Let the main loop re-evaluate

        # ABORT
        self._lifecycle.emit(LifecycleEvent.ERROR_RECOVERY_FAILED, session_id)
        return False

    # ── Context building ───────────────────────────────────────────────

    async def _build_context(self, goal: str) -> str:
        """Build the initial context string from available sources."""
        parts: list[str] = []

        if self._context:
            try:
                return await self._context.assemble(goal, plan=None)
            except Exception:
                logger.warning("Context manager failed, using basic context")

        if self._memory:
            try:
                memories = await self._memory.recall(goal, limit=5)
                if memories:
                    parts.append("RELEVANT MEMORIES:")
                    for m in memories:
                        parts.append(f"  - {m}")
            except Exception:
                logger.warning("Memory recall failed")

        parts.append(f"GOAL: {goal}")
        return "\n".join(parts)

    # ── Termination handling ───────────────────────────────────────────

    def _handle_termination(
        self, decision: TerminationDecision, session_id: str,
    ) -> None:
        """Handle a termination decision."""
        logger.info("Termination: %s — %s", decision.reason.value, decision.message)

        if decision.reason == TerminationReason.COST_LIMIT:
            self._lifecycle.emit(LifecycleEvent.COST_WARNING, session_id)
        elif decision.reason == TerminationReason.MAX_ITERATIONS:
            self._lifecycle.emit(LifecycleEvent.ITERATION_WARNING, session_id)
