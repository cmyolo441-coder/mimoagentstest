"""Session manager — lifecycle management for agent sessions.

Handles creation, persistence, pause/resume, and cleanup of sessions.
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any

from terminal_agent.exceptions import SessionError
from terminal_agent.types import Plan, Session, SessionStatus, TraceEntry

logger = logging.getLogger(__name__)


class SessionManager:
    """Manages the lifecycle of agent sessions.

    Responsibilities:
      - Create new sessions with unique IDs.
      - Track active sessions.
      - Pause and resume sessions.
      - End sessions (complete, fail, cancel).
      - Persist session data (via an optional persistence backend).
    """

    def __init__(self, persistence: Any | None = None) -> None:
        """
        Args:
            persistence: Optional persistence backend (database interface).
        """
        self._persistence = persistence
        self._active_sessions: dict[str, Session] = {}
        self._paused_sessions: dict[str, Session] = {}

    def create_session(
        self,
        goal: str,
        model: str = "",
        plan: Plan | None = None,
    ) -> Session:
        """Create a new agent session.

        Args:
            goal: The user's goal text.
            model: The LLM model to use.
            plan: The initial plan (if pre-generated).

        Returns:
            A new Session object in PENDING status.
        """
        session = Session(
            id=str(uuid.uuid4()),
            goal=goal,
            status=SessionStatus.PENDING,
            start_time=time.time(),
            model_used=model,
            plan=plan,
        )
        self._active_sessions[session.id] = session
        logger.info("Created session %s for goal: %s", session.id, goal[:80])
        return session

    def start_session(self, session_id: str) -> Session:
        """Transition a session to RUNNING status.

        Args:
            session_id: The session to start.

        Returns:
            The updated session.

        Raises:
            SessionError: If the session is not found or not in PENDING status.
        """
        session = self._get_session(session_id)
        if session.status != SessionStatus.PENDING:
            raise SessionError(
                f"Cannot start session in {session.status.value} status",
                details={"session_id": session_id},
            )
        session.status = SessionStatus.RUNNING
        logger.info("Session %s started", session_id)
        return session

    def pause_session(self, session_id: str) -> Session:
        """Pause a running session.

        Args:
            session_id: The session to pause.

        Returns:
            The updated session.
        """
        session = self._get_active(session_id)
        if session.status != SessionStatus.RUNNING:
            raise SessionError(
                f"Cannot pause session in {session.status.value} status",
                details={"session_id": session_id},
            )
        session.status = SessionStatus.PAUSED
        self._paused_sessions[session_id] = session
        del self._active_sessions[session_id]
        logger.info("Session %s paused", session_id)
        return session

    def resume_session(self, session_id: str) -> Session:
        """Resume a paused session.

        Args:
            session_id: The session to resume.

        Returns:
            The updated session.
        """
        session = self._paused_sessions.pop(session_id, None)
        if session is None:
            raise SessionError(
                f"Session {session_id} not found in paused sessions",
                details={"session_id": session_id},
            )
        session.status = SessionStatus.RUNNING
        self._active_sessions[session_id] = session
        logger.info("Session %s resumed", session_id)
        return session

    def complete_session(
        self,
        session_id: str,
        outcome: str = "",
    ) -> Session:
        """Mark a session as completed.

        Args:
            session_id: The session to complete.
            outcome: Human-readable outcome description.

        Returns:
            The updated session.
        """
        session = self._get_session(session_id)
        session.status = SessionStatus.COMPLETED
        session.end_time = time.time()
        session.outcome = outcome
        self._persist(session)
        self._cleanup(session_id)
        logger.info("Session %s completed: %s", session_id, outcome[:100])
        return session

    def fail_session(
        self,
        session_id: str,
        error_message: str = "",
    ) -> Session:
        """Mark a session as failed.

        Args:
            session_id: The session to fail.
            error_message: Description of the failure.

        Returns:
            The updated session.
        """
        session = self._get_session(session_id)
        session.status = SessionStatus.FAILED
        session.end_time = time.time()
        session.error_message = error_message
        self._persist(session)
        self._cleanup(session_id)
        logger.info("Session %s failed: %s", session_id, error_message[:100])
        return session

    def cancel_session(self, session_id: str) -> Session:
        """Cancel a session (user-initiated).

        Args:
            session_id: The session to cancel.

        Returns:
            The updated session.
        """
        session = self._get_session(session_id)
        session.status = SessionStatus.CANCELLED
        session.end_time = time.time()
        session.outcome = "Cancelled by user"
        self._persist(session)
        self._cleanup(session_id)
        logger.info("Session %s cancelled", session_id)
        return session

    def timeout_session(self, session_id: str) -> Session:
        """Mark a session as timed out.

        Args:
            session_id: The session that timed out.

        Returns:
            The updated session.
        """
        session = self._get_session(session_id)
        session.status = SessionStatus.TIMEOUT
        session.end_time = time.time()
        session.outcome = "Timed out"
        self._persist(session)
        self._cleanup(session_id)
        logger.info("Session %s timed out", session_id)
        return session

    def get_session(self, session_id: str) -> Session | None:
        """Get a session by ID (active or paused)."""
        return (
            self._active_sessions.get(session_id)
            or self._paused_sessions.get(session_id)
        )

    def get_active_sessions(self) -> list[Session]:
        """List all active sessions."""
        return list(self._active_sessions.values())

    def get_paused_sessions(self) -> list[Session]:
        """List all paused sessions."""
        return list(self._paused_sessions.values())

    def add_trace(self, session_id: str, entry: TraceEntry) -> None:
        """Add a trace entry to a session."""
        session = self._get_session(session_id)
        session.traces.append(entry)

    def update_tokens(self, session_id: str, tokens: int, cost: float = 0.0) -> None:
        """Update cumulative token usage for a session."""
        session = self._get_session(session_id)
        session.total_tokens += tokens
        session.total_cost += cost

    def increment_steps(self, session_id: str) -> None:
        """Increment the step counter for a session."""
        session = self._get_session(session_id)
        session.total_steps += 1

    # ── Private helpers ────────────────────────────────────────────────

    def _get_session(self, session_id: str) -> Session:
        """Get a session from active or paused, or raise."""
        session = self.get_session(session_id)
        if session is None:
            raise SessionError(
                f"Session {session_id} not found",
                details={"session_id": session_id},
            )
        return session

    def _get_active(self, session_id: str) -> Session:
        """Get a session from active sessions only, or raise."""
        session = self._active_sessions.get(session_id)
        if session is None:
            raise SessionError(
                f"Active session {session_id} not found",
                details={"session_id": session_id},
            )
        return session

    def _persist(self, session: Session) -> None:
        """Persist a session to the backend (if available)."""
        if self._persistence is not None:
            try:
                self._persistence.save_session(session)  # type: ignore[union-attr]
            except Exception:
                logger.exception("Failed to persist session %s", session.id)

    def _cleanup(self, session_id: str) -> None:
        """Remove a session from in-memory tracking."""
        self._active_sessions.pop(session_id, None)
        self._paused_sessions.pop(session_id, None)
