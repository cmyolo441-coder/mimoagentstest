"""Re-planner — handles plan adaptation on failure or new information.

When a step fails or new context emerges, the re-planner decides
whether to retry, skip, substitute, or regenerate the plan.
"""

from __future__ import annotations

import logging
from enum import Enum
from typing import Any

from terminal_agent.exceptions import PlanningError
from terminal_agent.orchestrator.planner import Planner
from terminal_agent.types import (
    GoalComplexity,
    Plan,
    PlanStep,
    RecoveryLevel,
    SessionStatus,
)

logger = logging.getLogger(__name__)


class ReplanStrategy(str, Enum):
    """Available re-planning strategies."""
    RETRY_SAME = "retry_same"
    RETRY_MODIFIED = "retry_modified"
    SUBSTITUTE_STEP = "substitute_step"
    SKIP_STEP = "skip_step"
    INSERT_RECOVERY = "insert_recovery"
    REGENERATE_REMAINING = "regenerate_remaining"
    ABORT = "abort"


class ReplanDecision:
    """Decision from the re-planner."""

    def __init__(
        self,
        strategy: ReplanStrategy,
        reason: str,
        modified_plan: Plan | None = None,
        recovery_step: PlanStep | None = None,
    ) -> None:
        self.strategy = strategy
        self.reason = reason
        self.modified_plan = modified_plan
        self.recovery_step = recovery_step


class RePlanner:
    """Decides how to adapt a plan when things go wrong.

    Uses an escalation strategy — starts with the least disruptive
    recovery and escalates to more drastic measures if needed.
    """

    def __init__(self, planner: Planner | None = None) -> None:
        self._planner = planner
        self._failure_counts: dict[str, int] = {}
        self._max_same_step_retries = 2

    async def handle_failure(
        self,
        plan: Plan,
        failed_step: PlanStep,
        error: str,
        completed_steps: list[str],
        context: str = "",
    ) -> ReplanDecision:
        """Decide how to handle a failed step.

        Args:
            plan: The current plan.
            failed_step: The step that failed.
            error: Error description.
            completed_steps: IDs of already-completed steps.
            context: Additional context for LLM-assisted re-planning.

        Returns:
            A ReplanDecision with the chosen strategy.
        """
        self._failure_counts[failed_step.id] = (
            self._failure_counts.get(failed_step.id, 0) + 1
        )
        failures = self._failure_counts[failed_step.id]

        logger.info(
            "Re-planning for step %s (failure #%d): %s",
            failed_step.id, failures, error[:200],
        )

        # Escalation ladder
        if failures == 1:
            return ReplanDecision(
                strategy=ReplanStrategy.RETRY_SAME,
                reason="First failure — retrying the same step.",
            )

        if failures == 2:
            return ReplanDecision(
                strategy=ReplanStrategy.RETRY_MODIFIED,
                reason="Second failure — retrying with modified approach.",
            )

        if failures == 3:
            # Try substituting with an alternative step
            recovery = PlanStep(
                id=f"{failed_step.id}_alt",
                description=f"Alternative approach for: {failed_step.description}",
                dependencies=failed_step.dependencies,
                status=SessionStatus.PENDING,
            )
            return ReplanDecision(
                strategy=ReplanStrategy.SUBSTITUTE_STEP,
                reason="Third failure — substituting with alternative step.",
                recovery_step=recovery,
            )

        # Beyond 3 failures: decide skip or regenerate
        if self._is_non_critical(plan, failed_step):
            return ReplanDecision(
                strategy=ReplanStrategy.SKIP_STEP,
                reason="Non-critical step failed multiple times — skipping.",
            )

        # Critical step: regenerate remaining plan
        if self._planner is not None:
            try:
                new_plan = await self._planner.regenerate_plan(
                    original_plan=plan,
                    completed_steps=completed_steps,
                    failed_step=failed_step.id,
                    error_info=error,
                    context=context,
                )
                return ReplanDecision(
                    strategy=ReplanStrategy.REGENERATE_REMAINING,
                    reason="Critical step failed — regenerated remaining plan.",
                    modified_plan=new_plan,
                )
            except PlanningError:
                pass

        return ReplanDecision(
            strategy=ReplanStrategy.ABORT,
            reason="All recovery strategies exhausted.",
        )

    def get_recovery_level(self, strategy: ReplanStrategy) -> RecoveryLevel:
        """Map a re-plan strategy to a recovery level."""
        mapping = {
            ReplanStrategy.RETRY_SAME: RecoveryLevel.IMMEDIATE_RETRY,
            ReplanStrategy.RETRY_MODIFIED: RecoveryLevel.MODIFIED_RETRY,
            ReplanStrategy.SUBSTITUTE_STEP: RecoveryLevel.ALTERNATIVE_APPROACH,
            ReplanStrategy.SKIP_STEP: RecoveryLevel.ALTERNATIVE_APPROACH,
            ReplanStrategy.INSERT_RECOVERY: RecoveryLevel.ALTERNATIVE_APPROACH,
            ReplanStrategy.REGENERATE_REMAINING: RecoveryLevel.RE_PLAN,
            ReplanStrategy.ABORT: RecoveryLevel.GRACEFUL_ABORT,
        }
        return mapping.get(strategy, RecoveryLevel.GRACEFUL_ABORT)

    def reset(self) -> None:
        """Reset failure counters (e.g. for a new session)."""
        self._failure_counts.clear()

    # ── Private helpers ────────────────────────────────────────────────

    @staticmethod
    def _is_non_critical(plan: Plan, step: PlanStep) -> bool:
        """Determine if a step is non-critical (safe to skip).

        A step is non-critical if:
        - No other step depends on it, OR
        - It's a verification/documentation step (not a creation step).
        """
        # Check if any other step depends on this one
        dependent_ids = {
            dep
            for s in plan.steps
            for dep in s.dependencies
            if dep == step.id
        }
        if dependent_ids:
            return False  # Other steps depend on this

        # Check step description for non-critical keywords
        non_critical_keywords = [
            "verify", "check", "test", "document", "lint",
            "format", "review", "validate", "summary",
        ]
        desc_lower = step.description.lower()
        return any(kw in desc_lower for kw in non_critical_keywords)
