"""Progress tracking and display — human-readable progress reporting.

Provides a ProgressTracker that accumulates step results and a
ProgressBar for terminal display.
"""

from __future__ import annotations

import sys
import time
from dataclasses import dataclass, field
from typing import TextIO

from terminal_agent.types import PlanStep, SessionStatus


@dataclass
class StepRecord:
    """Record of a completed or failed step."""
    step_id: str
    description: str
    status: SessionStatus
    duration_ms: float = 0.0
    output_preview: str = ""
    error: str | None = None


class ProgressTracker:
    """Tracks cumulative progress across plan steps.

    Accumulates step records, computes statistics, and provides
    summary text for reporting.
    """

    def __init__(self) -> None:
        self._records: list[StepRecord] = []
        self._start_time: float = time.monotonic()
        self._total_steps: int = 0

    def set_total(self, total: int) -> None:
        """Set the expected total number of steps."""
        self._total_steps = total

    def record_step(self, record: StepRecord) -> None:
        """Record the result of a step."""
        self._records.append(record)

    @property
    def completed(self) -> int:
        return sum(1 for r in self._records if r.status == SessionStatus.COMPLETED)

    @property
    def failed(self) -> int:
        return sum(1 for r in self._records if r.status == SessionStatus.FAILED)

    @property
    def total(self) -> int:
        return self._total_steps or len(self._records)

    @property
    def percent(self) -> float:
        t = self.total
        return (self.completed / t * 100) if t > 0 else 0.0

    @property
    def elapsed(self) -> float:
        return time.monotonic() - self._start_time

    @property
    def is_done(self) -> bool:
        return self.completed + self.failed >= self.total

    def summary(self) -> str:
        """Generate a human-readable progress summary."""
        lines = [
            f"Progress: {self.completed}/{self.total} steps ({self.percent:.0f}%)",
            f"Elapsed: {self.elapsed:.1f}s",
        ]
        if self.failed:
            lines.append(f"Failed: {self.failed} steps")

        # Show last few steps
        recent = self._records[-5:]
        if recent:
            lines.append("Recent steps:")
            for r in recent:
                icon = "✓" if r.status == SessionStatus.COMPLETED else "✗"
                lines.append(f"  {icon} {r.step_id}: {r.description[:60]}")

        return "\n".join(lines)

    def files_summary(self) -> str:
        """Summarise files created or modified."""
        # Placeholder — would be populated from tool side-effects
        return "Files changed: (tracking not yet connected to tool results)"

    def final_report(self) -> str:
        """Generate a final completion report."""
        lines = [
            "═" * 60,
            "  TASK COMPLETE" if self.failed == 0 else "  TASK FINISHED WITH ERRORS",
            "═" * 60,
            "",
            f"  Steps completed: {self.completed}/{self.total}",
            f"  Steps failed:    {self.failed}",
            f"  Total time:      {self.elapsed:.1f}s",
            "",
        ]

        if self._records:
            lines.append("  Step details:")
            for r in self._records:
                icon = "✓" if r.status == SessionStatus.COMPLETED else "✗"
                dur = f"{r.duration_ms:.0f}ms" if r.duration_ms else "—"
                lines.append(f"    {icon} [{dur}] {r.description}")
                if r.error:
                    lines.append(f"      Error: {r.error[:100]}")

        lines.append("")
        lines.append("═" * 60)
        return "\n".join(lines)


class ProgressBar:
    """Renders a progress bar to a terminal stream.

    Supports both interactive (overwrite-in-place) and log-style output.
    """

    def __init__(
        self,
        stream: TextIO | None = None,
        width: int = 40,
        interactive: bool = True,
    ) -> None:
        self._stream = stream or sys.stderr
        self._width = width
        self._interactive = interactive
        self._last_line_len = 0

    def render(self, tracker: ProgressTracker) -> None:
        """Render the current progress."""
        if self._interactive:
            self._render_interactive(tracker)
        else:
            self._render_log(tracker)

    def _render_interactive(self, tracker: ProgressTracker) -> None:
        """Overwrite-in-place progress bar."""
        pct = tracker.percent
        filled = int(self._width * pct / 100)
        bar = "█" * filled + "░" * (self._width - filled)

        line = f"\r  [{bar}] {pct:5.1f}%  {tracker.completed}/{tracker.total} steps"
        self._stream.write(line + " " * max(0, self._last_line_len - len(line)))
        self._stream.flush()
        self._last_line_len = len(line)

    def _render_log(self, tracker: ProgressTracker) -> None:
        """Log-style one-line progress."""
        pct = tracker.percent
        filled = int(self._width * pct / 100)
        bar = "█" * filled + "░" * (self._width - filled)
        self._stream.write(f"  [{bar}] {pct:5.1f}%  {tracker.completed}/{tracker.total}\n")
        self._stream.flush()

    def finish(self, tracker: ProgressTracker) -> None:
        """Final render and newline."""
        if self._interactive:
            self._render_interactive(tracker)
            self._stream.write("\n")
            self._stream.flush()
