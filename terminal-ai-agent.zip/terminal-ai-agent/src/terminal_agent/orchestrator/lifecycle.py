"""Lifecycle manager — session lifecycle events and hooks.

Provides a pub/sub event system for lifecycle events, allowing
other modules to react to session state changes.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

logger = logging.getLogger(__name__)


class LifecycleEvent(str, Enum):
    """Lifecycle events emitted during session execution."""
    SESSION_CREATED = "session_created"
    SESSION_STARTED = "session_started"
    SESSION_PAUSED = "session_paused"
    SESSION_RESUMED = "session_resumed"
    SESSION_COMPLETED = "session_completed"
    SESSION_FAILED = "session_failed"
    SESSION_CANCELLED = "session_cancelled"
    SESSION_TIMED_OUT = "session_timed_out"

    PLAN_GENERATED = "plan_generated"
    PLAN_UPDATED = "plan_updated"

    STEP_STARTED = "step_started"
    STEP_COMPLETED = "step_completed"
    STEP_FAILED = "step_failed"
    STEP_SKIPPED = "step_skipped"

    TOOL_CALLED = "tool_called"
    TOOL_SUCCEEDED = "tool_succeeded"
    TOOL_FAILED = "tool_failed"

    LLM_CALLED = "llm_called"
    LLM_RESPONDED = "llm_responded"

    VERIFICATION_PASSED = "verification_passed"
    VERIFICATION_FAILED = "verification_failed"

    ERROR_RECOVERY_STARTED = "error_recovery_started"
    ERROR_RECOVERY_SUCCEEDED = "error_recovery_succeeded"
    ERROR_RECOVERY_FAILED = "error_recovery_failed"

    COST_WARNING = "cost_warning"
    ITERATION_WARNING = "iteration_warning"

    GOAL_ACHIEVED = "goal_achieved"
    GOAL_FAILED = "goal_failed"


@dataclass
class LifecycleEventData:
    """Payload for a lifecycle event."""
    event: LifecycleEvent
    timestamp: float = field(default_factory=time.time)
    session_id: str = ""
    data: dict[str, Any] = field(default_factory=dict)


# Type alias for event handlers
EventHandler = Callable[[LifecycleEventData], None]


class LifecycleManager:
    """Pub/sub event system for session lifecycle events.

    Other modules register handlers for specific events.  When an
    event fires, all registered handlers are called synchronously
    (in registration order).
    """

    def __init__(self) -> None:
        self._handlers: dict[LifecycleEvent, list[EventHandler]] = {}
        self._global_handlers: list[EventHandler] = []
        self._history: list[LifecycleEventData] = []
        self._max_history = 500

    def on(
        self,
        event: LifecycleEvent,
        handler: EventHandler,
    ) -> None:
        """Register a handler for a specific event.

        Args:
            event: The event to listen for.
            handler: Callable to invoke when the event fires.
        """
        self._handlers.setdefault(event, []).append(handler)
        logger.debug("Registered handler for %s", event.value)

    def on_any(self, handler: EventHandler) -> None:
        """Register a handler that receives ALL events.

        Args:
            handler: Callable to invoke for every event.
        """
        self._global_handlers.append(handler)

    def off(
        self,
        event: LifecycleEvent,
        handler: EventHandler,
    ) -> None:
        """Unregister a handler for a specific event."""
        handlers = self._handlers.get(event, [])
        if handler in handlers:
            handlers.remove(handler)

    def emit(
        self,
        event: LifecycleEvent,
        session_id: str = "",
        data: dict[str, Any] | None = None,
    ) -> None:
        """Emit a lifecycle event.

        All registered handlers for the event (and global handlers)
        are called synchronously.

        Args:
            event: The event type.
            session_id: The session this event relates to.
            data: Arbitrary event payload.
        """
        event_data = LifecycleEventData(
            event=event,
            timestamp=time.time(),
            session_id=session_id,
            data=data or {},
        )

        # Store in history
        self._history.append(event_data)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

        logger.debug(
            "Lifecycle event: %s (session=%s)",
            event.value, session_id or "—",
        )

        # Call specific handlers
        for handler in self._handlers.get(event, []):
            try:
                handler(event_data)
            except Exception:
                logger.exception(
                    "Handler error for event %s", event.value,
                )

        # Call global handlers
        for handler in self._global_handlers:
            try:
                handler(event_data)
            except Exception:
                logger.exception(
                    "Global handler error for event %s", event.value,
                )

    def get_history(
        self,
        event: LifecycleEvent | None = None,
        session_id: str | None = None,
        limit: int = 50,
    ) -> list[LifecycleEventData]:
        """Query event history.

        Args:
            event: Filter by event type (None = all).
            session_id: Filter by session ID (None = all).
            limit: Maximum events to return.

        Returns:
            Matching events in reverse chronological order.
        """
        results = self._history
        if event is not None:
            results = [e for e in results if e.event == event]
        if session_id is not None:
            results = [e for e in results if e.session_id == session_id]
        return list(reversed(results[-limit:]))

    def clear_history(self) -> None:
        """Clear event history."""
        self._history.clear()

    def handler_count(self, event: LifecycleEvent | None = None) -> int:
        """Count registered handlers."""
        if event is not None:
            return len(self._handlers.get(event, []))
        total = len(self._global_handlers)
        for handlers in self._handlers.values():
            total += len(handlers)
        return total
