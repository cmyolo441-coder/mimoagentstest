"""Step executor — runs individual plan steps via the tool dispatcher.

Translates a PlanStep into tool calls, invokes them, captures results,
and performs basic verification before returning.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Protocol

from terminal_agent.exceptions import ExecutionError, ToolExecutionError
from terminal_agent.types import (
    LLMResponse,
    PlanStep,
    SessionStatus,
    ToolCall,
    ToolResult,
    ToolResultStatus,
)

logger = logging.getLogger(__name__)


class ToolDispatcher(Protocol):
    """Minimal interface for tool dispatching."""

    async def dispatch(self, tool_call: ToolCall) -> ToolResult:
        """Execute a tool call and return the result."""
        ...


class LLMEngine(Protocol):
    """Minimal interface for the LLM engine."""

    async def generate(self, prompt: str, **kwargs: Any) -> LLMResponse:
        """Generate a response from the LLM."""
        ...


class StepExecutor:
    """Executes individual plan steps.

    Each step goes through:
      1.  Determine the tool call (via LLM or direct mapping).
      2.  Execute the tool call.
      3.  Capture and verify the result.
      4.  Return a structured result.
    """

    def __init__(
        self,
        tool_dispatcher: ToolDispatcher,
        llm_engine: LLMEngine | None = None,
        max_retries: int = 2,
        step_timeout: float = 300.0,
    ) -> None:
        self._dispatcher = tool_dispatcher
        self._llm = llm_engine
        self._max_retries = max_retries
        self._step_timeout = step_timeout

    async def execute(self, step: PlanStep, context: str = "") -> ToolResult:
        """Execute a single plan step.

        Args:
            step: The plan step to execute.
            context: Additional context for the LLM (file contents, etc.).

        Returns:
            A ToolResult with the outcome.

        Raises:
            ExecutionError: If execution fails after all retries.
        """
        logger.info("Executing step %s: %s", step.id, step.description)
        step.status = SessionStatus.RUNNING
        start_time = time.monotonic()

        last_error: str | None = None
        for attempt in range(1, self._max_retries + 1):
            try:
                # Determine the tool call
                tool_call = await self._determine_tool_call(step, context, last_error)

                # Execute
                result = await self._execute_tool_call(tool_call)

                elapsed = (time.monotonic() - start_time) * 1000
                result.duration_ms = elapsed

                if result.status in (ToolResultStatus.SUCCESS, ToolResultStatus.PARTIAL):
                    step.status = SessionStatus.COMPLETED
                    step.result = result
                    logger.info(
                        "Step %s completed (attempt %d, %.0fms)",
                        step.id, attempt, elapsed,
                    )
                    return result

                # Failure — capture error for retry
                last_error = result.error or result.output
                logger.warning(
                    "Step %s attempt %d failed: %s",
                    step.id, attempt, last_error[:200],
                )

            except Exception as exc:
                last_error = str(exc)
                logger.warning(
                    "Step %s attempt %d exception: %s",
                    step.id, attempt, last_error[:200],
                )

        # All retries exhausted
        step.status = SessionStatus.FAILED
        step.error = last_error
        elapsed = (time.monotonic() - start_time) * 1000
        raise ExecutionError(
            f"Step '{step.id}' failed after {self._max_retries} attempts: {last_error}",
            details={"step_id": step.id, "elapsed_ms": elapsed},
        )

    async def determine_tool_call(
        self, step: PlanStep, context: str = "",
    ) -> ToolCall:
        """Public interface to determine the tool call for a step."""
        return await self._determine_tool_call(step, context)

    # ── Private helpers ────────────────────────────────────────────────

    async def _determine_tool_call(
        self,
        step: PlanStep,
        context: str = "",
        previous_error: str | None = None,
    ) -> ToolCall:
        """Determine what tool call to make for a step.

        Uses the step's tool_hint if available, otherwise asks the LLM.
        """
        # If the step has a direct tool hint, use it
        if step.tool_hint:
            return ToolCall(
                name=step.tool_hint,
                parameters={"description": step.description},
            )

        # Use LLM to determine the tool call
        if self._llm is not None:
            return await self._llm_determine_tool(step, context, previous_error)

        # Fallback: generic execute tool
        return ToolCall(
            name="shell.execute",
            parameters={"command": step.description},
        )

    async def _llm_determine_tool(
        self,
        step: PlanStep,
        context: str,
        previous_error: str | None,
    ) -> ToolCall:
        """Ask the LLM to select the right tool for a step."""
        parts = [
            "You are a tool-selection engine. Given a step description,",
            "choose the best tool and provide its parameters.",
            "",
            f"STEP: {step.description}",
        ]
        if context:
            parts.append(f"CONTEXT:\n{context}")
        if previous_error:
            parts.append(f"PREVIOUS ERROR: {previous_error}")
            parts.append("Try a different approach this time.")
        parts.extend([
            "",
            "Respond in JSON format:",
            '{"tool": "<tool_name>", "parameters": {<params>}}',
        ])

        response = await self._llm.generate("\n".join(parts))  # type: ignore[union-attr]
        return self._parse_tool_call_response(response.content)

    @staticmethod
    def _parse_tool_call_response(content: str) -> ToolCall:
        """Parse an LLM response into a ToolCall."""
        import json

        # Try to extract JSON from the response
        content = content.strip()
        # Find JSON block
        start = content.find("{")
        end = content.rfind("}") + 1
        if start >= 0 and end > start:
            try:
                data = json.loads(content[start:end])
                return ToolCall(
                    name=data.get("tool", "shell.execute"),
                    parameters=data.get("parameters", {}),
                )
            except json.JSONDecodeError:
                pass

        # Fallback: treat entire content as a shell command
        return ToolCall(
            name="shell.execute",
            parameters={"command": content},
        )

    async def _execute_tool_call(self, tool_call: ToolCall) -> ToolResult:
        """Execute a tool call via the dispatcher with timeout."""
        import asyncio

        try:
            result = await asyncio.wait_for(
                self._dispatcher.dispatch(tool_call),
                timeout=self._step_timeout,
            )
            return result
        except asyncio.TimeoutError:
            return ToolResult(
                status=ToolResultStatus.TIMEOUT,
                error=f"Tool call timed out after {self._step_timeout}s",
            )
        except Exception as exc:
            return ToolResult(
                status=ToolResultStatus.ERROR,
                error=str(exc),
            )
