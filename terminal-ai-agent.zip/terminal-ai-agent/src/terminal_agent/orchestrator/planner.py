"""Planner — generates multi-step plans from parsed goals.

Uses LLM-assisted planning when available, with a deterministic
fallback that produces reasonable plans from goal structure alone.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Protocol

from terminal_agent.exceptions import PlanningError
from terminal_agent.orchestrator.goal_parser import GoalType, ParsedGoal
from terminal_agent.types import GoalComplexity, Plan, PlanStep, SessionStatus

logger = logging.getLogger(__name__)


class LLMProvider(Protocol):
    """Minimal interface the planner needs from the LLM engine."""

    async def generate(self, prompt: str, **kwargs: Any) -> str:
        """Send a prompt and return the text response."""
        ...


# ── Default plan templates keyed by goal type ──────────────────────────

_TEMPLATES: dict[GoalType, list[str]] = {
    GoalType.FILE_OPERATION: [
        "Read and understand the target file(s)",
        "Perform the requested file operation",
        "Verify the file changes are correct",
    ],
    GoalType.CODE_GENERATION: [
        "Analyze requirements and existing code structure",
        "Generate the code implementation",
        "Write the code to the target file(s)",
        "Verify syntax and basic correctness",
    ],
    GoalType.CODE_MODIFICATION: [
        "Read and understand the existing code",
        "Identify the specific changes needed",
        "Apply the modifications",
        "Verify the changes compile/parse correctly",
        "Run relevant tests if available",
    ],
    GoalType.DEBUGGING: [
        "Reproduce and understand the error",
        "Analyze root cause",
        "Implement the fix",
        "Verify the fix resolves the issue",
        "Run tests to check for regressions",
    ],
    GoalType.TESTING: [
        "Analyze the code to be tested",
        "Generate or locate test files",
        "Run the test suite",
        "Analyze results and fix any failures",
    ],
    GoalType.GIT_OPERATION: [
        "Check current repository state",
        "Perform the git operation",
        "Verify the operation succeeded",
    ],
    GoalType.PACKAGE_MANAGEMENT: [
        "Detect package manager and current state",
        "Execute the package operation",
        "Verify installation/update succeeded",
    ],
    GoalType.DATABASE_OPERATION: [
        "Connect to the database",
        "Execute the database operation",
        "Verify the results",
    ],
    GoalType.DOCKER_OPERATION: [
        "Check Docker state and configuration",
        "Execute the Docker operation",
        "Verify the result",
    ],
    GoalType.DEPLOYMENT: [
        "Verify prerequisites and credentials",
        "Build/prepare artifacts",
        "Execute deployment steps",
        "Verify deployment health",
        "Run smoke tests",
    ],
    GoalType.DOCUMENTATION: [
        "Analyze the target code/project",
        "Generate documentation content",
        "Write documentation to appropriate files",
        "Verify documentation accuracy",
    ],
    GoalType.REFACTORING: [
        "Analyze current code structure",
        "Plan the refactoring approach",
        "Apply refactoring changes",
        "Verify code still compiles/parses",
        "Run tests to ensure no regressions",
    ],
    GoalType.PROJECT_SETUP: [
        "Create project directory structure",
        "Generate configuration files",
        "Install base dependencies",
        "Initialize version control",
        "Verify project setup works",
    ],
    GoalType.SEARCH: [
        "Define search criteria",
        "Execute search across codebase",
        "Report findings",
    ],
    GoalType.ANALYSIS: [
        "Gather relevant information",
        "Perform the analysis",
        "Report findings and recommendations",
    ],
    GoalType.MULTI_STEP: [
        "Analyze the overall goal and break it down",
        "Execute sub-task 1",
        "Execute sub-task 2",
        "Verify overall completion",
    ],
    GoalType.UNKNOWN: [
        "Analyze the goal and determine approach",
        "Execute the primary action",
        "Verify the result",
    ],
}


class Planner:
    """Generates multi-step plans from parsed goals.

    Can operate in two modes:
      - **LLM-assisted**: sends the goal to the LLM for plan generation.
      - **Template-based** (fallback): uses pre-defined templates per goal type.
    """

    def __init__(self, llm: LLMProvider | None = None) -> None:
        self._llm = llm

    async def generate_plan(
        self,
        parsed_goal: ParsedGoal,
        context: str = "",
    ) -> Plan:
        """Generate a plan for the given goal.

        Args:
            parsed_goal: The parsed goal from GoalParser.
            context: Optional context (project info, memory, etc.).

        Returns:
            A Plan with ordered steps.

        Raises:
            PlanningError: If plan generation fails.
        """
        plan = Plan(
            goal=parsed_goal.raw_text,
            complexity=parsed_goal.complexity,
            created_at=time.time(),
            updated_at=time.time(),
        )

        try:
            if self._llm is not None:
                steps = await self._llm_plan(parsed_goal, context)
            else:
                steps = self._template_plan(parsed_goal)

            plan.steps = steps
            plan.estimated_steps = len(steps)
            logger.info(
                "Generated plan with %d steps (complexity=%s)",
                len(steps), parsed_goal.complexity.value,
            )
        except Exception as exc:
            raise PlanningError(
                f"Failed to generate plan: {exc}",
                details={"goal": parsed_goal.raw_text},
            ) from exc

        return plan

    async def regenerate_plan(
        self,
        original_plan: Plan,
        completed_steps: list[str],
        failed_step: str | None,
        error_info: str = "",
        context: str = "",
    ) -> Plan:
        """Re-generate a plan after a failure or new information.

        Args:
            original_plan: The original plan.
            completed_steps: IDs of steps already completed.
            failed_step: ID of the step that failed (if any).
            error_info: Error details for the failed step.
            context: Additional context for the LLM.

        Returns:
            A new Plan incorporating the current state.
        """
        # If LLM available, ask it to re-plan
        if self._llm is not None:
            return await self._llm_replan(
                original_plan, completed_steps, failed_step, error_info, context,
            )

        # Template fallback: keep completed steps, retry or skip failed
        new_steps: list[PlanStep] = []
        for step in original_plan.steps:
            if step.id in completed_steps:
                new_steps.append(PlanStep(
                    id=step.id,
                    description=step.description,
                    dependencies=step.dependencies,
                    status=SessionStatus.COMPLETED,
                ))
            elif step.id == failed_step:
                # Add a retry step
                new_steps.append(PlanStep(
                    id=f"{step.id}_retry",
                    description=f"Retry: {step.description}",
                    dependencies=step.dependencies,
                    status=SessionStatus.PENDING,
                ))
            else:
                new_steps.append(PlanStep(
                    id=step.id,
                    description=step.description,
                    dependencies=step.dependencies,
                    status=SessionStatus.PENDING,
                ))

        plan = Plan(
            goal=original_plan.goal,
            steps=new_steps,
            complexity=original_plan.complexity,
            estimated_steps=len(new_steps),
            created_at=original_plan.created_at,
            updated_at=time.time(),
        )
        return plan

    # ── Private helpers ────────────────────────────────────────────────

    def _template_plan(self, parsed_goal: ParsedGoal) -> list[PlanStep]:
        """Build a plan from templates."""
        templates = _TEMPLATES.get(parsed_goal.goal_type, _TEMPLATES[GoalType.UNKNOWN])

        # If the goal has explicit sub-goals, use those instead
        if parsed_goal.sub_goals:
            templates = parsed_goal.sub_goals

        steps: list[PlanStep] = []
        for i, desc in enumerate(templates):
            step_id = f"step_{i + 1}"
            deps: list[str] = []
            if i > 0:
                deps = [f"step_{i}"]

            steps.append(PlanStep(
                id=step_id,
                description=desc,
                dependencies=deps,
                status=SessionStatus.PENDING,
            ))

        return steps

    async def _llm_plan(
        self, parsed_goal: ParsedGoal, context: str,
    ) -> list[PlanStep]:
        """Use the LLM to generate a detailed plan."""
        prompt = self._build_planning_prompt(parsed_goal, context)
        response = await self._llm.generate(prompt)  # type: ignore[union-attr]
        return self._parse_plan_response(response)

    async def _llm_replan(
        self,
        original: Plan,
        completed: list[str],
        failed: str | None,
        error: str,
        context: str,
    ) -> Plan:
        """Use the LLM to re-plan after failure."""
        prompt = self._build_replanning_prompt(original, completed, failed, error, context)
        response = await self._llm.generate(prompt)  # type: ignore[union-attr]
        steps = self._parse_plan_response(response)

        # Prepend completed steps
        completed_steps = [
            s for s in original.steps if s.id in completed
        ]
        all_steps = completed_steps + steps

        return Plan(
            goal=original.goal,
            steps=all_steps,
            complexity=original.complexity,
            estimated_steps=len(all_steps),
            created_at=original.created_at,
            updated_at=time.time(),
        )

    @staticmethod
    def _build_planning_prompt(parsed_goal: ParsedGoal, context: str) -> str:
        """Construct the LLM prompt for plan generation."""
        parts = [
            "You are a planning engine for an autonomous terminal agent.",
            "Given the following goal, produce a step-by-step plan.",
            "Each step should be atomic and achievable with a single tool call.",
            "",
            f"GOAL: {parsed_goal.raw_text}",
            f"TYPE: {parsed_goal.goal_type.value}",
            f"COMPLEXITY: {parsed_goal.complexity.value}",
        ]
        if parsed_goal.constraints:
            parts.append(f"CONSTRAINTS: {'; '.join(parsed_goal.constraints)}")
        if context:
            parts.append(f"\nCONTEXT:\n{context}")
        parts.extend([
            "",
            "Respond with one step per line in the format:",
            "STEP: <description>",
            "DEPENDS_ON: <step numbers, comma-separated, or 'none'>",
        ])
        return "\n".join(parts)

    @staticmethod
    def _build_replanning_prompt(
        original: Plan,
        completed: list[str],
        failed: str | None,
        error: str,
        context: str,
    ) -> str:
        """Construct the LLM prompt for re-planning."""
        parts = [
            "You are a re-planning engine. A previous plan partially failed.",
            "Generate new steps to achieve the remaining goal.",
            "",
            f"ORIGINAL GOAL: {original.goal}",
            f"COMPLETED STEPS: {', '.join(completed) if completed else 'none'}",
        ]
        if failed:
            parts.append(f"FAILED STEP: {failed}")
            parts.append(f"ERROR: {error}")
        if context:
            parts.append(f"\nCONTEXT:\n{context}")
        parts.extend([
            "",
            "Respond with NEW steps only (do not repeat completed steps).",
            "Format: STEP: <description>",
        ])
        return "\n".join(parts)

    @staticmethod
    def _parse_plan_response(response: str) -> list[PlanStep]:
        """Parse an LLM response into PlanStep objects."""
        steps: list[PlanStep] = []
        current_desc = ""
        current_deps: list[str] = []

        for line in response.strip().splitlines():
            line = line.strip()
            if line.upper().startswith("STEP:"):
                if current_desc:
                    step_id = f"step_{len(steps) + 1}"
                    # Map numeric deps to step IDs
                    resolved_deps = []
                    for d in current_deps:
                        if d.isdigit():
                            resolved_deps.append(f"step_{d}")
                        else:
                            resolved_deps.append(d)
                    steps.append(PlanStep(
                        id=step_id,
                        description=current_desc,
                        dependencies=resolved_deps,
                        status=SessionStatus.PENDING,
                    ))
                current_desc = line.split(":", 1)[1].strip()
                current_deps = []
            elif line.upper().startswith("DEPENDS_ON:"):
                dep_str = line.split(":", 1)[1].strip()
                if dep_str.lower() != "none":
                    current_deps = [d.strip() for d in dep_str.split(",")]

        # Flush last step
        if current_desc:
            step_id = f"step_{len(steps) + 1}"
            resolved_deps = []
            for d in current_deps:
                if d.isdigit():
                    resolved_deps.append(f"step_{d}")
                else:
                    resolved_deps.append(d)
            steps.append(PlanStep(
                id=step_id,
                description=current_desc,
                dependencies=resolved_deps,
                status=SessionStatus.PENDING,
            ))

        return steps
