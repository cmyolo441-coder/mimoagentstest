"""Termination conditions — decides when the agent loop should stop.

Evaluates multiple termination signals (goal achieved, max iterations,
cost budget, unrecoverable errors, user interrupt) and reports the
reason for stopping.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any

from terminal_agent.constants import (
    DEFAULT_COST_WARNING_THRESHOLD,
    DEFAULT_MAX_COST_PER_TASK,
    DEFAULT_MAX_ITERATIONS,
)
from terminal_agent.types import Plan, SessionStatus

logger = logging.getLogger(__name__)


class TerminationReason(str, Enum):
    """Why the agent loop terminated."""
    GOAL_ACHIEVED = "goal_achieved"
    MAX_ITERATIONS = "max_iterations"
    COST_LIMIT = "cost_limit"
    UNRECOVERABLE_ERROR = "unrecoverable_error"
    USER_INTERRUPT = "user_interrupt"
    PLAN_COMPLETE = "plan_complete"
    ALL_STEPS_FAILED = "all_steps_failed"
    TIMEOUT = "timeout"
    NOT_TERMINATED = "not_terminated"


@dataclass
class TerminationDecision:
    """Result of a termination check."""
    should_stop: bool
    reason: TerminationReason
    message: str = ""
    details: dict[str, Any] | None = None


class TerminationChecker:
    """Evaluates termination conditions on each loop iteration.

    The checker is called at the end of every agent-loop iteration.
    It evaluates conditions in priority order and returns a decision.
    """

    def __init__(
        self,
        max_iterations: int = DEFAULT_MAX_ITERATIONS,
        max_cost: float = DEFAULT_MAX_COST_PER_TASK,
        cost_warning_threshold: float = DEFAULT_COST_WARNING_THRESHOLD,
        max_time_seconds: float = 0.0,
        user_interrupt: bool = False,
    ) -> None:
        """
        Args:
            max_iterations: Maximum loop iterations before forced stop.
            max_cost: Maximum cumulative cost in dollars.
            cost_warning_threshold: Fraction of max_cost to trigger warning.
            max_time_seconds: Maximum wall-clock time (0 = unlimited).
            user_interrupt: Flag set externally when user requests stop.
        """
        self._max_iterations = max_iterations
        self._max_cost = max_cost
        self._cost_warning = cost_warning_threshold
        self._max_time = max_time_seconds
        self._user_interrupt = user_interrupt

        self._start_time: float = 0.0
        self._iteration: int = 0
        self._cumulative_cost: float = 0.0
        self._cost_warned: bool = False

    def start(self) -> None:
        """Reset and start timing."""
        self._start_time = time.monotonic()
        self._iteration = 0
        self._cumulative_cost = 0.0
        self._cost_warned = False

    def increment_iteration(self) -> None:
        """Bump the iteration counter."""
        self._iteration += 1

    def add_cost(self, cost: float) -> None:
        """Add to the cumulative cost."""
        self._cumulative_cost += cost

    def set_user_interrupt(self) -> None:
        """Flag a user-initiated interrupt."""
        self._user_interrupt = True

    def check(
        self,
        plan: Plan | None = None,
        last_error: str | None = None,
    ) -> TerminationDecision:
        """Check all termination conditions.

        Args:
            plan: The current plan (to check step statuses).
            last_error: The most recent error message (if any).

        Returns:
            A TerminationDecision indicating whether to stop and why.
        """
        # Priority 1: User interrupt
        if self._user_interrupt:
            return TerminationDecision(
                should_stop=True,
                reason=TerminationReason.USER_INTERRUPT,
                message="Stopped by user request.",
            )

        # Priority 2: Max iterations
        if self._iteration >= self._max_iterations:
            return TerminationDecision(
                should_stop=True,
                reason=TerminationReason.MAX_ITERATIONS,
                message=(
                    f"Reached maximum iterations ({self._max_iterations})."
                ),
                details={"iterations": self._iteration},
            )

        # Priority 3: Cost limit
        if self._max_cost > 0 and self._cumulative_cost >= self._max_cost:
            return TerminationDecision(
                should_stop=True,
                reason=TerminationReason.COST_LIMIT,
                message=(
                    f"Reached cost limit (${self._cumulative_cost:.2f} >= "
                    f"${self._max_cost:.2f})."
                ),
                details={"cost": self._cumulative_cost, "limit": self._max_cost},
            )

        # Priority 4: Time limit
        if self._max_time > 0:
            elapsed = time.monotonic() - self._start_time
            if elapsed >= self._max_time:
                return TerminationDecision(
                    should_stop=True,
                    reason=TerminationReason.TIMEOUT,
                    message=f"Reached time limit ({elapsed:.0f}s >= {self._max_time:.0f}s).",
                    details={"elapsed": elapsed},
                )

        # Priority 5: Plan completion
        if plan is not None:
            all_terminal = all(
                s.status in (SessionStatus.COMPLETED, SessionStatus.FAILED)
                for s in plan.steps
            )
            if all_terminal and plan.steps:
                all_failed = all(
                    s.status == SessionStatus.FAILED for s in plan.steps
                )
                if all_failed:
                    return TerminationDecision(
                        should_stop=True,
                        reason=TerminationReason.ALL_STEPS_FAILED,
                        message="All plan steps failed.",
                    )
                return TerminationDecision(
                    should_stop=True,
                    reason=TerminationReason.PLAN_COMPLETE,
                    message="All plan steps completed.",
                )

        # Non-blocking: Cost warning
        if (
            self._max_cost > 0
            and not self._cost_warned
            and self._cumulative_cost >= self._max_cost * self._cost_warning
        ):
            self._cost_warned = True
            logger.warning(
                "Cost warning: $%.2f of $%.2f budget used (%.0f%%)",
                self._cumulative_cost, self._max_cost,
                self._cumulative_cost / self._max_cost * 100,
            )

        # No termination
        return TerminationDecision(
            should_stop=False,
            reason=TerminationReason.NOT_TERMINATED,
        )

    @property
    def iteration(self) -> int:
        return self._iteration

    @property
    def cumulative_cost(self) -> float:
        return self._cumulative_cost

    @property
    def elapsed(self) -> float:
        return time.monotonic() - self._start_time if self._start_time else 0.0
