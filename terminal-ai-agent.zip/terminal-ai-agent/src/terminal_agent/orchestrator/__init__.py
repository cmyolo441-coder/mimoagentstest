"""Orchestrator module — plans, executes, and monitors the agent loop.

This is the brain of the Terminal Agent. It coordinates all other modules
to achieve user goals through the Think-Act-Observe-Verify paradigm.
"""

from __future__ import annotations

from terminal_agent.orchestrator.core import AgentLoop
from terminal_agent.orchestrator.goal_parser import GoalParser
from terminal_agent.orchestrator.planner import Planner
from terminal_agent.orchestrator.executor import StepExecutor
from terminal_agent.orchestrator.parallel_executor import ParallelExecutor
from terminal_agent.orchestrator.monitor import ProgressMonitor
from terminal_agent.orchestrator.re_planner import RePlanner
from terminal_agent.orchestrator.progress import ProgressTracker, ProgressBar
from terminal_agent.orchestrator.session_manager import SessionManager
from terminal_agent.orchestrator.dependency_resolver import DependencyResolver
from terminal_agent.orchestrator.termination import TerminationChecker, TerminationReason
from terminal_agent.orchestrator.lifecycle import LifecycleManager, LifecycleEvent

__all__ = [
    "AgentLoop",
    "GoalParser",
    "Planner",
    "StepExecutor",
    "ParallelExecutor",
    "ProgressMonitor",
    "RePlanner",
    "ProgressTracker",
    "ProgressBar",
    "SessionManager",
    "DependencyResolver",
    "TerminationChecker",
    "TerminationReason",
    "LifecycleManager",
    "LifecycleEvent",
]
