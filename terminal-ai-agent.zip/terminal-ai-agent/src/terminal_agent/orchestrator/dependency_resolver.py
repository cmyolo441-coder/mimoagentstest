"""Dependency resolver — topological ordering of plan steps.

Resolves inter-step dependencies, detects cycles, and produces
an execution order that respects prerequisites while maximising
opportunities for parallelism.
"""

from __future__ import annotations

import logging
from collections import defaultdict, deque
from dataclasses import dataclass, field

from terminal_agent.types import PlanStep

logger = logging.getLogger(__name__)


class CyclicDependencyError(Exception):
    """Raised when a dependency cycle is detected among plan steps."""

    def __init__(self, cycle: list[str]):
        self.cycle = cycle
        super().__init__(f"Dependency cycle detected: {' → '.join(cycle)}")


@dataclass
class ExecutionLayer:
    """A group of steps that can execute in parallel."""
    level: int
    step_ids: list[str] = field(default_factory=list)


@dataclass
class ResolutionResult:
    """Result of dependency resolution."""
    ordered_steps: list[str]  # Topological order
    layers: list[ExecutionLayer]  # Parallel-execution layers
    adjacency: dict[str, list[str]]  # step_id → dependents
    has_cycles: bool = False


class DependencyResolver:
    """Resolves step dependencies and produces an optimal execution order.

    Given a list of PlanStep objects with their dependency lists, this
    resolver:
      1.  Builds a directed graph (step → its dependents).
      2.  Detects cycles via DFS.
      3.  Produces a topological ordering.
      4.  Groups steps into parallel-execution layers (steps in the same
          layer have no mutual dependencies).
    """

    def resolve(self, steps: list[PlanStep]) -> ResolutionResult:
        """Resolve dependencies for a list of plan steps.

        Args:
            steps: The plan steps with dependency lists populated.

        Returns:
            A ResolutionResult with ordering, layers, and adjacency info.

        Raises:
            CyclicDependencyError: If a dependency cycle exists.
        """
        if not steps:
            return ResolutionResult(ordered_steps=[], layers=[], adjacency={})

        step_map = {s.id: s for s in steps}
        all_ids = set(step_map)

        # Build adjacency: parent → list of dependents (children)
        adjacency: dict[str, list[str]] = defaultdict(list)
        in_degree: dict[str, int] = {s.id: 0 for s in steps}

        for step in steps:
            for dep in step.dependencies:
                if dep not in all_ids:
                    logger.warning(
                        "Step %s depends on unknown step %s — skipping",
                        step.id, dep,
                    )
                    continue
                adjacency[dep].append(step.id)
                in_degree[step.id] += 1

        # ── Cycle detection (DFS) ──────────────────────────────────────
        cycle = self._detect_cycle(steps, adjacency)
        if cycle:
            raise CyclicDependencyError(cycle)

        # ── Topological sort (Kahn's algorithm) ───────────────────────
        ordered = self._topological_sort(steps, adjacency, in_degree)

        # ── Layer assignment for parallelism ───────────────────────────
        layers = self._assign_layers(steps, adjacency, in_degree)

        return ResolutionResult(
            ordered_steps=ordered,
            layers=layers,
            adjacency=dict(adjacency),
        )

    # ── Private helpers ────────────────────────────────────────────────

    def _detect_cycle(
        self,
        steps: list[PlanStep],
        adjacency: dict[str, list[str]],
    ) -> list[str] | None:
        """Detect a cycle using DFS. Returns the cycle path or None."""
        WHITE, GRAY, BLACK = 0, 1, 2
        color: dict[str, int] = {s.id: WHITE for s in steps}
        parent: dict[str, str | None] = {s.id: None for s in steps}

        def dfs(node: str) -> list[str] | None:
            color[node] = GRAY
            for neighbour in adjacency.get(node, []):
                if color.get(neighbour) is not None:
                    if color[neighbour] == GRAY:
                        # Back edge — reconstruct cycle
                        cycle = [neighbour, node]
                        cur = node
                        while cur != neighbour:
                            cur = parent[cur]  # type: ignore[assignment]
                            cycle.append(cur)
                        cycle.reverse()
                        return cycle
                if color[neighbour] == WHITE:
                    parent[neighbour] = node
                    result = dfs(neighbour)
                    if result:
                        return result
            color[node] = BLACK
            return None

        for step in steps:
            if color[step.id] == WHITE:
                result = dfs(step.id)
                if result:
                    return result
        return None

    def _topological_sort(
        self,
        steps: list[PlanStep],
        adjacency: dict[str, list[str]],
        in_degree: dict[str, int],
    ) -> list[str]:
        """Kahn's algorithm — BFS-based topological sort."""
        queue: deque[str] = deque(
            sid for sid, deg in in_degree.items() if deg == 0
        )
        ordered: list[str] = []

        while queue:
            node = queue.popleft()
            ordered.append(node)
            for child in adjacency.get(node, []):
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    queue.append(child)

        return ordered

    def _assign_layers(
        self,
        steps: list[PlanStep],
        adjacency: dict[str, list[str]],
        in_degree: dict[str, int],
    ) -> list[ExecutionLayer]:
        """Assign steps to layers — steps in the same layer are parallelisable."""
        layer_of: dict[str, int] = {}
        # Start with all zero-in-degree nodes at layer 0
        queue: deque[str] = deque()

        for sid, deg in in_degree.items():
            if deg == 0:
                layer_of[sid] = 0
                queue.append(sid)

        while queue:
            node = queue.popleft()
            for child in adjacency.get(node, []):
                new_layer = layer_of[node] + 1
                layer_of[child] = max(layer_of.get(child, 0), new_layer)
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    queue.append(child)

        # Group by layer
        max_layer = max(layer_of.values(), default=-1)
        layers: list[ExecutionLayer] = []
        for lvl in range(max_layer + 1):
            ids = [sid for sid, l in layer_of.items() if l == lvl]
            layers.append(ExecutionLayer(level=lvl, step_ids=ids))

        return layers

    def get_execution_order(self, steps: list[PlanStep]) -> list[list[str]]:
        """Convenience: return a list of batches, each batch parallelisable.

        Returns:
            A list of lists.  Each inner list is a set of step IDs that
            may run concurrently.  Batches must execute sequentially.
        """
        result = self.resolve(steps)
        return [layer.step_ids for layer in result.layers]

    def can_run_now(self, step_id: str, completed: set[str], steps: list[PlanStep]) -> bool:
        """Check whether a step's dependencies are all satisfied."""
        step_map = {s.id: s for s in steps}
        step = step_map.get(step_id)
        if step is None:
            return False
        return all(dep in completed for dep in step.dependencies)
