"""Terminal Agent — The most powerful terminal-based autonomous AI agent."""

__version__ = "0.1.0"
__author__ = "Terminal Agent Team"
