"""Prompt optimizer — tracks and improves prompt effectiveness.

Collects metrics on prompt performance and suggests or auto-applies
improvements based on success/failure patterns.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PromptMetric:
    """Performance data for a single prompt usage."""
    prompt_name: str
    template_version: int
    timestamp: float = field(default_factory=time.time)
    tokens_used: int = 0
    latency_ms: float = 0.0
    success: bool = True
    error_category: str | None = None
    task_type: str = ""
    notes: str = ""


@dataclass
class PromptVariant:
    """An alternative version of a prompt for A/B testing."""
    name: str
    template: str
    variant_id: str
    created_at: float = field(default_factory=time.time)
    test_count: int = 0
    success_count: int = 0
    total_tokens: int = 0
    avg_latency_ms: float = 0.0

    @property
    def success_rate(self) -> float:
        return (self.success_count / self.test_count * 100) if self.test_count > 0 else 0.0

    @property
    def avg_tokens(self) -> float:
        return (self.total_tokens / self.test_count) if self.test_count > 0 else 0.0


class PromptOptimizer:
    """Tracks prompt effectiveness and manages A/B testing.

    Responsibilities:
      - Record metrics for each prompt usage.
      - Compute effectiveness scores per template.
      - Manage A/B test variants.
      - Suggest improvements based on failure analysis.
    """

    def __init__(self) -> None:
        self._metrics: list[PromptMetric] = []
        self._variants: dict[str, list[PromptVariant]] = {}
        self._max_metrics = 10000

    def record(self, metric: PromptMetric) -> None:
        """Record a prompt usage metric."""
        self._metrics.append(metric)
        if len(self._metrics) > self._max_metrics:
            self._metrics = self._metrics[-self._max_metrics:]

        # Update variant stats if applicable
        for variant in self._variants.get(metric.prompt_name, []):
            variant.test_count += 1
            variant.total_tokens += metric.tokens_used
            if metric.success:
                variant.success_count += 1
            # Running average for latency
            n = variant.test_count
            variant.avg_latency_ms = (
                (variant.avg_latency_ms * (n - 1) + metric.latency_ms) / n
            )

    def get_effectiveness(self, prompt_name: str) -> float:
        """Get the overall effectiveness score for a prompt.

        Returns:
            Score from 0.0 to 1.0.
        """
        relevant = [m for m in self._metrics if m.prompt_name == prompt_name]
        if not relevant:
            return 0.5  # Unknown
        successes = sum(1 for m in relevant if m.success)
        return successes / len(relevant)

    def get_stats(self, prompt_name: str) -> dict[str, Any]:
        """Get detailed stats for a prompt."""
        relevant = [m for m in self._metrics if m.prompt_name == prompt_name]
        if not relevant:
            return {"name": prompt_name, "uses": 0}

        successes = sum(1 for m in relevant if m.success)
        avg_tokens = sum(m.tokens_used for m in relevant) / len(relevant)
        avg_latency = sum(m.latency_ms for m in relevant) / len(relevant)

        # Error breakdown
        errors: dict[str, int] = {}
        for m in relevant:
            if m.error_category:
                errors[m.error_category] = errors.get(m.error_category, 0) + 1

        return {
            "name": prompt_name,
            "uses": len(relevant),
            "success_rate": successes / len(relevant) * 100,
            "avg_tokens": avg_tokens,
            "avg_latency_ms": avg_latency,
            "errors": errors,
        }

    def register_variant(
        self,
        prompt_name: str,
        variant_id: str,
        template: str,
    ) -> PromptVariant:
        """Register a new A/B test variant for a prompt.

        Args:
            prompt_name: The base prompt name.
            variant_id: Unique ID for this variant.
            template: The variant's template text.

        Returns:
            The registered PromptVariant.
        """
        variant = PromptVariant(
            name=prompt_name,
            template=template,
            variant_id=variant_id,
        )
        self._variants.setdefault(prompt_name, []).append(variant)
        logger.info("Registered variant %s for prompt %s", variant_id, prompt_name)
        return variant

    def get_best_variant(self, prompt_name: str) -> PromptVariant | None:
        """Get the best-performing variant for a prompt.

        Returns:
            The variant with the highest success rate, or None.
        """
        variants = self._variants.get(prompt_name, [])
        if not variants:
            return None
        # Require minimum test count
        tested = [v for v in variants if v.test_count >= 10]
        if not tested:
            tested = variants
        return max(tested, key=lambda v: v.success_rate)

    def suggest_improvements(self, prompt_name: str) -> list[str]:
        """Suggest improvements based on failure patterns.

        Returns:
            List of human-readable improvement suggestions.
        """
        suggestions: list[str] = []
        relevant = [m for m in self._metrics if m.prompt_name == prompt_name]
        if len(relevant) < 10:
            return ["Not enough data for suggestions (need ≥10 uses)."]

        success_rate = sum(1 for m in relevant if m.success) / len(relevant)
        if success_rate < 0.5:
            suggestions.append(
                "Success rate is below 50%. Consider rewriting the prompt "
                "with clearer instructions and examples."
            )

        avg_tokens = sum(m.tokens_used for m in relevant) / len(relevant)
        if avg_tokens > 3000:
            suggestions.append(
                f"Average token usage is high ({avg_tokens:.0f}). "
                "Consider making the prompt more concise."
            )

        # Error category analysis
        errors: dict[str, int] = {}
        for m in relevant:
            if m.error_category:
                errors[m.error_category] = errors.get(m.error_category, 0) + 1
        if errors:
            top_error = max(errors, key=errors.get)  # type: ignore[arg-type]
            suggestions.append(
                f"Most common error: '{top_error}' ({errors[top_error]} occurrences). "
                "Consider adding instructions to handle this case."
            )

        if not suggestions:
            suggestions.append("Prompt is performing well. No changes suggested.")

        return suggestions

    def get_report(self) -> str:
        """Generate a full optimisation report."""
        prompt_names = set(m.prompt_name for m in self._metrics)
        if not prompt_names:
            return "No prompt metrics recorded yet."

        lines = ["PROMPT OPTIMIZATION REPORT", "=" * 40]
        for name in sorted(prompt_names):
            stats = self.get_stats(name)
            lines.append(f"\n{name}:")
            lines.append(f"  Uses: {stats['uses']}")
            if stats['uses'] > 0:
                lines.append(f"  Success rate: {stats.get('success_rate', 0):.1f}%")
                lines.append(f"  Avg tokens: {stats.get('avg_tokens', 0):.0f}")
                lines.append(f"  Avg latency: {stats.get('avg_latency_ms', 0):.0f}ms")

            variants = self._variants.get(name, [])
            if variants:
                lines.append(f"  Variants: {len(variants)}")
                for v in variants:
                    lines.append(
                        f"    {v.variant_id}: {v.success_rate:.0f}% "
                        f"({v.test_count} tests)"
                    )

        return "\n".join(lines)
