"""Prompt manager module — template management and prompt construction.

Provides tools for managing prompt templates, constructing prompts
dynamically, optimising prompts, and managing few-shot examples.
"""

from __future__ import annotations

from terminal_agent.prompts.constructor import PromptConstructor
from terminal_agent.prompts.few_shot import FewShotManager
from terminal_agent.prompts.manager import PromptManager
from terminal_agent.prompts.optimizer import PromptOptimizer

__all__ = [
    "PromptManager",
    "PromptConstructor",
    "PromptOptimizer",
    "FewShotManager",
]
