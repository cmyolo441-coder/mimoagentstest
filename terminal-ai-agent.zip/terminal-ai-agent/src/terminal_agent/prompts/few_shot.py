"""Few-shot example manager — manages examples for in-context learning.

Stores, retrieves, and selects few-shot examples to include in prompts
based on task similarity and diversity.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class FewShotExample:
    """A single few-shot example."""
    id: str
    category: str  # e.g. "file_operation", "debugging", "code_generation"
    task: str  # The input/task description
    output: str  # The expected output/response
    tags: list[str] = field(default_factory=list)
    quality_score: float = 1.0  # 0.0 – 1.0
    use_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def format(self, include_output: bool = True) -> str:
        """Format the example for inclusion in a prompt."""
        parts = [f"Task: {self.task}"]
        if include_output:
            parts.append(f"Response: {self.output}")
        return "\n".join(parts)


class FewShotManager:
    """Manages a library of few-shot examples for prompt construction.

    Features:
      - Register examples by category and tags.
      - Select the most relevant examples for a given task.
      - Ensure diversity (don't pick 5 examples from the same category).
      - Track usage and quality for adaptive selection.
    """

    def __init__(self, max_examples_per_prompt: int = 3) -> None:
        self._examples: dict[str, list[FewShotExample]] = {}
        self._all_examples: list[FewShotExample] = []
        self._max_per_prompt = max_examples_per_prompt
        self._register_defaults()

    def register(self, example: FewShotExample) -> None:
        """Register a few-shot example."""
        self._examples.setdefault(example.category, []).append(example)
        self._all_examples.append(example)
        logger.debug(
            "Registered few-shot example %s (category=%s)",
            example.id, example.category,
        )

    def get_examples(
        self,
        category: str | None = None,
        task: str = "",
        max_count: int | None = None,
        min_quality: float = 0.0,
    ) -> list[FewShotExample]:
        """Select relevant few-shot examples.

        Args:
            category: Filter by category (None = any).
            task: The current task (for relevance matching).
            max_count: Maximum examples to return.
            min_quality: Minimum quality score.

        Returns:
            Selected examples, ordered by relevance.
        """
        max_count = max_count or self._max_per_prompt

        # Get candidate pool
        if category and category in self._examples:
            pool = list(self._examples[category])
        else:
            pool = list(self._all_examples)

        # Filter by quality
        pool = [e for e in pool if e.quality_score >= min_quality]
        if not pool:
            return []

        # Score by relevance to task
        if task:
            scored = [(self._relevance(e, task), e) for e in pool]
            scored.sort(key=lambda x: x[0], reverse=True)
            pool = [e for _, e in scored]

        # Ensure diversity: max 2 from same category
        selected: list[FewShotExample] = []
        category_counts: dict[str, int] = {}
        for example in pool:
            cat = example.category
            if category_counts.get(cat, 0) >= 2:
                continue
            selected.append(example)
            category_counts[cat] = category_counts.get(cat, 0) + 1
            example.use_count += 1
            if len(selected) >= max_count:
                break

        return selected

    def format_examples(
        self,
        examples: list[FewShotExample],
        include_output: bool = True,
    ) -> str:
        """Format multiple examples into a prompt section."""
        if not examples:
            return ""
        parts = ["Here are some examples:"]
        for i, ex in enumerate(examples, 1):
            parts.append(f"\nExample {i}:")
            parts.append(ex.format(include_output=include_output))
        return "\n".join(parts)

    def get_for_prompt(
        self,
        category: str | None = None,
        task: str = "",
        include_output: bool = True,
    ) -> str:
        """Get formatted few-shot examples ready for prompt insertion.

        Convenience method combining selection and formatting.

        Args:
            category: Filter by category.
            task: Current task for relevance.
            include_output: Whether to include expected outputs.

        Returns:
            Formatted examples string, or empty string if none.
        """
        examples = self.get_examples(category=category, task=task)
        return self.format_examples(examples, include_output=include_output)

    def categories(self) -> list[str]:
        """List available categories."""
        return sorted(self._examples.keys())

    def count(self, category: str | None = None) -> int:
        """Count examples, optionally by category."""
        if category:
            return len(self._examples.get(category, []))
        return len(self._all_examples)

    def record_quality(self, example_id: str, success: bool) -> None:
        """Update the quality score of an example based on usage outcome."""
        for example in self._all_examples:
            if example.id == example_id:
                alpha = 0.1
                example.quality_score = (
                    alpha * (1.0 if success else 0.0)
                    + (1 - alpha) * example.quality_score
                )
                break

    # ── Private helpers ────────────────────────────────────────────────

    @staticmethod
    def _relevance(example: FewShotExample, task: str) -> float:
        """Score relevance of an example to a task (simple keyword overlap)."""
        task_words = set(re.findall(r"\w{3,}", task.lower()))
        example_words = set(re.findall(r"\w{3,}", example.task.lower()))
        if not task_words:
            return 0.5
        overlap = task_words & example_words
        return len(overlap) / len(task_words)

    def _register_defaults(self) -> None:
        """Register built-in few-shot examples."""
        defaults = [
            FewShotExample(
                id="file_read_basic",
                category="file_operation",
                task="Read the contents of config.json",
                output=(
                    "I'll read the config.json file for you.\n"
                    "Action: filesystem.read(path='config.json')\n"
                    "Result: File contents displayed successfully."
                ),
                tags=["read", "file", "json"],
            ),
            FewShotExample(
                id="file_write_basic",
                category="file_operation",
                task="Create a new file called hello.py with a print statement",
                output=(
                    "I'll create hello.py with a simple print statement.\n"
                    "Action: filesystem.write(path='hello.py', content='print(\"Hello, World!\")\\n')\n"
                    "Result: File created successfully."
                ),
                tags=["write", "file", "python"],
            ),
            FewShotExample(
                id="git_commit",
                category="git_operation",
                task="Commit all staged changes with message 'fix: resolve login bug'",
                output=(
                    "I'll commit the staged changes.\n"
                    "Action: shell.execute(command='git commit -m \"fix: resolve login bug\"')\n"
                    "Result: Commit created successfully."
                ),
                tags=["git", "commit"],
            ),
            FewShotExample(
                id="debug_traceback",
                category="debugging",
                task="Fix this error: TypeError: 'NoneType' object is not subscriptable",
                output=(
                    "This error means you're trying to index into a None value. "
                    "Let me find where this occurs.\n"
                    "1. Search for the subscript operation in the traceback\n"
                    "2. Add a None check before the access\n"
                    "3. Verify the fix resolves the error"
                ),
                tags=["debug", "error", "python"],
            ),
            FewShotExample(
                id="code_function",
                category="code_generation",
                task="Write a Python function to calculate fibonacci numbers",
                output=(
                    "```python\ndef fibonacci(n: int) -> int:\n"
                    "    \"\"\"Calculate the nth Fibonacci number.\"\"\"\n"
                    "    if n <= 1:\n"
                    "        return n\n"
                    "    a, b = 0, 1\n"
                    "    for _ in range(2, n + 1):\n"
                    "        a, b = b, a + b\n"
                    "    return b\n```"
                ),
                tags=["python", "function", "algorithm"],
            ),
            FewShotExample(
                id="test_pytest",
                category="testing",
                task="Write pytest tests for the fibonacci function",
                output=(
                    "```python\nimport pytest\nfrom mymodule import fibonacci\n\n"
                    "def test_fibonacci_base():\n"
                    "    assert fibonacci(0) == 0\n"
                    "    assert fibonacci(1) == 1\n\n"
                    "def test_fibonacci_sequence():\n"
                    "    assert fibonacci(5) == 5\n"
                    "    assert fibonacci(10) == 55\n\n"
                    "def test_fibonacci_negative():\n"
                    "    with pytest.raises(ValueError):\n"
                    "        fibonacci(-1)\n```"
                ),
                tags=["test", "pytest", "python"],
            ),
            FewShotExample(
                id="docker_build",
                category="docker_operation",
                task="Build a Docker image from the current directory",
                output=(
                    "I'll build the Docker image.\n"
                    "Action: shell.execute(command='docker build -t myapp:latest .')\n"
                    "Result: Image built successfully."
                ),
                tags=["docker", "build"],
            ),
        ]
        for ex in defaults:
            self.register(ex)
