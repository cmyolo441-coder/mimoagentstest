"""Prompt template manager — stores and retrieves prompt templates.

Manages a library of prompt templates with versioning, variable
substitution, and provider-specific formatting.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PromptTemplate:
    """A versioned prompt template."""
    name: str
    template: str
    version: int = 1
    description: str = ""
    variables: list[str] = field(default_factory=list)
    provider_specific: str | None = None  # None = generic
    tags: list[str] = field(default_factory=list)
    effectiveness_score: float = 0.5
    use_count: int = 0


class PromptManager:
    """Manages a library of prompt templates.

    Templates use Python-style ``{variable}`` placeholders.  The manager
    handles registration, retrieval, variable substitution, and
    provider-specific formatting.
    """

    # ── Built-in templates ─────────────────────────────────────────────

    SYSTEM_PROMPT = (
        "You are Terminal Agent, an autonomous AI assistant that operates "
        "inside the user's terminal. You can read files, write code, execute "
        "shell commands, manage git, install packages, and much more.\n\n"
        "CORE PRINCIPLES:\n"
        "- Think step-by-step before acting.\n"
        "- Verify every result.\n"
        "- If unsure, ask rather than guess.\n"
        "- Never run destructive commands without confirmation.\n"
        "- Report progress clearly and concisely.\n\n"
        "AVAILABLE TOOLS:\n{tool_descriptions}\n\n"
        "SAFETY LEVEL: {safety_level}\n"
        "{safety_rules}"
    )

    PLANNING_PROMPT = (
        "You are a planning engine. Given a goal, produce a step-by-step plan.\n\n"
        "GOAL: {goal}\n"
        "COMPLEXITY: {complexity}\n"
        "CONTEXT:\n{context}\n\n"
        "Produce a plan with one step per line:\n"
        "STEP: <description>\n"
        "DEPENDS_ON: <step numbers or 'none'>"
    )

    TOOL_SELECTION_PROMPT = (
        "Select the best tool for the following task.\n\n"
        "TASK: {task_description}\n"
        "AVAILABLE TOOLS:\n{tool_list}\n"
        "CONTEXT:\n{context}\n\n"
        "Respond in JSON: {{\"tool\": \"<name>\", \"parameters\": {{...}}}}"
    )

    VERIFICATION_PROMPT = (
        "Verify whether the following result achieves the goal.\n\n"
        "GOAL: {goal}\n"
        "STEP: {step_description}\n"
        "RESULT:\n{result}\n\n"
        "Respond with PASS or FAIL and a brief explanation."
    )

    ERROR_ANALYSIS_PROMPT = (
        "Analyze the following error and suggest a fix.\n\n"
        "STEP: {step_description}\n"
        "ERROR:\n{error}\n"
        "CONTEXT:\n{context}\n\n"
        "Suggest the best recovery approach."
    )

    SUMMARIZATION_PROMPT = (
        "Summarise the following conversation concisely, preserving "
        "key decisions, actions, and important context.\n\n"
        "{text}\n\nSummary:"
    )

    CODE_GENERATION_PROMPT = (
        "Generate code for the following requirement.\n\n"
        "REQUIREMENT: {requirement}\n"
        "LANGUAGE: {language}\n"
        "FRAMEWORK: {framework}\n"
        "CONTEXT:\n{context}\n\n"
        "Provide clean, well-documented code."
    )

    def __init__(self) -> None:
        self._templates: dict[str, PromptTemplate] = {}
        self._register_builtins()

    def register(self, template: PromptTemplate) -> None:
        """Register a prompt template."""
        key = f"{template.name}:v{template.version}"
        self._templates[key] = template
        # Also register as latest
        self._templates[template.name] = template
        logger.debug("Registered template %s (v%d)", template.name, template.version)

    def get(self, name: str, version: int | None = None) -> PromptTemplate | None:
        """Retrieve a template by name (and optional version)."""
        if version is not None:
            return self._templates.get(f"{name}:v{version}")
        return self._templates.get(name)

    def render(
        self,
        name: str,
        variables: dict[str, Any] | None = None,
        version: int | None = None,
    ) -> str:
        """Render a template with variable substitution.

        Args:
            name: Template name.
            variables: Values for template placeholders.
            version: Specific version (latest if None).

        Returns:
            The rendered prompt string.

        Raises:
            KeyError: If the template is not found.
        """
        template = self.get(name, version)
        if template is None:
            raise KeyError(f"Template '{name}' not found")

        variables = variables or {}
        # Add defaults for missing variables
        for var in template.variables:
            if var not in variables:
                variables[var] = f"[{var}]"

        try:
            return template.template.format(**variables)
        except KeyError as exc:
            logger.warning("Missing variable %s in template %s", exc, name)
            # Return with unfilled placeholders
            result = template.template
            for key, value in variables.items():
                result = result.replace(f"{{{key}}}", str(value))
            return result

    def list_templates(self, tag: str | None = None) -> list[str]:
        """List available template names, optionally filtered by tag."""
        names: list[str] = []
        seen: set[str] = set()
        for key, tmpl in self._templates.items():
            if ":" in key:
                continue  # Skip versioned entries
            if tag and tag not in tmpl.tags:
                continue
            if tmpl.name not in seen:
                names.append(tmpl.name)
                seen.add(tmpl.name)
        return sorted(names)

    def record_usage(self, name: str, success: bool) -> None:
        """Record template usage for effectiveness tracking."""
        template = self._templates.get(name)
        if template:
            template.use_count += 1
            # Exponential moving average
            alpha = 0.1
            template.effectiveness_score = (
                alpha * (1.0 if success else 0.0)
                + (1 - alpha) * template.effectiveness_score
            )

    # ── Private helpers ────────────────────────────────────────────────

    def _register_builtins(self) -> None:
        """Register built-in templates."""
        builtins = [
            PromptTemplate(
                name="system", template=self.SYSTEM_PROMPT,
                variables=["tool_descriptions", "safety_level", "safety_rules"],
                tags=["system", "core"],
            ),
            PromptTemplate(
                name="planning", template=self.PLANNING_PROMPT,
                variables=["goal", "complexity", "context"],
                tags=["planning", "core"],
            ),
            PromptTemplate(
                name="tool_selection", template=self.TOOL_SELECTION_PROMPT,
                variables=["task_description", "tool_list", "context"],
                tags=["tool", "core"],
            ),
            PromptTemplate(
                name="verification", template=self.VERIFICATION_PROMPT,
                variables=["goal", "step_description", "result"],
                tags=["verification", "core"],
            ),
            PromptTemplate(
                name="error_analysis", template=self.ERROR_ANALYSIS_PROMPT,
                variables=["step_description", "error", "context"],
                tags=["error", "recovery"],
            ),
            PromptTemplate(
                name="summarization", template=self.SUMMARIZATION_PROMPT,
                variables=["text"],
                tags=["context", "compression"],
            ),
            PromptTemplate(
                name="code_generation", template=self.CODE_GENERATION_PROMPT,
                variables=["requirement", "language", "framework", "context"],
                tags=["code", "generation"],
            ),
        ]
        for tmpl in builtins:
            self.register(tmpl)
