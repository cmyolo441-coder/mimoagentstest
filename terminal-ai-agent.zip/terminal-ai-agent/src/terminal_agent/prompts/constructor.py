"""Prompt constructor — dynamic prompt building from components.

Builds prompts incrementally, adding sections as needed and
adapting to the current provider's format requirements.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.prompts.manager import PromptManager

logger = logging.getLogger(__name__)


@dataclass
class PromptSection:
    """A section of a prompt with ordering and formatting metadata."""
    name: str
    content: str
    order: int = 50  # lower = earlier in the prompt
    separator: str = "\n\n"
    required: bool = False
    provider_format: str | None = None  # None = use default


class PromptConstructor:
    """Builds prompts dynamically from ordered sections.

    Supports:
      - Incremental section addition.
      - Automatic ordering.
      - Provider-specific formatting.
      - Variable substitution via the PromptManager.
    """

    def __init__(self, manager: PromptManager | None = None) -> None:
        self._manager = manager or PromptManager()
        self._sections: list[PromptSection] = []

    def add_section(
        self,
        name: str,
        content: str,
        order: int = 50,
        separator: str = "\n\n",
        required: bool = False,
    ) -> PromptConstructor:
        """Add a section to the prompt being constructed.

        Args:
            name: Section identifier.
            content: Section text.
            order: Ordering priority (lower = earlier).
            separator: Text to place before this section.
            required: If True, section is never dropped during compression.

        Returns:
            self (for chaining).
        """
        # Replace existing section with same name
        self._sections = [s for s in self._sections if s.name != name]
        self._sections.append(PromptSection(
            name=name,
            content=content,
            order=order,
            separator=separator,
            required=required,
        ))
        return self

    def add_template(
        self,
        template_name: str,
        variables: dict[str, Any] | None = None,
        order: int = 50,
    ) -> PromptConstructor:
        """Add a rendered template as a section.

        Args:
            template_name: Name of the template in the PromptManager.
            variables: Template variables.
            order: Ordering priority.

        Returns:
            self (for chaining).
        """
        try:
            rendered = self._manager.render(template_name, variables)
            self.add_section(
                name=template_name,
                content=rendered,
                order=order,
            )
        except KeyError:
            logger.warning("Template %s not found", template_name)
        return self

    def build(self) -> str:
        """Build the final prompt string from all sections.

        Sections are sorted by order and concatenated with their
        separators.

        Returns:
            The complete prompt string.
        """
        sorted_sections = sorted(self._sections, key=lambda s: s.order)
        parts: list[str] = []
        for section in sorted_sections:
            if section.content:
                parts.append(section.content)
        return "\n\n".join(parts)

    def build_messages(self, provider: str = "openai") -> list[dict[str, str]]:
        """Build the prompt as a message list for chat-based APIs.

        The first section with order < 20 becomes the system message.
        All other sections are concatenated into the user message.

        Args:
            provider: The provider format to use.

        Returns:
            A list of {"role": ..., "content": ...} dicts.
        """
        sorted_sections = sorted(self._sections, key=lambda s: s.order)
        system_parts: list[str] = []
        user_parts: list[str] = []

        for section in sorted_sections:
            if not section.content:
                continue
            if section.order < 20:
                system_parts.append(section.content)
            else:
                user_parts.append(section.content)

        messages: list[dict[str, str]] = []
        if system_parts:
            messages.append({"role": "system", "content": "\n\n".join(system_parts)})
        if user_parts:
            messages.append({"role": "user", "content": "\n\n".join(user_parts)})

        return messages

    def get_section(self, name: str) -> PromptSection | None:
        """Get a section by name."""
        for section in self._sections:
            if section.name == name:
                return section
        return None

    def remove_section(self, name: str) -> None:
        """Remove a section by name."""
        self._sections = [s for s in self._sections if s.name != name]

    def clear(self) -> None:
        """Remove all sections."""
        self._sections.clear()

    def section_names(self) -> list[str]:
        """List current section names in order."""
        return [s.name for s in sorted(self._sections, key=lambda s: s.order)]

    def estimated_tokens(self) -> int:
        """Estimate total token count (rough: chars / 4)."""
        total_chars = sum(len(s.content) for s in self._sections)
        return total_chars // 4
