"""Diff display: colorized terminal rendering of diffs.

Provides syntax-highlighted diff output with line-level coloring
and optional side-by-side mode.
"""

from __future__ import annotations

from typing import Any


# ANSI color codes
_COLORS = {
    "header": "\033[1;35m",     # Bold Magenta
    "file_old": "\033[1;31m",   # Bold Red
    "file_new": "\033[1;32m",   # Bold Green
    "add": "\033[32m",          # Green
    "remove": "\033[31m",       # Red
    "context": "\033[90m",      # Gray
    "hunk": "\033[36m",         # Cyan
    "reset": "\033[0m",
}


class DiffDisplay:
    """Render diffs for terminal display.

    Usage::

        display = DiffDisplay(colorize=True)
        print(display.render(diff_text))
        print(display.render_side_by_side(old_text, new_text, "file.py"))
    """

    def __init__(self, colorize: bool = True, width: int = 120) -> None:
        self._colorize = colorize
        self._width = width

    def render(self, diff: str) -> str:
        """Render a unified diff with colors."""
        if not self._colorize:
            return diff

        lines = diff.splitlines()
        rendered: list[str] = []
        for line in lines:
            rendered.append(self._colorize_line(line))
        return "\n".join(rendered)

    def render_side_by_side(
        self,
        old: str,
        new: str,
        filename: str = "",
    ) -> str:
        """Render a side-by-side diff."""
        import difflib
        old_lines = old.splitlines()
        new_lines = new.splitlines()
        differ = difflib.Differ()
        diff = list(differ.compare(old_lines, new_lines))

        half = (self._width - 3) // 2
        lines: list[str] = []

        if filename:
            header = f"--- {filename} ---"
            lines.append(self._color("header", header.center(self._width)))
            lines.append("")

        left_col: list[str] = []
        right_col: list[str] = []

        for line in diff:
            tag = line[0]
            text = line[2:]
            if tag == " ":
                left_col.append(text[:half].ljust(half))
                right_col.append(text[:half].ljust(half))
            elif tag == "-":
                left_col.append(self._color("remove", text[:half].ljust(half)))
                right_col.append(" ".ljust(half))
            elif tag == "+":
                left_col.append(" ".ljust(half))
                right_col.append(self._color("add", text[:half].ljust(half)))
            elif tag == "?":
                continue

        for left, right in zip(left_col, right_col):
            lines.append(f"{left} | {right}")

        return "\n".join(lines)

    def render_stats(self, diff: str) -> str:
        """Render a compact diff summary (files changed, lines added/removed)."""
        lines = diff.splitlines()
        added = sum(1 for l in lines if l.startswith("+") and not l.startswith("+++"))
        removed = sum(1 for l in lines if l.startswith("-") and not l.startswith("---"))
        files = set()
        for l in lines:
            if l.startswith("--- ") or l.startswith("+++ "):
                name = l[4:].split("\t")[0]
                if name != "/dev/null":
                    files.add(name.lstrip("ab/"))

        parts = []
        if files:
            parts.append(f"{len(files)} file(s) changed")
        parts.append(f"{added} insertion(s)")
        parts.append(f"{removed} deletion(s)")
        summary = ", ".join(parts)

        if self._colorize:
            summary = f"{_COLORS['add']}+{added}{_COLORS['reset']} / {_COLORS['remove']}-{removed}{_COLORS['reset']} | {summary}"
        return summary

    def _colorize_line(self, line: str) -> str:
        """Apply color to a single diff line."""
        if line.startswith("+++") or line.startswith("---"):
            return self._color("file_new" if line.startswith("+++") else "file_old", line)
        elif line.startswith("@@"):
            return self._color("hunk", line)
        elif line.startswith("+"):
            return self._color("add", line)
        elif line.startswith("-"):
            return self._color("remove", line)
        elif line.startswith("diff "):
            return self._color("header", line)
        else:
            return line

    def _color(self, style: str, text: str) -> str:
        """Wrap *text* in the color for *style*."""
        if not self._colorize:
            return text
        color = _COLORS.get(style, "")
        return f"{color}{text}{_COLORS['reset']}"
