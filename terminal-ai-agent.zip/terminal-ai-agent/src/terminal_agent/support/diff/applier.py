"""Diff application: apply unified diffs to text or files.

Supports applying patch-style unified diffs with conflict detection.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ApplyResult:
    """Result of applying a diff."""
    success: bool
    content: str = ""
    conflicts: list[str] = field(default_factory=list)
    lines_applied: int = 0
    error: str | None = None


class DiffApplier:
    """Apply unified diffs to text.

    Usage::

        applier = DiffApplier()
        result = applier.apply(original_text, unified_diff)
        if result.success:
            new_text = result.content
    """

    def apply(self, content: str, diff: str) -> ApplyResult:
        """Apply a unified diff to *content*.

        Parses the diff into hunks and applies them sequentially.
        Returns an ApplyResult with the patched content or conflict info.
        """
        try:
            hunks = self._parse_hunks(diff)
        except ValueError as exc:
            return ApplyResult(success=False, error=f"Failed to parse diff: {exc}")

        if not hunks:
            return ApplyResult(success=True, content=content, lines_applied=0)

        lines = content.splitlines()
        result_lines: list[str] = []
        current_line = 0
        total_applied = 0

        for hunk in hunks:
            # Copy lines before this hunk
            start = hunk.old_start - 1  # Convert to 0-indexed
            if start < current_line:
                return ApplyResult(
                    success=False,
                    error=f"Hunk overlaps with previous (line {start + 1} < {current_line + 1})",
                )
            result_lines.extend(lines[current_line:start])
            current_line = start

            # Apply hunk lines
            for line_type, text in hunk.lines:
                if line_type == " ":
                    # Context line — must match
                    if current_line >= len(lines) or lines[current_line] != text:
                        return ApplyResult(
                            success=False,
                            error=f"Context mismatch at line {current_line + 1}: expected '{text}'",
                        )
                    result_lines.append(text)
                    current_line += 1
                elif line_type == "-":
                    # Remove line — must match
                    if current_line >= len(lines) or lines[current_line] != text:
                        return ApplyResult(
                            success=False,
                            error=f"Remove mismatch at line {current_line + 1}: expected '{text}'",
                        )
                    current_line += 1
                elif line_type == "+":
                    # Add line
                    result_lines.append(text)
                    total_applied += 1

        # Copy remaining lines
        result_lines.extend(lines[current_line:])

        return ApplyResult(
            success=True,
            content="\n".join(result_lines),
            lines_applied=total_applied,
        )

    def apply_to_file(self, file_path: str | Path, diff: str) -> ApplyResult:
        """Apply a diff to a file and write the result."""
        path = Path(file_path)
        if not path.exists():
            return ApplyResult(success=False, error=f"File not found: {path}")
        content = path.read_text(encoding="utf-8")
        result = self.apply(content, diff)
        if result.success:
            path.write_text(result.content, encoding="utf-8")
        return result

    def _parse_hunks(self, diff: str) -> list[_Hunk]:
        """Parse unified diff into hunk objects."""
        hunks: list[_Hunk] = []
        current_hunk: _Hunk | None = None

        for line in diff.splitlines():
            # Hunk header: @@ -old_start,old_count +new_start,new_count @@
            match = re.match(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", line)
            if match:
                current_hunk = _Hunk(
                    old_start=int(match.group(1)),
                    old_count=int(match.group(2) or "1"),
                    new_start=int(match.group(3)),
                    new_count=int(match.group(4) or "1"),
                )
                hunks.append(current_hunk)
                continue
            if current_hunk is None:
                continue
            if line.startswith("+"):
                current_hunk.lines.append(("+", line[1:]))
            elif line.startswith("-"):
                current_hunk.lines.append(("-", line[1:]))
            elif line.startswith(" "):
                current_hunk.lines.append((" ", line[1:]))
            elif line.startswith("\\"):
                # "\ No newline at end of file"
                pass

        return hunks


@dataclass
class _Hunk:
    """A parsed diff hunk."""
    old_start: int
    old_count: int
    new_start: int
    new_count: int
    lines: list[tuple[str, str]] = field(default_factory=list)
