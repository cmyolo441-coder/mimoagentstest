"""Diff generation: compare two strings or files and produce a unified diff.

Supports unified, context, and ndiff output formats.
"""

from __future__ import annotations

import difflib
from pathlib import Path
from typing import Any


class DiffGenerator:
    """Generate diffs between strings or files.

    Usage::

        gen = DiffGenerator()
        diff = gen.diff_strings(old_text, new_text, "file.py")
        diff = gen.diff_files("old.py", "new.py")
        changes = gen.changed_lines(old_text, new_text)
    """

    def diff_strings(
        self,
        old: str,
        new: str,
        filename: str = "",
        *,
        format: str = "unified",
        context_lines: int = 3,
    ) -> str:
        """Generate a diff between two strings.

        Args:
            old: Original text.
            new: Modified text.
            filename: Filename for the diff header.
            format: 'unified', 'context', or 'ndiff'.
            context_lines: Number of context lines for unified/context format.

        Returns:
            Formatted diff string.
        """
        old_lines = old.splitlines(keepends=True)
        new_lines = new.splitlines(keepends=True)
        old_label = f"a/{filename}" if filename else "a"
        new_label = f"b/{filename}" if filename else "b"

        if format == "unified":
            return "".join(difflib.unified_diff(
                old_lines, new_lines,
                fromfile=old_label, tofile=new_label,
                n=context_lines,
            ))
        elif format == "context":
            return "".join(difflib.context_diff(
                old_lines, new_lines,
                fromfile=old_label, tofile=new_label,
                n=context_lines,
            ))
        elif format == "ndiff":
            return "".join(difflib.ndiff(old_lines, new_lines))
        else:
            raise ValueError(f"Unknown diff format: '{format}'")

    def diff_files(
        self,
        old_path: str | Path,
        new_path: str | Path,
        *,
        format: str = "unified",
        context_lines: int = 3,
    ) -> str:
        """Generate a diff between two files."""
        old_text = Path(old_path).read_text(encoding="utf-8")
        new_text = Path(new_path).read_text(encoding="utf-8")
        return self.diff_strings(
            old_text, new_text,
            filename=str(new_path),
            format=format,
            context_lines=context_lines,
        )

    def changed_lines(self, old: str, new: str) -> dict[str, list[int]]:
        """Identify changed line numbers.

        Returns:
            Dict with 'added', 'removed', 'modified' lists of 1-indexed line numbers.
        """
        old_lines = old.splitlines()
        new_lines = new.splitlines()
        matcher = difflib.SequenceMatcher(None, old_lines, new_lines)

        result: dict[str, list[int]] = {"added": [], "removed": [], "modified": []}
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == "insert":
                result["added"].extend(range(j1 + 1, j2 + 1))
            elif tag == "delete":
                result["removed"].extend(range(i1 + 1, i2 + 1))
            elif tag == "replace":
                result["modified"].extend(range(j1 + 1, j2 + 1))
        return result

    def similarity_ratio(self, old: str, new: str) -> float:
        """Return similarity ratio between two strings (0.0 to 1.0)."""
        return difflib.SequenceMatcher(None, old, new).ratio()

    def diff_lines(self, old: str, new: str) -> list[tuple[str, str]]:
        """Return a list of (tag, line) tuples.

        Tags: '+' added, '-' removed, ' ' unchanged, '?' hint.
        """
        old_lines = old.splitlines()
        new_lines = new.splitlines()
        differ = difflib.Differ()
        return [(line[0], line[2:]) for line in differ.compare(old_lines, new_lines)]
