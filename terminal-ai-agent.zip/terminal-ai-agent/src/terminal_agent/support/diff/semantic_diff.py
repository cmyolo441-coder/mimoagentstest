"""Semantic diff: understand code changes at the structural level.

Goes beyond text-level diffs to identify what changed semantically:
function additions/removals, signature changes, import changes, etc.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ChangeKind(str, Enum):
    """Types of semantic changes."""
    FUNCTION_ADDED = "function_added"
    FUNCTION_REMOVED = "function_removed"
    FUNCTION_MODIFIED = "function_modified"
    CLASS_ADDED = "class_added"
    CLASS_REMOVED = "class_removed"
    CLASS_MODIFIED = "class_modified"
    IMPORT_ADDED = "import_added"
    IMPORT_REMOVED = "import_removed"
    VARIABLE_ADDED = "variable_added"
    VARIABLE_REMOVED = "variable_removed"
    DOCSTRING_CHANGED = "docstring_changed"
    DECORATOR_CHANGED = "decorator_changed"
    UNKNOWN = "unknown"


@dataclass
class SemanticChange:
    """A single semantic change."""
    kind: ChangeKind
    name: str
    old_content: str | None = None
    new_content: str | None = None
    line_number: int | None = None
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class SemanticDiffResult:
    """Result of a semantic diff."""
    changes: list[SemanticChange] = field(default_factory=list)
    summary: dict[str, int] = field(default_factory=dict)

    @property
    def has_changes(self) -> bool:
        return len(self.changes) > 0


# Patterns for common languages
_PATTERNS: dict[str, dict[str, re.Pattern[str]]] = {
    "python": {
        "function": re.compile(r"^(?:async\s+)?def\s+(\w+)\s*\("),
        "class": re.compile(r"^class\s+(\w+)"),
        "import": re.compile(r"^(?:from\s+\S+\s+)?import\s+(.+)"),
        "decorator": re.compile(r"^@(\w+)"),
    },
    "javascript": {
        "function": re.compile(r"(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:function|\([^)]*\)\s*=>))"),
        "class": re.compile(r"^class\s+(\w+)"),
        "import": re.compile(r"^import\s+"),
    },
    "go": {
        "function": re.compile(r"^func\s+(?:\([^)]+\)\s+)?(\w+)\s*\("),
        "import": re.compile(r'^"'),
    },
    "rust": {
        "function": re.compile(r"^(?:pub\s+)?(?:async\s+)?fn\s+(\w+)"),
        "class": re.compile(r"^(?:pub\s+)?struct\s+(\w+)"),
        "import": re.compile(r"^use\s+"),
    },
}


class SemanticDiffer:
    """Compare two code versions at the semantic level.

    Usage::

        differ = SemanticDiffer(language="python")
        result = differ.diff(old_code, new_code)
        for change in result.changes:
            print(f"{change.kind}: {change.name}")
    """

    def __init__(self, language: str = "python") -> None:
        self._language = language
        self._patterns = _PATTERNS.get(language, _PATTERNS.get("python", {}))

    def diff(self, old: str, new: str) -> SemanticDiffResult:
        """Compare two code versions semantically."""
        old_defs = self._extract_definitions(old)
        new_defs = self._extract_definitions(new)

        changes: list[SemanticChange] = []

        # Check for removed and modified definitions
        for name, (kind, old_content, old_line) in old_defs.items():
            if name in new_defs:
                new_kind, new_content, new_line = new_defs[name]
                if old_content.strip() != new_content.strip():
                    changes.append(SemanticChange(
                        kind=ChangeKind(f"{kind}_modified"),
                        name=name,
                        old_content=old_content,
                        new_content=new_content,
                        line_number=new_line,
                    ))
            else:
                changes.append(SemanticChange(
                    kind=ChangeKind(f"{kind}_removed"),
                    name=name,
                    old_content=old_content,
                    line_number=old_line,
                ))

        # Check for added definitions
        for name, (kind, new_content, new_line) in new_defs.items():
            if name not in old_defs:
                changes.append(SemanticChange(
                    kind=ChangeKind(f"{kind}_added"),
                    name=name,
                    new_content=new_content,
                    line_number=new_line,
                ))

        # Check for import changes
        old_imports = self._extract_imports(old)
        new_imports = self._extract_imports(new)
        for imp in old_imports - new_imports:
            changes.append(SemanticChange(kind=ChangeKind.IMPORT_REMOVED, name=imp))
        for imp in new_imports - old_imports:
            changes.append(SemanticChange(kind=ChangeKind.IMPORT_ADDED, name=imp))

        # Build summary
        summary: dict[str, int] = {}
        for change in changes:
            summary[change.kind.value] = summary.get(change.kind.value, 0) + 1

        return SemanticDiffResult(changes=changes, summary=summary)

    def _extract_definitions(self, code: str) -> dict[str, tuple[str, str, int]]:
        """Extract named definitions from code.

        Returns: {name: (kind, content, line_number)}
        """
        definitions: dict[str, tuple[str, str, int]] = {}
        lines = code.splitlines()

        func_pattern = self._patterns.get("function")
        class_pattern = self._patterns.get("class")

        for i, line in enumerate(lines):
            if func_pattern:
                match = func_pattern.search(line)
                if match:
                    name = match.group(1) or match.group(2) if match.lastindex and match.lastindex >= 2 else match.group(1)
                    if name:
                        body = self._extract_body(lines, i)
                        definitions[name] = ("function", body, i + 1)

            if class_pattern:
                match = class_pattern.search(line)
                if match:
                    name = match.group(1)
                    body = self._extract_body(lines, i)
                    definitions[name] = ("class", body, i + 1)

        return definitions

    def _extract_imports(self, code: str) -> set[str]:
        """Extract import statements."""
        imports: set[str] = set()
        import_pattern = self._patterns.get("import")
        if not import_pattern:
            return imports
        for line in code.splitlines():
            if import_pattern.search(line):
                imports.add(line.strip())
        return imports

    @staticmethod
    def _extract_body(lines: list[str], start: int) -> str:
        """Extract the body of a definition (up to next same-level def or EOF)."""
        if start >= len(lines):
            return ""
        # Simple heuristic: take up to 50 lines or until dedent
        indent = len(lines[start]) - len(lines[start].lstrip())
        body_lines = [lines[start]]
        for i in range(start + 1, min(start + 50, len(lines))):
            line = lines[i]
            if line.strip() == "":
                body_lines.append(line)
                continue
            current_indent = len(line) - len(line.lstrip())
            if current_indent <= indent and line.strip():
                break
            body_lines.append(line)
        return "\n".join(body_lines)
