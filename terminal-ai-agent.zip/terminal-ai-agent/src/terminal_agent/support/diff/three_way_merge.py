"""Three-way merge: merge two modified versions using a common ancestor.

Implements line-level three-way merge with conflict detection
for scenarios where two independent edits were made to the same file.
"""

from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from typing import Any


@dataclass
class MergeResult:
    """Result of a three-way merge."""
    success: bool
    content: str = ""
    conflicts: list[dict[str, Any]] = field(default_factory=list)
    lines_merged: int = 0
    conflict_count: int = 0


class ThreeWayMerger:
    """Three-way merge engine.

    Usage::

        merger = ThreeWayMerger()
        result = merger.merge(base, version_a, version_b)
        if result.success:
            merged = result.content
        else:
            # Handle conflicts
            for c in result.conflicts:
                print(c["base"], c["a"], c["b"])
    """

    def merge(
        self,
        base: str,
        version_a: str,
        version_b: str,
        *,
        conflict_markers: bool = True,
    ) -> MergeResult:
        """Merge version_a and version_b using base as common ancestor.

        Args:
            base: The common ancestor text.
            version_a: First modified version.
            version_b: Second modified version.
            conflict_markers: If True, insert conflict markers on conflict.

        Returns:
            MergeResult with merged content or conflict info.
        """
        base_lines = base.splitlines()
        a_lines = version_a.splitlines()
        b_lines = version_b.splitlines()

        # Get opcodes for both sides vs base
        sm_a = difflib.SequenceMatcher(None, base_lines, a_lines)
        sm_b = difflib.SequenceMatcher(None, base_lines, b_lines)

        ops_a = sm_a.get_opcodes()
        ops_b = sm_b.get_opcodes()

        merged: list[str] = []
        conflicts: list[dict[str, Any]] = []
        a_idx = 0
        b_idx = 0
        lines_merged = 0

        # Simple three-way merge: iterate through base lines
        # For each region, check if A changed, B changed, both, or neither
        regions = self._compute_regions(ops_a, ops_b, len(base_lines))

        for region in regions:
            base_start, base_end = region["base_range"]
            a_op = region["a_op"]
            b_op = region["b_op"]

            if a_op == "equal" and b_op == "equal":
                # No changes — keep base
                merged.extend(base_lines[base_start:base_end])
                lines_merged += base_end - base_start
            elif a_op != "equal" and b_op == "equal":
                # Only A changed
                a_start, a_end = region["a_range"]
                merged.extend(a_lines[a_start:a_end])
                lines_merged += a_end - a_start
            elif a_op == "equal" and b_op != "equal":
                # Only B changed
                b_start, b_end = region["b_range"]
                merged.extend(b_lines[b_start:b_end])
                lines_merged += b_end - b_start
            else:
                # Both changed — potential conflict
                a_start, a_end = region["a_range"]
                b_start, b_end = region["b_range"]
                a_content = a_lines[a_start:a_end]
                b_content = b_lines[b_start:b_end]

                if a_content == b_content:
                    # Same change — no conflict
                    merged.extend(a_content)
                    lines_merged += len(a_content)
                else:
                    # Real conflict
                    conflicts.append({
                        "base": base_lines[base_start:base_end],
                        "a": a_content,
                        "b": b_content,
                        "line": len(merged) + 1,
                    })
                    if conflict_markers:
                        merged.append("<<<<<<< VERSION A")
                        merged.extend(a_content)
                        merged.append("=======")
                        merged.extend(b_content)
                        merged.append(">>>>>>> VERSION B")
                    else:
                        # Default: keep A
                        merged.extend(a_content)

        return MergeResult(
            success=len(conflicts) == 0,
            content="\n".join(merged),
            conflicts=conflicts,
            lines_merged=lines_merged,
            conflict_count=len(conflicts),
        )

    def _compute_regions(
        self,
        ops_a: list[tuple[str, int, int, int, int]],
        ops_b: list[tuple[str, int, int, int, int]],
        base_len: int,
    ) -> list[dict[str, Any]]:
        """Compute merged regions from both opcodes."""
        # Build a combined view of changes against the base
        # For simplicity, create a mapping: base_line → (a_op, b_op)
        changes_a: dict[int, str] = {}
        changes_b: dict[int, str] = {}

        for tag, i1, i2, _, _ in ops_a:
            for line in range(i1, i2):
                changes_a[line] = tag

        for tag, i1, i2, _, _ in ops_b:
            for line in range(i1, i2):
                changes_b[line] = tag

        # Group consecutive lines with the same change pattern
        regions: list[dict[str, Any]] = []
        current: dict[str, Any] | None = None

        for i in range(base_len):
            a_op = changes_a.get(i, "equal")
            b_op = changes_b.get(i, "equal")
            key = (a_op, b_op)

            if current is None or current["key"] != key:
                if current is not None:
                    current["base_range"] = (current["base_start"], i)
                    regions.append(current)
                # Find ranges for A and B
                a_start = ops_a[0][3] if ops_a else 0
                b_start = ops_b[0][3] if ops_b else 0
                current = {
                    "key": key,
                    "a_op": a_op,
                    "b_op": b_op,
                    "base_start": i,
                    "a_range": (0, 0),
                    "b_range": (0, 0),
                }

        if current is not None:
            current["base_range"] = (current["base_start"], base_len)
            regions.append(current)

        return regions
