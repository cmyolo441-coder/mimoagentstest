"""Diff subsystem: generate, apply, display, compare, and merge diffs
for file changes with conflict detection and semantic understanding.
"""

from terminal_agent.support.diff.generator import DiffGenerator
from terminal_agent.support.diff.applier import DiffApplier
from terminal_agent.support.diff.display import DiffDisplay
from terminal_agent.support.diff.conflict_detector import ConflictDetector
from terminal_agent.support.diff.conflict_resolver import ConflictResolver
from terminal_agent.support.diff.three_way_merge import ThreeWayMerger
from terminal_agent.support.diff.semantic_diff import SemanticDiffer
from terminal_agent.support.diff.stats import DiffStats

__all__ = [
    "DiffGenerator",
    "DiffApplier",
    "DiffDisplay",
    "ConflictDetector",
    "ConflictResolver",
    "ThreeWayMerger",
    "SemanticDiffer",
    "DiffStats",
]
