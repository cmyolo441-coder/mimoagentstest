"""Conflict resolution: strategies for resolving merge conflicts.

Provides automatic and interactive conflict resolution with
multiple strategies (ours, theirs, manual, LLM-assisted).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ResolutionStrategy(str, Enum):
    """Conflict resolution strategies."""
    OURS = "ours"         # Keep the first version
    THEIRS = "theirs"     # Keep the second version
    BOTH = "both"         # Keep both (with markers)
    NEWEST = "newest"     # Keep the more recent version
    MANUAL = "manual"     # Require manual resolution


@dataclass
class ResolvedConflict:
    """A resolved conflict region."""
    start_line: int
    end_line: int
    resolution: str
    strategy: ResolutionStrategy


@dataclass
class ResolutionResult:
    """Result of conflict resolution."""
    success: bool
    content: str = ""
    resolved: list[ResolvedConflict] = field(default_factory=list)
    unresolved: list[int] = field(default_factory=list)
    error: str | None = None


class ConflictResolver:
    """Resolve merge conflicts in text.

    Usage::

        resolver = ConflictResolver()
        result = resolver.resolve(conflicted_text, strategy=ResolutionStrategy.OURS)
        if result.success:
            clean_text = result.content
    """

    # Regex to match conflict markers
    _CONFLICT_RE = re.compile(
        r"^<<<<<<<[^\n]*\n(.*?)=======\n(.*?)>>>>>>>[^\n]*\n",
        re.MULTILINE | re.DOTALL,
    )

    def resolve(
        self,
        content: str,
        strategy: ResolutionStrategy = ResolutionStrategy.OURS,
    ) -> ResolutionResult:
        """Resolve all conflicts in *content* using the given strategy.

        Args:
            content: Text containing conflict markers.
            strategy: How to resolve each conflict.

        Returns:
            ResolutionResult with the clean content.
        """
        conflicts = list(self._CONFLICT_RE.finditer(content))
        if not conflicts:
            return ResolutionResult(success=True, content=content)

        resolved: list[ResolvedConflict] = []
        result = content

        # Process in reverse to preserve positions
        for match in reversed(conflicts):
            ours = match.group(1)
            theirs = match.group(2)

            if strategy == ResolutionStrategy.OURS:
                resolution = ours
            elif strategy == ResolutionStrategy.THEIRS:
                resolution = theirs
            elif strategy == ResolutionStrategy.BOTH:
                resolution = ours + theirs
            elif strategy == ResolutionStrategy.NEWEST:
                resolution = theirs  # Assume theirs is newer
            else:
                # Manual — leave markers
                continue

            result = result[:match.start()] + resolution + result[match.end():]
            resolved.append(ResolvedConflict(
                start_line=content[:match.start()].count("\n") + 1,
                end_line=content[:match.end()].count("\n") + 1,
                resolution=resolution,
                strategy=strategy,
            ))

        return ResolutionResult(
            success=True,
            content=result,
            resolved=list(reversed(resolved)),
        )

    def has_conflicts(self, content: str) -> bool:
        """Check if text contains conflict markers."""
        return bool(self._CONFLICT_RE.search(content))

    def count_conflicts(self, content: str) -> int:
        """Count the number of conflict regions."""
        return len(self._CONFLICT_RE.findall(content))

    def extract_conflicts(self, content: str) -> list[dict[str, str]]:
        """Extract conflict regions as structured data."""
        conflicts: list[dict[str, str]] = []
        for match in self._CONFLICT_RE.finditer(content):
            conflicts.append({
                "ours": match.group(1),
                "theirs": match.group(2),
                "start": match.start(),
                "end": match.end(),
            })
        return conflicts

    def strip_conflicts(
        self,
        content: str,
        keep: ResolutionStrategy = ResolutionStrategy.OURS,
    ) -> str:
        """Remove conflict markers, keeping one side."""
        result = self.resolve(content, strategy=keep)
        return result.content if result.success else content
