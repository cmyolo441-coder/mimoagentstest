"""Diff statistics: compute metrics from diffs.

Provides file-level and aggregate statistics for diffs including
lines added, removed, files changed, and complexity metrics.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class FileStats:
    """Statistics for a single file diff."""
    path: str
    lines_added: int = 0
    lines_removed: int = 0
    lines_modified: int = 0
    total_lines: int = 0
    is_new: bool = False
    is_deleted: bool = False
    is_binary: bool = False

    @property
    def lines_changed(self) -> int:
        """Total lines changed (added + removed + modified)."""
        return self.lines_added + self.lines_removed + self.lines_modified


@dataclass
class DiffStatsResult:
    """Aggregate diff statistics."""
    files_changed: int = 0
    files_added: int = 0
    files_deleted: int = 0
    total_lines_added: int = 0
    total_lines_removed: int = 0
    total_lines_modified: int = 0
    file_stats: list[FileStats] = field(default_factory=list)

    @property
    def total_changes(self) -> int:
        """Total line-level changes across all files."""
        return self.total_lines_added + self.total_lines_removed + self.total_lines_modified

    def summary(self, colorize: bool = False) -> str:
        """Human-readable summary."""
        parts = []
        if self.files_changed:
            parts.append(f"{self.files_changed} file(s) changed")
        if self.files_added:
            parts.append(f"{self.files_added} added")
        if self.files_deleted:
            parts.append(f"{self.files_deleted} deleted")
        if self.total_lines_added:
            parts.append(f"+{self.total_lines_added} insertions")
        if self.total_lines_removed:
            parts.append(f"-{self.total_lines_removed} deletions")
        return ", ".join(parts) if parts else "No changes"

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a dictionary."""
        return {
            "files_changed": self.files_changed,
            "files_added": self.files_added,
            "files_deleted": self.files_deleted,
            "total_lines_added": self.total_lines_added,
            "total_lines_removed": self.total_lines_removed,
            "total_lines_modified": self.total_lines_modified,
            "total_changes": self.total_changes,
            "files": [
                {
                    "path": fs.path,
                    "added": fs.lines_added,
                    "removed": fs.lines_removed,
                    "modified": fs.lines_modified,
                }
                for fs in self.file_stats
            ],
        }


class DiffStats:
    """Compute statistics from diffs.

    Usage::

        stats = DiffStats()
        result = stats.from_diff(unified_diff)
        print(result.summary())
    """

    def from_diff(self, diff: str) -> DiffStatsResult:
        """Compute statistics from a unified diff string."""
        result = DiffStatsResult()
        current_file: FileStats | None = None

        for line in diff.splitlines():
            # Detect file boundaries
            if line.startswith("diff "):
                if current_file:
                    self._accumulate(result, current_file)
                current_file = FileStats(path="")
                continue

            if line.startswith("--- "):
                if current_file and not current_file.path:
                    fname = line[4:].split("\t")[0]
                    if fname == "/dev/null":
                        if current_file:
                            current_file.is_new = True
                continue

            if line.startswith("+++ "):
                if current_file:
                    fname = line[4:].split("\t")[0]
                    current_file.path = fname.lstrip("ab/")
                    if fname == "/dev/null":
                        current_file.is_deleted = True
                continue

            if line.startswith("@@"):
                continue

            if current_file is None:
                continue

            if line.startswith("+"):
                current_file.lines_added += 1
                current_file.total_lines += 1
            elif line.startswith("-"):
                current_file.lines_removed += 1
            else:
                current_file.total_lines += 1

        # Don't forget the last file
        if current_file:
            self._accumulate(result, current_file)

        return result

    def from_file_stats(self, file_stats: list[FileStats]) -> DiffStatsResult:
        """Build a DiffStatsResult from a list of FileStats."""
        result = DiffStatsResult()
        for fs in file_stats:
            self._accumulate(result, fs)
        return result

    @staticmethod
    def _accumulate(result: DiffStatsResult, fs: FileStats) -> None:
        """Add file stats to the aggregate result."""
        result.file_stats.append(fs)
        result.files_changed += 1
        if fs.is_new:
            result.files_added += 1
        if fs.is_deleted:
            result.files_deleted += 1
        result.total_lines_added += fs.lines_added
        result.total_lines_removed += fs.lines_removed
        result.total_lines_modified += fs.lines_modified
