"""Conflict detection: identify conflicting changes between diffs.

Detects when two diffs modify the same lines and cannot be
automatically merged.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ConflictRegion:
    """A region where two diffs conflict."""
    start_line: int
    end_line: int
    diff1_content: list[str] = field(default_factory=list)
    diff2_content: list[str] = field(default_factory=list)
    reason: str = ""


@dataclass
class ConflictReport:
    """Result of conflict detection."""
    has_conflicts: bool
    conflicts: list[ConflictRegion] = field(default_factory=list)
    non_conflicting_regions: int = 0
    summary: str = ""


class ConflictDetector:
    """Detect conflicts between two sets of changes.

    Usage::

        detector = ConflictDetector()
        report = detector.detect(original, diff1, diff2)
        if report.has_conflicts:
            print(report.summary)
    """

    def detect(
        self,
        original: str,
        diff1: str,
        diff2: str,
    ) -> ConflictReport:
        """Detect conflicts between two unified diffs applied to the same original.

        Args:
            original: The original text.
            diff1: First unified diff.
            diff2: Second unified diff.

        Returns:
            A ConflictReport describing any conflicts found.
        """
        from terminal_agent.support.diff.applier import DiffApplier

        applier = DiffApplier()

        # Try applying diff1 then diff2
        result1 = applier.apply(original, diff1)
        if not result1.success:
            return ConflictReport(
                has_conflicts=True,
                summary=f"First diff failed to apply: {result1.error}",
            )

        result2 = applier.apply(result1.content, diff2)
        if not result2.success:
            # The second diff conflicts with the first
            conflict = ConflictRegion(
                start_line=0,
                end_line=0,
                diff1_content=diff1.splitlines(),
                diff2_content=diff2.splitlines(),
                reason=result2.error or "Second diff could not be applied after first",
            )
            return ConflictReport(
                has_conflicts=True,
                conflicts=[conflict],
                summary="Diffs conflict: second diff cannot be applied after first",
            )

        # Try the reverse order
        result1_rev = applier.apply(original, diff2)
        if not result1_rev.success:
            return ConflictReport(
                has_conflicts=True,
                summary="Second diff fails to apply to original",
            )

        result2_rev = applier.apply(result1_rev.content, diff1)
        if not result2_rev.success:
            conflict = ConflictRegion(
                start_line=0,
                end_line=0,
                diff1_content=diff1.splitlines(),
                diff2_content=diff2.splitlines(),
                reason="Diffs produce different results depending on order",
            )
            return ConflictReport(
                has_conflicts=True,
                conflicts=[conflict],
                summary="Diffs conflict: order-dependent changes",
            )

        # Both orders produce the same result — no conflict
        return ConflictReport(
            has_conflicts=False,
            non_conflicting_regions=1,
            summary="No conflicts detected — diffs can be merged",
        )

    def detect_line_conflicts(
        self,
        changes1: dict[int, str],
        changes2: dict[int, str],
    ) -> list[tuple[int, str, str]]:
        """Detect line-level conflicts between two change sets.

        Args:
            changes1: {line_number: new_content} from diff 1.
            changes2: {line_number: new_content} from diff 2.

        Returns:
            List of (line_number, content1, content2) for conflicting lines.
        """
        conflicts: list[tuple[int, str, str]] = []
        common_lines = set(changes1) & set(changes2)
        for line_num in sorted(common_lines):
            if changes1[line_num] != changes2[line_num]:
                conflicts.append((line_num, changes1[line_num], changes2[line_num]))
        return conflicts
