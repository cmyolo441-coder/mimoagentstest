"""Dependency validator — verify all imports and dependencies resolve.

Checks that all required packages are installed, all imports resolve,
and there are no circular dependencies.
"""

from __future__ import annotations

import ast
import logging
import re
import subprocess
import time
from pathlib import Path
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.dependency_validator")

# Standard library modules (Python 3.9+)
_PYTHON_STDLIB: frozenset[str] = frozenset({
    "abc", "aifc", "argparse", "array", "ast", "asynchat", "asyncio",
    "asyncore", "atexit", "base64", "bdb", "binascii", "binhex",
    "bisect", "builtins", "bz2", "calendar", "cgi", "cgitb", "chunk",
    "cmath", "cmd", "code", "codecs", "codeop", "collections",
    "colorsys", "compileall", "concurrent", "configparser", "contextlib",
    "contextvars", "copy", "copyreg", "cProfile", "crypt", "csv",
    "ctypes", "curses", "dataclasses", "datetime", "dbm", "decimal",
    "difflib", "dis", "distutils", "doctest", "email", "encodings",
    "enum", "errno", "faulthandler", "fcntl", "filecmp", "fileinput",
    "fnmatch", "fractions", "ftplib", "functools", "gc", "getopt",
    "getpass", "gettext", "glob", "grp", "gzip", "hashlib", "heapq",
    "hmac", "html", "http", "idlelib", "imaplib", "imghdr", "imp",
    "importlib", "inspect", "io", "ipaddress", "itertools", "json",
    "keyword", "lib2to3", "linecache", "locale", "logging", "lzma",
    "mailbox", "mailcap", "marshal", "math", "mimetypes", "mmap",
    "modulefinder", "multiprocessing", "netrc", "nis", "nntplib",
    "numbers", "operator", "optparse", "os", "ossaudiodev", "pathlib",
    "pdb", "pickle", "pickletools", "pipes", "pkgutil", "platform",
    "plistlib", "poplib", "posix", "posixpath", "pprint", "profile",
    "pstats", "pty", "pwd", "py_compile", "pyclbr", "pydoc",
    "queue", "quopri", "random", "readline", "re", "reprlib",
    "resource", "rlcompleter", "runpy", "sched", "secrets", "select",
    "selectors", "shelve", "shlex", "shutil", "signal", "site",
    "smtpd", "smtplib", "sndhdr", "socket", "socketserver", "sqlite3",
    "ssl", "stat", "statistics", "string", "stringprep", "struct",
    "subprocess", "sunau", "symtable", "sys", "sysconfig", "syslog",
    "tabnanny", "tarfile", "telnetlib", "tempfile", "termios", "test",
    "textwrap", "threading", "time", "timeit", "tkinter", "token",
    "tokenize", "tomllib", "trace", "traceback", "tracemalloc",
    "tty", "turtle", "turtledemo", "types", "typing", "unicodedata",
    "unittest", "urllib", "uu", "uuid", "venv", "warnings", "wave",
    "weakref", "webbrowser", "winreg", "winsound", "wsgiref",
    "xdrlib", "xml", "xmlrpc", "zipapp", "zipfile", "zipimport",
    "zlib",
})


class DependencyValidator:
    """Verify that all dependencies and imports resolve correctly.

    Checks:
    - Python imports resolve to installed packages
    - Node.js imports are in node_modules
    - No obvious circular dependency issues

    Usage::

        validator = DependencyValidator()
        result = validator.validate(tool_call, tool_result, context)
    """

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Validate dependencies for modified files."""
        t0 = time.monotonic()

        if tool_call.name not in ("write_file", "edit_file"):
            return CheckResult(
                name="dependency", stage=VerificationStage.QUALITY,
                severity=Severity.SKIP,
                message="Not a file-writing tool",
                duration_ms=_ms(t0),
            )

        path = tool_call.parameters.get("path", tool_call.parameters.get("file", ""))
        if not path:
            return CheckResult(
                name="dependency", stage=VerificationStage.QUALITY,
                severity=Severity.SKIP,
                message="No file path",
                duration_ms=_ms(t0),
            )

        issues: list[str] = []

        if path.endswith(".py"):
            issues.extend(self._check_python_deps(path, context))
        elif path.endswith((".js", ".ts", ".tsx", ".jsx")):
            issues.extend(self._check_node_deps(path, context))

        if issues:
            return CheckResult(
                name="dependency", stage=VerificationStage.QUALITY,
                severity=Severity.WARN,
                message=f"Dependency issues: {len(issues)} found",
                details={"issues": issues[:10]},
                duration_ms=_ms(t0),
            )

        return CheckResult(
            name="dependency", stage=VerificationStage.QUALITY,
            severity=Severity.PASS,
            message="Dependencies OK",
            duration_ms=_ms(t0),
        )

    # ── Python ──────────────────────────────────────────────────────

    def _check_python_deps(
        self, path: str, context: dict[str, Any]
    ) -> list[str]:
        """Check Python import dependencies."""
        issues: list[str] = []
        try:
            content = Path(path).read_text()
            tree = ast.parse(content)
        except (OSError, SyntaxError):
            return []

        # Collect all top-level imports
        imports: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.add(alias.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom):
                if node.module and not node.level:
                    imports.add(node.module.split(".")[0])

        # Check each import
        for mod in imports:
            if mod in _PYTHON_STDLIB:
                continue
            if mod.startswith("_"):
                continue
            # Try to import
            try:
                __import__(mod)
            except ImportError:
                # Check if it's a local module
                project_root = context.get("project_root", ".")
                local_path = Path(project_root) / f"{mod}.py"
                local_pkg = Path(project_root) / mod / "__init__.py"
                if not local_path.exists() and not local_pkg.exists():
                    issues.append(f"Missing dependency: {mod}")

        return issues

    # ── Node.js ─────────────────────────────────────────────────────

    def _check_node_deps(
        self, path: str, context: dict[str, Any]
    ) -> list[str]:
        """Check Node.js import dependencies."""
        issues: list[str] = []
        try:
            content = Path(path).read_text()
        except OSError:
            return []

        # Find non-relative imports
        import_pattern = re.compile(
            r"""(?:import|require)\s*\(?\s*['"]([^.'"][^'"]*?)['"]"""
        )
        for match in import_pattern.finditer(content):
            pkg = match.group(1)
            # Scoped package
            if pkg.startswith("@"):
                parts = pkg.split("/")
                pkg = "/".join(parts[:2]) if len(parts) >= 2 else pkg
            else:
                pkg = pkg.split("/")[0]

            # Check node_modules
            project_root = context.get("project_root", ".")
            node_modules = Path(project_root) / "node_modules" / pkg
            if not node_modules.exists():
                issues.append(f"Missing npm package: {pkg}")

        return issues


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
