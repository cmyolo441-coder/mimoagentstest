"""Test validator — run tests and check pass/fail status.

Detects the test framework for the current project and runs the
appropriate test command.  Parses output to determine success/failure
and extracts failing test names.
"""

from __future__ import annotations

import logging
import re
import subprocess
import time
from pathlib import Path
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.test_validator")

# Test framework detection: file → command
_FRAMEWORK_DETECTIONS: list[tuple[str, list[str]]] = [
    ("pytest.ini", ["python3", "-m", "pytest", "--tb=short", "-q"]),
    ("pyproject.toml", ["python3", "-m", "pytest", "--tb=short", "-q"]),
    ("setup.cfg", ["python3", "-m", "pytest", "--tb=short", "-q"]),
    ("tox.ini", ["python3", "-m", "pytest", "--tb=short", "-q"]),
    ("package.json", ["npx", "jest", "--passWithNoTests", "--silent"]),
    ("jest.config.js", ["npx", "jest", "--passWithNoTests", "--silent"]),
    ("vitest.config.ts", ["npx", "vitest", "run"]),
    ("Cargo.toml", ["cargo", "test"]),
    ("go.mod", ["go", "test", "./..."]),
    ("Makefile", []),  # check for test target dynamically
]


class TestValidator:
    """Run tests and validate results.

    Only triggers when the tool call was test-related (running tests,
    writing test files, modifying test code).

    Usage::

        validator = TestValidator(timeout=60)
        result = validator.validate(tool_call, tool_result, context)
    """

    def __init__(self, timeout: int = 120) -> None:
        self._timeout = timeout

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Run tests if the tool call was test-related."""
        t0 = time.monotonic()

        # Only trigger for test-related tool calls
        if not self._is_test_related(tool_call, context):
            return CheckResult(
                name="tests", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message="Not a test-related tool call",
                duration_ms=_ms(t0),
            )

        # Find test command
        test_cmd = self._find_test_command(context)
        if not test_cmd:
            return CheckResult(
                name="tests", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message="No test framework detected",
                duration_ms=_ms(t0),
            )

        # Run tests
        exit_code, stdout, stderr = self._run_tests(test_cmd)

        if exit_code == 0:
            # Parse pass count
            passed = self._count_passed(stdout)
            return CheckResult(
                name="tests", stage=VerificationStage.LOGIC,
                severity=Severity.PASS,
                message=f"Tests passed ({passed} test(s))",
                details={"passed": passed, "output": stdout[:2000]},
                duration_ms=_ms(t0),
            )

        # Parse failures
        failed_tests = self._extract_failures(stdout + "\n" + stderr)
        return CheckResult(
            name="tests", stage=VerificationStage.LOGIC,
            severity=Severity.FAIL,
            message=f"Tests failed: {len(failed_tests)} failure(s)",
            details={
                "failed_tests": failed_tests,
                "exit_code": exit_code,
                "output": (stdout + "\n" + stderr)[:2000],
            },
            duration_ms=_ms(t0),
        )

    # ── helpers ──────────────────────────────────────────────────────

    def _run_tests(self, cmd: list[str]) -> tuple[int, str, str]:
        """Execute test command."""
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self._timeout,
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return -1, "", f"Tests timed out after {self._timeout}s"
        except FileNotFoundError:
            return -2, "", f"Test runner not found: {cmd[0]}"

    @staticmethod
    def _is_test_related(tool_call: ToolCall, context: dict[str, Any]) -> bool:
        """Check if the tool call is test-related."""
        # Explicit test running
        if tool_call.name == "execute_command":
            cmd = tool_call.parameters.get("command", tool_call.parameters.get("cmd", ""))
            test_keywords = ("test", "pytest", "jest", "mocha", "cargo test", "go test")
            if any(kw in cmd.lower() for kw in test_keywords):
                return True

        # Writing test files
        if tool_call.name in ("write_file", "edit_file"):
            path = tool_call.parameters.get("path", tool_call.parameters.get("file", ""))
            if path and ("test" in path.lower() or "spec" in path.lower()):
                return True

        # Context flag
        if context.get("run_tests"):
            return True

        return False

    @staticmethod
    def _find_test_command(context: dict[str, Any]) -> list[str] | None:
        """Detect the test command for the project."""
        # Check context for explicit command
        if "test_command" in context:
            return context["test_command"]

        # Check for test framework files
        project_root = context.get("project_root", ".")
        for marker, cmd in _FRAMEWORK_DETECTIONS:
            if Path(project_root, marker).exists():
                if cmd:
                    return cmd
                # Makefile — check for test target
                if marker == "Makefile":
                    makefile = Path(project_root, "Makefile")
                    try:
                        content = makefile.read_text()
                        if "test:" in content:
                            return ["make", "test"]
                    except OSError:
                        pass

        return None

    @staticmethod
    def _count_passed(output: str) -> int:
        """Extract pass count from test output."""
        # pytest: "5 passed"
        m = re.search(r"(\d+)\s+passed", output)
        if m:
            return int(m.group(1))
        # jest: "Tests: 5 passed"
        m = re.search(r"Tests:\s+(\d+)\s+passed", output)
        if m:
            return int(m.group(1))
        # go test: "ok" in output
        if "ok" in output:
            return 1
        return 0

    @staticmethod
    def _extract_failures(output: str) -> list[str]:
        """Extract failing test names from output."""
        failures: list[str] = []

        # pytest FAILED pattern
        for m in re.finditer(r"FAILED\s+([\w/]+::[\w]+)", output):
            failures.append(m.group(1))

        # jest FAIL pattern
        for m in re.finditer(r"FAIL\s+([\w/]+\.[\w]+)", output):
            failures.append(m.group(1))

        # General "Error in" or "Test failed" patterns
        for m in re.finditer(r"(?:Error|FAIL|Failure)\s+(?:in|at)\s+([\w/.:]+)", output):
            failures.append(m.group(1))

        # Deduplicate
        return list(dict.fromkeys(failures))[:20]


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
