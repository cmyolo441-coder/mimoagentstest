"""Runtime validator — execute code and check for runtime errors.

Runs generated scripts in a sandboxed subprocess to verify they don't
crash, hang, or produce unexpected errors.  Timeouts and resource
limits prevent runaway processes.
"""

from __future__ import annotations

import logging
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.runtime_validator")

# Languages we can runtime-validate, and how to run them
_RUNNERS: dict[str, list[str]] = {
    "python": ["python3", "-c"],
    "javascript": ["node", "-e"],
    "shell": ["bash", "-c"],
    "ruby": ["ruby", "-e"],
    "php": ["php", "-r"],
    "lua": ["lua", "-e"],
}


class RuntimeValidator:
    """Validate code by executing it in a controlled subprocess.

    Only runs code for languages with available interpreters and only
    when the tool call wrote a standalone script (not a library module).

    Usage::

        validator = RuntimeValidator(timeout=10)
        result = validator.validate(tool_call, tool_result, context)
    """

    def __init__(self, timeout: int = 15) -> None:
        self._timeout = timeout

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Run runtime validation if applicable."""
        t0 = time.monotonic()

        # Only validate code-writing tools
        if tool_call.name not in ("write_file", "execute_command"):
            return CheckResult(
                name="runtime", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message="Not a code-writing tool",
                duration_ms=_ms(t0),
            )

        code = self._extract_runnable_code(tool_call, tool_result)
        if not code:
            return CheckResult(
                name="runtime", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message="No runnable code to validate",
                duration_ms=_ms(t0),
            )

        language = context.get("language", self._detect_language(code))
        if not language or language not in _RUNNERS:
            return CheckResult(
                name="runtime", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message=f"No runtime runner for language '{language}'",
                duration_ms=_ms(t0),
            )

        # Skip if code looks like a library module (no main block)
        if not self._is_runnable(code, language):
            return CheckResult(
                name="runtime", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message="Code appears to be a library module, skipping runtime check",
                duration_ms=_ms(t0),
            )

        # Execute
        runner = _RUNNERS[language]
        exit_code, stdout, stderr = self._run_code(code, runner)

        if exit_code != 0:
            error_msg = stderr.strip()[:500] if stderr else f"Exit code {exit_code}"
            return CheckResult(
                name="runtime", stage=VerificationStage.LOGIC,
                severity=Severity.FAIL,
                message=f"Runtime error: {error_msg}",
                details={
                    "exit_code": exit_code,
                    "stderr": stderr[:1000],
                    "stdout": stdout[:1000],
                },
                duration_ms=_ms(t0),
            )

        return CheckResult(
            name="runtime", stage=VerificationStage.LOGIC,
            severity=Severity.PASS,
            message="Runtime execution succeeded",
            duration_ms=_ms(t0),
        )

    def _run_code(
        self, code: str, runner: list[str]
    ) -> tuple[int, str, str]:
        """Execute code in a subprocess."""
        try:
            result = subprocess.run(
                runner + [code],
                capture_output=True,
                text=True,
                timeout=self._timeout,
                env={"PATH": "/usr/bin:/bin:/usr/local/bin"},
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return -1, "", f"Execution timed out after {self._timeout}s"
        except FileNotFoundError:
            return -2, "", f"Interpreter not found: {runner[0]}"

    @staticmethod
    def _is_runnable(code: str, language: str) -> bool:
        """Heuristic: does this code have a runnable entry point?"""
        if language == "python":
            return "if __name__" in code or code.strip().startswith("print(")
        if language == "javascript":
            return "console.log" in code or "process.exit" in code
        if language == "shell":
            return True  # shell scripts are always runnable
        if language == "ruby":
            return "puts " in code or code.strip().startswith("#!")
        return False

    @staticmethod
    def _detect_language(code: str) -> str | None:
        """Heuristic language detection."""
        if code.strip().startswith("#!"):
            first = code.split("\n", 1)[0]
            if "python" in first:
                return "python"
            if "bash" in first or "sh" in first:
                return "shell"
            if "node" in first:
                return "javascript"
            if "ruby" in first:
                return "ruby"
        if "def " in code and ":" in code:
            return "python"
        if "function " in code or "=>" in code:
            return "javascript"
        return None

    @staticmethod
    def _extract_runnable_code(
        tool_call: ToolCall, result: ToolResult
    ) -> str:
        """Extract code that can be run standalone."""
        params = tool_call.parameters
        if tool_call.name == "execute_command":
            cmd = params.get("command", params.get("cmd", ""))
            # Only validate script-like commands, not arbitrary shell
            if any(cmd.startswith(p) for p in ("python3 ", "python ", "node ", "bash ")):
                # Extract the inline code
                parts = cmd.split(" ", 1)
                if len(parts) > 1:
                    return parts[1]
            return ""
        if "content" in params:
            return str(params["content"])
        return ""


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
