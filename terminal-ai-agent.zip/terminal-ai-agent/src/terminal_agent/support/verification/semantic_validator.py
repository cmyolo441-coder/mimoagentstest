"""Semantic validator — use LLM to check if output makes sense.

Sends the tool output (and context) to an LLM for a "does this look
right?" check.  This catches logical errors, nonsensical output, and
subtle bugs that static analysis cannot detect.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.semantic_validator")

# Default prompt for semantic validation
_SEMANTIC_PROMPT = """You are a code reviewer. Analyze the following tool execution and determine if the output is correct and makes sense.

Tool: {tool_name}
Parameters: {parameters}
Output: {output}
Error (if any): {error}

Context: {context}

Respond with a JSON object:
{{"valid": true/false, "confidence": 0.0-1.0, "issues": ["issue1", ...], "suggestion": "..."}}
"""


class SemanticValidator:
    """Use LLM to validate semantic correctness of tool output.

    This is the most expensive check and is disabled by default.
    Enable it for critical operations or when debugging.

    Usage::

        validator = SemanticValidator(llm_call=my_llm_function)
        result = validator.validate(tool_call, tool_result, context)
    """

    def __init__(
        self,
        llm_call: Callable[[str], str] | None = None,
        *,
        confidence_threshold: float = 0.7,
    ) -> None:
        self._llm_call = llm_call
        self._confidence_threshold = confidence_threshold

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Run semantic validation via LLM."""
        t0 = time.monotonic()

        if not self._llm_call:
            return CheckResult(
                name="semantic", stage=VerificationStage.SEMANTIC,
                severity=Severity.SKIP,
                message="No LLM function configured for semantic validation",
                duration_ms=_ms(t0),
            )

        # Only validate for significant operations
        if not self._should_validate(tool_call, tool_result):
            return CheckResult(
                name="semantic", stage=VerificationStage.SEMANTIC,
                severity=Severity.SKIP,
                message="Operation does not warrant semantic validation",
                duration_ms=_ms(t0),
            )

        # Build the prompt
        prompt = _SEMANTIC_PROMPT.format(
            tool_name=tool_call.name,
            parameters=_truncate(str(tool_call.parameters), 1000),
            output=_truncate(tool_result.output, 2000),
            error=_truncate(tool_result.error or "None", 500),
            context=_truncate(str(context.get("description", "")), 500),
        )

        # Call LLM
        try:
            response = self._llm_call(prompt)
            return self._parse_response(response, t0)
        except Exception as e:
            logger.warning("Semantic validation LLM call failed: %s", e)
            return CheckResult(
                name="semantic", stage=VerificationStage.SEMANTIC,
                severity=Severity.WARN,
                message=f"Semantic validation failed: {e}",
                duration_ms=_ms(t0),
            )

    # ── helpers ──────────────────────────────────────────────────────

    def _should_validate(
        self, tool_call: ToolCall, tool_result: ToolResult
    ) -> bool:
        """Determine if this operation warrants LLM validation."""
        # Always validate code generation
        if tool_call.name in ("write_file", "edit_file"):
            return True
        # Validate failed commands to understand why
        if tool_result.exit_code != 0:
            return True
        # Validate database operations
        if tool_call.name == "database_execute":
            return True
        return False

    def _parse_response(self, response: str, t0: float) -> CheckResult:
        """Parse the LLM's semantic validation response."""
        import json

        try:
            # Try to extract JSON from response
            cleaned = response.strip()
            if cleaned.startswith("```"):
                lines = cleaned.split("\n")
                lines = [l for l in lines if not l.strip().startswith("```")]
                cleaned = "\n".join(lines)

            data = json.loads(cleaned)
            valid = data.get("valid", True)
            confidence = data.get("confidence", 0.5)
            issues = data.get("issues", [])
            suggestion = data.get("suggestion", "")

            if valid and confidence >= self._confidence_threshold:
                return CheckResult(
                    name="semantic", stage=VerificationStage.SEMANTIC,
                    severity=Severity.PASS,
                    message=f"Semantic check passed (confidence: {confidence:.0%})",
                    details={"confidence": confidence},
                    duration_ms=_ms(t0),
                )
            elif not valid:
                return CheckResult(
                    name="semantic", stage=VerificationStage.SEMANTIC,
                    severity=Severity.WARN,
                    message=f"Semantic issues: {'; '.join(issues[:3])}",
                    details={"issues": issues, "suggestion": suggestion},
                    duration_ms=_ms(t0),
                )
            else:
                return CheckResult(
                    name="semantic", stage=VerificationStage.SEMANTIC,
                    severity=Severity.WARN,
                    message=f"Low confidence ({confidence:.0%}): {suggestion}",
                    details={"confidence": confidence, "suggestion": suggestion},
                    duration_ms=_ms(t0),
                )

        except (json.JSONDecodeError, KeyError):
            # If we can't parse JSON, check for negative keywords
            lower = response.lower()
            if any(kw in lower for kw in ("incorrect", "wrong", "error", "bug", "invalid")):
                return CheckResult(
                    name="semantic", stage=VerificationStage.SEMANTIC,
                    severity=Severity.WARN,
                    message="Semantic review flagged potential issues",
                    details={"raw_response": response[:500]},
                    duration_ms=_ms(t0),
                )
            return CheckResult(
                name="semantic", stage=VerificationStage.SEMANTIC,
                severity=Severity.PASS,
                message="Semantic check passed (unstructured response)",
                duration_ms=_ms(t0),
            )


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[:max_len - 3] + "..."


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
