"""Cross-reference validator — check consistency across files.

Verifies that changes to one file don't break references in other files:
import statements, function calls, configuration keys, etc.
"""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.cross_reference")


class CrossReferenceValidator:
    """Check cross-file consistency after code changes.

    Usage::

        validator = CrossReferenceValidator()
        result = validator.validate(tool_call, tool_result, context)
    """

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Validate cross-file references."""
        t0 = time.monotonic()

        if tool_call.name not in ("write_file", "edit_file"):
            return CheckResult(
                name="cross_reference", stage=VerificationStage.QUALITY,
                severity=Severity.SKIP,
                message="Not a file-writing tool",
                duration_ms=_ms(t0),
            )

        path = tool_call.parameters.get("path", tool_call.parameters.get("file", ""))
        if not path:
            return CheckResult(
                name="cross_reference", stage=VerificationStage.QUALITY,
                severity=Severity.SKIP,
                message="No file path in tool parameters",
                duration_ms=_ms(t0),
            )

        issues: list[str] = []

        # Check Python imports
        if path.endswith(".py"):
            issues.extend(self._check_python_references(path, context))

        # Check JavaScript/TypeScript imports
        if path.endswith((".js", ".ts", ".tsx", ".jsx")):
            issues.extend(self._check_js_references(path, context))

        # Check configuration references
        if path.endswith((".json", ".yaml", ".yml", ".toml")):
            issues.extend(self._check_config_references(path, context))

        if issues:
            severity = Severity.FAIL if len(issues) > 3 else Severity.WARN
            return CheckResult(
                name="cross_reference", stage=VerificationStage.QUALITY,
                severity=severity,
                message=f"Cross-reference issues: {len(issues)} found",
                details={"issues": issues[:10]},
                duration_ms=_ms(t0),
            )

        return CheckResult(
            name="cross_reference", stage=VerificationStage.QUALITY,
            severity=Severity.PASS,
            message="Cross-references OK",
            duration_ms=_ms(t0),
        )

    # ── language-specific checks ────────────────────────────────────

    def _check_python_references(
        self, path: str, context: dict[str, Any]
    ) -> list[str]:
        """Check Python import references."""
        issues: list[str] = []
        try:
            content = Path(path).read_text()
        except OSError:
            return []

        # Find all imports
        import_pattern = re.compile(
            r"^(?:from\s+([\w.]+)\s+import|import\s+([\w.]+))",
            re.MULTILINE,
        )
        for match in import_pattern.finditer(content):
            module = match.group(1) or match.group(2)
            if module and module.startswith("."):
                continue  # relative imports — harder to check
            if module:
                # Check if module file exists
                parts = module.split(".")
                potential_paths = [
                    Path(*parts).with_suffix(".py"),
                    Path(*parts, "__init__.py"),
                ]
                project_root = context.get("project_root", ".")
                found = any(
                    (Path(project_root) / p).exists() for p in potential_paths
                )
                if not found:
                    # Could be a third-party package — skip
                    pass

        return issues

    def _check_js_references(
        self, path: str, context: dict[str, Any]
    ) -> list[str]:
        """Check JavaScript/TypeScript import references."""
        issues: list[str] = []
        try:
            content = Path(path).read_text()
        except OSError:
            return []

        # Find local imports (starting with ./ or ../)
        import_pattern = re.compile(
            r"""(?:import|require)\s*\(?\s*['"](\.[^'"]+)['"]""",
        )
        for match in import_pattern.finditer(content):
            import_path = match.group(1)
            base_dir = Path(path).parent
            # Try common extensions
            for ext in ("", ".js", ".ts", ".tsx", ".jsx", "/index.js", "/index.ts"):
                candidate = base_dir / (import_path + ext)
                if candidate.exists():
                    break
            else:
                issues.append(f"Import not found: {import_path}")

        return issues

    def _check_config_references(
        self, path: str, context: dict[str, Any]
    ) -> list[str]:
        """Check configuration file references."""
        issues: list[str] = []
        try:
            content = Path(path).read_text()
        except OSError:
            return []

        # Check file path references in config
        path_pattern = re.compile(r"""['"]([^'"]*\.[a-z]{1,5})['"]""")
        base_dir = Path(path).parent
        for match in path_pattern.finditer(content):
            ref = match.group(1)
            if ref.startswith(("http", "ftp", "ws")):
                continue  # URLs
            if "/" in ref or "\\" in ref:
                candidate = base_dir / ref
                if not candidate.exists():
                    # Could be a template reference
                    pass

        return issues


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
