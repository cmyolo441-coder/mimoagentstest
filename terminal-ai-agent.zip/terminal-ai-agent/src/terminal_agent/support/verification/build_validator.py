"""Build validator — attempt a build and check for success.

Detects the build system (npm build, cargo build, go build, make,
mvn, gradle, etc.) and runs it to verify that generated code compiles.
"""

from __future__ import annotations

import logging
import re
import subprocess
import time
from pathlib import Path
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.build_validator")

# Build system detection: marker file → build command
_BUILD_SYSTEMS: list[tuple[str, list[str], str]] = [
    ("package.json", ["npm", "run", "build"], "node"),
    ("tsconfig.json", ["npx", "tsc", "--noEmit"], "typescript"),
    ("Cargo.toml", ["cargo", "build", "--quiet"], "rust"),
    ("go.mod", ["go", "build", "./..."], "go"),
    ("Makefile", ["make", "build"], "make"),
    ("build.gradle", ["./gradlew", "build", "-x", "test"], "gradle"),
    ("pom.xml", ["mvn", "compile", "-q"], "maven"),
    ("CMakeLists.txt", ["cmake", "--build", "."], "cmake"),
    ("pyproject.toml", ["python3", "-m", "build", "--no-isolation"], "python"),
    ("setup.py", ["python3", "setup.py", "build"], "python"),
]


class BuildValidator:
    """Run the project's build system to verify compilation.

    Usage::

        validator = BuildValidator(timeout=120)
        result = validator.validate(tool_call, tool_result, context)
    """

    def __init__(self, timeout: int = 180) -> None:
        self._timeout = timeout

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Run build validation if the tool call was build-related."""
        t0 = time.monotonic()

        if not self._is_build_related(tool_call, context):
            return CheckResult(
                name="build", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message="Not a build-related change",
                duration_ms=_ms(t0),
            )

        build_cmd = self._find_build_command(context)
        if not build_cmd:
            return CheckResult(
                name="build", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message="No build system detected",
                duration_ms=_ms(t0),
            )

        exit_code, stdout, stderr = self._run_build(build_cmd)

        if exit_code == 0:
            return CheckResult(
                name="build", stage=VerificationStage.LOGIC,
                severity=Severity.PASS,
                message="Build succeeded",
                duration_ms=_ms(t0),
            )

        # Extract first error
        error_output = (stdout + "\n" + stderr).strip()
        first_error = self._extract_first_error(error_output)
        return CheckResult(
            name="build", stage=VerificationStage.LOGIC,
            severity=Severity.FAIL,
            message=f"Build failed: {first_error}",
            details={
                "exit_code": exit_code,
                "errors": error_output[:2000],
                "build_command": " ".join(build_cmd),
            },
            duration_ms=_ms(t0),
        )

    # ── helpers ──────────────────────────────────────────────────────

    def _run_build(self, cmd: list[str]) -> tuple[int, str, str]:
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self._timeout,
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return -1, "", f"Build timed out after {self._timeout}s"
        except FileNotFoundError:
            return -2, "", f"Build tool not found: {cmd[0]}"

    @staticmethod
    def _is_build_related(tool_call: ToolCall, context: dict[str, Any]) -> bool:
        """Check if the tool call could affect compilation."""
        if tool_call.name in ("write_file", "edit_file"):
            path = tool_call.parameters.get("path", tool_call.parameters.get("file", ""))
            if not path:
                return False
            # Check for build-relevant file extensions
            build_exts = (
                ".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs",
                ".java", ".c", ".cpp", ".h", ".hpp", ".cs", ".swift",
                ".kt", ".scala", ".rb", ".toml", ".json", ".yaml",
            )
            if any(path.endswith(ext) for ext in build_exts):
                return True

        if tool_call.name == "execute_command":
            cmd = tool_call.parameters.get("command", tool_call.parameters.get("cmd", ""))
            build_keywords = ("build", "compile", "make", "cmake", "cargo build")
            if any(kw in cmd.lower() for kw in build_keywords):
                return True

        if context.get("run_build"):
            return True

        return False

    @staticmethod
    def _find_build_command(context: dict[str, Any]) -> list[str] | None:
        """Detect the build command for the project."""
        if "build_command" in context:
            return context["build_command"]

        project_root = context.get("project_root", ".")
        for marker, cmd, _ in _BUILD_SYSTEMS:
            if Path(project_root, marker).exists():
                return cmd
        return None

    @staticmethod
    def _extract_first_error(output: str) -> str:
        """Extract the first error message from build output."""
        lines = output.split("\n")
        for line in lines:
            lower = line.lower()
            if any(kw in lower for kw in ("error:", "fatal:", "failed", "cannot")):
                return line.strip()[:200]
        # Fallback: last non-empty line
        for line in reversed(lines):
            if line.strip():
                return line.strip()[:200]
        return "Unknown build error"


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
