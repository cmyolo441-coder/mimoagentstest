"""Schema validator — check output matches expected schemas.

Validates JSON, YAML, and structured data against user-defined or
auto-detected schemas.  Useful for verifying API responses, config
files, and structured tool outputs.
"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.schema_validator")


class SchemaValidator:
    """Validate structured data against expected schemas.

    Supports:
    - JSON Schema validation (if jsonschema is installed)
    - Basic structural validation (required fields, types)
    - Custom validation rules from context

    Usage::

        validator = SchemaValidator()
        result = validator.validate(tool_call, tool_result, context={
            "expected_schema": {"type": "object", "required": ["name", "version"]}
        })
    """

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Validate tool output against an expected schema."""
        t0 = time.monotonic()

        # Only validate if there's an expected schema in context
        schema = context.get("expected_schema")
        if not schema:
            return CheckResult(
                name="schema", stage=VerificationStage.FORMAT,
                severity=Severity.SKIP,
                message="No expected schema defined",
                duration_ms=_ms(t0),
            )

        output = tool_result.output
        if not output:
            return CheckResult(
                name="schema", stage=VerificationStage.FORMAT,
                severity=Severity.WARN,
                message="No output to validate against schema",
                duration_ms=_ms(t0),
            )

        # Try to parse output as JSON
        data = self._try_parse_json(output)
        if data is None:
            return CheckResult(
                name="schema", stage=VerificationStage.FORMAT,
                severity=Severity.WARN,
                message="Output is not valid JSON, cannot validate against schema",
                duration_ms=_ms(t0),
            )

        # Try jsonschema first
        error = self._validate_jsonschema(data, schema)
        if error:
            return CheckResult(
                name="schema", stage=VerificationStage.FORMAT,
                severity=Severity.FAIL,
                message=f"Schema validation failed: {error}",
                details={"error": error},
                duration_ms=_ms(t0),
            )

        # Fall back to basic structural validation
        errors = self._validate_basic(data, schema)
        if errors:
            return CheckResult(
                name="schema", stage=VerificationStage.FORMAT,
                severity=Severity.FAIL,
                message=f"Schema validation failed: {'; '.join(errors)}",
                details={"errors": errors},
                duration_ms=_ms(t0),
            )

        return CheckResult(
            name="schema", stage=VerificationStage.FORMAT,
            severity=Severity.PASS,
            message="Schema validation passed",
            duration_ms=_ms(t0),
        )

    # ── validation methods ──────────────────────────────────────────

    @staticmethod
    def _validate_jsonschema(data: Any, schema: dict[str, Any]) -> str | None:
        """Validate using jsonschema library if available."""
        try:
            import jsonschema
            jsonschema.validate(data, schema)
            return None
        except jsonschema.ValidationError as e:
            return str(e.message)[:500]
        except ImportError:
            return None  # jsonschema not installed, skip
        except Exception as e:
            logger.debug("jsonschema error: %s", e)
            return None

    @staticmethod
    def _validate_basic(data: Any, schema: dict[str, Any]) -> list[str]:
        """Basic structural validation without jsonschema."""
        errors: list[str] = []

        # Check required fields
        required = schema.get("required", [])
        if isinstance(data, dict):
            for field in required:
                if field not in data:
                    errors.append(f"Missing required field: '{field}'")

        # Check type
        expected_type = schema.get("type")
        if expected_type:
            type_map = {
                "object": dict, "array": list, "string": str,
                "number": (int, float), "integer": int,
                "boolean": bool, "null": type(None),
            }
            expected_py = type_map.get(expected_type)
            if expected_py and not isinstance(data, expected_py):
                errors.append(
                    f"Expected type '{expected_type}', got '{type(data).__name__}'"
                )

        # Check properties
        properties = schema.get("properties", {})
        if isinstance(data, dict):
            for prop_name, prop_schema in properties.items():
                if prop_name in data:
                    prop_type = prop_schema.get("type")
                    if prop_type:
                        type_map = {
                            "object": dict, "array": list, "string": str,
                            "number": (int, float), "integer": int,
                            "boolean": bool,
                        }
                        expected_py = type_map.get(prop_type)
                        if expected_py and not isinstance(data[prop_name], expected_py):
                            errors.append(
                                f"Field '{prop_name}': expected '{prop_type}', "
                                f"got '{type(data[prop_name]).__name__}'"
                            )

        return errors

    @staticmethod
    def _try_parse_json(text: str) -> Any:
        """Try to parse text as JSON, handling markdown code blocks."""
        # Strip markdown code fences
        cleaned = text.strip()
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            # Remove first and last lines (code fences)
            lines = [l for l in lines if not l.strip().startswith("```")]
            cleaned = "\n".join(lines)

        try:
            return json.loads(cleaned)
        except (json.JSONDecodeError, ValueError):
            return None


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
