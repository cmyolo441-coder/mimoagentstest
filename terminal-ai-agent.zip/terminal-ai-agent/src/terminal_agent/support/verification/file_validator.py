"""File validator — verify files exist, are readable, and are well-formed.

Checks file existence, permissions, encoding, size limits, and
format-specific integrity (e.g., valid zip, valid PDF header).
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.file_validator")

# Maximum file size we'll read for validation (10 MB)
_MAX_FILE_SIZE = 10 * 1024 * 1024

# Magic bytes for common file types
_MAGIC_BYTES: dict[str, bytes] = {
    "zip": b"PK\x03\x04",
    "gzip": b"\x1f\x8b",
    "pdf": b"%PDF",
    "png": b"\x89PNG\r\n\x1a\n",
    "jpeg": b"\xff\xd8\xff",
    "gif": b"GIF8",
    "sqlite": b"SQLite format 3\x00",
    "elf": b"\x7fELF",
}


class FileValidator:
    """Validate file existence, readability, and integrity.

    Usage::

        validator = FileValidator()
        result = validator.validate(tool_call, tool_result, context)
    """

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Validate files referenced by the tool call."""
        t0 = time.monotonic()

        paths = self._extract_paths(tool_call)
        if not paths:
            return CheckResult(
                name="file_integrity", stage=VerificationStage.FORMAT,
                severity=Severity.SKIP,
                message="No file paths to validate",
                duration_ms=_ms(t0),
            )

        errors: list[str] = []
        warnings: list[str] = []

        for path in paths:
            result = self._validate_single(path, tool_call.name)
            if result["status"] == "error":
                errors.append(f"{path}: {result['message']}")
            elif result["status"] == "warn":
                warnings.append(f"{path}: {result['message']}")

        if errors:
            return CheckResult(
                name="file_integrity", stage=VerificationStage.FORMAT,
                severity=Severity.FAIL,
                message=f"File validation failed: {'; '.join(errors)}",
                details={"errors": errors, "warnings": warnings},
                duration_ms=_ms(t0),
            )

        if warnings:
            return CheckResult(
                name="file_integrity", stage=VerificationStage.FORMAT,
                severity=Severity.WARN,
                message=f"File validation warnings: {'; '.join(warnings)}",
                details={"warnings": warnings},
                duration_ms=_ms(t0),
            )

        return CheckResult(
            name="file_integrity", stage=VerificationStage.FORMAT,
            severity=Severity.PASS,
            message=f"All {len(paths)} file(s) validated OK",
            duration_ms=_ms(t0),
        )

    # ── single file validation ──────────────────────────────────────

    def _validate_single(self, path: str, tool_name: str) -> dict[str, str]:
        """Validate a single file path."""
        p = Path(path)

        # For write/create tools, check the file was created
        if tool_name in ("write_file", "edit_file", "copy_file"):
            if not p.exists():
                return {"status": "error", "message": "File was not created"}
            if not p.is_file():
                return {"status": "error", "message": "Path exists but is not a file"}

        # For read tools, check the file exists
        if tool_name in ("read_file", "get_metadata"):
            if not p.exists():
                return {"status": "error", "message": "File does not exist"}
            if not os.access(p, os.R_OK):
                return {"status": "error", "message": "File is not readable"}

        # For delete tools, check the file was removed
        if tool_name in ("delete_file", "delete_directory"):
            if p.exists():
                return {"status": "error", "message": "File/directory was not deleted"}

        # If file exists, check additional properties
        if p.exists() and p.is_file():
            size = p.stat().st_size
            if size > _MAX_FILE_SIZE:
                return {
                    "status": "warn",
                    "message": f"File is very large ({size / 1024 / 1024:.1f} MB)",
                }
            if size == 0:
                return {"status": "warn", "message": "File is empty"}

        return {"status": "ok", "message": "OK"}

    # ── helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _extract_paths(tool_call: ToolCall) -> list[str]:
        """Extract file paths from tool parameters."""
        params = tool_call.parameters
        paths: list[str] = []
        for key in ("path", "file", "file_path", "source", "destination",
                     "directory", "dir", "target"):
            if key in params:
                val = params[key]
                if isinstance(val, str):
                    paths.append(val)
                elif isinstance(val, list):
                    paths.extend(str(v) for v in val)
        return paths


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
