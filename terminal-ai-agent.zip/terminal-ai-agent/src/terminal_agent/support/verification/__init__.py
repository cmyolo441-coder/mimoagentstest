"""Verification subsystem for Terminal Agent.

Validates every action's result through a multi-stage pipeline:

1. Basic checks   — exit code, output presence
2. Format checks  — syntax, schema, encoding
3. Logic checks   — tests pass, build succeeds
4. Quality checks — linting, complexity, style
5. Semantic checks — LLM review of output
6. Regression checks — existing functionality preserved
"""

from __future__ import annotations

from terminal_agent.support.verification.engine import VerificationEngine
from terminal_agent.support.verification.syntax_validator import SyntaxValidator
from terminal_agent.support.verification.runtime_validator import RuntimeValidator
from terminal_agent.support.verification.type_validator import TypeValidator
from terminal_agent.support.verification.schema_validator import SchemaValidator
from terminal_agent.support.verification.file_validator import FileValidator
from terminal_agent.support.verification.test_validator import TestValidator
from terminal_agent.support.verification.build_validator import BuildValidator
from terminal_agent.support.verification.regression_validator import RegressionValidator
from terminal_agent.support.verification.semantic_validator import SemanticValidator
from terminal_agent.support.verification.cross_reference import CrossReferenceValidator
from terminal_agent.support.verification.dependency_validator import DependencyValidator

__all__ = [
    "VerificationEngine",
    "SyntaxValidator",
    "RuntimeValidator",
    "TypeValidator",
    "SchemaValidator",
    "FileValidator",
    "TestValidator",
    "BuildValidator",
    "RegressionValidator",
    "SemanticValidator",
    "CrossReferenceValidator",
    "DependencyValidator",
]
