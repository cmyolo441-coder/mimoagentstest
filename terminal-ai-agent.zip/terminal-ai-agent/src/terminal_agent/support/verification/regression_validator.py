"""Regression validator — verify that previously working things still work.

Compares the current state against a known-good baseline.  Detects
when code changes break existing functionality.
"""

from __future__ import annotations

import hashlib
import json
import logging
import subprocess
import time
from pathlib import Path
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.regression_validator")


class RegressionValidator:
    """Detect regressions by comparing against a baseline.

    Checks:
    - Previously passing tests still pass
    - Modified files don't break imports/dependencies
    - Key project files haven't been accidentally changed

    Usage::

        validator = RegressionValidator()
        result = validator.validate(tool_call, tool_result, context)
    """

    def __init__(self, timeout: int = 60) -> None:
        self._timeout = timeout

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Run regression checks."""
        t0 = time.monotonic()

        checks_run = 0
        failures: list[str] = []
        warnings: list[str] = []

        # Check 1: Protected files not modified
        protected = context.get("protected_files", [])
        if protected:
            modified = self._get_modified_files(context)
            accidentally_changed = [
                f for f in modified if f in protected
            ]
            if accidentally_changed:
                failures.append(
                    f"Protected files modified: {', '.join(accidentally_changed)}"
                )
            checks_run += 1

        # Check 2: Git status — no unexpected changes
        if context.get("check_git_clean"):
            unexpected = self._check_git_status(context)
            if unexpected:
                warnings.extend(unexpected)
            checks_run += 1

        # Check 3: Import graph integrity
        if tool_call.name in ("write_file", "edit_file"):
            path = tool_call.parameters.get("path", tool_call.parameters.get("file", ""))
            if path and path.endswith(".py"):
                import_error = self._check_python_imports(path)
                if import_error:
                    failures.append(f"Import check failed: {import_error}")
                checks_run += 1

        if checks_run == 0:
            return CheckResult(
                name="regression", stage=VerificationStage.REGRESSION,
                severity=Severity.SKIP,
                message="No regression checks applicable",
                duration_ms=_ms(t0),
            )

        if failures:
            return CheckResult(
                name="regression", stage=VerificationStage.REGRESSION,
                severity=Severity.FAIL,
                message=f"Regression detected: {'; '.join(failures)}",
                details={"failures": failures, "warnings": warnings},
                duration_ms=_ms(t0),
            )

        if warnings:
            return CheckResult(
                name="regression", stage=VerificationStage.REGRESSION,
                severity=Severity.WARN,
                message=f"Regression warnings: {'; '.join(warnings)}",
                details={"warnings": warnings},
                duration_ms=_ms(t0),
            )

        return CheckResult(
            name="regression", stage=VerificationStage.REGRESSION,
            severity=Severity.PASS,
            message=f"All {checks_run} regression check(s) passed",
            duration_ms=_ms(t0),
        )

    # ── checks ──────────────────────────────────────────────────────

    @staticmethod
    def _get_modified_files(context: dict[str, Any]) -> list[str]:
        """Get list of modified files from context or git."""
        if "modified_files" in context:
            return context["modified_files"]

        try:
            result = subprocess.run(
                ["git", "diff", "--name-only", "HEAD"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                return [f for f in result.stdout.strip().split("\n") if f]
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        return []

    @staticmethod
    def _check_git_status(context: dict[str, Any]) -> list[str]:
        """Check for unexpected changes in git."""
        warnings: list[str] = []
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                for line in result.stdout.strip().split("\n"):
                    if line.startswith("??"):
                        warnings.append(f"New untracked file: {line[3:]}")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        return warnings

    @staticmethod
    def _check_python_imports(path: str) -> str | None:
        """Verify that a Python file can be parsed for imports."""
        try:
            content = Path(path).read_text()
            import ast
            tree = ast.parse(content)
            # Check for obvious import issues
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom):
                    if node.module and ".." in (node.module or ""):
                        # Relative import — verify it resolves
                        pass
            return None
        except SyntaxError as e:
            return f"Syntax error prevents import analysis: {e}"
        except OSError:
            return None  # File might have been moved


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
