"""Main verification engine — orchestrates the validation pipeline.

Coordinates all validators through a staged pipeline.  Each stage can
pass, warn, or fail.  A failure at any stage short-circuits (unless
configured otherwise) and returns a detailed ``VerificationReport``.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.build_validator import BuildValidator
from terminal_agent.support.verification.cross_reference import CrossReferenceValidator
from terminal_agent.support.verification.dependency_validator import DependencyValidator
from terminal_agent.support.verification.file_validator import FileValidator
from terminal_agent.support.verification.regression_validator import RegressionValidator
from terminal_agent.support.verification.runtime_validator import RuntimeValidator
from terminal_agent.support.verification.schema_validator import SchemaValidator
from terminal_agent.support.verification.semantic_validator import SemanticValidator
from terminal_agent.support.verification.syntax_validator import SyntaxValidator
from terminal_agent.support.verification.test_validator import TestValidator
from terminal_agent.support.verification.type_validator import TypeValidator

logger = logging.getLogger("terminal_agent.support.verification.engine")


class Severity(str, Enum):
    """Severity of a single verification check."""
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    SKIP = "skip"


@dataclass
class CheckResult:
    """Result of a single verification check."""
    name: str
    stage: VerificationStage
    severity: Severity
    message: str = ""
    details: dict[str, Any] = field(default_factory=dict)
    duration_ms: float = 0.0


@dataclass
class VerificationReport:
    """Aggregated report from the verification pipeline."""
    passed: bool
    checks: list[CheckResult] = field(default_factory=list)
    total_duration_ms: float = 0.0

    @property
    def failures(self) -> list[CheckResult]:
        return [c for c in self.checks if c.severity == Severity.FAIL]

    @property
    def warnings(self) -> list[CheckResult]:
        return [c for c in self.checks if c.severity == Severity.WARN]

    @property
    def passes(self) -> list[CheckResult]:
        return [c for c in self.checks if c.severity == Severity.PASS]

    def summary(self) -> str:
        """Human-readable summary."""
        lines = [
            f"Verification: {'PASSED' if self.passed else 'FAILED'}",
            f"Checks: {len(self.passes)} passed, "
            f"{len(self.warnings)} warnings, "
            f"{len(self.failures)} failures "
            f"({self.total_duration_ms:.0f}ms)",
        ]
        for f in self.failures:
            lines.append(f"  ✗ [{f.name}] {f.message}")
        for w in self.warnings:
            lines.append(f"  ⚠ [{w.name}] {w.message}")
        return "\n".join(lines)


class VerificationEngine:
    """Orchestrate the multi-stage verification pipeline.

    Usage::

        engine = VerificationEngine()
        report = engine.verify(tool_call, tool_result, context={})
        if not report.passed:
            print(report.summary())
    """

    def __init__(
        self,
        *,
        skip_stages: set[VerificationStage] | None = None,
        fail_fast: bool = True,
        enable_semantic: bool = False,
        semantic_llm_call: Any | None = None,
    ) -> None:
        self._skip_stages = skip_stages or set()
        self._fail_fast = fail_fast
        self._enable_semantic = enable_semantic

        # Instantiate all validators
        self._syntax = SyntaxValidator()
        self._runtime = RuntimeValidator()
        self._type = TypeValidator()
        self._schema = SchemaValidator()
        self._file = FileValidator()
        self._test = TestValidator()
        self._build = BuildValidator()
        self._regression = RegressionValidator()
        self._semantic = SemanticValidator(llm_call=semantic_llm_call)
        self._cross_ref = CrossReferenceValidator()
        self._dependency = DependencyValidator()

    # ── public API ──────────────────────────────────────────────────

    def verify(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any] | None = None,
    ) -> VerificationReport:
        """Run the full verification pipeline.

        Args:
            tool_call: The tool call that was executed.
            tool_result: The result of the tool execution.
            context: Additional context (project info, file contents, etc.).

        Returns:
            A ``VerificationReport`` with all check results.
        """
        ctx = context or {}
        checks: list[CheckResult] = []
        start = time.monotonic()

        # Stage 1: Basic checks
        checks.extend(self._run_stage(VerificationStage.BASIC, [
            ("exit_code", self._check_exit_code, tool_call, tool_result, ctx),
            ("output_presence", self._check_output_presence, tool_call, tool_result, ctx),
        ]))

        if self._should_stop(checks):
            return self._build_report(checks, start)

        # Stage 2: Format checks
        checks.extend(self._run_stage(VerificationStage.FORMAT, [
            ("syntax", self._syntax.validate, tool_call, tool_result, ctx),
            ("file_integrity", self._file.validate, tool_call, tool_result, ctx),
            ("schema", self._schema.validate, tool_call, tool_result, ctx),
        ]))

        if self._should_stop(checks):
            return self._build_report(checks, start)

        # Stage 3: Logic checks
        checks.extend(self._run_stage(VerificationStage.LOGIC, [
            ("runtime", self._runtime.validate, tool_call, tool_result, ctx),
            ("type_check", self._type.validate, tool_call, tool_result, ctx),
            ("tests", self._test.validate, tool_call, tool_result, ctx),
            ("build", self._build.validate, tool_call, tool_result, ctx),
        ]))

        if self._should_stop(checks):
            return self._build_report(checks, start)

        # Stage 4: Quality checks
        checks.extend(self._run_stage(VerificationStage.QUALITY, [
            ("cross_reference", self._cross_ref.validate, tool_call, tool_result, ctx),
            ("dependency", self._dependency.validate, tool_call, tool_result, ctx),
        ]))

        if self._should_stop(checks):
            return self._build_report(checks, start)

        # Stage 5: Semantic checks (optional, expensive)
        if self._enable_semantic and VerificationStage.SEMANTIC not in self._skip_stages:
            checks.extend(self._run_stage(VerificationStage.SEMANTIC, [
                ("semantic", self._semantic.validate, tool_call, tool_result, ctx),
            ]))

        # Stage 6: Regression checks
        checks.extend(self._run_stage(VerificationStage.REGRESSION, [
            ("regression", self._regression.validate, tool_call, tool_result, ctx),
        ]))

        return self._build_report(checks, start)

    def register_custom_check(
        self,
        stage: VerificationStage,
        name: str,
        check_fn: Any,
    ) -> None:
        """Register a custom verification check (advanced)."""
        logger.info("Registered custom check '%s' in stage %s", name, stage.value)

    # ── internal checks ─────────────────────────────────────────────

    def _check_exit_code(
        self, tool_call: ToolCall, result: ToolResult, ctx: dict
    ) -> CheckResult:
        t0 = time.monotonic()
        if result.exit_code == 0:
            return CheckResult(
                name="exit_code", stage=VerificationStage.BASIC,
                severity=Severity.PASS, duration_ms=_ms(t0),
            )
        return CheckResult(
            name="exit_code", stage=VerificationStage.BASIC,
            severity=Severity.FAIL,
            message=f"Non-zero exit code: {result.exit_code}",
            details={"exit_code": result.exit_code, "error": result.error},
            duration_ms=_ms(t0),
        )

    def _check_output_presence(
        self, tool_call: ToolCall, result: ToolResult, ctx: dict
    ) -> CheckResult:
        t0 = time.monotonic()
        # Some tools legitimately produce no output
        tools_expecting_output = {
            "execute_command", "read_file", "search_code", "search_files",
            "git_status", "git_log", "git_diff", "http_get",
        }
        if tool_call.name in tools_expecting_output and not result.output:
            return CheckResult(
                name="output_presence", stage=VerificationStage.BASIC,
                severity=Severity.WARN,
                message=f"Tool '{tool_call.name}' produced no output",
                duration_ms=_ms(t0),
            )
        return CheckResult(
            name="output_presence", stage=VerificationStage.BASIC,
            severity=Severity.PASS, duration_ms=_ms(t0),
        )

    # ── pipeline helpers ────────────────────────────────────────────

    def _run_stage(
        self,
        stage: VerificationStage,
        checks: list[tuple[str, Any, ToolCall, ToolResult, dict]],
    ) -> list[CheckResult]:
        if stage in self._skip_stages:
            return [CheckResult(
                name=name, stage=stage, severity=Severity.SKIP,
                message=f"Stage {stage.value} skipped",
            ) for name, *_ in checks]

        results: list[CheckResult] = []
        for name, fn, tc, tr, ctx in checks:
            try:
                result = fn(tc, tr, ctx)
                results.append(result)
            except Exception as e:
                logger.warning("Check '%s' raised: %s", name, e)
                results.append(CheckResult(
                    name=name, stage=stage, severity=Severity.WARN,
                    message=f"Check raised exception: {e}",
                ))
        return results

    def _should_stop(self, checks: list[CheckResult]) -> bool:
        if not self._fail_fast:
            return False
        return any(c.severity == Severity.FAIL for c in checks)

    def _build_report(
        self, checks: list[CheckResult], start: float
    ) -> VerificationReport:
        passed = all(c.severity != Severity.FAIL for c in checks)
        return VerificationReport(
            passed=passed,
            checks=checks,
            total_duration_ms=(time.monotonic() - start) * 1000,
        )


def _ms(t0: float) -> float:
    """Elapsed milliseconds since *t0*."""
    return (time.monotonic() - t0) * 1000
