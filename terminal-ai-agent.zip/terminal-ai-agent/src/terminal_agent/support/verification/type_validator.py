"""Type validator — check type correctness where applicable.

Runs type checkers (mypy, pyright, tsc) for languages that support
static typing.  Falls back to basic type inference for others.
"""

from __future__ import annotations

import json
import logging
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.type_validator")

# Type checkers we can invoke
_TYPE_CHECKERS: dict[str, dict[str, Any]] = {
    "python": {
        "cmd": ["python3", "-m", "mypy", "--no-error-summary", "--no-color-output"],
        "ext": ".py",
    },
    "typescript": {
        "cmd": ["npx", "tsc", "--noEmit", "--pretty", "false"],
        "ext": ".ts",
    },
}


class TypeValidator:
    """Run static type checkers on generated code.

    For Python files, uses mypy.  For TypeScript, uses tsc.  Other
    languages are skipped (no type checker available by default).

    Usage::

        validator = TypeValidator()
        result = validator.validate(tool_call, tool_result, context)
    """

    def __init__(self, timeout: int = 30) -> None:
        self._timeout = timeout

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Run type validation if applicable."""
        t0 = time.monotonic()

        if tool_call.name not in ("write_file", "edit_file"):
            return CheckResult(
                name="type_check", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message="Not a file-writing tool",
                duration_ms=_ms(t0),
            )

        path = self._extract_path(tool_call)
        language = self._detect_language(path, context)

        if not language or language not in _TYPE_CHECKERS:
            return CheckResult(
                name="type_check", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message=f"No type checker for '{language}'",
                duration_ms=_ms(t0),
            )

        checker = _TYPE_CHECKERS[language]
        code = self._extract_code(tool_call)
        if not code:
            return CheckResult(
                name="type_check", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message="No code content to type-check",
                duration_ms=_ms(t0),
            )

        # Write to temp file and run checker
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=checker["ext"], delete=False
            ) as f:
                f.write(code)
                temp_path = f.name

            cmd = checker["cmd"] + [temp_path]
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=self._timeout
            )

            if result.returncode != 0:
                errors = result.stdout.strip()[:1000]
                error_count = errors.count("\n") + 1
                return CheckResult(
                    name="type_check", stage=VerificationStage.LOGIC,
                    severity=Severity.WARN,  # type errors are warnings, not hard failures
                    message=f"Type checker found {error_count} issue(s)",
                    details={"output": errors, "checker": language},
                    duration_ms=_ms(t0),
                )

            return CheckResult(
                name="type_check", stage=VerificationStage.LOGIC,
                severity=Severity.PASS,
                message=f"Type check passed ({language})",
                duration_ms=_ms(t0),
            )

        except subprocess.TimeoutExpired:
            return CheckResult(
                name="type_check", stage=VerificationStage.LOGIC,
                severity=Severity.WARN,
                message=f"Type checker timed out after {self._timeout}s",
                duration_ms=_ms(t0),
            )
        except FileNotFoundError:
            return CheckResult(
                name="type_check", stage=VerificationStage.LOGIC,
                severity=Severity.SKIP,
                message=f"Type checker not installed for {language}",
                duration_ms=_ms(t0),
            )
        except Exception as e:
            return CheckResult(
                name="type_check", stage=VerificationStage.LOGIC,
                severity=Severity.WARN,
                message=f"Type check error: {e}",
                duration_ms=_ms(t0),
            )
        finally:
            try:
                Path(temp_path).unlink(missing_ok=True)  # type: ignore[name-defined]
            except Exception:
                pass

    # ── helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _extract_path(tool_call: ToolCall) -> str:
        params = tool_call.parameters
        for key in ("path", "file", "file_path", "target"):
            if key in params:
                return str(params[key])
        return ""

    @staticmethod
    def _extract_code(tool_call: ToolCall) -> str:
        params = tool_call.parameters
        for key in ("content", "new_content", "replacement"):
            if key in params:
                return str(params[key])
        return ""

    @staticmethod
    def _detect_language(path: str, context: dict[str, Any]) -> str | None:
        if path.endswith(".py") or path.endswith(".pyi"):
            return "python"
        if path.endswith(".ts") or path.endswith(".tsx"):
            return "typescript"
        if "language" in context:
            return context["language"]
        return None


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
