"""Syntax validator — check generated code for syntax errors.

Supports Python, JavaScript/TypeScript, Go, Rust, Java, C/C++, Ruby,
PHP, shell scripts, JSON, YAML, TOML, XML, and HTML/CSS.
"""

from __future__ import annotations

import ast
import json
import logging
import re
import time
from typing import Any

from terminal_agent.types import ToolCall, ToolResult, VerificationStage
from terminal_agent.support.verification.engine import CheckResult, Severity

logger = logging.getLogger("terminal_agent.support.verification.syntax_validator")

# Map file extensions → language identifiers
_EXT_LANG: dict[str, str] = {
    ".py": "python", ".pyi": "python",
    ".js": "javascript", ".mjs": "javascript", ".cjs": "javascript",
    ".ts": "typescript", ".tsx": "typescript", ".mts": "typescript",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".c": "c", ".h": "c",
    ".cpp": "cpp", ".cxx": "cpp", ".cc": "cpp", ".hpp": "cpp",
    ".rb": "ruby",
    ".php": "php",
    ".sh": "shell", ".bash": "shell", ".zsh": "shell",
    ".json": "json",
    ".yaml": "yaml", ".yml": "yaml",
    ".toml": "toml",
    ".xml": "xml",
    ".html": "html", ".htm": "html",
    ".css": "css",
    ".sql": "sql",
    ".lua": "lua",
    ".swift": "swift",
    ".kt": "kotlin", ".kts": "kotlin",
    ".scala": "scala",
    ".dart": "dart",
    ".r": "r", ".R": "r",
}


class SyntaxValidator:
    """Validate syntax of generated or modified code files.

    Usage::

        validator = SyntaxValidator()
        result = validator.validate(tool_call, tool_result, context)
    """

    def validate(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> CheckResult:
        """Check syntax of any code written by the tool call."""
        t0 = time.monotonic()

        # Only check write/edit tool calls
        if tool_call.name not in ("write_file", "edit_file", "execute_command"):
            return CheckResult(
                name="syntax", stage=VerificationStage.FORMAT,
                severity=Severity.SKIP,
                message="Not a code-writing tool",
                duration_ms=_ms(t0),
            )

        # Get the code content
        code = self._extract_code(tool_call, tool_result)
        if not code:
            return CheckResult(
                name="syntax", stage=VerificationStage.FORMAT,
                severity=Severity.SKIP,
                message="No code content to validate",
                duration_ms=_ms(t0),
            )

        # Determine language
        path = self._extract_path(tool_call)
        language = self._detect_language(path, code, context)

        if not language:
            return CheckResult(
                name="syntax", stage=VerificationStage.FORMAT,
                severity=Severity.SKIP,
                message="Could not determine language for syntax check",
                duration_ms=_ms(t0),
            )

        # Run syntax check
        error = self._check_syntax(code, language)
        if error:
            return CheckResult(
                name="syntax", stage=VerificationStage.FORMAT,
                severity=Severity.FAIL,
                message=f"Syntax error ({language}): {error}",
                details={"language": language, "error": error},
                duration_ms=_ms(t0),
            )

        return CheckResult(
            name="syntax", stage=VerificationStage.FORMAT,
            severity=Severity.PASS,
            message=f"Syntax OK ({language})",
            duration_ms=_ms(t0),
        )

    # ── language-specific syntax checkers ───────────────────────────

    def _check_syntax(self, code: str, language: str) -> str | None:
        """Return error message or None if syntax is OK."""
        try:
            if language == "python":
                return self._check_python(code)
            elif language in ("javascript", "typescript"):
                return self._check_js_ts(code, language)
            elif language == "json":
                return self._check_json(code)
            elif language in ("yaml", "yml"):
                return self._check_yaml(code)
            elif language == "toml":
                return self._check_toml(code)
            elif language == "xml" or language == "html":
                return self._check_xml(code)
            elif language == "shell":
                return self._check_shell(code)
            elif language == "go":
                return self._check_go(code)
            elif language == "rust":
                return self._check_rust(code)
            elif language in ("c", "cpp"):
                return self._check_c_cpp(code)
            else:
                # No specific checker — skip
                return None
        except Exception as e:
            logger.debug("Syntax checker for %s raised: %s", language, e)
            return None

    @staticmethod
    def _check_python(code: str) -> str | None:
        try:
            ast.parse(code)
            return None
        except SyntaxError as e:
            return f"Line {e.lineno}: {e.msg}"

    @staticmethod
    def _check_json(code: str) -> str | None:
        try:
            json.loads(code)
            return None
        except json.JSONDecodeError as e:
            return f"Line {e.lineno}, Col {e.colno}: {e.msg}"

    @staticmethod
    def _check_yaml(code: str) -> str | None:
        try:
            import yaml
            yaml.safe_load(code)
            return None
        except Exception as e:
            return str(e)[:200]

    @staticmethod
    def _check_toml(code: str) -> str | None:
        try:
            import tomllib
            tomllib.loads(code)
            return None
        except Exception as e:
            # Python < 3.11 or parse error
            try:
                import tomli
                tomli.loads(code)
                return None
            except Exception as e2:
                return str(e2)[:200]

    @staticmethod
    def _check_xml(code: str) -> str | None:
        try:
            import xml.etree.ElementTree as ET
            ET.fromstring(code)
            return None
        except ET.ParseError as e:
            return str(e)[:200]

    @staticmethod
    def _check_shell(code: str) -> str | None:
        """Basic shell syntax check using bash -n."""
        import subprocess
        try:
            result = subprocess.run(
                ["bash", "-n", "-c", code],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode != 0:
                return result.stderr.strip()[:200]
            return None
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return None  # bash not available

    @staticmethod
    def _check_js_ts(code: str, language: str) -> str | None:
        """Basic JS/TS syntax check — looks for obvious issues."""
        # Count braces/parens balance
        opens = code.count("{") + code.count("(") + code.count("[")
        closes = code.count("}") + code.count(")") + code.count("]")
        if abs(opens - closes) > 2:
            return f"Brace/parenthesis imbalance (opens={opens}, closes={closes})"
        return None

    @staticmethod
    def _check_go(code: str) -> str | None:
        """Basic Go syntax check — verify package declaration exists."""
        if "package " not in code and len(code.strip()) > 50:
            return "Missing package declaration"
        return None

    @staticmethod
    def _check_rust(code: str) -> str | None:
        """Basic Rust syntax check — brace balance."""
        opens = code.count("{")
        closes = code.count("}")
        if abs(opens - closes) > 1:
            return f"Brace imbalance (opens={opens}, closes={closes})"
        return None

    @staticmethod
    def _check_c_cpp(code: str) -> str | None:
        """Basic C/C++ syntax check — brace balance."""
        opens = code.count("{")
        closes = code.count("}")
        if abs(opens - closes) > 1:
            return f"Brace imbalance (opens={opens}, closes={closes})"
        return None

    # ── helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _extract_code(tool_call: ToolCall, result: ToolResult) -> str:
        """Extract the code content from tool parameters or result."""
        params = tool_call.parameters
        # For write_file, the content is in parameters
        if "content" in params:
            return str(params["content"])
        # For edit_file, the new content might be in parameters
        if "new_content" in params:
            return str(params["new_content"])
        if "replacement" in params:
            return str(params["replacement"])
        # For execute_command, check if it's a code-writing command
        cmd = params.get("command", params.get("cmd", ""))
        if any(marker in cmd for marker in ("cat >", "tee", "echo '")):
            return result.output
        return ""

    @staticmethod
    def _extract_path(tool_call: ToolCall) -> str:
        """Extract the file path from tool parameters."""
        params = tool_call.parameters
        for key in ("path", "file", "file_path", "target"):
            if key in params:
                return str(params[key])
        return ""

    @staticmethod
    def _detect_language(
        path: str, code: str, context: dict[str, Any]
    ) -> str | None:
        """Detect the programming language."""
        # From file extension
        if path:
            for ext, lang in _EXT_LANG.items():
                if path.endswith(ext):
                    return lang

        # From context
        if "language" in context:
            return context["language"]

        # Heuristic from code content
        if code.startswith("#!"):
            first_line = code.split("\n", 1)[0]
            if "python" in first_line:
                return "python"
            if "bash" in first_line or "sh" in first_line:
                return "shell"
            if "node" in first_line:
                return "javascript"

        if re.search(r"\bdef\s+\w+\s*\(", code):
            return "python"
        if re.search(r"\bfunction\s+\w+\s*\(", code) or "=>" in code:
            return "javascript"
        if re.search(r"\bfn\s+\w+\s*\(", code):
            return "rust"
        if re.search(r"\bfunc\s+\w+\s*\(", code):
            return "go"

        return None


def _ms(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
