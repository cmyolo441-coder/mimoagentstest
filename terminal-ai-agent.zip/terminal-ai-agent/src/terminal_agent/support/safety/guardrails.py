"""Main safety guardrails — the central gate for all tool executions.

Coordinates pattern matching, path control, destructive detection,
blocked command registry, and confirmation prompts.  Every tool call
passes through ``SafetyGuardrails.evaluate()`` before execution.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from terminal_agent.exceptions import (
    CommandBlockedError,
    ConfirmationRequiredError,
    SafetyError,
)
from terminal_agent.types import SafetyLevel, ToolCall, ToolResult
from terminal_agent.support.safety.audit import AuditLogger
from terminal_agent.support.safety.blocked_commands import BlockedCommandRegistry
from terminal_agent.support.safety.confirmation import ConfirmationManager
from terminal_agent.support.safety.destructive_detector import DestructiveDetector
from terminal_agent.support.safety.emergency_stop import EmergencyStop
from terminal_agent.support.safety.path_controller import PathController
from terminal_agent.support.safety.patterns import CommandPatternMatcher

logger = logging.getLogger("terminal_agent.support.safety.guardrails")


class SafetyDecision(str, Enum):
    """Possible safety evaluation outcomes."""
    ALLOW = "allow"
    CONFIRM = "confirm"
    BLOCK = "block"
    EMERGENCY_STOP = "emergency_stop"


@dataclass
class SafetyVerdict:
    """Result of a safety evaluation."""
    decision: SafetyDecision
    reason: str
    tool_call: ToolCall
    safety_level: SafetyLevel
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def allowed(self) -> bool:
        return self.decision == SafetyDecision.ALLOW

    @property
    def needs_confirmation(self) -> bool:
        return self.decision == SafetyDecision.CONFIRM

    @property
    def blocked(self) -> bool:
        return self.decision in (SafetyDecision.BLOCK, SafetyDecision.EMERGENCY_STOP)


class SafetyGuardrails:
    """Central safety gate for all tool executions.

    Coordinates all safety subsystems and produces a verdict for every
    proposed tool call.  The verdict is one of ALLOW, CONFIRM, BLOCK,
    or EMERGENCY_STOP.

    Usage::

        guardrails = SafetyGuardrails(safety_level=SafetyLevel.STANDARD)
        verdict = guardrails.evaluate(tool_call)
        if verdict.allowed:
            # execute
        elif verdict.needs_confirmation:
            # prompt user
        else:
            # blocked
    """

    # Tools that are read-only and generally safe at any level
    _READ_ONLY_TOOLS: frozenset[str] = frozenset({
        "read_file", "list_directory", "search_files", "search_code",
        "get_metadata", "show_diff", "git_status", "git_log",
        "git_diff", "git_blame", "process_list", "disk_usage",
        "check_port", "dns_lookup", "ping", "http_get",
    })

    # Tools that modify state but are low-risk
    _LOW_RISK_TOOLS: frozenset[str] = frozenset({
        "write_file", "edit_file", "create_directory", "copy_file",
        "git_add", "git_commit", "git_push", "run_tests",
        "format_code", "lint_code",
    })

    # Tools that can cause significant changes
    _HIGH_RISK_TOOLS: frozenset[str] = frozenset({
        "delete_file", "delete_directory", "move_file", "execute_command",
        "git_reset", "git_rebase", "install_package", "uninstall_package",
        "docker_run", "docker_rm", "database_execute", "terraform_apply",
        "kubernetes_apply",
    })

    def __init__(
        self,
        safety_level: SafetyLevel = SafetyLevel.STANDARD,
        *,
        audit_logger: AuditLogger | None = None,
        emergency_stop: EmergencyStop | None = None,
    ) -> None:
        self._safety_level = safety_level
        self._audit = audit_logger or AuditLogger()
        self._emergency = emergency_stop or EmergencyStop()

        # Sub-systems
        self._patterns = CommandPatternMatcher()
        self._blocked = BlockedCommandRegistry()
        self._path_ctrl = PathController()
        self._destructive = DestructiveDetector()
        self._confirmation = ConfirmationManager()

    # ── public API ──────────────────────────────────────────────────

    @property
    def safety_level(self) -> SafetyLevel:
        return self._safety_level

    @safety_level.setter
    def safety_level(self, level: SafetyLevel) -> None:
        logger.info("Safety level changed: %s → %s", self._safety_level, level)
        self._safety_level = level

    def evaluate(self, tool_call: ToolCall) -> SafetyVerdict:
        """Evaluate a proposed tool call against all safety rules.

        Returns a ``SafetyVerdict`` with one of ALLOW, CONFIRM, BLOCK,
        or EMERGENCY_STOP.
        """
        # Check emergency stop first
        if self._emergency.is_active:
            verdict = SafetyVerdict(
                decision=SafetyDecision.EMERGENCY_STOP,
                reason="Emergency stop is active — all execution halted",
                tool_call=tool_call,
                safety_level=self._safety_level,
            )
            self._audit.log_verdict(verdict)
            return verdict

        # Level 0 — unrestricted
        if self._safety_level == SafetyLevel.UNRESTRICTED:
            verdict = SafetyVerdict(
                decision=SafetyDecision.ALLOW,
                reason="Safety level 0 (unrestricted)",
                tool_call=tool_call,
                safety_level=self._safety_level,
            )
            self._audit.log_verdict(verdict)
            return verdict

        # Level 5 — review: everything needs confirmation
        if self._safety_level == SafetyLevel.REVIEW:
            verdict = SafetyVerdict(
                decision=SafetyDecision.CONFIRM,
                reason="Safety level 5 (review) — all actions require approval",
                tool_call=tool_call,
                safety_level=self._safety_level,
            )
            self._audit.log_verdict(verdict)
            return verdict

        # Run through checks in order of severity
        checks = [
            self._check_blocked,
            self._check_patterns,
            self._check_paths,
            self._check_destructive,
            self._check_tool_risk,
        ]

        for check in checks:
            result = check(tool_call)
            if result is not None:
                self._audit.log_verdict(result)
                return result

        # Default: allow
        verdict = SafetyVerdict(
            decision=SafetyDecision.ALLOW,
            reason="All safety checks passed",
            tool_call=tool_call,
            safety_level=self._safety_level,
        )
        self._audit.log_verdict(verdict)
        return verdict

    def add_blocked_pattern(self, pattern: str) -> None:
        """Add a custom blocked command pattern."""
        self._blocked.add_pattern(pattern)

    def add_restricted_path(self, path: str) -> None:
        """Add a custom restricted path."""
        self._path_ctrl.add_restricted(path)

    def add_allowed_path(self, path: str) -> None:
        """Add a custom allowed path."""
        self._path_ctrl.add_allowed(path)

    # ── internal checks ─────────────────────────────────────────────

    def _check_blocked(self, tool_call: ToolCall) -> SafetyVerdict | None:
        """Check against the blocked command registry."""
        command = self._extract_command(tool_call)
        if command and self._blocked.is_blocked(command):
            return SafetyVerdict(
                decision=SafetyDecision.BLOCK,
                reason=f"Command matches blocked pattern: {command[:80]}",
                tool_call=tool_call,
                safety_level=self._safety_level,
                details={"blocked_command": command},
            )
        return None

    def _check_patterns(self, tool_call: ToolCall) -> SafetyVerdict | None:
        """Check command against dangerous pattern matcher."""
        command = self._extract_command(tool_call)
        if command and self._safety_level >= SafetyLevel.MINIMAL:
            match = self._patterns.match(command)
            if match:
                severity = match.get("severity", "high")
                if severity == "critical" or self._safety_level >= SafetyLevel.STANDARD:
                    return SafetyVerdict(
                        decision=SafetyDecision.BLOCK,
                        reason=f"Dangerous pattern detected: {match['description']}",
                        tool_call=tool_call,
                        safety_level=self._safety_level,
                        details={"pattern_match": match},
                    )
        return None

    def _check_paths(self, tool_call: ToolCall) -> SafetyVerdict | None:
        """Check path access restrictions."""
        paths = self._extract_paths(tool_call)
        for path in paths:
            if not self._path_ctrl.is_allowed(path):
                return SafetyVerdict(
                    decision=SafetyDecision.BLOCK,
                    reason=f"Path access restricted: {path}",
                    tool_call=tool_call,
                    safety_level=self._safety_level,
                    details={"restricted_path": path},
                )
        return None

    def _check_destructive(self, tool_call: ToolCall) -> SafetyVerdict | None:
        """Check for destructive operations."""
        command = self._extract_command(tool_call)
        if command and self._destructive.is_destructive(command):
            if self._safety_level >= SafetyLevel.MODERATE:
                return SafetyVerdict(
                    decision=SafetyDecision.CONFIRM,
                    reason="Destructive operation detected",
                    tool_call=tool_call,
                    safety_level=self._safety_level,
                    details={"destructive": True},
                )
        return None

    def _check_tool_risk(self, tool_call: ToolCall) -> SafetyVerdict | None:
        """Check tool risk level against safety level."""
        tool = tool_call.name
        level = self._safety_level

        if tool in self._HIGH_RISK_TOOLS and level >= SafetyLevel.STANDARD:
            return SafetyVerdict(
                decision=SafetyDecision.CONFIRM,
                reason=f"High-risk tool '{tool}' requires confirmation at level {level.name}",
                tool_call=tool_call,
                safety_level=self._safety_level,
                details={"risk": "high"},
            )

        if tool in self._LOW_RISK_TOOLS and level >= SafetyLevel.MODERATE:
            return SafetyVerdict(
                decision=SafetyDecision.CONFIRM,
                reason=f"Tool '{tool}' requires confirmation at level {level.name}",
                tool_call=tool_call,
                safety_level=self._safety_level,
                details={"risk": "low"},
            )

        if level >= SafetyLevel.STRICT and tool not in self._READ_ONLY_TOOLS:
            return SafetyVerdict(
                decision=SafetyDecision.CONFIRM,
                reason=f"Strict mode — all non-read-only tools require confirmation",
                tool_call=tool_call,
                safety_level=self._safety_level,
                details={"risk": "any"},
            )

        return None

    # ── helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _extract_command(tool_call: ToolCall) -> str | None:
        """Extract a command string from tool parameters."""
        params = tool_call.parameters
        for key in ("command", "cmd", "script", "expression"):
            if key in params:
                return str(params[key])
        return None

    @staticmethod
    def _extract_paths(tool_call: ToolCall) -> list[str]:
        """Extract file paths from tool parameters."""
        params = tool_call.parameters
        paths: list[str] = []
        for key in ("path", "file", "file_path", "source", "destination",
                     "directory", "dir", "target"):
            if key in params:
                val = params[key]
                if isinstance(val, str):
                    paths.append(val)
                elif isinstance(val, list):
                    paths.extend(str(v) for v in val)
        return paths
