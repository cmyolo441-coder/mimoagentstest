"""Confirmation prompt generation for risky operations.

Builds clear, human-readable confirmation messages so users understand
exactly what the agent is about to do before they approve it.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import ToolCall

logger = logging.getLogger("terminal_agent.support.safety.confirmation")


@dataclass
class ConfirmationRequest:
    """A confirmation prompt to present to the user."""
    tool_call: ToolCall
    risk_level: str  # "critical", "high", "medium", "low"
    summary: str
    details: list[str] = field(default_factory=list)
    consequences: list[str] = field(default_factory=list)
    alternatives: list[str] = field(default_factory=list)
    requires_reason: bool = False


class ConfirmationManager:
    """Build and manage confirmation prompts for risky tool calls.

    Usage::

        mgr = ConfirmationManager()
        request = mgr.build_request(tool_call, risk_level="high",
                                     reason="Recursive deletion detected")
        print(request.summary)
    """

    # Descriptions of what each tool does (human-readable)
    _TOOL_DESCRIPTIONS: dict[str, str] = {
        "execute_command": "Run a shell command",
        "write_file": "Create or overwrite a file",
        "edit_file": "Modify a file in-place",
        "delete_file": "Delete a file",
        "delete_directory": "Delete a directory and its contents",
        "move_file": "Move or rename a file",
        "copy_file": "Copy a file",
        "git_push": "Push commits to a remote repository",
        "git_reset": "Reset the repository to a specific state",
        "git_rebase": "Rebase the current branch",
        "install_package": "Install a package",
        "uninstall_package": "Remove an installed package",
        "database_execute": "Execute a database query",
        "docker_run": "Start a Docker container",
        "docker_rm": "Remove a Docker container",
        "terraform_apply": "Apply Terraform infrastructure changes",
        "kubernetes_apply": "Apply Kubernetes manifests",
    }

    def build_request(
        self,
        tool_call: ToolCall,
        risk_level: str = "medium",
        reason: str = "",
        *,
        details: list[str] | None = None,
        consequences: list[str] | None = None,
        alternatives: list[str] | None = None,
    ) -> ConfirmationRequest:
        """Build a confirmation request for *tool_call*.

        Args:
            tool_call: The proposed tool call.
            risk_level: One of critical/high/medium/low.
            reason: Why confirmation is needed.
            details: Extra detail lines to show the user.
            consequences: What happens if the user approves.
            alternatives: Safer alternatives the user could choose.

        Returns:
            A ``ConfirmationRequest`` ready for display.
        """
        tool_desc = self._TOOL_DESCRIPTIONS.get(tool_call.name, tool_call.name)
        params = tool_call.parameters

        summary_parts = [f"⚠️  [{risk_level.upper()}] {tool_desc}"]

        # Add specific context based on tool type
        detail_lines = list(details or [])
        consequence_lines = list(consequences or [])
        alt_lines = list(alternatives or [])

        if tool_call.name == "execute_command":
            cmd = params.get("command", params.get("cmd", ""))
            if cmd:
                summary_parts.append(f"Command: `{cmd}`")
                consequence_lines.extend(self._analyze_command_consequences(cmd))

        elif tool_call.name in ("write_file", "edit_file"):
            path = params.get("path", params.get("file", ""))
            if path:
                summary_parts.append(f"File: `{path}`")

        elif tool_call.name in ("delete_file", "delete_directory"):
            path = params.get("path", params.get("directory", ""))
            if path:
                summary_parts.append(f"Target: `{path}`")
                consequence_lines.append(f"⚠️  {'File' if tool_call.name == 'delete_file' else 'Directory'} will be permanently deleted")
                alt_lines.append("Use `trash` instead of `rm` for recoverable deletion")

        elif tool_call.name == "database_execute":
            query = params.get("query", params.get("sql", ""))
            if query:
                summary_parts.append(f"Query: `{query[:200]}`")

        elif tool_call.name == "git_push":
            remote = params.get("remote", "origin")
            branch = params.get("branch", "")
            force = params.get("force", False)
            summary_parts.append(f"Remote: {remote}, Branch: {branch}")
            if force:
                consequence_lines.append("⚠️  Force push will overwrite remote history")
                alt_lines.append("Use `git push --force-with-lease` for safer force push")

        if reason:
            detail_lines.insert(0, f"Reason: {reason}")

        return ConfirmationRequest(
            tool_call=tool_call,
            risk_level=risk_level,
            summary=" ".join(summary_parts),
            details=detail_lines,
            consequences=consequence_lines,
            alternatives=alt_lines,
            requires_reason=risk_level == "critical",
        )

    def format_prompt(self, request: ConfirmationRequest) -> str:
        """Format a confirmation request as a user-facing prompt string."""
        lines = [request.summary, ""]

        if request.details:
            lines.append("Details:")
            for d in request.details:
                lines.append(f"  • {d}")
            lines.append("")

        if request.consequences:
            lines.append("Consequences:")
            for c in request.consequences:
                lines.append(f"  • {c}")
            lines.append("")

        if request.alternatives:
            lines.append("Alternatives:")
            for a in request.alternatives:
                lines.append(f"  • {a}")
            lines.append("")

        lines.append("Approve? [y/N] ")
        return "\n".join(lines)

    # ── helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _analyze_command_consequences(command: str) -> list[str]:
        """Infer consequences from a shell command."""
        consequences: list[str] = []
        lower = command.lower().strip()

        if "rm " in lower:
            consequences.append("Files/directories will be deleted")
        if " > " in lower or " >> " in lower:
            consequences.append("File contents will be overwritten or appended")
        if "sudo " in lower:
            consequences.append("Command runs with elevated (root) privileges")
        if "curl " in lower and ("| sh" in lower or "| bash" in lower):
            consequences.append("Remote code will be executed directly")
        if "git push" in lower:
            consequences.append("Commits will be pushed to remote repository")
        if "docker" in lower and "rm" in lower:
            consequences.append("Docker containers/images will be removed")
        if "pip install" in lower or "npm install" in lower:
            consequences.append("New packages will be installed")
        if "apt " in lower and ("install" in lower or "remove" in lower):
            consequences.append("System packages will be modified")

        return consequences
