"""Emergency stop mechanism — immediate halt of all agent execution.

Provides a thread-safe, signal-aware mechanism to instantly stop all
agent activity.  Can be triggered programmatically, via signal handler,
or by an external watchdog.
"""

from __future__ import annotations

import logging
import signal
import threading
import time
from typing import Callable

logger = logging.getLogger("terminal_agent.support.safety.emergency_stop")


class EmergencyStop:
    """Thread-safe emergency stop for the agent.

    When activated, ``is_active`` returns ``True`` and all safety
    checks should return EMERGENCY_STOP.  The orchestrator's main
    loop checks this flag between iterations.

    Usage::

        stop = EmergencyStop()
        stop.activate("User pressed Ctrl+C three times")
        # ...
        stop.deactivate()

        # Register signal handlers
        stop.install_signal_handlers()
    """

    def __init__(self) -> None:
        self._active = False
        self._reason = ""
        self._activated_at: float = 0.0
        self._lock = threading.Lock()
        self._callbacks: list[Callable[[str], None]] = []
        self._original_sigint: signal.Handlers | None = None
        self._original_sigterm: signal.Handlers | None = None

    # ── public API ──────────────────────────────────────────────────

    @property
    def is_active(self) -> bool:
        """Whether emergency stop is currently active."""
        return self._active

    @property
    def reason(self) -> str:
        """The reason for the emergency stop."""
        return self._reason

    @property
    def activated_at(self) -> float:
        """Timestamp when emergency stop was activated (0 if not active)."""
        return self._activated_at

    def activate(self, reason: str = "Emergency stop triggered") -> None:
        """Activate emergency stop.

        Thread-safe.  Idempotent — calling when already active just
        updates the reason.
        """
        with self._lock:
            was_active = self._active
            self._active = True
            self._reason = reason
            self._activated_at = time.time()

        if not was_active:
            logger.critical("EMERGENCY STOP ACTIVATED: %s", reason)

        # Fire callbacks (outside lock to avoid deadlocks)
        if not was_active:
            for cb in self._callbacks:
                try:
                    cb(reason)
                except Exception as e:
                    logger.warning("Emergency stop callback error: %s", e)

    def deactivate(self) -> None:
        """Deactivate emergency stop and resume normal operation."""
        with self._lock:
            if self._active:
                logger.info("Emergency stop deactivated (was: %s)", self._reason)
                self._active = False
                self._reason = ""
                self._activated_at = 0.0

    def on_activate(self, callback: Callable[[str], None]) -> None:
        """Register a callback to be called when emergency stop fires.

        The callback receives the reason string.
        """
        self._callbacks.append(callback)

    def install_signal_handlers(self) -> None:
        """Install SIGINT/SIGTERM handlers for emergency stop.

        - First SIGINT → graceful interrupt (normal cancellation)
        - Second SIGINT within 2s → emergency stop
        - SIGTERM → immediate emergency stop
        """
        self._original_sigint = signal.getsignal(signal.SIGINT)
        self._original_sigterm = signal.getsignal(signal.SIGTERM)

        self._last_sigint_time = 0.0

        def _sigint_handler(signum: int, frame: object) -> None:
            now = time.time()
            if now - self._last_sigint_time < 2.0:
                self.activate("User pressed Ctrl+C twice — emergency stop")
            else:
                logger.info("Interrupt received. Press Ctrl+C again within 2s for emergency stop.")
            self._last_sigint_time = now

        def _sigterm_handler(signum: int, frame: object) -> None:
            self.activate("SIGTERM received — emergency stop")

        try:
            signal.signal(signal.SIGINT, _sigint_handler)
            signal.signal(signal.SIGTERM, _sigterm_handler)
            logger.debug("Emergency stop signal handlers installed")
        except (OSError, ValueError) as e:
            # May fail in threads or restricted environments
            logger.warning("Could not install signal handlers: %s", e)

    def uninstall_signal_handlers(self) -> None:
        """Restore original signal handlers."""
        if self._original_sigint is not None:
            try:
                signal.signal(signal.SIGINT, self._original_sigint)
            except (OSError, ValueError):
                pass
        if self._original_sigterm is not None:
            try:
                signal.signal(signal.SIGTERM, self._original_sigterm)
            except (OSError, ValueError):
                pass

    def wait_for_stop(self, timeout: float | None = None) -> bool:
        """Block until emergency stop is activated or timeout.

        Returns ``True`` if stop was activated, ``False`` on timeout.
        """
        deadline = time.time() + timeout if timeout else float("inf")
        while not self._active:
            if time.time() >= deadline:
                return False
            time.sleep(0.1)
        return True
