"""Command pattern matching for dangerous shell commands.

Maintains a library of regex patterns that match known-dangerous shell
commands (fork bombs, disk wipes, permission escalations, etc.).  Each
pattern carries a severity level and human-readable description.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class DangerousPattern:
    """A single dangerous-command pattern."""
    name: str
    regex: str
    severity: str  # "critical", "high", "medium"
    description: str
    _compiled: re.Pattern[str] | None = None

    def compiled(self) -> re.Pattern[str]:
        if self._compiled is None:
            object.__setattr__(self, "_compiled", re.compile(self.regex, re.IGNORECASE))
        return self._compiled  # type: ignore[return-value]


# ── Built-in pattern library ────────────────────────────────────────

_BUILTIN_PATTERNS: list[DangerousPattern] = [
    # ── Critical: system destruction ──
    DangerousPattern(
        name="rm_root",
        regex=r"\brm\s+(-[a-zA-Z]*[rf]{1,2}[a-zA-Z]*\s+)?/\s*$",
        severity="critical",
        description="Recursive deletion of root filesystem",
    ),
    DangerousPattern(
        name="rm_rf_all",
        regex=r"\brm\s+-[a-zA-Z]*[rf]{1,2}[a-zA-Z]*\s+\*",
        severity="critical",
        description="Recursive force deletion with wildcard",
    ),
    DangerousPattern(
        name="dd_zero_disk",
        regex=r"\bdd\s+.*if=/dev/zero.*of=/dev/[a-z]",
        severity="critical",
        description="Overwriting disk with zeros (disk wipe)",
    ),
    DangerousPattern(
        name="dd_random_disk",
        regex=r"\bdd\s+.*if=/dev/urandom.*of=/dev/[a-z]",
        severity="critical",
        description="Overwriting disk with random data (disk wipe)",
    ),
    DangerousPattern(
        name="mkfs_format",
        regex=r"\bmkfs\.\w+\s+/dev/",
        severity="critical",
        description="Formatting a disk partition (destroys all data)",
    ),
    DangerousPattern(
        name="fork_bomb",
        regex=r":\(\)\s*\{\s*:\|:\&\s*\}\s*;:",
        severity="critical",
        description="Fork bomb — crashes the system by exhausting processes",
    ),
    DangerousPattern(
        name="chmod_777_recursive",
        regex=r"\bchmod\s+(-[a-zA-Z]*\s+)?777\s+(-[a-zA-Z]*\s+)?/",
        severity="critical",
        description="Recursive chmod 777 on root (exposes entire filesystem)",
    ),
    DangerousPattern(
        name="bootloader_modify",
        regex=r"\b(dd|mkfs|rm)\s+.*(/dev/sd[a-z]|/dev/nvme)",
        severity="critical",
        description="Direct disk device manipulation",
    ),

    # ── High: significant damage potential ──
    DangerousPattern(
        name="rm_rf_home",
        regex=r"\brm\s+-[a-zA-Z]*[rf]{1,2}[a-zA-Z]*\s+~",
        severity="high",
        description="Recursive deletion of home directory",
    ),
    DangerousPattern(
        name="rm_rf_var",
        regex=r"\brm\s+-[a-zA-Z]*[rf]{1,2}[a-zA-Z]*\s+/var",
        severity="high",
        description="Recursive deletion of /var (logs, databases, mail)",
    ),
    DangerousPattern(
        name="rm_rf_etc",
        regex=r"\brm\s+-[a-zA-Z]*[rf]{1,2}[a-zA-Z]*\s+/etc",
        severity="high",
        description="Recursive deletion of /etc (system configuration)",
    ),
    DangerousPattern(
        name="chmod_777_etc",
        regex=r"\bchmod\s+777\s+/etc",
        severity="high",
        description="Setting world-writable permissions on /etc",
    ),
    DangerousPattern(
        name="chown_root",
        regex=r"\bchown\s+(-[a-zA-Z]*\s+)?[^:]+\s+/",
        severity="high",
        description="Changing ownership of root-level paths",
    ),
    DangerousPattern(
        name="kill_all",
        regex=r"\bkill\s+-9\s+-1",
        severity="high",
        description="Kill all processes (sends SIGKILL to every process)",
    ),
    DangerousPattern(
        name="pkill_all",
        regex=r"\bpkill\s+(-9\s+)?-u\s+root",
        severity="high",
        description="Kill all root processes",
    ),
    DangerousPattern(
        name="shutdown_reboot",
        regex=r"\b(shutdown|reboot|halt|poweroff|init\s+0|init\s+6)\b",
        severity="high",
        description="System shutdown or reboot",
    ),
    DangerousPattern(
        name="drop_database",
        regex=r"\bDROP\s+DATABASE\b",
        severity="high",
        description="SQL DROP DATABASE — permanently deletes a database",
    ),
    DangerousPattern(
        name="drop_table",
        regex=r"\bDROP\s+TABLE\b",
        severity="high",
        description="SQL DROP TABLE — permanently deletes a table",
    ),
    DangerousPattern(
        name="truncate_table",
        regex=r"\bTRUNCATE\s+TABLE\b",
        severity="high",
        description="SQL TRUNCATE TABLE — deletes all rows",
    ),
    DangerousPattern(
        name="rm_rf_tmp",
        regex=r"\brm\s+-[a-zA-Z]*[rf]{1,2}[a-zA-Z]*\s+/tmp",
        severity="high",
        description="Recursive deletion of /tmp",
    ),
    DangerousPattern(
        name="iptables_flush",
        regex=r"\biptables\s+-F",
        severity="high",
        description="Flush all iptables rules (removes firewall protection)",
    ),
    DangerousPattern(
        name="shadow_access",
        regex=r"\b(cat|less|more|head|tail|vi|vim|nano|edit)\s+.*/etc/shadow",
        severity="high",
        description="Direct access to /etc/shadow (password hashes)",
    ),
    DangerousPattern(
        name="curl_pipe_sh",
        regex=r"\bcurl\s+.*\|\s*(ba)?sh",
        severity="high",
        description="Piping remote script directly to shell (supply chain risk)",
    ),
    DangerousPattern(
        name="wget_pipe_sh",
        regex=r"\bwget\s+.*\|\s*(ba)?sh",
        severity="high",
        description="Piping remote script directly to shell (supply chain risk)",
    ),
    DangerousPattern(
        name="eval_remote",
        regex=r"\beval\s+.*\$\((curl|wget)",
        severity="high",
        description="Evaluating remote code via eval",
    ),

    # ── Medium: risky but sometimes legitimate ──
    DangerousPattern(
        name="rm_no_interactive",
        regex=r"\brm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+)(?!.*-[a-zA-Z]*i)",
        severity="medium",
        description="Force deletion without interactive confirmation",
    ),
    DangerousPattern(
        name="chmod_777",
        regex=r"\bchmod\s+777\s",
        severity="medium",
        description="Setting world-writable permissions (chmod 777)",
    ),
    DangerousPattern(
        name="nohup_background",
        regex=r"\bnohup\s+.*&",
        severity="medium",
        description="Background process that persists after shell exit",
    ),
    DangerousPattern(
        name="ssh_keygen_overwrite",
        regex=r"\bssh-keygen\s+.*-f\s+.*\.ssh/",
        severity="medium",
        description="Overwriting SSH keys",
    ),
    DangerousPattern(
        name="git_force_push",
        regex=r"\bgit\s+push\s+.*--force",
        severity="medium",
        description="Force push to remote (can overwrite history)",
    ),
    DangerousPattern(
        name="git_reset_hard",
        regex=r"\bgit\s+reset\s+--hard",
        severity="medium",
        description="Hard reset — discards all uncommitted changes",
    ),
    DangerousPattern(
        name="env_secrets",
        regex=r"\b(env|printenv|set)\b.*\b(API_KEY|SECRET|PASSWORD|TOKEN)\b",
        severity="medium",
        description="Exposing secret environment variables",
    ),
]


class CommandPatternMatcher:
    """Match shell commands against known-dangerous patterns.

    Usage::

        matcher = CommandPatternMatcher()
        result = matcher.match("rm -rf /")
        # {'name': 'rm_root', 'severity': 'critical', ...}
    """

    def __init__(self, *, include_builtin: bool = True) -> None:
        self._patterns: list[DangerousPattern] = []
        if include_builtin:
            self._patterns.extend(_BUILTIN_PATTERNS)

    def add_pattern(self, pattern: DangerousPattern) -> None:
        """Add a custom dangerous pattern."""
        self._patterns.append(pattern)

    def add_pattern_simple(
        self,
        name: str,
        regex: str,
        severity: str = "high",
        description: str = "",
    ) -> None:
        """Add a custom pattern from simple parameters."""
        self._patterns.append(DangerousPattern(
            name=name,
            regex=regex,
            severity=severity,
            description=description or f"Custom pattern: {name}",
        ))

    def match(self, command: str) -> dict[str, Any] | None:
        """Check *command* against all patterns.

        Returns a dict with pattern info on first match, or ``None``.
        """
        for pattern in self._patterns:
            if pattern.compiled().search(command):
                return {
                    "name": pattern.name,
                    "severity": pattern.severity,
                    "description": pattern.description,
                    "regex": pattern.regex,
                }
        return None

    def match_all(self, command: str) -> list[dict[str, Any]]:
        """Return *all* matching patterns (not just the first)."""
        matches: list[dict[str, Any]] = []
        for pattern in self._patterns:
            if pattern.compiled().search(command):
                matches.append({
                    "name": pattern.name,
                    "severity": pattern.severity,
                    "description": pattern.description,
                    "regex": pattern.regex,
                })
        return matches

    @property
    def pattern_count(self) -> int:
        """Number of loaded patterns."""
        return len(self._patterns)

    def list_patterns(self) -> list[dict[str, str]]:
        """Return a summary of all loaded patterns."""
        return [
            {"name": p.name, "severity": p.severity, "description": p.description}
            for p in self._patterns
        ]
