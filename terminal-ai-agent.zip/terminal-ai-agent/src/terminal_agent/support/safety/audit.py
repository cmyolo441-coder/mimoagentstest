"""Audit trail logging for safety decisions.

Records every safety evaluation, user confirmation, blocked command,
and emergency stop event for post-hoc review and compliance.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger("terminal_agent.support.safety.audit")


class AuditEventType(str, Enum):
    """Types of audit events."""
    VERDICT = "verdict"
    CONFIRMATION = "confirmation"
    BLOCKED = "blocked"
    EMERGENCY_STOP = "emergency_stop"
    SAFETY_LEVEL_CHANGE = "safety_level_change"
    POLICY_CHANGE = "policy_change"


@dataclass
class AuditEntry:
    """A single audit trail entry."""
    timestamp: float
    event_type: AuditEventType
    summary: str
    details: dict[str, Any] = field(default_factory=dict)
    session_id: str | None = None
    tool_name: str | None = None
    safety_level: int | None = None


class AuditLogger:
    """Append-only audit trail for safety decisions.

    Writes entries to a JSON-lines file and keeps an in-memory buffer
    for recent lookups.

    Usage::

        audit = AuditLogger(log_path="/var/log/agent/audit.jsonl")
        audit.log_verdict(verdict)
        audit.log_blocked(command, reason)
        entries = audit.recent(50)
    """

    def __init__(
        self,
        log_path: str | Path | None = None,
        *,
        max_memory_entries: int = 1000,
    ) -> None:
        self._log_path = Path(log_path) if log_path else None
        self._max_memory = max_memory_entries
        self._buffer: list[AuditEntry] = []

        # Ensure parent directory exists
        if self._log_path:
            self._log_path.parent.mkdir(parents=True, exist_ok=True)

    # ── logging methods ─────────────────────────────────────────────

    def log_verdict(self, verdict: Any) -> None:
        """Log a safety verdict (from SafetyGuardrails.evaluate)."""
        entry = AuditEntry(
            timestamp=time.time(),
            event_type=AuditEventType.VERDICT,
            summary=f"{verdict.decision.value}: {verdict.reason}",
            details={
                "decision": verdict.decision.value,
                "reason": verdict.reason,
                "tool": verdict.tool_call.name,
                "parameters": _safe_params(verdict.tool_call.parameters),
                **verdict.details,
            },
            tool_name=verdict.tool_call.name,
            safety_level=verdict.safety_level.value if hasattr(verdict.safety_level, 'value') else verdict.safety_level,
        )
        self._write(entry)

    def log_blocked(self, command: str, reason: str, *, tool_name: str = "") -> None:
        """Log a blocked command."""
        entry = AuditEntry(
            timestamp=time.time(),
            event_type=AuditEventType.BLOCKED,
            summary=f"Blocked: {reason}",
            details={"command": command[:500], "reason": reason},
            tool_name=tool_name or "execute_command",
        )
        self._write(entry)

    def log_confirmation(
        self,
        tool_name: str,
        approved: bool,
        *,
        parameters: dict[str, Any] | None = None,
    ) -> None:
        """Log a user confirmation decision."""
        entry = AuditEntry(
            timestamp=time.time(),
            event_type=AuditEventType.CONFIRMATION,
            summary=f"{'Approved' if approved else 'Denied'}: {tool_name}",
            details={
                "tool": tool_name,
                "approved": approved,
                "parameters": _safe_params(parameters or {}),
            },
            tool_name=tool_name,
        )
        self._write(entry)

    def log_emergency_stop(self, reason: str = "") -> None:
        """Log an emergency stop activation."""
        entry = AuditEntry(
            timestamp=time.time(),
            event_type=AuditEventType.EMERGENCY_STOP,
            summary=f"Emergency stop activated: {reason}",
            details={"reason": reason},
        )
        self._write(entry)

    def log_safety_level_change(self, old_level: int, new_level: int) -> None:
        """Log a safety level change."""
        entry = AuditEntry(
            timestamp=time.time(),
            event_type=AuditEventType.SAFETY_LEVEL_CHANGE,
            summary=f"Safety level: {old_level} → {new_level}",
            details={"old_level": old_level, "new_level": new_level},
        )
        self._write(entry)

    def log_policy_change(self, description: str, details: dict[str, Any] | None = None) -> None:
        """Log a policy change (blocked command added, path restriction, etc.)."""
        entry = AuditEntry(
            timestamp=time.time(),
            event_type=AuditEventType.POLICY_CHANGE,
            summary=description,
            details=details or {},
        )
        self._write(entry)

    # ── query methods ───────────────────────────────────────────────

    def recent(self, count: int = 50) -> list[AuditEntry]:
        """Return the most recent audit entries from memory buffer."""
        return self._buffer[-count:]

    def by_type(self, event_type: AuditEventType, count: int = 50) -> list[AuditEntry]:
        """Filter recent entries by event type."""
        return [e for e in self._buffer if e.event_type == event_type][-count:]

    def count_since(self, timestamp: float) -> dict[str, int]:
        """Count events by type since *timestamp*."""
        counts: dict[str, int] = {}
        for entry in self._buffer:
            if entry.timestamp >= timestamp:
                key = entry.event_type.value
                counts[key] = counts.get(key, 0) + 1
        return counts

    def load_from_file(self, limit: int = 1000) -> list[AuditEntry]:
        """Load entries from the audit log file."""
        if not self._log_path or not self._log_path.exists():
            return []
        entries: list[AuditEntry] = []
        try:
            with open(self._log_path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        entries.append(AuditEntry(
                            timestamp=data["timestamp"],
                            event_type=AuditEventType(data["event_type"]),
                            summary=data["summary"],
                            details=data.get("details", {}),
                            session_id=data.get("session_id"),
                            tool_name=data.get("tool_name"),
                            safety_level=data.get("safety_level"),
                        ))
                    except (json.JSONDecodeError, KeyError):
                        continue
        except OSError as e:
            logger.warning("Failed to read audit log: %s", e)
        return entries[-limit:]

    @property
    def buffer_size(self) -> int:
        return len(self._buffer)

    # ── internals ───────────────────────────────────────────────────

    def _write(self, entry: AuditEntry) -> None:
        """Write an entry to memory buffer and log file."""
        self._buffer.append(entry)

        # Trim buffer
        if len(self._buffer) > self._max_memory:
            self._buffer = self._buffer[-self._max_memory:]

        # Write to file
        if self._log_path:
            try:
                record = asdict(entry)
                record["event_type"] = entry.event_type.value
                with open(self._log_path, "a") as f:
                    f.write(json.dumps(record, default=str) + "\n")
            except OSError as e:
                logger.warning("Failed to write audit entry: %s", e)


def _safe_params(params: dict[str, Any]) -> dict[str, Any]:
    """Truncate large parameter values for logging."""
    safe: dict[str, Any] = {}
    for k, v in params.items():
        s = str(v)
        safe[k] = s[:500] + "…" if len(s) > 500 else s
    return safe
