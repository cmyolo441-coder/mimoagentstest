"""Safety subsystem for Terminal Agent.

Provides guardrails, command blocking, path control, destructive action
detection, confirmation prompts, audit logging, emergency stop, and
sandbox isolation.

Safety Levels:
    0 — Unrestricted: No safety checks (development only)
    1 — Minimal: Block only catastrophic commands
    2 — Standard: Block destructive commands, confirm modifications
    3 — Moderate: Confirm all writes and executions
    4 — Strict: Confirm everything, read-only by default
    5 — Review: Plan only, no execution without explicit approval
"""

from __future__ import annotations

from terminal_agent.support.safety.guardrails import SafetyGuardrails
from terminal_agent.support.safety.audit import AuditLogger
from terminal_agent.support.safety.blocked_commands import BlockedCommandRegistry
from terminal_agent.support.safety.confirmation import ConfirmationManager
from terminal_agent.support.safety.destructive_detector import DestructiveDetector
from terminal_agent.support.safety.emergency_stop import EmergencyStop
from terminal_agent.support.safety.path_controller import PathController
from terminal_agent.support.safety.patterns import CommandPatternMatcher
from terminal_agent.support.safety.sandbox import Sandbox

__all__ = [
    "SafetyGuardrails",
    "AuditLogger",
    "BlockedCommandRegistry",
    "ConfirmationManager",
    "DestructiveDetector",
    "EmergencyStop",
    "PathController",
    "CommandPatternMatcher",
    "Sandbox",
]
