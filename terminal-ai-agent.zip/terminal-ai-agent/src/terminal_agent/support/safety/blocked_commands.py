"""Blocked command registry — maintains and updates the block list.

Provides exact-match and pattern-based blocking of shell commands that
should never be executed, regardless of safety level.  The registry
ships with sensible defaults and supports runtime additions.
"""

from __future__ import annotations

import logging
import re

logger = logging.getLogger("terminal_agent.support.safety.blocked_commands")

# ── Default blocked commands (exact match) ──────────────────────────

_DEFAULT_BLOCKED_EXACT: set[str] = {
    ":(){ :|:& };:",           # fork bomb
    "rm -rf /",
    "rm -rf /*",
    "rm -rf ~",
    "rm -rf $HOME",
    "mkfs",
    "dd if=/dev/zero of=/dev/sda",
    "dd if=/dev/urandom of=/dev/sda",
    "> /dev/sda",
    "chmod -R 777 /",
    "chown -R nobody /",
    "wget -O- | sh",
    "curl -sL | bash",
}

# ── Default blocked patterns (regex) ────────────────────────────────

_DEFAULT_BLOCKED_PATTERNS: list[tuple[str, str]] = [
    (r"\brm\s+(-[a-zA-Z]*[rf]{1,2}[a-zA-Z]*\s+)?/\s*$",
     "Recursive root deletion"),
    (r"\brm\s+(-[a-zA-Z]*[rf]{1,2}[a-zA-Z]*\s+)?/\*",
     "Recursive root wildcard deletion"),
    (r":\(\)\s*\{\s*:\|:\&\s*\}\s*;:",
     "Fork bomb"),
    (r"\bdd\s+.*if=/dev/(zero|urandom)\s+.*of=/dev/",
     "Disk overwrite"),
    (r"\bmkfs\b.*\s+/dev/",
     "Filesystem format"),
    (r"\bshutdown\b|\breboot\b|\bhalt\b|\bpoweroff\b",
     "System shutdown/reboot"),
    (r"\binit\s+[06]\b",
     "Runlevel change (shutdown/reboot)"),
    (r"\biptables\s+-F\b",
     "Firewall flush"),
    (r"\bmodprobe\s+-r\b.*\b(ext4|xfs|btrfs)\b",
     "Unload essential filesystem kernel module"),
]


class BlockedCommandRegistry:
    """Registry of commands that must never be executed.

    Supports both exact string matching and regex pattern matching.
    Commands are checked case-insensitively.

    Usage::

        registry = BlockedCommandRegistry()
        registry.is_blocked("rm -rf /")        # True
        registry.is_blocked("ls -la")           # False
        registry.add_exact("dangerous-cmd")
        registry.add_pattern(r"\bcustom-evil\b", "Custom evil command")
    """

    def __init__(self, *, include_defaults: bool = True) -> None:
        self._exact: set[str] = set()
        self._patterns: list[tuple[re.Pattern[str], str]] = []

        if include_defaults:
            self._exact.update(_DEFAULT_BLOCKED_EXACT)
            for regex, desc in _DEFAULT_BLOCKED_PATTERNS:
                self._patterns.append((re.compile(regex, re.IGNORECASE), desc))

    # ── public API ──────────────────────────────────────────────────

    def is_blocked(self, command: str) -> bool:
        """Check whether *command* is blocked."""
        normalized = command.strip()

        # Exact match
        if normalized in self._exact:
            return True

        # Pattern match
        for pattern, _ in self._patterns:
            if pattern.search(normalized):
                return True

        return False

    def why_blocked(self, command: str) -> str | None:
        """Return the reason *command* is blocked, or ``None``."""
        normalized = command.strip()

        if normalized in self._exact:
            return f"Exact match: '{normalized}'"

        for pattern, desc in self._patterns:
            if pattern.search(normalized):
                return f"Pattern match: {desc}"

        return None

    def add_exact(self, command: str) -> None:
        """Add an exact-match blocked command."""
        self._exact.add(command.strip())
        logger.info("Added blocked command (exact): %s", command)

    def add_pattern(self, regex: str, description: str = "") -> None:
        """Add a regex-pattern blocked command."""
        compiled = re.compile(regex, re.IGNORECASE)
        self._patterns.append((compiled, description or regex))
        logger.info("Added blocked command (pattern): %s", regex)

    def remove_exact(self, command: str) -> None:
        """Remove an exact-match blocked command."""
        self._exact.discard(command.strip())

    def remove_pattern(self, regex: str) -> None:
        """Remove a pattern by its regex string."""
        self._patterns = [
            (p, d) for p, d in self._patterns if p.pattern != regex
        ]

    @property
    def exact_count(self) -> int:
        return len(self._exact)

    @property
    def pattern_count(self) -> int:
        return len(self._patterns)

    def list_exact(self) -> list[str]:
        """Return all exact-match blocked commands."""
        return sorted(self._exact)

    def list_patterns(self) -> list[dict[str, str]]:
        """Return all pattern-match blocked commands."""
        return [{"regex": p.pattern, "description": d} for p, d in self._patterns]

    def clear(self) -> None:
        """Remove all blocked commands (use with caution)."""
        self._exact.clear()
        self._patterns.clear()
        logger.warning("Blocked command registry cleared")

    def reset_to_defaults(self) -> None:
        """Reset to default blocked commands."""
        self._exact = set(_DEFAULT_BLOCKED_EXACT)
        self._patterns = [
            (re.compile(regex, re.IGNORECASE), desc)
            for regex, desc in _DEFAULT_BLOCKED_PATTERNS
        ]
        logger.info("Blocked command registry reset to defaults")
