"""Sandbox mode — isolate agent execution in a controlled environment.

Provides filesystem and process isolation so that agent actions cannot
affect the host system.  Uses temporary directories, environment
variable overrides, and optional container-based isolation.
"""

from __future__ import annotations

import logging
import os
import shutil
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator

logger = logging.getLogger("terminal_agent.support.safety.sandbox")


class Sandbox:
    """Isolated execution environment for the agent.

    In sandbox mode:
    - All file operations are scoped to a temporary directory
    - Environment variables are overridden
    - Working directory is redirected
    - Network access can be restricted (container-level)
    - Process count can be limited (container-level)

    Usage::

        with Sandbox(work_dir="/tmp/agent-sandbox") as sb:
            # All file ops should use sb.resolve_path(original_path)
            safe_path = sb.resolve_path("/home/user/project/file.py")
            # → /tmp/agent-sandbox/home/user/project/file.py
    """

    def __init__(
        self,
        work_dir: str | Path | None = None,
        *,
        env_overrides: dict[str, str] | None = None,
        max_files: int = 10000,
        max_disk_mb: int = 5120,
        copy_on_write: bool = True,
    ) -> None:
        self._work_dir = Path(work_dir) if work_dir else None
        self._env_overrides = env_overrides or {}
        self._max_files = max_files
        self._max_disk_mb = max_disk_mb
        self._copy_on_write = copy_on_write
        self._active = False
        self._temp_dir: Path | None = None
        self._original_cwd: str = ""
        self._original_env: dict[str, str | None] = {}

    # ── public API ──────────────────────────────────────────────────

    @property
    def is_active(self) -> bool:
        return self._active

    @property
    def root(self) -> Path:
        """Sandbox root directory."""
        if self._temp_dir:
            return self._temp_dir
        if self._work_dir:
            return self._work_dir
        raise RuntimeError("Sandbox not activated")

    def activate(self) -> Path:
        """Activate the sandbox and return its root path.

        Creates a temporary directory (or uses configured work_dir),
        sets up environment overrides, and changes the working directory.
        """
        if self._active:
            return self.root

        # Create sandbox root
        if self._work_dir:
            self._work_dir.mkdir(parents=True, exist_ok=True)
            self._temp_dir = self._work_dir
        else:
            self._temp_dir = Path(tempfile.mkdtemp(prefix="agent-sandbox-"))

        # Save and override environment
        self._original_env.clear()
        for key, value in self._env_overrides.items():
            self._original_env[key] = os.environ.get(key)
            os.environ[key] = value

        # Save and change working directory
        self._original_cwd = os.getcwd()
        os.chdir(str(self._temp_dir))

        self._active = True
        logger.info("Sandbox activated: %s", self._temp_dir)
        return self._temp_dir

    def deactivate(self) -> None:
        """Deactivate the sandbox and restore original state."""
        if not self._active:
            return

        # Restore working directory
        if self._original_cwd:
            try:
                os.chdir(self._original_cwd)
            except OSError:
                pass

        # Restore environment
        for key, original_value in self._original_env.items():
            if original_value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = original_value

        self._active = False
        logger.info("Sandbox deactivated")

    def cleanup(self) -> None:
        """Deactivate and remove the sandbox directory."""
        self.deactivate()
        if self._temp_dir and not self._work_dir:
            # Only remove if we created the temp dir
            try:
                shutil.rmtree(self._temp_dir)
                logger.info("Sandbox directory removed: %s", self._temp_dir)
            except OSError as e:
                logger.warning("Failed to remove sandbox dir: %s", e)

    def resolve_path(self, original_path: str | Path) -> Path:
        """Map an original path to its sandbox equivalent.

        Args:
            original_path: The path as requested by the agent.

        Returns:
            The corresponding path inside the sandbox.

        Examples::

            sb.resolve_path("/home/user/project/file.py")
            # → /tmp/agent-sandbox-xxx/home/user/project/file.py

            sb.resolve_path("relative/file.py")
            # → /tmp/agent-sandbox-xxx/relative/file.py
        """
        p = Path(original_path)
        if p.is_absolute():
            # Strip leading "/" and place under sandbox root
            relative = str(p).lstrip("/")
        else:
            relative = str(p)
        return self.root / relative

    def check_limits(self) -> dict[str, Any]:
        """Check whether sandbox resource limits are exceeded."""
        if not self._active or not self._temp_dir:
            return {"status": "inactive"}

        file_count = sum(1 for _ in self._temp_dir.rglob("*") if _.is_file())
        total_bytes = sum(
            f.stat().st_size
            for f in self._temp_dir.rglob("*")
            if f.is_file()
        )
        disk_mb = total_bytes / (1024 * 1024)

        exceeded = []
        if file_count > self._max_files:
            exceeded.append(f"file_count ({file_count} > {self._max_files})")
        if disk_mb > self._max_disk_mb:
            exceeded.append(f"disk_usage ({disk_mb:.1f}MB > {self._max_disk_mb}MB)")

        return {
            "status": "exceeded" if exceeded else "ok",
            "file_count": file_count,
            "max_files": self._max_files,
            "disk_mb": round(disk_mb, 1),
            "max_disk_mb": self._max_disk_mb,
            "exceeded": exceeded,
        }

    @contextmanager
    def scoped(self) -> Generator[Sandbox, None, None]:
        """Context manager that activates and cleans up the sandbox."""
        self.activate()
        try:
            yield self
        finally:
            self.cleanup()

    # ── dunder ──────────────────────────────────────────────────────

    def __enter__(self) -> Sandbox:
        self.activate()
        return self

    def __exit__(self, *exc: object) -> None:
        self.cleanup()

    def __repr__(self) -> str:
        status = "active" if self._active else "inactive"
        root = str(self._temp_dir or self._work_dir or "auto")
        return f"<Sandbox {status} root={root}>"
