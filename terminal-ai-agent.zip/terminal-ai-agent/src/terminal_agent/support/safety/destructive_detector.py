"""Destructive action detection — identify irreversible operations.

Analyses tool calls and shell commands to flag operations that cannot
be undone: recursive deletions, disk formatting, database drops,
permission changes, force pushes, etc.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass

logger = logging.getLogger("terminal_agent.support.safety.destructive_detector")


@dataclass(frozen=True)
class DestructiveIndicator:
    """A single indicator of a destructive operation."""
    name: str
    severity: str  # "critical", "high", "medium"
    description: str
    reversible: bool = False


# ── Indicator patterns ──────────────────────────────────────────────

_INDICATORS: list[tuple[str, str, str, str, bool]] = [
    # (name, regex, severity, description, reversible)
    (
        "recursive_delete",
        r"\brm\s+-[a-zA-Z]*r[a-zA-Z]*\b",
        "high",
        "Recursive file/directory deletion",
        False,
    ),
    (
        "force_delete",
        r"\brm\s+-[a-zA-Z]*f[a-zA-Z]*\b",
        "medium",
        "Force deletion (no confirmation prompts)",
        False,
    ),
    (
        "disk_format",
        r"\bmkfs\b",
        "critical",
        "Disk/filesystem formatting",
        False,
    ),
    (
        "disk_wipe",
        r"\bdd\s+.*of=/dev/",
        "critical",
        "Direct disk write (potential data destruction)",
        False,
    ),
    (
        "drop_database",
        r"\bDROP\s+(DATABASE|SCHEMA)\b",
        "critical",
        "Database/schema drop — permanently deletes data",
        False,
    ),
    (
        "drop_table",
        r"\bDROP\s+TABLE\b",
        "high",
        "Table drop — permanently deletes table and data",
        False,
    ),
    (
        "truncate",
        r"\bTRUNCATE\b",
        "high",
        "Truncate — deletes all rows from table(s)",
        False,
    ),
    (
        "delete_no_where",
        r"\bDELETE\s+FROM\s+\w+\s*;",
        "high",
        "DELETE without WHERE clause — deletes all rows",
        False,
    ),
    (
        "git_force_push",
        r"\bgit\s+push\s+.*--force",
        "high",
        "Force push — overwrites remote history",
        False,
    ),
    (
        "git_reset_hard",
        r"\bgit\s+reset\s+--hard",
        "medium",
        "Hard reset — discards uncommitted changes",
        False,
    ),
    (
        "git_clean_fd",
        r"\bgit\s+clean\s+.*-f.*-d",
        "medium",
        "Git clean — removes untracked files and directories",
        False,
    ),
    (
        "chmod_recursive",
        r"\bchmod\s+(-[a-zA-Z]*R|[a-zA-Z]*R[a-zA-Z]*)\b",
        "medium",
        "Recursive permission change",
        False,
    ),
    (
        "chown_recursive",
        r"\bchown\s+(-[a-zA-Z]*R|[a-zA-Z]*R[a-zA-Z]*)\b",
        "medium",
        "Recursive ownership change",
        False,
    ),
    (
        "container_rm",
        r"\bdocker\s+rm\b",
        "medium",
        "Docker container removal",
        True,  # can recreate from image
    ),
    (
        "image_rm",
        r"\bdocker\s+rmi\b",
        "medium",
        "Docker image removal",
        True,  # can re-pull
    ),
    (
        "terraform_destroy",
        r"\bterraform\s+destroy\b",
        "critical",
        "Terraform destroy — tears down infrastructure",
        False,
    ),
    (
        "kubectl_delete",
        r"\bkubectl\s+delete\b",
        "high",
        "Kubernetes resource deletion",
        True,  # can re-apply manifests
    ),
    (
        "pip_uninstall",
        r"\b(pip|pip3)\s+uninstall\b",
        "low",
        "Package uninstallation",
        True,
    ),
    (
        "npm_uninstall_global",
        r"\bnpm\s+uninstall\s+-g\b",
        "low",
        "Global npm package uninstallation",
        True,
    ),
    (
        "service_stop",
        r"\b(systemctl|service)\s+(stop|disable)\b",
        "medium",
        "Service stop/disable",
        True,
    ),
    (
        "user_delete",
        r"\buserdel\b",
        "high",
        "User account deletion",
        False,
    ),
    (
        "group_delete",
        r"\bgroupdel\b",
        "medium",
        "Group deletion",
        False,
    ),
    (
        "swapoff",
        r"\bswapoff\b",
        "medium",
        "Swap space deactivation",
        True,
    ),
    (
        "umount",
        r"\bumount\b",
        "medium",
        "Filesystem unmount",
        True,
    ),
]


class DestructiveDetector:
    """Detect destructive / irreversible operations in commands.

    Usage::

        detector = DestructiveDetector()
        indicators = detector.analyze("rm -rf /tmp/old_data")
        # [DestructiveIndicator(name='recursive_delete', ...)]
    """

    def __init__(self, *, include_builtin: bool = True) -> None:
        self._indicators: list[tuple[re.Pattern[str], DestructiveIndicator]] = []
        if include_builtin:
            for name, regex, severity, desc, reversible in _INDICATORS:
                self._indicators.append((
                    re.compile(regex, re.IGNORECASE),
                    DestructiveIndicator(name, severity, desc, reversible),
                ))

    def add_indicator(
        self,
        name: str,
        regex: str,
        severity: str = "high",
        description: str = "",
        reversible: bool = False,
    ) -> None:
        """Register a custom destructive indicator."""
        indicator = DestructiveIndicator(name, severity, description, reversible)
        self._indicators.append((re.compile(regex, re.IGNORECASE), indicator))

    def is_destructive(self, command: str) -> bool:
        """Quick boolean check — does *command* look destructive?"""
        return any(pat.search(command) for pat, _ in self._indicators)

    def analyze(self, command: str) -> list[DestructiveIndicator]:
        """Return all matching destructive indicators for *command*."""
        return [ind for pat, ind in self._indicators if pat.search(command)]

    def max_severity(self, command: str) -> str | None:
        """Return the highest severity found, or ``None``."""
        order = {"critical": 4, "high": 3, "medium": 2, "low": 1}
        best: str | None = None
        for ind in self.analyze(command):
            if best is None or order.get(ind.severity, 0) > order.get(best, 0):
                best = ind.severity
        return best

    def summarize(self, command: str) -> str:
        """Human-readable summary of destructive indicators."""
        indicators = self.analyze(command)
        if not indicators:
            return "No destructive indicators found."
        lines = ["Destructive indicators detected:"]
        for ind in indicators:
            rev = " (reversible)" if ind.reversible else " (irreversible)"
            lines.append(f"  [{ind.severity.upper()}] {ind.description}{rev}")
        return "\n".join(lines)
