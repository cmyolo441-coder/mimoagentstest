"""Path access control — restrict which filesystem paths the agent may touch.

Provides allow-list and deny-list semantics with glob support.  Paths
are resolved to absolute form before checking so that relative traversal
attacks (``../../etc/passwd``) cannot bypass restrictions.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

logger = logging.getLogger("terminal_agent.support.safety.path_controller")

# ── Default restricted paths ────────────────────────────────────────

_DEFAULT_RESTRICTED: list[str] = [
    "/etc/shadow",
    "/etc/passwd",
    "/etc/sudoers",
    "/etc/ssh",
    "/boot",
    "/dev",
    "/proc",
    "/sys",
    "/root",
    "/var/run/docker.sock",
]

# Paths that are always allowed even under strict mode
_DEFAULT_ALLOWED: list[str] = [
    "/tmp",
    "/var/tmp",
]


class PathController:
    """Enforce path access policies for tool calls.

    Resolution order:
    1. If path matches any *allowed* entry → ALLOW
    2. If path matches any *restricted* entry → DENY
    3. Otherwise → ALLOW (default-allow with explicit deny)

    Usage::

        ctrl = PathController(allowed_paths=["/home/user/project"])
        ctrl.is_allowed("/home/user/project/src/main.py")  # True
        ctrl.is_allowed("/etc/shadow")                       # False
    """

    def __init__(
        self,
        *,
        restricted_paths: list[str] | None = None,
        allowed_paths: list[str] | None = None,
    ) -> None:
        self._restricted = [
            self._normalize(p) for p in (restricted_paths or _DEFAULT_RESTRICTED)
        ]
        self._allowed = [
            self._normalize(p) for p in (allowed_paths or _DEFAULT_ALLOWED)
        ]

    # ── public API ──────────────────────────────────────────────────

    def is_allowed(self, path: str) -> bool:
        """Check whether *path* is accessible under current policy."""
        resolved = self._resolve(path)

        # Check allowed list first (explicit allow wins)
        for allowed in self._allowed:
            if self._is_within(resolved, allowed):
                return True

        # Check restricted list
        for restricted in self._restricted:
            if self._is_within(resolved, restricted):
                return False

        # Default: allow
        return True

    def add_restricted(self, path: str) -> None:
        """Add a path to the restricted list."""
        normalized = self._normalize(path)
        if normalized not in self._restricted:
            self._restricted.append(normalized)
            logger.info("Added restricted path: %s", normalized)

    def add_allowed(self, path: str) -> None:
        """Add a path to the allowed list."""
        normalized = self._normalize(path)
        if normalized not in self._allowed:
            self._allowed.append(normalized)
            logger.info("Added allowed path: %s", normalized)

    def remove_restricted(self, path: str) -> None:
        """Remove a path from the restricted list."""
        normalized = self._normalize(path)
        try:
            self._restricted.remove(normalized)
            logger.info("Removed restricted path: %s", normalized)
        except ValueError:
            pass

    def remove_allowed(self, path: str) -> None:
        """Remove a path from the allowed list."""
        normalized = self._normalize(path)
        try:
            self._allowed.remove(normalized)
            logger.info("Removed allowed path: %s", normalized)
        except ValueError:
            pass

    @property
    def restricted_paths(self) -> list[str]:
        """Current restricted paths."""
        return list(self._restricted)

    @property
    def allowed_paths(self) -> list[str]:
        """Current allowed paths."""
        return list(self._allowed)

    def check_paths(self, paths: list[str]) -> tuple[list[str], list[str]]:
        """Batch-check multiple paths.

        Returns ``(allowed, denied)`` lists.
        """
        ok: list[str] = []
        denied: list[str] = []
        for p in paths:
            (ok if self.is_allowed(p) else denied).append(p)
        return ok, denied

    # ── internals ───────────────────────────────────────────────────

    @staticmethod
    def _resolve(path: str) -> str:
        """Resolve to absolute, canonical path."""
        try:
            return str(Path(path).resolve())
        except (OSError, ValueError):
            return os.path.abspath(path)

    @staticmethod
    def _normalize(path: str) -> str:
        """Normalize a policy path (resolve but keep trailing semantics)."""
        p = path.rstrip("/")
        if not p:
            return "/"
        try:
            return str(Path(p).resolve())
        except (OSError, ValueError):
            return os.path.abspath(p)

    @staticmethod
    def _is_within(child: str, parent: str) -> bool:
        """Check if *child* is the same as or inside *parent*."""
        if child == parent:
            return True
        return child.startswith(parent + "/")
