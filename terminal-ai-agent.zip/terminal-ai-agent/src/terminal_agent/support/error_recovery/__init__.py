"""Error recovery subsystem for Terminal Agent.

Classifies errors and applies a 6-level recovery strategy hierarchy:

1. Immediate retry — same action, same parameters
2. Modified retry — same action, adjusted parameters
3. Alternative approach — different tool or method
4. Re-plan — regenerate plan considering the error
5. Ask user — describe the problem, request guidance
6. Graceful abort — save state, explain what happened
"""

from __future__ import annotations

from terminal_agent.support.error_recovery.classifier import ErrorClassifier
from terminal_agent.support.error_recovery.recovery_engine import RecoveryEngine
from terminal_agent.support.error_recovery.error_patterns import ErrorPatternLibrary

__all__ = [
    "ErrorClassifier",
    "RecoveryEngine",
    "ErrorPatternLibrary",
]
