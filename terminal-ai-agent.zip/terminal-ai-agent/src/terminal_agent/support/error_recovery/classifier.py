"""Error classifier — categorize errors and determine root cause.

Analyses error messages, exit codes, stderr output, and context to
assign an ``ErrorCategory`` and extract structured information for
the recovery engine.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import ErrorCategory, ToolCall, ToolResult
from terminal_agent.support.error_recovery.error_patterns import ErrorPatternLibrary

logger = logging.getLogger("terminal_agent.support.error_recovery.classifier")


@dataclass
class ClassifiedError:
    """An error that has been classified by the classifier."""
    category: ErrorCategory
    summary: str
    details: dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    original_error: str = ""
    exit_code: int = 0
    tool_name: str = ""
    recoverable: bool = True
    retry_count: int = 0


class ErrorClassifier:
    """Classify errors from tool executions.

    Uses pattern matching on error messages and exit codes to assign
    an ``ErrorCategory``.  Falls back to UNKNOWN when no pattern matches.

    Usage::

        classifier = ErrorClassifier()
        error = classifier.classify(tool_call, tool_result)
        print(error.category)   # ErrorCategory.SYNTAX
        print(error.summary)    # "SyntaxError: unexpected indent at line 42"
    """

    # Ordered list of (regex, category, description) patterns
    _PATTERNS: list[tuple[str, ErrorCategory, str]] = [
        # Syntax errors
        (r"SyntaxError:", ErrorCategory.SYNTAX, "Python syntax error"),
        (r"syntax error", ErrorCategory.SYNTAX, "Syntax error"),
        (r"unexpected token", ErrorCategory.SYNTAX, "Unexpected token"),
        (r"unexpected end of input", ErrorCategory.SYNTAX, "Unexpected EOF"),
        (r"Missing semicolon", ErrorCategory.SYNTAX, "Missing semicolon"),
        (r"IndentationError:", ErrorCategory.SYNTAX, "Indentation error"),
        (r"TabError:", ErrorCategory.SYNTAX, "Tab/space mixing"),

        # Type errors
        (r"TypeError:", ErrorCategory.TYPE, "Type error"),
        (r"type mismatch", ErrorCategory.TYPE, "Type mismatch"),
        (r"not assignable", ErrorCategory.TYPE, "Type assignment error"),
        (r"Property .* does not exist", ErrorCategory.TYPE, "Missing property"),

        # Import errors
        (r"ModuleNotFoundError:", ErrorCategory.IMPORT, "Module not found"),
        (r"ImportError:", ErrorCategory.IMPORT, "Import error"),
        (r"Cannot find module", ErrorCategory.IMPORT, "Module not found"),
        (r"No module named", ErrorCategory.IMPORT, "Module not found"),
        (r"Module not found", ErrorCategory.IMPORT, "Module not found"),

        # Permission errors
        (r"PermissionError:", ErrorCategory.PERMISSION, "Permission denied"),
        (r"Permission denied", ErrorCategory.PERMISSION, "Permission denied"),
        (r"EACCES", ErrorCategory.PERMISSION, "Access denied"),
        (r"Operation not permitted", ErrorCategory.PERMISSION, "Operation not permitted"),
        (r"access denied", ErrorCategory.PERMISSION, "Access denied"),
        (r"sudo", ErrorCategory.PERMISSION, "Requires elevated privileges"),

        # File not found
        (r"FileNotFoundError:", ErrorCategory.FILE_NOT_FOUND, "File not found"),
        (r"No such file or directory", ErrorCategory.FILE_NOT_FOUND, "File not found"),
        (r"not found", ErrorCategory.FILE_NOT_FOUND, "Not found"),
        (r"does not exist", ErrorCategory.FILE_NOT_FOUND, "Does not exist"),
        (r"ENOENT", ErrorCategory.FILE_NOT_FOUND, "No such file"),

        # Network errors
        (r"ConnectionError:", ErrorCategory.NETWORK, "Connection error"),
        (r"Connection refused", ErrorCategory.NETWORK, "Connection refused"),
        (r"Connection reset", ErrorCategory.NETWORK, "Connection reset"),
        (r"ETIMEDOUT", ErrorCategory.NETWORK, "Connection timed out"),
        (r"ECONNREFUSED", ErrorCategory.NETWORK, "Connection refused"),
        (r"Name or service not known", ErrorCategory.NETWORK, "DNS resolution failed"),
        (r"Network is unreachable", ErrorCategory.NETWORK, "Network unreachable"),
        (r"SSL", ErrorCategory.NETWORK, "SSL/TLS error"),
        (r"certificate", ErrorCategory.NETWORK, "Certificate error"),

        # API errors
        (r"status code:?\s*4\d{2}", ErrorCategory.API, "Client error (4xx)"),
        (r"status code:?\s*5\d{2}", ErrorCategory.API, "Server error (5xx)"),
        (r"HTTP\s*4\d{2}", ErrorCategory.API, "HTTP client error"),
        (r"HTTP\s*5\d{2}", ErrorCategory.API, "HTTP server error"),
        (r"API error", ErrorCategory.API, "API error"),
        (r"Bad Gateway", ErrorCategory.API, "Bad gateway"),
        (r"Service Unavailable", ErrorCategory.API, "Service unavailable"),

        # Rate limiting
        (r"rate limit", ErrorCategory.RATE_LIMIT, "Rate limited"),
        (r"429", ErrorCategory.RATE_LIMIT, "Too many requests"),
        (r"Too Many Requests", ErrorCategory.RATE_LIMIT, "Rate limited"),
        (r"throttl", ErrorCategory.RATE_LIMIT, "Throttled"),

        # Authentication
        (r"401", ErrorCategory.AUTHENTICATION, "Unauthorized"),
        (r"403", ErrorCategory.AUTHENTICATION, "Forbidden"),
        (r"Invalid API key", ErrorCategory.AUTHENTICATION, "Invalid API key"),
        (r"Authentication failed", ErrorCategory.AUTHENTICATION, "Auth failed"),
        (r"invalid token", ErrorCategory.AUTHENTICATION, "Invalid token"),
        (r"expired", ErrorCategory.AUTHENTICATION, "Credentials expired"),

        # Resource errors
        (r"MemoryError:", ErrorCategory.RESOURCE, "Out of memory"),
        (r"out of memory", ErrorCategory.RESOURCE, "Out of memory"),
        (r"OOM", ErrorCategory.RESOURCE, "Out of memory"),
        (r"disk full", ErrorCategory.RESOURCE, "Disk full"),
        (r"No space left", ErrorCategory.RESOURCE, "No disk space"),
        (r"ENOSPC", ErrorCategory.RESOURCE, "No disk space"),
        (r"Cannot allocate memory", ErrorCategory.RESOURCE, "Memory allocation failed"),
        (r"process limit", ErrorCategory.RESOURCE, "Process limit reached"),

        # Dependency errors
        (r"npm ERR!", ErrorCategory.DEPENDENCY, "npm error"),
        (r"ERESOLVE", ErrorCategory.DEPENDENCY, "Dependency conflict"),
        (r"peer dep", ErrorCategory.DEPENDENCY, "Peer dependency issue"),
        (r"Could not resolve dependencies", ErrorCategory.DEPENDENCY, "Dependency resolution failed"),
        (r"version conflict", ErrorCategory.DEPENDENCY, "Version conflict"),

        # Build errors
        (r"error\[E\d+\]", ErrorCategory.BUILD, "Rust compilation error"),
        (r"Build Failed", ErrorCategory.BUILD, "Build failed"),
        (r"compilation terminated", ErrorCategory.BUILD, "Compilation terminated"),
        (r"undefined reference", ErrorCategory.BUILD, "Undefined reference"),
        (r"linker error", ErrorCategory.BUILD, "Linker error"),
        (r"CMake Error", ErrorCategory.BUILD, "CMake error"),

        # Test errors
        (r"FAILED", ErrorCategory.TEST, "Test failed"),
        (r"AssertionError", ErrorCategory.TEST, "Assertion error"),
        (r"test.*failed", ErrorCategory.TEST, "Test failure"),
        (r"FAIL ", ErrorCategory.TEST, "Test failure"),

        # Timeout
        (r"timed? ?out", ErrorCategory.TIMEOUT, "Timeout"),
        (r"ETIMEDOUT", ErrorCategory.TIMEOUT, "Connection timeout"),
        (r"TimeoutError", ErrorCategory.TIMEOUT, "Timeout error"),
        (r"deadline exceeded", ErrorCategory.TIMEOUT, "Deadline exceeded"),

        # Configuration
        (r"ConfigError", ErrorCategory.CONFIGURATION, "Configuration error"),
        (r"invalid configuration", ErrorCategory.CONFIGURATION, "Invalid config"),
        (r"missing required", ErrorCategory.CONFIGURATION, "Missing required config"),

        # Concurrency
        (r"deadlock", ErrorCategory.CONCURRENCY, "Deadlock detected"),
        (r"race condition", ErrorCategory.CONCURRENCY, "Race condition"),
        (r"Resource temporarily unavailable", ErrorCategory.CONCURRENCY, "Resource busy"),
        (r"EAGAIN", ErrorCategory.CONCURRENCY, "Try again"),
        (r"lock.*timeout", ErrorCategory.CONCURRENCY, "Lock timeout"),
    ]

    def __init__(self) -> None:
        self._patterns = [
            (re.compile(regex, re.IGNORECASE), cat, desc)
            for regex, cat, desc in self._PATTERNS
        ]
        self._pattern_library = ErrorPatternLibrary()

    def classify(
        self,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any] | None = None,
    ) -> ClassifiedError:
        """Classify the error from a tool execution.

        Args:
            tool_call: The tool call that was executed.
            tool_result: The result of the tool execution.
            context: Additional context (previous attempts, etc.).

        Returns:
            A ``ClassifiedError`` with category, summary, and details.
        """
        error_text = self._build_error_text(tool_result)
        exit_code = tool_result.exit_code

        # Try pattern matching
        for pattern, category, description in self._patterns:
            match = pattern.search(error_text)
            if match:
                # Check known error patterns for additional info
                known = self._pattern_library.lookup(error_text)
                return ClassifiedError(
                    category=category,
                    summary=f"{description}: {match.group(0)[:200]}",
                    details={
                        "matched_pattern": pattern.pattern,
                        "description": description,
                        "known_solution": known.get("solution") if known else None,
                        "known_cause": known.get("cause") if known else None,
                    },
                    confidence=0.9,
                    original_error=error_text[:2000],
                    exit_code=exit_code,
                    tool_name=tool_call.name,
                    recoverable=category not in (
                        ErrorCategory.AUTHENTICATION,
                        ErrorCategory.RESOURCE,
                    ),
                )

        # Classify by exit code
        if exit_code != 0:
            category = self._classify_by_exit_code(exit_code)
            return ClassifiedError(
                category=category,
                summary=f"Exit code {exit_code}",
                details={"exit_code": exit_code},
                confidence=0.5,
                original_error=error_text[:2000],
                exit_code=exit_code,
                tool_name=tool_call.name,
                recoverable=True,
            )

        # Unknown error
        return ClassifiedError(
            category=ErrorCategory.UNKNOWN,
            summary=f"Unknown error: {error_text[:200]}",
            details={},
            confidence=0.1,
            original_error=error_text[:2000],
            exit_code=exit_code,
            tool_name=tool_call.name,
            recoverable=True,
        )

    # ── helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _build_error_text(result: ToolResult) -> str:
        """Combine all error sources into one searchable string."""
        parts = []
        if result.error:
            parts.append(result.error)
        if result.output:
            parts.append(result.output)
        return "\n".join(parts)

    @staticmethod
    def _classify_by_exit_code(code: int) -> ErrorCategory:
        """Map common exit codes to error categories."""
        mapping = {
            1: ErrorCategory.UNKNOWN,     # General error
            2: ErrorCategory.SYNTAX,       # Misuse of shell command
            126: ErrorCategory.PERMISSION, # Cannot execute
            127: ErrorCategory.FILE_NOT_FOUND, # Command not found
            137: ErrorCategory.RESOURCE,   # SIGKILL (OOM)
            139: ErrorCategory.CONCURRENCY, # SIGSEGV
            143: ErrorCategory.TIMEOUT,    # SIGTERM
        }
        return mapping.get(code, ErrorCategory.UNKNOWN)
