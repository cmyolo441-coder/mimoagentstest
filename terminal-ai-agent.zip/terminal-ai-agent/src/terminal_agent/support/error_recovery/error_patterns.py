"""Known error patterns — library of common errors and their solutions.

Provides a lookup table of error patterns with known causes and
solutions.  Used by the classifier to enrich error information and
by the recovery engine to select better strategies.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass

logger = logging.getLogger("terminal_agent.support.error_recovery.error_patterns")


@dataclass(frozen=True)
class ErrorPattern:
    """A known error pattern with cause and solution."""
    name: str
    regex: str
    cause: str
    solution: str
    category: str = ""
    _compiled: re.Pattern[str] | None = None

    def compiled(self) -> re.Pattern[str]:
        if self._compiled is None:
            object.__setattr__(self, "_compiled", re.compile(self.regex, re.IGNORECASE))
        return self._compiled  # type: ignore[return-value]


# ── Built-in error pattern library ──────────────────────────────────

_KNOWN_PATTERNS: list[ErrorPattern] = [
    # ── Python ──
    ErrorPattern(
        name="python_indentation",
        regex=r"IndentationError:\s*unexpected indent",
        cause="Mixed tabs and spaces, or incorrect indentation level",
        solution="Convert tabs to spaces (4 spaces per level). Use an editor with visible whitespace.",
        category="syntax",
    ),
    ErrorPattern(
        name="python_missing_colon",
        regex=r"SyntaxError:\s*expected ':'",
        cause="Missing colon after if/for/while/def/class statement",
        solution="Add ':' at the end of the statement line.",
        category="syntax",
    ),
    ErrorPattern(
        name="python_missing_module",
        regex=r"ModuleNotFoundError:\s*No module named '(\w+)'",
        cause="Required package is not installed in the current environment",
        solution="Install with pip: pip install <module_name>",
        category="import",
    ),
    ErrorPattern(
        name="python_circular_import",
        regex=r"ImportError:\s*cannot import name",
        cause="Circular import dependency between modules",
        solution="Restructure imports to avoid circular dependencies. Use local imports inside functions.",
        category="import",
    ),
    ErrorPattern(
        name="python_type_error_none",
        regex=r"TypeError:\s*'.*' object is not (subscriptable|iterable|callable)",
        cause="Variable is None or wrong type when operation is attempted",
        solution="Add None checks before the operation. Verify variable types.",
        category="type",
    ),
    ErrorPattern(
        name="python_key_error",
        regex=r"KeyError:\s*'?(\w+)'?",
        cause="Accessing a dictionary key that doesn't exist",
        solution="Use dict.get('key', default) or check 'key' in dict first.",
        category="runtime",
    ),
    ErrorPattern(
        name="python_index_error",
        regex=r"IndexError:\s*list index out of range",
        cause="Accessing a list element beyond its length",
        solution="Check list length before accessing by index. Use try/except IndexError.",
        category="runtime",
    ),
    ErrorPattern(
        name="python_attribute_error",
        regex=r"AttributeError:\s*'?(\w+)'? object has no attribute '?(\w+)'?",
        cause="Accessing an attribute/method that doesn't exist on the object",
        solution="Check the object type and available attributes with dir(). Verify the attribute name.",
        category="runtime",
    ),
    ErrorPattern(
        name="python_permission_denied",
        regex=r"PermissionError:\s*\[Errno 13\] Permission denied",
        cause="Insufficient permissions to read/write the file",
        solution="Check file permissions. Use a user-writable directory. Avoid system paths.",
        category="permission",
    ),
    ErrorPattern(
        name="python_file_not_found",
        regex=r"FileNotFoundError:\s*\[Errno 2\] No such file or directory",
        cause="Referenced file or directory does not exist",
        solution="Verify the file path. Create parent directories with os.makedirs().",
        category="file_not_found",
    ),

    # ── Node.js / JavaScript ──
    ErrorPattern(
        name="node_module_not_found",
        regex=r"Cannot find module '(\w+)'",
        cause="npm package not installed or not in node_modules",
        solution="Run 'npm install' or 'npm install <package>'",
        category="import",
    ),
    ErrorPattern(
        name="node_enoent",
        regex=r"Error:\s*ENOENT.*open",
        cause="File or directory does not exist",
        solution="Verify the file path exists. Create parent directories if needed.",
        category="file_not_found",
    ),
    ErrorPattern(
        name="node_eacces",
        regex=r"Error:\s*EACCES",
        cause="Permission denied for file or port",
        solution="Check file permissions. For ports < 1024, use sudo or a higher port.",
        category="permission",
    ),
    ErrorPattern(
        name="node_eaddrinuse",
        regex=r"Error:\s*EADDRINUSE",
        cause="Port is already in use by another process",
        solution="Use a different port, or stop the process using the port (lsof -i :<port>).",
        category="resource",
    ),
    ErrorPattern(
        name="node_heap_out_of_memory",
        regex=r"FATAL ERROR:.*heap.*out of memory",
        cause="Node.js process exceeded memory limit",
        solution="Increase heap size: node --max-old-space-size=4096. Or optimize memory usage.",
        category="resource",
    ),

    # ── Git ──
    ErrorPattern(
        name="git_merge_conflict",
        regex=r"CONFLICT.*Merge conflict",
        cause="Conflicting changes between branches",
        solution="Resolve conflicts manually, then 'git add' and 'git commit'.",
        category="state",
    ),
    ErrorPattern(
        name="git_detached_head",
        regex=r"You are in 'detached HEAD' state",
        cause="Checked out a specific commit instead of a branch",
        solution="Create a branch: git checkout -b <branch-name>",
        category="state",
    ),
    ErrorPattern(
        name="git_push_rejected",
        regex=r"rejected.*failed to push",
        cause="Remote has changes not in local branch",
        solution="Pull first: git pull --rebase, then push again.",
        category="state",
    ),

    # ── Docker ──
    ErrorPattern(
        name="docker_not_running",
        regex=r"Cannot connect to the Docker daemon",
        cause="Docker daemon is not running",
        solution="Start Docker: sudo systemctl start docker",
        category="state",
    ),
    ErrorPattern(
        name="docker_image_not_found",
        regex=r"pull access denied.*not found",
        cause="Docker image doesn't exist or requires authentication",
        solution="Verify image name. Login to registry if private: docker login",
        category="file_not_found",
    ),
    ErrorPattern(
        name="docker_port_conflict",
        regex=r"port is already allocated",
        cause="Port is in use by another container or process",
        solution="Stop the conflicting container or use a different port mapping.",
        category="resource",
    ),

    # ── Network / HTTP ──
    ErrorPattern(
        name="ssl_certificate_error",
        regex=r"SSL.*certificate.*(?:verify|expired|self.signed)",
        cause="SSL certificate is invalid, expired, or self-signed",
        solution="Update CA certificates, or use --insecure flag for testing only.",
        category="network",
    ),
    ErrorPattern(
        name="dns_resolution_failed",
        regex=r"(?:getaddrinfo|Name or service not known|DNS resolution failed)",
        cause="DNS cannot resolve the hostname",
        solution="Check the URL. Verify DNS settings. Try IP address directly.",
        category="network",
    ),
    ErrorPattern(
        name="connection_refused",
        regex=r"(?:Connection refused|ECONNREFUSED)",
        cause="Target service is not running or not accepting connections",
        solution="Verify the service is running. Check host and port. Check firewall rules.",
        category="network",
    ),
    ErrorPattern(
        name="rate_limit_429",
        regex=r"(?:429|Too Many Requests|rate limit)",
        cause="API rate limit exceeded",
        solution="Wait before retrying. Implement exponential backoff. Check rate limit headers.",
        category="rate_limit",
    ),

    # ── Build / Compilation ──
    ErrorPattern(
        name="rust_borrow_checker",
        regex=r"(?:cannot borrow|borrowed|moved)",
        cause="Rust borrow checker violations",
        solution="Review ownership rules. Use references (&) or clone() where appropriate.",
        category="build",
    ),
    ErrorPattern(
        name="go_unused_import",
        regex=r"imported and not used",
        cause="Go package imported but not referenced in code",
        solution="Remove unused imports or use blank identifier: _ = package.Function",
        category="build",
    ),
    ErrorPattern(
        name="typescript_type_error",
        regex=r"TS\d{4}:",
        cause="TypeScript type checking error",
        solution="Fix the type annotation or add appropriate type assertions.",
        category="type",
    ),

    # ── Database ──
    ErrorPattern(
        name="db_connection_refused",
        regex=r"(?:could not connect|connection refused|ECONNREFUSED).*(?:postgres|mysql|mongo|redis)",
        cause="Database server is not running or not accepting connections",
        solution="Start the database service. Verify connection string. Check port and host.",
        category="network",
    ),
    ErrorPattern(
        name="db_syntax_error",
        regex=r"syntax error at or near",
        cause="SQL syntax error in query",
        solution="Check SQL syntax. Verify table and column names. Check for missing quotes.",
        category="syntax",
    ),
    ErrorPattern(
        name="db_relation_not_exist",
        regex=r'relation "(\w+)" does not exist',
        cause="Table or relation doesn't exist in the database",
        solution="Run migrations. Verify table name. Check database/schema selection.",
        category="file_not_found",
    ),
]


class ErrorPatternLibrary:
    """Lookup error patterns and retrieve known causes/solutions.

    Usage::

        library = ErrorPatternLibrary()
        match = library.lookup("ModuleNotFoundError: No module named 'requests'")
        # {'cause': 'Required package...', 'solution': 'Install with pip...'}
    """

    def __init__(self, *, include_builtin: bool = True) -> None:
        self._patterns: list[ErrorPattern] = []
        if include_builtin:
            self._patterns.extend(_KNOWN_PATTERNS)

    def add_pattern(self, pattern: ErrorPattern) -> None:
        """Add a custom error pattern."""
        self._patterns.append(pattern)

    def add_simple(
        self,
        name: str,
        regex: str,
        cause: str,
        solution: str,
        category: str = "",
    ) -> None:
        """Add a pattern from simple parameters."""
        self._patterns.append(ErrorPattern(
            name=name, regex=regex, cause=cause,
            solution=solution, category=category,
        ))

    def lookup(self, error_text: str) -> dict[str, str] | None:
        """Find the first matching pattern for *error_text*.

        Returns a dict with 'name', 'cause', 'solution', 'category',
        or ``None`` if no pattern matches.
        """
        for pattern in self._patterns:
            if pattern.compiled().search(error_text):
                return {
                    "name": pattern.name,
                    "cause": pattern.cause,
                    "solution": pattern.solution,
                    "category": pattern.category,
                }
        return None

    def lookup_all(self, error_text: str) -> list[dict[str, str]]:
        """Find all matching patterns for *error_text*."""
        matches: list[dict[str, str]] = []
        for pattern in self._patterns:
            if pattern.compiled().search(error_text):
                matches.append({
                    "name": pattern.name,
                    "cause": pattern.cause,
                    "solution": pattern.solution,
                    "category": pattern.category,
                })
        return matches

    def search(self, query: str) -> list[dict[str, str]]:
        """Search patterns by name, cause, or solution text."""
        query_lower = query.lower()
        results: list[dict[str, str]] = []
        for pattern in self._patterns:
            if (query_lower in pattern.name.lower()
                    or query_lower in pattern.cause.lower()
                    or query_lower in pattern.solution.lower()):
                results.append({
                    "name": pattern.name,
                    "cause": pattern.cause,
                    "solution": pattern.solution,
                    "category": pattern.category,
                })
        return results

    @property
    def pattern_count(self) -> int:
        return len(self._patterns)

    def list_categories(self) -> list[str]:
        """List all unique categories."""
        return sorted(set(p.category for p in self._patterns if p.category))
