"""Level 1: Immediate retry — same action, same parameters.

Best for transient errors: network timeouts, rate limits, temporary
resource unavailability.  Adds a small delay between retries.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from terminal_agent.types import ErrorCategory, RecoveryLevel, ToolCall, ToolResult
from terminal_agent.support.error_recovery.classifier import ClassifiedError

logger = logging.getLogger("terminal_agent.support.error_recovery.strategies.immediate_retry")

# Delay between retries in seconds, per error category
_RETRY_DELAYS: dict[ErrorCategory, float] = {
    ErrorCategory.NETWORK: 2.0,
    ErrorCategory.RATE_LIMIT: 5.0,
    ErrorCategory.API: 3.0,
    ErrorCategory.TIMEOUT: 2.0,
    ErrorCategory.CONCURRENCY: 1.0,
    ErrorCategory.RUNTIME: 0.5,
}


class ImmediateRetryStrategy:
    """Retry the exact same action with the same parameters.

    Applies a category-specific delay.  Returns SUCCESS to signal
    "retry now" or ESCALATE if the error is not transient.
    """

    # Errors that are good candidates for immediate retry
    _RETRYABLE: set[ErrorCategory] = {
        ErrorCategory.NETWORK,
        ErrorCategory.RATE_LIMIT,
        ErrorCategory.API,
        ErrorCategory.TIMEOUT,
        ErrorCategory.CONCURRENCY,
        ErrorCategory.RUNTIME,
        ErrorCategory.UNKNOWN,
    }

    def execute(
        self,
        error: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> "RecoveryResult":
        """Execute immediate retry strategy."""
        # Import here to avoid circular imports
        from terminal_agent.support.error_recovery.recovery_engine import (
            RecoveryOutcome, RecoveryResult,
        )

        if error.category not in self._RETRYABLE:
            return RecoveryResult(
                outcome=RecoveryOutcome.ESCALATE,
                strategy="immediate_retry",
                level=RecoveryLevel.IMMEDIATE_RETRY,
                classified_error=error,
                suggestion=f"Error category '{error.category.value}' is not transient — escalating",
            )

        # Apply delay
        delay = _RETRY_DELAYS.get(error.category, 1.0)
        logger.info("Immediate retry after %.1fs delay for %s", delay, error.category.value)
        time.sleep(delay)

        return RecoveryResult(
            outcome=RecoveryOutcome.SUCCESS,
            strategy="immediate_retry",
            level=RecoveryLevel.IMMEDIATE_RETRY,
            classified_error=error,
            modified_tool_call=tool_call,  # Same call, same params
            suggestion=f"Retrying same action after {delay}s delay",
            details={"delay_seconds": delay},
        )
