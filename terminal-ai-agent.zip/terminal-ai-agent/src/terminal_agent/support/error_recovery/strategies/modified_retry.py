"""Level 2: Modified retry — same action, adjusted parameters.

Analyses the error to determine what parameters should change, then
returns a modified tool call.  Good for syntax errors, missing files,
wrong paths, and version conflicts.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from terminal_agent.types import ErrorCategory, RecoveryLevel, ToolCall, ToolResult
from terminal_agent.support.error_recovery.classifier import ClassifiedError

logger = logging.getLogger("terminal_agent.support.error_recovery.strategies.modified_retry")


class ModifiedRetryStrategy:
    """Retry with modified parameters based on error analysis.

    Analyses the error message to extract specific corrections:
    - Syntax errors: extract line number and error type
    - Missing files: suggest similar file names
    - Import errors: suggest package install
    - Path errors: suggest corrected paths
    """

    def execute(
        self,
        error: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> "RecoveryResult":
        """Execute modified retry strategy."""
        from terminal_agent.support.error_recovery.recovery_engine import (
            RecoveryOutcome, RecoveryResult,
        )

        modifications = self._analyze_modifications(error, tool_call, tool_result)

        if not modifications:
            return RecoveryResult(
                outcome=RecoveryOutcome.ESCALATE,
                strategy="modified_retry",
                level=RecoveryLevel.MODIFIED_RETRY,
                classified_error=error,
                suggestion="No modifications identified — escalating",
            )

        # Build modified tool call
        modified = self._apply_modifications(tool_call, modifications)

        return RecoveryResult(
            outcome=RecoveryOutcome.SUCCESS,
            strategy="modified_retry",
            level=RecoveryLevel.MODIFIED_RETRY,
            classified_error=error,
            modified_tool_call=modified,
            suggestion=f"Modified retry with: {modifications.get('description', 'adjustments')}",
            details=modifications,
        )

    def _analyze_modifications(
        self,
        error: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
    ) -> dict[str, Any]:
        """Determine what parameters to modify."""
        mods: dict[str, Any] = {}
        err_text = error.original_error.lower()

        # Known solution from pattern library
        if error.details.get("known_solution"):
            mods["description"] = f"Apply known solution: {error.details['known_solution']}"
            mods["hint"] = error.details["known_solution"]
            return mods

        if error.category == ErrorCategory.SYNTAX:
            # Extract line number
            line_match = re.search(r"line\s+(\d+)", err_text)
            if line_match:
                mods["error_line"] = int(line_match.group(1))
            mods["description"] = "Fix syntax error"
            mods["action"] = "fix_syntax"
            return mods

        if error.category == ErrorCategory.IMPORT:
            # Extract module name
            module_match = re.search(
                r"(?:no module named|cannot find module|modulenotfounderror)\s*['\"]?(\w+)",
                err_text,
            )
            if module_match:
                mods["missing_module"] = module_match.group(1)
                mods["description"] = f"Install missing module: {mods['missing_module']}"
                mods["action"] = "install_package"
                mods["install_command"] = f"pip install {mods['missing_module']}"
                return mods

        if error.category == ErrorCategory.FILE_NOT_FOUND:
            # Extract file path
            path_match = re.search(
                r"(?:no such file|not found|does not exist)\s*[:']?\s*([^\s']+)",
                err_text,
            )
            if path_match:
                mods["missing_path"] = path_match.group(1)
                mods["description"] = f"Create missing file: {mods['missing_path']}"
                mods["action"] = "create_file"
                return mods

        if error.category == ErrorCategory.PERMISSION:
            # Suggest chmod or sudo
            if tool_call.name == "execute_command":
                original_cmd = tool_call.parameters.get("command", "")
                mods["description"] = f"Add sudo to command"
                mods["action"] = "add_sudo"
                mods["new_command"] = f"sudo {original_cmd}"
                return mods
            mods["description"] = "Fix file permissions"
            mods["action"] = "chmod"
            return mods

        if error.category == ErrorCategory.TIMEOUT:
            # Increase timeout
            if "timeout" in tool_call.parameters:
                original = tool_call.parameters["timeout"]
                mods["description"] = f"Increase timeout from {original} to {original * 2}"
                mods["action"] = "increase_timeout"
                mods["new_timeout"] = original * 2
                return mods
            mods["description"] = "Add/increase timeout"
            mods["action"] = "add_timeout"
            mods["new_timeout"] = 60
            return mods

        if error.category == ErrorCategory.NETWORK:
            mods["description"] = "Add retry with backoff"
            mods["action"] = "retry_with_backoff"
            return mods

        if error.category == ErrorCategory.DEPENDENCY:
            # Extract package info
            pkg_match = re.search(r"(?:missing|install)\s+(\S+)", err_text)
            if pkg_match:
                mods["missing_package"] = pkg_match.group(1)
                mods["description"] = f"Install missing package: {mods['missing_package']}"
                mods["action"] = "install_package"
                return mods

        return mods

    def _apply_modifications(
        self, tool_call: ToolCall, mods: dict[str, Any]
    ) -> ToolCall:
        """Apply modifications to create a new tool call."""
        import copy
        modified = copy.deepcopy(tool_call)

        if mods.get("action") == "install_package":
            # Return an execute_command to install the package
            return ToolCall(
                name="execute_command",
                parameters={"command": mods.get("install_command", "pip install")},
            )

        if mods.get("action") == "add_sudo":
            modified.parameters["command"] = mods.get("new_command", "")
            return modified

        if mods.get("action") in ("increase_timeout", "add_timeout"):
            modified.parameters["timeout"] = mods.get("new_timeout", 60)
            return modified

        if mods.get("action") == "fix_syntax":
            # Signal to the LLM to fix the specific syntax error
            modified.parameters["_recovery_hint"] = mods.get("description", "")
            return modified

        # Default: return original with hint
        modified.parameters["_recovery_hint"] = mods.get("description", "")
        return modified
