"""Level 6: Graceful abort — save state, explain what happened.

The last resort.  Saves all relevant state, generates a detailed
explanation of what went wrong, and stops execution cleanly.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from terminal_agent.types import ErrorCategory, RecoveryLevel, ToolCall, ToolResult
from terminal_agent.support.error_recovery.classifier import ClassifiedError

logger = logging.getLogger("terminal_agent.support.error_recovery.strategies.graceful_abort")


class GracefulAbortStrategy:
    """Save state and abort gracefully.

    Produces a comprehensive failure report that includes:
    - What was attempted
    - What went wrong
    - What recovery strategies were tried
    - Suggestions for manual resolution
    """

    def execute(
        self,
        error: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> "RecoveryResult":
        """Execute graceful abort strategy."""
        from terminal_agent.support.error_recovery.recovery_engine import (
            RecoveryOutcome, RecoveryResult,
        )

        report = self._build_abort_report(error, tool_call, tool_result, context)
        state = self._save_state(error, tool_call, tool_result, context)

        logger.error("Graceful abort: %s", error.summary)

        return RecoveryResult(
            outcome=RecoveryOutcome.ABORT,
            strategy="graceful_abort",
            level=RecoveryLevel.GRACEFUL_ABORT,
            classified_error=error,
            suggestion=report,
            details={
                "abort_report": report,
                "saved_state": state,
                "timestamp": time.time(),
            },
        )

    def _build_abort_report(
        self,
        error: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> str:
        """Build a comprehensive abort report."""
        lines = [
            "╔══════════════════════════════════════════════════════════╗",
            "║              TASK ABORTED — Error Report                ║",
            "╚══════════════════════════════════════════════════════════╝",
            "",
            f"Error Category: {error.category.value}",
            f"Summary: {error.summary}",
            f"Confidence: {error.confidence:.0%}",
            "",
            "─── What Was Attempted ───",
            f"Tool: {tool_call.name}",
        ]

        # Add parameters
        for key, value in tool_call.parameters.items():
            val_str = str(value)
            if len(val_str) > 200:
                val_str = val_str[:200] + "..."
            lines.append(f"  {key}: {val_str}")

        lines.extend([
            "",
            "─── What Went Wrong ───",
        ])

        if error.original_error:
            # Show first 10 lines of error
            err_lines = error.original_error.split("\n")[:10]
            for line in err_lines:
                lines.append(f"  {line}")
            if len(error.original_error.split("\n")) > 10:
                lines.append("  ...")

        lines.extend([
            "",
            "─── Recovery Attempts ───",
            f"Total retry attempts: {error.retry_count}",
        ])

        # Add recovery history from context
        recovery_history = context.get("recovery_history", [])
        for i, attempt in enumerate(recovery_history, 1):
            lines.append(f"  {i}. {attempt.get('strategy', 'unknown')}: "
                        f"{attempt.get('outcome', 'unknown')}")

        lines.extend([
            "",
            "─── Suggested Manual Steps ───",
        ])

        suggestions = self._get_manual_suggestions(error)
        for suggestion in suggestions:
            lines.append(f"  • {suggestion}")

        lines.extend([
            "",
            "─── State Snapshot ───",
            f"Exit code: {error.exit_code}",
            f"Tool: {error.tool_name}",
        ])

        # Add context state
        if "current_step" in context:
            lines.append(f"Current step: {context['current_step']}")
        if "plan_progress" in context:
            lines.append(f"Plan progress: {context['plan_progress']}")

        return "\n".join(lines)

    def _save_state(
        self,
        error: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Save relevant state for potential resumption."""
        return {
            "error_category": error.category.value,
            "error_summary": error.summary,
            "failed_tool": tool_call.name,
            "failed_parameters": {
                k: str(v)[:500] for k, v in tool_call.parameters.items()
            },
            "exit_code": error.exit_code,
            "error_output": error.original_error[:5000],
            "tool_output": tool_result.output[:5000],
            "context_snapshot": {
                k: str(v)[:1000] for k, v in context.items()
                if k not in ("recovery_history",)
            },
            "timestamp": time.time(),
        }

    def _get_manual_suggestions(self, error: ClassifiedError) -> list[str]:
        """Get manual resolution suggestions based on error category."""
        suggestions: list[str] = []

        category_suggestions = {
            ErrorCategory.AUTHENTICATION: [
                "Verify API keys are set correctly in environment variables",
                "Check if credentials have expired and need renewal",
                "Ensure the API key has the required permissions",
            ],
            ErrorCategory.PERMISSION: [
                "Run the command with sudo if appropriate",
                "Check file/directory permissions with 'ls -la'",
                "Ensure the user has write access to the target directory",
            ],
            ErrorCategory.RESOURCE: [
                "Check available memory with 'free -h'",
                "Check disk space with 'df -h'",
                "Close unnecessary processes to free resources",
            ],
            ErrorCategory.NETWORK: [
                "Check internet connectivity",
                "Verify DNS resolution with 'nslookup'",
                "Check if a proxy is required",
                "Try again later if the service is temporarily down",
            ],
            ErrorCategory.DEPENDENCY: [
                "Check for version conflicts in dependency files",
                "Try clearing the package cache and reinstalling",
                "Verify the package exists in the registry",
            ],
            ErrorCategory.BUILD: [
                "Check the build output for specific error messages",
                "Verify all build prerequisites are installed",
                "Try a clean build (delete build artifacts first)",
            ],
            ErrorCategory.CONFIGURATION: [
                "Check configuration file syntax",
                "Verify all required configuration values are set",
                "Compare with a known-working configuration",
            ],
        }

        suggestions = category_suggestions.get(error.category, [
            "Review the error output for specific clues",
            "Check the project documentation for known issues",
            "Try running the failed command manually to see the full error",
        ])

        # Add known solution if available
        if error.details.get("known_solution"):
            suggestions.insert(0, f"Known solution: {error.details['known_solution']}")

        return suggestions
