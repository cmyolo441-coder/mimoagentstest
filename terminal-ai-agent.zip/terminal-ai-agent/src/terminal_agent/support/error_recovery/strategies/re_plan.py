"""Level 4: Re-plan — regenerate the plan considering the error.

When the current approach is fundamentally wrong, ask the orchestrator
to regenerate the plan with the error context included.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.types import ErrorCategory, RecoveryLevel, ToolCall, ToolResult
from terminal_agent.support.error_recovery.classifier import ClassifiedError

logger = logging.getLogger("terminal_agent.support.error_recovery.strategies.re_plan")


class RePlanStrategy:
    """Signal the orchestrator to re-plan.

    This strategy doesn't produce a modified tool call — it produces
    a suggestion that the orchestrator should regenerate its plan with
    the error context included.
    """

    def execute(
        self,
        error: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> "RecoveryResult":
        """Execute re-plan strategy."""
        from terminal_agent.support.error_recovery.recovery_engine import (
            RecoveryOutcome, RecoveryResult,
        )

        # Build re-plan context
        replan_context = {
            "failed_step": {
                "tool": tool_call.name,
                "parameters": tool_call.parameters,
                "error_category": error.category.value,
                "error_summary": error.summary,
                "error_details": error.original_error[:1000],
            },
            "reason": self._build_replan_reason(error),
            "suggestions": self._build_suggestions(error),
        }

        return RecoveryResult(
            outcome=RecoveryOutcome.SUCCESS,
            strategy="re_plan",
            level=RecoveryLevel.RE_PLAN,
            classified_error=error,
            suggestion=replan_context["reason"],
            details=replan_context,
        )

    def _build_replan_reason(self, error: ClassifiedError) -> str:
        """Build a human-readable reason for re-planning."""
        reasons = {
            ErrorCategory.PERMISSION: (
                "The current approach requires permissions that are not available. "
                "Need to find an alternative that doesn't require elevated access."
            ),
            ErrorCategory.RESOURCE: (
                "System resources are insufficient for the current approach. "
                "Need to find a less resource-intensive method."
            ),
            ErrorCategory.STATE: (
                "The system is in an unexpected state. "
                "Need to reassess the approach from the current state."
            ),
            ErrorCategory.DEPENDENCY: (
                "Dependencies are incompatible or missing. "
                "Need to find compatible versions or alternative libraries."
            ),
            ErrorCategory.BUILD: (
                "The build is failing repeatedly. "
                "Need to reconsider the code changes or build approach."
            ),
        }
        return reasons.get(
            error.category,
            f"Step failed with {error.category.value} error after multiple attempts. "
            f"Need to try a fundamentally different approach.",
        )

    def _build_suggestions(self, error: ClassifiedError) -> list[str]:
        """Build suggestions for the new plan."""
        suggestions: list[str] = []

        if error.category == ErrorCategory.PERMISSION:
            suggestions.extend([
                "Check if the operation can be done without elevated privileges",
                "Use a user-writable directory instead",
                "Ask the user to grant necessary permissions",
            ])
        elif error.category == ErrorCategory.RESOURCE:
            suggestions.extend([
                "Break the operation into smaller parts",
                "Free up resources before retrying",
                "Use a less memory-intensive approach",
            ])
        elif error.category == ErrorCategory.DEPENDENCY:
            suggestions.extend([
                "Check for version compatibility",
                "Use alternative packages",
                "Pin dependency versions",
            ])
        elif error.category == ErrorCategory.BUILD:
            suggestions.extend([
                "Review the build errors and fix them individually",
                "Check if the build system configuration is correct",
                "Try building from a clean state",
            ])

        return suggestions
