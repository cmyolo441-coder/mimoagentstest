"""Level 5: Ask user — describe the problem, request guidance.

When automated recovery fails, present the error to the user with
context and ask for guidance.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.types import ErrorCategory, RecoveryLevel, ToolCall, ToolResult
from terminal_agent.support.error_recovery.classifier import ClassifiedError

logger = logging.getLogger("terminal_agent.support.error_recovery.strategies.ask_user")


class AskUserStrategy:
    """Ask the user for guidance on how to proceed.

    Produces a detailed error report and specific questions for the user.
    Returns WAITING to signal that the engine is paused for user input.
    """

    def execute(
        self,
        error: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> "RecoveryResult":
        """Execute ask-user strategy."""
        from terminal_agent.support.error_recovery.recovery_engine import (
            RecoveryOutcome, RecoveryResult,
        )

        report = self._build_error_report(error, tool_call, tool_result)
        questions = self._build_questions(error)

        return RecoveryResult(
            outcome=RecoveryOutcome.WAITING,
            strategy="ask_user",
            level=RecoveryLevel.ASK_USER,
            classified_error=error,
            suggestion=report,
            details={
                "questions": questions,
                "error_report": report,
                "options": self._build_options(error),
            },
        )

    def _build_error_report(
        self,
        error: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
    ) -> str:
        """Build a detailed error report for the user."""
        lines = [
            "═══ Error Report ═══",
            "",
            f"Category: {error.category.value}",
            f"Summary: {error.summary}",
            f"Tool: {tool_call.name}",
            "",
        ]

        # Add tool parameters (sanitized)
        params = tool_call.parameters
        if "command" in params:
            lines.append(f"Command: {params['command']}")
        elif "path" in params:
            lines.append(f"File: {params['path']}")

        lines.append("")

        # Add error details
        if error.original_error:
            # Truncate long errors
            err_display = error.original_error[:500]
            if len(error.original_error) > 500:
                err_display += "..."
            lines.append(f"Error output:\n{err_display}")
            lines.append("")

        # Add known solution if available
        if error.details.get("known_solution"):
            lines.append(f"Known solution: {error.details['known_solution']}")
            lines.append("")

        # Add recovery attempts so far
        if error.retry_count > 0:
            lines.append(f"Previous attempts: {error.retry_count}")
            lines.append("")

        return "\n".join(lines)

    def _build_questions(self, error: ClassifiedError) -> list[str]:
        """Build specific questions based on error category."""
        questions: list[str] = []

        category_questions = {
            ErrorCategory.AUTHENTICATION: [
                "Do you have valid API keys/credentials configured?",
                "Should I try a different authentication method?",
                "Can you provide the necessary credentials?",
            ],
            ErrorCategory.PERMISSION: [
                "Should I use sudo for this operation?",
                "Is there an alternative path I should use?",
                "Can you adjust the file permissions?",
            ],
            ErrorCategory.CONFIGURATION: [
                "What configuration values should I use?",
                "Is there a config file I should create or modify?",
                "Should I use default settings?",
            ],
            ErrorCategory.DEPENDENCY: [
                "Which package version should I use?",
                "Should I try a different package?",
                "Can I install the dependency manually?",
            ],
            ErrorCategory.BUILD: [
                "Should I try a different build approach?",
                "Are there build prerequisites I'm missing?",
                "Should I skip the build check for now?",
            ],
        }

        questions = category_questions.get(error.category, [
            "How would you like me to proceed?",
            "Should I try a different approach?",
            "Can you provide more context about this error?",
        ])

        return questions

    def _build_options(self, error: ClassifiedError) -> list[dict[str, str]]:
        """Build actionable options for the user."""
        options: list[dict[str, str]] = [
            {"label": "Skip this step", "action": "skip"},
            {"label": "Retry with different parameters", "action": "retry"},
            {"label": "Try a completely different approach", "action": "alternative"},
        ]

        if error.category == ErrorCategory.AUTHENTICATION:
            options.insert(0, {
                "label": "Provide credentials",
                "action": "provide_credentials",
            })

        if error.category == ErrorCategory.PERMISSION:
            options.insert(0, {
                "label": "Use sudo",
                "action": "use_sudo",
            })

        options.append({"label": "Abort the task", "action": "abort"})

        return options
