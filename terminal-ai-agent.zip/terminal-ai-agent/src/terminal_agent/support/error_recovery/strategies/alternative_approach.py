"""Level 3: Alternative approach — different tool or method.

When the same action keeps failing, suggest an entirely different
approach: different tool, different command, different file path, etc.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.types import ErrorCategory, RecoveryLevel, ToolCall, ToolResult
from terminal_agent.support.error_recovery.classifier import ClassifiedError

logger = logging.getLogger("terminal_agent.support.error_recovery.strategies.alternative_approach")

# Alternative tool/command suggestions per error category
_ALTERNATIVES: dict[ErrorCategory, list[dict[str, Any]]] = {
    ErrorCategory.PERMISSION: [
        {
            "description": "Use elevated privileges (sudo)",
            "tool": "execute_command",
            "param_transform": lambda p: {**p, "command": f"sudo {p.get('command', '')}"},
        },
        {
            "description": "Check if file exists first, then retry",
            "tool": "read_file",
            "param_transform": lambda p: {"path": p.get("path", p.get("file", ""))},
        },
    ],
    ErrorCategory.FILE_NOT_FOUND: [
        {
            "description": "Search for the file first",
            "tool": "search_files",
            "param_transform": lambda p: {"pattern": p.get("path", "").split("/")[-1]},
        },
        {
            "description": "Create the directory structure first",
            "tool": "execute_command",
            "param_transform": lambda p: {
                "command": f"mkdir -p {p.get('path', '').rsplit('/', 1)[0]}"
            },
        },
    ],
    ErrorCategory.NETWORK: [
        {
            "description": "Use curl instead of http_client",
            "tool": "execute_command",
            "param_transform": lambda p: {"command": f"curl -sL {p.get('url', '')}"},
        },
    ],
    ErrorCategory.RESOURCE: [
        {
            "description": "Free up resources first",
            "tool": "execute_command",
            "param_transform": lambda p: {"command": "free -h && df -h"},
        },
    ],
    ErrorCategory.BUILD: [
        {
            "description": "Try clean build",
            "tool": "execute_command",
            "param_transform": lambda p: {"command": "make clean && make"},
        },
    ],
    ErrorCategory.DEPENDENCY: [
        {
            "description": "Clear cache and reinstall",
            "tool": "execute_command",
            "param_transform": lambda p: {
                "command": "rm -rf node_modules && npm install"
            },
        },
    ],
}


class AlternativeApproachStrategy:
    """Suggest an alternative tool or method to achieve the same goal.

    Returns SUCCESS with an alternative tool call, or ESCALATE if no
    alternatives are available.
    """

    def execute(
        self,
        error: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any],
    ) -> "RecoveryResult":
        """Execute alternative approach strategy."""
        from terminal_agent.support.error_recovery.recovery_engine import (
            RecoveryOutcome, RecoveryResult,
        )

        alternatives = _ALTERNATIVES.get(error.category, [])

        # Also check context for user-suggested alternatives
        context_alts = context.get("alternative_approaches", [])
        alternatives = alternatives + context_alts

        if not alternatives:
            return RecoveryResult(
                outcome=RecoveryOutcome.ESCALATE,
                strategy="alternative_approach",
                level=RecoveryLevel.ALTERNATIVE_APPROACH,
                classified_error=error,
                suggestion=f"No alternative approaches for '{error.category.value}' — escalating",
            )

        # Pick the first alternative
        alt = alternatives[0]
        try:
            new_params = alt["param_transform"](tool_call.parameters)
        except Exception:
            new_params = tool_call.parameters

        alternative_call = ToolCall(
            name=alt.get("tool", tool_call.name),
            parameters=new_params,
        )

        return RecoveryResult(
            outcome=RecoveryOutcome.SUCCESS,
            strategy="alternative_approach",
            level=RecoveryLevel.ALTERNATIVE_APPROACH,
            classified_error=error,
            modified_tool_call=alternative_call,
            alternative_tool=alt.get("tool"),
            suggestion=alt.get("description", "Try alternative approach"),
            details={"alternatives_available": len(alternatives)},
        )
