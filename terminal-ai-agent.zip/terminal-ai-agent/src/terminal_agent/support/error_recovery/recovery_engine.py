"""Recovery engine — select and execute recovery strategies.

Given a classified error, the engine selects the best recovery strategy
from the 6-level hierarchy and executes it.  Strategies are tried in
order; if one fails, the engine escalates to the next level.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from terminal_agent.types import ErrorCategory, RecoveryLevel, ToolCall, ToolResult
from terminal_agent.support.error_recovery.classifier import ClassifiedError, ErrorClassifier
from terminal_agent.support.error_recovery.strategies.alternative_approach import AlternativeApproachStrategy
from terminal_agent.support.error_recovery.strategies.ask_user import AskUserStrategy
from terminal_agent.support.error_recovery.strategies.graceful_abort import GracefulAbortStrategy
from terminal_agent.support.error_recovery.strategies.immediate_retry import ImmediateRetryStrategy
from terminal_agent.support.error_recovery.strategies.modified_retry import ModifiedRetryStrategy
from terminal_agent.support.error_recovery.strategies.re_plan import RePlanStrategy

logger = logging.getLogger("terminal_agent.support.error_recovery.recovery_engine")


class RecoveryOutcome(str, Enum):
    """Outcome of a recovery attempt."""
    SUCCESS = "success"       # Recovery succeeded, can continue
    ESCALATE = "escalate"     # Strategy didn't help, try next level
    ABORT = "abort"           # No more strategies, must abort
    WAITING = "waiting"       # Waiting for user input


@dataclass
class RecoveryResult:
    """Result of the recovery engine's attempt."""
    outcome: RecoveryOutcome
    strategy: str
    level: RecoveryLevel
    classified_error: ClassifiedError
    suggestion: str = ""
    modified_tool_call: ToolCall | None = None
    alternative_tool: str | None = None
    details: dict[str, Any] = field(default_factory=dict)
    duration_ms: float = 0.0


class RecoveryEngine:
    """Select and execute recovery strategies for classified errors.

    The engine tries strategies in order from level 1 (immediate retry)
    to level 6 (graceful abort).  Each strategy can return SUCCESS,
    ESCALATE, or ABORT.

    Usage::

        engine = RecoveryEngine()
        classified = classifier.classify(tool_call, tool_result)
        result = engine.recover(classified, tool_call, tool_result)
        if result.outcome == RecoveryOutcome.SUCCESS:
            # Retry with result.modified_tool_call
            pass
    """

    # Max retries per level before escalating
    _MAX_RETRIES: dict[RecoveryLevel, int] = {
        RecoveryLevel.IMMEDIATE_RETRY: 2,
        RecoveryLevel.MODIFIED_RETRY: 2,
        RecoveryLevel.ALTERNATIVE_APPROACH: 1,
        RecoveryLevel.RE_PLAN: 1,
        RecoveryLevel.ASK_USER: 1,
        RecoveryLevel.GRACEFUL_ABORT: 0,
    }

    # Default starting level per error category
    _CATEGORY_START_LEVEL: dict[ErrorCategory, RecoveryLevel] = {
        ErrorCategory.SYNTAX: RecoveryLevel.MODIFIED_RETRY,
        ErrorCategory.RUNTIME: RecoveryLevel.IMMEDIATE_RETRY,
        ErrorCategory.TYPE: RecoveryLevel.MODIFIED_RETRY,
        ErrorCategory.IMPORT: RecoveryLevel.MODIFIED_RETRY,
        ErrorCategory.PERMISSION: RecoveryLevel.ALTERNATIVE_APPROACH,
        ErrorCategory.FILE_NOT_FOUND: RecoveryLevel.MODIFIED_RETRY,
        ErrorCategory.NETWORK: RecoveryLevel.IMMEDIATE_RETRY,
        ErrorCategory.API: RecoveryLevel.IMMEDIATE_RETRY,
        ErrorCategory.RATE_LIMIT: RecoveryLevel.IMMEDIATE_RETRY,
        ErrorCategory.AUTHENTICATION: RecoveryLevel.ASK_USER,
        ErrorCategory.RESOURCE: RecoveryLevel.ALTERNATIVE_APPROACH,
        ErrorCategory.DEPENDENCY: RecoveryLevel.MODIFIED_RETRY,
        ErrorCategory.BUILD: RecoveryLevel.MODIFIED_RETRY,
        ErrorCategory.TEST: RecoveryLevel.MODIFIED_RETRY,
        ErrorCategory.TIMEOUT: RecoveryLevel.MODIFIED_RETRY,
        ErrorCategory.CONFIGURATION: RecoveryLevel.ASK_USER,
        ErrorCategory.STATE: RecoveryLevel.ALTERNATIVE_APPROACH,
        ErrorCategory.CONCURRENCY: RecoveryLevel.IMMEDIATE_RETRY,
        ErrorCategory.UNKNOWN: RecoveryLevel.IMMEDIATE_RETRY,
    }

    def __init__(self) -> None:
        self._classifier = ErrorClassifier()
        self._strategies = {
            RecoveryLevel.IMMEDIATE_RETRY: ImmediateRetryStrategy(),
            RecoveryLevel.MODIFIED_RETRY: ModifiedRetryStrategy(),
            RecoveryLevel.ALTERNATIVE_APPROACH: AlternativeApproachStrategy(),
            RecoveryLevel.RE_PLAN: RePlanStrategy(),
            RecoveryLevel.ASK_USER: AskUserStrategy(),
            RecoveryLevel.GRACEFUL_ABORT: GracefulAbortStrategy(),
        }
        self._retry_counts: dict[str, int] = {}

    def recover(
        self,
        classified: ClassifiedError,
        tool_call: ToolCall,
        tool_result: ToolResult,
        context: dict[str, Any] | None = None,
    ) -> RecoveryResult:
        """Select and execute a recovery strategy.

        Args:
            classified: The classified error.
            tool_call: The original tool call that failed.
            tool_result: The result of the failed execution.
            context: Additional context (plan state, history, etc.).

        Returns:
            A ``RecoveryResult`` with the strategy outcome.
        """
        start = time.monotonic()
        ctx = context or {}

        # Determine starting level
        start_level = self._get_start_level(classified)
        current_level = start_level

        # Try each level
        while current_level.value <= RecoveryLevel.GRACEFUL_ABORT.value:
            strategy = self._strategies.get(current_level)
            if not strategy:
                current_level = RecoveryLevel(current_level.value + 1)
                continue

            # Check retry count for this level
            retry_key = f"{current_level.value}:{classified.category.value}"
            retries = self._retry_counts.get(retry_key, 0)
            max_retries = self._MAX_RETRIES.get(current_level, 1)

            if retries >= max_retries:
                logger.info(
                    "Max retries (%d) reached for %s, escalating",
                    max_retries, current_level.name,
                )
                current_level = RecoveryLevel(current_level.value + 1)
                continue

            self._retry_counts[retry_key] = retries + 1

            # Execute strategy
            logger.info(
                "Trying recovery level %d (%s) for %s",
                current_level.value, current_level.name, classified.category.value,
            )

            try:
                result = strategy.execute(
                    classified, tool_call, tool_result, ctx
                )
            except Exception as e:
                logger.warning("Strategy %s raised: %s", current_level.name, e)
                result = RecoveryResult(
                    outcome=RecoveryOutcome.ESCALATE,
                    strategy=current_level.name,
                    level=current_level,
                    classified_error=classified,
                    suggestion=f"Strategy raised exception: {e}",
                )

            result.duration_ms = (time.monotonic() - start) * 1000

            if result.outcome == RecoveryOutcome.SUCCESS:
                logger.info("Recovery succeeded at level %d", current_level.value)
                return result

            if result.outcome == RecoveryOutcome.ABORT:
                logger.info("Recovery aborted at level %d", current_level.value)
                return result

            if result.outcome == RecoveryOutcome.WAITING:
                return result

            # ESCALATE — try next level
            current_level = RecoveryLevel(current_level.value + 1)

        # All levels exhausted
        return RecoveryResult(
            outcome=RecoveryOutcome.ABORT,
            strategy="exhausted",
            level=RecoveryLevel.GRACEFUL_ABORT,
            classified_error=classified,
            suggestion="All recovery strategies exhausted. Manual intervention required.",
            duration_ms=(time.monotonic() - start) * 1000,
        )

    def reset_retry_counts(self) -> None:
        """Reset all retry counters (e.g., for a new task)."""
        self._retry_counts.clear()

    def get_retry_count(self, level: RecoveryLevel, category: ErrorCategory) -> int:
        """Get current retry count for a level/category combination."""
        return self._retry_counts.get(f"{level.value}:{category.value}", 0)

    # ── internals ───────────────────────────────────────────────────

    def _get_start_level(self, classified: ClassifiedError) -> RecoveryLevel:
        """Determine the starting recovery level for an error."""
        # If we have a known solution, start at modified retry
        if classified.details.get("known_solution"):
            return RecoveryLevel.MODIFIED_RETRY

        return self._CATEGORY_START_LEVEL.get(
            classified.category, RecoveryLevel.IMMEDIATE_RETRY
        )
