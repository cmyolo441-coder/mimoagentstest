"""Support systems for Terminal Agent."""
