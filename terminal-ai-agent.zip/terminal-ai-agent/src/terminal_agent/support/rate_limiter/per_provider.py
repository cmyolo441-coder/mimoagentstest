"""Per-provider rate limiting.

Maintains separate rate limits for each LLM provider (OpenAI,
Anthropic, Google, etc.) with configurable limits per provider.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.support.rate_limiter.token_bucket import TokenBucket
from terminal_agent.support.rate_limiter.sliding_window import SlidingWindowLimiter

logger = logging.getLogger("terminal_agent.support.rate_limiter.per_provider")


class PerProviderLimiter:
    """Rate limiter with per-provider configuration.

    Usage::

        limiter = PerProviderLimiter()
        limiter.configure("openai", requests_per_minute=60, tokens_per_minute=150000)
        limiter.configure("anthropic", requests_per_minute=50, tokens_per_minute=100000)
        if limiter.allow("openai", tokens=500):
            call_openai()
    """

    def __init__(self) -> None:
        # provider → {requests: SlidingWindow, tokens: TokenBucket}
        self._limiters: dict[str, dict[str, Any]] = {}

    def configure(
        self,
        provider: str,
        *,
        requests_per_minute: int = 60,
        tokens_per_minute: int = 0,
        burst_size: int | None = None,
    ) -> None:
        """Configure rate limits for a provider.

        Args:
            provider: Provider identifier (e.g. 'openai', 'anthropic').
            requests_per_minute: Max API calls per minute.
            tokens_per_minute: Max tokens per minute (0 = unlimited).
            burst_size: Burst capacity for token bucket (defaults to 2× rate).
        """
        self._limiters[provider] = {
            "requests": SlidingWindowLimiter(
                max_requests=requests_per_minute,
                window_seconds=60.0,
                name=f"{provider}:requests",
            ),
            "tokens": TokenBucket(
                rate=tokens_per_minute / 60.0 if tokens_per_minute else float("inf"),
                capacity=float(burst_size or (tokens_per_minute // 5 if tokens_per_minute else float("inf"))),
                name=f"{provider}:tokens",
            ) if tokens_per_minute else None,
        }
        logger.info(
            "Configured rate limits for %s: %d req/min, %d tokens/min",
            provider, requests_per_minute, tokens_per_minute,
        )

    def allow(self, provider: str, tokens: int = 0) -> bool:
        """Check if a request is allowed for *provider*.

        Args:
            provider: Provider identifier.
            tokens: Number of tokens this request will consume.

        Returns:
            True if the request is within all applicable limits.
        """
        limiters = self._limiters.get(provider)
        if limiters is None:
            # No limits configured — allow
            return True
        # Check request count
        req_limiter: SlidingWindowLimiter = limiters["requests"]
        if not req_limiter.allow():
            logger.warning("Rate limit hit for %s: request count", provider)
            return False
        # Check token budget
        token_limiter: TokenBucket | None = limiters.get("tokens")
        if token_limiter and tokens > 0:
            if not token_limiter.acquire(tokens):
                logger.warning("Rate limit hit for %s: token budget", provider)
                return False
        return True

    def wait_time(self, provider: str) -> float:
        """Estimate seconds until a request would be allowed."""
        limiters = self._limiters.get(provider)
        if limiters is None:
            return 0.0
        req_limiter: SlidingWindowLimiter = limiters["requests"]
        return req_limiter.wait_time()

    def stats(self, provider: str | None = None) -> dict[str, Any]:
        """Return rate limit statistics."""
        if provider:
            limiters = self._limiters.get(provider)
            if not limiters:
                return {"provider": provider, "configured": False}
            result: dict[str, Any] = {"provider": provider, "configured": True}
            result["requests"] = limiters["requests"].stats()
            if limiters.get("tokens"):
                result["tokens"] = limiters["tokens"].stats()
            return result
        return {p: self.stats(p) for p in self._limiters}

    def list_providers(self) -> list[str]:
        """List configured providers."""
        return list(self._limiters.keys())

    def reset(self, provider: str | None = None) -> None:
        """Reset limits for a specific or all providers."""
        if provider:
            limiters = self._limiters.get(provider)
            if limiters:
                limiters["requests"].reset()
                if limiters.get("tokens"):
                    limiters["tokens"].reset()
        else:
            for p in self._limiters:
                self.reset(p)

    def __repr__(self) -> str:
        return f"PerProviderLimiter(providers={list(self._limiters.keys())})"
