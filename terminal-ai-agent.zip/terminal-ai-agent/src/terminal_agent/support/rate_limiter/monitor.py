"""Rate limit monitor: track and report rate limit events.

Records when rate limits are hit, tracks patterns, and provides
visibility into rate limit usage across providers and tools.
"""

from __future__ import annotations

import logging
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("terminal_agent.support.rate_limiter.monitor")


@dataclass
class RateLimitEvent:
    """Record of a rate limit event."""
    source: str  # provider or tool name
    event_type: str  # "blocked", "queued", "retry", "recovered"
    timestamp: float = field(default_factory=time.time)
    wait_seconds: float = 0.0
    details: dict[str, Any] = field(default_factory=dict)


class RateLimitMonitor:
    """Monitor and report rate limit events.

    Usage::

        monitor = RateLimitMonitor()
        monitor.record("openai", "blocked", wait_seconds=2.5)
        monitor.record("openai", "recovered")
        print(monitor.summary())
    """

    def __init__(self, max_events: int = 1000) -> None:
        self._max_events = max_events
        self._events: list[RateLimitEvent] = []
        self._counts: Counter[str] = Counter()
        self._source_counts: Counter[str] = Counter()

    def record(
        self,
        source: str,
        event_type: str,
        *,
        wait_seconds: float = 0.0,
        **details: Any,
    ) -> RateLimitEvent:
        """Record a rate limit event."""
        event = RateLimitEvent(
            source=source,
            event_type=event_type,
            wait_seconds=wait_seconds,
            details=details,
        )
        self._events.append(event)
        self._counts[event_type] += 1
        self._source_counts[source] += 1

        # Trim old events
        if len(self._events) > self._max_events:
            self._events = self._events[-self._max_events:]

        if event_type == "blocked":
            logger.warning(
                "Rate limit blocked: %s (wait=%.1fs)", source, wait_seconds
            )
        elif event_type == "recovered":
            logger.info("Rate limit recovered: %s", source)

        return event

    def get_events(
        self,
        *,
        source: str | None = None,
        event_type: str | None = None,
        since: float | None = None,
        limit: int = 50,
    ) -> list[RateLimitEvent]:
        """Query recorded events with filters."""
        events = self._events
        if source:
            events = [e for e in events if e.source == source]
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        if since:
            events = [e for e in events if e.timestamp >= since]
        return events[-limit:]

    def summary(self) -> dict[str, Any]:
        """Return a summary of rate limit activity."""
        total_wait = sum(e.wait_seconds for e in self._events)
        return {
            "total_events": len(self._events),
            "event_types": dict(self._counts),
            "by_source": dict(self._source_counts),
            "total_wait_seconds": total_wait,
            "avg_wait_seconds": total_wait / len(self._events) if self._events else 0.0,
            "recent_blocks": len([
                e for e in self._events[-100:]
                if e.event_type == "blocked"
            ]),
        }

    def is_source_throttled(self, source: str, window_seconds: float = 60.0) -> bool:
        """Check if a source has been recently throttled."""
        cutoff = time.time() - window_seconds
        recent_blocks = [
            e for e in self._events
            if e.source == source and e.event_type == "blocked" and e.timestamp >= cutoff
        ]
        return len(recent_blocks) > 0

    def recommended_delay(self, source: str) -> float:
        """Recommend a delay based on recent rate limit events for *source*."""
        recent = [
            e for e in self._events[-50:]
            if e.source == source and e.event_type == "blocked"
        ]
        if not recent:
            return 0.0
        # Average of recent wait times, capped at 30s
        avg_wait = sum(e.wait_seconds for e in recent) / len(recent)
        return min(avg_wait, 30.0)

    def clear(self) -> None:
        """Clear all recorded events."""
        self._events.clear()
        self._counts.clear()
        self._source_counts.clear()

    def __repr__(self) -> str:
        return f"RateLimitMonitor(events={len(self._events)})"
