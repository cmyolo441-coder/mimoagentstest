"""Request queue for rate-limited operations.

Queues requests when rate limits are hit and processes them
in order as capacity becomes available.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger("terminal_agent.support.rate_limiter.queue")


@dataclass
class QueuedRequest:
    """A request waiting in the queue."""
    id: str
    func: Callable[..., Any]
    args: tuple = ()
    kwargs: dict = field(default_factory=dict)
    priority: int = 0  # Lower = higher priority
    enqueue_time: float = field(default_factory=time.monotonic)
    timeout: float = 30.0
    callback: Callable[[Any], None] | None = None
    error_callback: Callable[[Exception], None] | None = None


class RequestQueue:
    """Queue requests when rate limits are hit.

    Usage::

        queue = RequestQueue(max_size=100, workers=2)
        queue.start()
        future = queue.submit(my_function, arg1, arg2)
        result = future.get(timeout=30)
        queue.stop()
    """

    def __init__(
        self,
        max_size: int = 100,
        workers: int = 1,
        default_timeout: float = 30.0,
    ) -> None:
        self._max_size = max_size
        self._workers = workers
        self._default_timeout = default_timeout
        self._queue: deque[QueuedRequest] = deque()
        self._threads: list[threading.Thread] = []
        self._stop_event = threading.Event()
        self._not_empty = threading.Condition()
        self._lock = threading.Lock()
        self._stats = {"submitted": 0, "completed": 0, "failed": 0, "timed_out": 0}
        self._running = False

    # ── Lifecycle ──────────────────────────────────────────────────────

    def start(self) -> None:
        """Start worker threads."""
        if self._running:
            return
        self._running = True
        self._stop_event.clear()
        for i in range(self._workers):
            t = threading.Thread(
                target=self._worker,
                name=f"request-queue-{i}",
                daemon=True,
            )
            t.start()
            self._threads.append(t)
        logger.info("Request queue started with %d workers", self._workers)

    def stop(self, drain: bool = True) -> None:
        """Stop worker threads.

        Args:
            drain: If True, process remaining requests before stopping.
        """
        if not self._running:
            return
        if drain:
            # Wait for queue to empty
            while self._queue:
                time.sleep(0.1)
        self._stop_event.set()
        with self._not_empty:
            self._not_empty.notify_all()
        for t in self._threads:
            t.join(timeout=5.0)
        self._threads.clear()
        self._running = False
        logger.info("Request queue stopped")

    # ── Submit ─────────────────────────────────────────────────────────

    def submit(
        self,
        func: Callable[..., Any],
        *args: Any,
        priority: int = 0,
        timeout: float | None = None,
        callback: Callable[[Any], None] | None = None,
        error_callback: Callable[[Exception], None] | None = None,
        **kwargs: Any,
    ) -> QueuedRequest:
        """Submit a request to the queue.

        Args:
            func: Function to execute.
            *args: Positional arguments.
            priority: Lower values are processed first.
            timeout: Request-level timeout.
            callback: Called with result on success.
            error_callback: Called with exception on failure.

        Returns:
            The queued request object.

        Raises:
            RuntimeError: If queue is full.
        """
        with self._lock:
            if len(self._queue) >= self._max_size:
                raise RuntimeError(f"Request queue is full ({self._max_size})")
            req = QueuedRequest(
                id=f"req-{self._stats['submitted']}",
                func=func,
                args=args,
                kwargs=kwargs,
                priority=priority,
                timeout=timeout or self._default_timeout,
                callback=callback,
                error_callback=error_callback,
            )
            self._queue.append(req)
            self._stats["submitted"] += 1

        with self._not_empty:
            self._not_empty.notify()
        return req

    # ── Stats ──────────────────────────────────────────────────────────

    @property
    def pending(self) -> int:
        """Number of requests waiting in the queue."""
        return len(self._queue)

    @property
    def is_running(self) -> bool:
        """Whether the queue is processing requests."""
        return self._running

    def stats(self) -> dict[str, Any]:
        """Return queue statistics."""
        return {
            "running": self._running,
            "pending": len(self._queue),
            "max_size": self._max_size,
            "workers": self._workers,
            **self._stats,
        }

    def clear(self) -> int:
        """Remove all pending requests.  Returns count removed."""
        with self._lock:
            count = len(self._queue)
            self._queue.clear()
            return count

    # ── Worker ─────────────────────────────────────────────────────────

    def _worker(self) -> None:
        """Worker thread that processes queued requests."""
        while not self._stop_event.is_set():
            req = None
            with self._not_empty:
                if not self._queue:
                    self._not_empty.wait(timeout=1.0)
                if self._queue:
                    req = self._queue.popleft()
            if req is None:
                continue
            self._execute(req)

    def _execute(self, req: QueuedRequest) -> None:
        """Execute a single queued request."""
        try:
            result = req.func(*req.args, **req.kwargs)
            self._stats["completed"] += 1
            if req.callback:
                try:
                    req.callback(result)
                except Exception as exc:
                    logger.warning("Request callback error: %s", exc)
        except Exception as exc:
            self._stats["failed"] += 1
            logger.warning("Request %s failed: %s", req.id, exc)
            if req.error_callback:
                try:
                    req.error_callback(exc)
                except Exception as cb_exc:
                    logger.warning("Error callback error: %s", cb_exc)

    def __repr__(self) -> str:
        return (
            f"RequestQueue(pending={len(self._queue)}, "
            f"running={self._running}, workers={self._workers})"
        )
