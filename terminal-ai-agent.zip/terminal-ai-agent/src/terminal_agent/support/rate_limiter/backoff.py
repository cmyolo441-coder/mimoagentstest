"""Backoff strategies for retrying rate-limited or failed requests.

Provides exponential, linear, and fixed backoff with jitter support.
"""

from __future__ import annotations

import random
import time
from abc import ABC, abstractmethod
from typing import Any


class BackoffStrategy(ABC):
    """Base class for backoff strategies."""

    @abstractmethod
    def delay(self, attempt: int) -> float:
        """Return the delay in seconds for the given attempt number (0-indexed)."""

    @abstractmethod
    def reset(self) -> None:
        """Reset internal state."""

    def wait(self, attempt: int) -> None:
        """Sleep for the computed delay."""
        time.sleep(self.delay(attempt))


class ExponentialBackoff(BackoffStrategy):
    """Exponential backoff with optional jitter.

    delay = base * (factor ** attempt) + random_jitter

    Usage::

        backoff = ExponentialBackoff(base=1.0, factor=2.0, max_delay=60.0)
        for attempt in range(5):
            if try_request():
                break
            backoff.wait(attempt)
    """

    def __init__(
        self,
        base: float = 1.0,
        factor: float = 2.0,
        max_delay: float = 60.0,
        jitter: bool = True,
    ) -> None:
        self._base = base
        self._factor = factor
        self._max_delay = max_delay
        self._jitter = jitter

    def delay(self, attempt: int) -> float:
        """Compute exponential delay for *attempt*."""
        d = self._base * (self._factor ** attempt)
        d = min(d, self._max_delay)
        if self._jitter:
            d = d * (0.5 + random.random())
        return d

    def reset(self) -> None:
        """No state to reset."""
        pass


class LinearBackoff(BackoffStrategy):
    """Linear backoff with optional jitter.

    delay = base + (increment * attempt)

    Usage::

        backoff = LinearBackoff(base=1.0, increment=2.0, max_delay=30.0)
    """

    def __init__(
        self,
        base: float = 1.0,
        increment: float = 1.0,
        max_delay: float = 30.0,
        jitter: bool = True,
    ) -> None:
        self._base = base
        self._increment = increment
        self._max_delay = max_delay
        self._jitter = jitter

    def delay(self, attempt: int) -> float:
        d = self._base + (self._increment * attempt)
        d = min(d, self._max_delay)
        if self._jitter:
            d = d * (0.5 + random.random())
        return d

    def reset(self) -> None:
        pass


class FixedBackoff(BackoffStrategy):
    """Fixed delay backoff.

    Always returns the same delay regardless of attempt number.

    Usage::

        backoff = FixedBackoff(delay=5.0)
    """

    def __init__(self, delay: float = 5.0) -> None:
        self._delay = delay

    def delay(self, attempt: int) -> float:
        return self._delay

    def reset(self) -> None:
        pass


# Factory
_BACKOFF_STRATEGIES: dict[str, type[BackoffStrategy]] = {
    "exponential": ExponentialBackoff,
    "linear": LinearBackoff,
    "fixed": FixedBackoff,
}


def create_backoff(
    strategy: str = "exponential",
    **kwargs: Any,
) -> BackoffStrategy:
    """Create a backoff strategy by name.

    Raises:
        ValueError: If strategy name is unknown.
    """
    cls = _BACKOFF_STRATEGIES.get(strategy.lower())
    if cls is None:
        available = ", ".join(_BACKOFF_STRATEGIES)
        raise ValueError(f"Unknown backoff strategy '{strategy}'. Available: {available}")
    return cls(**kwargs)
