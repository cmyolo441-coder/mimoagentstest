"""Per-tool rate limiting.

Controls execution rate for individual tools to prevent abuse
of external services (databases, APIs, Docker, etc.).
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.support.rate_limiter.sliding_window import SlidingWindowLimiter
from terminal_agent.support.rate_limiter.token_bucket import TokenBucket

logger = logging.getLogger("terminal_agent.support.rate_limiter.per_tool")


class PerToolLimiter:
    """Rate limiter with per-tool configuration.

    Usage::

        limiter = PerToolLimiter()
        limiter.configure("shell_exec", max_per_minute=120)
        limiter.configure("http_request", max_per_minute=30, burst=10)
        if limiter.allow("shell_exec"):
            execute_command()
    """

    def __init__(self) -> None:
        self._limiters: dict[str, _ToolLimiters] = {}

    def configure(
        self,
        tool: str,
        *,
        max_per_minute: int = 120,
        max_concurrent: int = 0,
        burst: int = 0,
    ) -> None:
        """Configure rate limits for a tool.

        Args:
            tool: Tool name.
            max_per_minute: Maximum calls per minute.
            max_concurrent: Maximum concurrent executions (0 = unlimited).
            burst: Burst capacity (0 = defaults to max_per_minute / 10).
        """
        self._limiters[tool] = _ToolLimiters(
            window=SlidingWindowLimiter(
                max_requests=max_per_minute,
                window_seconds=60.0,
                name=f"{tool}:window",
            ),
            bucket=TokenBucket(
                rate=max_per_minute / 60.0,
                capacity=burst or max(1, max_per_minute // 10),
                name=f"{tool}:burst",
            ),
            max_concurrent=max_concurrent,
            current_concurrent=0,
        )
        logger.info("Configured rate limits for tool '%s': %d/min", tool, max_per_minute)

    def allow(self, tool: str) -> bool:
        """Check if a tool call is allowed.

        Returns True if within all limits.
        """
        limits = self._limiters.get(tool)
        if limits is None:
            return True
        # Check window limit
        if not limits.window.allow():
            logger.warning("Rate limit hit for tool '%s': window limit", tool)
            return False
        # Check concurrency
        if limits.max_concurrent > 0 and limits.current_concurrent >= limits.max_concurrent:
            logger.warning("Rate limit hit for tool '%s': concurrency limit", tool)
            return False
        limits.current_concurrent += 1
        return True

    def release(self, tool: str) -> None:
        """Release a concurrency slot after tool execution completes."""
        limits = self._limiters.get(tool)
        if limits and limits.current_concurrent > 0:
            limits.current_concurrent -= 1

    def wait_time(self, tool: str) -> float:
        """Estimate seconds until a call would be allowed."""
        limits = self._limiters.get(tool)
        if limits is None:
            return 0.0
        return limits.window.wait_time()

    def stats(self, tool: str | None = None) -> dict[str, Any]:
        """Return rate limit statistics."""
        if tool:
            limits = self._limiters.get(tool)
            if not limits:
                return {"tool": tool, "configured": False}
            return {
                "tool": tool,
                "configured": True,
                "window": limits.window.stats(),
                "concurrent": limits.current_concurrent,
                "max_concurrent": limits.max_concurrent,
            }
        return {t: self.stats(t) for t in self._limiters}

    def list_tools(self) -> list[str]:
        """List configured tools."""
        return list(self._limiters.keys())

    def reset(self, tool: str | None = None) -> None:
        """Reset limits for a specific or all tools."""
        if tool:
            limits = self._limiters.get(tool)
            if limits:
                limits.window.reset()
                limits.bucket.reset()
                limits.current_concurrent = 0
        else:
            for t in self._limiters:
                self.reset(t)

    def __repr__(self) -> str:
        return f"PerToolLimiter(tools={list(self._limiters.keys())})"


class _ToolLimiters:
    """Internal container for per-tool limiters."""
    __slots__ = ("window", "bucket", "max_concurrent", "current_concurrent")

    def __init__(
        self,
        window: SlidingWindowLimiter,
        bucket: TokenBucket,
        max_concurrent: int,
        current_concurrent: int,
    ) -> None:
        self.window = window
        self.bucket = bucket
        self.max_concurrent = max_concurrent
        self.current_concurrent = current_concurrent
