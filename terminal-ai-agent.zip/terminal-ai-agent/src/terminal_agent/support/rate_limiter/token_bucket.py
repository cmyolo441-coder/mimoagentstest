"""Token bucket rate limiter algorithm.

Provides smooth rate limiting with burst support.  Tokens are added
at a constant rate and consumed on each request.  When the bucket
is empty, requests are rejected or queued.
"""

from __future__ import annotations

import threading
import time
from typing import Any


class TokenBucket:
    """Thread-safe token bucket rate limiter.

    Usage::

        bucket = TokenBucket(rate=10.0, capacity=20)
        if bucket.acquire():
            do_request()
        # Or with blocking:
        bucket.acquire_blocking(timeout=5.0)
    """

    def __init__(
        self,
        rate: float,
        capacity: float,
        *,
        name: str = "",
    ) -> None:
        """
        Args:
            rate: Tokens added per second.
            capacity: Maximum tokens the bucket can hold (burst size).
            name: Optional name for identification.
        """
        self.name = name
        self._rate = rate
        self._capacity = capacity
        self._tokens = capacity
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

    # ── Core operations ────────────────────────────────────────────────

    def acquire(self, tokens: float = 1.0) -> bool:
        """Try to consume *tokens*.

        Returns True if tokens were available, False otherwise.
        Does not block.
        """
        with self._lock:
            self._refill()
            if self._tokens >= tokens:
                self._tokens -= tokens
                return True
            return False

    def acquire_blocking(self, tokens: float = 1.0, timeout: float = 30.0) -> bool:
        """Block until tokens are available or timeout.

        Returns True if tokens were acquired, False on timeout.
        """
        deadline = time.monotonic() + timeout
        while True:
            if self.acquire(tokens):
                return True
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            # Sleep for the estimated wait time
            wait = self._wait_time(tokens)
            time.sleep(min(wait, remaining, 0.1))

    def try_acquire(self, tokens: float = 1.0) -> float:
        """Try to consume tokens, returning the actual amount consumed.

        Returns 0.0 if no tokens available.
        """
        with self._lock:
            self._refill()
            available = min(self._tokens, tokens)
            if available > 0:
                self._tokens -= available
                return available
            return 0.0

    # ── State ──────────────────────────────────────────────────────────

    @property
    def tokens(self) -> float:
        """Current token count (approximate)."""
        with self._lock:
            self._refill()
            return self._tokens

    @property
    def rate(self) -> float:
        """Token refill rate (tokens per second)."""
        return self._rate

    @property
    def capacity(self) -> float:
        """Maximum burst capacity."""
        return self._capacity

    def _refill(self) -> None:
        """Add tokens based on elapsed time (caller must hold lock)."""
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self._capacity, self._tokens + elapsed * self._rate)
        self._last_refill = now

    def _wait_time(self, tokens: float) -> float:
        """Estimate seconds until *tokens* will be available."""
        with self._lock:
            self._refill()
            if self._tokens >= tokens:
                return 0.0
            deficit = tokens - self._tokens
            return deficit / self._rate if self._rate > 0 else float("inf")

    def reset(self) -> None:
        """Reset to full capacity."""
        with self._lock:
            self._tokens = self._capacity
            self._last_refill = time.monotonic()

    def stats(self) -> dict[str, Any]:
        """Return current state."""
        return {
            "name": self.name,
            "rate": self._rate,
            "capacity": self._capacity,
            "tokens": self.tokens,
            "utilization": 1.0 - (self.tokens / self._capacity) if self._capacity else 0.0,
        }

    def __repr__(self) -> str:
        return f"TokenBucket({self.name!r}, rate={self._rate}, tokens={self.tokens:.1f}/{self._capacity})"
