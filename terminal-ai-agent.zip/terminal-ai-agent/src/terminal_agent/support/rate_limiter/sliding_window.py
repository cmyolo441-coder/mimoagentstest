"""Sliding window rate limiter.

Provides precise window-based rate limiting by tracking request
timestamps within a rolling time window.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from typing import Any


class SlidingWindowLimiter:
    """Sliding window rate limiter.

    Tracks request timestamps in a deque and enforces a maximum
    count within the rolling window.

    Usage::

        limiter = SlidingWindowLimiter(max_requests=60, window_seconds=60.0)
        if limiter.allow():
            do_request()
    """

    def __init__(
        self,
        max_requests: int,
        window_seconds: float = 60.0,
        *,
        name: str = "",
    ) -> None:
        self.name = name
        self._max_requests = max_requests
        self._window = window_seconds
        self._timestamps: deque[float] = deque()
        self._lock = threading.Lock()

    def allow(self) -> bool:
        """Check if a request is allowed (and record it if so).

        Returns True if the request is within limits.
        """
        with self._lock:
            now = time.monotonic()
            self._purge(now)
            if len(self._timestamps) < self._max_requests:
                self._timestamps.append(now)
                return True
            return False

    def peek(self) -> bool:
        """Check if a request would be allowed without recording it."""
        with self._lock:
            now = time.monotonic()
            self._purge(now)
            return len(self._timestamps) < self._max_requests

    def wait_time(self) -> float:
        """Estimate seconds until a slot becomes available.

        Returns 0.0 if a slot is available now.
        """
        with self._lock:
            now = time.monotonic()
            self._purge(now)
            if len(self._timestamps) < self._max_requests:
                return 0.0
            # Time until the oldest request exits the window
            oldest = self._timestamps[0]
            return max(0.0, oldest + self._window - now)

    def current_count(self) -> int:
        """Number of requests in the current window."""
        with self._lock:
            self._purge(time.monotonic())
            return len(self._timestamps)

    @property
    def max_requests(self) -> int:
        return self._max_requests

    @property
    def window_seconds(self) -> float:
        return self._window

    def _purge(self, now: float) -> None:
        """Remove timestamps outside the window (caller must hold lock)."""
        cutoff = now - self._window
        while self._timestamps and self._timestamps[0] < cutoff:
            self._timestamps.popleft()

    def reset(self) -> None:
        """Clear all recorded timestamps."""
        with self._lock:
            self._timestamps.clear()

    def stats(self) -> dict[str, Any]:
        """Return current state."""
        with self._lock:
            now = time.monotonic()
            self._purge(now)
            return {
                "name": self.name,
                "max_requests": self._max_requests,
                "window_seconds": self._window,
                "current_count": len(self._timestamps),
                "available": self._max_requests - len(self._timestamps),
                "utilization": len(self._timestamps) / self._max_requests if self._max_requests else 0.0,
            }

    def __repr__(self) -> str:
        return (
            f"SlidingWindowLimiter({self.name!r}, "
            f"max={self._max_requests}/{self._window}s)"
        )
