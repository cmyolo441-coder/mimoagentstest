"""File-based storage for backups, exports, templates, and artifacts.

Manages on-disk directories for data that doesn't belong in SQLite:
file backups before modification, exported sessions, project templates,
cached responses, and temporary working files.
"""

from __future__ import annotations

import hashlib
import json
import logging
import shutil
import time
from pathlib import Path
from typing import Any

from terminal_agent.constants import (
    GLOBAL_BACKUP_DIR,
    GLOBAL_CACHE_DIR,
    GLOBAL_EXPORT_DIR,
    GLOBAL_TEMPLATE_DIR,
    GLOBAL_TMP_DIR,
)
from terminal_agent.exceptions import FileStoreError

logger = logging.getLogger("terminal_agent.support.persistence.file_store")

# Default directory mapping: logical name → path constant
_DEFAULT_DIRS: dict[str, Path] = {
    "backups": GLOBAL_BACKUP_DIR,
    "exports": GLOBAL_EXPORT_DIR,
    "templates": GLOBAL_TEMPLATE_DIR,
    "cache": GLOBAL_CACHE_DIR,
    "tmp": GLOBAL_TMP_DIR,
}


class FileStore:
    """Manage file-based storage directories.

    Usage::

        store = FileStore()
        store.initialize()
        path = store.put("backups", "main.py.bak", b"old content")
        data = store.get("backups", "main.py.bak")
        store.cleanup("tmp", max_age_seconds=3600)
    """

    def __init__(self, base_dir: Path | None = None) -> None:
        self._base = base_dir
        self._dirs: dict[str, Path] = {}
        self._initialized = False

    # ── Lifecycle ──────────────────────────────────────────────────────

    def initialize(self) -> None:
        """Create all managed directories."""
        for name, default_path in _DEFAULT_DIRS.items():
            path = (self._base / name) if self._base else default_path
            path.mkdir(parents=True, exist_ok=True)
            self._dirs[name] = path
        self._initialized = True
        logger.info("FileStore initialized with %d directories", len(self._dirs))

    def register_directory(self, name: str, path: Path) -> None:
        """Register an additional managed directory."""
        path.mkdir(parents=True, exist_ok=True)
        self._dirs[name] = path

    # ── CRUD ───────────────────────────────────────────────────────────

    def put(
        self,
        category: str,
        filename: str,
        data: bytes | str,
        *,
        overwrite: bool = True,
    ) -> Path:
        """Write data to a file in the given category directory.

        Args:
            category: Directory name (e.g. 'backups', 'exports').
            filename: Target filename (subdirectories allowed).
            data: Content to write.
            overwrite: If False, raise on existing file.

        Returns:
            Absolute path of the written file.
        """
        path = self._resolve(category, filename)
        if path.exists() and not overwrite:
            raise FileStoreError(f"File already exists: {path}")
        path.parent.mkdir(parents=True, exist_ok=True)
        mode = "wb" if isinstance(data, bytes) else "w"
        try:
            with open(path, mode) as fh:
                fh.write(data)
            logger.debug("Stored %s/%s (%d bytes)", category, filename, len(data))
            return path
        except OSError as exc:
            raise FileStoreError(f"Failed to write {path}: {exc}") from exc

    def get(self, category: str, filename: str) -> bytes:
        """Read file contents as bytes."""
        path = self._resolve(category, filename)
        if not path.exists():
            raise FileStoreError(f"File not found: {path}")
        try:
            return path.read_bytes()
        except OSError as exc:
            raise FileStoreError(f"Failed to read {path}: {exc}") from exc

    def get_text(self, category: str, filename: str, encoding: str = "utf-8") -> str:
        """Read file contents as text."""
        return self.get(category, filename).decode(encoding)

    def exists(self, category: str, filename: str) -> bool:
        """Check whether a file exists."""
        return self._resolve(category, filename).exists()

    def delete(self, category: str, filename: str) -> None:
        """Delete a file."""
        path = self._resolve(category, filename)
        if not path.exists():
            raise FileStoreError(f"File not found: {path}")
        try:
            path.unlink()
            logger.debug("Deleted %s/%s", category, filename)
        except OSError as exc:
            raise FileStoreError(f"Failed to delete {path}: {exc}") from exc

    def list_files(
        self,
        category: str,
        pattern: str = "*",
        recursive: bool = False,
    ) -> list[Path]:
        """List files in a category directory.

        Args:
            category: Directory name.
            pattern: Glob pattern (default '*').
            recursive: Search subdirectories.

        Returns:
            Sorted list of matching paths.
        """
        base = self._get_dir(category)
        iterator = base.rglob(pattern) if recursive else base.glob(pattern)
        return sorted(p for p in iterator if p.is_file())

    def size(self, category: str) -> int:
        """Return total size in bytes of all files in a category."""
        base = self._get_dir(category)
        total = 0
        for path in base.rglob("*"):
            if path.is_file():
                total += path.stat().st_size
        return total

    # ── Cleanup ────────────────────────────────────────────────────────

    def cleanup(self, category: str, *, max_age_seconds: float = 86400) -> int:
        """Remove files older than *max_age_seconds*.

        Returns the number of files removed.
        """
        base = self._get_dir(category)
        cutoff = time.time() - max_age_seconds
        removed = 0
        for path in base.rglob("*"):
            if path.is_file() and path.stat().st_mtime < cutoff:
                try:
                    path.unlink()
                    removed += 1
                except OSError as exc:
                    logger.warning("Failed to remove %s: %s", path, exc)
        if removed:
            logger.info("Cleaned up %d files from %s", removed, category)
        return removed

    def cleanup_empty_dirs(self, category: str) -> int:
        """Remove empty subdirectories under *category*."""
        base = self._get_dir(category)
        removed = 0
        for path in sorted(base.rglob("*"), reverse=True):
            if path.is_dir() and not any(path.iterdir()):
                try:
                    path.rmdir()
                    removed += 1
                except OSError:
                    pass
        return removed

    # ── Checksum ───────────────────────────────────────────────────────

    def checksum(self, category: str, filename: str, algorithm: str = "sha256") -> str:
        """Return hex digest of a file."""
        data = self.get(category, filename)
        return hashlib.new(algorithm, data).hexdigest()

    # ── Internal ───────────────────────────────────────────────────────

    def _get_dir(self, category: str) -> Path:
        """Look up a registered directory."""
        if category not in self._dirs:
            raise FileStoreError(
                f"Unknown storage category: '{category}'. "
                f"Available: {', '.join(self._dirs)}"
            )
        return self._dirs[category]

    def _resolve(self, category: str, filename: str) -> Path:
        """Resolve a category + filename to an absolute path, ensuring
        the result stays inside the category directory (path-traversal guard)."""
        base = self._get_dir(category)
        path = (base / filename).resolve()
        if not str(path).startswith(str(base.resolve())):
            raise FileStoreError(
                f"Path traversal detected: '{filename}' escapes '{category}' directory"
            )
        return path

    def __repr__(self) -> str:
        return f"FileStore(dirs={list(self._dirs.keys())}, initialized={self._initialized})"
