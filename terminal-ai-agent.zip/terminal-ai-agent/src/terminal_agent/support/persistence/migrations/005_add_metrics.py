"""Migration 005: Add metrics and error tracking tables.

Stores time-series metrics (counters, gauges, histograms) and
classified error records for monitoring and alerting.
"""

from __future__ import annotations

import sqlite3


def upgrade(conn: sqlite3.Connection) -> None:
    """Create the metrics and errors tables."""

    conn.executescript("""
        -- Time-series metrics storage
        CREATE TABLE IF NOT EXISTS metrics (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_name     TEXT NOT NULL,
            metric_type     TEXT NOT NULL,  -- 'counter', 'gauge', 'histogram', 'timer'
            value           REAL NOT NULL,
            tags            TEXT,  -- JSON: {"provider": "openai", "model": "gpt-4o"}
            timestamp       REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_metrics_name
            ON metrics(metric_name, timestamp);
        CREATE INDEX IF NOT EXISTS idx_metrics_type
            ON metrics(metric_type);
        CREATE INDEX IF NOT EXISTS idx_metrics_timestamp
            ON metrics(timestamp);

        -- Classified errors with recovery tracking
        CREATE TABLE IF NOT EXISTS errors (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id      TEXT REFERENCES sessions(id),
            error_category  TEXT NOT NULL,  -- matches ErrorCategory enum
            error_message   TEXT NOT NULL,
            context         TEXT,  -- JSON: stack trace, tool, parameters
            recovery_action TEXT,  -- what recovery was attempted
            recovery_outcome TEXT,  -- 'success', 'failure', 'skipped'
            timestamp       REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_errors_session
            ON errors(session_id);
        CREATE INDEX IF NOT EXISTS idx_errors_category
            ON errors(error_category);
        CREATE INDEX IF NOT EXISTS idx_errors_timestamp
            ON errors(timestamp);

        -- File change tracking
        CREATE TABLE IF NOT EXISTS file_changes (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id      TEXT NOT NULL REFERENCES sessions(id),
            file_path       TEXT NOT NULL,
            change_type     TEXT NOT NULL,  -- 'create', 'modify', 'delete', 'move'
            before_hash     TEXT,
            after_hash      TEXT,
            diff            TEXT,
            timestamp       REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_file_changes_session
            ON file_changes(session_id);
        CREATE INDEX IF NOT EXISTS idx_file_changes_path
            ON file_changes(file_path);
    """)
