"""Migration 002: Add execution traces table.

Stores complete execution traces for replay, analysis, and
self-improvement.
"""

from __future__ import annotations

import sqlite3


def upgrade(conn: sqlite3.Connection) -> None:
    """Create the traces and trace_entries tables."""

    conn.executescript("""
        -- Execution trace header
        CREATE TABLE IF NOT EXISTS traces (
            id              TEXT PRIMARY KEY,
            session_id      TEXT NOT NULL REFERENCES sessions(id),
            goal            TEXT NOT NULL,
            status          TEXT NOT NULL DEFAULT 'running',
            start_time      REAL NOT NULL,
            end_time        REAL,
            total_steps     INTEGER DEFAULT 0,
            total_tokens    INTEGER DEFAULT 0,
            total_cost      REAL DEFAULT 0.0,
            outcome         TEXT,
            metadata        TEXT,  -- JSON
            created_at      REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_traces_session
            ON traces(session_id);
        CREATE INDEX IF NOT EXISTS idx_traces_status
            ON traces(status);

        -- Individual trace entries (thoughts, actions, observations)
        CREATE TABLE IF NOT EXISTS trace_entries (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            trace_id        TEXT NOT NULL REFERENCES traces(id),
            entry_type      TEXT NOT NULL,  -- 'thought','action','observation','verification','error'
            turn_number     INTEGER,
            content         TEXT NOT NULL,
            metadata        TEXT,  -- JSON
            timestamp       REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_trace_entries_trace
            ON trace_entries(trace_id, turn_number);
        CREATE INDEX IF NOT EXISTS idx_trace_entries_type
            ON trace_entries(entry_type);
    """)
