"""Migration 004: Add prompt templates and A/B testing table.

Stores prompt templates with version tracking and effectiveness
metrics for the prompt optimizer.
"""

from __future__ import annotations

import sqlite3


def upgrade(conn: sqlite3.Connection) -> None:
    """Create the prompts table."""

    conn.executescript("""
        -- Prompt templates with versioning and effectiveness tracking
        CREATE TABLE IF NOT EXISTS prompts (
            id              TEXT PRIMARY KEY,
            name            TEXT NOT NULL,
            template        TEXT NOT NULL,
            version         INTEGER NOT NULL DEFAULT 1,
            is_active       INTEGER NOT NULL DEFAULT 1,  -- boolean
            effectiveness   REAL DEFAULT 0.0,
            test_count      INTEGER DEFAULT 0,
            success_count   INTEGER DEFAULT 0,
            avg_tokens      REAL DEFAULT 0.0,
            avg_latency_ms  REAL DEFAULT 0.0,
            tags            TEXT,  -- JSON array
            metadata        TEXT,  -- JSON
            created_at      REAL NOT NULL,
            updated_at      REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_prompts_name
            ON prompts(name);
        CREATE INDEX IF NOT EXISTS idx_prompts_active
            ON prompts(is_active, effectiveness DESC);

        -- Prompt A/B test assignments
        CREATE TABLE IF NOT EXISTS prompt_tests (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            prompt_id       TEXT NOT NULL REFERENCES prompts(id),
            session_id      TEXT REFERENCES sessions(id),
            variant         TEXT NOT NULL,  -- 'A' or 'B' or custom
            outcome         TEXT,  -- 'success', 'failure', 'timeout'
            tokens_used     INTEGER,
            latency_ms      REAL,
            created_at      REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_prompt_tests_prompt
            ON prompt_tests(prompt_id);
    """)
