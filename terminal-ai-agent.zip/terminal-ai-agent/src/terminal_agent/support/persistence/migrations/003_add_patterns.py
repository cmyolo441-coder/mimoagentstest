"""Migration 003: Add learned patterns table.

Stores reusable patterns extracted from successful task executions
for the self-improvement engine.
"""

from __future__ import annotations

import sqlite3


def upgrade(conn: sqlite3.Connection) -> None:
    """Create the patterns table."""

    conn.executescript("""
        -- Learned patterns from successful tasks
        CREATE TABLE IF NOT EXISTS patterns (
            id              TEXT PRIMARY KEY,
            name            TEXT NOT NULL,
            description     TEXT,
            pattern_type    TEXT NOT NULL,  -- 'tool_sequence', 'error_fix', 'code_pattern', etc.
            pattern_data    TEXT NOT NULL,  -- JSON: the actual pattern content
            frequency       INTEGER DEFAULT 1,
            success_rate    REAL DEFAULT 1.0,
            example_sessions TEXT,  -- JSON array of session IDs
            embedding_id    TEXT,
            created_at      REAL NOT NULL,
            updated_at      REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_patterns_type
            ON patterns(pattern_type);
        CREATE INDEX IF NOT EXISTS idx_patterns_name
            ON patterns(name);
        CREATE INDEX IF NOT EXISTS idx_patterns_frequency
            ON patterns(frequency DESC);
        CREATE INDEX IF NOT EXISTS idx_patterns_embedding
            ON patterns(embedding_id);
    """)
