"""Migration 001: Initial schema.

Creates the core tables required by the agent:
sessions, conversation_turns, tool_calls, memories, configurations.
"""

from __future__ import annotations

import sqlite3


def upgrade(conn: sqlite3.Connection) -> None:
    """Create the initial database schema."""

    conn.executescript("""
        -- Agent sessions
        CREATE TABLE IF NOT EXISTS sessions (
            id              TEXT PRIMARY KEY,
            goal            TEXT NOT NULL,
            status          TEXT NOT NULL DEFAULT 'pending',
            start_time      REAL NOT NULL,
            end_time        REAL,
            model_used      TEXT,
            total_tokens    INTEGER DEFAULT 0,
            total_cost      REAL DEFAULT 0.0,
            total_steps     INTEGER DEFAULT 0,
            outcome         TEXT,
            error_message   TEXT,
            configuration   TEXT  -- JSON snapshot of config at session start
        );

        CREATE INDEX IF NOT EXISTS idx_sessions_status
            ON sessions(status);
        CREATE INDEX IF NOT EXISTS idx_sessions_start_time
            ON sessions(start_time);

        -- Conversation turns within a session
        CREATE TABLE IF NOT EXISTS conversation_turns (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id      TEXT NOT NULL REFERENCES sessions(id),
            turn_number     INTEGER NOT NULL,
            role            TEXT NOT NULL,  -- 'user', 'assistant', 'system'
            content         TEXT NOT NULL,
            timestamp       REAL NOT NULL,
            token_count     INTEGER DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS idx_turns_session
            ON conversation_turns(session_id, turn_number);

        -- Tool calls made during a session
        CREATE TABLE IF NOT EXISTS tool_calls (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id      TEXT NOT NULL REFERENCES sessions(id),
            turn_id         INTEGER REFERENCES conversation_turns(id),
            tool_name       TEXT NOT NULL,
            parameters      TEXT,  -- JSON
            output          TEXT,
            exit_code       INTEGER,
            duration_ms     REAL,
            verification    TEXT,  -- JSON verification result
            timestamp       REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_tool_calls_session
            ON tool_calls(session_id);
        CREATE INDEX IF NOT EXISTS idx_tool_calls_tool
            ON tool_calls(tool_name);

        -- Long-term memories
        CREATE TABLE IF NOT EXISTS memories (
            id              TEXT PRIMARY KEY,
            category        TEXT NOT NULL,
            content         TEXT NOT NULL,
            embedding_id    TEXT,
            source_session  TEXT REFERENCES sessions(id),
            relevance_score REAL DEFAULT 1.0,
            access_count    INTEGER DEFAULT 0,
            last_accessed   REAL,
            metadata        TEXT,  -- JSON
            created_at      REAL NOT NULL,
            updated_at      REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_memories_category
            ON memories(category);
        CREATE INDEX IF NOT EXISTS idx_memories_embedding
            ON memories(embedding_id);

        -- Persistent configuration key-value store
        CREATE TABLE IF NOT EXISTS configurations (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            key             TEXT NOT NULL UNIQUE,
            value           TEXT NOT NULL,
            source          TEXT,  -- 'global', 'project', 'env', 'cli'
            scope           TEXT,  -- 'global', 'project'
            created_at      REAL NOT NULL,
            updated_at      REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_config_key
            ON configurations(key);
    """)
