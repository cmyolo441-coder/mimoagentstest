"""Database schema migrations.

Each migration file defines an ``upgrade(conn)`` function that applies
a single forward migration and a ``downgrade(conn)`` function for
rollback.  Migrations are executed in order based on their numeric
prefix (001, 002, …).
"""

from __future__ import annotations

import importlib
import logging
import sqlite3
from typing import Callable

from terminal_agent.exceptions import MigrationError

logger = logging.getLogger("terminal_agent.support.persistence.migrations")

# Registry: target_version → module path
# Version N means "migration that brings schema FROM version N-1 TO N".
_MIGRATIONS: dict[int, str] = {
    1: "terminal_agent.support.persistence.migrations.001_initial_schema",
    2: "terminal_agent.support.persistence.migrations.002_add_traces",
    3: "terminal_agent.support.persistence.migrations.003_add_patterns",
    4: "terminal_agent.support.persistence.migrations.004_add_prompts",
    5: "terminal_agent.support.persistence.migrations.005_add_metrics",
}


def run_migrations(
    conn: sqlite3.Connection,
    current_version: int,
    target_version: int,
) -> None:
    """Apply all pending migrations from *current_version* to *target_version*.

    Each migration runs inside its own transaction.  If any migration
    fails the error is raised and earlier migrations remain committed
    (partial progress is preserved).

    Args:
        conn: Active SQLite connection.
        current_version: Schema version already applied.
        target_version: Desired schema version.

    Raises:
        MigrationError: If a migration fails.
    """
    for version in range(current_version + 1, target_version + 1):
        module_path = _MIGRATIONS.get(version)
        if module_path is None:
            logger.warning(
                "No migration module registered for version %d, skipping", version
            )
            continue

        logger.info("Applying migration %03d: %s", version, module_path)
        try:
            module = importlib.import_module(module_path)
            upgrade_fn: Callable[[sqlite3.Connection], None] = module.upgrade
            conn.execute("BEGIN")
            try:
                upgrade_fn(conn)
                # Bump the user_version pragma to track progress
                conn.execute(f"PRAGMA user_version = {version}")
                conn.commit()
                logger.info("Migration %03d applied successfully", version)
            except Exception:
                conn.rollback()
                raise
        except Exception as exc:
            raise MigrationError(
                f"Migration {version:03d} failed: {exc}"
            ) from exc


def get_pending_migrations(current_version: int, target_version: int) -> list[int]:
    """Return list of migration versions that still need to be applied."""
    return [v for v in range(current_version + 1, target_version + 1) if v in _MIGRATIONS]
