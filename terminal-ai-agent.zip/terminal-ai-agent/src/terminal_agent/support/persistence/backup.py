"""Backup and restore for the agent's database and file data.

Supports full database backups (online backup API), file-level snapshots,
rotation of old backups, and one-click restore.
"""

from __future__ import annotations

import logging
import shutil
import sqlite3
import time
from pathlib import Path
from typing import Any

from terminal_agent.constants import GLOBAL_BACKUP_DIR, GLOBAL_DB_FILE
from terminal_agent.exceptions import PersistenceError

logger = logging.getLogger("terminal_agent.support.persistence.backup")


class BackupManager:
    """Manage database and file backups with rotation.

    Usage::

        mgr = BackupManager()
        path = mgr.create_backup("pre-migration")
        mgr.rotate(max_backups=10)
        mgr.restore(path)
    """

    def __init__(
        self,
        db_path: Path | None = None,
        backup_dir: Path | None = None,
    ) -> None:
        self._db_path = db_path or GLOBAL_DB_FILE
        self._backup_dir = backup_dir or GLOBAL_BACKUP_DIR
        self._backup_dir.mkdir(parents=True, exist_ok=True)

    # ── Database backup ────────────────────────────────────────────────

    def create_backup(self, label: str = "") -> Path:
        """Create an online backup of the SQLite database.

        Uses the SQLite Online Backup API so the database does not need
        to be closed and the backup is consistent even under concurrent
        writes.

        Args:
            label: Optional label appended to the filename for easy
                   identification (e.g. "pre-migration").

        Returns:
            Path to the backup file.
        """
        if not self._db_path.exists():
            raise PersistenceError(f"Database not found: {self._db_path}")

        timestamp = time.strftime("%Y%m%d_%H%M%S")
        suffix = f"_{label}" if label else ""
        backup_name = f"agent_backup_{timestamp}{suffix}.db"
        backup_path = self._backup_dir / backup_name

        try:
            source = sqlite3.connect(str(self._db_path))
            dest = sqlite3.connect(str(backup_path))
            source.backup(dest, pages=256, sleep=0.01)
            dest.close()
            source.close()
            logger.info("Database backup created: %s", backup_path)
            return backup_path
        except sqlite3.Error as exc:
            # Clean up partial backup
            backup_path.unlink(missing_ok=True)
            raise PersistenceError(f"Backup failed: {exc}") from exc

    def restore(self, backup_path: Path) -> None:
        """Restore the database from a backup file.

        Creates a safety backup of the current database before
        overwriting it.
        """
        if not backup_path.exists():
            raise PersistenceError(f"Backup not found: {backup_path}")

        # Safety backup of current state
        if self._db_path.exists():
            safety_path = self.create_backup("pre-restore")
            logger.info("Safety backup before restore: %s", safety_path)

        try:
            shutil.copy2(backup_path, self._db_path)
            logger.info("Database restored from %s", backup_path)
        except OSError as exc:
            raise PersistenceError(f"Restore failed: {exc}") from exc

    # ── File snapshots ─────────────────────────────────────────────────

    def snapshot_file(self, file_path: Path, label: str = "") -> Path:
        """Create a timestamped snapshot of a single file.

        Returns:
            Path to the snapshot.
        """
        if not file_path.exists():
            raise PersistenceError(f"File not found: {file_path}")

        timestamp = time.strftime("%Y%m%d_%H%M%S")
        suffix = f"_{label}" if label else ""
        backup_name = f"{file_path.name}_{timestamp}{suffix}.bak"
        backup_path = self._backup_dir / "files" / backup_name
        backup_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            shutil.copy2(file_path, backup_path)
            logger.debug("Snapshot created: %s", backup_path)
            return backup_path
        except OSError as exc:
            raise PersistenceError(f"Snapshot failed: {exc}") from exc

    def restore_file(self, backup_path: Path, target_path: Path) -> None:
        """Restore a single file from a snapshot."""
        if not backup_path.exists():
            raise PersistenceError(f"Snapshot not found: {backup_path}")
        try:
            shutil.copy2(backup_path, target_path)
            logger.info("File restored: %s → %s", backup_path, target_path)
        except OSError as exc:
            raise PersistenceError(f"File restore failed: {exc}") from exc

    # ── Listing & rotation ─────────────────────────────────────────────

    def list_backups(self) -> list[dict[str, Any]]:
        """List all database backups with metadata.

        Returns a list of dicts sorted newest-first, each containing:
        ``path``, ``name``, ``size_bytes``, ``created_at``.
        """
        backups: list[dict[str, Any]] = []
        for path in sorted(self._backup_dir.glob("agent_backup_*.db"), reverse=True):
            stat = path.stat()
            backups.append({
                "path": str(path),
                "name": path.name,
                "size_bytes": stat.st_size,
                "created_at": stat.st_mtime,
            })
        return backups

    def rotate(self, max_backups: int = 10) -> int:
        """Remove oldest backups beyond *max_backups*.

        Returns the number of backups removed.
        """
        backups = sorted(
            self._backup_dir.glob("agent_backup_*.db"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        removed = 0
        for path in backups[max_backups:]:
            try:
                path.unlink()
                removed += 1
                logger.info("Rotated out old backup: %s", path.name)
            except OSError as exc:
                logger.warning("Failed to remove backup %s: %s", path, exc)
        return removed

    def total_size(self) -> int:
        """Return total size of all backups in bytes."""
        total = 0
        for path in self._backup_dir.rglob("*"):
            if path.is_file():
                total += path.stat().st_size
        return total

    def cleanup_file_snapshots(self, max_age_seconds: float = 604800) -> int:
        """Remove file snapshots older than *max_age_seconds* (default 7 days)."""
        cutoff = time.time() - max_age_seconds
        files_dir = self._backup_dir / "files"
        if not files_dir.exists():
            return 0
        removed = 0
        for path in files_dir.rglob("*"):
            if path.is_file() and path.stat().st_mtime < cutoff:
                try:
                    path.unlink()
                    removed += 1
                except OSError:
                    pass
        return removed

    def __repr__(self) -> str:
        return f"BackupManager(db={self._db_path}, dir={self._backup_dir})"
