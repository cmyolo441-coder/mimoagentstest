"""Persistence subsystem: SQLite database, file store, and backup management.

Provides durable storage for sessions, traces, memories, patterns,
metrics, and all other data that must survive process restarts.
"""

from terminal_agent.support.persistence.database import Database
from terminal_agent.support.persistence.file_store import FileStore
from terminal_agent.support.persistence.backup import BackupManager

__all__ = [
    "Database",
    "FileStore",
    "BackupManager",
]
