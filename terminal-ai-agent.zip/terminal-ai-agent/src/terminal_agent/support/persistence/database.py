"""SQLite database management with connection pooling and migrations.

Provides thread-safe access to the agent's primary SQLite database,
including connection lifecycle, transaction management, and schema
migration support.
"""

from __future__ import annotations

import contextlib
import logging
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Generator

from terminal_agent.constants import GLOBAL_DB_FILE, DB_VERSION
from terminal_agent.exceptions import DatabaseError, MigrationError

logger = logging.getLogger("terminal_agent.support.persistence.database")

# SQLite pragmas applied to every connection for performance and safety
_PRAGMAS: list[tuple[str, str]] = [
    ("journal_mode", "WAL"),
    ("foreign_keys", "ON"),
    ("busy_timeout", "5000"),
    ("synchronous", "NORMAL"),
    ("cache_size", "-64000"),  # 64 MB
    ("temp_store", "MEMORY"),
]


class Database:
    """Thread-safe SQLite database manager.

    Usage::

        db = Database()
        db.initialize()
        with db.transaction() as tx:
            tx.execute("INSERT INTO sessions (goal) VALUES (?)", ("test",))
        rows = db.execute("SELECT * FROM sessions").fetchall()
        db.close()
    """

    def __init__(self, path: Path | str | None = None) -> None:
        self._path = Path(path) if path else GLOBAL_DB_FILE
        self._local = threading.local()
        self._lock = threading.Lock()
        self._initialized = False

    # ── Lifecycle ──────────────────────────────────────────────────────

    def initialize(self) -> None:
        """Create database file (if needed) and run pending migrations."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        conn = self._get_connection()
        try:
            self._apply_pragmas(conn)
            self._run_migrations(conn)
            self._initialized = True
            logger.info("Database initialized at %s (version %s)", self._path, DB_VERSION)
        except Exception as exc:
            raise DatabaseError(f"Failed to initialize database: {exc}") from exc

    def close(self) -> None:
        """Close the current thread's connection (if any)."""
        conn = getattr(self._local, "connection", None)
        if conn is not None:
            try:
                conn.close()
            except sqlite3.Error as exc:
                logger.warning("Error closing connection: %s", exc)
            self._local.connection = None

    def close_all(self) -> None:
        """Close connections across all threads (best-effort)."""
        # We can only close the calling thread's connection directly.
        self.close()
        logger.info("Database connections closed for current thread")

    # ── Query helpers ──────────────────────────────────────────────────

    def execute(
        self,
        sql: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> sqlite3.Cursor:
        """Execute a SQL statement and return the cursor."""
        conn = self._get_connection()
        try:
            if params:
                return conn.execute(sql, params)
            return conn.execute(sql)
        except sqlite3.Error as exc:
            raise DatabaseError(f"Query failed: {exc}") from exc

    def executemany(
        self,
        sql: str,
        params_seq: list[tuple[Any, ...]],
    ) -> sqlite3.Cursor:
        """Execute a SQL statement against many parameter sets."""
        conn = self._get_connection()
        try:
            return conn.executemany(sql, params_seq)
        except sqlite3.Error as exc:
            raise DatabaseError(f"Batch query failed: {exc}") from exc

    def executescript(self, script: str) -> None:
        """Execute a multi-statement SQL script."""
        conn = self._get_connection()
        try:
            conn.executescript(script)
        except sqlite3.Error as exc:
            raise DatabaseError(f"Script execution failed: {exc}") from exc

    def fetchone(
        self, sql: str, params: tuple[Any, ...] | None = None
    ) -> dict[str, Any] | None:
        """Execute and return a single row as a dict (or None)."""
        cursor = self.execute(sql, params)
        row = cursor.fetchone()
        if row is None:
            return None
        return dict(row)

    def fetchall(
        self, sql: str, params: tuple[Any, ...] | None = None
    ) -> list[dict[str, Any]]:
        """Execute and return all rows as a list of dicts."""
        cursor = self.execute(sql, params)
        return [dict(row) for row in cursor.fetchall()]

    # ── Transactions ───────────────────────────────────────────────────

    @contextlib.contextmanager
    def transaction(self) -> Generator[sqlite3.Connection, None, None]:
        """Context manager that commits on success, rolls back on error.

        Usage::

            with db.transaction() as tx:
                tx.execute("INSERT INTO ...")
        """
        conn = self._get_connection()
        conn.execute("BEGIN")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise

    # ── Health ─────────────────────────────────────────────────────────

    def health_check(self) -> dict[str, Any]:
        """Return database health information."""
        try:
            conn = self._get_connection()
            cursor = conn.execute("PRAGMA integrity_check")
            integrity = cursor.fetchone()[0]
            page_count = conn.execute("PRAGMA page_count").fetchone()[0]
            page_size = conn.execute("PRAGMA page_size").fetchone()[0]
            return {
                "status": "ok" if integrity == "ok" else "error",
                "path": str(self._path),
                "integrity": integrity,
                "size_bytes": page_count * page_size,
                "version": self._get_user_version(conn),
            }
        except Exception as exc:
            return {"status": "error", "error": str(exc)}

    def vacuum(self) -> None:
        """Reclaim unused space."""
        conn = self._get_connection()
        conn.execute("VACUUM")
        logger.info("Database vacuumed")

    # ── Internal ───────────────────────────────────────────────────────

    def _get_connection(self) -> sqlite3.Connection:
        """Return (or create) the current thread's connection."""
        conn = getattr(self._local, "connection", None)
        if conn is None:
            try:
                conn = sqlite3.connect(
                    str(self._path),
                    check_same_thread=False,
                    timeout=30.0,
                )
                conn.row_factory = sqlite3.Row
                self._apply_pragmas(conn)
                self._local.connection = conn
            except sqlite3.Error as exc:
                raise DatabaseError(f"Cannot connect to database: {exc}") from exc
        return conn

    def _apply_pragmas(self, conn: sqlite3.Connection) -> None:
        """Apply performance and safety pragmas."""
        for pragma, value in _PRAGMAS:
            conn.execute(f"PRAGMA {pragma} = {value}")

    def _get_user_version(self, conn: sqlite3.Connection) -> int:
        """Return the current schema version."""
        cursor = conn.execute("PRAGMA user_version")
        return cursor.fetchone()[0]

    def _run_migrations(self, conn: sqlite3.Connection) -> None:
        """Discover and run all pending migrations."""
        from terminal_agent.support.persistence.migrations import run_migrations

        current_version = self._get_user_version(conn)
        if current_version < DB_VERSION:
            run_migrations(conn, current_version, DB_VERSION)
            logger.info(
                "Migrations applied: %d → %d", current_version, DB_VERSION
            )

    # ── Dunder ─────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return f"Database(path={self._path!r}, initialized={self._initialized})"
