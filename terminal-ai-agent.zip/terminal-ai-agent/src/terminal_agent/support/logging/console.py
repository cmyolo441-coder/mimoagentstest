"""Console logging with color support and level-based formatting.

Provides a ready-to-use console handler that colorizes output
and respects terminal capabilities.
"""

from __future__ import annotations

import logging
import os
import sys
from typing import TextIO

from terminal_agent.support.logging.formatting import LogFormatter


class ConsoleLogger:
    """Configurable console logging handler.

    Usage::

        console = ConsoleLogger(level=logging.INFO, colorize=True)
        console.install()
        logging.getLogger("terminal_agent").info("Hello!")
    """

    def __init__(
        self,
        level: int = logging.INFO,
        *,
        colorize: bool | None = None,
        stream: TextIO | None = None,
        include_timestamp: bool = False,
        include_name: bool = True,
        json_format: bool = False,
    ) -> None:
        self._level = level
        # Auto-detect color support
        if colorize is None:
            self._colorize = self._supports_color(stream or sys.stderr)
        else:
            self._colorize = colorize
        self._stream = stream or sys.stderr
        self._formatter = LogFormatter(
            format="json" if json_format else "text",
            include_timestamp=include_timestamp,
            include_name=include_name,
            colorize=self._colorize,
        )

    def install(
        self,
        target_logger: logging.Logger | None = None,
    ) -> logging.Handler:
        """Attach console handler to *target_logger* (or root).

        Returns the handler for further customization.
        """
        handler = logging.StreamHandler(self._stream)
        handler.setLevel(self._level)

        # Use our custom formatter
        custom_fmt = self._formatter

        class _ConsoleFormattedHandler(logging.Handler):
            """Wrapper that applies custom console formatting."""
            def __init__(self, inner: logging.StreamHandler, formatter: LogFormatter) -> None:
                super().__init__()
                self._inner = inner
                self._fmt = formatter

            def emit(self, record: logging.LogRecord) -> None:
                try:
                    msg = self._fmt.format(record)
                    record.msg = msg
                    record.args = None
                    self._inner.emit(record)
                except Exception:
                    self.handleError(record)

            def setLevel(self, level: int) -> None:  # noqa: N802
                self._inner.setLevel(level)

            def close(self) -> None:
                self._inner.close()
                super().close()

        wrapped = _ConsoleFormattedHandler(handler, custom_fmt)
        wrapped.setLevel(self._level)

        target = target_logger or logging.getLogger()
        target.addHandler(wrapped)
        return wrapped

    @staticmethod
    def _supports_color(stream: TextIO) -> bool:
        """Detect whether the stream supports ANSI colors."""
        # Check environment variables
        if os.environ.get("NO_COLOR"):
            return False
        if os.environ.get("FORCE_COLOR"):
            return True
        # Check if stream is a TTY
        if hasattr(stream, "isatty") and stream.isatty():
            return True
        # Check TERM
        term = os.environ.get("TERM", "")
        if "color" in term or "256" in term:
            return True
        return False

    def __repr__(self) -> str:
        return f"ConsoleLogger(level={logging.getLevelName(self._level)}, colorize={self._colorize})"
