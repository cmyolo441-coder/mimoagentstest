"""Log rotation: manage log file size and age.

Provides size-based rotation (rotate when file exceeds a limit)
and time-based rotation (rotate at midnight, hourly, etc.).
"""

from __future__ import annotations

import gzip
import logging
import logging.handlers
import os
import shutil
import time
from pathlib import Path
from typing import Any

from terminal_agent.constants import GLOBAL_LOG_DIR
from terminal_agent.exceptions import PersistenceError

logger = logging.getLogger("terminal_agent.support.logging.rotation")


class RotatingFileHandler(logging.Handler):
    """Size-based rotating file handler with compression.

    Rotates the log file when it exceeds *max_bytes*.  Old files
    are compressed with gzip and numbered (.1.gz, .2.gz, …).

    Usage::

        handler = RotatingFileHandler("agent.log", max_bytes=10_000_000, backup_count=5)
        logger.addHandler(handler)
    """

    def __init__(
        self,
        filename: str | Path,
        max_bytes: int = 10_000_000,  # 10 MB
        backup_count: int = 5,
        *,
        compress: bool = True,
    ) -> None:
        super().__init__()
        self._path = Path(filename)
        self._max_bytes = max_bytes
        self._backup_count = backup_count
        self._compress = compress
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._stream = open(self._path, "a", encoding="utf-8")

    def emit(self, record: logging.LogRecord) -> None:
        """Write a log record, rotating if needed."""
        try:
            msg = self.format(record) + "\n"
            self._stream.write(msg)
            self._stream.flush()
            if self._stream.tell() >= self._max_bytes:
                self._rotate()
        except Exception:
            self.handleError(record)

    def _rotate(self) -> None:
        """Perform the rotation."""
        self._stream.close()
        # Shift existing backups
        for i in range(self._backup_count - 1, 0, -1):
            src = self._backup_path(i)
            dst = self._backup_path(i + 1)
            if src.exists():
                if dst.exists():
                    dst.unlink()
                src.rename(dst)
        # Compress current file to .1
        backup = self._backup_path(1)
        if self._compress:
            with open(self._path, "rb") as f_in, gzip.open(str(backup) + ".gz", "wb") as f_out:
                shutil.copyfileobj(f_in, f_out)
        else:
            shutil.copy2(self._path, backup)
        # Truncate current file
        self._stream = open(self._path, "w", encoding="utf-8")
        # Remove old backups beyond limit
        self._cleanup_old()

    def _backup_path(self, index: int) -> Path:
        """Return the path for the i-th backup."""
        return self._path.with_suffix(f".{index}")

    def _cleanup_old(self) -> None:
        """Remove backups beyond backup_count."""
        for i in range(self._backup_count + 1, self._backup_count + 10):
            for suffix in ("", ".gz"):
                path = self._backup_path(i)
                if suffix:
                    path = Path(str(path) + suffix)
                if path.exists():
                    path.unlink()

    def close(self) -> None:
        """Close the handler."""
        self._stream.close()
        super().close()


class TimeRotatingHandler(logging.Handler):
    """Time-based rotating file handler.

    Rotates at midnight (or configurable interval).  Old files
    are renamed with a date suffix.

    Usage::

        handler = TimeRotatingHandler("agent.log", when="midnight", backup_count=30)
        logger.addHandler(handler)
    """

    def __init__(
        self,
        filename: str | Path,
        when: str = "midnight",
        interval: int = 1,
        backup_count: int = 30,
        *,
        compress: bool = True,
    ) -> None:
        super().__init__()
        self._path = Path(filename)
        self._when = when
        self._interval = interval
        self._backup_count = backup_count
        self._compress = compress
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._stream = open(self._path, "a", encoding="utf-8")
        self._next_rollover = self._compute_next_rollover()

    def emit(self, record: logging.LogRecord) -> None:
        """Write a log record, rotating if the time has come."""
        try:
            if time.time() >= self._next_rollover:
                self._rotate()
            msg = self.format(record) + "\n"
            self._stream.write(msg)
            self._stream.flush()
        except Exception:
            self.handleError(record)

    def _rotate(self) -> None:
        """Perform time-based rotation."""
        self._stream.close()
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        backup = self._path.with_name(f"{self._path.name}.{timestamp}")
        if self._compress:
            with open(self._path, "rb") as f_in, gzip.open(str(backup) + ".gz", "wb") as f_out:
                shutil.copyfileobj(f_in, f_out)
        else:
            shutil.copy2(self._path, backup)
        self._stream = open(self._path, "w", encoding="utf-8")
        self._next_rollover = self._compute_next_rollover()
        self._cleanup_old()

    def _compute_next_rollover(self) -> float:
        """Calculate the next rollover timestamp."""
        now = time.time()
        if self._when == "midnight":
            # Next midnight
            import datetime
            tomorrow = datetime.date.today() + datetime.timedelta(days=1)
            midnight = datetime.datetime.combine(tomorrow, datetime.time.min)
            return midnight.timestamp()
        elif self._when == "h":
            return now + self._interval * 3600
        elif self._when == "d":
            return now + self._interval * 86400
        else:
            return now + 86400  # default: daily

    def _cleanup_old(self) -> None:
        """Remove backups beyond backup_count."""
        import glob
        pattern = str(self._path) + ".*"
        files = sorted(glob.glob(pattern), reverse=True)
        for path in files[self._backup_count:]:
            try:
                os.remove(path)
            except OSError:
                pass

    def close(self) -> None:
        """Close the handler."""
        self._stream.close()
        super().close()
