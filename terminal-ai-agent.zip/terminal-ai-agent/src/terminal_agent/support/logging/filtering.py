"""Log filtering: control which log records pass through.

Provides composable filters for level, name patterns, message
patterns, and custom predicates.
"""

from __future__ import annotations

import logging
import re
from typing import Callable


class LogFilter:
    """Composable log filter.

    Usage::

        filt = LogFilter(min_level=logging.WARNING)
        filt.add_name_pattern(r"terminal_agent\\.tools\\..*")
        filt.add_message_pattern(r"password|secret", exclude=True)
        logger.addFilter(filt)
    """

    def __init__(self, min_level: int = logging.DEBUG) -> None:
        self._min_level = min_level
        self._include_names: list[re.Pattern[str]] = []
        self._exclude_names: list[re.Pattern[str]] = []
        self._include_messages: list[re.Pattern[str]] = []
        self._exclude_messages: list[re.Pattern[str]] = []
        self._custom_predicates: list[Callable[[logging.LogRecord], bool]] = []

    # ── Builder methods ────────────────────────────────────────────────

    def set_min_level(self, level: int) -> LogFilter:
        """Set minimum log level."""
        self._min_level = level
        return self

    def add_name_pattern(self, pattern: str, *, exclude: bool = False) -> LogFilter:
        """Add a regex pattern for logger names.

        Args:
            pattern: Regex pattern to match against ``record.name``.
            exclude: If True, matching records are dropped.
        """
        compiled = re.compile(pattern)
        if exclude:
            self._exclude_names.append(compiled)
        else:
            self._include_names.append(compiled)
        return self

    def add_message_pattern(self, pattern: str, *, exclude: bool = False) -> LogFilter:
        """Add a regex pattern for log messages."""
        compiled = re.compile(pattern)
        if exclude:
            self._exclude_messages.append(compiled)
        else:
            self._include_messages.append(compiled)
        return self

    def add_predicate(self, fn: Callable[[logging.LogRecord], bool]) -> LogFilter:
        """Add a custom predicate.  Return True to keep the record."""
        self._custom_predicates.append(fn)
        return self

    # ── Filtering ──────────────────────────────────────────────────────

    def filter(self, record: logging.LogRecord) -> bool:
        """Evaluate all filter rules against *record*.

        Returns True if the record should pass through.
        """
        # Level check
        if record.levelno < self._min_level:
            return False

        # Name exclusion
        for pat in self._exclude_names:
            if pat.search(record.name):
                return False

        # Name inclusion (if any patterns are set, name must match at least one)
        if self._include_names:
            if not any(pat.search(record.name) for pat in self._include_names):
                return False

        # Message exclusion
        msg = record.getMessage()
        for pat in self._exclude_messages:
            if pat.search(msg):
                return False

        # Message inclusion
        if self._include_messages:
            if not any(pat.search(msg) for pat in self._include_messages):
                return False

        # Custom predicates
        for pred in self._custom_predicates:
            if not pred(record):
                return False

        return True

    def __call__(self, record: logging.LogRecord) -> bool:
        """Make the filter callable (for ``logger.addFilter``)."""
        return self.filter(record)


def create_component_filter(
    components: list[str],
    min_level: int = logging.DEBUG,
) -> LogFilter:
    """Create a filter that only passes records from the listed components.

    Args:
        components: List of component name prefixes (e.g. ["terminal_agent.tools", "terminal_agent.llm"]).
        min_level: Minimum log level.
    """
    filt = LogFilter(min_level=min_level)
    for comp in components:
        filt.add_name_pattern(f"^{re.escape(comp)}")
    return filt


def create_sensitive_filter(patterns: list[str] | None = None) -> LogFilter:
    """Create a filter that redacts sensitive information from log messages.

    This filter doesn't drop records — it modifies them to redact
    matching patterns.  Call ``filter()`` which always returns True
    but modifies the record.
    """
    default_patterns = [
        r"(?i)(api[_-]?key|token|password|secret|credential)\s*[=:]\s*\S+",
    ]
    all_patterns = default_patterns + (patterns or [])
    compiled = [re.compile(p) for p in all_patterns]

    class _SensitiveFilter:
        """Redact sensitive data from log messages."""

        def filter(self, record: logging.LogRecord) -> bool:
            msg = record.getMessage()
            for pat in compiled:
                msg = pat.sub("[REDACTED]", msg)
            # Update the record's message
            record.msg = msg
            record.args = None
            return True

    return _SensitiveFilter()  # type: ignore[return-value]
