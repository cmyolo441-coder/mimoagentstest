"""File logging handler with rotation support.

Provides a convenience wrapper that combines file logging setup
with rotation configuration.
"""

from __future__ import annotations

import logging
from pathlib import Path

from terminal_agent.constants import GLOBAL_LOG_DIR
from terminal_agent.support.logging.rotation import RotatingFileHandler, TimeRotatingHandler
from terminal_agent.support.logging.formatting import LogFormatter
from terminal_agent.support.logging.filtering import LogFilter


class FileLogHandler:
    """Set up file-based logging with rotation.

    Usage::

        handler = FileLogHandler(
            filename="agent.log",
            level=logging.DEBUG,
            max_bytes=10_000_000,
            backup_count=5,
        )
        handler.install(root_logger)
    """

    def __init__(
        self,
        filename: str = "agent.log",
        log_dir: Path | str | None = None,
        level: int = logging.DEBUG,
        *,
        rotation: str = "size",
        max_bytes: int = 10_000_000,
        backup_count: int = 5,
        when: str = "midnight",
        compress: bool = True,
        json_format: bool = False,
        include_timestamp: bool = True,
    ) -> None:
        self._log_dir = Path(log_dir) if log_dir else GLOBAL_LOG_DIR
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._filepath = self._log_dir / filename

        # Choose rotation strategy
        if rotation == "time":
            self._handler: logging.Handler = TimeRotatingHandler(
                self._filepath,
                when=when,
                backup_count=backup_count,
                compress=compress,
            )
        else:
            self._handler = RotatingFileHandler(
                self._filepath,
                max_bytes=max_bytes,
                backup_count=backup_count,
                compress=compress,
            )

        self._handler.setLevel(level)

        # Set formatter
        fmt = LogFormatter(
            format="json" if json_format else "text",
            include_timestamp=include_timestamp,
            colorize=False,
        )
        self._handler.setFormatter(logging.Formatter(
            fmt="%(message)s" if json_format else None,
        ))
        # We'll use our custom format via a wrapper
        self._custom_formatter = fmt

    def install(self, target_logger: logging.Logger | None = None) -> logging.Handler:
        """Attach this handler to *target_logger* (or the root logger).

        Returns the underlying handler for further customization.
        """
        # Wrap emit to use our custom formatter
        original_emit = self._handler.emit
        custom_fmt = self._custom_formatter

        class _FormattedHandler(logging.Handler):
            """Wrapper that applies custom formatting."""
            def __init__(self, inner: logging.Handler, formatter: LogFormatter) -> None:
                super().__init__()
                self._inner = inner
                self._fmt = formatter

            def emit(self, record: logging.LogRecord) -> None:
                try:
                    msg = self._fmt.format(record)
                    record.msg = msg
                    record.args = None
                    self._inner.emit(record)
                except Exception:
                    self.handleError(record)

            def setLevel(self, level: int) -> None:  # noqa: N802
                self._inner.setLevel(level)

            def close(self) -> None:
                self._inner.close()
                super().close()

        wrapped = _FormattedHandler(self._handler, custom_fmt)
        wrapped.setLevel(self._handler.level)

        target = target_logger or logging.getLogger()
        target.addHandler(wrapped)
        return wrapped

    @property
    def filepath(self) -> Path:
        """Path to the log file."""
        return self._filepath

    def __repr__(self) -> str:
        return f"FileLogHandler(path={self._filepath})"
