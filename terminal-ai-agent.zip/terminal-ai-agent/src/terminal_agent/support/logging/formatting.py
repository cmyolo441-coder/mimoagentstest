"""Log formatting: produce human-readable and machine-readable log lines.

Supports plain text, colored console output, and structured JSON.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any


class LogFormatter:
    """Configurable log formatter supporting text and JSON modes.

    Usage::

        fmt = LogFormatter(format="json", include_timestamp=True)
        line = fmt.format(log_record)
    """

    def __init__(
        self,
        format: str = "text",
        *,
        include_timestamp: bool = True,
        include_level: bool = True,
        include_name: bool = True,
        timestamp_format: str = "%Y-%m-%dT%H:%M:%S%z",
        colorize: bool = False,
    ) -> None:
        self._format = format
        self._include_timestamp = include_timestamp
        self._include_level = include_level
        self._include_name = include_name
        self._timestamp_format = timestamp_format
        self._colorize = colorize

        # ANSI color codes for console output
        self._COLORS: dict[int, str] = {
            logging.DEBUG: "\033[36m",     # Cyan
            logging.INFO: "\033[32m",      # Green
            logging.WARNING: "\033[33m",   # Yellow
            logging.ERROR: "\033[31m",     # Red
            logging.CRITICAL: "\033[1;31m",  # Bold Red
        }
        self._RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        """Format a LogRecord into a string."""
        if self._format == "json":
            return self._format_json(record)
        return self._format_text(record)

    def _format_text(self, record: logging.LogRecord) -> str:
        """Produce a human-readable log line."""
        parts: list[str] = []
        if self._include_timestamp:
            ts = time.strftime(self._timestamp_format, time.localtime(record.created))
            parts.append(ts)
        if self._include_level:
            level = record.levelname
            if self._colorize and record.levelno in self._COLORS:
                level = f"{self._COLORS[record.levelno]}{level}{self._RESET}"
            parts.append(f"[{level}]")
        if self._include_name:
            parts.append(f"[{record.name}]")
        parts.append(record.getMessage())
        if record.exc_info and record.exc_info[1] is not None:
            parts.append("\n" + self._format_exception(record))
        return " ".join(parts)

    def _format_json(self, record: logging.LogRecord) -> str:
        """Produce a JSON log line."""
        data: dict[str, Any] = {
            "level": record.levelname.lower(),
            "logger": record.name,
            "message": record.getMessage(),
            "timestamp": time.strftime(
                self._timestamp_format, time.localtime(record.created)
            ),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        # Include extra fields
        for key in ("session_id", "tool", "provider", "model", "duration_ms", "tokens"):
            value = getattr(record, key, None)
            if value is not None:
                data[key] = value
        if record.exc_info and record.exc_info[1] is not None:
            data["exception"] = self._format_exception(record)
        return json.dumps(data, default=str, ensure_ascii=False)

    @staticmethod
    def _format_exception(record: logging.LogRecord) -> str:
        """Format exception info as a string."""
        if record.exc_text:
            return record.exc_text
        import traceback
        return "".join(traceback.format_exception(*record.exc_info))  # type: ignore[arg-type]

    def for_component(self, component: str) -> logging.Formatter:
        """Return a standard ``logging.Formatter`` pre-configured for a component."""
        return logging.Formatter(
            fmt=f"%(asctime)s [%(levelname)s] [{component}] %(message)s",
            datefmt=self._timestamp_format,
        )
