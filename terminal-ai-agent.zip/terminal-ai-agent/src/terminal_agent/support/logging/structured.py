"""Structured JSON logging for machine-parseable log output.

Provides a logger that emits JSON-formatted records with
consistent fields, making it easy to ingest logs into
ELK, Datadog, CloudWatch, or any structured log processor.
"""

from __future__ import annotations

import json
import logging
import sys
import time
from typing import Any, TextIO


class StructuredLogger:
    """JSON-structured logger.

    Usage::

        slog = StructuredLogger("terminal_agent", output=sys.stdout)
        logger = slog.get_logger()
        logger.info("Tool executed", extra={"tool": "shell_exec", "duration_ms": 42})
    """

    def __init__(
        self,
        name: str,
        level: int = logging.INFO,
        output: TextIO | None = None,
        *,
        include_caller: bool = False,
        static_fields: dict[str, Any] | None = None,
    ) -> None:
        self._name = name
        self._level = level
        self._output = output or sys.stdout
        self._include_caller = include_caller
        self._static_fields = static_fields or {}
        self._logger = self._build_logger()

    def get_logger(self) -> logging.Logger:
        """Return the configured logger."""
        return self._logger

    def _build_logger(self) -> logging.Logger:
        """Build and configure the structured logger."""
        logger = logging.getLogger(self._name)
        logger.setLevel(self._level)
        # Remove existing handlers to avoid duplicates
        logger.handlers.clear()
        handler = logging.StreamHandler(self._output)
        handler.setLevel(self._level)
        formatter = _StructuredFormatter(
            include_caller=self._include_caller,
            static_fields=self._static_fields,
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.propagate = False
        return logger

    def set_level(self, level: int) -> None:
        """Change the log level."""
        self._level = level
        self._logger.setLevel(level)
        for handler in self._logger.handlers:
            handler.setLevel(level)

    def add_output(self, stream: TextIO) -> None:
        """Add an additional output stream."""
        handler = logging.StreamHandler(stream)
        handler.setLevel(self._level)
        handler.setFormatter(_StructuredFormatter(
            include_caller=self._include_caller,
            static_fields=self._static_fields,
        ))
        self._logger.addHandler(handler)


class _StructuredFormatter(logging.Formatter):
    """Formatter that outputs one JSON object per line."""

    # Fields we extract from LogRecord
    _RECORD_FIELDS = (
        "name", "levelname", "lineno", "funcName", "module",
        "pathname", "filename", "thread", "threadName",
        "process", "processName",
    )

    def __init__(
        self,
        include_caller: bool = False,
        static_fields: dict[str, Any] | None = None,
    ) -> None:
        super().__init__()
        self._include_caller = include_caller
        self._static = static_fields or {}

    def format(self, record: logging.LogRecord) -> str:
        data: dict[str, Any] = {
            "level": record.levelname.lower(),
            "logger": record.name,
            "message": record.getMessage(),
            "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S%z"),
        }
        # Static fields
        data.update(self._static)
        # Caller info
        if self._include_caller:
            data["module"] = record.module
            data["function"] = record.funcName
            data["line"] = record.lineno
        # Extra fields commonly used by the agent
        for key in (
            "session_id", "tool", "provider", "model",
            "duration_ms", "tokens", "cost", "exit_code",
            "error_category", "recovery_level",
        ):
            value = getattr(record, key, None)
            if value is not None:
                data[key] = value
        # Any other extra fields
        if hasattr(record, "extra_fields"):
            data.update(record.extra_fields)
        # Exception
        if record.exc_info and record.exc_info[1] is not None:
            data["exception"] = {
                "type": type(record.exc_info[1]).__name__,
                "message": str(record.exc_info[1]),
                "traceback": self.formatException(record.exc_info),
            }
        return json.dumps(data, default=str, ensure_ascii=False)
