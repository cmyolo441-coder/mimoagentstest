"""Performance analyzer — measure and analyze agent performance.

Tracks success rates, efficiency metrics, and performance trends
across tasks to identify areas for improvement.
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class TaskMetrics:
    """Metrics for a single task."""
    task_id: str
    success: bool
    duration_s: float = 0.0
    total_steps: int = 0
    total_tokens: int = 0
    total_cost: float = 0.0
    tool_calls: int = 0
    errors: int = 0
    retried_steps: int = 0


@dataclass
class PerformanceStats:
    """Aggregated performance statistics."""
    total_tasks: int = 0
    successful_tasks: int = 0
    failed_tasks: int = 0
    success_rate: float = 0.0
    avg_duration_s: float = 0.0
    avg_steps: float = 0.0
    avg_tokens: float = 0.0
    avg_cost: float = 0.0
    total_tokens: int = 0
    total_cost: float = 0.0
    avg_tool_calls: float = 0.0
    avg_errors: float = 0.0


class PerformanceAnalyzer:
    """Analyzes agent performance across tasks.

    Collects per-task metrics and computes aggregated statistics
    to identify trends, bottlenecks, and improvement areas.
    """

    def __init__(self):
        self._task_metrics: list[TaskMetrics] = []
        self._tool_stats: dict[str, list[dict[str, Any]]] = defaultdict(list)

    def record_task(self, metrics: TaskMetrics) -> None:
        """Record metrics for a completed task.

        Args:
            metrics: Task metrics to record.
        """
        self._task_metrics.append(metrics)
        logger.debug(
            "Recorded task '%s': success=%s, steps=%d, tokens=%d",
            metrics.task_id,
            metrics.success,
            metrics.total_steps,
            metrics.total_tokens,
        )

    def record_tool_usage(
        self, tool_name: str, duration_ms: float, success: bool
    ) -> None:
        """Record tool usage statistics."""
        self._tool_stats[tool_name].append({
            "duration_ms": duration_ms,
            "success": success,
            "timestamp": time.time(),
        })

    def get_stats(self, last_n: int | None = None) -> PerformanceStats:
        """Get aggregated performance statistics.

        Args:
            last_n: Only consider last N tasks (None = all).

        Returns:
            Aggregated PerformanceStats.
        """
        metrics = self._task_metrics[-last_n:] if last_n else self._task_metrics
        if not metrics:
            return PerformanceStats()

        successful = [m for m in metrics if m.success]
        failed = [m for m in metrics if not m.success]

        return PerformanceStats(
            total_tasks=len(metrics),
            successful_tasks=len(successful),
            failed_tasks=len(failed),
            success_rate=len(successful) / len(metrics) if metrics else 0.0,
            avg_duration_s=sum(m.duration_s for m in metrics) / len(metrics),
            avg_steps=sum(m.total_steps for m in metrics) / len(metrics),
            avg_tokens=sum(m.total_tokens for m in metrics) / len(metrics),
            avg_cost=sum(m.total_cost for m in metrics) / len(metrics),
            total_tokens=sum(m.total_tokens for m in metrics),
            total_cost=sum(m.total_cost for m in metrics),
            avg_tool_calls=sum(m.tool_calls for m in metrics) / len(metrics),
            avg_errors=sum(m.errors for m in metrics) / len(metrics),
        )

    def get_tool_stats(self) -> dict[str, dict[str, Any]]:
        """Get per-tool performance statistics."""
        result: dict[str, dict[str, Any]] = {}
        for tool_name, calls in self._tool_stats.items():
            durations = [c["duration_ms"] for c in calls]
            successes = [c for c in calls if c["success"]]
            result[tool_name] = {
                "total_calls": len(calls),
                "success_rate": len(successes) / len(calls) if calls else 0.0,
                "avg_duration_ms": sum(durations) / len(durations) if durations else 0.0,
                "max_duration_ms": max(durations) if durations else 0.0,
                "min_duration_ms": min(durations) if durations else 0.0,
            }
        return result

    def get_trend(self, window: int = 10) -> dict[str, Any]:
        """Get performance trend over recent tasks.

        Args:
            window: Number of tasks per window.

        Returns:
            Trend data.
        """
        if len(self._task_metrics) < window * 2:
            return {"trend": "insufficient_data"}

        recent = self._task_metrics[-window:]
        older = self._task_metrics[-window * 2:-window]

        recent_success = sum(1 for m in recent if m.success) / len(recent)
        older_success = sum(1 for m in older if m.success) / len(older)

        recent_tokens = sum(m.total_tokens for m in recent) / len(recent)
        older_tokens = sum(m.total_tokens for m in older) / len(older)

        return {
            "success_rate_change": recent_success - older_success,
            "token_efficiency_change": (older_tokens - recent_tokens) / older_tokens if older_tokens else 0,
            "recent_success_rate": recent_success,
            "older_success_rate": older_success,
            "improving": recent_success > older_success,
        }

    def get_slowest_tasks(self, limit: int = 5) -> list[TaskMetrics]:
        """Get the slowest tasks."""
        return sorted(self._task_metrics, key=lambda m: m.duration_s, reverse=True)[:limit]

    def get_most_expensive_tasks(self, limit: int = 5) -> list[TaskMetrics]:
        """Get the most expensive tasks."""
        return sorted(self._task_metrics, key=lambda m: m.total_cost, reverse=True)[:limit]
