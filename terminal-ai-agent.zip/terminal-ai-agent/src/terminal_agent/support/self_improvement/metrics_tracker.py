"""Metrics tracker — track improvement metrics over time.

Maintains time-series data for performance metrics, tool usage,
error rates, and other improvement indicators.
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class MetricPoint:
    """A single metric data point."""
    timestamp: float
    value: float
    tags: dict[str, str] = field(default_factory=dict)


class MetricsTracker:
    """Tracks improvement metrics over time.

    Maintains counters, gauges, and time-series data for
    monitoring agent performance improvements.
    """

    def __init__(self):
        self._counters: dict[str, int] = defaultdict(int)
        self._gauges: dict[str, float] = {}
        self._series: dict[str, list[MetricPoint]] = defaultdict(list)
        self._task_starts: dict[str, float] = {}
        self._max_points = 10000

    def increment(self, name: str, value: int = 1) -> None:
        """Increment a counter.

        Args:
            name: Counter name.
            value: Increment value.
        """
        self._counters[name] += value

    def set_gauge(self, name: str, value: float) -> None:
        """Set a gauge value.

        Args:
            name: Gauge name.
            value: Current value.
        """
        self._gauges[name] = value

    def record(self, name: str, value: float, tags: dict[str, str] | None = None) -> None:
        """Record a metric data point.

        Args:
            name: Metric name.
            value: Metric value.
            tags: Optional tags.
        """
        point = MetricPoint(
            timestamp=time.time(),
            value=value,
            tags=tags or {},
        )
        series = self._series[name]
        series.append(point)
        if len(series) > self._max_points:
            self._series[name] = series[-self._max_points:]

    def record_task_start(self, task_id: str) -> None:
        """Record a task start time."""
        self._task_starts[task_id] = time.time()
        self._counters["total_tasks"] += 1

    def record_task_end(
        self,
        task_id: str,
        success: bool,
        total_tokens: int = 0,
        total_cost: float = 0.0,
        total_steps: int = 0,
    ) -> None:
        """Record task completion metrics.

        Args:
            task_id: Task identifier.
            success: Whether the task succeeded.
            total_tokens: Tokens used.
            total_cost: Cost incurred.
            total_steps: Steps taken.
        """
        start_time = self._task_starts.pop(task_id, None)
        duration = time.time() - start_time if start_time else 0.0

        self._counters["completed_tasks"] += 1
        if success:
            self._counters["successful_tasks"] += 1
        else:
            self._counters["failed_tasks"] += 1

        self._counters["total_tokens"] += total_tokens
        self._counters["total_steps"] += total_steps

        self.record("task_duration", duration)
        self.record("task_tokens", total_tokens)
        self.record("task_cost", total_cost)
        self.record("task_steps", total_steps)

        self._gauges["success_rate"] = (
            self._counters["successful_tasks"] / self._counters["completed_tasks"]
            if self._counters["completed_tasks"] > 0
            else 0.0
        )

    def record_tool_call(
        self, tool_name: str, duration_ms: float, success: bool
    ) -> None:
        """Record tool call metrics."""
        self._counters[f"tool_calls:{tool_name}"] += 1
        if not success:
            self._counters[f"tool_errors:{tool_name}"] += 1
        self.record(f"tool_duration:{tool_name}", duration_ms)

    def get_counter(self, name: str) -> int:
        """Get a counter value."""
        return self._counters.get(name, 0)

    def get_gauge(self, name: str) -> float | None:
        """Get a gauge value."""
        return self._gauges.get(name)

    def get_series(
        self,
        name: str,
        since: float | None = None,
        limit: int = 100,
    ) -> list[MetricPoint]:
        """Get metric series data.

        Args:
            name: Metric name.
            since: Only return points after this timestamp.
            limit: Maximum points.

        Returns:
            List of metric points.
        """
        points = self._series.get(name, [])
        if since:
            points = [p for p in points if p.timestamp >= since]
        return points[-limit:]

    def get_summary(self) -> dict[str, Any]:
        """Get a summary of all tracked metrics."""
        return {
            "counters": dict(self._counters),
            "gauges": dict(self._gauges),
            "series_count": {name: len(points) for name, points in self._series.items()},
        }

    def get_success_rate(self) -> float:
        """Get the overall success rate."""
        return self._gauges.get("success_rate", 0.0)

    def get_avg_metric(self, name: str, last_n: int = 100) -> float:
        """Get the average of a metric over recent points.

        Args:
            name: Metric name.
            last_n: Number of recent points.

        Returns:
            Average value or 0.0.
        """
        points = self._series.get(name, [])[-last_n:]
        if not points:
            return 0.0
        return sum(p.value for p in points) / len(points)

    def reset(self) -> None:
        """Reset all metrics."""
        self._counters.clear()
        self._gauges.clear()
        self._series.clear()
        self._task_starts.clear()
