"""Strategy optimizer — analyze and improve planning strategies.

Tracks which planning approaches work best for different task types
and suggests strategy improvements.
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class StrategyRecord:
    """Record of a strategy used in a task."""
    strategy_id: str
    task_type: str
    tools_used: list[str] = field(default_factory=list)
    success: bool = False
    duration_s: float = 0.0
    steps: int = 0
    timestamp: float = field(default_factory=time.time)


@dataclass
class StrategySuggestion:
    """A suggestion for strategy improvement."""
    task_type: str
    suggestion: str
    reason: str
    recommended_tools: list[str] = field(default_factory=list)


class StrategyOptimizer:
    """Analyzes and improves planning strategies.

    Tracks strategy performance across task types and suggests
    optimal approaches based on historical data.
    """

    def __init__(self):
        self._records: list[StrategyRecord] = []
        self._strategy_stats: dict[str, dict[str, Any]] = defaultdict(
            lambda: {"success": 0, "total": 0, "avg_steps": 0.0}
        )

    def record_strategy(self, record: StrategyRecord) -> None:
        """Record a strategy outcome.

        Args:
            record: Strategy record.
        """
        self._records.append(record)

        key = f"{record.task_type}:{record.strategy_id}"
        stats = self._strategy_stats[key]
        stats["total"] += 1
        if record.success:
            stats["success"] += 1
        n = stats["total"]
        stats["avg_steps"] = (stats["avg_steps"] * (n - 1) + record.steps) / n

    def get_best_strategy(self, task_type: str) -> str | None:
        """Get the best strategy for a task type.

        Args:
            task_type: The task type.

        Returns:
            Best strategy ID or None.
        """
        best_id = None
        best_rate = -1.0

        for key, stats in self._strategy_stats.items():
            if not key.startswith(f"{task_type}:"):
                continue
            if stats["total"] < 2:
                continue
            rate = stats["success"] / stats["total"]
            if rate > best_rate:
                best_rate = rate
                best_id = key.split(":", 1)[1]

        return best_id

    def get_suggestions(self) -> list[dict[str, Any]]:
        """Get strategy improvement suggestions."""
        suggestions: list[dict[str, Any]] = []

        task_types: set[str] = set()
        for record in self._records:
            task_types.add(record.task_type)

        for task_type in task_types:
            records = [r for r in self._records if r.task_type == task_type]
            if len(records) < 5:
                continue

            success_rate = sum(1 for r in records if r.success) / len(records)
            if success_rate < 0.7:
                suggestions.append({
                    "task_type": task_type,
                    "suggestion": f"Consider alternative approaches for {task_type} tasks",
                    "current_success_rate": success_rate,
                })

        return suggestions

    def get_stats(self) -> dict[str, Any]:
        """Get strategy statistics."""
        return {
            "total_records": len(self._records),
            "strategies": dict(self._strategy_stats),
        }
