"""Error analyzer — find common error types and their solutions.

Analyzes errors across tasks to identify patterns, common causes,
and effective recovery strategies.
"""

from __future__ import annotations

import logging
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ErrorRecord:
    """A recorded error occurrence."""
    error_type: str
    message: str
    context: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    resolved: bool = False
    resolution: str = ""


@dataclass
class ErrorPattern:
    """A pattern of recurring errors."""
    error_type: str
    occurrences: int = 0
    resolved_count: int = 0
    common_messages: list[str] = field(default_factory=list)
    resolutions: list[str] = field(default_factory=list)
    first_seen: float = 0.0
    last_seen: float = 0.0

    @property
    def resolution_rate(self) -> float:
        return self.resolved_count / self.occurrences if self.occurrences > 0 else 0.0


class ErrorAnalyzer:
    """Analyzes errors to find patterns and solutions.

    Tracks error frequencies, identifies common causes,
    and suggests resolution strategies.
    """

    def __init__(self, max_records: int = 5000):
        self._records: list[ErrorRecord] = []
        self._patterns: dict[str, ErrorPattern] = {}
        self._max_records = max_records

    def record_error(
        self,
        error_type: str,
        message: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Record an error occurrence.

        Args:
            error_type: The error category/type.
            message: Error message.
            context: Additional context.
        """
        record = ErrorRecord(
            error_type=error_type,
            message=message,
            context=context or {},
        )
        self._records.append(record)

        if len(self._records) > self._max_records:
            self._records = self._records[-self._max_records:]

        if error_type not in self._patterns:
            self._patterns[error_type] = ErrorPattern(
                error_type=error_type,
                first_seen=time.time(),
            )

        pattern = self._patterns[error_type]
        pattern.occurrences += 1
        pattern.last_seen = time.time()

        if message not in pattern.common_messages:
            pattern.common_messages.append(message)
            if len(pattern.common_messages) > 10:
                pattern.common_messages = pattern.common_messages[-10:]

    def record_resolution(self, error_type: str, resolution: str) -> None:
        """Record a successful error resolution.

        Args:
            error_type: The error type.
            resolution: How the error was resolved.
        """
        pattern = self._patterns.get(error_type)
        if pattern:
            pattern.resolved_count += 1
            if resolution not in pattern.resolutions:
                pattern.resolutions.append(resolution)

        for record in reversed(self._records):
            if record.error_type == error_type and not record.resolved:
                record.resolved = True
                record.resolution = resolution
                break

    def get_common_errors(self, limit: int = 10) -> list[dict[str, Any]]:
        """Get the most common error types.

        Args:
            limit: Maximum number of errors to return.

        Returns:
            List of common error info dictionaries.
        """
        sorted_patterns = sorted(
            self._patterns.values(),
            key=lambda p: p.occurrences,
            reverse=True,
        )
        return [
            {
                "error_type": p.error_type,
                "occurrences": p.occurrences,
                "resolution_rate": p.resolution_rate,
                "common_messages": p.common_messages[:3],
                "resolutions": p.resolutions[:3],
            }
            for p in sorted_patterns[:limit]
        ]

    def get_summary(self) -> dict[str, Any]:
        """Get error analysis summary."""
        total = len(self._records)
        resolved = sum(1 for r in self._records if r.resolved)
        type_counts = Counter(r.error_type for r in self._records)

        return {
            "total_errors": total,
            "resolved": resolved,
            "resolution_rate": resolved / total if total > 0 else 0.0,
            "unique_types": len(self._patterns),
            "top_errors": type_counts.most_common(5),
            "patterns": {
                name: {
                    "occurrences": p.occurrences,
                    "resolution_rate": p.resolution_rate,
                }
                for name, p in self._patterns.items()
            },
        }

    def suggest_resolution(self, error_type: str, message: str) -> str | None:
        """Suggest a resolution for an error.

        Args:
            error_type: The error type.
            message: Error message.

        Returns:
            Suggested resolution or None.
        """
        pattern = self._patterns.get(error_type)
        if pattern and pattern.resolutions:
            return pattern.resolutions[0]
        return None

    def get_error_trend(self, window: int = 100) -> dict[str, Any]:
        """Get error trend over recent records."""
        if len(self._records) < window * 2:
            return {"trend": "insufficient_data"}

        recent = self._records[-window:]
        older = self._records[-window * 2:-window]

        recent_rate = len(recent) / window
        older_rate = len(older) / window

        return {
            "recent_error_rate": recent_rate,
            "older_error_rate": older_rate,
            "improving": recent_rate < older_rate,
        }
