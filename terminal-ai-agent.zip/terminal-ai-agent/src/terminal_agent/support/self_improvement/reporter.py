"""Improvement reporter — generate improvement reports.

Produces human-readable reports on agent performance, learned
patterns, and improvement recommendations.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ReportSection:
    """A section in an improvement report."""
    title: str
    content: str
    metrics: dict[str, Any] = field(default_factory=dict)


class ImprovementReporter:
    """Generates improvement reports from analysis data.

    Combines metrics, patterns, errors, and suggestions into
    structured reports for review.
    """

    def __init__(self):
        self._reports: list[dict[str, Any]] = []

    def generate(
        self,
        metrics: dict[str, Any] | None = None,
        patterns: list[Any] | None = None,
        errors: dict[str, Any] | None = None,
        prompts: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Generate an improvement report.

        Args:
            metrics: Performance metrics.
            patterns: Learned patterns.
            errors: Error analysis.
            prompts: Prompt suggestions.

        Returns:
            Structured report dictionary.
        """
        sections: list[dict[str, Any]] = []

        if metrics:
            sections.append(self._build_metrics_section(metrics))

        if patterns:
            sections.append(self._build_patterns_section(patterns))

        if errors:
            sections.append(self._build_errors_section(errors))

        if prompts:
            sections.append(self._build_prompts_section(prompts))

        report = {
            "generated_at": time.time(),
            "generated_at_iso": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()),
            "sections": sections,
            "summary": self._build_summary(metrics, patterns, errors),
        }

        self._reports.append(report)
        return report

    def get_reports(self, limit: int = 10) -> list[dict[str, Any]]:
        """Get recent reports."""
        return self._reports[-limit:]

    def _build_metrics_section(self, metrics: dict[str, Any]) -> dict[str, Any]:
        """Build the metrics section."""
        return {
            "title": "Performance Metrics",
            "content": self._format_metrics(metrics),
            "metrics": metrics,
        }

    def _build_patterns_section(self, patterns: list[Any]) -> dict[str, Any]:
        """Build the patterns section."""
        pattern_summaries = []
        for p in patterns[:10]:
            if hasattr(p, "name"):
                pattern_summaries.append({
                    "name": p.name,
                    "type": p.pattern_type if hasattr(p, "pattern_type") else "unknown",
                    "frequency": p.frequency if hasattr(p, "frequency") else 0,
                })

        return {
            "title": "Learned Patterns",
            "content": f"Total patterns: {len(patterns)}",
            "metrics": {"patterns": pattern_summaries},
        }

    def _build_errors_section(self, errors: dict[str, Any]) -> dict[str, Any]:
        """Build the errors section."""
        return {
            "title": "Error Analysis",
            "content": self._format_errors(errors),
            "metrics": errors,
        }

    def _build_prompts_section(self, prompts: list[dict[str, Any]]) -> dict[str, Any]:
        """Build the prompts section."""
        return {
            "title": "Prompt Improvement Suggestions",
            "content": f"{len(prompts)} suggestion(s) available",
            "metrics": {"suggestions": prompts},
        }

    def _build_summary(
        self,
        metrics: dict[str, Any] | None,
        patterns: list[Any] | None,
        errors: dict[str, Any] | None,
    ) -> str:
        """Build an executive summary."""
        parts: list[str] = []

        if metrics:
            success_rate = metrics.get("success_rate", 0)
            parts.append(f"Success rate: {success_rate:.0%}")

        if patterns:
            parts.append(f"Patterns learned: {len(patterns)}")

        if errors:
            total_errors = errors.get("total_errors", 0)
            parts.append(f"Errors recorded: {total_errors}")

        return " | ".join(parts) if parts else "No data available"

    def _format_metrics(self, metrics: dict[str, Any]) -> str:
        """Format metrics as readable text."""
        lines: list[str] = []
        for key, value in metrics.items():
            if isinstance(value, float):
                lines.append(f"  {key}: {value:.2f}")
            else:
                lines.append(f"  {key}: {value}")
        return "\n".join(lines)

    def _format_errors(self, errors: dict[str, Any]) -> str:
        """Format errors as readable text."""
        lines: list[str] = []
        total = errors.get("total_errors", 0)
        resolved = errors.get("resolved", 0)
        lines.append(f"Total: {total}, Resolved: {resolved}")

        top_errors = errors.get("top_errors", [])
        for error_type, count in top_errors[:5]:
            lines.append(f"  {error_type}: {count} occurrences")

        return "\n".join(lines)
