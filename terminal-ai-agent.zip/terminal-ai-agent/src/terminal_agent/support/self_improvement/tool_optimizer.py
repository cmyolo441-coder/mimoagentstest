"""Tool optimizer — analyze and optimize tool usage patterns.

Tracks tool usage statistics, identifies inefficient patterns,
and suggests better tool selection strategies.
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ToolUsageRecord:
    """Record of a tool usage."""
    tool_name: str
    task_type: str
    success: bool
    duration_ms: float
    parameters: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class ToolOptimizer:
    """Analyzes tool usage patterns and suggests optimizations.

    Tracks which tools work best for which tasks and identifies
    inefficient usage patterns.
    """

    def __init__(self):
        self._records: list[ToolUsageRecord] = []
        self._tool_stats: dict[str, dict[str, Any]] = defaultdict(
            lambda: {
                "total_calls": 0,
                "success_count": 0,
                "total_duration_ms": 0.0,
                "task_types": defaultdict(int),
            }
        )

    def record_usage(self, record: ToolUsageRecord) -> None:
        """Record a tool usage.

        Args:
            record: Tool usage record.
        """
        self._records.append(record)

        stats = self._tool_stats[record.tool_name]
        stats["total_calls"] += 1
        if record.success:
            stats["success_count"] += 1
        stats["total_duration_ms"] += record.duration_ms
        stats["task_types"][record.task_type] += 1

    def get_tool_stats(self) -> dict[str, dict[str, Any]]:
        """Get per-tool statistics."""
        result: dict[str, dict[str, Any]] = {}
        for name, stats in self._tool_stats.items():
            total = stats["total_calls"]
            result[name] = {
                "total_calls": total,
                "success_rate": stats["success_count"] / total if total > 0 else 0.0,
                "avg_duration_ms": stats["total_duration_ms"] / total if total > 0 else 0.0,
                "task_types": dict(stats["task_types"]),
            }
        return result

    def get_suggestions(self) -> list[dict[str, Any]]:
        """Get tool optimization suggestions."""
        suggestions: list[dict[str, Any]] = []

        for name, stats in self._tool_stats.items():
            total = stats["total_calls"]
            if total < 5:
                continue

            success_rate = stats["success_count"] / total
            if success_rate < 0.7:
                suggestions.append({
                    "tool": name,
                    "issue": "low_success_rate",
                    "success_rate": success_rate,
                    "suggestion": f"Tool '{name}' has low success rate ({success_rate:.0%})",
                })

            avg_duration = stats["total_duration_ms"] / total
            if avg_duration > 30000:
                suggestions.append({
                    "tool": name,
                    "issue": "slow_execution",
                    "avg_duration_ms": avg_duration,
                    "suggestion": f"Tool '{name}' is slow (avg {avg_duration:.0f}ms)",
                })

        return suggestions

    def get_best_tool_for_task(self, task_type: str) -> str | None:
        """Get the best performing tool for a task type.

        Args:
            task_type: The task type.

        Returns:
            Best tool name or None.
        """
        best_tool = None
        best_rate = -1.0

        for name, stats in self._tool_stats.items():
            task_count = stats["task_types"].get(task_type, 0)
            if task_count < 3:
                continue
            rate = stats["success_count"] / stats["total_calls"]
            if rate > best_rate:
                best_rate = rate
                best_tool = name

        return best_tool
