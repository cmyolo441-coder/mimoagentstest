"""Self-improvement system — learn from every task to improve performance.

Provides trace recording, performance analysis, pattern learning,
prompt optimization, and continuous improvement capabilities.
"""

from __future__ import annotations

from terminal_agent.support.self_improvement.engine import SelfImprovementEngine
from terminal_agent.support.self_improvement.trace_recorder import TraceRecorder
from terminal_agent.support.self_improvement.performance_analyzer import PerformanceAnalyzer
from terminal_agent.support.self_improvement.pattern_learner import PatternLearner
from terminal_agent.support.self_improvement.pattern_matcher import PatternMatcher
from terminal_agent.support.self_improvement.error_analyzer import ErrorAnalyzer
from terminal_agent.support.self_improvement.prompt_optimizer import PromptOptimizer
from terminal_agent.support.self_improvement.strategy_optimizer import StrategyOptimizer
from terminal_agent.support.self_improvement.tool_optimizer import ToolOptimizer
from terminal_agent.support.self_improvement.ab_tester import ABTester
from terminal_agent.support.self_improvement.knowledge_distiller import KnowledgeDistiller
from terminal_agent.support.self_improvement.reporter import ImprovementReporter
from terminal_agent.support.self_improvement.metrics_tracker import MetricsTracker

__all__ = [
    "SelfImprovementEngine",
    "TraceRecorder",
    "PerformanceAnalyzer",
    "PatternLearner",
    "PatternMatcher",
    "ErrorAnalyzer",
    "PromptOptimizer",
    "StrategyOptimizer",
    "ToolOptimizer",
    "ABTester",
    "KnowledgeDistiller",
    "ImprovementReporter",
    "MetricsTracker",
]
