"""Self-improvement engine — orchestrate the improvement cycle.

Coordinates trace recording, analysis, pattern extraction, and
optimization to continuously improve agent performance.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.support.self_improvement.trace_recorder import TraceRecorder
from terminal_agent.support.self_improvement.performance_analyzer import PerformanceAnalyzer
from terminal_agent.support.self_improvement.pattern_learner import PatternLearner
from terminal_agent.support.self_improvement.pattern_matcher import PatternMatcher
from terminal_agent.support.self_improvement.error_analyzer import ErrorAnalyzer
from terminal_agent.support.self_improvement.prompt_optimizer import PromptOptimizer
from terminal_agent.support.self_improvement.strategy_optimizer import StrategyOptimizer
from terminal_agent.support.self_improvement.tool_optimizer import ToolOptimizer
from terminal_agent.support.self_improvement.knowledge_distiller import KnowledgeDistiller
from terminal_agent.support.self_improvement.reporter import ImprovementReporter
from terminal_agent.support.self_improvement.metrics_tracker import MetricsTracker

logger = logging.getLogger(__name__)


@dataclass
class ImprovementCycleResult:
    """Result of a single improvement cycle."""
    patterns_extracted: int = 0
    prompts_improved: int = 0
    strategies_updated: int = 0
    knowledge_items: int = 0
    duration_ms: float = 0.0
    errors: list[str] = field(default_factory=list)


class SelfImprovementEngine:
    """Orchestrates the self-improvement cycle.

    After each task, records traces, analyzes performance, extracts
    patterns, and generates improvements for future tasks.
    """

    def __init__(self):
        self._trace_recorder = TraceRecorder()
        self._performance_analyzer = PerformanceAnalyzer()
        self._pattern_learner = PatternLearner()
        self._pattern_matcher = PatternMatcher()
        self._error_analyzer = ErrorAnalyzer()
        self._prompt_optimizer = PromptOptimizer()
        self._strategy_optimizer = StrategyOptimizer()
        self._tool_optimizer = ToolOptimizer()
        self._knowledge_distiller = KnowledgeDistiller()
        self._reporter = ImprovementReporter()
        self._metrics_tracker = MetricsTracker()
        self._cycle_count = 0

    @property
    def trace_recorder(self) -> TraceRecorder:
        return self._trace_recorder

    @property
    def pattern_learner(self) -> PatternLearner:
        return self._pattern_learner

    @property
    def pattern_matcher(self) -> PatternMatcher:
        return self._pattern_matcher

    @property
    def metrics_tracker(self) -> MetricsTracker:
        return self._metrics_tracker

    async def on_task_start(self, task_id: str, goal: str) -> None:
        """Called when a new task starts.

        Args:
            task_id: Unique task identifier.
            goal: The task goal description.
        """
        self._trace_recorder.start_trace(task_id, goal)
        self._metrics_tracker.record_task_start(task_id)
        logger.debug("Self-improvement: task '%s' started", task_id)

    async def on_task_end(
        self,
        task_id: str,
        success: bool,
        total_tokens: int = 0,
        total_cost: float = 0.0,
        total_steps: int = 0,
    ) -> None:
        """Called when a task ends. Triggers the improvement cycle.

        Args:
            task_id: The task identifier.
            success: Whether the task succeeded.
            total_tokens: Total tokens used.
            total_cost: Total cost incurred.
            total_steps: Total steps taken.
        """
        self._trace_recorder.end_trace(task_id, success)
        self._metrics_tracker.record_task_end(
            task_id, success, total_tokens, total_cost, total_steps
        )

        trace = self._trace_recorder.get_trace(task_id)
        if trace:
            await self._run_improvement_cycle(trace)

    async def on_tool_call(
        self,
        task_id: str,
        tool_name: str,
        parameters: dict[str, Any],
        result: Any,
        duration_ms: float,
        success: bool,
    ) -> None:
        """Record a tool call for analysis."""
        self._trace_recorder.record_tool_call(
            task_id, tool_name, parameters, result, duration_ms, success
        )
        self._metrics_tracker.record_tool_call(
            tool_name, duration_ms, success
        )

    async def on_error(
        self,
        task_id: str,
        error_type: str,
        error_message: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Record an error for analysis."""
        self._trace_recorder.record_error(task_id, error_type, error_message, context)
        self._error_analyzer.record_error(error_type, error_message, context)

    def find_matching_patterns(self, goal: str, context: dict[str, Any] | None = None) -> list[Any]:
        """Find patterns matching a goal.

        Args:
            goal: The task goal.
            context: Additional context.

        Returns:
            List of matching patterns.
        """
        return self._pattern_matcher.find_matches(goal, context)

    def get_improvements(self) -> dict[str, Any]:
        """Get current improvement recommendations."""
        return {
            "prompt_suggestions": self._prompt_optimizer.get_suggestions(),
            "strategy_suggestions": self._strategy_optimizer.get_suggestions(),
            "tool_suggestions": self._tool_optimizer.get_suggestions(),
            "common_errors": self._error_analyzer.get_common_errors(),
            "patterns": self._pattern_learner.get_pattern_count(),
        }

    def generate_report(self) -> dict[str, Any]:
        """Generate an improvement report."""
        return self._reporter.generate(
            metrics=self._metrics_tracker.get_summary(),
            patterns=self._pattern_learner.get_patterns(),
            errors=self._error_analyzer.get_summary(),
            prompts=self._prompt_optimizer.get_suggestions(),
        )

    async def _run_improvement_cycle(self, trace: Any) -> ImprovementCycleResult:
        """Run a single improvement cycle on a completed trace."""
        start = time.monotonic()
        result = ImprovementCycleResult()
        self._cycle_count += 1

        try:
            patterns = self._pattern_learner.learn_from_trace(trace)
            result.patterns_extracted = len(patterns)
        except Exception as exc:
            result.errors.append(f"Pattern learning: {exc}")
            logger.warning("Pattern learning failed: %s", exc)

        try:
            self._knowledge_distiller.distill(trace)
            result.knowledge_items += 1
        except Exception as exc:
            result.errors.append(f"Knowledge distillation: {exc}")

        try:
            improvements = self._prompt_optimizer.analyze_trace(trace)
            result.prompts_improved = len(improvements)
        except Exception as exc:
            result.errors.append(f"Prompt optimization: {exc}")

        result.duration_ms = (time.monotonic() - start) * 1000
        logger.debug(
            "Improvement cycle #%d: %d patterns, %d prompt improvements (%.1fms)",
            self._cycle_count,
            result.patterns_extracted,
            result.prompts_improved,
            result.duration_ms,
        )
        return result
