"""Trace recorder — record complete execution traces.

Captures every action, thought, observation, and decision
during a task for later analysis and replay.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class TraceStep:
    """A single step in an execution trace."""
    timestamp: float
    step_type: str  # thought, action, observation, verification, error, decision
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Trace:
    """A complete execution trace for a task."""
    task_id: str
    goal: str
    steps: list[TraceStep] = field(default_factory=list)
    start_time: float = 0.0
    end_time: float = 0.0
    success: bool = False
    total_tokens: int = 0
    total_cost: float = 0.0

    @property
    def duration(self) -> float:
        if self.end_time and self.start_time:
            return self.end_time - self.start_time
        return 0.0

    @property
    def step_count(self) -> int:
        return len(self.steps)

    def get_steps_by_type(self, step_type: str) -> list[TraceStep]:
        """Get all steps of a specific type."""
        return [s for s in self.steps if s.step_type == step_type]

    def get_tool_calls(self) -> list[TraceStep]:
        """Get all tool call steps."""
        return self.get_steps_by_type("action")

    def get_errors(self) -> list[TraceStep]:
        """Get all error steps."""
        return self.get_steps_by_type("error")


class TraceRecorder:
    """Records execution traces for tasks.

    Maintains active traces and stores completed traces
    for analysis by the self-improvement system.
    """

    def __init__(self, max_traces: int = 1000):
        self._active_traces: dict[str, Trace] = {}
        self._completed_traces: list[Trace] = []
        self._max_traces = max_traces

    def start_trace(self, task_id: str, goal: str) -> None:
        """Start recording a new trace.

        Args:
            task_id: Unique task identifier.
            goal: The task goal description.
        """
        trace = Trace(
            task_id=task_id,
            goal=goal,
            start_time=time.time(),
        )
        self._active_traces[task_id] = trace
        logger.debug("Started trace for task '%s'", task_id)

    def end_trace(self, task_id: str, success: bool) -> Trace | None:
        """End a trace and move it to completed.

        Args:
            task_id: The task identifier.
            success: Whether the task succeeded.

        Returns:
            The completed trace, or None if not found.
        """
        trace = self._active_traces.pop(task_id, None)
        if trace is None:
            return None

        trace.end_time = time.time()
        trace.success = success
        self._completed_traces.append(trace)

        if len(self._completed_traces) > self._max_traces:
            self._completed_traces = self._completed_traces[-self._max_traces:]

        logger.debug(
            "Ended trace for task '%s': %d steps, success=%s",
            task_id,
            trace.step_count,
            success,
        )
        return trace

    def record_step(
        self,
        task_id: str,
        step_type: str,
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Record a step in the active trace.

        Args:
            task_id: The task identifier.
            step_type: Type of step.
            content: Step content.
            metadata: Additional metadata.
        """
        trace = self._active_traces.get(task_id)
        if trace is None:
            return

        step = TraceStep(
            timestamp=time.time(),
            step_type=step_type,
            content=content,
            metadata=metadata or {},
        )
        trace.steps.append(step)

    def record_tool_call(
        self,
        task_id: str,
        tool_name: str,
        parameters: dict[str, Any],
        result: Any,
        duration_ms: float,
        success: bool,
    ) -> None:
        """Record a tool call step.

        Args:
            task_id: The task identifier.
            tool_name: Name of the tool called.
            parameters: Tool parameters.
            result: Tool result.
            duration_ms: Duration in milliseconds.
            success: Whether the call succeeded.
        """
        self.record_step(task_id, "action", f"Called {tool_name}", {
            "tool_name": tool_name,
            "parameters": parameters,
            "result": str(result)[:500],
            "duration_ms": duration_ms,
            "success": success,
        })

    def record_error(
        self,
        task_id: str,
        error_type: str,
        error_message: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Record an error step."""
        self.record_step(task_id, "error", error_message, {
            "error_type": error_type,
            **(context or {}),
        })

    def record_thought(self, task_id: str, thought: str) -> None:
        """Record a thought/reasoning step."""
        self.record_step(task_id, "thought", thought)

    def record_observation(self, task_id: str, observation: str) -> None:
        """Record an observation step."""
        self.record_step(task_id, "observation", observation)

    def get_trace(self, task_id: str) -> Trace | None:
        """Get a trace by task ID (active or completed)."""
        if task_id in self._active_traces:
            return self._active_traces[task_id]
        for trace in self._completed_traces:
            if trace.task_id == task_id:
                return trace
        return None

    def get_completed_traces(self, limit: int = 100) -> list[Trace]:
        """Get recent completed traces."""
        return self._completed_traces[-limit:]

    def get_trace_count(self) -> int:
        """Get total number of completed traces."""
        return len(self._completed_traces)

    def clear(self) -> None:
        """Clear all completed traces."""
        self._completed_traces.clear()
