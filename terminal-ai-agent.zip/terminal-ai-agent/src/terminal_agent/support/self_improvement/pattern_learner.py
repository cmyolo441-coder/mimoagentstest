"""Pattern learner — extract reusable patterns from successful tasks.

Analyzes completed task traces to identify common patterns,
strategies, and solutions that can be reused in future tasks.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class Pattern:
    """A learned pattern from task execution."""
    id: str
    name: str
    description: str
    pattern_type: str  # tool_sequence, strategy, solution, workaround
    steps: list[dict[str, Any]] = field(default_factory=list)
    success_count: int = 0
    failure_count: int = 0
    avg_duration_ms: float = 0.0
    tags: list[str] = field(default_factory=list)
    example_task_id: str = ""
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    @property
    def success_rate(self) -> float:
        total = self.success_count + self.failure_count
        return self.success_count / total if total > 0 else 0.0

    @property
    def frequency(self) -> int:
        return self.success_count + self.failure_count


class PatternLearner:
    """Learns patterns from task execution traces.

    Analyzes successful and failed tasks to extract reusable
    patterns that improve future task performance.
    """

    def __init__(self, min_occurrences: int = 2):
        self._patterns: dict[str, Pattern] = {}
        self._min_occurrences = min_occurrences
        self._pattern_counter = 0

    def learn_from_trace(self, trace: Any) -> list[Pattern]:
        """Extract patterns from a completed trace.

        Args:
            trace: The completed task trace.

        Returns:
            List of newly extracted or updated patterns.
        """
        patterns: list[Pattern] = []

        tool_patterns = self._extract_tool_sequences(trace)
        patterns.extend(tool_patterns)

        if hasattr(trace, "success") and trace.success:
            strategy_pattern = self._extract_strategy(trace)
            if strategy_pattern:
                patterns.append(strategy_pattern)

        for pattern in patterns:
            existing = self._find_similar(pattern)
            if existing:
                existing.success_count += 1
                existing.updated_at = time.time()
            else:
                self._patterns[pattern.id] = pattern

        return patterns

    def get_patterns(self, pattern_type: str | None = None) -> list[Pattern]:
        """Get all learned patterns.

        Args:
            pattern_type: Filter by type (None = all).

        Returns:
            List of patterns.
        """
        patterns = list(self._patterns.values())
        if pattern_type:
            patterns = [p for p in patterns if p.pattern_type == pattern_type]
        return sorted(patterns, key=lambda p: p.frequency, reverse=True)

    def get_pattern_count(self) -> int:
        """Get total number of learned patterns."""
        return len(self._patterns)

    def get_pattern(self, pattern_id: str) -> Pattern | None:
        """Get a pattern by ID."""
        return self._patterns.get(pattern_id)

    def record_outcome(self, pattern_id: str, success: bool) -> None:
        """Record the outcome of using a pattern.

        Args:
            pattern_id: The pattern ID.
            success: Whether the pattern usage succeeded.
        """
        pattern = self._patterns.get(pattern_id)
        if pattern:
            if success:
                pattern.success_count += 1
            else:
                pattern.failure_count += 1
            pattern.updated_at = time.time()

    def _extract_tool_sequences(self, trace: Any) -> list[Pattern]:
        """Extract tool call sequence patterns."""
        patterns: list[Pattern] = []
        if not hasattr(trace, "steps"):
            return patterns

        tool_calls: list[dict[str, Any]] = []
        for step in trace.steps:
            if step.step_type == "action":
                tool_name = step.metadata.get("tool_name", "")
                if tool_name:
                    tool_calls.append({
                        "tool": tool_name,
                        "params": step.metadata.get("parameters", {}),
                        "success": step.metadata.get("success", True),
                    })

        if len(tool_calls) >= 2:
            for i in range(len(tool_calls) - 1):
                sequence = tool_calls[i:i + 2]
                if all(c["success"] for c in sequence):
                    self._pattern_counter += 1
                    pattern = Pattern(
                        id=f"seq_{self._pattern_counter}",
                        name=f"Tool sequence: {sequence[0]['tool']} -> {sequence[1]['tool']}",
                        description=f"Use {sequence[0]['tool']} followed by {sequence[1]['tool']}",
                        pattern_type="tool_sequence",
                        steps=sequence,
                        success_count=1,
                        example_task_id=getattr(trace, "task_id", ""),
                    )
                    patterns.append(pattern)

        return patterns

    def _extract_strategy(self, trace: Any) -> Pattern | None:
        """Extract a high-level strategy pattern."""
        if not hasattr(trace, "steps") or not hasattr(trace, "goal"):
            return None

        tools_used = []
        for step in trace.steps:
            if step.step_type == "action":
                tool_name = step.metadata.get("tool_name", "")
                if tool_name and tool_name not in tools_used:
                    tools_used.append(tool_name)

        if len(tools_used) >= 2:
            self._pattern_counter += 1
            return Pattern(
                id=f"strat_{self._pattern_counter}",
                name=f"Strategy: {' + '.join(tools_used[:3])}",
                description=f"Strategy for '{trace.goal[:100]}'",
                pattern_type="strategy",
                steps=[{"tools": tools_used}],
                success_count=1,
                example_task_id=getattr(trace, "task_id", ""),
            )
        return None

    def _find_similar(self, pattern: Pattern) -> Pattern | None:
        """Find an existing similar pattern."""
        for existing in self._patterns.values():
            if existing.pattern_type != pattern.pattern_type:
                continue
            if existing.name == pattern.name:
                return existing
            if pattern.pattern_type == "tool_sequence" and existing.steps and pattern.steps:
                if existing.steps[0].get("tool") == pattern.steps[0].get("tool"):
                    return existing
        return None
