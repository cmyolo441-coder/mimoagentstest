"""Pattern matcher — recognize when a new task matches known patterns.

Matches incoming tasks against learned patterns to suggest
proven strategies and tool sequences.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PatternMatch:
    """A matched pattern for a task."""
    pattern_id: str
    pattern_name: str
    confidence: float
    pattern_type: str
    suggestion: str = ""
    steps: list[dict[str, Any]] = field(default_factory=list)


class PatternMatcher:
    """Matches tasks against learned patterns.

    Uses keyword matching, goal similarity, and context analysis
    to find relevant patterns for new tasks.
    """

    def __init__(self):
        self._patterns: list[Any] = []

    def update_patterns(self, patterns: list[Any]) -> None:
        """Update the pattern index.

        Args:
            patterns: List of learned patterns.
        """
        self._patterns = list(patterns)

    def find_matches(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        min_confidence: float = 0.3,
        limit: int = 5,
    ) -> list[PatternMatch]:
        """Find patterns matching a task goal.

        Args:
            goal: The task goal description.
            context: Additional context (tools available, project type, etc.).
            min_confidence: Minimum confidence threshold.
            limit: Maximum matches to return.

        Returns:
            List of matching patterns sorted by confidence.
        """
        matches: list[PatternMatch] = []
        goal_lower = goal.lower()
        goal_words = set(goal_lower.split())

        for pattern in self._patterns:
            confidence = self._calculate_confidence(pattern, goal_lower, goal_words, context)
            if confidence >= min_confidence:
                match = PatternMatch(
                    pattern_id=pattern.id if hasattr(pattern, "id") else "",
                    pattern_name=pattern.name if hasattr(pattern, "name") else "",
                    confidence=confidence,
                    pattern_type=pattern.pattern_type if hasattr(pattern, "pattern_type") else "",
                    steps=pattern.steps if hasattr(pattern, "steps") else [],
                )
                matches.append(match)

        matches.sort(key=lambda m: m.confidence, reverse=True)
        return matches[:limit]

    def _calculate_confidence(
        self,
        pattern: Any,
        goal_lower: str,
        goal_words: set[str],
        context: dict[str, Any] | None,
    ) -> float:
        """Calculate confidence score for a pattern match."""
        score = 0.0

        pattern_desc = ""
        if hasattr(pattern, "description"):
            pattern_desc = pattern.description.lower()
        elif hasattr(pattern, "name"):
            pattern_desc = pattern.name.lower()

        if pattern_desc:
            pattern_words = set(pattern_desc.split())
            overlap = goal_words & pattern_words
            if pattern_words:
                score += len(overlap) / len(pattern_words) * 0.5

        if hasattr(pattern, "tags"):
            for tag in pattern.tags:
                if tag.lower() in goal_lower:
                    score += 0.2

        if hasattr(pattern, "success_rate"):
            score += pattern.success_rate * 0.2

        if hasattr(pattern, "frequency"):
            freq_score = min(1.0, pattern.frequency / 10)
            score += freq_score * 0.1

        return min(1.0, score)
