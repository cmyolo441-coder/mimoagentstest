"""A/B tester — test variations of prompts and strategies.

Provides statistical A/B testing to compare different approaches
and determine which performs better.
"""

from __future__ import annotations

import logging
import random
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ABTestVariant:
    """A variant in an A/B test."""
    id: str
    name: str
    description: str = ""
    sample_count: int = 0
    success_count: int = 0
    total_score: float = 0.0

    @property
    def success_rate(self) -> float:
        return self.success_count / self.sample_count if self.sample_count > 0 else 0.0

    @property
    def avg_score(self) -> float:
        return self.total_score / self.sample_count if self.sample_count > 0 else 0.0


@dataclass
class ABTest:
    """An A/B test experiment."""
    id: str
    name: str
    variants: list[ABTestVariant] = field(default_factory=list)
    start_time: float = field(default_factory=time.time)
    end_time: float | None = None
    min_samples: int = 10
    completed: bool = False
    winner: str | None = None


class ABTester:
    """Manages A/B tests for prompt and strategy variations.

    Supports creating tests, assigning variants, recording results,
    and determining statistical winners.
    """

    def __init__(self):
        self._tests: dict[str, ABTest] = {}

    def create_test(
        self,
        test_id: str,
        name: str,
        variants: list[dict[str, str]],
        min_samples: int = 10,
    ) -> ABTest:
        """Create a new A/B test.

        Args:
            test_id: Unique test identifier.
            name: Test name.
            variants: List of variant definitions with 'id' and 'name'.
            min_samples: Minimum samples per variant before declaring winner.

        Returns:
            The created ABTest.
        """
        test_variants = [
            ABTestVariant(id=v["id"], name=v["name"], description=v.get("description", ""))
            for v in variants
        ]
        test = ABTest(
            id=test_id,
            name=name,
            variants=test_variants,
            min_samples=min_samples,
        )
        self._tests[test_id] = test
        logger.info("Created A/B test '%s' with %d variants", name, len(variants))
        return test

    def assign_variant(self, test_id: str) -> str | None:
        """Randomly assign a variant for a test.

        Args:
            test_id: The test ID.

        Returns:
            Variant ID or None if test not found.
        """
        test = self._tests.get(test_id)
        if test is None or test.completed:
            return None
        if not test.variants:
            return None
        return random.choice(test.variants).id

    def record_result(
        self,
        test_id: str,
        variant_id: str,
        success: bool,
        score: float = 0.0,
    ) -> None:
        """Record a test result.

        Args:
            test_id: The test ID.
            variant_id: The variant used.
            success: Whether the task succeeded.
            score: Quality score (0-1).
        """
        test = self._tests.get(test_id)
        if test is None:
            return

        for variant in test.variants:
            if variant.id == variant_id:
                variant.sample_count += 1
                if success:
                    variant.success_count += 1
                variant.total_score += score
                break

        self._check_completion(test)

    def get_winner(self, test_id: str) -> str | None:
        """Get the winning variant for a completed test.

        Args:
            test_id: The test ID.

        Returns:
            Winning variant ID or None.
        """
        test = self._tests.get(test_id)
        if test is None:
            return None
        return test.winner

    def get_test(self, test_id: str) -> ABTest | None:
        """Get a test by ID."""
        return self._tests.get(test_id)

    def get_results(self, test_id: str) -> dict[str, Any]:
        """Get test results.

        Args:
            test_id: The test ID.

        Returns:
            Test results dictionary.
        """
        test = self._tests.get(test_id)
        if test is None:
            return {}

        return {
            "test_id": test.id,
            "name": test.name,
            "completed": test.completed,
            "winner": test.winner,
            "variants": [
                {
                    "id": v.id,
                    "name": v.name,
                    "samples": v.sample_count,
                    "success_rate": v.success_rate,
                    "avg_score": v.avg_score,
                }
                for v in test.variants
            ],
        }

    def _check_completion(self, test: ABTest) -> None:
        """Check if a test has enough samples to determine a winner."""
        if test.completed:
            return

        if all(v.sample_count >= test.min_samples for v in test.variants):
            best = max(test.variants, key=lambda v: v.avg_score)
            test.winner = best.id
            test.completed = True
            test.end_time = time.time()
            logger.info("A/B test '%s' completed. Winner: %s", test.name, best.name)
