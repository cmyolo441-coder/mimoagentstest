"""Prompt optimizer — analyze and improve prompt effectiveness.

Tracks prompt performance, suggests improvements, and manages
A/B testing of prompt variations.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PromptVariant:
    """A variant of a prompt template."""
    id: str
    name: str
    template: str
    version: int = 1
    usage_count: int = 0
    success_count: int = 0
    avg_quality_score: float = 0.0
    created_at: float = field(default_factory=time.time)

    @property
    def success_rate(self) -> float:
        return self.success_count / self.usage_count if self.usage_count > 0 else 0.0


@dataclass
class PromptSuggestion:
    """A suggestion for prompt improvement."""
    prompt_name: str
    current_version: int
    suggestion: str
    reason: str
    expected_improvement: str = ""


class PromptOptimizer:
    """Analyzes prompt effectiveness and suggests improvements.

    Tracks how different prompt variants perform and generates
    optimization suggestions based on success patterns.
    """

    def __init__(self):
        self._variants: dict[str, list[PromptVariant]] = {}
        self._suggestions: list[PromptSuggestion] = []
        self._performance_log: list[dict[str, Any]] = []

    def register_variant(
        self,
        prompt_name: str,
        variant_id: str,
        template: str,
    ) -> PromptVariant:
        """Register a prompt variant.

        Args:
            prompt_name: The prompt template name.
            variant_id: Unique variant identifier.
            template: The prompt template text.

        Returns:
            The registered PromptVariant.
        """
        variant = PromptVariant(
            id=variant_id,
            name=prompt_name,
            template=template,
        )
        if prompt_name not in self._variants:
            self._variants[prompt_name] = []
        self._variants[prompt_name].append(variant)
        return variant

    def record_usage(
        self,
        prompt_name: str,
        variant_id: str,
        success: bool,
        quality_score: float = 0.0,
    ) -> None:
        """Record prompt usage outcome.

        Args:
            prompt_name: The prompt name.
            variant_id: The variant used.
            success: Whether the task succeeded.
            quality_score: Quality score (0-1).
        """
        variant = self._get_variant(prompt_name, variant_id)
        if variant:
            variant.usage_count += 1
            if success:
                variant.success_count += 1
            if quality_score > 0:
                n = variant.usage_count
                variant.avg_quality_score = (
                    (variant.avg_quality_score * (n - 1) + quality_score) / n
                )

        self._performance_log.append({
            "prompt_name": prompt_name,
            "variant_id": variant_id,
            "success": success,
            "quality_score": quality_score,
            "timestamp": time.time(),
        })

    def analyze_trace(self, trace: Any) -> list[PromptSuggestion]:
        """Analyze a trace for prompt improvement opportunities.

        Args:
            trace: Completed task trace.

        Returns:
            List of improvement suggestions.
        """
        suggestions: list[PromptSuggestion] = []

        if hasattr(trace, "steps"):
            error_count = sum(1 for s in trace.steps if s.step_type == "error")
            if error_count > 3:
                suggestions.append(PromptSuggestion(
                    prompt_name="system",
                    current_version=1,
                    suggestion="Add more specific error handling instructions",
                    reason=f"Task had {error_count} errors",
                ))

        return suggestions

    def get_suggestions(self) -> list[dict[str, Any]]:
        """Get current improvement suggestions."""
        return [
            {
                "prompt": s.prompt_name,
                "suggestion": s.suggestion,
                "reason": s.reason,
            }
            for s in self._suggestions
        ]

    def get_best_variant(self, prompt_name: str) -> PromptVariant | None:
        """Get the best performing variant for a prompt.

        Args:
            prompt_name: The prompt name.

        Returns:
            Best variant or None.
        """
        variants = self._variants.get(prompt_name, [])
        if not variants:
            return None
        return max(variants, key=lambda v: v.success_rate)

    def get_all_variants(self, prompt_name: str) -> list[PromptVariant]:
        """Get all variants for a prompt."""
        return self._variants.get(prompt_name, [])

    def _get_variant(self, prompt_name: str, variant_id: str) -> PromptVariant | None:
        """Get a specific variant."""
        for variant in self._variants.get(prompt_name, []):
            if variant.id == variant_id:
                return variant
        return None
