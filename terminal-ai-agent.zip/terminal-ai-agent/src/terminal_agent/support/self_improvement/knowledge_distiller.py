"""Knowledge distiller — extract general knowledge from specific tasks.

Distills task-specific learnings into reusable knowledge that
can be applied across different tasks and contexts.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class KnowledgeItem:
    """A piece of distilled knowledge."""
    id: str
    category: str  # tool_usage, error_resolution, code_pattern, workflow
    title: str
    content: str
    source_task_id: str = ""
    confidence: float = 1.0
    usage_count: int = 0
    created_at: float = field(default_factory=time.time)

    @property
    def relevance_score(self) -> float:
        """Score combining confidence and usage."""
        return self.confidence * (1 + min(1.0, self.usage_count / 10)) / 2


class KnowledgeDistiller:
    """Extracts and manages reusable knowledge from task traces.

    Analyzes completed tasks to identify generalizable knowledge
    about tools, patterns, error handling, and workflows.
    """

    def __init__(self, max_items: int = 1000):
        self._items: dict[str, KnowledgeItem] = {}
        self._counter = 0
        self._max_items = max_items

    def distill(self, trace: Any) -> list[KnowledgeItem]:
        """Extract knowledge from a completed trace.

        Args:
            trace: Completed task trace.

        Returns:
            List of extracted knowledge items.
        """
        items: list[KnowledgeItem] = []

        tool_items = self._extract_tool_knowledge(trace)
        items.extend(tool_items)

        error_items = self._extract_error_knowledge(trace)
        items.extend(error_items)

        workflow_items = self._extract_workflow_knowledge(trace)
        items.extend(workflow_items)

        for item in items:
            if item.id not in self._items:
                self._items[item.id] = item
            if len(self._items) > self._max_items:
                self._evict_oldest()

        return items

    def query(
        self,
        category: str | None = None,
        keyword: str | None = None,
        limit: int = 10,
    ) -> list[KnowledgeItem]:
        """Query knowledge items.

        Args:
            category: Filter by category.
            keyword: Filter by keyword in title/content.
            limit: Maximum results.

        Returns:
            Matching knowledge items sorted by relevance.
        """
        results = list(self._items.values())

        if category:
            results = [i for i in results if i.category == category]

        if keyword:
            keyword_lower = keyword.lower()
            results = [
                i for i in results
                if keyword_lower in i.title.lower() or keyword_lower in i.content.lower()
            ]

        results.sort(key=lambda i: i.relevance_score, reverse=True)
        return results[:limit]

    def get_stats(self) -> dict[str, Any]:
        """Get knowledge base statistics."""
        categories: dict[str, int] = {}
        for item in self._items.values():
            categories[item.category] = categories.get(item.category, 0) + 1

        return {
            "total_items": len(self._items),
            "categories": categories,
        }

    def _extract_tool_knowledge(self, trace: Any) -> list[KnowledgeItem]:
        """Extract knowledge about tool usage."""
        items: list[KnowledgeItem] = []
        if not hasattr(trace, "steps"):
            return items

        tool_sequence: list[str] = []
        for step in trace.steps:
            if step.step_type == "action":
                tool_name = step.metadata.get("tool_name", "")
                if tool_name:
                    tool_sequence.append(tool_name)

        if len(tool_sequence) >= 3:
            self._counter += 1
            items.append(KnowledgeItem(
                id=f"tool_seq_{self._counter}",
                category="tool_usage",
                title=f"Tool sequence: {' → '.join(tool_sequence[:4])}",
                content=f"Effective tool sequence: {' → '.join(tool_sequence)}",
                source_task_id=getattr(trace, "task_id", ""),
            ))

        return items

    def _extract_error_knowledge(self, trace: Any) -> list[KnowledgeItem]:
        """Extract knowledge about error handling."""
        items: list[KnowledgeItem] = []
        if not hasattr(trace, "steps"):
            return items

        for step in trace.steps:
            if step.step_type == "error":
                error_type = step.metadata.get("error_type", "unknown")
                resolution = step.metadata.get("resolution", "")
                if resolution:
                    self._counter += 1
                    items.append(KnowledgeItem(
                        id=f"error_{self._counter}",
                        category="error_resolution",
                        title=f"Error resolution: {error_type}",
                        content=f"Error: {step.content}\nResolution: {resolution}",
                        source_task_id=getattr(trace, "task_id", ""),
                    ))

        return items

    def _extract_workflow_knowledge(self, trace: Any) -> list[KnowledgeItem]:
        """Extract knowledge about workflows."""
        items: list[KnowledgeItem] = []
        if not hasattr(trace, "goal") or not hasattr(trace, "success"):
            return items

        if trace.success:
            self._counter += 1
            items.append(KnowledgeItem(
                id=f"workflow_{self._counter}",
                category="workflow",
                title=f"Successful approach: {trace.goal[:50]}",
                content=f"Goal: {trace.goal}\nSteps: {trace.step_count if hasattr(trace, 'steps') else 'N/A'}",
                source_task_id=getattr(trace, "task_id", ""),
            ))

        return items

    def _evict_oldest(self) -> None:
        """Evict the oldest knowledge item."""
        if not self._items:
            return
        oldest_id = min(self._items, key=lambda k: self._items[k].created_at)
        del self._items[oldest_id]
