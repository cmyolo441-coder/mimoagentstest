"""Counter metric: monotonically increasing value.

Used for counting events: total LLM calls, total errors, etc.
"""

from __future__ import annotations

import threading
from typing import Any


class Counter:
    """Thread-safe counter metric.

    Usage::

        c = Counter("llm_calls_total", tags={"provider": "openai"})
        c.inc()
        c.inc(5)
        print(c.value)  # 6
    """

    def __init__(
        self,
        name: str,
        *,
        description: str = "",
        tags: dict[str, str] | None = None,
    ) -> None:
        self.name = name
        self.description = description
        self.tags = tags or {}
        self._value: float = 0.0
        self._lock = threading.Lock()

    @property
    def value(self) -> float:
        """Current counter value."""
        return self._value

    def inc(self, amount: float = 1.0) -> None:
        """Increment the counter.

        Args:
            amount: Value to add (must be >= 0).

        Raises:
            ValueError: If amount is negative.
        """
        if amount < 0:
            raise ValueError(f"Counter cannot be decremented (got {amount})")
        with self._lock:
            self._value += amount

    def reset(self) -> None:
        """Reset the counter to zero."""
        with self._lock:
            self._value = 0.0

    def snapshot(self) -> dict[str, Any]:
        """Return a point-in-time snapshot."""
        return {
            "name": self.name,
            "type": "counter",
            "value": self._value,
            "tags": dict(self.tags),
            "description": self.description,
        }

    def __repr__(self) -> str:
        return f"Counter({self.name!r}, value={self._value}, tags={self.tags})"
