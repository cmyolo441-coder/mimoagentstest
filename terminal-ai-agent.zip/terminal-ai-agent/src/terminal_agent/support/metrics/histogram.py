"""Histogram metric: distribution of observed values.

Used for latency distributions, token count distributions, etc.
Tracks count, sum, and configurable buckets.
"""

from __future__ import annotations

import math
import threading
from typing import Any


class Histogram:
    """Thread-safe histogram metric.

    Usage::

        h = Histogram("llm_latency_ms", buckets=[100, 500, 1000, 5000, 10000])
        h.observe(234)
        h.observe(1500)
        print(h.stats())
    """

    def __init__(
        self,
        name: str,
        *,
        buckets: list[float] | None = None,
        description: str = "",
        tags: dict[str, str] | None = None,
    ) -> None:
        self.name = name
        self.description = description
        self.tags = tags or {}
        self._buckets = sorted(buckets or [10, 50, 100, 500, 1000, 5000, 10000, 60000])
        self._counts: dict[float, int] = {b: 0 for b in self._buckets}
        self._counts[math.inf] = 0  # +Inf bucket
        self._count = 0
        self._sum = 0.0
        self._min = float("inf")
        self._max = float("-inf")
        self._values: list[float] = []  # For percentile calculation
        self._lock = threading.Lock()

    def observe(self, value: float) -> None:
        """Record an observation."""
        with self._lock:
            self._count += 1
            self._sum += value
            self._min = min(self._min, value)
            self._max = max(self._max, value)
            self._values.append(value)
            # Update buckets
            for bucket in self._buckets:
                if value <= bucket:
                    self._counts[bucket] += 1
            self._counts[math.inf] += 1

    @property
    def count(self) -> int:
        return self._count

    @property
    def sum(self) -> float:
        return self._sum

    def mean(self) -> float:
        """Average of all observed values."""
        return self._sum / self._count if self._count else 0.0

    def percentile(self, p: float) -> float:
        """Return the p-th percentile (0-100)."""
        with self._lock:
            if not self._values:
                return 0.0
            sorted_vals = sorted(self._values)
            idx = int(len(sorted_vals) * p / 100)
            idx = min(idx, len(sorted_vals) - 1)
            return sorted_vals[idx]

    def stats(self) -> dict[str, Any]:
        """Return histogram statistics."""
        with self._lock:
            return {
                "name": self.name,
                "type": "histogram",
                "count": self._count,
                "sum": self._sum,
                "min": self._min if self._min != float("inf") else 0.0,
                "max": self._max if self._max != float("-inf") else 0.0,
                "mean": self.mean(),
                "p50": self.percentile(50),
                "p90": self.percentile(90),
                "p95": self.percentile(95),
                "p99": self.percentile(99),
                "buckets": {str(k): v for k, v in self._counts.items()},
                "tags": dict(self.tags),
                "description": self.description,
            }

    def snapshot(self) -> dict[str, Any]:
        """Alias for stats()."""
        return self.stats()

    def reset(self) -> None:
        """Reset all values."""
        with self._lock:
            self._counts = {b: 0 for b in self._buckets}
            self._counts[math.inf] = 0
            self._count = 0
            self._sum = 0.0
            self._min = float("inf")
            self._max = float("-inf")
            self._values.clear()

    def __repr__(self) -> str:
        return f"Histogram({self.name!r}, count={self._count}, mean={self.mean():.1f})"
