"""Gauge metric: a value that can go up and down.

Used for point-in-time measurements: memory usage, active sessions, etc.
"""

from __future__ import annotations

import threading
from typing import Any


class Gauge:
    """Thread-safe gauge metric.

    Usage::

        g = Gauge("active_sessions")
        g.set(3)
        g.inc()
        g.dec()
        print(g.value)  # 3
    """

    def __init__(
        self,
        name: str,
        *,
        description: str = "",
        tags: dict[str, str] | None = None,
    ) -> None:
        self.name = name
        self.description = description
        self.tags = tags or {}
        self._value: float = 0.0
        self._lock = threading.Lock()

    @property
    def value(self) -> float:
        """Current gauge value."""
        return self._value

    def set(self, value: float) -> None:
        """Set the gauge to an absolute value."""
        with self._lock:
            self._value = value

    def inc(self, amount: float = 1.0) -> None:
        """Increment the gauge."""
        with self._lock:
            self._value += amount

    def dec(self, amount: float = 1.0) -> None:
        """Decrement the gauge."""
        with self._lock:
            self._value -= amount

    def snapshot(self) -> dict[str, Any]:
        """Return a point-in-time snapshot."""
        return {
            "name": self.name,
            "type": "gauge",
            "value": self._value,
            "tags": dict(self.tags),
            "description": self.description,
        }

    def __repr__(self) -> str:
        return f"Gauge({self.name!r}, value={self._value}, tags={self.tags})"
