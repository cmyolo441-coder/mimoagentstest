"""Metrics collector: central registry for all metric types.

Provides a unified API for creating, registering, and querying
counters, gauges, histograms, and timers.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any

from terminal_agent.support.metrics.counter import Counter
from terminal_agent.support.metrics.gauge import Gauge
from terminal_agent.support.metrics.histogram import Histogram
from terminal_agent.support.metrics.timer import Timer
from terminal_agent.support.metrics.aggregation import MetricAggregator
from terminal_agent.support.metrics.alerting import AlertManager, Alert, AlertRule, AlertSeverity

logger = logging.getLogger("terminal_agent.support.metrics.collector")


class MetricsCollector:
    """Central metrics registry.

    Usage::

        collector = MetricsCollector()
        c = collector.counter("llm_calls", tags={"provider": "openai"})
        c.inc()
        g = collector.gauge("active_sessions")
        g.set(5)
        h = collector.histogram("latency_ms", buckets=[100, 500, 1000])
        h.observe(234)
        t = collector.timer("tool_time")
        with t:
            run_tool()
        print(collector.snapshot())
    """

    def __init__(self, *, enable_aggregation: bool = True) -> None:
        self._metrics: dict[str, Any] = {}
        self._lock = threading.Lock()
        self._aggregator = MetricAggregator() if enable_aggregation else None
        self._alert_manager = AlertManager()

    # ── Properties ─────────────────────────────────────────────────────

    @property
    def aggregator(self) -> MetricAggregator | None:
        """Access the metric aggregator."""
        return self._aggregator

    @property
    def alert_manager(self) -> AlertManager:
        """Access the alert manager."""
        return self._alert_manager

    # ── Metric creation ────────────────────────────────────────────────

    def counter(
        self,
        name: str,
        *,
        description: str = "",
        tags: dict[str, str] | None = None,
    ) -> Counter:
        """Get or create a counter metric."""
        key = self._make_key(name, tags)
        with self._lock:
            if key not in self._metrics:
                self._metrics[key] = Counter(name, description=description, tags=tags)
            return self._metrics[key]

    def gauge(
        self,
        name: str,
        *,
        description: str = "",
        tags: dict[str, str] | None = None,
    ) -> Gauge:
        """Get or create a gauge metric."""
        key = self._make_key(name, tags)
        with self._lock:
            if key not in self._metrics:
                self._metrics[key] = Gauge(name, description=description, tags=tags)
            return self._metrics[key]

    def histogram(
        self,
        name: str,
        *,
        buckets: list[float] | None = None,
        description: str = "",
        tags: dict[str, str] | None = None,
    ) -> Histogram:
        """Get or create a histogram metric."""
        key = self._make_key(name, tags)
        with self._lock:
            if key not in self._metrics:
                self._metrics[key] = Histogram(
                    name, buckets=buckets, description=description, tags=tags
                )
            return self._metrics[key]

    def timer(
        self,
        name: str,
        *,
        description: str = "",
        tags: dict[str, str] | None = None,
        buckets: list[float] | None = None,
    ) -> Timer:
        """Get or create a timer metric."""
        key = self._make_key(name, tags)
        with self._lock:
            if key not in self._metrics:
                self._metrics[key] = Timer(
                    name, description=description, tags=tags, buckets=buckets
                )
            return self._metrics[key]

    # ── Convenience recording ──────────────────────────────────────────

    def record_value(
        self,
        name: str,
        value: float,
        *,
        tags: dict[str, str] | None = None,
    ) -> None:
        """Record a value into the aggregator and check alerts."""
        if self._aggregator:
            self._aggregator.record(name, value, tags=tags)
        self._alert_manager.evaluate(name, value)

    # ── Queries ────────────────────────────────────────────────────────

    def get(self, name: str, tags: dict[str, str] | None = None) -> Any | None:
        """Retrieve a metric by name and optional tags."""
        key = self._make_key(name, tags)
        return self._metrics.get(key)

    def list_metrics(self) -> list[str]:
        """List all registered metric names (deduplicated)."""
        names: set[str] = set()
        for m in self._metrics.values():
            names.add(m.name)
        return sorted(names)

    def snapshot(self) -> dict[str, Any]:
        """Return a snapshot of all metrics."""
        result: dict[str, Any] = {}
        with self._lock:
            for key, metric in self._metrics.items():
                result[key] = metric.snapshot()
        if self._aggregator:
            result["_aggregation_points"] = self._aggregator.point_count()
        return result

    def reset(self) -> None:
        """Reset all metrics."""
        with self._lock:
            for metric in self._metrics.values():
                metric.reset()
        if self._aggregator:
            self._aggregator.clear()

    # ── Internals ──────────────────────────────────────────────────────

    @staticmethod
    def _make_key(name: str, tags: dict[str, str] | None) -> str:
        """Create a unique key from name + tags."""
        if not tags:
            return name
        tag_str = ",".join(f"{k}={v}" for k, v in sorted(tags.items()))
        return f"{name}{{{tag_str}}}"

    def __repr__(self) -> str:
        return f"MetricsCollector(metrics={len(self._metrics)})"
