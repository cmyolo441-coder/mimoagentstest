"""Metric aggregation: compute sums, averages, percentiles,
and time-windowed aggregates from raw metric data.
"""

from __future__ import annotations

import statistics
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any


@dataclass
class AggregateResult:
    """Result of an aggregation operation."""
    name: str
    count: int = 0
    sum: float = 0.0
    min: float = 0.0
    max: float = 0.0
    mean: float = 0.0
    median: float = 0.0
    p90: float = 0.0
    p95: float = 0.0
    p99: float = 0.0
    stddev: float = 0.0
    tags: dict[str, str] = field(default_factory=dict)


class MetricAggregator:
    """Aggregate metric values over time windows.

    Usage::

        agg = MetricAggregator()
        agg.record("llm_latency_ms", 234.5, tags={"provider": "openai"})
        agg.record("llm_latency_ms", 890.1, tags={"provider": "openai"})
        result = agg.aggregate("llm_latency_ms")
        print(result.mean, result.p95)
    """

    def __init__(self, max_points_per_metric: int = 10000) -> None:
        self._max_points = max_points_per_metric
        # metric_name → [(timestamp, value, tags)]
        self._data: dict[str, list[tuple[float, float, dict[str, str]]]] = defaultdict(list)

    def record(
        self,
        name: str,
        value: float,
        *,
        tags: dict[str, str] | None = None,
        timestamp: float | None = None,
    ) -> None:
        """Record a metric data point."""
        ts = timestamp or time.time()
        self._data[name].append((ts, value, tags or {}))
        # Trim if over limit
        if len(self._data[name]) > self._max_points:
            self._data[name] = self._data[name][-self._max_points:]

    def aggregate(
        self,
        name: str,
        *,
        since: float | None = None,
        tags: dict[str, str] | None = None,
    ) -> AggregateResult:
        """Aggregate all recorded values for *name*.

        Args:
            name: Metric name.
            since: Only include data points after this timestamp.
            tags: Filter by tag values (partial match).
        """
        points = self._data.get(name, [])
        if since is not None:
            points = [(ts, v, t) for ts, v, t in points if ts >= since]
        if tags:
            points = [
                (ts, v, t) for ts, v, t in points
                if all(t.get(k) == v for k, v in tags.items())
            ]
        if not points:
            return AggregateResult(name=name)

        values = [v for _, v, _ in points]
        sorted_vals = sorted(values)
        n = len(sorted_vals)

        return AggregateResult(
            name=name,
            count=n,
            sum=sum(values),
            min=sorted_vals[0],
            max=sorted_vals[-1],
            mean=statistics.mean(values),
            median=statistics.median(values),
            p90=sorted_vals[int(n * 0.9)] if n > 1 else sorted_vals[0],
            p95=sorted_vals[int(n * 0.95)] if n > 1 else sorted_vals[0],
            p99=sorted_vals[int(n * 0.99)] if n > 1 else sorted_vals[0],
            stddev=statistics.stdev(values) if n > 1 else 0.0,
        )

    def aggregate_windowed(
        self,
        name: str,
        window_seconds: float = 60.0,
    ) -> list[AggregateResult]:
        """Aggregate metric over sliding time windows.

        Returns one AggregateResult per window, most recent first.
        """
        points = self._data.get(name, [])
        if not points:
            return []
        now = time.time()
        windows: list[AggregateResult] = []
        window_start = now - window_seconds
        while window_start >= points[0][0]:
            window_end = window_start + window_seconds
            window_points = [
                v for ts, v, _ in points
                if window_start <= ts < window_end
            ]
            if window_points:
                sorted_vals = sorted(window_points)
                n = len(sorted_vals)
                windows.append(AggregateResult(
                    name=name,
                    count=n,
                    sum=sum(window_points),
                    min=sorted_vals[0],
                    max=sorted_vals[-1],
                    mean=statistics.mean(window_points),
                    median=statistics.median(window_points),
                    p90=sorted_vals[int(n * 0.9)] if n > 1 else sorted_vals[0],
                    p95=sorted_vals[int(n * 0.95)] if n > 1 else sorted_vals[0],
                    p99=sorted_vals[int(n * 0.99)] if n > 1 else sorted_vals[0],
                    stddev=statistics.stdev(window_points) if n > 1 else 0.0,
                ))
            window_start -= window_seconds
        return windows

    def list_metrics(self) -> list[str]:
        """List all recorded metric names."""
        return list(self._data.keys())

    def clear(self, name: str | None = None) -> None:
        """Clear data for a specific metric or all metrics."""
        if name:
            self._data.pop(name, None)
        else:
            self._data.clear()

    def point_count(self, name: str | None = None) -> int:
        """Count recorded data points."""
        if name:
            return len(self._data.get(name, []))
        return sum(len(v) for v in self._data.values())
