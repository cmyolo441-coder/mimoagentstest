"""Metric export: format metrics for Prometheus, StatsD, and JSON.

Provides exporters that convert internal metric snapshots into
the wire format expected by external monitoring systems.
"""

from __future__ import annotations

import json
import time
from typing import Any, TextIO

from terminal_agent.support.metrics.counter import Counter
from terminal_agent.support.metrics.gauge import Gauge
from terminal_agent.support.metrics.histogram import Histogram
from terminal_agent.support.metrics.timer import Timer


class MetricsExporter:
    """Export metrics in various formats.

    Usage::

        exporter = MetricsExporter()
        prom = exporter.to_prometheus([counter, gauge, histogram])
        statsd = exporter.to_statsd([counter, gauge])
        json_str = exporter.to_json([counter, gauge, histogram, timer])
    """

    # ── Prometheus ─────────────────────────────────────────────────────

    def to_prometheus(self, metrics: list[Any]) -> str:
        """Format metrics as Prometheus exposition format."""
        lines: list[str] = []
        for m in metrics:
            if isinstance(m, Counter):
                lines.extend(self._prometheus_counter(m))
            elif isinstance(m, Gauge):
                lines.extend(self._prometheus_gauge(m))
            elif isinstance(m, (Histogram, Timer)):
                lines.extend(self._prometheus_histogram(m))
        return "\n".join(lines) + "\n"

    def _prometheus_counter(self, c: Counter) -> list[str]:
        name = self._sanitize(c.name)
        tags = self._prom_tags(c.tags)
        lines = []
        if c.description:
            lines.append(f"# HELP {name} {c.description}")
        lines.append(f"# TYPE {name} counter")
        lines.append(f"{name}{tags} {c.value}")
        return lines

    def _prometheus_gauge(self, g: Gauge) -> list[str]:
        name = self._sanitize(g.name)
        tags = self._prom_tags(g.tags)
        lines = []
        if g.description:
            lines.append(f"# HELP {name} {g.description}")
        lines.append(f"# TYPE {name} gauge")
        lines.append(f"{name}{tags} {g.value}")
        return lines

    def _prometheus_histogram(self, h: Any) -> list[str]:
        name = self._sanitize(h.name)
        tags = self._prom_tags(h.tags)
        stats = h.stats()
        lines = []
        if h.description:
            lines.append(f"# HELP {name} {h.description}")
        lines.append(f"# TYPE {name} histogram")
        for bucket, count in stats.get("buckets", {}).items():
            if bucket == "inf":
                bucket_tag = f'{tags.rstrip("}")},le="+Inf")' if tags else '{le="+Inf"}'
            else:
                bucket_tag = f'{tags.rstrip("}")},le={bucket})' if tags else f'{{le={bucket}}}'
            lines.append(f"{name}_bucket{bucket_tag} {count}")
        lines.append(f"{name}_sum{tags} {stats['sum']}")
        lines.append(f"{name}_count{tags} {stats['count']}")
        return lines

    @staticmethod
    def _sanitize(name: str) -> str:
        """Sanitize metric name for Prometheus."""
        return name.replace(".", "_").replace("-", "_").replace(" ", "_")

    @staticmethod
    def _prom_tags(tags: dict[str, str]) -> str:
        """Format tags as Prometheus label set."""
        if not tags:
            return ""
        pairs = ",".join(f'{k}="{v}"' for k, v in sorted(tags.items()))
        return "{" + pairs + "}"

    # ── StatsD ─────────────────────────────────────────────────────────

    def to_statsd(self, metrics: list[Any]) -> list[str]:
        """Format metrics as StatsD lines."""
        lines: list[str] = []
        for m in metrics:
            if isinstance(m, Counter):
                lines.append(f"{m.name}:{m.value}|c")
            elif isinstance(m, Gauge):
                lines.append(f"{m.name}:{m.value}|g")
            elif isinstance(m, Histogram):
                stats = m.stats()
                lines.append(f"{m.name}:{stats['mean']}|ms")
            elif isinstance(m, Timer):
                stats = m.stats()
                lines.append(f"{m.name}:{stats['mean']}|ms")
        return lines

    # ── JSON ───────────────────────────────────────────────────────────

    def to_json(self, metrics: list[Any], *, indent: int = 2) -> str:
        """Format metrics as JSON."""
        data = [m.snapshot() for m in metrics]
        return json.dumps(data, indent=indent, default=str)

    def to_jsonl(self, metrics: list[Any]) -> str:
        """Format metrics as JSON Lines."""
        lines = [json.dumps(m.snapshot(), default=str) for m in metrics]
        return "\n".join(lines) + "\n"

    # ── File export ────────────────────────────────────────────────────

    def write_prometheus(self, metrics: list[Any], path: str | TextIO) -> None:
        """Write Prometheus format to a file or stream."""
        content = self.to_prometheus(metrics)
        if isinstance(path, str):
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
        else:
            path.write(content)

    def write_json(self, metrics: list[Any], path: str) -> None:
        """Write JSON format to a file."""
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.to_json(metrics))
