"""Metric alerting: define thresholds and trigger alerts.

Monitors metrics against configurable conditions and fires
callbacks when thresholds are breached.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

logger = logging.getLogger("terminal_agent.support.metrics.alerting")


class AlertSeverity(str, Enum):
    """Alert severity levels."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class ComparisonOp(str, Enum):
    """Comparison operators for alert conditions."""
    GT = ">"
    GTE = ">="
    LT = "<"
    LTE = "<="
    EQ = "=="
    NEQ = "!="


@dataclass
class AlertRule:
    """A rule that triggers when a metric crosses a threshold."""
    name: str
    metric_name: str
    condition: ComparisonOp
    threshold: float
    severity: AlertSeverity = AlertSeverity.WARNING
    description: str = ""
    cooldown_seconds: float = 300.0
    tags: dict[str, str] = field(default_factory=dict)
    _last_fired: float = 0.0

    def evaluate(self, value: float) -> bool:
        """Check if the condition is met."""
        ops = {
            ComparisonOp.GT: value > self.threshold,
            ComparisonOp.GTE: value >= self.threshold,
            ComparisonOp.LT: value < self.threshold,
            ComparisonOp.LTE: value <= self.threshold,
            ComparisonOp.EQ: value == self.threshold,
            ComparisonOp.NEQ: value != self.threshold,
        }
        return ops[self.condition]

    def can_fire(self) -> bool:
        """Check if cooldown has elapsed since last firing."""
        return time.time() - self._last_fired >= self.cooldown_seconds

    def mark_fired(self) -> None:
        """Record that this rule just fired."""
        self._last_fired = time.time()


@dataclass
class Alert:
    """A triggered alert."""
    rule_name: str
    metric_name: str
    severity: AlertSeverity
    value: float
    threshold: float
    condition: ComparisonOp
    message: str
    timestamp: float = field(default_factory=time.time)
    resolved: bool = False


# Type alias for alert callbacks
AlertCallback = Callable[[Alert], None]


class AlertManager:
    """Manage alert rules and fire callbacks when thresholds are breached.

    Usage::

        mgr = AlertManager()
        mgr.add_rule(AlertRule(
            name="high-cost",
            metric_name="task_cost",
            condition=ComparisonOp.GT,
            threshold=2.0,
            severity=AlertSeverity.WARNING,
        ))
        mgr.on_alert(lambda alert: print(f"ALERT: {alert.message}"))
        mgr.evaluate("task_cost", 3.50)
    """

    def __init__(self) -> None:
        self._rules: dict[str, AlertRule] = {}
        self._callbacks: list[AlertCallback] = []
        self._history: list[Alert] = []

    # ── Rule management ────────────────────────────────────────────────

    def add_rule(self, rule: AlertRule) -> None:
        """Add an alert rule."""
        self._rules[rule.name] = rule
        logger.info("Added alert rule '%s' for metric '%s'", rule.name, rule.metric_name)

    def remove_rule(self, name: str) -> bool:
        """Remove a rule by name."""
        return self._rules.pop(name, None) is not None

    def list_rules(self) -> list[dict[str, Any]]:
        """List all rules."""
        return [
            {
                "name": r.name,
                "metric_name": r.metric_name,
                "condition": r.condition.value,
                "threshold": r.threshold,
                "severity": r.severity.value,
                "description": r.description,
                "cooldown_seconds": r.cooldown_seconds,
            }
            for r in self._rules.values()
        ]

    # ── Callbacks ──────────────────────────────────────────────────────

    def on_alert(self, callback: AlertCallback) -> None:
        """Register an alert callback."""
        self._callbacks.append(callback)

    # ── Evaluation ─────────────────────────────────────────────────────

    def evaluate(self, metric_name: str, value: float) -> list[Alert]:
        """Evaluate all rules for *metric_name* against *value*.

        Returns list of alerts that were triggered.
        """
        triggered: list[Alert] = []
        for rule in self._rules.values():
            if rule.metric_name != metric_name:
                continue
            if not rule.can_fire():
                continue
            if rule.evaluate(value):
                alert = Alert(
                    rule_name=rule.name,
                    metric_name=metric_name,
                    severity=rule.severity,
                    value=value,
                    threshold=rule.threshold,
                    condition=rule.condition,
                    message=(
                        f"[{rule.severity.value.upper()}] {rule.name}: "
                        f"{metric_name} = {value} {rule.condition.value} {rule.threshold}"
                    ),
                )
                rule.mark_fired()
                self._history.append(alert)
                triggered.append(alert)
                logger.warning("Alert triggered: %s", alert.message)
                for cb in self._callbacks:
                    try:
                        cb(alert)
                    except Exception as exc:
                        logger.error("Alert callback error: %s", exc)
        return triggered

    def evaluate_all(self, metrics: dict[str, float]) -> list[Alert]:
        """Evaluate all rules against a dict of metric values."""
        all_alerts: list[Alert] = []
        for name, value in metrics.items():
            all_alerts.extend(self.evaluate(name, value))
        return all_alerts

    # ── History ────────────────────────────────────────────────────────

    def get_history(
        self,
        *,
        severity: AlertSeverity | None = None,
        limit: int = 50,
    ) -> list[Alert]:
        """Return alert history, newest first."""
        alerts = self._history
        if severity:
            alerts = [a for a in alerts if a.severity == severity]
        return list(reversed(alerts[-limit:]))

    def clear_history(self) -> None:
        """Clear alert history."""
        self._history.clear()

    def __repr__(self) -> str:
        return f"AlertManager(rules={len(self._rules)}, history={len(self._history)})"
