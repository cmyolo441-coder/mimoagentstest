"""Timer metric: measure durations with start/stop semantics.

Wrages a Histogram for distribution tracking and provides
convenient context-manager and decorator interfaces.
"""

from __future__ import annotations

import time
from typing import Any, Callable

from terminal_agent.support.metrics.histogram import Histogram


class Timer:
    """Timer metric with context manager and decorator support.

    Usage::

        timer = Timer("tool_execution_ms")

        # Context manager
        with timer:
            do_work()

        # Decorator
        @timer.measure
        def slow_function():
            ...

        # Manual
        timer.start()
        do_work()
        elapsed = timer.stop()

        print(timer.stats())
    """

    def __init__(
        self,
        name: str,
        *,
        description: str = "",
        tags: dict[str, str] | None = None,
        buckets: list[float] | None = None,
    ) -> None:
        self.name = name
        self.description = description
        self.tags = tags or {}
        self._histogram = Histogram(name, buckets=buckets, description=description, tags=tags)
        self._start_time: float | None = None

    # ── Context manager ────────────────────────────────────────────────

    def __enter__(self) -> Timer:
        self.start()
        return self

    def __exit__(self, *args: Any) -> None:
        self.stop()

    # ── Manual start/stop ──────────────────────────────────────────────

    def start(self) -> None:
        """Start the timer."""
        self._start_time = time.monotonic()

    def stop(self) -> float:
        """Stop the timer and record the elapsed time.

        Returns:
            Elapsed time in milliseconds.
        """
        if self._start_time is None:
            raise RuntimeError("Timer was not started")
        elapsed_ms = (time.monotonic() - self._start_time) * 1000
        self._histogram.observe(elapsed_ms)
        self._start_time = None
        return elapsed_ms

    # ── Decorator ──────────────────────────────────────────────────────

    def measure(self, fn: Callable[..., Any]) -> Callable[..., Any]:
        """Decorator that measures function execution time."""
        import functools

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with self:
                return fn(*args, **kwargs)

        return wrapper

    # ── Direct observation ─────────────────────────────────────────────

    def observe_ms(self, duration_ms: float) -> None:
        """Record a pre-computed duration in milliseconds."""
        self._histogram.observe(duration_ms)

    def observe_seconds(self, duration_s: float) -> None:
        """Record a pre-computed duration in seconds (converted to ms)."""
        self._histogram.observe(duration_s * 1000)

    # ── Stats ──────────────────────────────────────────────────────────

    def stats(self) -> dict[str, Any]:
        """Return timer statistics."""
        return self._histogram.stats()

    def snapshot(self) -> dict[str, Any]:
        """Return a point-in-time snapshot."""
        return self._histogram.snapshot()

    def reset(self) -> None:
        """Reset all recorded data."""
        self._histogram.reset()

    @property
    def count(self) -> int:
        """Number of recorded timings."""
        return self._histogram.count

    def __repr__(self) -> str:
        return f"Timer({self.name!r}, count={self.count})"
