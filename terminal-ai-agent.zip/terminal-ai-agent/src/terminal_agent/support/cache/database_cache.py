"""Database-backed cache using SQLite.

Queryable, persistent cache that leverages the agent's existing
SQLite database.  Suitable for data that needs to survive restarts
and be queried by attributes (tags, prefixes, time ranges).
"""

from __future__ import annotations

import json
import logging
import threading
import time
from typing import Any

from terminal_agent.support.persistence.database import Database
from terminal_agent.exceptions import DatabaseError

logger = logging.getLogger("terminal_agent.support.cache.database_cache")

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS cache_entries (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    tags        TEXT,           -- JSON array
    size_bytes  INTEGER DEFAULT 0,
    created_at  REAL NOT NULL,
    last_access REAL NOT NULL,
    access_count INTEGER DEFAULT 0,
    expires_at  REAL
);
"""

_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_cache_expires ON cache_entries(expires_at);",
    "CREATE INDEX IF NOT EXISTS idx_cache_tags ON cache_entries(tags);",
]


class DatabaseCache:
    """SQLite-backed cache.

    Usage::

        db = Database()
        db.initialize()
        cache = DatabaseCache(db, default_ttl=3600)
        cache.set("key1", {"data": 42}, tags=["llm", "openai"])
        value = cache.get("key1")
    """

    def __init__(
        self,
        database: Database,
        default_ttl: float | None = None,
    ) -> None:
        self._db = database
        self._default_ttl = default_ttl
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0
        self._ensure_schema()

    # ── Schema ─────────────────────────────────────────────────────────

    def _ensure_schema(self) -> None:
        """Create the cache table if it doesn't exist."""
        try:
            self._db.execute(_CREATE_TABLE)
            for idx_sql in _INDEXES:
                self._db.execute(idx_sql)
        except DatabaseError as exc:
            logger.error("Failed to create cache schema: %s", exc)
            raise

    # ── Core ───────────────────────────────────────────────────────────

    def get(self, key: str) -> Any | None:
        """Retrieve a cached value."""
        with self._lock:
            row = self._db.fetchone(
                "SELECT value, expires_at FROM cache_entries WHERE key = ?",
                (key,),
            )
            if row is None:
                self._misses += 1
                return None
            if row["expires_at"] and time.time() >= row["expires_at"]:
                self.delete(key)
                self._misses += 1
                return None
            # Update access stats
            self._db.execute(
                "UPDATE cache_entries SET last_access = ?, access_count = access_count + 1 WHERE key = ?",
                (time.time(), key),
            )
            self._hits += 1
            try:
                return json.loads(row["value"])
            except json.JSONDecodeError:
                return row["value"]

    def set(
        self,
        key: str,
        value: Any,
        ttl: float | None = None,
        tags: list[str] | None = None,
    ) -> None:
        """Store *value* under *key* with optional TTL and tags."""
        effective_ttl = ttl if ttl is not None else self._default_ttl
        now = time.time()
        expires_at = (now + effective_ttl) if effective_ttl else None
        try:
            serialized = json.dumps(value, default=str, ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            raise DatabaseError(f"Cannot serialize value for key '{key}': {exc}") from exc
        tags_json = json.dumps(tags) if tags else None
        size_bytes = len(serialized.encode("utf-8"))
        with self._lock:
            self._db.execute(
                """INSERT INTO cache_entries (key, value, tags, size_bytes, created_at, last_access, access_count, expires_at)
                   VALUES (?, ?, ?, ?, ?, ?, 0, ?)
                   ON CONFLICT(key) DO UPDATE SET
                       value = excluded.value,
                       tags = excluded.tags,
                       size_bytes = excluded.size_bytes,
                       last_access = excluded.last_access,
                       expires_at = excluded.expires_at""",
                (key, serialized, tags_json, size_bytes, now, now, expires_at),
            )

    def delete(self, key: str) -> bool:
        """Remove a key.  Returns True if it existed."""
        with self._lock:
            cursor = self._db.execute(
                "DELETE FROM cache_entries WHERE key = ?", (key,)
            )
            return cursor.rowcount > 0

    def has(self, key: str) -> bool:
        """Check if key exists and is not expired."""
        with self._lock:
            row = self._db.fetchone(
                "SELECT expires_at FROM cache_entries WHERE key = ?", (key,)
            )
            if row is None:
                return False
            if row["expires_at"] and time.time() >= row["expires_at"]:
                self.delete(key)
                return False
            return True

    def clear(self) -> int:
        """Remove all cache entries."""
        with self._lock:
            cursor = self._db.execute("DELETE FROM cache_entries")
            return cursor.rowcount

    # ── Tag-based queries ──────────────────────────────────────────────

    def delete_by_tag(self, tag: str) -> int:
        """Delete all entries whose tags include *tag*."""
        with self._lock:
            # SQLite JSON: use LIKE for simplicity (tags stored as JSON array)
            cursor = self._db.execute(
                "DELETE FROM cache_entries WHERE tags LIKE ?",
                (f'%"{tag}"%',),
            )
            return cursor.rowcount

    def get_by_tag(self, tag: str) -> list[dict[str, Any]]:
        """Return all entries matching a tag."""
        with self._lock:
            rows = self._db.fetchall(
                "SELECT key, value, tags, created_at FROM cache_entries WHERE tags LIKE ?",
                (f'%"{tag}"%',),
            )
            result = []
            for row in rows:
                try:
                    value = json.loads(row["value"])
                except json.JSONDecodeError:
                    value = row["value"]
                result.append({"key": row["key"], "value": value, "tags": row["tags"]})
            return result

    # ── Maintenance ────────────────────────────────────────────────────

    def cleanup_expired(self) -> int:
        """Remove all expired entries.  Returns count removed."""
        with self._lock:
            cursor = self._db.execute(
                "DELETE FROM cache_entries WHERE expires_at IS NOT NULL AND expires_at < ?",
                (time.time(),),
            )
            return cursor.rowcount

    def evict_lru(self, max_entries: int) -> int:
        """Evict least-recently-used entries beyond *max_entries*."""
        with self._lock:
            count_row = self._db.fetchone("SELECT COUNT(*) as cnt FROM cache_entries")
            current = count_row["cnt"] if count_row else 0
            if current <= max_entries:
                return 0
            to_remove = current - max_entries
            cursor = self._db.execute(
                "DELETE FROM cache_entries WHERE key IN (SELECT key FROM cache_entries ORDER BY last_access ASC LIMIT ?)",
                (to_remove,),
            )
            return cursor.rowcount

    # ── Stats ──────────────────────────────────────────────────────────

    def stats(self) -> dict[str, Any]:
        """Return cache statistics."""
        with self._lock:
            row = self._db.fetchone(
                "SELECT COUNT(*) as entries, COALESCE(SUM(size_bytes), 0) as total_bytes FROM cache_entries"
            )
            total = self._hits + self._misses
            return {
                "entries": row["entries"] if row else 0,
                "size_bytes": row["total_bytes"] if row else 0,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self._hits / total if total else 0.0,
            }

    def __repr__(self) -> str:
        return f"DatabaseCache(db={self._db!r})"
