"""Caching subsystem: memory, disk, and database backends with
key generation, invalidation, warming, and eviction strategies.
"""

from terminal_agent.support.cache.manager import CacheManager
from terminal_agent.support.cache.memory_cache import MemoryCache
from terminal_agent.support.cache.disk_cache import DiskCache
from terminal_agent.support.cache.database_cache import DatabaseCache
from terminal_agent.support.cache.key_generator import KeyGenerator
from terminal_agent.support.cache.invalidation import InvalidationManager
from terminal_agent.support.cache.warming import CacheWarmer
from terminal_agent.support.cache.eviction import (
    LRUEviction,
    LFUEviction,
    FIFOEviction,
)

__all__ = [
    "CacheManager",
    "MemoryCache",
    "DiskCache",
    "DatabaseCache",
    "KeyGenerator",
    "InvalidationManager",
    "CacheWarmer",
    "LRUEviction",
    "LFUEviction",
    "FIFOEviction",
]
