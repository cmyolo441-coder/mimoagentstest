"""Cache invalidation strategies.

Provides event-based, TTL-based, and manual invalidation across
all cache tiers (memory, disk, database).
"""

from __future__ import annotations

import logging
import re
import threading
import time
from typing import Any, Callable

logger = logging.getLogger("terminal_agent.support.cache.invalidation")


class InvalidationRule:
    """A rule that invalidates cache entries matching a pattern.

    Attributes:
        pattern: Regex pattern matched against cache keys.
        reason: Human-readable reason for invalidation.
        created_at: When the rule was created.
    """

    __slots__ = ("pattern", "reason", "created_at", "_compiled")

    def __init__(self, pattern: str, reason: str = "") -> None:
        self.pattern = pattern
        self.reason = reason
        self.created_at = time.time()
        self._compiled = re.compile(pattern)

    def matches(self, key: str) -> bool:
        """Return True if *key* matches this rule's pattern."""
        return bool(self._compiled.search(key))


class InvalidationManager:
    """Coordinate invalidation across cache layers.

    Usage::

        mgr = InvalidationManager()
        mgr.register_cache(memory_cache)
        mgr.register_cache(disk_cache)
        # Invalidate all LLM-related entries
        mgr.invalidate_pattern(r"^ta:llm:.*")
        # Add a rule that auto-invalidates future matches
        mgr.add_rule(InvalidationRule(r":openai:", "Provider changed"))
    """

    def __init__(self) -> None:
        self._caches: list[Any] = []
        self._rules: list[InvalidationRule] = []
        self._subscribers: list[Callable[[str], None]] = []
        self._lock = threading.Lock()

    # ── Cache registration ─────────────────────────────────────────────

    def register_cache(self, cache: Any) -> None:
        """Register a cache instance (must support ``delete(key)``)."""
        with self._lock:
            if cache not in self._caches:
                self._caches.append(cache)

    def unregister_cache(self, cache: Any) -> None:
        """Unregister a cache instance."""
        with self._lock:
            try:
                self._caches.remove(cache)
            except ValueError:
                pass

    # ── Rules ──────────────────────────────────────────────────────────

    def add_rule(self, rule: InvalidationRule) -> None:
        """Add a persistent invalidation rule."""
        with self._lock:
            self._rules.append(rule)

    def remove_rule(self, pattern: str) -> bool:
        """Remove a rule by its pattern.  Returns True if found."""
        with self._lock:
            for i, rule in enumerate(self._rules):
                if rule.pattern == pattern:
                    self._rules.pop(i)
                    return True
            return False

    def list_rules(self) -> list[dict[str, Any]]:
        """Return all active rules."""
        with self._lock:
            return [
                {"pattern": r.pattern, "reason": r.reason, "created_at": r.created_at}
                for r in self._rules
            ]

    # ── Invalidation ───────────────────────────────────────────────────

    def invalidate_key(self, key: str) -> int:
        """Invalidate a specific key across all registered caches.

        Returns the number of caches where the key was found and deleted.
        """
        removed = 0
        with self._lock:
            caches = list(self._caches)
        for cache in caches:
            try:
                if cache.delete(key):
                    removed += 1
            except Exception as exc:
                logger.warning("Failed to invalidate key '%s' in %s: %s", key, cache, exc)
        if removed:
            self._notify(key)
        return removed

    def invalidate_pattern(self, pattern: str) -> int:
        """Invalidate all keys matching *pattern* across all caches.

        For caches that support ``keys()``, we iterate and match.
        For others, this is a no-op with a warning.

        Returns the total number of entries invalidated.
        """
        regex = re.compile(pattern)
        total = 0
        with self._lock:
            caches = list(self._caches)
        for cache in caches:
            try:
                keys_fn = getattr(cache, "keys", None)
                if keys_fn is None:
                    logger.debug("Cache %s does not support key listing, skipping pattern invalidation", cache)
                    continue
                keys = keys_fn()
                for key in keys:
                    if regex.search(key):
                        if cache.delete(key):
                            total += 1
                            self._notify(key)
            except Exception as exc:
                logger.warning("Pattern invalidation failed on %s: %s", cache, exc)
        if total:
            logger.info("Invalidated %d entries matching '%s'", total, pattern)
        return total

    def check_and_invalidate(self, key: str) -> bool:
        """Check *key* against all rules and invalidate if matched."""
        with self._lock:
            rules = list(self._rules)
        for rule in rules:
            if rule.matches(key):
                logger.debug("Rule triggered for key '%s': %s", key, rule.reason)
                self.invalidate_key(key)
                return True
        return False

    def invalidate_all(self) -> int:
        """Clear all registered caches.  Returns total entries removed."""
        total = 0
        with self._lock:
            caches = list(self._caches)
        for cache in caches:
            try:
                result = cache.clear()
                if isinstance(result, int):
                    total += result
                else:
                    total += 1
            except Exception as exc:
                logger.warning("Failed to clear cache %s: %s", cache, exc)
        return total

    # ── Subscribers ────────────────────────────────────────────────────

    def subscribe(self, callback: Callable[[str], None]) -> None:
        """Subscribe to invalidation events (called with the invalidated key)."""
        with self._lock:
            self._subscribers.append(callback)

    def _notify(self, key: str) -> None:
        """Notify all subscribers of an invalidation."""
        for cb in self._subscribers:
            try:
                cb(key)
            except Exception as exc:
                logger.warning("Invalidation subscriber error: %s", exc)

    def __repr__(self) -> str:
        return (
            f"InvalidationManager(caches={len(self._caches)}, "
            f"rules={len(self._rules)})"
        )
