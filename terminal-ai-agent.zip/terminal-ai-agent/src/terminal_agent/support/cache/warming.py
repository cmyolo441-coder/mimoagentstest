"""Cache warming: proactively populate caches with frequently accessed data.

Runs background tasks to preload project analysis, LLM responses
for common prompts, and tool results for idempotent operations.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any, Callable

logger = logging.getLogger("terminal_agent.support.cache.warming")

# Type alias for a warming function: takes no args, returns key-value pairs
WarmerFn = Callable[[], list[tuple[str, Any]]]


class CacheWarmer:
    """Manage and execute cache warming tasks.

    Usage::

        warmer = CacheWarmer(cache)
        warmer.register("project_analysis", warm_project_analysis, interval=300)
        warmer.start()   # runs in background thread
        warmer.stop()
    """

    def __init__(self, cache: Any | None = None) -> None:
        self._cache = cache
        self._tasks: dict[str, _WarmingTask] = {}
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()

    # ── Task management ────────────────────────────────────────────────

    def register(
        self,
        name: str,
        warmer_fn: WarmerFn,
        interval: float = 300.0,
        *,
        enabled: bool = True,
        tags: list[str] | None = None,
    ) -> None:
        """Register a warming task.

        Args:
            name: Unique task name.
            warmer_fn: Callable returning ``[(key, value), ...]``.
            interval: Seconds between warming runs.
            enabled: Whether the task is active.
            tags: Optional tags for grouping.
        """
        with self._lock:
            self._tasks[name] = _WarmingTask(
                name=name,
                fn=warmer_fn,
                interval=interval,
                enabled=enabled,
                tags=tags or [],
            )
        logger.info("Registered warming task '%s' (interval=%ds)", name, interval)

    def unregister(self, name: str) -> bool:
        """Remove a warming task."""
        with self._lock:
            return self._tasks.pop(name, None) is not None

    def enable(self, name: str) -> None:
        """Enable a warming task."""
        with self._lock:
            task = self._tasks.get(name)
            if task:
                task.enabled = True

    def disable(self, name: str) -> None:
        """Disable a warming task."""
        with self._lock:
            task = self._tasks.get(name)
            if task:
                task.enabled = False

    # ── Execution ──────────────────────────────────────────────────────

    def warm_now(self, name: str | None = None) -> dict[str, int]:
        """Run warming tasks immediately (synchronously).

        Args:
            name: Specific task name, or None to run all.

        Returns:
            Dict mapping task names to the number of entries warmed.
        """
        results: dict[str, int] = {}
        with self._lock:
            tasks = (
                {name: self._tasks[name]} if name and name in self._tasks
                else dict(self._tasks)
            )
        for task_name, task in tasks.items():
            if not task.enabled:
                continue
            count = self._run_task(task)
            results[task_name] = count
        return results

    def start(self) -> None:
        """Start background warming loop."""
        if self._thread and self._thread.is_alive():
            logger.warning("Warming loop already running")
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="cache-warmer")
        self._thread.start()
        logger.info("Cache warming loop started")

    def stop(self) -> None:
        """Stop the background warming loop."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=10)
            self._thread = None
        logger.info("Cache warming loop stopped")

    # ── Status ─────────────────────────────────────────────────────────

    def list_tasks(self) -> list[dict[str, Any]]:
        """List all registered warming tasks."""
        with self._lock:
            return [
                {
                    "name": t.name,
                    "interval": t.interval,
                    "enabled": t.enabled,
                    "tags": t.tags,
                    "last_run": t.last_run,
                    "last_count": t.last_count,
                    "last_error": t.last_error,
                }
                for t in self._tasks.values()
            ]

    # ── Internals ──────────────────────────────────────────────────────

    def _loop(self) -> None:
        """Background loop that runs tasks on schedule."""
        while not self._stop_event.is_set():
            now = time.monotonic()
            with self._lock:
                tasks = list(self._tasks.values())
            for task in tasks:
                if not task.enabled:
                    continue
                if now - task.last_run >= task.interval:
                    self._run_task(task)
            # Sleep in small increments so we can respond to stop
            self._stop_event.wait(timeout=5.0)

    def _run_task(self, task: _WarmingTask) -> int:
        """Execute a single warming task and store results."""
        count = 0
        try:
            pairs = task.fn()
            if self._cache and pairs:
                for key, value in pairs:
                    self._cache.set(key, value)
                    count += 1
            task.last_count = count
            task.last_error = None
            logger.debug("Warming task '%s' populated %d entries", task.name, count)
        except Exception as exc:
            task.last_error = str(exc)
            logger.warning("Warming task '%s' failed: %s", task.name, exc)
        finally:
            task.last_run = time.monotonic()
        return count


class _WarmingTask:
    """Internal representation of a warming task."""

    __slots__ = ("name", "fn", "interval", "enabled", "tags", "last_run", "last_count", "last_error")

    def __init__(
        self,
        name: str,
        fn: WarmerFn,
        interval: float,
        enabled: bool,
        tags: list[str],
    ) -> None:
        self.name = name
        self.fn = fn
        self.interval = interval
        self.enabled = enabled
        self.tags = tags
        self.last_run: float = 0.0
        self.last_count: int = 0
        self.last_error: str | None = None
