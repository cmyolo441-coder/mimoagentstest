"""Deterministic, collision-resistant cache key generation.

Provides multiple strategies for building cache keys from tool names,
parameters, file paths, and arbitrary data structures.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any


class KeyGenerator:
    """Generate deterministic cache keys.

    Usage::

        gen = KeyGenerator()
        key = gen.from_tool("shell_exec", {"command": "ls -la"})
        key = gen.from_file("/path/to/file", offset=100)
        key = gen.from_parts("llm", "openai", "gpt-4o", prompt_hash)
    """

    def __init__(self, prefix: str = "ta", hash_algo: str = "sha256") -> None:
        self._prefix = prefix
        self._hash_algo = hash_algo

    # ── High-level builders ────────────────────────────────────────────

    def from_tool(self, tool_name: str, parameters: dict[str, Any]) -> str:
        """Generate a key for a tool call with its parameters.

        Parameters are serialized deterministically (sorted keys) so
        identical calls always produce the same key.
        """
        param_hash = self._hash_dict(parameters)
        return f"{self._prefix}:tool:{tool_name}:{param_hash}"

    def from_file(self, path: str, *, offset: int = 0, limit: int | None = None) -> str:
        """Generate a key for a file read with optional range."""
        parts = [f"file:{path}"]
        if offset:
            parts.append(f"off:{offset}")
        if limit is not None:
            parts.append(f"lim:{limit}")
        return self._make_key(":".join(parts))

    def from_llm(
        self,
        provider: str,
        model: str,
        prompt: str,
        *,
        temperature: float = 0.0,
        max_tokens: int = 4096,
    ) -> str:
        """Generate a key for an LLM call."""
        prompt_hash = self._hash_string(prompt)
        return self._make_key(
            f"llm:{provider}:{model}:t{temperature}:m{max_tokens}:{prompt_hash}"
        )

    def from_parts(self, *parts: str) -> str:
        """Generate a key from arbitrary string parts."""
        return self._make_key(":".join(parts))

    def from_dict(self, namespace: str, data: dict[str, Any]) -> str:
        """Generate a key from a namespace and a dictionary."""
        data_hash = self._hash_dict(data)
        return self._make_key(f"{namespace}:{data_hash}")

    # ── Hashing helpers ────────────────────────────────────────────────

    def _hash_dict(self, data: dict[str, Any]) -> str:
        """Deterministically hash a dictionary (sorted keys, compact JSON)."""
        serialized = json.dumps(data, sort_keys=True, separators=(",", ":"), default=str)
        return self._hash_string(serialized)

    def _hash_string(self, value: str) -> str:
        """Hash a string and return a hex digest (truncated to 16 chars)."""
        return hashlib.new(self._hash_algo, value.encode("utf-8")).hexdigest()[:16]

    def _make_key(self, body: str) -> str:
        """Compose the final key with prefix."""
        return f"{self._prefix}:{body}"
