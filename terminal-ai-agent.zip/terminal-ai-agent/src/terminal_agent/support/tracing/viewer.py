"""Trace viewer: render traces in human-readable format.

Provides text-based rendering for terminal display, with support
for filtering, pagination, and summary views.
"""

from __future__ import annotations

from typing import Any

from terminal_agent.support.tracing.format import EntryType, Trace, TraceEntry, TraceStatus


# ANSI colors
_COLORS = {
    EntryType.THOUGHT: "\033[36m",      # Cyan
    EntryType.ACTION: "\033[32m",       # Green
    EntryType.OBSERVATION: "\033[33m",  # Yellow
    EntryType.VERIFICATION: "\033[35m", # Magenta
    EntryType.ERROR: "\033[31m",        # Red
    EntryType.PLAN: "\033[34m",         # Blue
    EntryType.MEMORY: "\033[90m",       # Gray
    EntryType.SAFETY: "\033[1;31m",     # Bold Red
    EntryType.SYSTEM: "\033[90m",       # Gray
}
_STATUS_COLORS = {
    TraceStatus.RUNNING: "\033[33m",
    TraceStatus.COMPLETED: "\033[32m",
    TraceStatus.FAILED: "\033[31m",
    TraceStatus.CANCELLED: "\033[90m",
}
_RESET = "\033[0m"
_BOLD = "\033[1m"


class TraceViewer:
    """Render traces for terminal display.

    Usage::

        viewer = TraceViewer(colorize=True)
        print(viewer.summary(trace))
        print(viewer.render(trace))
        print(viewer.render_entry(trace.entries[0]))
    """

    def __init__(self, colorize: bool = True, max_content_length: int = 500) -> None:
        self._colorize = colorize
        self._max_content = max_content_length

    def summary(self, trace: Trace) -> str:
        """Render a one-line summary of a trace."""
        status = trace.status.value
        duration = trace.duration_seconds
        duration_str = f"{duration:.1f}s" if duration is not None else "running"
        if self._colorize:
            color = _STATUS_COLORS.get(trace.status, "")
            status = f"{color}{status}{_RESET}"
        return (
            f"Trace {trace.id} | {status} | "
            f"{trace.step_count} steps | {duration_str} | "
            f"tokens={trace.total_tokens} | cost=${trace.total_cost:.4f}"
        )

    def header(self, trace: Trace) -> str:
        """Render the trace header."""
        lines = [
            "=" * 72,
            f"{_BOLD if self._colorize else ''}Trace: {trace.id}{_RESET if self._colorize else ''}",
            f"Session: {trace.session_id}",
            f"Goal: {trace.goal}",
            f"Status: {trace.status.value}",
            f"Steps: {trace.step_count} | Entries: {len(trace.entries)}",
        ]
        if trace.total_tokens:
            lines.append(f"Tokens: {trace.total_tokens} | Cost: ${trace.total_cost:.4f}")
        if trace.duration_seconds is not None:
            lines.append(f"Duration: {trace.duration_seconds:.2f}s")
        lines.append("=" * 72)
        return "\n".join(lines)

    def render(
        self,
        trace: Trace,
        *,
        entry_types: set[EntryType] | None = None,
        start: int = 0,
        limit: int | None = None,
    ) -> str:
        """Render a full trace with all (or filtered) entries.

        Args:
            trace: The trace to render.
            entry_types: If set, only show these entry types.
            start: Index of the first entry to show.
            limit: Maximum number of entries to show.
        """
        parts = [self.header(trace), ""]
        entries = trace.entries
        if entry_types:
            entries = [e for e in entries if e.entry_type in entry_types]
        if limit is not None:
            entries = entries[start:start + limit]
        elif start:
            entries = entries[start:]
        for entry in entries:
            parts.append(self.render_entry(entry))
        parts.append("")
        parts.append(self.summary(trace))
        return "\n".join(parts)

    def render_entry(self, entry: TraceEntry) -> str:
        """Render a single trace entry."""
        icon = self._icon(entry.entry_type)
        color = _COLORS.get(entry.entry_type, "") if self._colorize else ""
        reset = _RESET if self._colorize else ""

        # Truncate long content
        content = entry.content
        if len(content) > self._max_content:
            content = content[:self._max_content] + "…"

        parts = [f"{color}{icon} {content}{reset}"]
        if entry.duration_ms is not None:
            parts.append(f"  ⏱ {entry.duration_ms:.1f}ms")
        if entry.metadata:
            tool = entry.metadata.get("tool")
            if tool:
                parts.append(f"  🔧 {tool}")
            exit_code = entry.metadata.get("exit_code")
            if exit_code is not None and exit_code != 0:
                parts.append(f"  ❌ exit={exit_code}")
        return "\n".join(parts)

    def render_entries(self, entries: list[TraceEntry]) -> str:
        """Render a list of entries."""
        return "\n".join(self.render_entry(e) for e in entries)

    def table(self, traces: list[dict[str, Any]]) -> str:
        """Render a table of trace summaries (from list_traces output)."""
        if not traces:
            return "No traces found."
        header = f"{'ID':<18} {'Status':<12} {'Steps':>6} {'Tokens':>8} {'Cost':>10} {'Goal'}"
        lines = [header, "-" * 80]
        for t in traces:
            cost = f"${t.get('total_cost', 0):.4f}"
            goal = t.get("goal", "")[:40]
            lines.append(
                f"{t['id']:<18} {t['status']:<12} {t.get('total_steps', 0):>6} "
                f"{t.get('total_tokens', 0):>8} {cost:>10} {goal}"
            )
        return "\n".join(lines)

    @staticmethod
    def _icon(entry_type: EntryType) -> str:
        """Return an icon for each entry type."""
        icons = {
            EntryType.THOUGHT: "💭",
            EntryType.ACTION: "⚡",
            EntryType.OBSERVATION: "👁 ",
            EntryType.VERIFICATION: "✅",
            EntryType.ERROR: "❌",
            EntryType.PLAN: "📋",
            EntryType.MEMORY: "🧠",
            EntryType.SAFETY: "🛡 ",
            EntryType.SYSTEM: "⚙ ",
        }
        return icons.get(entry_type, "•")
