"""Tracing subsystem: record, store, view, compare, analyze, and export
execution traces for replay and self-improvement.
"""

from terminal_agent.support.tracing.recorder import TraceRecorder
from terminal_agent.support.tracing.format import Trace, TraceEntry, EntryType, TraceStatus
from terminal_agent.support.tracing.storage import TraceStorage
from terminal_agent.support.tracing.viewer import TraceViewer
from terminal_agent.support.tracing.comparator import TraceComparator
from terminal_agent.support.tracing.analyzer import TraceAnalyzer
from terminal_agent.support.tracing.exporter import TraceExporter

__all__ = [
    "Trace",
    "TraceEntry",
    "EntryType",
    "TraceStatus",
    "TraceRecorder",
    "TraceStorage",
    "TraceViewer",
    "TraceComparator",
    "TraceAnalyzer",
    "TraceExporter",
]
