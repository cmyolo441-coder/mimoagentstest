"""Trace storage: persist and retrieve traces in SQLite.

Provides CRUD operations for traces and their entries,
with support for querying by session, time range, and status.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from terminal_agent.support.persistence.database import Database
from terminal_agent.support.tracing.format import (
    EntryType,
    Trace,
    TraceEntry,
    TraceStatus,
)
from terminal_agent.exceptions import PersistenceError

logger = logging.getLogger("terminal_agent.support.tracing.storage")


class TraceStorage:
    """Store and retrieve traces in SQLite.

    Usage::

        storage = TraceStorage(database)
        storage.save(trace)
        traces = storage.list_traces(session_id="abc123")
        trace = storage.load(trace_id)
    """

    def __init__(self, database: Database) -> None:
        self._db = database

    def save(self, trace: Trace) -> str:
        """Save (or update) a trace and its entries.

        Returns the trace ID.
        """
        try:
            with self._db.transaction() as conn:
                conn.execute(
                    """INSERT OR REPLACE INTO traces
                       (id, session_id, goal, status, start_time, end_time,
                        total_steps, total_tokens, total_cost, outcome, metadata, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        trace.id,
                        trace.session_id,
                        trace.goal,
                        trace.status.value,
                        trace.start_time,
                        trace.end_time,
                        trace.step_count,
                        trace.total_tokens,
                        trace.total_cost,
                        trace.status.value,
                        _json_dumps(trace.metadata),
                        trace.start_time,
                    ),
                )
                # Delete old entries for this trace (replace semantics)
                conn.execute("DELETE FROM trace_entries WHERE trace_id = ?", (trace.id,))
                # Insert all entries
                for entry in trace.entries:
                    conn.execute(
                        """INSERT INTO trace_entries
                           (trace_id, entry_type, turn_number, content, metadata, timestamp)
                           VALUES (?, ?, ?, ?, ?, ?)""",
                        (
                            trace.id,
                            entry.entry_type.value,
                            entry.turn_number,
                            entry.content,
                            _json_dumps(entry.metadata),
                            entry.timestamp,
                        ),
                    )
            logger.debug("Saved trace %s with %d entries", trace.id, len(trace.entries))
            return trace.id
        except Exception as exc:
            raise PersistenceError(f"Failed to save trace: {exc}") from exc

    def load(self, trace_id: str) -> Trace | None:
        """Load a trace by ID (returns None if not found)."""
        row = self._db.fetchone("SELECT * FROM traces WHERE id = ?", (trace_id,))
        if row is None:
            return None
        return self._row_to_trace(row)

    def _row_to_trace(self, row: dict[str, Any]) -> Trace:
        """Convert a database row to a Trace object with entries."""
        trace = Trace(
            id=row["id"],
            session_id=row["session_id"],
            goal=row["goal"],
            status=TraceStatus(row["status"]),
            start_time=row["start_time"],
            end_time=row["end_time"],
            total_tokens=row.get("total_tokens", 0),
            total_cost=row.get("total_cost", 0.0),
            metadata=_json_loads(row.get("metadata", "{}")),
        )
        # Load entries
        entry_rows = self._db.fetchall(
            "SELECT * FROM trace_entries WHERE trace_id = ? ORDER BY id",
            (trace.id,),
        )
        for erow in entry_rows:
            entry = TraceEntry(
                entry_type=EntryType(erow["entry_type"]),
                content=erow["content"],
                timestamp=erow["timestamp"],
                turn_number=erow.get("turn_number"),
                metadata=_json_loads(erow.get("metadata", "{}")),
            )
            trace.entries.append(entry)
        return trace

    def list_traces(
        self,
        session_id: str | None = None,
        status: TraceStatus | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """List traces with optional filters.

        Returns lightweight dicts (without entries) for listing.
        """
        conditions: list[str] = []
        params: list[Any] = []
        if session_id:
            conditions.append("session_id = ?")
            params.append(session_id)
        if status:
            conditions.append("status = ?")
            params.append(status.value)
        where = " WHERE " + " AND ".join(conditions) if conditions else ""
        query = f"SELECT * FROM traces{where} ORDER BY start_time DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        rows = self._db.fetchall(query, tuple(params))
        return [
            {
                "id": r["id"],
                "session_id": r["session_id"],
                "goal": r["goal"],
                "status": r["status"],
                "start_time": r["start_time"],
                "end_time": r["end_time"],
                "total_steps": r.get("total_steps", 0),
                "total_tokens": r.get("total_tokens", 0),
                "total_cost": r.get("total_cost", 0.0),
            }
            for r in rows
        ]

    def delete(self, trace_id: str) -> bool:
        """Delete a trace and its entries."""
        with self._db.transaction() as conn:
            conn.execute("DELETE FROM trace_entries WHERE trace_id = ?", (trace_id,))
            cursor = conn.execute("DELETE FROM traces WHERE id = ?", (trace_id,))
            return cursor.rowcount > 0

    def count(self, session_id: str | None = None) -> int:
        """Count traces matching optional filter."""
        if session_id:
            row = self._db.fetchone(
                "SELECT COUNT(*) as cnt FROM traces WHERE session_id = ?",
                (session_id,),
            )
        else:
            row = self._db.fetchone("SELECT COUNT(*) as cnt FROM traces")
        return row["cnt"] if row else 0


def _json_dumps(data: Any) -> str:
    """Safe JSON serialization."""
    import json
    try:
        return json.dumps(data, default=str, ensure_ascii=False)
    except Exception:
        return "{}"


def _json_loads(text: str | None) -> dict[str, Any]:
    """Safe JSON deserialization."""
    import json
    if not text:
        return {}
    try:
        return json.loads(text)
    except Exception:
        return {}
