"""Trace recorder: capture execution traces in real-time.

Provides a high-level API for recording agent actions, thoughts,
observations, and errors into a structured trace.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable

from terminal_agent.support.tracing.format import (
    EntryType,
    Trace,
    TraceEntry,
    TraceStatus,
)

logger = logging.getLogger("terminal_agent.support.tracing.recorder")


class TraceRecorder:
    """Record execution traces.

    Usage::

        recorder = TraceRecorder(session_id="abc123", goal="Fix the bug")
        recorder.start()
        recorder.record_thought("I need to look at the error log")
        recorder.record_action("shell_exec", {"command": "cat error.log"}, output="...", duration_ms=50)
        recorder.record_observation("Found the error on line 42")
        recorder.record_verification("syntax_check", passed=True)
        trace = recorder.stop()
    """

    def __init__(
        self,
        session_id: str,
        goal: str,
        *,
        on_entry: Callable[[TraceEntry], None] | None = None,
    ) -> None:
        self._trace = Trace(session_id=session_id, goal=goal)
        self._on_entry = on_entry
        self._turn_counter = 0
        self._active = False

    # ── Lifecycle ──────────────────────────────────────────────────────

    def start(self) -> Trace:
        """Start recording."""
        self._active = True
        self._trace.start_time = time.time()
        self._trace.status = TraceStatus.RUNNING
        logger.info("Trace recording started for session %s", self._trace.session_id)
        return self._trace

    def stop(self, status: TraceStatus = TraceStatus.COMPLETED) -> Trace:
        """Stop recording and return the completed trace."""
        self._trace.complete(status)
        self._active = False
        logger.info(
            "Trace recording stopped: %d entries, %d steps",
            len(self._trace.entries),
            self._trace.step_count,
        )
        return self._trace

    @property
    def trace(self) -> Trace:
        """Access the current trace."""
        return self._trace

    @property
    def is_active(self) -> bool:
        """Whether recording is in progress."""
        return self._active

    # ── Recording methods ──────────────────────────────────────────────

    def record_thought(self, content: str, **metadata: Any) -> TraceEntry:
        """Record a reasoning/thinking step."""
        return self._add(EntryType.THOUGHT, content, metadata=metadata)

    def record_action(
        self,
        tool: str,
        parameters: dict[str, Any],
        *,
        output: str = "",
        exit_code: int = 0,
        duration_ms: float = 0.0,
        **metadata: Any,
    ) -> TraceEntry:
        """Record a tool action with its result."""
        meta = {
            "tool": tool,
            "parameters": parameters,
            "output_preview": output[:500] if output else "",
            "exit_code": exit_code,
            **metadata,
        }
        return self._add(EntryType.ACTION, f"{tool}({parameters})", metadata=meta, duration_ms=duration_ms)

    def record_observation(self, content: str, **metadata: Any) -> TraceEntry:
        """Record an observation (tool output, environment change)."""
        return self._add(EntryType.OBSERVATION, content, metadata=metadata)

    def record_verification(
        self,
        check_type: str,
        *,
        passed: bool,
        details: str = "",
        **metadata: Any,
    ) -> TraceEntry:
        """Record a verification check result."""
        meta = {"check_type": check_type, "passed": passed, **metadata}
        content = f"{check_type}: {'PASS' if passed else 'FAIL'}"
        if details:
            content += f" - {details}"
        return self._add(EntryType.VERIFICATION, content, metadata=meta)

    def record_error(
        self,
        error_type: str,
        message: str,
        *,
        recovery: str | None = None,
        **metadata: Any,
    ) -> TraceEntry:
        """Record an error and optional recovery action."""
        meta = {"error_type": error_type, "recovery": recovery, **metadata}
        return self._add(EntryType.ERROR, f"{error_type}: {message}", metadata=meta)

    def record_plan(self, plan_data: dict[str, Any]) -> TraceEntry:
        """Record a plan creation or update."""
        return self._add(EntryType.PLAN, f"Plan with {len(plan_data.get('steps', []))} steps", metadata=plan_data)

    def record_memory(self, operation: str, details: str, **metadata: Any) -> TraceEntry:
        """Record a memory operation (store, recall, consolidate)."""
        meta = {"operation": operation, **metadata}
        return self._add(EntryType.MEMORY, f"memory.{operation}: {details}", metadata=meta)

    def record_safety(self, decision: str, reason: str, **metadata: Any) -> TraceEntry:
        """Record a safety decision."""
        meta = {"decision": decision, "reason": reason, **metadata}
        return self._add(EntryType.SAFETY, f"Safety: {decision} - {reason}", metadata=meta)

    def record_system(self, event: str, **metadata: Any) -> TraceEntry:
        """Record a system event (startup, shutdown, config change)."""
        return self._add(EntryType.SYSTEM, event, metadata=metadata)

    # ── Metrics tracking ───────────────────────────────────────────────

    def add_tokens(self, count: int) -> None:
        """Add to the total token count."""
        self._trace.total_tokens += count

    def add_cost(self, amount: float) -> None:
        """Add to the total cost."""
        self._trace.total_cost += amount

    # ── Internals ──────────────────────────────────────────────────────

    def _add(
        self,
        entry_type: EntryType,
        content: str,
        metadata: dict[str, Any] | None = None,
        duration_ms: float | None = None,
    ) -> TraceEntry:
        """Internal helper to add an entry."""
        if not self._active:
            logger.warning("Attempted to record entry on inactive trace")
        entry = self._trace.add_entry(
            entry_type=entry_type,
            content=content,
            turn_number=self._turn_counter,
            metadata=metadata or {},
            duration_ms=duration_ms,
        )
        if entry_type == EntryType.ACTION:
            self._turn_counter += 1
        if self._on_entry:
            try:
                self._on_entry(entry)
            except Exception as exc:
                logger.warning("on_entry callback failed: %s", exc)
        return entry

    def __repr__(self) -> str:
        return (
            f"TraceRecorder(session={self._trace.session_id}, "
            f"entries={len(self._trace.entries)}, active={self._active})"
        )
