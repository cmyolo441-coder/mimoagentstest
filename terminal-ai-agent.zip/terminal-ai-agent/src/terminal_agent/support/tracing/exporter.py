"""Trace exporter: serialize traces for external analysis.

Supports exporting traces to JSON, CSV, and plain-text formats
for use with external tools, reports, or archival.
"""

from __future__ import annotations

import csv
import io
import json
from pathlib import Path
from typing import Any, TextIO

from terminal_agent.support.tracing.format import EntryType, Trace


class TraceExporter:
    """Export traces in various formats.

    Usage::

        exporter = TraceExporter()
        json_str = exporter.to_json(trace)
        exporter.to_file(trace, "trace.json", format="json")
        csv_str = exporter.to_csv([trace1, trace2])
    """

    # ── JSON ───────────────────────────────────────────────────────────

    def to_json(self, trace: Trace, *, indent: int = 2) -> str:
        """Export a single trace as JSON."""
        return trace.to_json(indent=indent)

    def to_jsonl(self, traces: list[Trace]) -> str:
        """Export multiple traces as JSON Lines (one per line)."""
        lines = [json.dumps(t.to_dict(), default=str, ensure_ascii=False) for t in traces]
        return "\n".join(lines) + "\n"

    # ── CSV ────────────────────────────────────────────────────────────

    def to_csv(self, traces: list[Trace]) -> str:
        """Export trace summaries as CSV."""
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            "id", "session_id", "goal", "status", "steps",
            "entries", "tokens", "cost", "duration_s",
            "start_time", "end_time",
        ])
        for t in traces:
            writer.writerow([
                t.id,
                t.session_id,
                t.goal,
                t.status.value,
                t.step_count,
                len(t.entries),
                t.total_tokens,
                f"{t.total_cost:.4f}",
                f"{t.duration_seconds:.2f}" if t.duration_seconds else "",
                t.start_time,
                t.end_time or "",
            ])
        return output.getvalue()

    def entries_to_csv(self, trace: Trace) -> str:
        """Export all entries of a trace as CSV."""
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["id", "type", "turn", "content", "duration_ms", "timestamp"])
        for entry in trace.entries:
            writer.writerow([
                entry.id,
                entry.entry_type.value,
                entry.turn_number or "",
                entry.content[:200],
                f"{entry.duration_ms:.1f}" if entry.duration_ms else "",
                entry.timestamp,
            ])
        return output.getvalue()

    # ── Plain text ─────────────────────────────────────────────────────

    def to_text(self, trace: Trace) -> str:
        """Export a trace as human-readable plain text."""
        from terminal_agent.support.tracing.viewer import TraceViewer
        viewer = TraceViewer(colorize=False)
        return viewer.render(trace)

    # ── File export ────────────────────────────────────────────────────

    def to_file(
        self,
        trace: Trace,
        path: str | Path,
        format: str = "json",
    ) -> Path:
        """Export a trace to a file.

        Args:
            trace: The trace to export.
            path: Output file path.
            format: One of 'json', 'csv', 'text'.

        Returns:
            Path to the written file.
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        if format == "json":
            content = self.to_json(trace)
        elif format == "csv":
            content = self.entries_to_csv(trace)
        elif format == "text":
            content = self.to_text(trace)
        else:
            raise ValueError(f"Unknown export format: '{format}'")
        path.write_text(content, encoding="utf-8")
        return path

    def to_directory(
        self,
        traces: list[Trace],
        directory: str | Path,
        format: str = "json",
    ) -> list[Path]:
        """Export each trace as a separate file in a directory."""
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        paths: list[Path] = []
        ext = {"json": ".json", "csv": ".csv", "text": ".txt"}.get(format, ".txt")
        for trace in traces:
            filename = f"trace_{trace.id}{ext}"
            path = self.to_file(trace, directory / filename, format=format)
            paths.append(path)
        return paths
