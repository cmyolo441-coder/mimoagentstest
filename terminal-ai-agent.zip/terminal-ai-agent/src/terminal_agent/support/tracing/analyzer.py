"""Trace analyzer: extract patterns, metrics, and insights from traces.

Supports self-improvement by identifying common patterns, frequent
errors, tool usage trends, and optimization opportunities.
"""

from __future__ import annotations

import statistics
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.support.tracing.format import EntryType, Trace, TraceStatus


@dataclass
class TraceAnalysis:
    """Result of analyzing one or more traces."""
    trace_count: int = 0
    success_rate: float = 0.0
    avg_steps: float = 0.0
    avg_duration: float = 0.0
    avg_tokens: float = 0.0
    avg_cost: float = 0.0
    tool_frequency: dict[str, int] = field(default_factory=dict)
    error_frequency: dict[str, int] = field(default_factory=dict)
    common_patterns: list[str] = field(default_factory=list)
    bottlenecks: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)


class TraceAnalyzer:
    """Analyze execution traces.

    Usage::

        analyzer = TraceAnalyzer()
        analysis = analyzer.analyze([trace1, trace2, trace3])
        print(analysis.recommendations)
    """

    def analyze(self, traces: list[Trace]) -> TraceAnalysis:
        """Analyze a collection of traces."""
        if not traces:
            return TraceAnalysis(trace_count=0)

        analysis = TraceAnalysis(trace_count=len(traces))
        analysis.success_rate = self._success_rate(traces)
        analysis.avg_steps = statistics.mean(t.step_count for t in traces)
        durations = [t.duration_seconds for t in traces if t.duration_seconds is not None]
        analysis.avg_duration = statistics.mean(durations) if durations else 0.0
        analysis.avg_tokens = statistics.mean(t.total_tokens for t in traces)
        analysis.avg_cost = statistics.mean(t.total_cost for t in traces)
        analysis.tool_frequency = self._tool_frequency(traces)
        analysis.error_frequency = self._error_frequency(traces)
        analysis.common_patterns = self._find_patterns(traces)
        analysis.bottlenecks = self._find_bottlenecks(traces)
        analysis.recommendations = self._generate_recommendations(analysis)

        return analysis

    def analyze_single(self, trace: Trace) -> dict[str, Any]:
        """Analyze a single trace in detail."""
        actions = [e for e in trace.entries if e.entry_type == EntryType.ACTION]
        errors = [e for e in trace.entries if e.entry_type == EntryType.ERROR]
        verifications = [e for e in trace.entries if e.entry_type == EntryType.VERIFICATION]

        # Timing breakdown
        action_durations = [e.duration_ms for e in actions if e.duration_ms is not None]
        total_action_time = sum(action_durations) if action_durations else 0

        # Verification pass rate
        verif_passed = sum(1 for v in verifications if v.metadata.get("passed", False))
        verif_total = len(verifications)

        return {
            "id": trace.id,
            "status": trace.status.value,
            "total_entries": len(trace.entries),
            "actions": len(actions),
            "errors": len(errors),
            "verifications": verif_total,
            "verification_pass_rate": verif_passed / verif_total if verif_total else 1.0,
            "total_action_time_ms": total_action_time,
            "avg_action_time_ms": total_action_time / len(actions) if actions else 0,
            "tool_sequence": [e.metadata.get("tool", "?") for e in actions],
            "error_types": [e.metadata.get("error_type", "?") for e in errors],
            "duration": trace.duration_seconds,
            "tokens": trace.total_tokens,
            "cost": trace.total_cost,
        }

    # ── Internal analysis methods ──────────────────────────────────────

    @staticmethod
    def _success_rate(traces: list[Trace]) -> float:
        if not traces:
            return 0.0
        successes = sum(1 for t in traces if t.status == TraceStatus.COMPLETED)
        return successes / len(traces)

    @staticmethod
    def _tool_frequency(traces: list[Trace]) -> dict[str, int]:
        counter: Counter[str] = Counter()
        for trace in traces:
            for entry in trace.entries:
                if entry.entry_type == EntryType.ACTION:
                    tool = entry.metadata.get("tool", "unknown")
                    counter[tool] += 1
        return dict(counter.most_common())

    @staticmethod
    def _error_frequency(traces: list[Trace]) -> dict[str, int]:
        counter: Counter[str] = Counter()
        for trace in traces:
            for entry in trace.entries:
                if entry.entry_type == EntryType.ERROR:
                    error_type = entry.metadata.get("error_type", "unknown")
                    counter[error_type] += 1
        return dict(counter.most_common())

    @staticmethod
    def _find_patterns(traces: list[Trace]) -> list[str]:
        """Identify common tool sequences across traces."""
        patterns: list[str] = []
        # Find common 2-step tool sequences
        sequences: Counter[tuple[str, str]] = Counter()
        for trace in traces:
            actions = [e for e in trace.entries if e.entry_type == EntryType.ACTION]
            tools = [e.metadata.get("tool", "?") for e in actions]
            for i in range(len(tools) - 1):
                sequences[(tools[i], tools[i + 1])] += 1
        for (t1, t2), count in sequences.most_common(5):
            if count >= 2:
                patterns.append(f"{t1} → {t2} (used {count} times)")
        return patterns

    @staticmethod
    def _find_bottlenecks(traces: list[Trace]) -> list[str]:
        """Identify slow tools or steps."""
        tool_times: dict[str, list[float]] = {}
        for trace in traces:
            for entry in trace.entries:
                if entry.entry_type == EntryType.ACTION and entry.duration_ms is not None:
                    tool = entry.metadata.get("tool", "unknown")
                    tool_times.setdefault(tool, []).append(entry.duration_ms)

        bottlenecks: list[str] = []
        for tool, times in sorted(tool_times.items(), key=lambda x: max(x[1]), reverse=True):
            avg_time = statistics.mean(times)
            max_time = max(times)
            if max_time > 10000:  # > 10s
                bottlenecks.append(
                    f"{tool}: avg={avg_time:.0f}ms, max={max_time:.0f}ms ({len(times)} calls)"
                )
        return bottlenecks[:5]

    @staticmethod
    def _generate_recommendations(analysis: TraceAnalysis) -> list[str]:
        """Generate actionable recommendations."""
        recs: list[str] = []
        if analysis.success_rate < 0.5:
            recs.append("Low success rate — consider reviewing error patterns and recovery strategies.")
        if analysis.avg_steps > 20:
            recs.append("High average step count — consider breaking goals into smaller tasks.")
        if analysis.avg_cost > 1.0:
            recs.append("High average cost — consider caching LLM responses and optimizing prompts.")
        # Most common error
        if analysis.error_frequency:
            top_error = next(iter(analysis.error_frequency))
            recs.append(f"Most frequent error: '{top_error}' — consider targeted error handling.")
        # Slow tools
        if analysis.bottlenecks:
            recs.append("Performance bottleneck detected — see bottlenecks for details.")
        return recs
