"""Trace format definitions and serialization.

Defines the canonical structure of a trace and its entries,
with support for serialization to/from JSON and dict.
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class EntryType(str, Enum):
    """Types of trace entries."""
    THOUGHT = "thought"
    ACTION = "action"
    OBSERVATION = "observation"
    VERIFICATION = "verification"
    ERROR = "error"
    PLAN = "plan"
    MEMORY = "memory"
    SAFETY = "safety"
    SYSTEM = "system"


class TraceStatus(str, Enum):
    """Trace execution status."""
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class TraceEntry:
    """A single entry in an execution trace."""
    entry_type: EntryType
    content: str
    timestamp: float = field(default_factory=time.time)
    turn_number: int | None = None
    duration_ms: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a dictionary."""
        d = asdict(self)
        d["entry_type"] = self.entry_type.value
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TraceEntry:
        """Deserialize from a dictionary."""
        data = dict(data)
        data["entry_type"] = EntryType(data["entry_type"])
        return cls(**data)


@dataclass
class Trace:
    """A complete execution trace."""
    session_id: str
    goal: str
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    status: TraceStatus = TraceStatus.RUNNING
    start_time: float = field(default_factory=time.time)
    end_time: float | None = None
    entries: list[TraceEntry] = field(default_factory=list)
    total_tokens: int = 0
    total_cost: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def duration_seconds(self) -> float | None:
        """Trace duration in seconds (None if still running)."""
        if self.end_time:
            return self.end_time - self.start_time
        return None

    @property
    def step_count(self) -> int:
        """Number of action entries."""
        return sum(1 for e in self.entries if e.entry_type == EntryType.ACTION)

    def add_entry(
        self,
        entry_type: EntryType,
        content: str,
        **kwargs: Any,
    ) -> TraceEntry:
        """Append a new entry to the trace."""
        entry = TraceEntry(entry_type=entry_type, content=content, **kwargs)
        self.entries.append(entry)
        return entry

    def complete(self, status: TraceStatus = TraceStatus.COMPLETED) -> None:
        """Mark the trace as complete."""
        self.status = status
        self.end_time = time.time()

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a dictionary."""
        return {
            "id": self.id,
            "session_id": self.session_id,
            "goal": self.goal,
            "status": self.status.value,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "total_tokens": self.total_tokens,
            "total_cost": self.total_cost,
            "metadata": self.metadata,
            "entries": [e.to_dict() for e in self.entries],
        }

    def to_json(self, indent: int | None = None) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=indent, default=str)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Trace:
        """Deserialize from a dictionary."""
        data = dict(data)
        data["status"] = TraceStatus(data["status"])
        entries_data = data.pop("entries", [])
        trace = cls(**data)
        trace.entries = [TraceEntry.from_dict(e) for e in entries_data]
        return trace

    @classmethod
    def from_json(cls, json_str: str) -> Trace:
        """Deserialize from a JSON string."""
        return cls.from_dict(json.loads(json_str))
