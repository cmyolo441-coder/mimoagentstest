"""Trace comparator: compare two execution traces.

Identifies differences in steps, timing, tool usage, and outcomes
to support debugging and self-improvement analysis.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from terminal_agent.support.tracing.format import EntryType, Trace, TraceEntry


@dataclass
class TraceDiff:
    """Difference between two traces."""
    only_in_first: list[TraceEntry] = field(default_factory=list)
    only_in_second: list[TraceEntry] = field(default_factory=list)
    common_entries: list[tuple[TraceEntry, TraceEntry]] = field(default_factory=list)
    timing_delta: float = 0.0
    token_delta: int = 0
    cost_delta: float = 0.0
    step_delta: int = 0
    summary: str = ""


@dataclass
class ComparisonResult:
    """Full comparison result between two traces."""
    trace1_summary: dict[str, Any]
    trace2_summary: dict[str, Any]
    diff: TraceDiff
    tool_usage_diff: dict[str, dict[str, int]]
    outcome_match: bool
    details: str


class TraceComparator:
    """Compare two execution traces.

    Usage::

        comparator = TraceComparator()
        result = comparator.compare(trace1, trace2)
        print(result.details)
    """

    def compare(self, trace1: Trace, trace2: Trace) -> ComparisonResult:
        """Compare two traces and return a detailed comparison."""
        diff = self._compute_diff(trace1, trace2)
        tool_diff = self._compare_tool_usage(trace1, trace2)
        outcome_match = trace1.status == trace2.status

        result = ComparisonResult(
            trace1_summary=self._trace_summary(trace1),
            trace2_summary=self._trace_summary(trace2),
            diff=diff,
            tool_usage_diff=tool_diff,
            outcome_match=outcome_match,
            details=self._format_details(trace1, trace2, diff, tool_diff, outcome_match),
        )
        return result

    def _compute_diff(self, trace1: Trace, trace2: Trace) -> TraceDiff:
        """Compute structural differences between traces."""
        # Align by action entries (compare tool calls)
        actions1 = [e for e in trace1.entries if e.entry_type == EntryType.ACTION]
        actions2 = [e for e in trace2.entries if e.entry_type == EntryType.ACTION]

        diff = TraceDiff()
        diff.step_delta = len(actions1) - len(actions2)

        # Compare action-by-action
        max_len = max(len(actions1), len(actions2))
        for i in range(max_len):
            if i < len(actions1) and i < len(actions2):
                diff.common_entries.append((actions1[i], actions2[i]))
            elif i < len(actions1):
                diff.only_in_first.append(actions1[i])
            else:
                diff.only_in_second.append(actions2[i])

        # Timing and cost deltas
        dur1 = trace1.duration_seconds or 0
        dur2 = trace2.duration_seconds or 0
        diff.timing_delta = dur1 - dur2
        diff.token_delta = trace1.total_tokens - trace2.total_tokens
        diff.cost_delta = trace1.total_cost - trace2.total_cost

        # Generate summary
        if diff.step_delta == 0 and diff.timing_delta == 0:
            diff.summary = "Traces are identical in structure and timing."
        else:
            parts = []
            if diff.step_delta:
                parts.append(f"Step count differs by {diff.step_delta}")
            if abs(diff.timing_delta) > 1:
                parts.append(f"Timing differs by {diff.timing_delta:.1f}s")
            if abs(diff.cost_delta) > 0.001:
                parts.append(f"Cost differs by ${diff.cost_delta:.4f}")
            diff.summary = "; ".join(parts) if parts else "Minor differences detected."

        return diff

    def _compare_tool_usage(
        self, trace1: Trace, trace2: Trace
    ) -> dict[str, dict[str, int]]:
        """Compare tool usage counts between traces."""
        usage1 = self._tool_counts(trace1)
        usage2 = self._tool_counts(trace2)
        all_tools = set(usage1) | set(usage2)
        result: dict[str, dict[str, int]] = {}
        for tool in sorted(all_tools):
            c1 = usage1.get(tool, 0)
            c2 = usage2.get(tool, 0)
            if c1 != c2:
                result[tool] = {"trace1": c1, "trace2": c2, "delta": c1 - c2}
        return result

    @staticmethod
    def _tool_counts(trace: Trace) -> dict[str, int]:
        """Count tool usage in a trace."""
        counts: dict[str, int] = {}
        for entry in trace.entries:
            if entry.entry_type == EntryType.ACTION:
                tool = entry.metadata.get("tool", "unknown")
                counts[tool] = counts.get(tool, 0) + 1
        return counts

    @staticmethod
    def _trace_summary(trace: Trace) -> dict[str, Any]:
        """Create a summary dict for a trace."""
        return {
            "id": trace.id,
            "status": trace.status.value,
            "steps": trace.step_count,
            "entries": len(trace.entries),
            "tokens": trace.total_tokens,
            "cost": trace.total_cost,
            "duration": trace.duration_seconds,
        }

    def _format_details(
        self,
        trace1: Trace,
        trace2: Trace,
        diff: TraceDiff,
        tool_diff: dict[str, dict[str, int]],
        outcome_match: bool,
    ) -> str:
        """Format a human-readable comparison report."""
        lines = [
            "=== Trace Comparison ===",
            "",
            f"Trace 1: {trace1.id} ({trace1.status.value})",
            f"Trace 2: {trace2.id} ({trace2.status.value})",
            f"Outcome match: {'✓' if outcome_match else '✗'}",
            "",
            f"Steps: {trace1.step_count} vs {trace2.step_count} (Δ={diff.step_delta})",
            f"Tokens: {trace1.total_tokens} vs {trace2.total_tokens} (Δ={diff.token_delta})",
            f"Cost: ${trace1.total_cost:.4f} vs ${trace2.total_cost:.4f} (Δ=${diff.cost_delta:.4f})",
            "",
        ]
        if tool_diff:
            lines.append("Tool usage differences:")
            for tool, counts in tool_diff.items():
                lines.append(f"  {tool}: {counts['trace1']} → {counts['trace2']} (Δ={counts['delta']})")
        else:
            lines.append("Tool usage: identical")
        lines.append("")
        lines.append(f"Summary: {diff.summary}")
        return "\n".join(lines)
