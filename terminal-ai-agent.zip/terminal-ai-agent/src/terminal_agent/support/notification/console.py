"""Console notifications: in-terminal alerts.

Displays notifications directly in the terminal with color coding
based on severity level.
"""

from __future__ import annotations

import logging
import sys
from typing import Any, TextIO

from terminal_agent.support.notification.levels import Notification, NotificationLevel

logger = logging.getLogger("terminal_agent.support.notification.console")

_COLORS = {
    NotificationLevel.DEBUG: "\033[90m",     # Gray
    NotificationLevel.INFO: "\033[36m",      # Cyan
    NotificationLevel.WARNING: "\033[33m",   # Yellow
    NotificationLevel.ERROR: "\033[31m",     # Red
    NotificationLevel.CRITICAL: "\033[1;31m",  # Bold Red
}
_RESET = "\033[0m"


class ConsoleNotifier:
    """Display notifications in the terminal.

    Usage::

        notifier = ConsoleNotifier(min_level=NotificationLevel.INFO)
        notifier.notify(Notification(title="Build complete", level=NotificationLevel.INFO))
    """

    def __init__(
        self,
        min_level: NotificationLevel = NotificationLevel.INFO,
        *,
        colorize: bool = True,
        stream: TextIO | None = None,
        show_source: bool = True,
        show_timestamp: bool = False,
    ) -> None:
        self._min_level = min_level
        self._colorize = colorize
        self._stream = stream or sys.stderr
        self._show_source = show_source
        self._show_timestamp = show_timestamp

    def notify(self, notification: Notification) -> bool:
        """Display a notification in the terminal.

        Returns True if the notification was displayed.
        """
        if notification.level < self._min_level:
            return False

        parts: list[str] = []

        if self._show_timestamp:
            import time
            ts = time.strftime("%H:%M:%S", time.localtime(notification.timestamp))
            parts.append(f"[{ts}]")

        level_name = notification.level.name
        if self._colorize:
            color = _COLORS.get(notification.level, "")
            parts.append(f"{color}[{level_name}]{_RESET}")
        else:
            parts.append(f"[{level_name}]")

        if self._show_source and notification.source:
            parts.append(f"[{notification.source}]")

        parts.append(notification.title)

        if notification.body:
            parts.append(f"— {notification.body}")

        line = " ".join(parts)
        try:
            self._stream.write(line + "\n")
            self._stream.flush()
        except OSError as exc:
            logger.warning("Failed to write console notification: %s", exc)
            return False

        return True

    def set_min_level(self, level: NotificationLevel) -> None:
        """Change the minimum notification level."""
        self._min_level = level

    def __repr__(self) -> str:
        return f"ConsoleNotifier(min_level={self._min_level.name})"
