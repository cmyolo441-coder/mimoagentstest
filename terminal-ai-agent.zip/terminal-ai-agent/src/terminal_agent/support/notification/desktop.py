"""Desktop notifications: OS-level notification bubbles.

Uses platform-specific methods (notify-send on Linux, osascript on macOS,
or plyer as a cross-platform fallback) to show system notifications.
"""

from __future__ import annotations

import logging
import platform
import shutil
import subprocess
from typing import Any

from terminal_agent.support.notification.levels import Notification, NotificationLevel

logger = logging.getLogger("terminal_agent.support.notification.desktop")


class DesktopNotifier:
    """Send OS-level desktop notifications.

    Usage::

        notifier = DesktopNotifier(min_level=NotificationLevel.WARNING)
        notifier.notify(Notification(title="Task complete", level=NotificationLevel.INFO))
    """

    def __init__(
        self,
        min_level: NotificationLevel = NotificationLevel.WARNING,
        app_name: str = "Terminal Agent",
    ) -> None:
        self._min_level = min_level
        self._app_name = app_name
        self._platform = platform.system().lower()

    def notify(self, notification: Notification) -> bool:
        """Send a desktop notification.

        Returns True if the notification was sent successfully.
        """
        if notification.level < self._min_level:
            return False

        try:
            if self._platform == "linux":
                return self._notify_linux(notification)
            elif self._platform == "darwin":
                return self._notify_macos(notification)
            elif self._platform == "windows":
                return self._notify_windows(notification)
            else:
                logger.debug("Desktop notifications not supported on %s", self._platform)
                return False
        except Exception as exc:
            logger.warning("Desktop notification failed: %s", exc)
            return False

    def _notify_linux(self, notification: Notification) -> bool:
        """Send notification via notify-send on Linux."""
        if not shutil.which("notify-send"):
            logger.debug("notify-send not available")
            return False
        urgency = {
            NotificationLevel.DEBUG: "low",
            NotificationLevel.INFO: "normal",
            NotificationLevel.WARNING: "normal",
            NotificationLevel.ERROR: "critical",
            NotificationLevel.CRITICAL: "critical",
        }
        cmd = [
            "notify-send",
            f"--urgency={urgency.get(notification.level, 'normal')}",
            f"--app-name={self._app_name}",
            notification.title,
        ]
        if notification.body:
            cmd.append(notification.body)
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True

    def _notify_macos(self, notification: Notification) -> bool:
        """Send notification via osascript on macOS."""
        body = notification.body or notification.title
        script = (
            f'display notification "{body}" '
            f'with title "{self._app_name}" '
            f'subtitle "{notification.title}"'
        )
        subprocess.Popen(
            ["osascript", "-e", script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True

    def _notify_windows(self, notification: Notification) -> bool:
        """Send notification via Windows toast (best-effort)."""
        try:
            from plyer import notification as plyer_notification
            plyer_notification.notify(
                title=notification.title,
                message=notification.body or "",
                app_name=self._app_name,
                timeout=10,
            )
            return True
        except ImportError:
            logger.debug("plyer not available for Windows notifications")
            return False

    def is_available(self) -> bool:
        """Check if desktop notifications are available."""
        if self._platform == "linux":
            return shutil.which("notify-send") is not None
        elif self._platform == "darwin":
            return True  # osascript is always available
        elif self._platform == "windows":
            try:
                from plyer import notification  # noqa: F401
                return True
            except ImportError:
                return False
        return False

    def set_min_level(self, level: NotificationLevel) -> None:
        """Change the minimum notification level."""
        self._min_level = level

    def __repr__(self) -> str:
        return f"DesktopNotifier(platform={self._platform}, min_level={self._min_level.name})"
