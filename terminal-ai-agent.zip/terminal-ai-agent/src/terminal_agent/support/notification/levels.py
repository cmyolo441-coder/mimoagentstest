"""Notification levels and the Notification data model."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any


class NotificationLevel(IntEnum):
    """Notification severity levels (higher = more severe)."""
    DEBUG = 0
    INFO = 10
    WARNING = 20
    ERROR = 30
    CRITICAL = 40


@dataclass
class Notification:
    """A notification message.

    Attributes:
        title: Short summary.
        body: Detailed message.
        level: Severity level.
        source: Component that generated the notification.
        tags: Optional tags for filtering.
        timestamp: When the notification was created.
        id: Unique identifier.
        metadata: Arbitrary extra data.
    """
    title: str
    body: str = ""
    level: NotificationLevel = NotificationLevel.INFO
    source: str = ""
    tags: list[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a dictionary."""
        return {
            "id": self.id,
            "title": self.title,
            "body": self.body,
            "level": self.level.name.lower(),
            "level_value": self.level.value,
            "source": self.source,
            "tags": self.tags,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }

    @property
    def icon(self) -> str:
        """Icon for the notification level."""
        icons = {
            NotificationLevel.DEBUG: "🔍",
            NotificationLevel.INFO: "ℹ️ ",
            NotificationLevel.WARNING: "⚠️ ",
            NotificationLevel.ERROR: "❌",
            NotificationLevel.CRITICAL: "🚨",
        }
        return icons.get(self.level, "📢")

    def __str__(self) -> str:
        return f"[{self.level.name}] {self.title}: {self.body}"
