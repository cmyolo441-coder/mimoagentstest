"""Webhook notifications: send events to external services.

Supports generic HTTP webhooks with JSON payloads, plus
optimized formatters for Slack, Discord, and Microsoft Teams.
"""

from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from typing import Any

from terminal_agent.support.notification.levels import Notification, NotificationLevel

logger = logging.getLogger("terminal_agent.support.notification.webhook")


class WebhookNotifier:
    """Send notifications via HTTP webhooks.

    Usage::

        notifier = WebhookNotifier(
            url="https://hooks.slack.com/services/...",
            service="slack",
        )
        notifier.notify(Notification(title="Deploy complete", level=NotificationLevel.INFO))
    """

    def __init__(
        self,
        url: str,
        *,
        service: str = "generic",
        min_level: NotificationLevel = NotificationLevel.INFO,
        timeout: float = 10.0,
        headers: dict[str, str] | None = None,
    ) -> None:
        self._url = url
        self._service = service
        self._min_level = min_level
        self._timeout = timeout
        self._headers = headers or {"Content-Type": "application/json"}

    def notify(self, notification: Notification) -> bool:
        """Send a notification to the webhook.

        Returns True if the webhook responded with 2xx.
        """
        if notification.level < self._min_level:
            return False

        payload = self._format_payload(notification)
        try:
            data = json.dumps(payload, default=str).encode("utf-8")
            req = urllib.request.Request(
                self._url,
                data=data,
                headers=self._headers,
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                success = 200 <= resp.status < 300
                if success:
                    logger.debug("Webhook notification sent to %s", self._url)
                else:
                    logger.warning("Webhook returned status %d", resp.status)
                return success
        except urllib.error.URLError as exc:
            logger.warning("Webhook notification failed: %s", exc)
            return False
        except Exception as exc:
            logger.error("Webhook error: %s", exc)
            return False

    def _format_payload(self, notification: Notification) -> dict[str, Any]:
        """Format the notification for the target service."""
        if self._service == "slack":
            return self._format_slack(notification)
        elif self._service == "discord":
            return self._format_discord(notification)
        elif self._service == "teams":
            return self._format_teams(notification)
        else:
            return self._format_generic(notification)

    @staticmethod
    def _format_generic(notification: Notification) -> dict[str, Any]:
        """Generic JSON payload."""
        return notification.to_dict()

    @staticmethod
    def _format_slack(notification: Notification) -> dict[str, Any]:
        """Slack incoming webhook format."""
        color_map = {
            NotificationLevel.DEBUG: "#808080",
            NotificationLevel.INFO: "#36a64f",
            NotificationLevel.WARNING: "#daa038",
            NotificationLevel.ERROR: "#cc0000",
            NotificationLevel.CRITICAL: "#cc0000",
        }
        return {
            "attachments": [
                {
                    "color": color_map.get(notification.level, "#36a64f"),
                    "title": notification.title,
                    "text": notification.body,
                    "fields": [
                        {"title": "Level", "value": notification.level.name, "short": True},
                        {"title": "Source", "value": notification.source or "N/A", "short": True},
                    ],
                    "ts": int(notification.timestamp),
                }
            ]
        }

    @staticmethod
    def _format_discord(notification: Notification) -> dict[str, Any]:
        """Discord webhook format."""
        color_map = {
            NotificationLevel.DEBUG: 0x808080,
            NotificationLevel.INFO: 0x36A64F,
            NotificationLevel.WARNING: 0xDAA038,
            NotificationLevel.ERROR: 0xCC0000,
            NotificationLevel.CRITICAL: 0xCC0000,
        }
        return {
            "embeds": [
                {
                    "title": notification.title,
                    "description": notification.body,
                    "color": color_map.get(notification.level, 0x36A64F),
                    "fields": [
                        {"name": "Level", "value": notification.level.name, "inline": True},
                        {"name": "Source", "value": notification.source or "N/A", "inline": True},
                    ],
                }
            ]
        }

    @staticmethod
    def _format_teams(notification: Notification) -> dict[str, Any]:
        """Microsoft Teams webhook format (MessageCard)."""
        color_map = {
            NotificationLevel.DEBUG: "808080",
            NotificationLevel.INFO: "36a64f",
            NotificationLevel.WARNING: "daa038",
            NotificationLevel.ERROR: "cc0000",
            NotificationLevel.CRITICAL: "cc0000",
        }
        return {
            "@type": "MessageCard",
            "themeColor": color_map.get(notification.level, "36a64f"),
            "summary": notification.title,
            "sections": [
                {
                    "activityTitle": notification.title,
                    "activitySubtitle": f"Level: {notification.level.name}",
                    "text": notification.body,
                    "facts": [
                        {"name": "Source", "value": notification.source or "N/A"},
                    ],
                }
            ],
        }

    def set_min_level(self, level: NotificationLevel) -> None:
        """Change the minimum notification level."""
        self._min_level = level

    def __repr__(self) -> str:
        return f"WebhookNotifier(service={self._service}, url={self._url[:50]}...)"
