"""Notification history: record and query past notifications."""

from __future__ import annotations

import logging
import threading
import time
from typing import Any

from terminal_agent.support.notification.levels import Notification, NotificationLevel

logger = logging.getLogger("terminal_agent.support.notification.history")


class NotificationHistory:
    """Store notification history in memory with optional persistence.

    Usage::

        history = NotificationHistory(max_size=500)
        history.record(notification)
        recent = history.get_recent(level=NotificationLevel.WARNING, limit=10)
    """

    def __init__(self, max_size: int = 1000) -> None:
        self._max_size = max_size
        self._notifications: list[Notification] = []
        self._lock = threading.Lock()

    def record(self, notification: Notification) -> None:
        """Add a notification to history."""
        with self._lock:
            self._notifications.append(notification)
            if len(self._notifications) > self._max_size:
                self._notifications = self._notifications[-self._max_size:]

    def get_recent(
        self,
        *,
        level: NotificationLevel | None = None,
        source: str | None = None,
        tag: str | None = None,
        since: float | None = None,
        limit: int = 50,
    ) -> list[Notification]:
        """Query notification history with filters."""
        with self._lock:
            results = self._notifications
        if level is not None:
            results = [n for n in results if n.level >= level]
        if source:
            results = [n for n in results if n.source == source]
        if tag:
            results = [n for n in results if tag in n.tags]
        if since:
            results = [n for n in results if n.timestamp >= since]
        return results[-limit:]

    def count(
        self,
        *,
        level: NotificationLevel | None = None,
        since: float | None = None,
    ) -> int:
        """Count notifications matching filters."""
        with self._lock:
            results = self._notifications
        if level is not None:
            results = [n for n in results if n.level >= level]
        if since:
            results = [n for n in results if n.timestamp >= since]
        return len(results)

    def clear(self) -> int:
        """Clear history.  Returns count of notifications removed."""
        with self._lock:
            count = len(self._notifications)
            self._notifications.clear()
            return count

    def summary(self) -> dict[str, Any]:
        """Return a summary of notification history."""
        with self._lock:
            by_level: dict[str, int] = {}
            for n in self._notifications:
                level_name = n.level.name.lower()
                by_level[level_name] = by_level.get(level_name, 0) + 1
            return {
                "total": len(self._notifications),
                "by_level": by_level,
                "oldest": self._notifications[0].timestamp if self._notifications else None,
                "newest": self._notifications[-1].timestamp if self._notifications else None,
            }

    def __len__(self) -> int:
        return len(self._notifications)
