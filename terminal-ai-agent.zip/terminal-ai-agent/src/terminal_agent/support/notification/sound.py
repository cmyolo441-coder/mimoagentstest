"""Sound notifications: audible alerts for important events.

Uses platform-specific methods to play notification sounds.
"""

from __future__ import annotations

import logging
import platform
import shutil
import subprocess
from pathlib import Path
from typing import Any

from terminal_agent.support.notification.levels import Notification, NotificationLevel

logger = logging.getLogger("terminal_agent.support.notification.sound")

# Default system sound paths per platform
_DEFAULT_SOUNDS: dict[str, str] = {
    "linux": "/usr/share/sounds/freedesktop/stereo/complete.oga",
    "darwin": "/System/Library/Sounds/Glass.aiff",
    "windows": "C:\\Windows\\Media\\notify.wav",
}


class SoundNotifier:
    """Play audible notification sounds.

    Usage::

        notifier = SoundNotifier(min_level=NotificationLevel.WARNING)
        notifier.notify(Notification(title="Error", level=NotificationLevel.ERROR))
    """

    def __init__(
        self,
        min_level: NotificationLevel = NotificationLevel.WARNING,
        sound_path: str | None = None,
        *,
        enabled: bool = True,
    ) -> None:
        self._min_level = min_level
        self._enabled = enabled
        self._platform = platform.system().lower()
        self._sound_path = sound_path or _DEFAULT_SOUNDS.get(self._platform, "")

    def notify(self, notification: Notification) -> bool:
        """Play a sound for the notification.

        Returns True if sound was played.
        """
        if not self._enabled or notification.level < self._min_level:
            return False
        return self._play_sound()

    def _play_sound(self) -> bool:
        """Play the configured sound."""
        try:
            if self._platform == "linux":
                return self._play_linux()
            elif self._platform == "darwin":
                return self._play_macos()
            elif self._platform == "windows":
                return self._play_windows()
            else:
                return self._play_fallback()
        except Exception as exc:
            logger.debug("Sound notification failed: %s", exc)
            return False

    def _play_linux(self) -> bool:
        """Play sound on Linux using paplay or aplay."""
        if self._sound_path and Path(self._sound_path).exists():
            for player in ("paplay", "aplay", "ffplay"):
                if shutil.which(player):
                    cmd = [player, self._sound_path]
                    if player == "ffplay":
                        cmd = ["ffplay", "-nodisp", "-autoexit", self._sound_path]
                    subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return True
        # Fallback: terminal bell
        return self._play_bell()

    def _play_macos(self) -> bool:
        """Play sound on macOS using afplay."""
        if self._sound_path and Path(self._sound_path).exists():
            subprocess.Popen(["afplay", self._sound_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        return self._play_bell()

    def _play_windows(self) -> bool:
        """Play sound on Windows."""
        try:
            import winsound
            if self._sound_path and Path(self._sound_path).exists():
                winsound.PlaySound(self._sound_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
                return True
        except ImportError:
            pass
        return self._play_bell()

    def _play_fallback(self) -> bool:
        """Cross-platform fallback using the terminal bell."""
        return self._play_bell()

    @staticmethod
    def _play_bell() -> bool:
        """Ring the terminal bell."""
        try:
            import sys
            sys.stderr.write("\a")
            sys.stderr.flush()
            return True
        except Exception:
            return False

    def set_enabled(self, enabled: bool) -> None:
        """Enable or disable sound notifications."""
        self._enabled = enabled

    def set_min_level(self, level: NotificationLevel) -> None:
        """Change the minimum notification level."""
        self._min_level = level

    def set_sound(self, path: str) -> None:
        """Change the notification sound file."""
        self._sound_path = path

    def is_available(self) -> bool:
        """Check if sound playback is available."""
        if self._platform == "linux":
            return any(shutil.which(p) for p in ("paplay", "aplay", "ffplay"))
        elif self._platform == "darwin":
            return shutil.which("afplay") is not None
        return True  # Windows has winsound built-in

    def __repr__(self) -> str:
        return f"SoundNotifier(enabled={self._enabled}, min_level={self._min_level.name})"
