"""Email notifications: send alerts via SMTP.

Supports plain-text and HTML email bodies with TLS encryption.
"""

from __future__ import annotations

import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any

from terminal_agent.support.notification.levels import Notification, NotificationLevel

logger = logging.getLogger("terminal_agent.support.notification.email")


class EmailNotifier:
    """Send email notifications via SMTP.

    Usage::

        notifier = EmailNotifier(
            smtp_host="smtp.gmail.com",
            smtp_port=587,
            username="user@gmail.com",
            password="app-password",
            from_addr="user@gmail.com",
            to_addrs=["admin@example.com"],
        )
        notifier.notify(Notification(title="Critical error", level=NotificationLevel.CRITICAL))
    """

    def __init__(
        self,
        smtp_host: str,
        smtp_port: int = 587,
        username: str = "",
        password: str = "",
        from_addr: str = "",
        to_addrs: list[str] | None = None,
        *,
        use_tls: bool = True,
        min_level: NotificationLevel = NotificationLevel.ERROR,
        subject_prefix: str = "[Terminal Agent]",
    ) -> None:
        self._smtp_host = smtp_host
        self._smtp_port = smtp_port
        self._username = username
        self._password = password
        self._from_addr = from_addr or username
        self._to_addrs = to_addrs or []
        self._use_tls = use_tls
        self._min_level = min_level
        self._subject_prefix = subject_prefix

    def notify(self, notification: Notification) -> bool:
        """Send an email notification.

        Returns True if the email was sent successfully.
        """
        if notification.level < self._min_level:
            return False
        if not self._to_addrs:
            logger.warning("No email recipients configured")
            return False

        try:
            msg = self._build_message(notification)
            self._send(msg)
            logger.info("Email notification sent: %s", notification.title)
            return True
        except Exception as exc:
            logger.error("Email notification failed: %s", exc)
            return False

    def _build_message(self, notification: Notification) -> MIMEMultipart:
        """Build a MIME email message."""
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"{self._subject_prefix} [{notification.level.name}] {notification.title}"
        msg["From"] = self._from_addr
        msg["To"] = ", ".join(self._to_addrs)

        # Plain text body
        text_body = self._format_text(notification)
        msg.attach(MIMEText(text_body, "plain", "utf-8"))

        # HTML body
        html_body = self._format_html(notification)
        msg.attach(MIMEText(html_body, "html", "utf-8"))

        return msg

    def _send(self, msg: MIMEMultipart) -> None:
        """Send the message via SMTP."""
        if self._use_tls:
            with smtplib.SMTP(self._smtp_host, self._smtp_port) as server:
                server.ehlo()
                server.starttls()
                if self._username:
                    server.login(self._username, self._password)
                server.sendmail(self._from_addr, self._to_addrs, msg.as_string())
        else:
            with smtplib.SMTP(self._smtp_host, self._smtp_port) as server:
                if self._username:
                    server.login(self._username, self._password)
                server.sendmail(self._from_addr, self._to_addrs, msg.as_string())

    @staticmethod
    def _format_text(notification: Notification) -> str:
        """Format notification as plain text."""
        lines = [
            f"Level: {notification.level.name}",
            f"Title: {notification.title}",
            f"Source: {notification.source or 'N/A'}",
            "",
            notification.body or "(no details)",
        ]
        if notification.tags:
            lines.append(f"Tags: {', '.join(notification.tags)}")
        return "\n".join(lines)

    @staticmethod
    def _format_html(notification: Notification) -> str:
        """Format notification as HTML."""
        color_map = {
            NotificationLevel.DEBUG: "#808080",
            NotificationLevel.INFO: "#2196F3",
            NotificationLevel.WARNING: "#FF9800",
            NotificationLevel.ERROR: "#F44336",
            NotificationLevel.CRITICAL: "#B71C1C",
        }
        color = color_map.get(notification.level, "#2196F3")
        body_html = (notification.body or "(no details)").replace("\n", "<br>")
        return f"""
        <html>
        <body style="font-family: Arial, sans-serif;">
            <div style="border-left: 4px solid {color}; padding: 10px; margin: 10px 0;">
                <h3 style="color: {color}; margin: 0;">{notification.icon} {notification.title}</h3>
                <p style="color: #666; margin: 5px 0;">Level: {notification.level.name} | Source: {notification.source or 'N/A'}</p>
                <div style="margin: 10px 0;">{body_html}</div>
                {'<p style="color: #999;">Tags: ' + ', '.join(notification.tags) + '</p>' if notification.tags else ''}
            </div>
        </body>
        </html>
        """

    def set_min_level(self, level: NotificationLevel) -> None:
        """Change the minimum notification level."""
        self._min_level = level

    def add_recipient(self, email: str) -> None:
        """Add an email recipient."""
        if email not in self._to_addrs:
            self._to_addrs.append(email)

    def __repr__(self) -> str:
        return f"EmailNotifier(host={self._smtp_host}, to={self._to_addrs})"
