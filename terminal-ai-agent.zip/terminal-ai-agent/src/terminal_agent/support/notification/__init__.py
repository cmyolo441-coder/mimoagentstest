"""Notification subsystem: console, desktop, sound, webhook, and email
notifications with level filtering and history tracking.
"""

from terminal_agent.support.notification.console import ConsoleNotifier
from terminal_agent.support.notification.desktop import DesktopNotifier
from terminal_agent.support.notification.sound import SoundNotifier
from terminal_agent.support.notification.webhook import WebhookNotifier
from terminal_agent.support.notification.email import EmailNotifier
from terminal_agent.support.notification.levels import NotificationLevel, Notification
from terminal_agent.support.notification.history import NotificationHistory

__all__ = [
    "ConsoleNotifier",
    "DesktopNotifier",
    "SoundNotifier",
    "WebhookNotifier",
    "EmailNotifier",
    "NotificationLevel",
    "Notification",
    "NotificationHistory",
]
