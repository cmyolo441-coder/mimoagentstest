"""Type definitions for Terminal Agent."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Any


class SafetyLevel(IntEnum):
    """Safety levels from 0 (unrestricted) to 5 (review only)."""
    UNRESTRICTED = 0
    MINIMAL = 1
    STANDARD = 2
    MODERATE = 3
    STRICT = 4
    REVIEW = 5


class SessionStatus(str, Enum):
    """Session status."""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


class GoalComplexity(str, Enum):
    """Goal complexity levels."""
    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"
    MULTI_SYSTEM = "multi_system"


class ErrorCategory(str, Enum):
    """Error categories for classification."""
    SYNTAX = "syntax"
    RUNTIME = "runtime"
    TYPE = "type"
    IMPORT = "import"
    PERMISSION = "permission"
    FILE_NOT_FOUND = "file_not_found"
    NETWORK = "network"
    API = "api"
    RATE_LIMIT = "rate_limit"
    AUTHENTICATION = "authentication"
    RESOURCE = "resource"
    DEPENDENCY = "dependency"
    BUILD = "build"
    TEST = "test"
    TIMEOUT = "timeout"
    CONFIGURATION = "configuration"
    STATE = "state"
    CONCURRENCY = "concurrency"
    UNKNOWN = "unknown"


class RecoveryLevel(IntEnum):
    """Error recovery levels."""
    IMMEDIATE_RETRY = 1
    MODIFIED_RETRY = 2
    ALTERNATIVE_APPROACH = 3
    RE_PLAN = 4
    ASK_USER = 5
    GRACEFUL_ABORT = 6


class ToolResultStatus(str, Enum):
    """Tool execution result status."""
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILURE = "failure"
    ERROR = "error"
    TIMEOUT = "timeout"
    BLOCKED = "blocked"


class MemoryCategory(str, Enum):
    """Memory categories."""
    TASK = "task"
    ERROR = "error"
    PATTERN = "pattern"
    PREFERENCE = "preference"
    PROJECT = "project"
    TOOL = "tool"
    ENVIRONMENT = "environment"


class VerificationStage(str, Enum):
    """Verification pipeline stages."""
    BASIC = "basic"
    FORMAT = "format"
    LOGIC = "logic"
    QUALITY = "quality"
    SEMANTIC = "semantic"
    REGRESSION = "regression"


@dataclass
class ToolCall:
    """Represents a tool call from the LLM."""
    name: str
    parameters: dict[str, Any]
    id: str | None = None


@dataclass
class ToolResult:
    """Result of a tool execution."""
    status: ToolResultStatus
    output: str = ""
    error: str | None = None
    exit_code: int = 0
    duration_ms: float = 0.0
    side_effects: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMResponse:
    """Parsed LLM response."""
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    reasoning: str | None = None
    finish_reason: str | None = None
    tokens_in: int = 0
    tokens_out: int = 0
    cost: float = 0.0
    latency_ms: float = 0.0
    provider: str = ""
    model: str = ""


@dataclass
class PlanStep:
    """A single step in a plan."""
    id: str
    description: str
    tool_hint: str | None = None
    dependencies: list[str] = field(default_factory=list)
    status: SessionStatus = SessionStatus.PENDING
    result: ToolResult | None = None
    error: str | None = None


@dataclass
class Plan:
    """A multi-step plan to achieve a goal."""
    goal: str
    steps: list[PlanStep] = field(default_factory=list)
    complexity: GoalComplexity = GoalComplexity.MODERATE
    estimated_steps: int = 0
    created_at: float = 0.0
    updated_at: float = 0.0


@dataclass
class Memory:
    """A stored memory."""
    id: str | None = None
    category: MemoryCategory = MemoryCategory.TASK
    content: str = ""
    embedding_id: str | None = None
    source_session_id: str | None = None
    relevance_score: float = 1.0
    access_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TraceEntry:
    """A single entry in an execution trace."""
    timestamp: float
    entry_type: str  # "thought", "action", "observation", "verification", "error"
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Session:
    """An agent session."""
    id: str | None = None
    goal: str = ""
    status: SessionStatus = SessionStatus.PENDING
    start_time: float = 0.0
    end_time: float = 0.0
    model_used: str = ""
    total_tokens: int = 0
    total_cost: float = 0.0
    total_steps: int = 0
    outcome: str = ""
    error_message: str | None = None
    plan: Plan | None = None
    traces: list[TraceEntry] = field(default_factory=list)


@dataclass
class ProviderConfig:
    """Configuration for an LLM provider."""
    provider: str = ""
    model: str = ""
    api_key: str = ""
    base_url: str | None = None
    organization: str | None = None
    temperature: float = 0.0
    max_tokens: int = 4096
    timeout: int = 120
    max_retries: int = 3
    retry_delay: float = 1.0


@dataclass
class ProjectInfo:
    """Detected project information."""
    languages: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    build_system: str | None = None
    test_framework: str | None = None
    package_manager: str | None = None
    cicd: str | None = None
    entry_points: list[str] = field(default_factory=list)
    root_dir: str = ""
    structure: dict[str, Any] = field(default_factory=dict)
