"""Global constants for Terminal Agent."""

from pathlib import Path

# Application
APP_NAME = "terminal-agent"
APP_DISPLAY_NAME = "Terminal Agent"
APP_VERSION = "0.1.0"

# Directories
GLOBAL_DIR = Path.home() / ".terminal-agent"
GLOBAL_CONFIG_FILE = GLOBAL_DIR / "config.toml"
GLOBAL_DB_FILE = GLOBAL_DIR / "agent.db"
GLOBAL_VECTOR_DB_FILE = GLOBAL_DIR / "vector.db"
GLOBAL_LOG_DIR = GLOBAL_DIR / "logs"
GLOBAL_CACHE_DIR = GLOBAL_DIR / "cache"
GLOBAL_BACKUP_DIR = GLOBAL_DIR / "backups"
GLOBAL_TRACE_DIR = GLOBAL_DIR / "traces"
GLOBAL_EXPORT_DIR = GLOBAL_DIR / "exports"
GLOBAL_PLUGIN_DIR = GLOBAL_DIR / "plugins"
GLOBAL_TEMPLATE_DIR = GLOBAL_DIR / "templates"
GLOBAL_KEY_DIR = GLOBAL_DIR / "keys"
GLOBAL_TMP_DIR = GLOBAL_DIR / "tmp"

PROJECT_DIR = Path(".agent")
PROJECT_CONFIG_FILE = PROJECT_DIR / "project.toml"
PROJECT_IGNORE_FILE = PROJECT_DIR / ".agentignore"
PROJECT_SESSION_DIR = PROJECT_DIR / "sessions"
PROJECT_STATE_DIR = PROJECT_DIR / "state"
PROJECT_CACHE_DIR = PROJECT_DIR / "cache"

# LLM Defaults
DEFAULT_LLM_PROVIDER = "openai"
DEFAULT_LLM_MODEL = "gpt-4o"
DEFAULT_TEMPERATURE = 0.0
DEFAULT_MAX_TOKENS = 4096
DEFAULT_TIMEOUT = 120
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_DELAY = 1.0

# Memory Defaults
DEFAULT_SHORT_TERM_TURNS = 20
DEFAULT_WORKING_MEMORY_FILES = 10
DEFAULT_LONG_TERM_MEMORIES_PER_QUERY = 5
DEFAULT_EMBEDDING_MODEL = "text-embedding-3-small"
DEFAULT_EMBEDDING_DIMENSIONS = 1536
DEFAULT_VECTOR_BACKEND = "chroma"
DEFAULT_CONSOLIDATION_INTERVAL = 3600
DEFAULT_DECAY_RATE = 0.1
DEFAULT_MAX_MEMORY_SIZE = 10000

# Safety
DEFAULT_SAFETY_LEVEL = 2
MAX_SAFETY_LEVEL = 5

# Cache
DEFAULT_CACHE_BACKEND = "memory"
DEFAULT_CACHE_MAX_SIZE = 1000
DEFAULT_CACHE_TTL = 3600

# Rate Limiting
DEFAULT_LLM_CALLS_PER_MINUTE = 60
DEFAULT_TOOL_CALLS_PER_MINUTE = 120
DEFAULT_BURST_ALLOWANCE = 10

# Tool Defaults
DEFAULT_SHELL_TIMEOUT = 300
DEFAULT_SHELL_MAX_OUTPUT = 100_000
DEFAULT_FILESYSTEM_MAX_READ = 1_000_000

# Agent Loop
DEFAULT_MAX_ITERATIONS = 100
DEFAULT_MAX_COST_PER_TASK = 5.00
DEFAULT_COST_WARNING_THRESHOLD = 0.80

# Performance Targets
TARGET_STARTUP_TIME = 2.0
TARGET_FIRST_TOKEN = 1.0
TARGET_TOOL_OVERHEAD = 0.1
TARGET_MEMORY_SEARCH = 0.05
TARGET_CONTEXT_ASSEMBLY = 0.2

# Database
DB_VERSION = 1
DB_TABLES = [
    "sessions",
    "conversation_turns",
    "tool_calls",
    "memories",
    "patterns",
    "prompts",
    "metrics",
    "errors",
    "file_changes",
    "configurations",
]

# Provider IDs
PROVIDER_OPENAI = "openai"
PROVIDER_ANTHROPIC = "anthropic"
PROVIDER_GOOGLE = "google"
PROVIDER_OLLAMA = "ollama"
PROVIDER_LITELLM = "litellm"
PROVIDER_AZURE = "azure"
PROVIDER_BEDROCK = "bedrock"
PROVIDER_COHERE = "cohere"
PROVIDER_TOGETHER = "together"
PROVIDER_GROQ = "groq"
PROVIDER_DEEPSEEK = "deepseek"
PROVIDER_CUSTOM = "custom"

# Tool Categories
TOOL_CATEGORIES = [
    "shell",
    "filesystem",
    "code",
    "git",
    "package_manager",
    "database",
    "docker",
    "network",
    "search",
    "testing",
    "code_generation",
    "documentation",
    "devops",
]

# File Extensions
PYTHON_EXTENSIONS = {".py", ".pyw", ".pyi"}
JAVASCRIPT_EXTENSIONS = {".js", ".jsx", ".mjs", ".cjs"}
TYPESCRIPT_EXTENSIONS = {".ts", ".tsx", ".mts", ".cts"}
GO_EXTENSIONS = {".go"}
RUST_EXTENSIONS = {".rs"}
JAVA_EXTENSIONS = {".java"}
