"""Exception hierarchy for Terminal Agent."""


class TerminalAgentError(Exception):
    """Base exception for all Terminal Agent errors."""

    def __init__(self, message: str, details: dict | None = None):
        super().__init__(message)
        self.details = details or {}


# Configuration Errors
class ConfigError(TerminalAgentError):
    """Base configuration error."""
    pass


class ConfigFileNotFoundError(ConfigError):
    """Configuration file not found."""
    pass


class ConfigValidationError(ConfigError):
    """Configuration validation failed."""
    pass


class ConfigEncryptionError(ConfigError):
    """Configuration encryption/decryption failed."""
    pass


# LLM Errors
class LLMError(TerminalAgentError):
    """Base LLM error."""
    pass


class ProviderError(LLMError):
    """LLM provider error."""
    pass


class RateLimitError(LLMError):
    """Rate limit exceeded."""
    pass


class TokenLimitError(LLMError):
    """Token limit exceeded."""
    pass


class CostLimitError(LLMError):
    """Cost limit exceeded."""
    pass


class ResponseParseError(LLMError):
    """Failed to parse LLM response."""
    pass


class ProviderNotAvailableError(LLMError):
    """LLM provider not available."""
    pass


# Tool Errors
class ToolError(TerminalAgentError):
    """Base tool error."""
    pass


class ToolNotFoundError(ToolError):
    """Tool not found in registry."""
    pass


class ToolExecutionError(ToolError):
    """Tool execution failed."""
    pass


class ToolTimeoutError(ToolError):
    """Tool execution timed out."""
    pass


class ToolValidationError(ToolError):
    """Tool parameter validation failed."""
    pass


# Safety Errors
class SafetyError(TerminalAgentError):
    """Base safety error."""
    pass


class CommandBlockedError(SafetyError):
    """Command blocked by safety system."""
    pass


class PathRestrictedError(SafetyError):
    """Path access restricted by safety system."""
    pass


class ConfirmationRequiredError(SafetyError):
    """User confirmation required."""
    pass


class SandboxViolationError(SafetyError):
    """Sandbox violation detected."""
    pass


# Memory Errors
class MemoryError(TerminalAgentError):
    """Base memory error."""
    pass


class MemoryStoreError(MemoryError):
    """Failed to store memory."""
    pass


class MemoryRecallError(MemoryError):
    """Failed to recall memory."""
    pass


class EmbeddingError(MemoryError):
    """Embedding generation failed."""
    pass


class VectorStoreError(MemoryError):
    """Vector store operation failed."""
    pass


# Orchestrator Errors
class OrchestratorError(TerminalAgentError):
    """Base orchestrator error."""
    pass


class PlanningError(OrchestratorError):
    """Plan generation failed."""
    pass


class ExecutionError(OrchestratorError):
    """Plan execution failed."""
    pass


class SessionError(OrchestratorError):
    """Session management error."""
    pass


class MaxIterationsError(OrchestratorError):
    """Maximum iterations reached."""
    pass


# Verification Errors
class VerificationError(TerminalAgentError):
    """Base verification error."""
    pass


class SyntaxError_(VerificationError):
    """Syntax verification failed."""
    pass


class RuntimeError_(VerificationError):
    """Runtime verification failed."""
    pass


class SchemaValidationError(VerificationError):
    """Schema validation failed."""
    pass


# Plugin Errors
class PluginError(TerminalAgentError):
    """Base plugin error."""
    pass


class PluginNotFoundError(PluginError):
    """Plugin not found."""
    pass


class PluginLoadError(PluginError):
    """Plugin load failed."""
    pass


class PluginValidationError(PluginError):
    """Plugin validation failed."""
    pass


# MCP Errors
class MCPError(TerminalAgentError):
    """Base MCP error."""
    pass


class MCPConnectionError(MCPError):
    """MCP connection failed."""
    pass


class MCPProtocolError(MCPError):
    """MCP protocol error."""
    pass


# Persistence Errors
class PersistenceError(TerminalAgentError):
    """Base persistence error."""
    pass


class DatabaseError(PersistenceError):
    """Database operation failed."""
    pass


class MigrationError(PersistenceError):
    """Database migration failed."""
    pass


class FileStoreError(PersistenceError):
    """File store operation failed."""
    pass
