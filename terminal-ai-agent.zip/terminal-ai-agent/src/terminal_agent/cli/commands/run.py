"""Run command — Start an agent session with a goal.

Usage:
    terminal-agent run "build a REST API"
    terminal-agent run --file goal.txt
    echo "fix the bug" | terminal-agent run
    terminal-agent run -p openai -m gpt-4o "deploy to kubernetes"
"""

from __future__ import annotations

import sys
from pathlib import Path

import click

from terminal_agent.cli.output import Verbosity, get_output
from terminal_agent.cli.parser import (
    DURATION,
    common_options,
    llm_options,
    merge_options,
    read_goal_from_file,
    read_goal_from_stdin,
    safety_options,
    session_options,
    validate_goal,
)
from terminal_agent.constants import (
    DEFAULT_MAX_COST_PER_TASK,
    DEFAULT_MAX_ITERATIONS,
    DEFAULT_SAFETY_LEVEL,
)


@click.command("run")
@click.argument("goal", required=False, default=None)
@click.option("--file", "-f", "goal_file", type=click.Path(exists=True), default=None,
              help="Read goal from a file.")
@click.option("--plan-only", is_flag=True, default=False,
              help="Generate and display a plan without executing.")
@click.option("--no-verify", is_flag=True, default=False,
              help="Skip verification steps.")
@click.option("--parallel", is_flag=True, default=False,
              help="Enable parallel execution of independent steps.")
@click.option("--timeout", type=DURATION, default=None,
              help="Maximum execution time (e.g., 30m, 2h).")
@click.option("--resume", "resume_session", type=str, default=None,
              help="Resume a previous session by ID.")
@common_options
@llm_options
@safety_options
@session_options
@click.pass_context
def run_command(
    ctx: click.Context,
    goal: str | None,
    goal_file: str | None,
    plan_only: bool,
    no_verify: bool,
    parallel: bool,
    timeout: float | None,
    resume_session: str | None,
    verbose: bool,
    debug: bool,
    quiet: bool,
    output_format: str | None,
    no_color: bool,
    provider: str | None,
    model: str | None,
    temperature: float | None,
    max_tokens: int | None,
    safety_level: int | None,
    confirm_all: bool,
    dry_run: bool,
    session_id: str | None,
    max_iterations: int | None,
    max_cost: float | None,
) -> None:
    """Start an agent session to achieve a GOAL.

    The goal can be provided as an argument, read from a file, or piped via stdin.

    Examples:

        terminal-agent run "create a Python web scraper"

        terminal-agent run --file task.txt

        echo "refactor main.py" | terminal-agent run

        terminal-agent run --provider openai --model gpt-4o "deploy to AWS"
    """
    out = get_output()

    # Resolve the goal from argument, file, or stdin
    resolved_goal = None

    if resume_session:
        resolved_goal = None  # Goal comes from the existing session
    elif goal:
        resolved_goal = validate_goal(goal)
    elif goal_file:
        resolved_goal = read_goal_from_file(goal_file)
    else:
        resolved_goal = read_goal_from_stdin()

    if not resume_session and not resolved_goal:
        out.error("No goal provided. Use an argument, --file, or pipe via stdin.")
        out.info("Example: terminal-agent run \"build a REST API\"")
        raise SystemExit(1)

    # Merge options
    opts = merge_options(
        ctx,
        provider=provider,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        safety_level=safety_level,
        max_iterations=max_iterations or DEFAULT_MAX_ITERATIONS,
        max_cost=max_cost or DEFAULT_MAX_COST_PER_TASK,
        confirm_all=confirm_all,
        dry_run=dry_run,
        plan_only=plan_only,
        no_verify=no_verify,
        parallel=parallel,
        timeout=timeout,
        resume_session=resume_session,
    )

    if resume_session:
        out.info(f"Resuming session: {resume_session}")
    elif resolved_goal:
        out.info(f"Goal: {resolved_goal}")

    if opts.get("dry_run"):
        out.warning("Dry run mode — no actions will be executed.")

    if opts.get("plan_only"):
        out.info("Plan-only mode — generating plan without execution.")

    # Display configuration summary in verbose mode
    if verbose:
        out.subheader("Configuration")
        out.key_value({
            "Provider": opts.get("provider", "default"),
            "Model": opts.get("model", "default"),
            "Safety level": opts.get("safety_level", DEFAULT_SAFETY_LEVEL),
            "Max iterations": opts.get("max_iterations", DEFAULT_MAX_ITERATIONS),
            "Max cost": f"${opts.get('max_cost', DEFAULT_MAX_COST_PER_TASK):.2f}",
            "Parallel": opts.get("parallel", False),
            "Verify": not opts.get("no_verify", False),
        })
        out.blank()

    try:
        _execute_run(out, resolved_goal, opts)
    except KeyboardInterrupt:
        out.warning("\nExecution interrupted by user.")
        raise SystemExit(130)
    except Exception as exc:
        out.error(f"Fatal error: {exc}")
        if debug:
            import traceback
            traceback.print_exc()
        raise SystemExit(1)


def _execute_run(out, goal: str | None, opts: dict) -> None:
    """Execute the run command logic.

    This is the integration point with the orchestrator module.
    Currently implements a placeholder that demonstrates the expected flow.
    """
    out.header("Starting Agent Session")

    if goal:
        out.info(f"Analyzing goal: {goal}")

    # Phase 1: Initialize components
    out.info("Initializing components...")
    # TODO: Initialize orchestrator, memory, LLM engine
    # orchestrator = Orchestrator(config=opts)
    # session = orchestrator.create_session(goal=goal)

    # Phase 2: Generate plan
    out.info("Generating plan...")
    # TODO: orchestrator.generate_plan(goal)
    # plan = session.plan

    if opts.get("plan_only"):
        out.info("Plan-only mode — displaying plan and exiting.")
        # TODO: Display the generated plan
        out.success("Plan generated successfully.")
        return

    # Phase 3: Execute plan
    out.info("Executing plan...")
    # TODO: orchestrator.execute_plan(plan)

    # Phase 4: Verify results
    if not opts.get("no_verify"):
        out.info("Verifying results...")
        # TODO: verification_engine.verify(session)

    # Phase 5: Report results
    out.header("Session Complete")
    out.success("Goal achieved successfully!")
    # TODO: Display session summary (files changed, commands run, cost, etc.)

    # This will be replaced with actual orchestrator integration:
    out.warning("Orchestrator not yet implemented — this is a placeholder.")
    out.info("The run command will connect to the orchestrator module once it's built.")
