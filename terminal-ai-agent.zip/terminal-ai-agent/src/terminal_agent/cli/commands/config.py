"""Config command — View and edit configuration.

Usage:
    terminal-agent config show
    terminal-agent config get llm.provider
    terminal-agent config set llm.provider openai
    terminal-agent config edit
    terminal-agent config validate
    terminal-agent config reset
    terminal-agent config export config-backup.toml
    terminal-agent config import config-backup.toml
    terminal-agent config profiles
    terminal-agent config use-profile production
"""

from __future__ import annotations

from pathlib import Path

import click

from terminal_agent.cli.output import get_output
from terminal_agent.cli.parser import KEY_VALUE, common_options, merge_options
from terminal_agent.constants import (
    GLOBAL_CONFIG_FILE,
    GLOBAL_DIR,
    PROJECT_CONFIG_FILE,
)


@click.group("config")
@common_options
@click.pass_context
def config_command(
    ctx: click.Context,
    verbose: bool,
    debug: bool,
    quiet: bool,
    output_format: str | None,
    no_color: bool,
) -> None:
    """View and edit Terminal Agent configuration.

    Configuration is stored in TOML files with the following precedence:
    CLI flags > Environment variables > Project config > Global config

    Examples:

        terminal-agent config show

        terminal-agent config get llm.provider

        terminal-agent config set llm.provider anthropic

        terminal-agent config set llm.model claude-sonnet-4-20250514
    """
    pass


@config_command.command("show")
@click.option("--global-only", is_flag=True, default=False,
              help="Show only global configuration.")
@click.option("--project-only", is_flag=True, default=False,
              help="Show only project configuration.")
@click.option("--merged", is_flag=True, default=True,
              help="Show merged configuration (default).")
@click.pass_context
def config_show(
    ctx: click.Context,
    global_only: bool,
    project_only: bool,
    merged: bool,
) -> None:
    """Show the current configuration."""
    out = get_output()

    out.header("Terminal Agent Configuration")

    if global_only:
        _show_config_file(out, GLOBAL_CONFIG_FILE, "Global Config")
    elif project_only:
        _show_config_file(out, PROJECT_CONFIG_FILE, "Project Config")
    else:
        _show_config_file(out, GLOBAL_CONFIG_FILE, "Global Config")
        _show_config_file(out, PROJECT_CONFIG_FILE, "Project Config")

        # Show environment overrides
        _show_env_overrides(out)

        out.blank()
        out.info(f"Config directory: {GLOBAL_DIR}")
        out.info("Use 'terminal-agent config get <key>' to view a specific value.")
        out.info("Use 'terminal-agent config set <key> <value>' to change a value.")


@config_command.command("get")
@click.argument("key")
@click.pass_context
def config_get(ctx: click.Context, key: str) -> None:
    """Get a configuration value by key.

    Keys use dot notation: llm.provider, safety.level, memory.backend, etc.

    Examples:

        terminal-agent config get llm.provider

        terminal-agent config get safety.level
    """
    out = get_output()

    # TODO: Implement actual config reading from TOML files
    # config_manager = ConfigManager()
    # value = config_manager.get(key)
    # if value is not None:
    #     out.print(f"{key} = {value}")
    # else:
    #     out.warning(f"Key '{key}' not found in configuration.")

    out.info(f"Reading config key: {key}")
    out.warning("Config manager not yet implemented — this is a placeholder.")


@config_command.command("set")
@click.argument("key")
@click.argument("value")
@click.option("--global", "scope", flag_value="global", default=True,
              help="Set in global config (default).")
@click.option("--project", "scope", flag_value="project",
              help="Set in project config.")
@click.pass_context
def config_set(ctx: click.Context, key: str, value: str, scope: str) -> None:
    """Set a configuration value.

    Examples:

        terminal-agent config set llm.provider openai

        terminal-agent config set llm.model gpt-4o

        terminal-agent config set safety.level 3

        terminal-agent config --project set llm.model claude-sonnet-4-20250514
    """
    out = get_output()

    target = "global" if scope == "global" else "project"
    out.info(f"Setting {key} = {value} in {target} config")

    # TODO: Implement actual config writing
    # config_manager = ConfigManager(scope=scope)
    # config_manager.set(key, value)
    # config_manager.save()

    out.success(f"Set {key} = {value}")
    out.warning("Config manager not yet implemented — this is a placeholder.")


@config_command.command("edit")
@click.option("--global", "scope", flag_value="global", default=True,
              help="Edit global config (default).")
@click.option("--project", "scope", flag_value="project",
              help="Edit project config.")
@click.pass_context
def config_edit(ctx: click.Context, scope: str) -> None:
    """Open configuration file in your editor.

    Uses the EDITOR environment variable, falling back to vi.
    """
    out = get_output()

    import os
    config_file = GLOBAL_CONFIG_FILE if scope == "global" else PROJECT_CONFIG_FILE
    editor = os.environ.get("EDITOR", "vi")

    out.info(f"Opening {config_file} in {editor}...")

    # Ensure config file exists
    config_file.parent.mkdir(parents=True, exist_ok=True)
    if not config_file.exists():
        config_file.touch()
        out.info(f"Created new config file: {config_file}")

    # TODO: Implement actual editor launch with validation
    # After editing, validate the TOML and report errors
    import subprocess
    try:
        subprocess.run([editor, str(config_file)], check=True)
        out.success("Configuration saved.")
        # TODO: Validate the edited config
    except FileNotFoundError:
        out.error(f"Editor not found: {editor}")
        out.info("Set the EDITOR environment variable or edit manually:")
        out.info(f"  {config_file}")
    except subprocess.CalledProcessError:
        out.warning("Editor exited with non-zero status.")


@config_command.command("validate")
@click.pass_context
def config_validate(ctx: click.Context) -> None:
    """Validate the configuration files."""
    out = get_output()

    out.header("Validating Configuration")

    errors = []
    warnings = []

    # Check global config
    if GLOBAL_CONFIG_FILE.exists():
        out.info(f"Checking {GLOBAL_CONFIG_FILE}...")
        # TODO: Parse and validate TOML
        # try:
        #     config = toml.load(GLOBAL_CONFIG_FILE)
        #     validate_config(config)
        # except Exception as e:
        #     errors.append(f"Global config: {e}")
        out.info("  (validation not yet implemented)")
    else:
        warnings.append(f"Global config not found: {GLOBAL_CONFIG_FILE}")

    # Check project config
    if PROJECT_CONFIG_FILE.exists():
        out.info(f"Checking {PROJECT_CONFIG_FILE}...")
        out.info("  (validation not yet implemented)")
    else:
        warnings.append("No project config found (this is normal).")

    # Report results
    out.blank()
    if errors:
        for err in errors:
            out.error(err)
    if warnings:
        for warn in warnings:
            out.warning(warn)
    if not errors:
        out.success("Configuration is valid.")


@config_command.command("reset")
@click.option("--yes", "-y", is_flag=True, default=False,
              help="Skip confirmation prompt.")
@click.option("--global", "scope", flag_value="global", default=True,
              help="Reset global config (default).")
@click.option("--project", "scope", flag_value="project",
              help="Reset project config.")
@click.pass_context
def config_reset(ctx: click.Context, yes: bool, scope: str) -> None:
    """Reset configuration to defaults."""
    out = get_output()

    config_file = GLOBAL_CONFIG_FILE if scope == "global" else PROJECT_CONFIG_FILE

    if not yes:
        click.confirm(
            f"Reset {config_file} to defaults? This cannot be undone.",
            abort=True,
        )

    # TODO: Implement actual config reset
    # config_manager = ConfigManager(scope=scope)
    # config_manager.reset_to_defaults()
    # config_manager.save()

    out.success(f"Configuration reset to defaults: {config_file}")
    out.warning("Config manager not yet implemented — this is a placeholder.")


@config_command.command("export")
@click.argument("output_file", type=click.Path())
@click.pass_context
def config_export(ctx: click.Context, output_file: str) -> None:
    """Export configuration to a file."""
    out = get_output()

    path = Path(output_file)
    # TODO: Implement actual export
    # config = load_merged_config()
    # path.write_text(toml.dumps(config))

    out.success(f"Configuration exported to: {path}")
    out.warning("Config manager not yet implemented — this is a placeholder.")


@config_command.command("import")
@click.argument("input_file", type=click.Path(exists=True))
@click.pass_context
def config_import(ctx: click.Context, input_file: str) -> None:
    """Import configuration from a file."""
    out = get_output()

    path = Path(input_file)
    # TODO: Implement actual import with validation
    # config = toml.load(path)
    # validate_config(config)
    # save_config(config)

    out.success(f"Configuration imported from: {path}")
    out.warning("Config manager not yet implemented — this is a placeholder.")


@config_command.command("profiles")
@click.pass_context
def config_profiles(ctx: click.Context) -> None:
    """List available configuration profiles."""
    out = get_output()

    out.header("Configuration Profiles")

    # TODO: Implement actual profile listing
    # profiles = list_profiles()
    # for profile in profiles:
    #     out.status(profile.name, profile.status)

    out.info("Profile management not yet implemented.")
    out.info("Profiles allow switching between configurations (e.g., dev, staging, prod).")


@config_command.command("use-profile")
@click.argument("profile_name")
@click.pass_context
def config_use_profile(ctx: click.Context, profile_name: str) -> None:
    """Switch to a configuration profile."""
    out = get_output()

    # TODO: Implement actual profile switching
    # switch_profile(profile_name)

    out.success(f"Switched to profile: {profile_name}")
    out.warning("Profile management not yet implemented — this is a placeholder.")


# ── Helpers ───────────────────────────────────────────────────────────

def _show_config_file(out, path: Path, label: str) -> None:
    """Display contents of a config file."""
    out.subheader(label)
    if path.exists():
        try:
            content = path.read_text(encoding="utf-8").strip()
            if content:
                for line in content.splitlines():
                    out.print(f"  {line}")
            else:
                out.print("  (empty)", dim=True)
        except Exception as exc:
            out.error(f"  Error reading {path}: {exc}")
    else:
        out.print("  (not found)", dim=True)
    out.blank()


def _show_env_overrides(out) -> None:
    """Show environment variable overrides."""
    import os
    env_prefix = "TA_"
    env_vars = {
        k: v for k, v in os.environ.items()
        if k.startswith(env_prefix)
    }
    if env_vars:
        out.subheader("Environment Variable Overrides")
        for key, value in sorted(env_vars.items()):
            # Mask sensitive values
            display_value = value
            if any(s in key.lower() for s in ("key", "secret", "token", "password")):
                display_value = value[:4] + "****" if len(value) > 4 else "****"
            out.print(f"  {key} = {display_value}")
        out.blank()
