"""Health command — System health check.

Usage:
    terminal-agent health
    terminal-agent health --full
    terminal-agent health --fix
"""

from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

import click

from terminal_agent.cli.output import get_output
from terminal_agent.cli.parser import common_options
from terminal_agent.constants import (
    GLOBAL_CACHE_DIR,
    GLOBAL_CONFIG_FILE,
    GLOBAL_DB_FILE,
    GLOBAL_DIR,
    GLOBAL_LOG_DIR,
    GLOBAL_PLUGIN_DIR,
    GLOBAL_TRACE_DIR,
    GLOBAL_VECTOR_DB_FILE,
)


@click.command("health")
@click.option("--full", is_flag=True, default=False,
              help="Run comprehensive health checks including network tests.")
@click.option("--fix", is_flag=True, default=False,
              help="Attempt to fix detected issues automatically.")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="Output results as JSON.")
@common_options
@click.pass_context
def health_command(
    ctx: click.Context,
    full: bool,
    fix: bool,
    as_json: bool,
    verbose: bool,
    debug: bool,
    quiet: bool,
    output_format: str | None,
    no_color: bool,
) -> None:
    """Run system health checks.

    Checks the installation, configuration, dependencies, and connectivity
    of all Terminal Agent components.

    Examples:

        terminal-agent health

        terminal-agent health --full

        terminal-agent health --fix
    """
    out = get_output()

    if as_json:
        out.set_format(click.core._json_format)  # noqa

    out.header("System Health Check")

    checks = []
    all_passed = True

    # ── Check 1: Python version ──────────────────────────────────────
    py_version = sys.version_info
    if py_version >= (3, 10):
        checks.append(("Python version", f"{py_version.major}.{py_version.minor}.{py_version.micro}", "success"))
    elif py_version >= (3, 9):
        checks.append(("Python version", f"{py_version.major}.{py_version.minor}.{py_version.micro}", "warning"))
    else:
        checks.append(("Python version", f"{py_version.major}.{py_version.minor}.{py_version.micro}", "error"))
        all_passed = False

    # ── Check 2: Global directory ─────────────────────────────────────
    if GLOBAL_DIR.exists():
        checks.append(("Global directory", str(GLOBAL_DIR), "success"))
    else:
        if fix:
            GLOBAL_DIR.mkdir(parents=True, exist_ok=True)
            checks.append(("Global directory", f"Created: {GLOBAL_DIR}", "success"))
        else:
            checks.append(("Global directory", f"Not found: {GLOBAL_DIR}", "warning"))

    # ── Check 3: Config file ─────────────────────────────────────────
    if GLOBAL_CONFIG_FILE.exists():
        try:
            content = GLOBAL_CONFIG_FILE.read_text()
            if content.strip():
                checks.append(("Config file", "Present and non-empty", "success"))
            else:
                checks.append(("Config file", "Empty", "warning"))
        except Exception as exc:
            checks.append(("Config file", f"Read error: {exc}", "error"))
            all_passed = False
    else:
        checks.append(("Config file", "Not found (using defaults)", "info"))

    # ── Check 4: Database ────────────────────────────────────────────
    if GLOBAL_DB_FILE.exists():
        size_mb = GLOBAL_DB_FILE.stat().st_size / (1024 * 1024)
        checks.append(("Database", f"Present ({size_mb:.1f} MB)", "success"))
    else:
        checks.append(("Database", "Not initialized", "info"))

    # ── Check 5: Vector store ────────────────────────────────────────
    if GLOBAL_VECTOR_DB_FILE.exists():
        size_mb = GLOBAL_VECTOR_DB_FILE.stat().st_size / (1024 * 1024)
        checks.append(("Vector store", f"Present ({size_mb:.1f} MB)", "success"))
    else:
        checks.append(("Vector store", "Not initialized", "info"))

    # ── Check 6: Required directories ────────────────────────────────
    for dir_name, dir_path in [
        ("Logs", GLOBAL_LOG_DIR),
        ("Cache", GLOBAL_CACHE_DIR),
        ("Traces", GLOBAL_TRACE_DIR),
        ("Plugins", GLOBAL_PLUGIN_DIR),
    ]:
        if dir_path.exists():
            checks.append((f"{dir_name} directory", "Present", "success"))
        else:
            if fix:
                dir_path.mkdir(parents=True, exist_ok=True)
                checks.append((f"{dir_name} directory", "Created", "success"))
            else:
                checks.append((f"{dir_name} directory", "Not found", "warning"))

    # ── Check 7: CLI dependencies ────────────────────────────────────
    required_packages = ["click"]
    optional_packages = ["rich", "toml", "httpx", "pydantic"]

    for pkg in required_packages:
        try:
            __import__(pkg)
            checks.append((f"Package: {pkg}", "Installed", "success"))
        except ImportError:
            checks.append((f"Package: {pkg}", "Missing (required!)", "error"))
            all_passed = False

    for pkg in optional_packages:
        try:
            __import__(pkg)
            checks.append((f"Package: {pkg}", "Installed", "success"))
        except ImportError:
            checks.append((f"Package: {pkg}", "Not installed (optional)", "info"))

    # ── Check 8: Disk space ──────────────────────────────────────────
    try:
        usage = shutil.disk_usage(str(GLOBAL_DIR) if GLOBAL_DIR.exists() else "/")
        free_gb = usage.free / (1024 ** 3)
        if free_gb > 1.0:
            checks.append(("Disk space", f"{free_gb:.1f} GB free", "success"))
        elif free_gb > 0.1:
            checks.append(("Disk space", f"{free_gb:.2f} GB free", "warning"))
        else:
            checks.append(("Disk space", f"{free_gb:.2f} GB free", "error"))
            all_passed = False
    except Exception:
        checks.append(("Disk space", "Unable to check", "warning"))

    # ── Check 9: API keys ────────────────────────────────────────────
    api_keys = {
        "OpenAI": "OPENAI_API_KEY",
        "Anthropic": "ANTHROPIC_API_KEY",
        "Google": "GOOGLE_API_KEY",
        "DeepSeek": "DEEPSEEK_API_KEY",
        "Groq": "GROQ_API_KEY",
    }
    configured_keys = []
    for name, env_var in api_keys.items():
        if os.environ.get(env_var):
            configured_keys.append(name)

    if configured_keys:
        checks.append(("API keys", f"Configured: {', '.join(configured_keys)}", "success"))
    else:
        checks.append(("API keys", "None configured", "warning"))

    # ── Check 10: Network connectivity (full mode) ───────────────────
    if full:
        import socket
        endpoints = [
            ("OpenAI API", "api.openai.com", 443),
            ("Anthropic API", "api.anthropic.com", 443),
            ("PyPI", "pypi.org", 443),
        ]
        for name, host, port in endpoints:
            try:
                sock = socket.create_connection((host, port), timeout=5)
                sock.close()
                checks.append((f"Network: {name}", "Reachable", "success"))
            except (socket.timeout, OSError):
                checks.append((f"Network: {name}", "Unreachable", "warning"))

    # ── Display results ──────────────────────────────────────────────
    out.blank()
    for label, value, status in checks:
        out.status(label, value, status)

    out.blank()
    out.divider()

    if all_passed:
        out.success("All critical checks passed!")
    else:
        out.error("Some critical checks failed. Please fix the issues above.")

    if not fix:
        out.info("Run with --fix to attempt automatic fixes.")

    # Summary counts
    counts = {"success": 0, "warning": 0, "error": 0, "info": 0}
    for _, _, status in checks:
        counts[status] = counts.get(status, 0) + 1

    out.blank()
    out.print(
        f"  {counts['success']} passed, "
        f"{counts['warning']} warnings, "
        f"{counts['error']} errors, "
        f"{counts['info']} info"
    )
