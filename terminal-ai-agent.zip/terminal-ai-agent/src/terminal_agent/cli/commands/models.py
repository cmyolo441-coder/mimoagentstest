"""Models command — List available models and providers.

Usage:
    terminal-agent models list
    terminal-agent models list --provider openai
    terminal-agent models info gpt-4o
    terminal-agent models test gpt-4o
    terminal-agent models providers
    terminal-agent models set-default gpt-4o
"""

from __future__ import annotations

import click

from terminal_agent.cli.output import get_output
from terminal_agent.cli.parser import common_options
from terminal_agent.constants import (
    DEFAULT_LLM_MODEL,
    DEFAULT_LLM_PROVIDER,
    PROVIDER_ANTHROPIC,
    PROVIDER_AZURE,
    PROVIDER_BEDROCK,
    PROVIDER_COHERE,
    PROVIDER_CUSTOM,
    PROVIDER_DEEPSEEK,
    PROVIDER_GOOGLE,
    PROVIDER_GROQ,
    PROVIDER_LITELLM,
    PROVIDER_OLLAMA,
    PROVIDER_OPENAI,
    PROVIDER_TOGETHER,
)

# Provider metadata for display
_PROVIDERS = {
    PROVIDER_OPENAI: {
        "name": "OpenAI",
        "models": ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "o1", "o3", "o4-mini"],
        "env_key": "OPENAI_API_KEY",
    },
    PROVIDER_ANTHROPIC: {
        "name": "Anthropic",
        "models": ["claude-opus-4-20250514", "claude-sonnet-4-20250514", "claude-3-5-haiku-20241022"],
        "env_key": "ANTHROPIC_API_KEY",
    },
    PROVIDER_GOOGLE: {
        "name": "Google",
        "models": ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.0-flash"],
        "env_key": "GOOGLE_API_KEY",
    },
    PROVIDER_OLLAMA: {
        "name": "Ollama (Local)",
        "models": ["llama3.1", "mistral", "codellama", "qwen2.5", "phi3"],
        "env_key": None,
    },
    PROVIDER_DEEPSEEK: {
        "name": "DeepSeek",
        "models": ["deepseek-chat", "deepseek-coder", "deepseek-reasoner"],
        "env_key": "DEEPSEEK_API_KEY",
    },
    PROVIDER_GROQ: {
        "name": "Groq",
        "models": ["llama-3.1-70b-versatile", "mixtral-8x7b-32768"],
        "env_key": "GROQ_API_KEY",
    },
    PROVIDER_TOGETHER: {
        "name": "Together AI",
        "models": ["meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo", "mistralai/Mixtral-8x7B-Instruct-v0.1"],
        "env_key": "TOGETHER_API_KEY",
    },
    PROVIDER_COHERE: {
        "name": "Cohere",
        "models": ["command-r-plus", "command-r"],
        "env_key": "COHERE_API_KEY",
    },
    PROVIDER_LITELLM: {
        "name": "LiteLLM (Proxy)",
        "models": ["(proxied models)"],
        "env_key": "LITELLM_API_KEY",
    },
    PROVIDER_AZURE: {
        "name": "Azure OpenAI",
        "models": ["(configured per deployment)"],
        "env_key": "AZURE_OPENAI_API_KEY",
    },
    PROVIDER_BEDROCK: {
        "name": "AWS Bedrock",
        "models": ["anthropic.claude-3-5-sonnet-20241022-v2:0", "amazon.titan-text-express-v1"],
        "env_key": None,
    },
    PROVIDER_CUSTOM: {
        "name": "Custom (OpenAI-compatible)",
        "models": ["(user-defined)"],
        "env_key": None,
    },
}


@click.group("models")
@common_options
@click.pass_context
def models_command(
    ctx: click.Context,
    verbose: bool,
    debug: bool,
    quiet: bool,
    output_format: str | None,
    no_color: bool,
) -> None:
    """List available models and providers.

    Manage LLM providers and models used by the agent.

    Examples:

        terminal-agent models list

        terminal-agent models list --provider anthropic

        terminal-agent models providers
    """
    pass


@models_command.command("list")
@click.option("--provider", "-p", type=str, default=None,
              help="Filter by provider.")
@click.option("--search", "-s", type=str, default=None,
              help="Search models by name.")
@click.option("--format", "output_fmt", type=click.Choice(["table", "compact", "json"]),
              default="table", help="Output format.")
@click.pass_context
def models_list(
    ctx: click.Context,
    provider: str | None,
    search: str | None,
    output_fmt: str,
) -> None:
    """List available models."""
    out = get_output()

    out.header("Available Models")

    rows = []
    for prov_id, prov_info in _PROVIDERS.items():
        if provider and prov_id != provider:
            continue
        for model in prov_info["models"]:
            if search and search.lower() not in model.lower():
                continue
            is_default = (
                prov_id == DEFAULT_LLM_PROVIDER and model == DEFAULT_LLM_MODEL
            )
            default_marker = " (default)" if is_default else ""
            rows.append([
                prov_info["name"],
                model,
                f"{prov_id}{default_marker}",
            ])

    if rows:
        out.table(
            headers=["Provider", "Model", "Provider ID"],
            rows=rows,
        )
    else:
        out.info("No models found matching the criteria.")

    out.blank()
    out.info(f"Default: {DEFAULT_LLM_PROVIDER}/{DEFAULT_LLM_MODEL}")
    out.info("Use 'terminal-agent models set-default' to change.")


@models_command.command("providers")
@click.option("--configured-only", is_flag=True, default=False,
              help="Show only providers with configured API keys.")
@click.pass_context
def models_providers(ctx: click.Context, configured_only: bool) -> None:
    """List all supported LLM providers."""
    out = get_output()

    import os

    out.header("LLM Providers")

    rows = []
    for prov_id, prov_info in _PROVIDERS.items():
        env_key = prov_info.get("env_key")
        if env_key:
            configured = "✓ configured" if os.environ.get(env_key) else "✗ not configured"
        else:
            configured = "n/a"

        if configured_only and "not configured" in configured:
            continue

        rows.append([
            prov_info["name"],
            prov_id,
            configured,
            str(len(prov_info["models"])),
        ])

    out.table(
        headers=["Name", "ID", "API Key", "Models"],
        rows=rows,
    )

    out.blank()
    out.info("Set API keys via environment variables or 'terminal-agent config set'.")


@models_command.command("info")
@click.argument("model_name")
@click.pass_context
def models_info(ctx: click.Context, model_name: str) -> None:
    """Show detailed information about a model."""
    out = get_output()

    out.header(f"Model: {model_name}")

    # Find the model in our provider list
    found = False
    for prov_id, prov_info in _PROVIDERS.items():
        for model in prov_info["models"]:
            if model == model_name or model_name in model:
                found = True
                out.key_value({
                    "Provider": prov_info["name"],
                    "Provider ID": prov_id,
                    "Model": model,
                    "API Key Env": prov_info.get("env_key") or "N/A",
                })
                out.blank()
                break

    if not found:
        out.info(f"Model '{model_name}' not found in built-in catalog.")
        out.info("It may be available through a custom provider or LiteLLM proxy.")

    # TODO: Implement actual model info with capabilities
    out.info("Detailed model capabilities (context window, pricing, etc.)")
    out.info("will be available when the LLM engine is implemented.")


@models_command.command("test")
@click.argument("model_name")
@click.option("--prompt", type=str, default="Hello, respond with one word.",
              help="Test prompt to send.")
@click.option("--provider", "-p", type=str, default=None,
              help="Provider to use for testing.")
@click.pass_context
def models_test(
    ctx: click.Context,
    model_name: str,
    prompt: str,
    provider: str | None,
) -> None:
    """Test a model by sending a simple prompt."""
    out = get_output()

    out.info(f"Testing model: {model_name}")
    out.info(f"Prompt: {prompt}")

    # TODO: Implement actual model testing
    # llm_engine = LLMEngine(provider=provider, model=model_name)
    # start = time.time()
    # response = llm_engine.complete(prompt)
    # elapsed = time.time() - start
    # out.success(f"Response ({elapsed:.2f}s): {response.content}")

    out.warning("Model testing not yet implemented — this is a placeholder.")
    out.info("When implemented, this will:")
    out.list_items([
        "Send a test prompt to the model",
        "Measure response latency",
        "Show token usage",
        "Verify the model is accessible",
    ], indent=1)


@models_command.command("set-default")
@click.argument("model_name")
@click.option("--provider", "-p", type=str, default=None,
              help="Provider for the model.")
@click.pass_context
def models_set_default(ctx: click.Context, model_name: str, provider: str | None) -> None:
    """Set the default model for new sessions."""
    out = get_output()

    # TODO: Implement actual default model setting
    # config = ConfigManager()
    # config.set("llm.model", model_name)
    # if provider:
    #     config.set("llm.provider", provider)
    # config.save()

    if provider:
        out.success(f"Default model set to: {provider}/{model_name}")
    else:
        out.success(f"Default model set to: {model_name}")

    out.warning("Default model setting not yet implemented — this is a placeholder.")
