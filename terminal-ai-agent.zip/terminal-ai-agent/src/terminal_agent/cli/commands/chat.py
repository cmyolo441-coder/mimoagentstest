"""Chat command — Start an interactive chat session.

Usage:
    terminal-agent chat
    terminal-agent chat --system "You are a Python expert"
    terminal-agent chat --continue-session abc123
"""

from __future__ import annotations

import sys

import click

from terminal_agent.cli.output import Verbosity, get_output
from terminal_agent.cli.parser import common_options, llm_options, merge_options, safety_options


@click.command("chat")
@click.option("--system", "-S", "system_prompt", type=str, default=None,
              help="Custom system prompt for the chat session.")
@click.option("--continue-session", type=str, default=None,
              help="Continue a previous chat session by ID.")
@click.option("--context", type=click.Path(exists=True), multiple=True,
              help="Files to include as context (can be specified multiple times).")
@click.option("--max-history", type=int, default=50,
              help="Maximum conversation turns to keep in context.")
@common_options
@llm_options
@safety_options
@click.pass_context
def chat_command(
    ctx: click.Context,
    system_prompt: str | None,
    continue_session: str | None,
    context: tuple[str, ...],
    max_history: int,
    verbose: bool,
    debug: bool,
    quiet: bool,
    output_format: str | None,
    no_color: bool,
    provider: str | None,
    model: str | None,
    temperature: float | None,
    max_tokens: int | None,
    safety_level: int | None,
    confirm_all: bool,
    dry_run: bool,
) -> None:
    """Start an interactive chat session with the agent.

    In chat mode, you can have a conversation with the agent, give it
    goals, ask questions, and guide its behavior interactively.

    Examples:

        terminal-agent chat

        terminal-agent chat --system "You are a Rust expert"

        terminal-agent chat --context README.md --context src/main.py
    """
    out = get_output()

    opts = merge_options(
        ctx,
        provider=provider,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        safety_level=safety_level,
        system_prompt=system_prompt,
        continue_session=continue_session,
        context=list(context),
        max_history=max_history,
        confirm_all=confirm_all,
        dry_run=dry_run,
    )

    # Validate terminal
    if not sys.stdin.isatty():
        out.error("Chat mode requires an interactive terminal.")
        out.info("Use 'terminal-agent run \"your goal\"' for non-interactive execution.")
        raise SystemExit(1)

    out.header("Interactive Chat Session")
    out.info("Type your messages below. Commands:")
    out.list_items([
        "/help    — Show available commands",
        "/plan    — Display current plan",
        "/status  — Show session status",
        "/history — Show conversation history",
        "/clear   — Clear the screen",
        "/exit    — End the session",
    ], indent=1)
    out.blank()

    if continue_session:
        out.info(f"Continuing session: {continue_session}")

    if context:
        out.info(f"Loaded {len(context)} context file(s):")
        for ctx_file in context:
            out.print(f"  • {ctx_file}", indent=1)

    out.divider()
    out.blank()

    try:
        _run_chat_loop(out, opts)
    except KeyboardInterrupt:
        out.blank()
        out.info("Chat session ended.")
        raise SystemExit(0)
    except EOFError:
        out.blank()
        out.info("Chat session ended.")
        raise SystemExit(0)


def _run_chat_loop(out, opts: dict) -> None:
    """Run the interactive chat loop.

    This is the integration point with the orchestrator module.
    Reads user input, sends to the agent, displays responses.
    """
    # TODO: Initialize orchestrator, memory, LLM engine
    # orchestrator = Orchestrator(config=opts)
    # session = orchestrator.create_or_resume_session(...)

    turn = 0

    while True:
        try:
            # Read user input
            user_input = input(click.style("You › ", fg="cyan", bold=True)).strip()
        except EOFError:
            break

        if not user_input:
            continue

        # Handle slash commands
        if user_input.startswith("/"):
            cmd = user_input.lower().split()[0]
            if cmd in ("/exit", "/quit", "/q"):
                out.info("Ending chat session.")
                break
            elif cmd == "/help":
                out.list_items([
                    "/help    — Show this help message",
                    "/plan    — Display current plan",
                    "/status  — Show session status",
                    "/history — Show conversation history",
                    "/clear   — Clear the screen",
                    "/exit    — End the session",
                ], title="Commands", indent=1)
                continue
            elif cmd == "/clear":
                click.clear()
                continue
            elif cmd == "/plan":
                out.info("Plan display not yet implemented.")
                continue
            elif cmd == "/status":
                out.info(f"Turn: {turn}")
                out.info(f"Provider: {opts.get('provider', 'default')}")
                out.info(f"Model: {opts.get('model', 'default')}")
                continue
            elif cmd == "/history":
                out.info("History display not yet implemented.")
                continue
            else:
                out.warning(f"Unknown command: {cmd}. Type /help for available commands.")
                continue

        # Process message through agent
        turn += 1

        # TODO: Send to orchestrator, get response
        # response = orchestrator.chat(user_input)
        # out.print(f"Agent › {response.content}", color=_Colors.BRIGHT_GREEN)

        # Placeholder response
        out.print(
            click.style("Agent › ", fg="green", bold=True) +
            "(Orchestrator not yet implemented — this is a placeholder.)"
        )
        out.print(
            "The chat command will connect to the orchestrator module once it's built.",
            dim=True,
        )
        out.blank()
