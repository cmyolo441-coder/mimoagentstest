"""Export command — Export session data.

Usage:
    terminal-agent export session abc123 --format json
    terminal-agent export memories --format jsonl
    terminal-agent export traces --since 7d
    terminal-agent export config
    terminal-agent export all --output backup.tar.gz
"""

from __future__ import annotations

import click

from terminal_agent.cli.output import get_output
from terminal_agent.cli.parser import DURATION, common_options
from terminal_agent.constants import GLOBAL_EXPORT_DIR


@click.group("export")
@common_options
@click.pass_context
def export_command(
    ctx: click.Context,
    verbose: bool,
    debug: bool,
    quiet: bool,
    output_format: str | None,
    no_color: bool,
) -> None:
    """Export session data, memories, traces, and configuration.

    Export data for backup, analysis, or sharing.

    Examples:

        terminal-agent export session abc123

        terminal-agent export memories --format jsonl

        terminal-agent export all --output backup.tar.gz
    """
    pass


@export_command.command("session")
@click.argument("session_id")
@click.option("--format", "export_format", type=click.Choice(["json", "markdown", "html", "csv"]),
              default="json", help="Export format.")
@click.option("--output", "-o", type=click.Path(), default=None,
              help="Output file path (default: exports/<session_id>.<format>).")
@click.option("--include-traces", is_flag=True, default=True,
              help="Include execution traces.")
@click.option("--include-tool-outputs", is_flag=True, default=False,
              help="Include full tool outputs (can be large).")
@click.pass_context
def export_session(
    ctx: click.Context,
    session_id: str,
    export_format: str,
    output: str | None,
    include_traces: bool,
    include_tool_outputs: bool,
) -> None:
    """Export a single session."""
    out = get_output()

    out.info(f"Exporting session: {session_id}")
    out.info(f"Format: {export_format}")

    # Determine output path
    if output:
        output_path = output
    else:
        GLOBAL_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        output_path = str(GLOBAL_EXPORT_DIR / f"{session_id}.{export_format}")

    # TODO: Implement actual session export
    # db = get_database()
    # session = db.get_session(session_id)
    # if not session:
    #     out.error(f"Session not found: {session_id}")
    #     raise SystemExit(1)
    # exporter = SessionExporter(session)
    # exporter.export(
    #     format=export_format,
    #     output=output_path,
    #     include_traces=include_traces,
    #     include_tool_outputs=include_tool_outputs,
    # )

    out.success(f"Session exported to: {output_path}")
    out.warning("Session export not yet implemented — this is a placeholder.")


@export_command.command("memories")
@click.option("--format", "export_format", type=click.Choice(["json", "jsonl", "csv", "markdown"]),
              default="jsonl", help="Export format.")
@click.option("--output", "-o", type=click.Path(), default=None,
              help="Output file path.")
@click.option("--category", type=str, default=None,
              help="Filter by memory category.")
@click.option("--since", type=DURATION, default=None,
              help="Export memories from the last N seconds (e.g., 7d, 30d).")
@click.pass_context
def export_memories(
    ctx: click.Context,
    export_format: str,
    output: str | None,
    category: str | None,
    since: float | None,
) -> None:
    """Export stored memories."""
    out = get_output()

    out.info("Exporting memories...")

    if output:
        output_path = output
    else:
        GLOBAL_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        output_path = str(GLOBAL_EXPORT_DIR / f"memories.{export_format}")

    # TODO: Implement actual memory export
    # memory_engine = MemoryEngine()
    # memories = memory_engine.export(
    #     category=category,
    #     since=time.time() - since if since else None,
    #     format=export_format,
    # )
    # write_output(memories, output_path)

    out.success(f"Memories exported to: {output_path}")
    out.warning("Memory export not yet implemented — this is a placeholder.")


@export_command.command("traces")
@click.option("--format", "export_format", type=click.Choice(["json", "jsonl", "csv"]),
              default="jsonl", help="Export format.")
@click.option("--output", "-o", type=click.Path(), default=None,
              help="Output file path.")
@click.option("--session", type=str, default=None,
              help="Export traces for a specific session.")
@click.option("--since", type=DURATION, default=None,
              help="Export traces from the last N seconds.")
@click.option("--limit", type=int, default=1000,
              help="Maximum number of traces to export.")
@click.pass_context
def export_traces(
    ctx: click.Context,
    export_format: str,
    output: str | None,
    session: str | None,
    since: float | None,
    limit: int,
) -> None:
    """Export execution traces."""
    out = get_output()

    out.info("Exporting traces...")

    if output:
        output_path = output
    else:
        GLOBAL_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        output_path = str(GLOBAL_EXPORT_DIR / f"traces.{export_format}")

    # TODO: Implement actual trace export
    out.success(f"Traces exported to: {output_path}")
    out.warning("Trace export not yet implemented — this is a placeholder.")


@export_command.command("config")
@click.option("--output", "-o", type=click.Path(), default=None,
              help="Output file path.")
@click.option("--include-secrets", is_flag=True, default=False,
              help="Include API keys and secrets (use with caution).")
@click.pass_context
def export_config(ctx: click.Context, output: str | None, include_secrets: bool) -> None:
    """Export configuration."""
    out = get_output()

    if output:
        output_path = output
    else:
        GLOBAL_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        output_path = str(GLOBAL_EXPORT_DIR / "config.toml")

    if include_secrets:
        out.warning("Including secrets in export! Handle the output file carefully.")

    # TODO: Implement actual config export
    out.success(f"Configuration exported to: {output_path}")
    out.warning("Config export not yet implemented — this is a placeholder.")


@export_command.command("all")
@click.option("--output", "-o", type=click.Path(), default=None,
              help="Output archive path.")
@click.option("--compress", is_flag=True, default=True,
              help="Compress the output archive.")
@click.pass_context
def export_all(ctx: click.Context, output: str | None, compress: bool) -> None:
    """Export all data (sessions, memories, traces, config)."""
    out = get_output()

    import time
    timestamp = int(time.time())

    if output:
        output_path = output
    else:
        GLOBAL_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        output_path = str(GLOBAL_EXPORT_DIR / f"full-export-{timestamp}.tar.gz")

    out.info("Exporting all data...")
    out.info(f"Output: {output_path}")

    # TODO: Implement actual full export
    # Creates a tar.gz with all data

    out.success(f"All data exported to: {output_path}")
    out.warning("Full export not yet implemented — this is a placeholder.")
