"""CLI subcommands for Terminal Agent.

Each module in this package defines one or more Click commands
that are registered with the main CLI group in app.py.
"""

from terminal_agent.cli.commands.run import run_command
from terminal_agent.cli.commands.chat import chat_command
from terminal_agent.cli.commands.config import config_command
from terminal_agent.cli.commands.sessions import sessions_command
from terminal_agent.cli.commands.history import history_command
from terminal_agent.cli.commands.plugins import plugins_command
from terminal_agent.cli.commands.mcp import mcp_command
from terminal_agent.cli.commands.tools import tools_command
from terminal_agent.cli.commands.models import models_command
from terminal_agent.cli.commands.health import health_command
from terminal_agent.cli.commands.update import update_command
from terminal_agent.cli.commands.export import export_command
from terminal_agent.cli.commands.import_cmd import import_command
from terminal_agent.cli.commands.traces import traces_command
from terminal_agent.cli.commands.metrics import metrics_command
from terminal_agent.cli.commands.memory import memory_command

__all__ = [
    "run_command",
    "chat_command",
    "config_command",
    "sessions_command",
    "history_command",
    "plugins_command",
    "mcp_command",
    "tools_command",
    "models_command",
    "health_command",
    "update_command",
    "export_command",
    "import_command",
    "traces_command",
    "metrics_command",
    "memory_command",
]
