"""Update command — Self-update the agent.

Usage:
    terminal-agent update
    terminal-agent update --check
    terminal-agent update --version 1.2.0
    terminal-agent update --rollback
"""

from __future__ import annotations

import click

from terminal_agent.cli.output import get_output
from terminal_agent.cli.parser import common_options
from terminal_agent.version import __version__


@click.command("update")
@click.option("--check", is_flag=True, default=False,
              help="Check for updates without installing.")
@click.option("--version", type=str, default=None,
              help="Install a specific version.")
@click.option("--rollback", is_flag=True, default=False,
              help="Rollback to the previous version.")
@click.option("--yes", "-y", is_flag=True, default=False,
              help="Skip confirmation prompt.")
@click.option("--channel", type=click.Choice(["stable", "beta", "dev"]),
              default="stable", help="Update channel.")
@common_options
@click.pass_context
def update_command(
    ctx: click.Context,
    check: bool,
    version: str | None,
    rollback: bool,
    yes: bool,
    channel: str,
    verbose: bool,
    debug: bool,
    quiet: bool,
    output_format: str | None,
    no_color: bool,
) -> None:
    """Self-update Terminal Agent.

    Checks for new versions and updates the installation.

    Examples:

        terminal-agent update

        terminal-agent update --check

        terminal-agent update --version 1.2.0

        terminal-agent update --rollback
    """
    out = get_output()

    out.header("Update Terminal Agent")
    out.info(f"Current version: {__version__}")
    out.info(f"Channel: {channel}")

    if rollback:
        _perform_rollback(out)
        return

    if check:
        _check_for_updates(out, channel)
        return

    if version:
        out.info(f"Target version: {version}")
    else:
        out.info("Checking for latest version...")

    if not yes:
        click.confirm("Proceed with update?", abort=True)

    _perform_update(out, version, channel)


def _check_for_updates(out, channel: str) -> None:
    """Check if a newer version is available."""
    # TODO: Implement actual version check
    # latest = check_latest_version(channel=channel)
    # if latest > __version__:
    #     out.success(f"New version available: {latest}")
    #     out.info("Run 'terminal-agent update' to install.")
    # else:
    #     out.success("Already on the latest version.")

    out.info("Version check not yet implemented.")
    out.info("When implemented, this will check PyPI or the update server")
    out.info("for the latest available version.")


def _perform_update(out, target_version: str | None, channel: str) -> None:
    """Perform the update."""
    # TODO: Implement actual update mechanism
    # Steps:
    # 1. Back up current installation
    # 2. Download new version
    # 3. Verify checksum
    # 4. Install new version
    # 5. Run migrations if needed
    # 6. Verify installation

    out.info("Update mechanism not yet implemented.")
    out.blank()
    out.info("When implemented, this will:")
    out.list_items([
        "Back up the current version",
        "Download the new version",
        "Verify the download integrity",
        "Install the update",
        "Run any necessary migrations",
        "Verify the installation",
    ], indent=1)
    out.blank()
    out.info("Manual update: pip install --upgrade terminal-agent")


def _perform_rollback(out) -> None:
    """Rollback to the previous version."""
    # TODO: Implement actual rollback
    # backup_dir = GLOBAL_DIR / "backups" / "previous_version"
    # if not backup_dir.exists():
    #     out.error("No previous version found to rollback to.")
    #     raise SystemExit(1)
    # restore_from_backup(backup_dir)

    out.info("Rollback mechanism not yet implemented.")
    out.info("When implemented, this will restore the previous version")
    out.info("from the automatic backup created during updates.")
    out.blank()
    out.info("Manual rollback: pip install terminal-agent==<previous-version>")


@click.command("version")
@click.option("--short", is_flag=True, default=False,
              help="Show only the version number.")
@click.pass_context
def version_command(ctx: click.Context, short: bool) -> None:
    """Show version information."""
    out = get_output()

    if short:
        out.print(__version__)
        return

    out.key_value({
        "Version": __version__,
        "Python": f"{__import__('sys').version_info.major}.{__import__('sys').version_info.minor}.{__import__('sys').version_info.micro}",
        "Platform": __import__('sys').platform,
    })
