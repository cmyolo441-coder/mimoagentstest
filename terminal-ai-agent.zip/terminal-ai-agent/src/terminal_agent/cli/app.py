"""Main CLI application for Terminal Agent.

Entry point for the `terminal-agent` command. Defines the root Click group
and orchestrates subcommand registration, global option handling, and
output initialization.
"""

from __future__ import annotations

import signal
import sys
from typing import Any

import click

from terminal_agent.constants import (
    APP_DISPLAY_NAME,
    APP_NAME,
    DEFAULT_LLM_MODEL,
    DEFAULT_LLM_PROVIDER,
    DEFAULT_SAFETY_LEVEL,
)
from terminal_agent.version import __version__

from terminal_agent.cli.output import OutputFormat, Verbosity, init_output
from terminal_agent.cli.parser import common_options


def _handle_interrupt(signum: int, frame: Any) -> None:
    """Handle Ctrl+C gracefully."""
    click.echo("\n\nInterrupted. Exiting gracefully.", err=True)
    sys.exit(130)


def _handle_sigpipe() -> None:
    """Handle broken pipe (e.g., piping output to head)."""
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)


class TerminalAgentGroup(click.Group):
    """Custom Click group with enhanced help formatting."""

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        """Format the help text with a banner."""
        # Banner
        formatter.write(f"\n  {click.style(APP_DISPLAY_NAME, fg='cyan', bold=True)}")
        formatter.write(f"  {click.style(f'v{__version__}', dim=True)}\n")
        formatter.write(f"  {click.style('The most powerful terminal-based autonomous AI agent', dim=True)}\n\n")

        # Usage
        formatter.write_usage(ctx.invoked_subcommand, "[OPTIONS] COMMAND [ARGS]...")

        # Description
        if self.help:
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(self.help)

        # Options (Click's Group.format_options also calls format_commands)
        self.format_options(ctx, formatter)

        # Epilog
        if self.epilog:
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(self.epilog)

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        """Get a command, with fuzzy matching for common abbreviations."""
        # Exact match first
        rv = click.Group.get_command(self, ctx, cmd_name)
        if rv is not None:
            return rv

        # Prefix matching
        matches = [
            name for name in self.list_commands(ctx)
            if name.startswith(cmd_name)
        ]
        if len(matches) == 1:
            return click.Group.get_command(self, ctx, matches[0])

        if len(matches) > 1:
            ctx.fail(f"Ambiguous command '{cmd_name}'. Did you mean: {', '.join(matches)}?")

        return None


@click.group(
    cls=TerminalAgentGroup,
    invoke_without_command=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)
@click.version_option(
    version=__version__,
    prog_name=APP_NAME,
    message="%(prog)s version %(version)s",
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    default=False,
    help="Enable verbose output.",
)
@click.option(
    "--debug",
    is_flag=True,
    default=False,
    help="Enable debug output with detailed tracing.",
)
@click.option(
    "--quiet", "-q",
    is_flag=True,
    default=False,
    help="Suppress all output except errors.",
)
@click.option(
    "--output-format", "-o",
    type=click.Choice(["colored", "structured", "quiet", "json"], case_sensitive=False),
    default=None,
    help="Output format.",
)
@click.option(
    "--no-color",
    is_flag=True,
    default=False,
    help="Disable colored output.",
)
@click.option(
    "--config", "-c",
    type=click.Path(),
    default=None,
    help="Path to configuration file.",
    envvar="TA_CONFIG",
)
@click.option(
    "--provider", "-p",
    type=str,
    default=None,
    help=f"LLM provider (default: {DEFAULT_LLM_PROVIDER}).",
    envvar="TA_PROVIDER",
)
@click.option(
    "--model", "-m",
    type=str,
    default=None,
    help=f"LLM model (default: {DEFAULT_LLM_MODEL}).",
    envvar="TA_MODEL",
)
@click.option(
    "--safety-level", "-s",
    type=click.IntRange(0, 5),
    default=None,
    help=f"Safety level 0-5 (default: {DEFAULT_SAFETY_LEVEL}).",
    envvar="TA_SAFETY_LEVEL",
)
@click.pass_context
def main(
    ctx: click.Context,
    verbose: bool,
    debug: bool,
    quiet: bool,
    output_format: str | None,
    no_color: bool,
    config: str | None,
    provider: str | None,
    model: str | None,
    safety_level: int | None,
) -> None:
    """Terminal Agent — Autonomous AI agent for your terminal.

    Start by running a goal:

        terminal-agent run "build a REST API with FastAPI"

    Or start an interactive chat:

        terminal-agent chat

    Use --help with any command for detailed usage.
    """
    # Install signal handlers
    signal.signal(signal.SIGINT, _handle_interrupt)
    try:
        _handle_sigpipe()
    except (AttributeError, OSError):
        pass  # SIGPIPE not available on Windows

    # Determine verbosity
    if debug:
        verbosity = Verbosity.DEBUG
    elif verbose:
        verbosity = Verbosity.VERBOSE
    elif quiet:
        verbosity = Verbosity.QUIET
    else:
        verbosity = Verbosity.NORMAL

    # Determine output format
    if output_format:
        fmt = OutputFormat(output_format)
    elif no_color:
        fmt = OutputFormat.STRUCTURED
    elif quiet:
        fmt = OutputFormat.QUIET
    else:
        fmt = OutputFormat.COLORED

    # Initialize global output
    out = init_output(format=fmt, verbosity=verbosity)

    # Store global options in context
    ctx.ensure_object(dict)
    ctx.obj["output"] = out
    ctx.obj["config_path"] = config
    ctx.obj["provider"] = provider
    ctx.obj["model"] = model
    ctx.obj["safety_level"] = safety_level
    ctx.obj["verbose"] = verbose or debug
    ctx.obj["debug"] = debug
    ctx.obj["quiet"] = quiet
    ctx.obj["dry_run"] = False
    ctx.obj["output_format"] = fmt

    # If no subcommand given, show help
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── Register subcommands ─────────────────────────────────────────────

from terminal_agent.cli.commands.run import run_command  # noqa: E402
from terminal_agent.cli.commands.chat import chat_command  # noqa: E402
from terminal_agent.cli.commands.config import config_command  # noqa: E402
from terminal_agent.cli.commands.sessions import sessions_command  # noqa: E402
from terminal_agent.cli.commands.history import history_command  # noqa: E402
from terminal_agent.cli.commands.plugins import plugins_command  # noqa: E402
from terminal_agent.cli.commands.mcp import mcp_command  # noqa: E402
from terminal_agent.cli.commands.tools import tools_command  # noqa: E402
from terminal_agent.cli.commands.models import models_command  # noqa: E402
from terminal_agent.cli.commands.health import health_command  # noqa: E402
from terminal_agent.cli.commands.update import update_command  # noqa: E402
from terminal_agent.cli.commands.export import export_command  # noqa: E402
from terminal_agent.cli.commands.import_cmd import import_command  # noqa: E402
from terminal_agent.cli.commands.traces import traces_command  # noqa: E402
from terminal_agent.cli.commands.metrics import metrics_command  # noqa: E402
from terminal_agent.cli.commands.memory import memory_command  # noqa: E402

main.add_command(run_command, "run")
main.add_command(chat_command, "chat")
main.add_command(config_command, "config")
main.add_command(sessions_command, "sessions")
main.add_command(history_command, "history")
main.add_command(plugins_command, "plugins")
main.add_command(mcp_command, "mcp")
main.add_command(tools_command, "tools")
main.add_command(models_command, "models")
main.add_command(health_command, "health")
main.add_command(update_command, "update")
main.add_command(export_command, "export")
main.add_command(import_command, "import")
main.add_command(traces_command, "traces")
main.add_command(metrics_command, "metrics")
main.add_command(memory_command, "memory")


if __name__ == "__main__":
    main()
