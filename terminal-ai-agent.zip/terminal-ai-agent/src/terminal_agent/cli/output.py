"""Output formatting for Terminal Agent CLI.

Provides colored, structured, and quiet output modes with consistent
formatting across all CLI commands.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, TextIO

import click


class OutputFormat(str, Enum):
    """Supported output formats."""
    COLORED = "colored"
    STRUCTURED = "structured"
    QUIET = "quiet"
    JSON = "json"


class Verbosity(str, Enum):
    """Output verbosity levels."""
    QUIET = "quiet"
    NORMAL = "normal"
    VERBOSE = "verbose"
    DEBUG = "debug"


# ANSI color codes
class _Colors:
    """ANSI escape codes for terminal colors."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"

    # Foreground
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    # Bright foreground
    BRIGHT_RED = "\033[91m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN = "\033[96m"

    # Background
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"


# Semantic color mappings
_STATUS_COLORS = {
    "success": _Colors.BRIGHT_GREEN,
    "ok": _Colors.BRIGHT_GREEN,
    "done": _Colors.BRIGHT_GREEN,
    "completed": _Colors.BRIGHT_GREEN,
    "pass": _Colors.BRIGHT_GREEN,
    "warning": _Colors.BRIGHT_YELLOW,
    "warn": _Colors.BRIGHT_YELLOW,
    "pending": _Colors.BRIGHT_YELLOW,
    "running": _Colors.BRIGHT_CYAN,
    "in_progress": _Colors.BRIGHT_CYAN,
    "info": _Colors.BRIGHT_BLUE,
    "error": _Colors.BRIGHT_RED,
    "fail": _Colors.BRIGHT_RED,
    "failed": _Colors.BRIGHT_RED,
    "blocked": _Colors.BRIGHT_RED,
    "cancelled": _Colors.DIM,
    "skipped": _Colors.DIM,
    "timeout": _Colors.BRIGHT_MAGENTA,
}

_SYMBOLS = {
    "success": "✓",
    "error": "✗",
    "warning": "⚠",
    "info": "ℹ",
    "bullet": "•",
    "arrow": "→",
    "spinner_frames": ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"],
}


def _supports_color(stream: TextIO) -> bool:
    """Check if the output stream supports ANSI colors."""
    if not hasattr(stream, "isatty"):
        return False
    if not stream.isatty():
        return False
    if sys.platform == "win32":
        # Enable ANSI on Windows 10+
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return True


@dataclass
class Output:
    """Manages CLI output formatting.

    Supports three modes:
    - colored: Human-readable with ANSI colors (default for TTY)
    - structured: Machine-readable JSON output
    - quiet: Minimal output, errors only
    """

    format: OutputFormat = OutputFormat.COLORED
    verbosity: Verbosity = Verbosity.NORMAL
    stream: TextIO = field(default_factory=lambda: sys.stdout)
    _use_color: bool = field(default=False, repr=False)
    _indent: int = field(default=0, repr=False)

    def __post_init__(self) -> None:
        if self.format == OutputFormat.COLORED:
            self._use_color = _supports_color(self.stream)
        else:
            self._use_color = False

    # ── Core output methods ──────────────────────────────────────────

    def _write(self, text: str, end: str = "\n", file: TextIO | None = None) -> None:
        """Write text to output stream."""
        target = file or self.stream
        target.write(text + end)
        target.flush()

    def _colorize(self, text: str, color: str) -> str:
        """Apply color to text if color output is enabled."""
        if not self._use_color:
            return text
        return f"{color}{text}{_Colors.RESET}"

    def _indent_str(self) -> str:
        """Return indentation string."""
        return "  " * self._indent

    # ── Public API ───────────────────────────────────────────────────

    def set_format(self, fmt: OutputFormat) -> None:
        """Change the output format."""
        self.format = fmt
        self._use_color = fmt == OutputFormat.COLORED and _supports_color(self.stream)

    def set_verbosity(self, level: Verbosity) -> None:
        """Change the verbosity level."""
        self.verbosity = level

    def print(
        self,
        message: str,
        *,
        color: str | None = None,
        bold: bool = False,
        dim: bool = False,
        indent: int | None = None,
    ) -> None:
        """Print a general message."""
        if self.verbosity == Verbosity.QUIET:
            return

        text = message
        if bold and self._use_color:
            text = f"{_Colors.BOLD}{text}"
        if dim and self._use_color:
            text = f"{_Colors.DIM}{text}"
        if color and self._use_color:
            text = f"{color}{text}"

        indent_str = self._indent_str() if indent is None else "  " * indent
        self._write(f"{indent_str}{text}")

    def success(self, message: str, *, indent: int | None = None) -> None:
        """Print a success message."""
        if self.format == OutputFormat.JSON:
            self._json_output({"type": "success", "message": message})
            return
        symbol = self._colorize(_SYMBOLS["success"], _Colors.BRIGHT_GREEN)
        text = self._colorize(message, _Colors.BRIGHT_GREEN)
        ind = self._indent_str() if indent is None else "  " * indent
        self._write(f"{ind}{symbol} {text}")

    def error(self, message: str, *, indent: int | None = None) -> None:
        """Print an error message (always shown, even in quiet mode)."""
        if self.format == OutputFormat.JSON:
            self._json_output({"type": "error", "message": message})
            return
        symbol = self._colorize(_SYMBOLS["error"], _Colors.BRIGHT_RED)
        text = self._colorize(message, _Colors.BRIGHT_RED)
        ind = self._indent_str() if indent is None else "  " * indent
        self._write(f"{ind}{symbol} {text}", file=sys.stderr)

    def warning(self, message: str, *, indent: int | None = None) -> None:
        """Print a warning message."""
        if self.format == OutputFormat.JSON:
            self._json_output({"type": "warning", "message": message})
            return
        symbol = self._colorize(_SYMBOLS["warning"], _Colors.BRIGHT_YELLOW)
        text = self._colorize(message, _Colors.BRIGHT_YELLOW)
        ind = self._indent_str() if indent is None else "  " * indent
        self._write(f"{ind}{symbol} {text}")

    def info(self, message: str, *, indent: int | None = None) -> None:
        """Print an info message."""
        if self.verbosity == Verbosity.QUIET:
            return
        if self.format == OutputFormat.JSON:
            self._json_output({"type": "info", "message": message})
            return
        symbol = self._colorize(_SYMBOLS["info"], _Colors.BRIGHT_BLUE)
        ind = self._indent_str() if indent is None else "  " * indent
        self._write(f"{ind}{symbol} {message}")

    def debug(self, message: str, *, indent: int | None = None) -> None:
        """Print a debug message (only in debug verbosity)."""
        if self.verbosity != Verbosity.DEBUG:
            return
        if self.format == OutputFormat.JSON:
            self._json_output({"type": "debug", "message": message})
            return
        text = self._colorize(f"[DEBUG] {message}", _Colors.DIM)
        ind = self._indent_str() if indent is None else "  " * indent
        self._write(f"{ind}{text}")

    def status(
        self, label: str, value: str, status: str = "info", *, indent: int | None = None
    ) -> None:
        """Print a status line with label and colored value."""
        if self.verbosity == Verbosity.QUIET:
            return
        if self.format == OutputFormat.JSON:
            self._json_output({"type": "status", "label": label, "value": value, "status": status})
            return
        color = _STATUS_COLORS.get(status, "")
        colored_value = self._colorize(value, color)
        ind = self._indent_str() if indent is None else "  " * indent
        self._write(f"{ind}{label}: {colored_value}")

    def table(
        self,
        headers: list[str],
        rows: list[list[str]],
        *,
        title: str | None = None,
    ) -> None:
        """Print a formatted table."""
        if self.verbosity == Verbosity.QUIET:
            return
        if self.format == OutputFormat.JSON:
            data = [dict(zip(headers, row)) for row in rows]
            self._json_output({"type": "table", "title": title, "data": data})
            return

        # Calculate column widths
        col_widths = [len(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                if i < len(col_widths):
                    col_widths[i] = max(col_widths[i], len(str(cell)))

        # Build separator
        separator = "─┼─".join("─" * w for w in col_widths)

        # Print title
        if title:
            self._write("")
            self.print(title, bold=True)
            self._write(f"{'─' * len(separator)}")

        # Print header
        header_line = " │ ".join(
            self._colorize(h.ljust(col_widths[i]), _Colors.BOLD)
            for i, h in enumerate(headers)
        )
        self._write(f" {header_line} ")
        self._write(f" {separator} ")

        # Print rows
        for row in rows:
            cells = []
            for i, cell in enumerate(row):
                text = str(cell).ljust(col_widths[i]) if i < len(col_widths) else str(cell)
                cells.append(text)
            self._write(f" {' │ '.join(cells)} ")

    def key_value(
        self,
        data: dict[str, Any],
        *,
        title: str | None = None,
        indent: int = 0,
    ) -> None:
        """Print key-value pairs."""
        if self.verbosity == Verbosity.QUIET:
            return
        if self.format == OutputFormat.JSON:
            self._json_output({"type": "key_value", "title": title, "data": data})
            return

        prefix = "  " * indent
        if title:
            self._write(f"\n{prefix}{self._colorize(title, _Colors.BOLD)}")

        max_key_len = max(len(str(k)) for k in data) if data else 0
        for key, value in data.items():
            colored_key = self._colorize(str(key).ljust(max_key_len), _Colors.CYAN)
            self._write(f"{prefix}  {colored_key}  {_SYMBOLS['arrow']}  {value}")

    def list_items(
        self,
        items: list[str],
        *,
        title: str | None = None,
        bullet: str = "•",
        indent: int = 0,
    ) -> None:
        """Print a list of items."""
        if self.verbosity == Verbosity.QUIET:
            return
        if self.format == OutputFormat.JSON:
            self._json_output({"type": "list", "title": title, "items": items})
            return

        prefix = "  " * indent
        if title:
            self._write(f"\n{prefix}{self._colorize(title, _Colors.BOLD)}")
        for item in items:
            self._write(f"{prefix}  {self._colorize(bullet, _Colors.DIM)} {item}")

    def progress(self, current: int, total: int, label: str = "") -> None:
        """Print a progress indicator."""
        if self.verbosity == Verbosity.QUIET:
            return
        if self.format == OutputFormat.JSON:
            self._json_output(
                {"type": "progress", "current": current, "total": total, "label": label}
            )
            return

        pct = (current / total * 100) if total > 0 else 0
        bar_width = 30
        filled = int(bar_width * current / total) if total > 0 else 0
        bar = "█" * filled + "░" * (bar_width - filled)
        colored_bar = self._colorize(bar, _Colors.BRIGHT_CYAN)
        label_str = f"{label} " if label else ""
        self._write(f"\r{label_str}[{colored_bar}] {pct:.0f}% ({current}/{total})", end="")

    def progress_done(self) -> None:
        """Finish a progress line."""
        self._write("")

    def header(self, text: str) -> None:
        """Print a section header."""
        if self.verbosity == Verbosity.QUIET:
            return
        if self.format == OutputFormat.JSON:
            self._json_output({"type": "header", "text": text})
            return
        self._write("")
        self._write(self._colorize(f"═══ {text}", _Colors.BOLD + _Colors.BRIGHT_CYAN))

    def subheader(self, text: str) -> None:
        """Print a sub-section header."""
        if self.verbosity == Verbosity.QUIET:
            return
        if self.format == OutputFormat.JSON:
            self._json_output({"type": "subheader", "text": text})
            return
        self._write(self._colorize(f"─── {text}", _Colors.CYAN))

    def divider(self, char: str = "─", width: int = 60) -> None:
        """Print a divider line."""
        if self.verbosity == Verbosity.QUIET:
            return
        self._write(self._colorize(char * width, _Colors.DIM))

    def blank(self, count: int = 1) -> None:
        """Print blank lines."""
        if self.verbosity == Verbosity.QUIET:
            return
        for _ in range(count):
            self._write("")

    def _json_output(self, data: dict[str, Any]) -> None:
        """Output structured JSON."""
        self._write(json.dumps(data, default=str))

    def raw(self, text: str) -> None:
        """Print raw text without any formatting."""
        self._write(text, end="")

    def json_pretty(self, data: Any) -> None:
        """Print pretty-printed JSON."""
        self._write(json.dumps(data, indent=2, default=str))


# ── Global output instance ───────────────────────────────────────────

_output: Output | None = None


def get_output() -> Output:
    """Get the global output instance."""
    global _output
    if _output is None:
        _output = Output()
    return _output


def init_output(
    format: OutputFormat = OutputFormat.COLORED,
    verbosity: Verbosity = Verbosity.NORMAL,
    stream: TextIO | None = None,
) -> Output:
    """Initialize and return the global output instance."""
    global _output
    _output = Output(
        format=format,
        verbosity=verbosity,
        stream=stream or sys.stdout,
    )
    return _output


def reset_output() -> None:
    """Reset the global output instance."""
    global _output
    _output = None
