"""Shell completion generators for Terminal Agent.

Generates shell completion scripts for Bash, Zsh, and Fish.
Install completions with:

    terminal-agent completions bash >> ~/.bashrc
    terminal-agent completions zsh >> ~/.zshrc
    terminal-agent completions fish > ~/.config/fish/completions/terminal-agent.fish
"""

from terminal_agent.cli.completions.bash import generate_bash_completion
from terminal_agent.cli.completions.zsh import generate_zsh_completion
from terminal_agent.cli.completions.fish import generate_fish_completion

__all__ = [
    "generate_bash_completion",
    "generate_zsh_completion",
    "generate_fish_completion",
]
