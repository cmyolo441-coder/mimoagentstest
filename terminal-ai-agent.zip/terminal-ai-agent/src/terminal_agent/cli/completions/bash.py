"""Bash shell completion for Terminal Agent.

Generates a Bash completion script that provides tab-completion
for all commands, subcommands, and options.
"""

from __future__ import annotations


def generate_bash_completion() -> str:
    """Generate Bash completion script.

    Install with:
        terminal-agent completions bash >> ~/.bashrc
        # or
        eval "$(terminal-agent completions bash)"
    """
    return r'''#!/usr/bin/env bash
# Bash completion for terminal-agent
# Install: eval "$(terminal-agent completions bash)"

_terminal_agent_completions() {
    local cur prev commands subcommands
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"

    # Top-level commands
    commands="run chat config sessions history plugins mcp tools models health update export import traces metrics memory completions version"

    # Subcommands for each command
    local config_subcommands="show get set edit validate reset export import profiles use-profile"
    local sessions_subcommands="list show resume delete stats clean export"
    local history_subcommands="list show repeat clear export"
    local plugins_subcommands="list install uninstall enable disable info search create update"
    local mcp_subcommands="list add remove status tools test enable disable"
    local tools_subcommands="list info test enable disable categories"
    local models_subcommands="list providers info test set-default"
    local export_subcommands="session memories traces config all"
    local import_subcommands="memories patterns config session bulk"
    local traces_subcommands="list show replay compare analyze clear"
    local metrics_subcommands="summary llm tools cost performance memory reset"
    local memory_subcommands="stats search list show delete consolidate decay clear export import"

    # Global options
    local global_opts="--verbose --debug --quiet --output-format --no-color --config --provider --model --safety-level --help --version"

    # Find the subcommand
    local subcmd=""
    local i=1
    while [[ $i -lt $COMP_CWORD ]]; do
        local word="${COMP_WORDS[$i]}"
        if [[ "$word" != -* ]]; then
            case "$word" in
                config|sessions|history|plugins|mcp|tools|models|export|import|traces|metrics|memory)
                    subcmd="$word"
                    break
                    ;;
            esac
        fi
        ((i++))
    done

    # Complete options
    if [[ "$cur" == -* ]]; then
        case "$subcmd" in
            "")
                COMPREPLY=( $(compgen -W "$global_opts $commands" -- "$cur") )
                ;;
            config)
                case "${COMP_WORDS[2]}" in
                    show)   COMPREPLY=( $(compgen -W "--global-only --project-only --merged --help" -- "$cur") ;;
                    get)    COMPREPLY=( $(compgen -W "--help" -- "$cur") ;;
                    set)    COMPREPLY=( $(compgen -W "--global --project --help" -- "$cur") ;;
                    edit)   COMPREPLY=( $(compgen -W "--global --project --help" -- "$cur") ;;
                    reset)  COMPREPLY=( $(compgen -W "--yes --global --project --help" -- "$cur") ;;
                    *)      COMPREPLY=( $(compgen -W "$config_subcommands --help" -- "$cur") ;;
                esac
                ;;
            run)
                COMPREPLY=( $(compgen -W "--file --plan-only --no-verify --parallel --timeout --resume --provider --model --temperature --max-tokens --safety-level --confirm-all --dry-run --session-id --max-iterations --max-cost --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            chat)
                COMPREPLY=( $(compgen -W "--system --continue-session --context --max-history --provider --model --temperature --max-tokens --safety-level --confirm-all --dry-run --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            sessions)
                COMPREPLY=( $(compgen -W "$sessions_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            history)
                COMPREPLY=( $(compgen -W "$history_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            plugins)
                COMPREPLY=( $(compgen -W "$plugins_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            mcp)
                COMPREPLY=( $(compgen -W "$mcp_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            tools)
                COMPREPLY=( $(compgen -W "$tools_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            models)
                COMPREPLY=( $(compgen -W "$models_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            export)
                COMPREPLY=( $(compgen -W "$export_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            import)
                COMPREPLY=( $(compgen -W "$import_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            traces)
                COMPREPLY=( $(compgen -W "$traces_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            metrics)
                COMPREPLY=( $(compgen -W "$metrics_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            memory)
                COMPREPLY=( $(compgen -W "$memory_subcommands --verbose --debug --quiet --output-format --no-color --help" -- "$cur") )
                ;;
            *)
                COMPREPLY=( $(compgen -W "$global_opts" -- "$cur") )
                ;;
        esac
        return 0
    fi

    # Complete subcommands
    if [[ -z "$subcmd" ]]; then
        COMPREPLY=( $(compgen -W "$commands" -- "$cur") )
        return 0
    fi

    # Complete sub-subcommands
    case "$subcmd" in
        config)    COMPREPLY=( $(compgen -W "$config_subcommands" -- "$cur") ;;
        sessions)  COMPREPLY=( $(compgen -W "$sessions_subcommands" -- "$cur") ;;
        history)   COMPREPLY=( $(compgen -W "$history_subcommands" -- "$cur") ;;
        plugins)   COMPREPLY=( $(compgen -W "$plugins_subcommands" -- "$cur") ;;
        mcp)       COMPREPLY=( $(compgen -W "$mcp_subcommands" -- "$cur") ;;
        tools)     COMPREPLY=( $(compgen -W "$tools_subcommands" -- "$cur") ;;
        models)    COMPREPLY=( $(compgen -W "$models_subcommands" -- "$cur") ;;
        export)    COMPREPLY=( $(compgen -W "$export_subcommands" -- "$cur") ;;
        import)    COMPREPLY=( $(compgen -W "$import_subcommands" -- "$cur") ;;
        traces)    COMPREPLY=( $(compgen -W "$traces_subcommands" -- "$cur") ;;
        metrics)   COMPREPLY=( $(compgen -W "$metrics_subcommands" -- "$cur") ;;
        memory)    COMPREPLY=( $(compgen -W "$memory_subcommands" -- "$cur") ;;
    esac

    return 0
}

complete -F _terminal_agent_completions terminal-agent
complete -F _terminal_agent_completions ta
'''
