"""Zsh shell completion for Terminal Agent.

Generates a Zsh completion script with context-aware completions
for all commands, subcommands, options, and arguments.
"""

from __future__ import annotations


def generate_zsh_completion() -> str:
    """Generate Zsh completion script.

    Install with:
        terminal-agent completions zsh >> ~/.zshrc
        # or
        eval "$(terminal-agent completions zsh)"
    """
    return r'''#compdef terminal-agent ta
# Zsh completion for terminal-agent
# Install: eval "$(terminal-agent completions zsh)"

_terminal-agent() {
    local -a commands
    local -a config_subcmds sessions_subcmds history_subcmds
    local -a plugins_subcmds mcp_subcmds tools_subcmds models_subcmds
    local -a export_subcmds import_subcmds traces_subcmds metrics_subcmds memory_subcmds

    commands=(
        'run:Start an agent session with a goal'
        'chat:Start an interactive chat session'
        'config:View and edit configuration'
        'sessions:Manage agent sessions'
        'history:View and search command history'
        'plugins:Manage plugins'
        'mcp:Manage MCP server connections'
        'tools:List and inspect available tools'
        'models:List available models and providers'
        'health:Run system health checks'
        'update:Self-update the agent'
        'export:Export session data'
        'import:Import memories and patterns'
        'traces:View execution traces'
        'metrics:View performance metrics'
        'memory:Manage the memory system'
        'completions:Generate shell completion scripts'
        'version:Show version information'
    )

    config_subcmds=(
        'show:Show current configuration'
        'get:Get a configuration value'
        'set:Set a configuration value'
        'edit:Open config in editor'
        'validate:Validate configuration files'
        'reset:Reset configuration to defaults'
        'export:Export configuration to file'
        'import:Import configuration from file'
        'profiles:List configuration profiles'
        'use-profile:Switch to a profile'
    )

    sessions_subcmds=(
        'list:List past sessions'
        'show:Show session details'
        'resume:Resume a session'
        'delete:Delete a session'
        'stats:Show session statistics'
        'clean:Clean up old sessions'
        'export:Export a session'
    )

    history_subcmds=(
        'list:List command history'
        'show:Show history entry details'
        'repeat:Re-run a command from history'
        'clear:Clear command history'
        'export:Export history to file'
    )

    plugins_subcmds=(
        'list:List installed plugins'
        'install:Install a plugin'
        'uninstall:Uninstall a plugin'
        'enable:Enable a plugin'
        'disable:Disable a plugin'
        'info:Show plugin information'
        'search:Search plugin registry'
        'create:Create a new plugin'
        'update:Update plugins'
    )

    mcp_subcmds=(
        'list:List MCP servers'
        'add:Add an MCP server'
        'remove:Remove an MCP server'
        'status:Check server status'
        'tools:List server tools'
        'test:Test connection'
        'enable:Enable a server'
        'disable:Disable a server'
    )

    tools_subcmds=(
        'list:List available tools'
        'info:Show tool information'
        'test:Test a tool'
        'enable:Enable a tool'
        'disable:Disable a tool'
        'categories:List tool categories'
    )

    models_subcmds=(
        'list:List available models'
        'providers:List LLM providers'
        'info:Show model information'
        'test:Test a model'
        'set-default:Set default model'
    )

    export_subcmds=(
        'session:Export a session'
        'memories:Export memories'
        'traces:Export traces'
        'config:Export configuration'
        'all:Export all data'
    )

    import_subcmds=(
        'memories:Import memories'
        'patterns:Import patterns'
        'config:Import configuration'
        'session:Import a session'
        'bulk:Import from archive'
    )

    traces_subcmds=(
        'list:List traces'
        'show:Show trace details'
        'replay:Replay a trace'
        'compare:Compare two traces'
        'analyze:Analyze traces'
        'clear:Clear traces'
    )

    metrics_subcmds=(
        'summary:Show metrics summary'
        'llm:Show LLM metrics'
        'tools:Show tool metrics'
        'cost:Show cost metrics'
        'performance:Show performance metrics'
        'memory:Show memory metrics'
        'reset:Reset metrics'
    )

    memory_subcmds=(
        'stats:Show memory statistics'
        'search:Search memories'
        'list:List memories'
        'show:Show memory details'
        'delete:Delete a memory'
        'consolidate:Consolidate memories'
        'decay:Apply memory decay'
        'clear:Clear memories'
        'export:Export memories'
        'import:Import memories'
    )

    _arguments -C \
        '(-h --help)'{-h,--help}'[Show help message]' \
        '(-V --version)'{-V,--version}'[Show version]' \
        '(-v --verbose)'{-v,--verbose}'[Enable verbose output]' \
        '(-q --quiet)'{-q,--quiet}'[Suppress output except errors]' \
        '--debug[Enable debug output]' \
        '(-o --output-format)'{-o,--output-format}'[Output format]:format:(colored structured quiet json)' \
        '--no-color[Disable colored output]' \
        '(-c --config)'{-c,--config}'[Config file path]:file:_files' \
        '(-p --provider)'{-p,--provider}'[LLM provider]:provider:(openai anthropic google ollama deepseek groq together cohere custom)' \
        '(-m --model)'{-m,--model}'[LLM model]:model:' \
        '(-s --safety-level)'{-s,--safety-level}'[Safety level]:level:(0 1 2 3 4 5)' \
        '1:command:->command' \
        '*::arg:->args'

    case $state in
        command)
            _describe -t commands 'terminal-agent command' commands
            ;;
        args)
            case $words[1] in
                config)
                    _describe -t commands 'config subcommand' config_subcmds
                    ;;
                sessions)
                    _describe -t commands 'sessions subcommand' sessions_subcmds
                    ;;
                history)
                    _describe -t commands 'history subcommand' history_subcmds
                    ;;
                plugins)
                    _describe -t commands 'plugins subcommand' plugins_subcmds
                    ;;
                mcp)
                    _describe -t commands 'mcp subcommand' mcp_subcmds
                    ;;
                tools)
                    _describe -t commands 'tools subcommand' tools_subcmds
                    ;;
                models)
                    _describe -t commands 'models subcommand' models_subcmds
                    ;;
                export)
                    _describe -t commands 'export subcommand' export_subcmds
                    ;;
                import)
                    _describe -t commands 'import subcommand' import_subcmds
                    ;;
                traces)
                    _describe -t commands 'traces subcommand' traces_subcmds
                    ;;
                metrics)
                    _describe -t commands 'metrics subcommand' metrics_subcmds
                    ;;
                memory)
                    _describe -t commands 'memory subcommand' memory_subcmds
                    ;;
                run)
                    _arguments \
                        '(-f --file)'{-f,--file}'[Read goal from file]:file:_files' \
                        '--plan-only[Generate plan without executing]' \
                        '--no-verify[Skip verification]' \
                        '--parallel[Enable parallel execution]' \
                        '--timeout[Max execution time]:duration:' \
                        '--resume[Resume session]:session-id:' \
                        '*:goal:'
                    ;;
                chat)
                    _arguments \
                        '(-S --system)'{-S,--system}'[System prompt]:prompt:' \
                        '--continue-session[Continue session]:session-id:' \
                        '--context[Context files]:file:_files' \
                        '--max-history[Max history turns]:count:'
                    ;;
                completions)
                    _arguments \
                        '1:shell:(bash zsh fish)'
                    ;;
            esac
            ;;
    esac
}

_terminal-agent "$@"
'''
