"""Fish shell completion for Terminal Agent.

Generates a Fish completion script with full support for
subcommands, options, and contextual completions.
"""

from __future__ import annotations


def generate_fish_completion() -> str:
    """Generate Fish completion script.

    Install with:
        terminal-agent completions fish > ~/.config/fish/completions/terminal-agent.fish
    """
    return r'''# Fish completion for terminal-agent
# Install: terminal-agent completions fish > ~/.config/fish/completions/terminal-agent.fish

# ── Disable file completions by default ──────────────────────────────
complete -c terminal-agent -f
complete -c ta -f

# ── Global options ───────────────────────────────────────────────────
complete -c terminal-agent -l help -d 'Show help message'
complete -c terminal-agent -l version -d 'Show version'
complete -c terminal-agent -s v -l verbose -d 'Enable verbose output'
complete -c terminal-agent -l debug -d 'Enable debug output'
complete -c terminal-agent -s q -l quiet -d 'Suppress output except errors'
complete -c terminal-agent -s o -l output-format -d 'Output format' -xa 'colored structured quiet json'
complete -c terminal-agent -l no-color -d 'Disable colored output'
complete -c terminal-agent -s c -l config -d 'Config file path' -r
complete -c terminal-agent -s p -l provider -d 'LLM provider' -xa 'openai anthropic google ollama deepseek groq together cohere litellm azure bedrock custom'
complete -c terminal-agent -s m -l model -d 'LLM model' -r
complete -c terminal-agent -s s -l safety-level -d 'Safety level (0-5)' -xa '0 1 2 3 4 5'

# ── Top-level commands ───────────────────────────────────────────────
complete -c terminal-agent -n '__fish_use_subcommand' -a run -d 'Start an agent session with a goal'
complete -c terminal-agent -n '__fish_use_subcommand' -a chat -d 'Start an interactive chat session'
complete -c terminal-agent -n '__fish_use_subcommand' -a config -d 'View and edit configuration'
complete -c terminal-agent -n '__fish_use_subcommand' -a sessions -d 'Manage agent sessions'
complete -c terminal-agent -n '__fish_use_subcommand' -a history -d 'View and search command history'
complete -c terminal-agent -n '__fish_use_subcommand' -a plugins -d 'Manage plugins'
complete -c terminal-agent -n '__fish_use_subcommand' -a mcp -d 'Manage MCP server connections'
complete -c terminal-agent -n '__fish_use_subcommand' -a tools -d 'List and inspect available tools'
complete -c terminal-agent -n '__fish_use_subcommand' -a models -d 'List available models and providers'
complete -c terminal-agent -n '__fish_use_subcommand' -a health -d 'Run system health checks'
complete -c terminal-agent -n '__fish_use_subcommand' -a update -d 'Self-update the agent'
complete -c terminal-agent -n '__fish_use_subcommand' -a export -d 'Export session data'
complete -c terminal-agent -n '__fish_use_subcommand' -a import -d 'Import memories and patterns'
complete -c terminal-agent -n '__fish_use_subcommand' -a traces -d 'View execution traces'
complete -c terminal-agent -n '__fish_use_subcommand' -a metrics -d 'View performance metrics'
complete -c terminal-agent -n '__fish_use_subcommand' -a memory -d 'Manage the memory system'
complete -c terminal-agent -n '__fish_use_subcommand' -a completions -d 'Generate shell completions'

# ── run command ──────────────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -s f -l file -d 'Read goal from file' -r
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -l plan-only -d 'Generate plan without executing'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -l no-verify -d 'Skip verification steps'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -l parallel -d 'Enable parallel execution'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -l timeout -d 'Max execution time (e.g., 30m, 2h)'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -l resume -d 'Resume session by ID' -r
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -l confirm-all -d 'Confirm all actions'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -l dry-run -d 'Show what would be done'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -l session-id -d 'Session ID' -r
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -l max-iterations -d 'Max loop iterations' -r
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -l max-cost -d 'Max cost in USD' -r

# ── chat command ─────────────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from chat' -s S -l system -d 'Custom system prompt' -r
complete -c terminal-agent -n '__fish_seen_subcommand_from chat' -l continue-session -d 'Continue session by ID' -r
complete -c terminal-agent -n '__fish_seen_subcommand_from chat' -l context -d 'Context files' -r
complete -c terminal-agent -n '__fish_seen_subcommand_from chat' -l max-history -d 'Max conversation turns' -r

# ── config subcommands ───────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a show -d 'Show current configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a get -d 'Get a configuration value'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a set -d 'Set a configuration value'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a edit -d 'Open config in editor'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a validate -d 'Validate configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a reset -d 'Reset to defaults'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a export -d 'Export configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a import -d 'Import configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a profiles -d 'List profiles'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a use-profile -d 'Switch profile'

# ── sessions subcommands ─────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from sessions' -a list -d 'List past sessions'
complete -c terminal-agent -n '__fish_seen_subcommand_from sessions' -a show -d 'Show session details'
complete -c terminal-agent -n '__fish_seen_subcommand_from sessions' -a resume -d 'Resume a session'
complete -c terminal-agent -n '__fish_seen_subcommand_from sessions' -a delete -d 'Delete a session'
complete -c terminal-agent -n '__fish_seen_subcommand_from sessions' -a stats -d 'Session statistics'
complete -c terminal-agent -n '__fish_seen_subcommand_from sessions' -a clean -d 'Clean old sessions'
complete -c terminal-agent -n '__fish_seen_subcommand_from sessions' -a export -d 'Export a session'

# ── history subcommands ──────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from history' -a list -d 'List command history'
complete -c terminal-agent -n '__fish_seen_subcommand_from history' -a show -d 'Show entry details'
complete -c terminal-agent -n '__fish_seen_subcommand_from history' -a repeat -d 'Re-run a command'
complete -c terminal-agent -n '__fish_seen_subcommand_from history' -a clear -d 'Clear history'
complete -c terminal-agent -n '__fish_seen_subcommand_from history' -a export -d 'Export history'

# ── plugins subcommands ──────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from plugins' -a list -d 'List installed plugins'
complete -c terminal-agent -n '__fish_seen_subcommand_from plugins' -a install -d 'Install a plugin'
complete -c terminal-agent -n '__fish_seen_subcommand_from plugins' -a uninstall -d 'Uninstall a plugin'
complete -c terminal-agent -n '__fish_seen_subcommand_from plugins' -a enable -d 'Enable a plugin'
complete -c terminal-agent -n '__fish_seen_subcommand_from plugins' -a disable -d 'Disable a plugin'
complete -c terminal-agent -n '__fish_seen_subcommand_from plugins' -a info -d 'Plugin information'
complete -c terminal-agent -n '__fish_seen_subcommand_from plugins' -a search -d 'Search plugins'
complete -c terminal-agent -n '__fish_seen_subcommand_from plugins' -a create -d 'Create a plugin'
complete -c terminal-agent -n '__fish_seen_subcommand_from plugins' -a update -d 'Update plugins'

# ── mcp subcommands ──────────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from mcp' -a list -d 'List MCP servers'
complete -c terminal-agent -n '__fish_seen_subcommand_from mcp' -a add -d 'Add an MCP server'
complete -c terminal-agent -n '__fish_seen_subcommand_from mcp' -a remove -d 'Remove an MCP server'
complete -c terminal-agent -n '__fish_seen_subcommand_from mcp' -a status -d 'Server status'
complete -c terminal-agent -n '__fish_seen_subcommand_from mcp' -a tools -d 'List server tools'
complete -c terminal-agent -n '__fish_seen_subcommand_from mcp' -a test -d 'Test connection'
complete -c terminal-agent -n '__fish_seen_subcommand_from mcp' -a enable -d 'Enable a server'
complete -c terminal-agent -n '__fish_seen_subcommand_from mcp' -a disable -d 'Disable a server'

# ── tools subcommands ────────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from tools' -a list -d 'List available tools'
complete -c terminal-agent -n '__fish_seen_subcommand_from tools' -a info -d 'Tool information'
complete -c terminal-agent -n '__fish_seen_subcommand_from tools' -a test -d 'Test a tool'
complete -c terminal-agent -n '__fish_seen_subcommand_from tools' -a enable -d 'Enable a tool'
complete -c terminal-agent -n '__fish_seen_subcommand_from tools' -a disable -d 'Disable a tool'
complete -c terminal-agent -n '__fish_seen_subcommand_from tools' -a categories -d 'List categories'

# ── models subcommands ───────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from models' -a list -d 'List models'
complete -c terminal-agent -n '__fish_seen_subcommand_from models' -a providers -d 'List providers'
complete -c terminal-agent -n '__fish_seen_subcommand_from models' -a info -d 'Model information'
complete -c terminal-agent -n '__fish_seen_subcommand_from models' -a test -d 'Test a model'
complete -c terminal-agent -n '__fish_seen_subcommand_from models' -a set-default -d 'Set default model'

# ── export subcommands ───────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from export' -a session -d 'Export a session'
complete -c terminal-agent -n '__fish_seen_subcommand_from export' -a memories -d 'Export memories'
complete -c terminal-agent -n '__fish_seen_subcommand_from export' -a traces -d 'Export traces'
complete -c terminal-agent -n '__fish_seen_subcommand_from export' -a config -d 'Export configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from export' -a all -d 'Export all data'

# ── import subcommands ───────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from import' -a memories -d 'Import memories'
complete -c terminal-agent -n '__fish_seen_subcommand_from import' -a patterns -d 'Import patterns'
complete -c terminal-agent -n '__fish_seen_subcommand_from import' -a config -d 'Import configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from import' -a session -d 'Import a session'
complete -c terminal-agent -n '__fish_seen_subcommand_from import' -a bulk -d 'Import from archive'

# ── traces subcommands ───────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from traces' -a list -d 'List traces'
complete -c terminal-agent -n '__fish_seen_subcommand_from traces' -a show -d 'Show trace details'
complete -c terminal-agent -n '__fish_seen_subcommand_from traces' -a replay -d 'Replay a trace'
complete -c terminal-agent -n '__fish_seen_subcommand_from traces' -a compare -d 'Compare traces'
complete -c terminal-agent -n '__fish_seen_subcommand_from traces' -a analyze -d 'Analyze traces'
complete -c terminal-agent -n '__fish_seen_subcommand_from traces' -a clear -d 'Clear traces'

# ── metrics subcommands ──────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from metrics' -a summary -d 'Metrics summary'
complete -c terminal-agent -n '__fish_seen_subcommand_from metrics' -a llm -d 'LLM metrics'
complete -c terminal-agent -n '__fish_seen_subcommand_from metrics' -a tools -d 'Tool metrics'
complete -c terminal-agent -n '__fish_seen_subcommand_from metrics' -a cost -d 'Cost metrics'
complete -c terminal-agent -n '__fish_seen_subcommand_from metrics' -a performance -d 'Performance metrics'
complete -c terminal-agent -n '__fish_seen_subcommand_from metrics' -a memory -d 'Memory metrics'
complete -c terminal-agent -n '__fish_seen_subcommand_from metrics' -a reset -d 'Reset metrics'

# ── memory subcommands ───────────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from memory' -a stats -d 'Memory statistics'
complete -c terminal-agent -n '__fish_seen_subcommand_from memory' -a search -d 'Search memories'
complete -c terminal-agent -n '__fish_seen_subcommand_from memory' -a list -d 'List memories'
complete -c terminal-agent -n '__fish_seen_subcommand_from memory' -a show -d 'Show memory details'
complete -c terminal-agent -n '__fish_seen_subcommand_from memory' -a delete -d 'Delete a memory'
complete -c terminal-agent -n '__fish_seen_subcommand_from memory' -a consolidate -d 'Consolidate memories'
complete -c terminal-agent -n '__fish_seen_subcommand_from memory' -a decay -d 'Apply memory decay'
complete -c terminal-agent -n '__fish_seen_subcommand_from memory' -a clear -d 'Clear memories'
complete -c terminal-agent -n '__fish_seen_subcommand_from memory' -a export -d 'Export memories'
complete -c terminal-agent -n '__fish_seen_subcommand_from memory' -a import -d 'Import memories'

# ── completions subcommand ───────────────────────────────────────────
complete -c terminal-agent -n '__fish_seen_subcommand_from completions' -a bash -d 'Bash completions'
complete -c terminal-agent -n '__fish_seen_subcommand_from completions' -a zsh -d 'Zsh completions'
complete -c terminal-agent -n '__fish_seen_subcommand_from completions' -a fish -d 'Fish completions'

# ── Alias completions ────────────────────────────────────────────────
complete -c ta -w terminal-agent
'''
