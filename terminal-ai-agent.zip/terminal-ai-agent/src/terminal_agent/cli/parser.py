"""Argument parser utilities for Terminal Agent CLI.

Provides shared argument validation, option type conversion,
and common argument definitions used across all CLI commands.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import click

from terminal_agent.constants import (
    DEFAULT_LLM_MODEL,
    DEFAULT_LLM_PROVIDER,
    DEFAULT_MAX_COST_PER_TASK,
    DEFAULT_MAX_ITERATIONS,
    DEFAULT_SAFETY_LEVEL,
    MAX_SAFETY_LEVEL,
)
from terminal_agent.types import SafetyLevel


# ── Shared Click options ─────────────────────────────────────────────

def common_options(f: Any) -> Any:
    """Decorator that adds common CLI options to a command."""
    f = click.option(
        "--verbose", "-v",
        is_flag=True,
        default=False,
        help="Enable verbose output.",
    )(f)
    f = click.option(
        "--debug",
        is_flag=True,
        default=False,
        help="Enable debug output with detailed tracing.",
    )(f)
    f = click.option(
        "--quiet", "-q",
        is_flag=True,
        default=False,
        help="Suppress all output except errors.",
    )(f)
    f = click.option(
        "--output-format", "-o",
        type=click.Choice(["colored", "structured", "quiet", "json"], case_sensitive=False),
        default=None,
        help="Output format (default: colored for TTY, structured otherwise).",
    )(f)
    f = click.option(
        "--no-color",
        is_flag=True,
        default=False,
        help="Disable colored output.",
    )(f)
    return f


def llm_options(f: Any) -> Any:
    """Decorator that adds LLM-related CLI options."""
    f = click.option(
        "--provider", "-p",
        type=str,
        default=None,
        help=f"LLM provider (default: {DEFAULT_LLM_PROVIDER}).",
        envvar="TA_PROVIDER",
    )(f)
    f = click.option(
        "--model", "-m",
        type=str,
        default=None,
        help=f"LLM model name (default: {DEFAULT_LLM_MODEL}).",
        envvar="TA_MODEL",
    )(f)
    f = click.option(
        "--temperature", "-t",
        type=float,
        default=None,
        help="LLM temperature (0.0-2.0).",
        envvar="TA_TEMPERATURE",
    )(f)
    f = click.option(
        "--max-tokens",
        type=int,
        default=None,
        help="Maximum tokens for LLM response.",
        envvar="TA_MAX_TOKENS",
    )(f)
    return f


def safety_options(f: Any) -> Any:
    """Decorator that adds safety-related CLI options."""
    f = click.option(
        "--safety-level", "-s",
        type=click.IntRange(0, MAX_SAFETY_LEVEL),
        default=None,
        help=f"Safety level 0-{MAX_SAFETY_LEVEL} (default: {DEFAULT_SAFETY_LEVEL}).",
    )(f)
    f = click.option(
        "--confirm-all",
        is_flag=True,
        default=False,
        help="Require confirmation for all actions.",
    )(f)
    f = click.option(
        "--dry-run",
        is_flag=True,
        default=False,
        help="Show what would be done without executing.",
    )(f)
    return f


def session_options(f: Any) -> Any:
    """Decorator that adds session-related CLI options."""
    f = click.option(
        "--session-id",
        type=str,
        default=None,
        help="Resume an existing session by ID.",
    )(f)
    f = click.option(
        "--max-iterations",
        type=int,
        default=None,
        help=f"Maximum agent loop iterations (default: {DEFAULT_MAX_ITERATIONS}).",
    )(f)
    f = click.option(
        "--max-cost",
        type=float,
        default=None,
        help=f"Maximum cost per task in USD (default: {DEFAULT_MAX_COST_PER_TASK}).",
    )(f)
    return f


# ── Validation helpers ────────────────────────────────────────────────

def validate_goal(goal: str) -> str:
    """Validate and clean a goal string."""
    goal = goal.strip()
    if not goal:
        raise click.BadParameter("Goal cannot be empty.")
    if len(goal) > 50_000:
        raise click.BadParameter("Goal is too long (max 50,000 characters).")
    return goal


def validate_file_path(path: str, must_exist: bool = True) -> Path:
    """Validate a file path."""
    p = Path(path).expanduser().resolve()
    if must_exist and not p.exists():
        raise click.BadParameter(f"File not found: {p}")
    if must_exist and not p.is_file():
        raise click.BadParameter(f"Not a file: {p}")
    return p


def validate_directory(path: str, must_exist: bool = True) -> Path:
    """Validate a directory path."""
    p = Path(path).expanduser().resolve()
    if must_exist and not p.exists():
        raise click.BadParameter(f"Directory not found: {p}")
    if must_exist and not p.is_dir():
        raise click.BadParameter(f"Not a directory: {p}")
    return p


def validate_safety_level(level: int) -> SafetyLevel:
    """Validate and convert safety level."""
    try:
        return SafetyLevel(level)
    except ValueError:
        raise click.BadParameter(
            f"Invalid safety level: {level}. Must be 0-{MAX_SAFETY_LEVEL}."
        )


def read_goal_from_stdin() -> str | None:
    """Read a goal from stdin if data is being piped."""
    if not os.isatty(0):
        data = click.get_text_stream("stdin").read()
        if data and data.strip():
            return data.strip()
    return None


def read_goal_from_file(file_path: str) -> str:
    """Read a goal from a file."""
    path = validate_file_path(file_path)
    try:
        content = path.read_text(encoding="utf-8").strip()
        if not content:
            raise click.BadParameter(f"File is empty: {path}")
        return content
    except UnicodeDecodeError:
        raise click.BadParameter(f"File is not valid UTF-8: {path}")


def merge_options(ctx: click.Context, **kwargs: Any) -> dict[str, Any]:
    """Merge CLI options with context defaults, filtering out None values."""
    merged = {}
    # Get defaults from context (set by main group)
    ctx_defaults = ctx.obj or {}
    for key, value in kwargs.items():
        if value is not None:
            merged[key] = value
        elif key in ctx_defaults:
            merged[key] = ctx_defaults[key]
    return merged


# ── Click parameter types ─────────────────────────────────────────────

class DurationParamType(click.ParamType):
    """Click parameter type for duration strings like '5m', '1h', '30s'."""
    name = "duration"

    def convert(self, value: str, param: click.Parameter | None, ctx: click.Context | None) -> float:
        """Convert a duration string to seconds."""
        if isinstance(value, (int, float)):
            return float(value)

        value = value.strip().lower()
        multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400}

        if not value:
            self.fail("Duration cannot be empty.", param, ctx)

        # Check for bare number (assume seconds)
        try:
            return float(value)
        except ValueError:
            pass

        suffix = value[-1]
        if suffix not in multipliers:
            self.fail(
                f"Invalid duration format: '{value}'. Use a number followed by s/m/h/d.",
                param,
                ctx,
            )

        try:
            number = float(value[:-1])
            if number < 0:
                self.fail("Duration cannot be negative.", param, ctx)
            return number * multipliers[suffix]
        except ValueError:
            self.fail(f"Invalid duration: '{value}'.", param, ctx)


DURATION = DurationParamType()


class KeyValueParamType(click.ParamType):
    """Click parameter type for key=value pairs."""
    name = "key=value"

    def convert(
        self, value: str, param: click.Parameter | None, ctx: click.Context | None
    ) -> tuple[str, str]:
        """Convert a key=value string."""
        if "=" not in value:
            self.fail(f"Invalid format: '{value}'. Expected key=value.", param, ctx)
        key, _, val = value.partition("=")
        key = key.strip()
        val = val.strip()
        if not key:
            self.fail("Key cannot be empty.", param, ctx)
        return (key, val)


KEY_VALUE = KeyValueParamType()
