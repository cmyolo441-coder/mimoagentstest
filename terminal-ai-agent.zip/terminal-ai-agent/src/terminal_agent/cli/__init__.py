"""CLI Layer — Command-line interface for Terminal Agent.

Provides the user-facing command-line interface built on Click.
Handles argument parsing, subcommand dispatch, output formatting,
and shell completion generation.
"""

from terminal_agent.cli.app import main

__all__ = ["main"]
