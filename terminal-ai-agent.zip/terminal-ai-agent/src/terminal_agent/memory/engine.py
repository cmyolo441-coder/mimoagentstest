"""Main memory engine coordinating all three tiers.

This module provides the central MemoryEngine class that orchestrates
short-term, working, and long-term memory subsystems. It handles the
full lifecycle: store → retrieve → consolidate → decay.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.constants import (
DEFAULT_CONSOLIDATION_INTERVAL,
DEFAULT_DECAY_RATE,
DEFAULT_LONG_TERM_MEMORIES_PER_QUERY,
DEFAULT_MAX_MEMORY_SIZE,
DEFAULT_SHORT_TERM_TURNS,
DEFAULT_WORKING_MEMORY_FILES,
)
from terminal_agent.exceptions import MemoryError, MemoryRecallError, MemoryStoreError
from terminal_agent.memory.consolidator import MemoryConsolidator
from terminal_agent.memory.decay import MemoryDecay
from terminal_agent.memory.embedder import MemoryEmbedder
from terminal_agent.memory.long_term import LongTermMemory
from terminal_agent.memory.retriever import MemoryRetriever
from terminal_agent.memory.short_term import ShortTermMemory
from terminal_agent.memory.working_memory import WorkingMemory
from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory")


@dataclass
class MemoryEngineConfig:
    """Configuration for the memory engine."""

    # Short-term settings
    max_short_term_turns: int = DEFAULT_SHORT_TERM_TURNS

    # Working memory settings
    max_working_files: int = DEFAULT_WORKING_MEMORY_FILES

    # Long-term settings
    max_memories: int = DEFAULT_MAX_MEMORY_SIZE
    memories_per_query: int = DEFAULT_LONG_TERM_MEMORIES_PER_QUERY

    # Consolidation
    consolidation_interval: float = DEFAULT_CONSOLIDATION_INTERVAL

    # Decay
    decay_rate: float = DEFAULT_DECAY_RATE

    # Embedding
    embedding_model: str = "text-embedding-3-small"
    embedding_dimensions: int = 1536

    # Vector store backend
    vector_backend: str = "chroma"
    vector_store_path: str | None = None


@dataclass
class MemoryStats:
    """Statistics about memory usage."""

    short_term_count: int = 0
    short_term_tokens: int = 0
    working_files_count: int = 0
    working_scratch_size: int = 0
    long_term_count: int = 0
    categories: dict[str, int] = field(default_factory=dict)
    last_consolidation: float = 0.0
    last_decay: float = 0.0
    total_recalls: int = 0
    total_stores: int = 0
    hit_rate: float = 0.0


class MemoryEngine:
    """Coordinates the three-tier memory system.

    This is the main entry point for all memory operations. It delegates
    to the appropriate tier and manages cross-tier operations like
    consolidation, decay, and conflict resolution.

    Usage::

        config = MemoryEngineConfig(vector_backend="chroma")
        engine = MemoryEngine(config)

        # Store a conversation turn
        engine.store_turn("user", "How do I sort a list in Python?")

        # Store a long-term memory
        engine.store_memory("Use sorted() for non-destructive sorting", MemoryCategory.PATTERN)

        # Recall relevant memories
        memories = engine.recall("sorting lists python")
    """

    def __init__(self, config: MemoryEngineConfig | None = None) -> None:
        self._config = config or MemoryEngineConfig()
        self._stats = MemoryStats()

        # Initialize tiers
        self._short_term = ShortTermMemory(
            max_turns=self._config.max_short_term_turns
        )
        self._working = WorkingMemory(
            max_files=self._config.max_working_files
        )
        self._long_term = LongTermMemory(
            max_memories=self._config.max_memories,
            vector_backend=self._config.vector_backend,
            vector_store_path=self._config.vector_store_path,
            embedding_model=self._config.embedding_model,
            embedding_dimensions=self._config.embedding_dimensions,
        )

        # Support subsystems
        self._consolidator = MemoryConsolidator(
            interval=self._config.consolidation_interval
        )
        self._decay = MemoryDecay(rate=self._config.decay_rate)
        self._retriever = MemoryRetriever(
            long_term=self._long_term,
            short_term=self._short_term,
            memories_per_query=self._config.memories_per_query,
        )

        self._last_consolidation: float = time.time()
        self._last_decay: float = time.time()

        logger.info("MemoryEngine initialized with %s backend", self._config.vector_backend)

    # ── Short-Term Operations ────────────────────────────────────────

    def store_turn(self, role: str, content: str, metadata: dict[str, Any] | None = None) -> None:
        """Store a conversation turn in short-term memory.

        Args:
            role: The role of the speaker ("user", "assistant", "system").
            content: The content of the turn.
            metadata: Optional metadata for the turn.
        """
        try:
            self._short_term.add_turn(role, content, metadata or {})
            self._stats.total_stores += 1
            logger.debug("Stored turn: role=%s, len=%d", role, len(content))
        except Exception as e:
            raise MemoryStoreError(f"Failed to store turn: {e}") from e

    def get_conversation_history(self, max_turns: int | None = None) -> list[dict[str, Any]]:
        """Get recent conversation history.

        Args:
            max_turns: Maximum number of turns to return (default: all).

        Returns:
            List of turn dicts with 'role', 'content', 'timestamp' keys.
        """
        return self._short_term.get_turns(max_turns)

    def get_history_as_messages(self, max_turns: int | None = None) -> list[dict[str, str]]:
        """Get conversation history as LLM-compatible messages.

        Returns:
            List of dicts with 'role' and 'content' keys.
        """
        return self._short_term.get_as_messages(max_turns)

    # ── Working Memory Operations ────────────────────────────────────

    def store_working(self, key: str, value: Any, ttl: float | None = None) -> None:
        """Store a value in working memory.

        Args:
            key: Identifier for the data.
            value: Data to store (any serializable type).
            ttl: Time-to-live in seconds (None = session-scoped).
        """
        self._working.set(key, value, ttl)
        logger.debug("Working memory set: %s", key)

    def get_working(self, key: str, default: Any = None) -> Any:
        """Retrieve a value from working memory.

        Args:
            key: Identifier for the data.
            default: Default value if key not found.

        Returns:
            The stored value or default.
        """
        return self._working.get(key, default)

    def store_file_content(self, path: str, content: str) -> None:
        """Store file content in working memory for quick access."""
        self._working.add_file(path, content)

    def get_file_content(self, path: str) -> str | None:
        """Retrieve file content from working memory."""
        return self._working.get_file(path)

    def get_active_files(self) -> list[str]:
        """Get list of files currently in working memory."""
        return self._working.get_file_list()

    def store_scratch(self, key: str, value: str) -> None:
        """Store a scratch-pad note (temporary, ephemeral)."""
        self._working.set_scratch(key, value)

    def get_scratch(self, key: str) -> str | None:
        """Retrieve a scratch-pad note."""
        return self._working.get_scratch(key)

    # ── Long-Term Operations ─────────────────────────────────────────

    def store_memory(
        self,
        content: str,
        category: MemoryCategory = MemoryCategory.TASK,
        metadata: dict[str, Any] | None = None,
        source_session_id: str | None = None,
    ) -> Memory:
        """Store a memory in long-term storage with vector embedding.

        Args:
            content: The memory content text.
            category: The memory category.
            metadata: Additional metadata.
            source_session_id: ID of the originating session.

        Returns:
            The stored Memory object.
        """
        try:
            memory = self._long_term.store(
                content=content,
                category=category,
                metadata=metadata or {},
                source_session_id=source_session_id,
            )
            self._stats.total_stores += 1
            self._stats.long_term_count = self._long_term.count()
            logger.info("Stored long-term memory: category=%s, id=%s", category.value, memory.id)
            return memory
        except Exception as e:
            raise MemoryStoreError(f"Failed to store memory: {e}") from e

    def recall(
        self,
        query: str,
        categories: list[MemoryCategory] | None = None,
        limit: int | None = None,
    ) -> list[Memory]:
        """Recall memories relevant to a query.

        Searches long-term memory using semantic similarity, then
        applies category filtering and recency boosting.

        Args:
            query: The search query.
            categories: Optional filter by categories.
            limit: Maximum memories to return.

        Returns:
            List of relevant memories, sorted by relevance.
        """
        try:
            limit = limit or self._config.memories_per_query
            memories = self._retriever.retrieve(
                query=query,
                categories=categories,
                limit=limit,
            )
            self._stats.total_recalls += 1
            if memories:
                hit_count = sum(1 for m in memories if m.relevance_score > 0.5)
                self._stats.hit_rate = (
                    self._stats.hit_rate * 0.9 + (hit_count / len(memories)) * 0.1
                )
            logger.debug("Recalled %d memories for query: %s", len(memories), query[:80])
            return memories
        except Exception as e:
            raise MemoryRecallError(f"Failed to recall memories: {e}") from e

    def update_memory(self, memory_id: str, content: str | None = None, metadata: dict[str, Any] | None = None) -> Memory | None:
        """Update an existing long-term memory.

        Args:
            memory_id: ID of the memory to update.
            content: New content (if changing).
            metadata: New metadata (if changing).

        Returns:
            Updated Memory or None if not found.
        """
        return self._long_term.update(memory_id, content=content, metadata=metadata)

    def delete_memory(self, memory_id: str) -> bool:
        """Delete a long-term memory.

        Args:
            memory_id: ID of the memory to delete.

        Returns:
            True if deleted, False if not found.
        """
        result = self._long_term.delete(memory_id)
        if result:
            self._stats.long_term_count = self._long_term.count()
        return result

    def list_memories(
        self,
        category: MemoryCategory | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Memory]:
        """List long-term memories, optionally filtered by category."""
        return self._long_term.list_memories(category=category, limit=limit, offset=offset)

    # ── Cross-Tier Operations ────────────────────────────────────────

    def consolidate(self, force: bool = False) -> dict[str, Any]:
        """Run memory consolidation.

        Merges similar memories, summarizes short-term into long-term,
        and cleans up stale entries.

        Args:
            force: Force consolidation even if interval hasn't elapsed.

        Returns:
            Consolidation report with counts and actions taken.
        """
        now = time.time()
        if not force and (now - self._last_consolidation) < self._config.consolidation_interval:
            return {"skipped": True, "reason": "interval not elapsed"}

        report = self._consolidator.consolidate(
            short_term=self._short_term,
            long_term=self._long_term,
            working=self._working,
        )
        self._last_consolidation = now
        self._stats.last_consolidation = now
        self._stats.long_term_count = self._long_term.count()
        logger.info("Consolidation complete: %s", report)
        return report

    def apply_decay(self, force: bool = False) -> dict[str, Any]:
        """Apply relevance decay to long-term memories.

        Reduces relevance scores of memories that haven't been accessed
        recently, so frequently-used memories surface first.

        Args:
            force: Force decay even if interval hasn't elapsed.

        Returns:
            Decay report with counts.
        """
        now = time.time()
        if not force and (now - self._last_decay) < self._config.consolidation_interval:
            return {"skipped": True, "reason": "interval not elapsed"}

        report = self._decay.apply(self._long_term)
        self._last_decay = now
        self._stats.last_decay = now
        logger.info("Decay applied: %s", report)
        return report

    def get_context_for_llm(self, max_memories: int = 5) -> str:
        """Build a memory context string for LLM prompts.

        Combines working memory state and relevant long-term memories
        into a formatted string suitable for inclusion in prompts.

        Args:
            max_memories: Maximum long-term memories to include.

        Returns:
            Formatted context string.
        """
        sections: list[str] = []

        # Active files context
        active_files = self._working.get_file_list()
        if active_files:
            sections.append("## Active Files")
            for path in active_files[:10]:
                content = self._working.get_file(path)
                if content:
                    preview = content[:200] + "..." if len(content) > 200 else content
                    sections.append(f"### {path}\n```\n{preview}\n```")

        # Scratch pad
        scratch = self._working.get_all_scratch()
        if scratch:
            sections.append("## Scratch Pad")
            for key, value in scratch.items():
                sections.append(f"- **{key}**: {value}")

        # Recent long-term memories (use last conversation as query)
        recent_turns = self._short_term.get_turns(3)
        if recent_turns:
            query_parts = [t.get("content", "") for t in recent_turns]
            query = " ".join(query_parts)[-500:]
            memories = self.recall(query, limit=max_memories)
            if memories:
                sections.append("## Relevant Memories")
                for mem in memories:
                    sections.append(f"- [{mem.category.value}] {mem.content}")

        return "\n\n".join(sections) if sections else ""

    def clear_session(self) -> None:
        """Clear session-scoped memory (short-term and working)."""
        self._short_term.clear()
        self._working.clear()
        logger.info("Session memory cleared")

    def get_stats(self) -> MemoryStats:
        """Get current memory statistics."""
        self._stats.short_term_count = self._short_term.count()
        self._stats.short_term_tokens = self._short_term.estimate_tokens()
        self._stats.working_files_count = len(self._working.get_file_list())
        self._stats.working_scratch_size = self._working.scratch_count()
        self._stats.long_term_count = self._long_term.count()
        self._stats.categories = self._long_term.count_by_category()
        return self._stats

    def shutdown(self) -> None:
        """Persist and clean up on shutdown."""
        try:
            # Final consolidation
            self.consolidate(force=True)
            # Persist long-term memory
            self._long_term.persist()
            logger.info("MemoryEngine shut down cleanly")
        except Exception as e:
            logger.error("Error during memory shutdown: %s", e)
