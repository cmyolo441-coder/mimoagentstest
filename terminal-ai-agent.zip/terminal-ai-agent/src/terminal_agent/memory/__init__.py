"""Three-tier memory engine for Terminal Agent.

Memory Tiers:
    - Short-term: Current conversation turns (volatile, fast)
    - Working: Active state, file contents, scratch pad (session-scoped)
    - Long-term: Persistent knowledge with vector embeddings (durable)

The MemoryEngine class coordinates all three tiers and provides a unified
interface for store, recall, consolidate, and decay operations.
"""

from terminal_agent.memory.engine import MemoryEngine
from terminal_agent.memory.short_term import ShortTermMemory
from terminal_agent.memory.working_memory import WorkingMemory
from terminal_agent.memory.long_term import LongTermMemory
from terminal_agent.memory.consolidator import MemoryConsolidator
from terminal_agent.memory.compressor import MemoryCompressor
from terminal_agent.memory.embedder import MemoryEmbedder
from terminal_agent.memory.retriever import MemoryRetriever
from terminal_agent.memory.conflict_resolver import ConflictResolver
from terminal_agent.memory.decay import MemoryDecay

__all__ = [
    "MemoryEngine",
    "ShortTermMemory",
    "WorkingMemory",
    "LongTermMemory",
    "MemoryConsolidator",
    "MemoryCompressor",
    "MemoryEmbedder",
    "MemoryRetriever",
    "ConflictResolver",
    "MemoryDecay",
]
