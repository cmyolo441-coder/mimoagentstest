"""Long-term memory: persistent storage with vector embeddings.

Manages durable memories that survive across sessions. Each memory
is embedded into a vector for semantic search and stored with metadata
for category filtering, recency boosting, and access tracking.
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any

from terminal_agent.exceptions import EmbeddingError, MemoryStoreError, VectorStoreError
from terminal_agent.memory.embedder import MemoryEmbedder
from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.long_term")


class LongTermMemory:
    """Persistent memory store backed by a vector database.

    Each memory is:
        1. Embedded into a vector via the configured embedding model.
        2. Stored in the vector backend with metadata.
        3. Indexed for category filtering and recency access.

    Args:
        max_memories: Maximum memories before consolidation pressure.
        vector_backend: Vector store backend name.
        vector_store_path: Path for local backends (ChromaDB, FAISS).
        embedding_model: Embedding model identifier.
        embedding_dimensions: Embedding vector dimensions.
    """

    def __init__(
        self,
        max_memories: int = 10000,
        vector_backend: str = "chroma",
        vector_store_path: str | None = None,
        embedding_model: str = "text-embedding-3-small",
        embedding_dimensions: int = 1536,
    ) -> None:
        self._max_memories = max_memories
        self._embedder = MemoryEmbedder(
            model=embedding_model,
            dimensions=embedding_dimensions,
        )

        # Lazy-init vector store to avoid import errors when backends aren't installed
        self._vector_backend_name = vector_backend
        self._vector_store_path = vector_store_path
        self._vector_store: Any = None
        self._vector_store_initialized = False

        # In-memory index for fast metadata queries
        self._index: dict[str, Memory] = {}

        logger.info(
            "LongTermMemory initialized: backend=%s, max=%d, model=%s",
            vector_backend, max_memories, embedding_model,
        )

    def _ensure_vector_store(self) -> Any:
        """Lazily initialize the vector store backend."""
        if self._vector_store_initialized:
            return self._vector_store

        from terminal_agent.support.vector_store.manager import VectorStoreManager
        manager = VectorStoreManager()
        self._vector_store = manager.get_backend(
            self._vector_backend_name,
            path=self._vector_store_path,
        )
        self._vector_store_initialized = True
        return self._vector_store

    def store(
        self,
        content: str,
        category: MemoryCategory = MemoryCategory.TASK,
        metadata: dict[str, Any] | None = None,
        source_session_id: str | None = None,
    ) -> Memory:
        """Store a new memory with vector embedding.

        Args:
            content: Memory text content.
            category: Memory category.
            metadata: Additional metadata.
            source_session_id: Originating session ID.

        Returns:
            The stored Memory object.

        Raises:
            MemoryStoreError: If embedding or storage fails.
        """
        memory_id = str(uuid.uuid4())
        now = time.time()

        # Build embedding
        try:
            embedding = self._embedder.embed(content)
        except Exception as e:
            raise EmbeddingError(f"Failed to embed memory: {e}") from e

        # Build metadata for vector store
        vs_metadata = {
            "category": category.value,
            "source_session_id": source_session_id or "",
            "relevance_score": 1.0,
            "access_count": 0,
            "created_at": now,
            "updated_at": now,
            "last_accessed": now,
        }
        if metadata:
            vs_metadata.update({k: str(v) for k, v in metadata.items()})

        # Store in vector backend
        try:
            store = self._ensure_vector_store()
            store.upsert(
                id=memory_id,
                vector=embedding,
                metadata=vs_metadata,
                document=content,
            )
        except Exception as e:
            raise VectorStoreError(f"Failed to store vector: {e}") from e

        # Build Memory object
        memory = Memory(
            id=memory_id,
            category=category,
            content=content,
            embedding_id=memory_id,
            source_session_id=source_session_id,
            relevance_score=1.0,
            access_count=0,
            metadata=metadata or {},
        )

        # Update in-memory index
        self._index[memory_id] = memory

        logger.debug("Stored memory %s (category=%s)", memory_id, category.value)
        return memory

    def search(
        self,
        query_embedding: list[float],
        categories: list[MemoryCategory] | None = None,
        limit: int = 5,
        min_score: float = 0.0,
    ) -> list[Memory]:
        """Search memories by vector similarity.

        Args:
            query_embedding: Pre-computed query embedding vector.
            categories: Optional category filter.
            limit: Maximum results.
            min_score: Minimum similarity score.

        Returns:
            List of matching memories, sorted by relevance.
        """
        try:
            store = self._ensure_vector_store()

            # Build filter
            where_filter = None
            if categories:
                cat_values = [c.value for c in categories]
                if len(cat_values) == 1:
                    where_filter = {"category": cat_values[0]}
                else:
                    where_filter = {"category": {"$in": cat_values}}

            results = store.query(
                vector=query_embedding,
                top_k=limit,
                where=where_filter,
            )

            memories: list[Memory] = []
            for result in results:
                score = result.get("score", 0.0)
                if score < min_score:
                    continue

                memory_id = result.get("id", "")
                metadata = result.get("metadata", {})
                document = result.get("document", "")

                # Update access tracking
                self._touch_memory(memory_id)

                memory = Memory(
                    id=memory_id,
                    category=MemoryCategory(metadata.get("category", "task")),
                    content=document,
                    embedding_id=memory_id,
                    source_session_id=metadata.get("source_session_id") or None,
                    relevance_score=score,
                    access_count=metadata.get("access_count", 0),
                    metadata={k: v for k, v in metadata.items() if k not in (
                        "category", "source_session_id", "relevance_score",
                        "access_count", "created_at", "updated_at", "last_accessed",
                    )},
                )
                memories.append(memory)

            return memories

        except Exception as e:
            logger.error("Vector search failed: %s", e)
            return []

    def get(self, memory_id: str) -> Memory | None:
        """Get a memory by ID."""
        # Check in-memory index first
        if memory_id in self._index:
            return self._index[memory_id]

        # Fall back to vector store
        try:
            store = self._ensure_vector_store()
            results = store.get(ids=[memory_id])
            if results:
                data = results[0]
                metadata = data.get("metadata", {})
                memory = Memory(
                    id=memory_id,
                    category=MemoryCategory(metadata.get("category", "task")),
                    content=data.get("document", ""),
                    embedding_id=memory_id,
                    relevance_score=metadata.get("relevance_score", 1.0),
                    access_count=metadata.get("access_count", 0),
                )
                self._index[memory_id] = memory
                return memory
        except Exception as e:
            logger.error("Failed to get memory %s: %s", memory_id, e)

        return None

    def update(
        self,
        memory_id: str,
        content: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Memory | None:
        """Update an existing memory.

        If content changes, the embedding is recomputed.
        """
        existing = self.get(memory_id)
        if existing is None:
            return None

        now = time.time()
        new_content = content if content is not None else existing.content
        new_metadata = {**existing.metadata, **(metadata or {})}

        # Re-embed if content changed
        embedding: list[float] | None = None
        if content is not None:
            try:
                embedding = self._embedder.embed(new_content)
            except Exception as e:
                raise EmbeddingError(f"Failed to re-embed memory: {e}") from e

        # Update vector store
        try:
            store = self._ensure_vector_store()
            vs_metadata = {
                "category": existing.category.value,
                "source_session_id": existing.source_session_id or "",
                "relevance_score": existing.relevance_score,
                "access_count": existing.access_count,
                "created_at": new_metadata.get("created_at", now),
                "updated_at": now,
                "last_accessed": now,
            }
            vs_metadata.update({k: str(v) for k, v in new_metadata.items() if k not in vs_metadata})

            store.upsert(
                id=memory_id,
                vector=embedding,
                metadata=vs_metadata,
                document=new_content,
            )
        except Exception as e:
            raise VectorStoreError(f"Failed to update vector: {e}") from e

        # Update in-memory object
        updated = Memory(
            id=memory_id,
            category=existing.category,
            content=new_content,
            embedding_id=memory_id,
            source_session_id=existing.source_session_id,
            relevance_score=existing.relevance_score,
            access_count=existing.access_count,
            metadata=new_metadata,
        )
        self._index[memory_id] = updated
        return updated

    def delete(self, memory_id: str) -> bool:
        """Delete a memory by ID."""
        try:
            store = self._ensure_vector_store()
            store.delete(ids=[memory_id])
            self._index.pop(memory_id, None)
            logger.debug("Deleted memory %s", memory_id)
            return True
        except Exception as e:
            logger.error("Failed to delete memory %s: %s", memory_id, e)
            return False

    def list_memories(
        self,
        category: MemoryCategory | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Memory]:
        """List memories from the in-memory index."""
        items = list(self._index.values())
        if category:
            items = [m for m in items if m.category == category]
        # Sort by relevance then recency
        items.sort(key=lambda m: (-m.relevance_score, -m.metadata.get("created_at", 0)))
        return items[offset:offset + limit]

    def count(self) -> int:
        """Total number of stored memories."""
        return len(self._index)

    def count_by_category(self) -> dict[str, int]:
        """Count memories per category."""
        counts: dict[str, int] = {}
        for mem in self._index.values():
            cat = mem.category.value
            counts[cat] = counts.get(cat, 0) + 1
        return counts

    def persist(self) -> None:
        """Ensure all data is persisted to disk."""
        if self._vector_store is not None:
            try:
                if hasattr(self._vector_store, "persist"):
                    self._vector_store.persist()
                logger.info("Long-term memory persisted")
            except Exception as e:
                logger.error("Failed to persist vector store: %s", e)

    def _touch_memory(self, memory_id: str) -> None:
        """Update access tracking for a memory."""
        if memory_id in self._index:
            self._index[memory_id].access_count += 1
        # Also update in vector store metadata
        try:
            store = self._ensure_vector_store()
            store.update_metadata(
                id=memory_id,
                metadata={"access_count": self._index.get(memory_id, Memory()).access_count, "last_accessed": time.time()},
            )
        except Exception:
            pass  # Best-effort

    def get_all_for_consolidation(self, category: MemoryCategory | None = None) -> list[Memory]:
        """Get all memories for consolidation analysis."""
        return self.list_memories(category=category, limit=self._max_memories)

    def batch_update_relevance(self, updates: dict[str, float]) -> int:
        """Batch update relevance scores.

        Args:
            updates: Mapping of memory_id → new relevance score.

        Returns:
            Number of memories updated.
        """
        count = 0
        for memory_id, score in updates.items():
            if memory_id in self._index:
                self._index[memory_id].relevance_score = score
                try:
                    store = self._ensure_vector_store()
                    store.update_metadata(
                        id=memory_id,
                        metadata={"relevance_score": score},
                    )
                except Exception:
                    pass
                count += 1
        return count
