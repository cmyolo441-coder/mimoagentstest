"""Memory consolidation: merge, summarize, and deduplicate.

Periodically runs to:
    1. Summarize evicted short-term turns into long-term memories.
    2. Merge similar long-term memories to reduce duplication.
    3. Promote frequently-accessed working memory items to long-term.
    4. Prune low-relevance memories when the store is near capacity.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.consolidator")


@dataclass
class ConsolidationReport:
    """Report of a consolidation run."""

    turns_summarized: int = 0
    memories_merged: int = 0
    memories_pruned: int = 0
    working_promoted: int = 0
    duration_ms: float = 0.0
    actions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "turns_summarized": self.turns_summarized,
            "memories_merged": self.memories_merged,
            "memories_pruned": self.memories_pruned,
            "working_promoted": self.working_promoted,
            "duration_ms": self.duration_ms,
            "actions": self.actions,
        }


class MemoryConsolidator:
    """Consolidates memories across tiers.

    Runs periodically to move data between tiers, merge duplicates,
    and prune low-value memories.

    Args:
        interval: Minimum seconds between consolidation runs.
        merge_threshold: Cosine similarity threshold for merging.
        prune_threshold: Relevance score below which memories are pruned.
        max_memories: Maximum long-term memories before forced pruning.
    """

    def __init__(
        self,
        interval: float = 3600.0,
        merge_threshold: float = 0.92,
        prune_threshold: float = 0.1,
        max_memories: int = 10000,
    ) -> None:
        self._interval = interval
        self._merge_threshold = merge_threshold
        self._prune_threshold = prune_threshold
        self._max_memories = max_memories
        self._last_run: float = 0.0

    def should_run(self) -> bool:
        """Check if enough time has elapsed for a consolidation run."""
        return (time.time() - self._last_run) >= self._interval

    def consolidate(
        self,
        short_term: Any,
        long_term: Any,
        working: Any,
    ) -> dict[str, Any]:
        """Run a full consolidation pass across all tiers.

        Args:
            short_term: ShortTermMemory instance.
            long_term: LongTermMemory instance.
            working: WorkingMemory instance.

        Returns:
            Consolidation report dict.
        """
        start = time.time()
        report = ConsolidationReport()

        # 1. Summarize evicted short-term turns
        report.turns_summarized = self._summarize_evicted_turns(
            short_term, long_term
        )

        # 2. Merge similar long-term memories
        report.memories_merged = self._merge_similar_memories(long_term)

        # 3. Prune low-relevance memories
        report.memories_pruned = self._prune_low_relevance(long_term)

        # 4. Promote frequently-accessed working items
        report.working_promoted = self._promote_working(working, long_term)

        report.duration_ms = (time.time() - start) * 1000
        self._last_run = time.time()

        logger.info(
            "Consolidation: %d turns summarized, %d merged, %d pruned, %d promoted (%.1fms)",
            report.turns_summarized,
            report.memories_merged,
            report.memories_pruned,
            report.working_promoted,
            report.duration_ms,
        )

        return report.to_dict()

    def _summarize_evicted_turns(self, short_term: Any, long_term: Any) -> int:
        """Summarize evicted short-term turns into long-term memory.

        Takes the evicted turn queue from short-term memory, creates
        a summary, and stores it as a long-term memory.
        """
        evicted = short_term.get_evicted()
        if not evicted:
            return 0

        # Build a conversation summary from evicted turns
        summary_parts: list[str] = []
        for turn in evicted:
            role = turn.role
            content = turn.content[:300]
            summary_parts.append(f"[{role}] {content}")

        if not summary_parts:
            return 0

        summary = "Conversation excerpt:\n" + "\n".join(summary_parts)

        # Determine category based on content
        category = self._categorize_from_content(summary)

        try:
            long_term.store(
                content=summary,
                category=category,
                metadata={"source": "consolidation", "turn_count": len(evicted)},
            )
        except Exception as e:
            logger.warning("Failed to store consolidated turns: %s", e)
            return 0

        return len(evicted)

    def _merge_similar_memories(self, long_term: Any) -> int:
        """Find and merge similar long-term memories.

        Uses pairwise similarity comparison within the same category
        to find near-duplicate memories, then keeps the richer one
        and deletes the other.
        """
        merged = 0

        for category in MemoryCategory:
            memories = long_term.get_all_for_consolidation(category)
            if len(memories) < 2:
                continue

            # Compare within category (skip if too many — O(n²) is expensive)
            if len(memories) > 500:
                memories = memories[:500]

            to_delete: set[str] = set()

            for i, mem_a in enumerate(memories):
                if mem_a.id in to_delete:
                    continue
                for mem_b in memories[i + 1:]:
                    if mem_b.id in to_delete:
                        continue

                    # Simple content overlap check (fast heuristic)
                    similarity = self._content_similarity(mem_a.content, mem_b.content)
                    if similarity >= self._merge_threshold:
                        # Keep the one with more content / higher relevance
                        keep, drop = (mem_a, mem_b) if len(mem_a.content) >= len(mem_b.content) else (mem_b, mem_a)
                        to_delete.add(drop.id)
                        merged += 1
                        logger.debug("Merging %s into %s (sim=%.2f)", drop.id, keep.id, similarity)

            # Delete merged memories
            for mem_id in to_delete:
                try:
                    long_term.delete(mem_id)
                except Exception as e:
                    logger.warning("Failed to delete merged memory %s: %s", mem_id, e)

        return merged

    def _prune_low_relevance(self, long_term: Any) -> int:
        """Prune memories with very low relevance scores."""
        pruned = 0
        all_memories = long_term.get_all_for_consolidation()

        for mem in all_memories:
            if mem.relevance_score < self._prune_threshold:
                try:
                    long_term.delete(mem.id)
                    pruned += 1
                except Exception as e:
                    logger.warning("Failed to prune memory %s: %s", mem.id, e)

        return pruned

    def _promote_working(self, working: Any, long_term: Any) -> int:
        """Promote frequently-accessed working memory items to long-term."""
        promoted = 0

        # Check scratch pad entries for promotion-worthy content
        scratch = working.get_all_scratch()
        for key, value in scratch.items():
            if len(value) > 50:  # Only promote substantive entries
                try:
                    long_term.store(
                        content=f"[Working Note] {key}: {value}",
                        category=MemoryCategory.TASK,
                        metadata={"source": "working_promotion", "scratch_key": key},
                    )
                    promoted += 1
                except Exception as e:
                    logger.warning("Failed to promote scratch %s: %s", key, e)

        return promoted

    def _categorize_from_content(self, content: str) -> MemoryCategory:
        """Heuristic category detection from content text."""
        lower = content.lower()

        error_keywords = ("error", "exception", "traceback", "failed", "bug", "fix")
        pattern_keywords = ("pattern", "always", "use instead", "prefer", "convention")
        tool_keywords = ("command", "tool", "npm", "pip", "docker", "git")

        if any(kw in lower for kw in error_keywords):
            return MemoryCategory.ERROR
        if any(kw in lower for kw in pattern_keywords):
            return MemoryCategory.PATTERN
        if any(kw in lower for kw in tool_keywords):
            return MemoryCategory.TOOL
        return MemoryCategory.TASK

    @staticmethod
    def _content_similarity(a: str, b: str) -> float:
        """Fast Jaccard-word similarity between two strings.

        This is a cheap heuristic — real similarity uses embeddings,
        but for consolidation batching this is sufficient.
        """
        words_a = set(a.lower().split())
        words_b = set(b.lower().split())
        if not words_a or not words_b:
            return 0.0
        intersection = words_a & words_b
        union = words_a | words_b
        return len(intersection) / len(union)
