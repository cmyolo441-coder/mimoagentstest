"""Short-term memory: current conversation turns.

Stores the recent conversation history as an ordered list of turns.
This is the fastest tier — pure in-memory, no persistence, no embeddings.
When the turn limit is exceeded, the oldest turns are evicted and
summarized before being passed to the consolidator.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("terminal_agent.memory.short_term")


@dataclass
class Turn:
    """A single conversation turn."""

    role: str
    content: str
    timestamp: float = field(default_factory=time.time)
    token_estimate: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.token_estimate == 0:
            # Rough estimate: ~4 chars per token for English
            self.token_estimate = max(1, len(self.content) // 4)

    def to_dict(self) -> dict[str, Any]:
        return {
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp,
            "token_estimate": self.token_estimate,
            "metadata": self.metadata,
        }

    def to_message(self) -> dict[str, str]:
        """Convert to LLM-compatible message format."""
        return {"role": self.role, "content": self.content}


class ShortTermMemory:
    """In-memory conversation turn storage with sliding window.

    Maintains an ordered list of conversation turns. When the maximum
    number of turns is exceeded, the oldest turns are evicted. Evicted
    turns are made available for consolidation into long-term memory.

    Args:
        max_turns: Maximum number of turns to retain.
    """

    def __init__(self, max_turns: int = 20) -> None:
        self._max_turns = max_turns
        self._turns: list[Turn] = []
        self._evicted: list[Turn] = []
        logger.debug("ShortTermMemory initialized with max_turns=%d", max_turns)

    def add_turn(
        self,
        role: str,
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> Turn:
        """Add a conversation turn.

        Args:
            role: Speaker role ("user", "assistant", "system").
            content: Turn content text.
            metadata: Optional metadata.

        Returns:
            The created Turn object.
        """
        turn = Turn(role=role, content=content, metadata=metadata or {})
        self._turns.append(turn)

        # Evict oldest if over limit
        while len(self._turns) > self._max_turns:
            evicted = self._turns.pop(0)
            self._evicted.append(evicted)
            logger.debug("Evicted turn: role=%s, len=%d", evicted.role, len(evicted.content))

        return turn

    def get_turns(self, max_turns: int | None = None) -> list[dict[str, Any]]:
        """Get recent turns as dicts.

        Args:
            max_turns: Maximum turns to return (default: all stored).

        Returns:
            List of turn dicts.
        """
        turns = self._turns
        if max_turns is not None:
            turns = turns[-max_turns:]
        return [t.to_dict() for t in turns]

    def get_as_messages(self, max_turns: int | None = None) -> list[dict[str, str]]:
        """Get turns as LLM-compatible messages.

        Args:
            max_turns: Maximum turns to return.

        Returns:
            List of dicts with 'role' and 'content' keys.
        """
        turns = self._turns
        if max_turns is not None:
            turns = turns[-max_turns:]
        return [t.to_message() for t in turns]

    def get_last(self, n: int = 1) -> list[Turn]:
        """Get the last N turns as Turn objects."""
        return self._turns[-n:] if n <= len(self._turns) else list(self._turns)

    def get_last_user_message(self) -> str | None:
        """Get the content of the most recent user message."""
        for turn in reversed(self._turns):
            if turn.role == "user":
                return turn.content
        return None

    def get_last_assistant_message(self) -> str | None:
        """Get the content of the most recent assistant message."""
        for turn in reversed(self._turns):
            if turn.role == "assistant":
                return turn.content
        return None

    def get_evicted(self) -> list[Turn]:
        """Get evicted turns (for consolidation).

        Returns and clears the evicted queue.
        """
        evicted = list(self._evicted)
        self._evicted.clear()
        return evicted

    def count(self) -> int:
        """Number of turns currently stored."""
        return len(self._turns)

    def estimate_tokens(self) -> int:
        """Estimate total tokens across all stored turns."""
        return sum(t.token_estimate for t in self._turns)

    def is_empty(self) -> bool:
        """Check if short-term memory is empty."""
        return len(self._turns) == 0

    def clear(self) -> None:
        """Clear all turns and evicted queue."""
        self._turns.clear()
        self._evicted.clear()
        logger.debug("ShortTermMemory cleared")

    def replace_system_prompt(self, content: str) -> None:
        """Replace the system prompt turn if it exists, or insert at the start."""
        if self._turns and self._turns[0].role == "system":
            self._turns[0] = Turn(role="system", content=content)
        else:
            self._turns.insert(0, Turn(role="system", content=content))

    def summarize_for_context(self, max_chars: int = 2000) -> str:
        """Create a brief summary of conversation history for context.

        Useful when full turns are too long for the context window.
        """
        if not self._turns:
            return ""

        lines: list[str] = []
        total = 0
        # Walk from most recent backwards
        for turn in reversed(self._turns):
            snippet = turn.content[:200].replace("\n", " ")
            line = f"[{turn.role}] {snippet}"
            if total + len(line) > max_chars:
                break
            lines.append(line)
            total += len(line)

        lines.reverse()
        return "\n".join(lines)
