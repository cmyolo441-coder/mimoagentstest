"""Memory conflict resolution.

When new information conflicts with existing memories, this module
determines which version to keep, merge, or mark as superseded.
Handles contradictions, outdated information, and evolving facts.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.conflict_resolver")


class ConflictType(str, Enum):
    """Types of memory conflicts."""

    CONTRADICTION = "contradiction"  # Two memories say opposite things
    OUTDATED = "outdated"  # New info supersedes old
    DUPLICATE = "duplicate"  # Same info, different wording
    AMBIGUOUS = "ambiguous"  # Overlapping but not clearly conflicting


class Resolution(str, Enum):
    """Resolution strategies."""

    KEEP_NEW = "keep_new"  # Replace old with new
    KEEP_OLD = "keep_old"  # Keep existing, discard new
    MERGE = "merge"  # Combine both into a new memory
    KEEP_BOTH = "keep_both"  # Keep both with conflict markers
    SUPERSEDE = "supersede"  # Mark old as superseded, keep new


@dataclass
class Conflict:
    """A detected conflict between two memories."""

    conflict_type: ConflictType
    existing: Memory
    incoming: Memory
    confidence: float  # 0.0-1.0
    reason: str = ""
    resolution: Resolution | None = None


class ConflictResolver:
    """Detects and resolves conflicts between memories.

    When storing a new memory that may contradict an existing one,
    this resolver:
        1. Searches for potentially conflicting memories.
        2. Classifies the conflict type.
        3. Selects a resolution strategy.
        4. Applies the resolution.

    Args:
        similarity_threshold: Threshold for considering memories as potentially conflicting.
        recency_bias: How much to prefer newer memories (0.0-1.0).
    """

    def __init__(
        self,
        similarity_threshold: float = 0.75,
        recency_bias: float = 0.7,
    ) -> None:
        self._similarity_threshold = similarity_threshold
        self._recency_bias = recency_bias

    def check_conflicts(
        self,
        new_memory: Memory,
        existing_memories: list[Memory],
    ) -> list[Conflict]:
        """Check if a new memory conflicts with any existing memories.

        Args:
            new_memory: The incoming memory to check.
            existing_memories: Current memories to check against.

        Returns:
            List of detected conflicts.
        """
        conflicts: list[Conflict] = []

        for existing in existing_memories:
            if existing.id == new_memory.id:
                continue

            conflict = self._detect_conflict(existing, new_memory)
            if conflict:
                conflicts.append(conflict)

        return conflicts

    def resolve(
        self,
        conflict: Conflict,
        long_term: Any,
    ) -> Memory:
        """Resolve a conflict and apply the resolution.

        Args:
            conflict: The conflict to resolve.
            long_term: LongTermMemory instance for applying changes.

        Returns:
            The surviving memory after resolution.
        """
        if conflict.resolution is None:
            conflict.resolution = self._select_resolution(conflict)

        resolution = conflict.resolution
        logger.info(
            "Resolving %s conflict: %s (existing=%s, incoming=%s)",
            conflict.conflict_type.value,
            resolution.value,
            conflict.existing.id,
            conflict.incoming.id,
        )

        if resolution == Resolution.KEEP_NEW:
            return self._apply_keep_new(conflict, long_term)
        elif resolution == Resolution.KEEP_OLD:
            return self._apply_keep_old(conflict, long_term)
        elif resolution == Resolution.MERGE:
            return self._apply_merge(conflict, long_term)
        elif resolution == Resolution.SUPERSEDE:
            return self._apply_supersede(conflict, long_term)
        else:  # KEEP_BOTH
            return self._apply_keep_both(conflict, long_term)

    def resolve_all(
        self,
        conflicts: list[Conflict],
        long_term: Any,
    ) -> list[Memory]:
        """Resolve multiple conflicts.

        Args:
            conflicts: List of conflicts to resolve.
            long_term: LongTermMemory instance.

        Returns:
            List of surviving memories.
        """
        results: list[Memory] = []
        for conflict in conflicts:
            try:
                result = self.resolve(conflict, long_term)
                results.append(result)
            except Exception as e:
                logger.error("Failed to resolve conflict: %s", e)
                results.append(conflict.incoming)
        return results

    def _detect_conflict(self, existing: Memory, incoming: Memory) -> Conflict | None:
        """Detect if two memories conflict.

        Uses heuristics to identify contradictions and overlapping info.
        """
        # Must be same category to conflict meaningfully
        if existing.category != incoming.category:
            return None

        # Check content similarity
        similarity = self._content_similarity(existing.content, incoming.content)
        if similarity < self._similarity_threshold:
            return None

        # Classify conflict type
        conflict_type = self._classify_conflict(existing.content, incoming.content)

        return Conflict(
            conflict_type=conflict_type,
            existing=existing,
            incoming=incoming,
            confidence=similarity,
            reason=f"Content similarity: {similarity:.2f}",
        )

    def _classify_conflict(self, content_a: str, content_b: str) -> ConflictType:
        """Classify the type of conflict between two pieces of content."""
        lower_a = content_a.lower()
        lower_b = content_b.lower()

        # Check for negation patterns
        negation_patterns = [
            ("use", "don't use"),
            ("should", "shouldn't"),
            ("is", "is not"),
            ("always", "never"),
            ("prefer", "avoid"),
            ("yes", "no"),
            ("true", "false"),
        ]

        for pos, neg in negation_patterns:
            if (pos in lower_a and neg in lower_b) or (neg in lower_a and pos in lower_b):
                return ConflictType.CONTRADICTION

        # Check for version/date indicators (outdated)
        import re
        date_pattern = r"\b(20\d{2})\b"
        dates_a = re.findall(date_pattern, content_a)
        dates_b = re.findall(date_pattern, content_b)
        if dates_a and dates_b:
            if max(dates_b) > max(dates_a):
                return ConflictType.OUTDATED

        # High similarity without negation → duplicate
        similarity = self._content_similarity(content_a, content_b)
        if similarity > 0.95:
            return ConflictType.DUPLICATE

        # Medium similarity → ambiguous
        return ConflictType.AMBIGUOUS

    def _select_resolution(self, conflict: Conflict) -> Resolution:
        """Select the best resolution strategy for a conflict."""
        ct = conflict.conflict_type

        if ct == ConflictType.DUPLICATE:
            return Resolution.KEEP_NEW  # Newer version replaces

        if ct == ConflictType.OUTDATED:
            return Resolution.SUPERSEDE

        if ct == ConflictType.CONTRADICTION:
            # Use recency bias — prefer newer info for contradictions
            if self._recency_bias > 0.5:
                return Resolution.KEEP_NEW
            return Resolution.KEEP_BOTH  # Keep both for manual review

        # AMBIGUOUS
        if conflict.confidence > 0.9:
            return Resolution.MERGE
        return Resolution.KEEP_BOTH

    def _apply_keep_new(self, conflict: Conflict, long_term: Any) -> Memory:
        """Keep the new memory, delete the old one."""
        if conflict.existing.id:
            long_term.delete(conflict.existing.id)
        conflict.incoming.metadata["supersedes"] = conflict.existing.id
        return conflict.incoming

    def _apply_keep_old(self, conflict: Conflict, long_term: Any) -> Memory:
        """Keep the existing memory, discard the new one."""
        conflict.existing.metadata["rejected_new"] = conflict.incoming.id
        return conflict.existing

    def _apply_merge(self, conflict: Conflict, long_term: Any) -> Memory:
        """Merge both memories into a single combined memory."""
        merged_content = self._merge_content(
            conflict.existing.content,
            conflict.incoming.content,
        )

        # Create merged memory
        merged = long_term.store(
            content=merged_content,
            category=conflict.existing.category,
            metadata={
                "merged_from": [conflict.existing.id, conflict.incoming.id],
                "merge_reason": conflict.reason,
                "created_at": time.time(),
            },
        )

        # Delete originals
        if conflict.existing.id:
            long_term.delete(conflict.existing.id)
        if conflict.incoming.id:
            long_term.delete(conflict.incoming.id)

        return merged

    def _apply_supersede(self, conflict: Conflict, long_term: Any) -> Memory:
        """Mark old memory as superseded, keep new one."""
        if conflict.existing.id:
            # Update old memory with superseded marker
            long_term.update(
                conflict.existing.id,
                metadata={
                    "superseded": True,
                    "superseded_by": conflict.incoming.id,
                    "superseded_at": time.time(),
                },
            )
        conflict.incoming.metadata["supersedes"] = conflict.existing.id
        return conflict.incoming

    def _apply_keep_both(self, conflict: Conflict, long_term: Any) -> Memory:
        """Keep both memories with conflict markers."""
        conflict.incoming.metadata["conflicts_with"] = conflict.existing.id
        conflict.incoming.metadata["conflict_type"] = conflict.conflict_type.value
        return conflict.incoming

    def _merge_content(self, content_a: str, content_b: str) -> str:
        """Merge two pieces of content into a combined representation."""
        # Simple merge: keep both with markers
        return (
            f"[Merged memory]\n"
            f"Version A: {content_a}\n"
            f"Version B: {content_b}"
        )

    @staticmethod
    def _content_similarity(a: str, b: str) -> float:
        """Fast word-overlap similarity between two strings."""
        words_a = set(a.lower().split())
        words_b = set(b.lower().split())
        if not words_a or not words_b:
            return 0.0
        intersection = words_a & words_b
        union = words_a | words_b
        return len(intersection) / len(union)
