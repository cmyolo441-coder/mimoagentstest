"""Working memory: active state during a session.

Holds ephemeral data that the agent needs quick access to during
task execution: file contents, command outputs, scratch-pad notes,
and arbitrary key-value pairs. Data is session-scoped and optionally
TTL-expiring.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("terminal_agent.memory.working")


@dataclass
class WorkingEntry:
    """A single working memory entry."""

    key: str
    value: Any
    created_at: float = field(default_factory=time.time)
    ttl: float | None = None  # seconds; None = no expiry
    access_count: int = 0
    last_accessed: float = field(default_factory=time.time)

    def is_expired(self) -> bool:
        if self.ttl is None:
            return False
        return (time.time() - self.created_at) > self.ttl

    def touch(self) -> None:
        self.access_count += 1
        self.last_accessed = time.time()


class WorkingMemory:
    """Session-scoped working memory for active state.

    Provides three namespaces:
        - **store**: General key-value pairs with optional TTL.
        - **files**: File path → content mapping for quick reference.
        - **scratch**: Ephemeral notes (lightweight, no metadata).

    Args:
        max_files: Maximum number of files to retain.
    """

    def __init__(self, max_files: int = 10) -> None:
        self._max_files = max_files
        self._store: dict[str, WorkingEntry] = {}
        self._files: dict[str, str] = {}
        self._file_order: list[str] = []  # LRU tracking
        self._scratch: dict[str, str] = {}
        logger.debug("WorkingMemory initialized with max_files=%d", max_files)

    # ── General Store ────────────────────────────────────────────────

    def set(self, key: str, value: Any, ttl: float | None = None) -> None:
        """Set a working memory entry.

        Args:
            key: Entry key.
            value: Entry value (any serializable type).
            ttl: Time-to-live in seconds (None = session-scoped).
        """
        self._store[key] = WorkingEntry(key=key, value=value, ttl=ttl)
        logger.debug("Working memory set: %s (ttl=%s)", key, ttl)

    def get(self, key: str, default: Any = None) -> Any:
        """Get a working memory entry.

        Returns default if key is missing or expired.
        """
        entry = self._store.get(key)
        if entry is None:
            return default
        if entry.is_expired():
            del self._store[key]
            return default
        entry.touch()
        return entry.value

    def has(self, key: str) -> bool:
        """Check if a key exists and is not expired."""
        entry = self._store.get(key)
        if entry is None:
            return False
        if entry.is_expired():
            del self._store[key]
            return False
        return True

    def delete(self, key: str) -> bool:
        """Delete a working memory entry."""
        if key in self._store:
            del self._store[key]
            return True
        return False

    def keys(self) -> list[str]:
        """List all non-expired keys."""
        self._cleanup_expired()
        return list(self._store.keys())

    # ── File Contents ────────────────────────────────────────────────

    def add_file(self, path: str, content: str) -> None:
        """Store file content in working memory.

        If the file limit is exceeded, the least-recently-used file
        is evicted.

        Args:
            path: File path (used as key).
            content: File content.
        """
        # Update order if already present
        if path in self._file_order:
            self._file_order.remove(path)
        self._file_order.append(path)
        self._files[path] = content

        # Evict LRU if over limit
        while len(self._files) > self._max_files:
            evict_path = self._file_order.pop(0)
            del self._files[evict_path]
            logger.debug("Evicted file from working memory: %s", evict_path)

        logger.debug("Added file to working memory: %s (%d chars)", path, len(content))

    def get_file(self, path: str) -> str | None:
        """Get file content from working memory.

        Returns None if the file is not stored.
        """
        content = self._files.get(path)
        if content is not None and path in self._file_order:
            # Move to end (most recently used)
            self._file_order.remove(path)
            self._file_order.append(path)
        return content

    def remove_file(self, path: str) -> bool:
        """Remove a file from working memory."""
        if path in self._files:
            del self._files[path]
            if path in self._file_order:
                self._file_order.remove(path)
            return True
        return False

    def get_file_list(self) -> list[str]:
        """Get list of stored file paths, ordered by recency."""
        return list(reversed(self._file_order))

    def get_file_summary(self) -> dict[str, int]:
        """Get a summary of stored files (path → content length)."""
        return {path: len(content) for path, content in self._files.items()}

    # ── Scratch Pad ──────────────────────────────────────────────────

    def set_scratch(self, key: str, value: str) -> None:
        """Set a scratch-pad note."""
        self._scratch[key] = value

    def get_scratch(self, key: str) -> str | None:
        """Get a scratch-pad note."""
        return self._scratch.get(key)

    def delete_scratch(self, key: str) -> bool:
        """Delete a scratch-pad note."""
        if key in self._scratch:
            del self._scratch[key]
            return True
        return False

    def get_all_scratch(self) -> dict[str, str]:
        """Get all scratch-pad notes."""
        return dict(self._scratch)

    def scratch_count(self) -> int:
        """Number of scratch-pad notes."""
        return len(self._scratch)

    # ── Maintenance ──────────────────────────────────────────────────

    def _cleanup_expired(self) -> None:
        """Remove expired entries."""
        expired = [k for k, v in self._store.items() if v.is_expired()]
        for k in expired:
            del self._store[k]
        if expired:
            logger.debug("Cleaned up %d expired working memory entries", len(expired))

    def clear(self) -> None:
        """Clear all working memory."""
        self._store.clear()
        self._files.clear()
        self._file_order.clear()
        self._scratch.clear()
        logger.debug("WorkingMemory cleared")

    def size(self) -> int:
        """Total number of entries across all namespaces."""
        return len(self._store) + len(self._files) + len(self._scratch)

    def to_context_string(self, max_chars: int = 5000) -> str:
        """Build a formatted string representation for LLM context."""
        sections: list[str] = []
        total = 0

        # Files
        if self._files:
            sections.append("## Active Files")
            for path in self.get_file_list():
                content = self._files[path]
                preview = content[:300] + "..." if len(content) > 300 else content
                entry = f"### {path}\n```\n{preview}\n```"
                if total + len(entry) > max_chars:
                    break
                sections.append(entry)
                total += len(entry)

        # Scratch pad
        if self._scratch:
            scratch_section = "## Scratch Pad\n" + "\n".join(
                f"- **{k}**: {v[:200]}" for k, v in self._scratch.items()
            )
            if total + len(scratch_section) <= max_chars:
                sections.append(scratch_section)
                total += len(scratch_section)

        # Key-value store (non-file, non-scratch)
        kv_entries = {
            k: v.value for k, v in self._store.items() if not v.is_expired()
        }
        if kv_entries:
            kv_section = "## State\n" + "\n".join(
                f"- **{k}**: {str(v)[:200]}" for k, v in kv_entries.items()
            )
            if total + len(kv_section) <= max_chars:
                sections.append(kv_section)

        return "\n\n".join(sections) if sections else ""
