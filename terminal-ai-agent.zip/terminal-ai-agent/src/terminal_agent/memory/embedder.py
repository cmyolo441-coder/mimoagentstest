"""Embedding generation for memory vectorization.

Converts text content into dense vector representations for semantic
search. Supports multiple embedding backends (OpenAI, local models,
sentence-transformers) with a unified interface.
"""

from __future__ import annotations

import hashlib
import logging
from typing import Any

logger = logging.getLogger("terminal_agent.memory.embedder")


class MemoryEmbedder:
    """Generates and caches embeddings for memory content.

    Supports multiple embedding backends:
        - "openai": OpenAI text-embedding-3-small/large (API call)
        - "local": Hash-based pseudo-embeddings (zero-dependency fallback)
        - "sentence-transformers": Local sentence-transformers model

    The "local" backend produces deterministic pseudo-embeddings from
    content hashes. This is useful for development/testing and works
    without any external dependencies, but produces lower-quality
    semantic search results.

    Args:
        model: Embedding model identifier.
        dimensions: Embedding vector dimensions.
        cache_size: Maximum number of embeddings to cache.
    """

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        dimensions: int = 1536,
        cache_size: int = 5000,
    ) -> None:
        self._model = model
        self._dimensions = dimensions
        self._cache_size = cache_size
        self._cache: dict[str, list[float]] = {}
        self._backend: str = self._detect_backend(model)

        logger.info(
            "MemoryEmbedder: model=%s, dims=%d, backend=%s",
            model, dimensions, self._backend,
        )

    @staticmethod
    def _detect_backend(model: str) -> str:
        """Detect which backend to use based on model name."""
        if model.startswith("text-embedding"):
            return "openai"
        if model.startswith("sentence-transformers") or model.startswith("all-"):
            return "sentence-transformers"
        return "local"

    def embed(self, text: str) -> list[float]:
        """Generate an embedding vector for the given text.

        Results are cached by content hash to avoid recomputation.

        Args:
            text: Text to embed.

        Returns:
            List of floats representing the embedding vector.

        Raises:
            EmbeddingError: If embedding generation fails.
        """
        if not text.strip():
            return [0.0] * self._dimensions

        # Check cache
        cache_key = self._cache_key(text)
        if cache_key in self._cache:
            return self._cache[cache_key]

        # Generate embedding
        if self._backend == "openai":
            vector = self._embed_openai(text)
        elif self._backend == "sentence-transformers":
            vector = self._embed_sentence_transformers(text)
        else:
            vector = self._embed_local(text)

        # Cache
        self._cache_set(cache_key, vector)
        return vector

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts.

        Args:
            texts: List of texts to embed.

        Returns:
            List of embedding vectors.
        """
        if not texts:
            return []

        # Check which ones need computation
        results: list[list[float] | None] = [None] * len(texts)
        to_compute: list[tuple[int, str]] = []

        for i, text in enumerate(texts):
            if not text.strip():
                results[i] = [0.0] * self._dimensions
                continue
            cache_key = self._cache_key(text)
            if cache_key in self._cache:
                results[i] = self._cache[cache_key]
            else:
                to_compute.append((i, text))

        # Batch compute
        if to_compute:
            if self._backend == "openai":
                vectors = self._embed_openai_batch([t for _, t in to_compute])
            else:
                vectors = [self.embed(t) for _, t in to_compute]

            for (idx, text), vector in zip(to_compute, vectors):
                results[idx] = vector
                self._cache_set(self._cache_key(text), vector)

        return [r for r in results if r is not None]

    def _embed_openai(self, text: str) -> list[float]:
        """Embed using OpenAI API."""
        try:
            import openai

            client = openai.OpenAI()
            response = client.embeddings.create(
                model=self._model,
                input=text,
                dimensions=self._dimensions,
            )
            return response.data[0].embedding
        except ImportError:
            logger.warning("openai package not installed, falling back to local embedding")
            return self._embed_local(text)
        except Exception as e:
            logger.warning("OpenAI embedding failed (%s), falling back to local", e)
            return self._embed_local(text)

    def _embed_openai_batch(self, texts: list[str]) -> list[list[float]]:
        """Batch embed using OpenAI API."""
        try:
            import openai

            client = openai.OpenAI()
            # OpenAI allows up to 2048 inputs per batch
            all_vectors: list[list[float]] = []
            for i in range(0, len(texts), 2048):
                batch = texts[i : i + 2048]
                response = client.embeddings.create(
                    model=self._model,
                    input=batch,
                    dimensions=self._dimensions,
                )
                all_vectors.extend([d.embedding for d in response.data])
            return all_vectors
        except Exception as e:
            logger.warning("OpenAI batch embedding failed (%s), using sequential", e)
            return [self._embed_openai(t) for t in texts]

    def _embed_sentence_transformers(self, text: str) -> list[float]:
        """Embed using sentence-transformers."""
        try:
            from sentence_transformers import SentenceTransformer

            if not hasattr(self, "_st_model"):
                self._st_model = SentenceTransformer(self._model)
            vector = self._st_model.encode(text, normalize_embeddings=True)
            return vector.tolist()
        except ImportError:
            logger.warning("sentence-transformers not installed, falling back to local")
            return self._embed_local(text)
        except Exception as e:
            logger.warning("sentence-transformers failed (%s), falling back to local", e)
            return self._embed_local(text)

    def _embed_local(self, text: str) -> list[float]:
        """Generate a deterministic pseudo-embedding from content hash.

        This produces a consistent vector for identical text, enabling
        basic deduplication and grouping. Not suitable for real semantic
        search — use as a development/testing fallback.
        """
        # Create a hash-based pseudo-embedding
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()

        # Convert hex digest to float vector
        vector: list[float] = []
        for i in range(0, min(len(digest), self._dimensions * 2), 2):
            hex_pair = digest[i : i + 2]
            value = (int(hex_pair, 16) / 127.5) - 1.0  # Normalize to [-1, 1]
            vector.append(value)

        # Pad or truncate to target dimensions
        if len(vector) < self._dimensions:
            # Use multiple hash rounds to fill dimensions
            extra_text = text
            while len(vector) < self._dimensions:
                extra_text += "_ext"
                extra_hash = hashlib.sha256(extra_text.encode("utf-8")).hexdigest()
                for i in range(0, min(len(extra_hash), (self._dimensions - len(vector)) * 2), 2):
                    hex_pair = extra_hash[i : i + 2]
                    value = (int(hex_pair, 16) / 127.5) - 1.0
                    vector.append(value)
                    if len(vector) >= self._dimensions:
                        break
        elif len(vector) > self._dimensions:
            vector = vector[: self._dimensions]

        # Normalize to unit vector for cosine similarity
        magnitude = sum(v * v for v in vector) ** 0.5
        if magnitude > 0:
            vector = [v / magnitude for v in vector]

        return vector

    def _cache_key(self, text: str) -> str:
        """Generate a cache key for text content."""
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    def _cache_set(self, key: str, vector: list[float]) -> None:
        """Add to cache with LRU eviction."""
        if len(self._cache) >= self._cache_size:
            # Remove oldest entry (dict maintains insertion order in Python 3.7+)
            oldest = next(iter(self._cache))
            del self._cache[oldest]
        self._cache[key] = vector

    @property
    def dimensions(self) -> int:
        """Embedding vector dimensions."""
        return self._dimensions

    @property
    def model(self) -> str:
        """Embedding model identifier."""
        return self._model

    @property
    def backend(self) -> str:
        """Active embedding backend."""
        return self._backend

    def clear_cache(self) -> None:
        """Clear the embedding cache."""
        self._cache.clear()
