"""Memory compression for context window optimization.

Compresses verbose memories, long tool outputs, and conversation
history into concise representations that preserve key information
while reducing token count.
"""

from __future__ import annotations

import logging
import re
from typing import Any

logger = logging.getLogger("terminal_agent.memory.compressor")


class MemoryCompressor:
    """Compresses memory content for efficient context usage.

    Provides multiple compression strategies:
        - Truncation: Cut to max length preserving head/tail.
        - Deduplication: Remove repeated lines.
        - Summarization markers: Tag content for LLM summarization.
        - Structured extraction: Pull key facts from verbose text.

    Args:
        max_content_length: Default max length for compressed content.
        head_ratio: Fraction of content to keep from the start.
        tail_ratio: Fraction of content to keep from the end.
    """

    def __init__(
        self,
        max_content_length: int = 500,
        head_ratio: float = 0.6,
        tail_ratio: float = 0.3,
    ) -> None:
        self._max_length = max_content_length
        self._head_ratio = head_ratio
        self._tail_ratio = tail_ratio

    def compress(
        self,
        content: str,
        max_length: int | None = None,
        strategy: str = "auto",
    ) -> str:
        """Compress content using the specified strategy.

        Args:
            content: Text to compress.
            max_length: Maximum output length (overrides default).
            strategy: Compression strategy ("auto", "truncate", "dedupe",
                      "extract", "head_tail").

        Returns:
            Compressed text.
        """
        if not content:
            return ""

        max_len = max_length or self._max_length

        if len(content) <= max_len:
            return content

        if strategy == "auto":
            strategy = self._choose_strategy(content)

        if strategy == "truncate":
            return self._truncate(content, max_len)
        elif strategy == "dedupe":
            return self._deduplicate(content, max_len)
        elif strategy == "extract":
            return self._extract_key_info(content, max_len)
        elif strategy == "head_tail":
            return self._head_tail(content, max_len)
        else:
            return self._truncate(content, max_len)

    def compress_tool_output(self, output: str, max_length: int = 2000) -> str:
        """Compress tool output, preserving error lines and key results.

        Tool outputs often contain verbose headers, progress bars, and
        repetitive content. This keeps the important parts.
        """
        if len(output) <= max_length:
            return output

        lines = output.split("\n")
        important: list[str] = []
        rest: list[str] = []

        for line in lines:
            if self._is_important_line(line):
                important.append(line)
            else:
                rest.append(line)

        # Start with important lines
        result = "\n".join(important)

        # Fill remaining space with rest
        remaining = max_length - len(result) - 50  # Leave room for marker
        if remaining > 0 and rest:
            rest_text = "\n".join(rest)
            if len(rest_text) > remaining:
                head_size = int(remaining * 0.7)
                tail_size = int(remaining * 0.25)
                rest_text = (
                    rest_text[:head_size]
                    + f"\n... [{len(rest) - 2} lines truncated] ...\n"
                    + rest_text[-tail_size:]
                )
            result = rest_text + "\n---\n" + result if important else rest_text

        if len(result) > max_length:
            result = result[:max_length - 30] + "\n... [truncated] ..."

        return result

    def compress_conversation(
        self,
        turns: list[dict[str, str]],
        max_tokens: int = 2000,
    ) -> list[dict[str, str]]:
        """Compress conversation turns to fit within token budget.

        Keeps recent turns intact, compresses older ones.

        Args:
            turns: List of message dicts with 'role' and 'content'.
            max_tokens: Approximate token budget.

        Returns:
            Compressed list of turns.
        """
        if not turns:
            return []

        # Estimate tokens (rough: 1 token ≈ 4 chars)
        total_chars = sum(len(t.get("content", "")) for t in turns)
        max_chars = max_tokens * 4

        if total_chars <= max_chars:
            return turns

        # Keep the last 3 turns intact, compress the rest
        keep_recent = min(3, len(turns))
        recent = turns[-keep_recent:]
        older = turns[:-keep_recent]

        if not older:
            return recent

        # Budget for older turns
        recent_chars = sum(len(t.get("content", "")) for t in recent)
        older_budget = max_chars - recent_chars

        if older_budget <= 0:
            return recent

        # Compress older turns
        per_turn_budget = max(100, older_budget // len(older))
        compressed_older = []
        for turn in older:
            content = turn.get("content", "")
            if len(content) > per_turn_budget:
                content = self.compress(content, max_length=per_turn_budget)
            compressed_older.append({"role": turn["role"], "content": content})

        return compressed_older + recent

    def compress_memory_for_context(self, content: str, category: str = "task") -> str:
        """Compress a memory for inclusion in LLM context.

        Applies category-aware compression: error memories keep
        error details, pattern memories keep the pattern, etc.
        """
        max_len = self._max_length

        if category == "error":
            return self._compress_error_memory(content, max_len)
        elif category == "pattern":
            return self._compress_pattern_memory(content, max_len)
        elif category == "tool":
            return self._compress_tool_memory(content, max_len)
        else:
            return self.compress(content, max_length=max_len)

    def _choose_strategy(self, content: str) -> str:
        """Auto-select compression strategy based on content type."""
        lines = content.split("\n")

        # Many repeated lines → dedupe
        unique_ratio = len(set(lines)) / max(len(lines), 1)
        if unique_ratio < 0.5:
            return "dedupe"

        # Has error patterns → extract
        if re.search(r"(error|exception|traceback|failed)", content, re.IGNORECASE):
            return "extract"

        # Long single block → head_tail
        if len(lines) < 5 and len(content) > self._max_length * 2:
            return "head_tail"

        return "truncate"

    def _truncate(self, content: str, max_length: int) -> str:
        """Simple truncation with marker."""
        if len(content) <= max_length:
            return content
        return content[: max_length - 20] + "\n... [truncated] ..."

    def _head_tail(self, content: str, max_length: int) -> str:
        """Keep head and tail, drop the middle."""
        head_size = int(max_length * self._head_ratio)
        tail_size = int(max_length * self._tail_ratio)

        head = content[:head_size]
        tail = content[-tail_size:]
        dropped = len(content) - head_size - tail_size

        return f"{head}\n\n... [{dropped} chars omitted] ...\n\n{tail}"

    def _deduplicate(self, content: str, max_length: int) -> str:
        """Remove duplicate consecutive lines, then truncate."""
        lines = content.split("\n")
        deduped: list[str] = []
        prev = None
        dup_count = 0

        for line in lines:
            if line == prev:
                dup_count += 1
            else:
                if dup_count > 0:
                    deduped.append(f"  ... ({dup_count} duplicate lines)")
                    dup_count = 0
                deduped.append(line)
                prev = line

        if dup_count > 0:
            deduped.append(f"  ... ({dup_count} duplicate lines)")

        result = "\n".join(deduped)
        if len(result) > max_length:
            result = result[:max_length - 20] + "\n... [truncated] ..."
        return result

    def _extract_key_info(self, content: str, max_length: int) -> str:
        """Extract important lines (errors, results, key values)."""
        lines = content.split("\n")
        important = [line for line in lines if self._is_important_line(line)]

        result = "\n".join(important)
        if len(result) > max_length:
            result = self._head_tail(result, max_length)
        elif len(result) < max_length // 2:
            # Not enough important lines, add context from the rest
            remaining = [l for l in lines if not self._is_important_line(l)]
            budget = max_length - len(result) - 30
            context = "\n".join(remaining)
            if len(context) > budget:
                context = context[:budget] + "..."
            result = context + "\n---\n" + result if result else context

        return result

    def _is_important_line(self, line: str) -> bool:
        """Check if a line contains important information."""
        lower = line.lower().strip()
        if not lower:
            return False

        # Error indicators
        if re.search(r"(error|exception|fatal|critical|fail|panic)", lower):
            return True
        # Success indicators
        if re.search(r"(success|complete|pass|ok|done|created|installed)", lower):
            return True
        # Exit codes
        if re.search(r"exit\s*(code|status)", lower):
            return True
        # File paths
        if re.search(r"(/[a-zA-Z]+/|\.[a-zA-Z]{1,5}:\d+)", line):
            return True
        # Numbers that look like results
        if re.search(r"\d+\s*(tests?|files?|bytes?|errors?|warnings?)", lower):
            return True
        return False

    def _compress_error_memory(self, content: str, max_length: int) -> str:
        """Compress error memory keeping the error message and fix."""
        # Keep first error line and any fix/solution lines
        lines = content.split("\n")
        keep: list[str] = []
        for line in lines:
            lower = line.lower()
            if any(kw in lower for kw in ("error", "fix", "solution", "resolved", "workaround")):
                keep.append(line)

        result = "\n".join(keep) if keep else self._head_tail(content, max_length)
        if len(result) > max_length:
            result = result[:max_length - 20] + "... [truncated]"
        return result

    def _compress_pattern_memory(self, content: str, max_length: int) -> str:
        """Compress pattern memory keeping the core pattern."""
        # Keep code blocks and key instructions
        if len(content) <= max_length:
            return content
        return self._head_tail(content, max_length)

    def _compress_tool_memory(self, content: str, max_length: int) -> str:
        """Compress tool memory keeping command and outcome."""
        if len(content) <= max_length:
            return content
        return self._extract_key_info(content, max_length)
