"""Pattern memory: reusable code patterns and solutions.

Stores discovered patterns that can be reused across tasks:
code idioms, project conventions, architecture patterns, and
proven solution strategies.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.categories.pattern")


@dataclass
class PatternRecord:
    """A reusable pattern or convention."""

    name: str
    description: str
    pattern_type: str = "code"  # code, architecture, workflow, convention
    language: str = ""
    framework: str = ""
    example: str = ""
    tags: list[str] = field(default_factory=list)
    success_count: int = 0
    failure_count: int = 0
    session_id: str = ""

    def to_memory_content(self) -> str:
        parts = [
            f"Pattern: {self.name}",
            f"Type: {self.pattern_type}",
            f"Description: {self.description}",
        ]
        if self.language:
            parts.append(f"Language: {self.language}")
        if self.framework:
            parts.append(f"Framework: {self.framework}")
        if self.example:
            parts.append(f"Example:\n{self.example[:500]}")
        if self.tags:
            parts.append(f"Tags: {', '.join(self.tags)}")
        return "\n".join(parts)

    def to_metadata(self) -> dict[str, Any]:
        return {
            "pattern_type": self.pattern_type,
            "language": self.language,
            "framework": self.framework,
            "tags": ",".join(self.tags),
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "session_id": self.session_id,
            "created_at": time.time(),
        }


class PatternMemory:
    """Manages reusable patterns and conventions.

    Usage::

        pat_mem = PatternMemory(long_term_memory)
        pat_mem.store_pattern(PatternRecord(
            name="Python error handling",
            description="Use try/except with specific exceptions",
            pattern_type="code",
            language="python",
            example="try:\\n    result = risky_call()\\nexcept ValueError as e:\\n    handle(e)",
        ))
        patterns = pat_mem.find_patterns("error handling python")
    """

    def __init__(self, long_term: Any) -> None:
        self._long_term = long_term

    def store_pattern(self, record: PatternRecord) -> Memory:
        """Store a pattern."""
        return self._long_term.store(
            content=record.to_memory_content(),
            category=MemoryCategory.PATTERN,
            metadata=record.to_metadata(),
            source_session_id=record.session_id,
        )

    def find_patterns(
        self,
        query: str,
        language: str | None = None,
        pattern_type: str | None = None,
        limit: int = 5,
    ) -> list[Memory]:
        """Find patterns matching a query."""
        embedding = self._long_term._embedder.embed(query)
        memories = self._long_term.search(
            query_embedding=embedding,
            categories=[MemoryCategory.PATTERN],
            limit=limit * 2,
        )

        # Filter by metadata
        if language:
            memories = [m for m in memories if m.metadata.get("language", "") in ("", language)]
        if pattern_type:
            memories = [m for m in memories if m.metadata.get("pattern_type") == pattern_type]

        return memories[:limit]

    def find_by_language(self, language: str, limit: int = 10) -> list[Memory]:
        """Find all patterns for a specific language."""
        embedding = self._long_term._embedder.embed(f"patterns for {language}")
        return self._long_term.search(
            query_embedding=embedding,
            categories=[MemoryCategory.PATTERN],
            limit=limit,
        )

    def record_success(self, memory_id: str) -> None:
        """Increment success counter for a pattern."""
        mem = self._long_term.get(memory_id)
        if mem:
            count = mem.metadata.get("success_count", 0) + 1
            self._long_term.update(memory_id, metadata={"success_count": count})

    def record_failure(self, memory_id: str) -> None:
        """Increment failure counter for a pattern."""
        mem = self._long_term.get(memory_id)
        if mem:
            count = mem.metadata.get("failure_count", 0) + 1
            self._long_term.update(memory_id, metadata={"failure_count": count})

    def get_best_patterns(self, limit: int = 10) -> list[Memory]:
        """Get patterns with highest success rate."""
        all_patterns = self._long_term.get_all_for_consolidation(MemoryCategory.PATTERN)

        def success_rate(p: Memory) -> float:
            s = p.metadata.get("success_count", 0)
            f = p.metadata.get("failure_count", 0)
            total = s + f
            return s / total if total > 0 else 0.5

        all_patterns.sort(key=success_rate, reverse=True)
        return all_patterns[:limit]
