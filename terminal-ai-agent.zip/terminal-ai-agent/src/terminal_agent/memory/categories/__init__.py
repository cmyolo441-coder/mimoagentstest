"""Memory categories for specialized storage and retrieval.

Each category provides domain-specific logic for storing, compressing,
and querying memories of that type.
"""

from terminal_agent.memory.categories.task_memory import TaskMemory
from terminal_agent.memory.categories.error_memory import ErrorMemory
from terminal_agent.memory.categories.pattern_memory import PatternMemory
from terminal_agent.memory.categories.preference_memory import PreferenceMemory
from terminal_agent.memory.categories.project_memory import ProjectMemory
from terminal_agent.memory.categories.tool_memory import ToolMemory
from terminal_agent.memory.categories.environment_memory import EnvironmentMemory

__all__ = [
    "TaskMemory",
    "ErrorMemory",
    "PatternMemory",
    "PreferenceMemory",
    "ProjectMemory",
    "ToolMemory",
    "EnvironmentMemory",
]
