"""Error memory: records of errors and their resolutions.

Stores structured information about errors encountered during tasks,
including the error type, context, root cause, and fix applied.
This is critical for the agent's ability to recover from repeated errors.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import ErrorCategory, Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.categories.error")


@dataclass
class ErrorRecord:
    """Structured record of an error and its resolution."""

    error_message: str
    error_category: ErrorCategory = ErrorCategory.UNKNOWN
    context: str = ""  # What was happening when the error occurred
    root_cause: str = ""
    fix_applied: str = ""
    fix_worked: bool = True
    tool_involved: str = ""
    file_involved: str = ""
    command_involved: str = ""
    session_id: str = ""
    stack_trace: str = ""

    def to_memory_content(self) -> str:
        """Convert to text for memory storage."""
        parts = [
            f"Error [{self.error_category.value}]: {self.error_message[:300]}",
        ]
        if self.context:
            parts.append(f"Context: {self.context[:200]}")
        if self.root_cause:
            parts.append(f"Root cause: {self.root_cause[:200]}")
        if self.fix_applied:
            parts.append(f"Fix: {self.fix_applied[:300]}")
            parts.append(f"Fix worked: {'yes' if self.fix_worked else 'no'}")
        if self.tool_involved:
            parts.append(f"Tool: {self.tool_involved}")
        if self.command_involved:
            parts.append(f"Command: {self.command_involved[:200]}")
        return "\n".join(parts)

    def to_metadata(self) -> dict[str, Any]:
        return {
            "error_category": self.error_category.value,
            "fix_worked": self.fix_worked,
            "tool_involved": self.tool_involved,
            "file_involved": self.file_involved,
            "has_fix": bool(self.fix_applied),
            "session_id": self.session_id,
            "created_at": time.time(),
        }


class ErrorMemory:
    """Manages error-specific memories.

    Enables the agent to:
        - Look up known fixes for error messages
        - Avoid repeating past mistakes
        - Build a knowledge base of error patterns

    Usage::

        err_mem = ErrorMemory(long_term_memory)
        err_mem.record_error(ErrorRecord(
            error_message="ModuleNotFoundError: No module named 'requests'",
            error_category=ErrorCategory.IMPORT,
            fix_applied="pip install requests",
            fix_worked=True,
        ))
        fixes = err_mem.find_fix("import error requests module")
    """

    def __init__(self, long_term: Any) -> None:
        self._long_term = long_term

    def record_error(self, record: ErrorRecord) -> Memory:
        """Store an error record.

        Args:
            record: The error record to store.

        Returns:
            The stored Memory object.
        """
        content = record.to_memory_content()
        metadata = record.to_metadata()

        return self._long_term.store(
            content=content,
            category=MemoryCategory.ERROR,
            metadata=metadata,
            source_session_id=record.session_id,
        )

    def find_fix(self, error_description: str, limit: int = 5) -> list[Memory]:
        """Find known fixes for an error description.

        Args:
            error_description: Description or message of the error.

        Returns:
            List of error memories with fixes, sorted by relevance.
        """
        embedding = self._long_term._embedder.embed(error_description)
        memories = self._long_term.search(
            query_embedding=embedding,
            categories=[MemoryCategory.ERROR],
            limit=limit * 2,
        )
        # Prefer memories that have fixes
        with_fix = [m for m in memories if m.metadata.get("has_fix")]
        without_fix = [m for m in memories if not m.metadata.get("has_fix")]
        return (with_fix + without_fix)[:limit]

    def find_by_category(self, category: ErrorCategory, limit: int = 10) -> list[Memory]:
        """Find errors by error category."""
        embedding = self._long_term._embedder.embed(f"error category {category.value}")
        return self._long_term.search(
            query_embedding=embedding,
            categories=[MemoryCategory.ERROR],
            limit=limit,
        )

    def find_by_tool(self, tool_name: str, limit: int = 10) -> list[Memory]:
        """Find errors associated with a specific tool."""
        all_errors = self._long_term.get_all_for_consolidation(MemoryCategory.ERROR)
        tool_errors = [
            m for m in all_errors
            if m.metadata.get("tool_involved") == tool_name
        ]
        return tool_errors[:limit]

    def get_error_stats(self) -> dict[str, Any]:
        """Get aggregate error statistics."""
        all_errors = self._long_term.get_all_for_consolidation(MemoryCategory.ERROR)
        if not all_errors:
            return {"total": 0}

        categories: dict[str, int] = {}
        fix_rate = 0
        tools: dict[str, int] = {}

        for err in all_errors:
            cat = err.metadata.get("error_category", "unknown")
            categories[cat] = categories.get(cat, 0) + 1
            if err.metadata.get("has_fix"):
                fix_rate += 1
            tool = err.metadata.get("tool_involved", "")
            if tool:
                tools[tool] = tools.get(tool, 0) + 1

        return {
            "total": len(all_errors),
            "categories": categories,
            "fix_rate": fix_rate / len(all_errors),
            "top_tools": dict(sorted(tools.items(), key=lambda x: -x[1])[:5]),
        }
