"""Project memory: project-specific knowledge and conventions.

Stores information about specific projects: structure, conventions,
dependencies, build systems, deployment details, and team practices.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.categories.project")


@dataclass
class ProjectRecord:
    """Project-specific knowledge."""

    project_path: str
    knowledge_type: str  # structure, convention, dependency, deployment, config
    content: str
    language: str = ""
    framework: str = ""
    tags: list[str] = field(default_factory=list)
    session_id: str = ""

    def to_memory_content(self) -> str:
        parts = [
            f"Project: {self.project_path}",
            f"Type: {self.knowledge_type}",
            f"Info: {self.content}",
        ]
        if self.language:
            parts.append(f"Language: {self.language}")
        if self.framework:
            parts.append(f"Framework: {self.framework}")
        return "\n".join(parts)

    def to_metadata(self) -> dict[str, Any]:
        return {
            "project_path": self.project_path,
            "knowledge_type": self.knowledge_type,
            "language": self.language,
            "framework": self.framework,
            "tags": ",".join(self.tags),
            "session_id": self.session_id,
            "created_at": time.time(),
        }


class ProjectMemory:
    """Manages project-specific memories.

    Usage::

        proj_mem = ProjectMemory(long_term_memory)
        proj_mem.store_knowledge(ProjectRecord(
            project_path="/home/user/myapp",
            knowledge_type="convention",
            content="API endpoints use /api/v2/ prefix",
            framework="fastapi",
        ))
        knowledge = proj_mem.get_project_knowledge("/home/user/myapp")
    """

    def __init__(self, long_term: Any) -> None:
        self._long_term = long_term

    def store_knowledge(self, record: ProjectRecord) -> Memory:
        """Store project knowledge."""
        return self._long_term.store(
            content=record.to_memory_content(),
            category=MemoryCategory.PROJECT,
            metadata=record.to_metadata(),
            source_session_id=record.session_id,
        )

    def get_project_knowledge(
        self,
        project_path: str,
        knowledge_type: str | None = None,
        limit: int = 20,
    ) -> list[Memory]:
        """Get knowledge for a specific project."""
        query = f"project {project_path} {knowledge_type or ''}".strip()
        embedding = self._long_term._embedder.embed(query)
        memories = self._long_term.search(
            query_embedding=embedding,
            categories=[MemoryCategory.PROJECT],
            limit=limit * 2,
        )

        # Filter by project path
        memories = [
            m for m in memories
            if m.metadata.get("project_path", "") == project_path
        ]

        if knowledge_type:
            memories = [m for m in memories if m.metadata.get("knowledge_type") == knowledge_type]

        return memories[:limit]

    def get_conventions(self, project_path: str) -> list[Memory]:
        """Get conventions for a project."""
        return self.get_project_knowledge(project_path, knowledge_type="convention")

    def get_structure_info(self, project_path: str) -> list[Memory]:
        """Get structure info for a project."""
        return self.get_project_knowledge(project_path, knowledge_type="structure")

    def get_deployment_info(self, project_path: str) -> list[Memory]:
        """Get deployment info for a project."""
        return self.get_project_knowledge(project_path, knowledge_type="deployment")
