"""Environment memory: system configuration and setup details.

Stores information about the user's environment: OS, installed tools,
shell configuration, PATH entries, and system-specific quirks.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.categories.environment")


@dataclass
class EnvironmentRecord:
    """System environment information."""

    category: str  # os, shell, tool_version, path, config, quirk
    key: str
    value: str
    platform: str = ""
    session_id: str = ""

    def to_memory_content(self) -> str:
        return f"Environment [{self.category}]: {self.key} = {self.value}"

    def to_metadata(self) -> dict[str, Any]:
        return {
            "env_category": self.category,
            "env_key": self.key,
            "platform": self.platform,
            "session_id": self.session_id,
            "created_at": time.time(),
        }


class EnvironmentMemory:
    """Manages environment-specific memories.

    Usage::

        env_mem = EnvironmentMemory(long_term_memory)
        env_mem.store_environment(EnvironmentRecord(
            category="tool_version",
            key="python",
            value="3.11.4",
            platform="linux",
        ))
        env_info = env_mem.get_environment("python")
    """

    def __init__(self, long_term: Any) -> None:
        self._long_term = long_term

    def store_environment(self, record: EnvironmentRecord) -> Memory:
        """Store environment information."""
        return self._long_term.store(
            content=record.to_memory_content(),
            category=MemoryCategory.ENVIRONMENT,
            metadata=record.to_metadata(),
            source_session_id=record.session_id,
        )

    def get_environment(
        self,
        key: str | None = None,
        category: str | None = None,
        limit: int = 20,
    ) -> list[Memory]:
        """Get environment information."""
        query = f"environment {category or ''} {key or ''}".strip()
        embedding = self._long_term._embedder.embed(query)
        memories = self._long_term.search(
            query_embedding=embedding,
            categories=[MemoryCategory.ENVIRONMENT],
            limit=limit * 2,
        )

        if key:
            memories = [m for m in memories if m.metadata.get("env_key") == key]
        if category:
            memories = [m for m in memories if m.metadata.get("env_category") == category]

        return memories[:limit]

    def get_tool_versions(self) -> list[Memory]:
        """Get all recorded tool versions."""
        return self.get_environment(category="tool_version")

    def get_os_info(self) -> list[Memory]:
        """Get OS information."""
        return self.get_environment(category="os")

    def get_shell_config(self) -> list[Memory]:
        """Get shell configuration."""
        return self.get_environment(category="shell")

    def get_quirks(self) -> list[Memory]:
        """Get known system quirks."""
        return self.get_environment(category="quirk")
