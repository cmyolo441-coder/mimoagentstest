"""Task memory: records of completed tasks and their outcomes.

Stores structured information about each task the agent performs,
including the goal, approach, tools used, outcome, and lessons learned.
This is the primary memory category for self-improvement.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.categories.task")


@dataclass
class TaskRecord:
    """Structured record of a completed task."""

    goal: str
    approach: str = ""
    tools_used: list[str] = field(default_factory=list)
    files_changed: list[str] = field(default_factory=list)
    commands_run: list[str] = field(default_factory=list)
    outcome: str = "success"  # success, partial, failure
    duration_seconds: float = 0.0
    iterations: int = 0
    error_count: int = 0
    lessons: list[str] = field(default_factory=list)
    session_id: str = ""

    def to_memory_content(self) -> str:
        """Convert to a text representation for memory storage."""
        parts = [
            f"Task: {self.goal}",
            f"Outcome: {self.outcome}",
        ]
        if self.approach:
            parts.append(f"Approach: {self.approach}")
        if self.tools_used:
            parts.append(f"Tools: {', '.join(self.tools_used)}")
        if self.files_changed:
            parts.append(f"Files: {', '.join(self.files_changed[:10])}")
        if self.commands_run:
            parts.append(f"Commands: {'; '.join(self.commands_run[:5])}")
        if self.lessons:
            parts.append(f"Lessons: {'; '.join(self.lessons)}")
        parts.append(f"Duration: {self.duration_seconds:.0f}s, Iterations: {self.iterations}")
        return "\n".join(parts)

    def to_metadata(self) -> dict[str, Any]:
        """Convert to metadata dict for vector store."""
        return {
            "outcome": self.outcome,
            "tool_count": len(self.tools_used),
            "file_count": len(self.files_changed),
            "error_count": self.error_count,
            "duration_seconds": self.duration_seconds,
            "iterations": self.iterations,
            "session_id": self.session_id,
            "created_at": time.time(),
        }


class TaskMemory:
    """Manages task-specific memories.

    Provides methods to store and retrieve task records with
    structured metadata for filtering and analysis.

    Usage::

        task_mem = TaskMemory(long_term_memory)
        task_mem.record_task(TaskRecord(
            goal="Fix the login bug",
            approach="Modified auth middleware",
            tools_used=["file_edit", "shell"],
            outcome="success",
        ))
        past_tasks = task_mem.find_similar_tasks("authentication fix")
    """

    def __init__(self, long_term: Any) -> None:
        self._long_term = long_term

    def record_task(self, record: TaskRecord) -> Memory:
        """Store a completed task record.

        Args:
            record: The task record to store.

        Returns:
            The stored Memory object.
        """
        content = record.to_memory_content()
        metadata = record.to_metadata()

        return self._long_term.store(
            content=content,
            category=MemoryCategory.TASK,
            metadata=metadata,
            source_session_id=record.session_id,
        )

    def find_similar_tasks(self, query: str, limit: int = 5) -> list[Memory]:
        """Find past tasks similar to a query.

        Args:
            query: Description of the task to find matches for.
            limit: Maximum results.

        Returns:
            List of matching task memories.
        """
        return self._long_term.search(
            query_embedding=self._long_term._embedder.embed(query),
            categories=[MemoryCategory.TASK],
            limit=limit,
        )

    def find_successful_tasks(self, query: str, limit: int = 5) -> list[Memory]:
        """Find successful past tasks matching a query."""
        memories = self.find_similar_tasks(query, limit=limit * 2)
        return [m for m in memories if m.metadata.get("outcome") == "success"][:limit]

    def find_failed_tasks(self, query: str, limit: int = 5) -> list[Memory]:
        """Find failed past tasks matching a query (to learn from mistakes)."""
        memories = self.find_similar_tasks(query, limit=limit * 2)
        return [m for m in memories if m.metadata.get("outcome") == "failure"][:limit]

    def get_task_stats(self) -> dict[str, Any]:
        """Get aggregate statistics about stored tasks."""
        all_tasks = self._long_term.get_all_for_consolidation(MemoryCategory.TASK)
        if not all_tasks:
            return {"total": 0}

        outcomes = {}
        total_duration = 0.0
        total_iterations = 0

        for task in all_tasks:
            outcome = task.metadata.get("outcome", "unknown")
            outcomes[outcome] = outcomes.get(outcome, 0) + 1
            total_duration += task.metadata.get("duration_seconds", 0)
            total_iterations += task.metadata.get("iterations", 0)

        return {
            "total": len(all_tasks),
            "outcomes": outcomes,
            "success_rate": outcomes.get("success", 0) / len(all_tasks),
            "avg_duration": total_duration / len(all_tasks),
            "avg_iterations": total_iterations / len(all_tasks),
        }
