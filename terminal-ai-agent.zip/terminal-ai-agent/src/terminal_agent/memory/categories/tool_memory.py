"""Tool memory: tool usage patterns and gotchas.

Stores information about how tools are used, common pitfalls,
optimal parameters, and workarounds for tool limitations.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.categories.tool")


@dataclass
class ToolRecord:
    """Tool usage knowledge."""

    tool_name: str
    observation: str  # What was learned
    gotcha_type: str = "tip"  # tip, pitfall, workaround, best_practice
    context: str = ""
    command_example: str = ""
    platform: str = ""  # linux, macos, windows, all
    session_id: str = ""

    def to_memory_content(self) -> str:
        parts = [
            f"Tool: {self.tool_name}",
            f"[{self.gotcha_type}] {self.observation}",
        ]
        if self.context:
            parts.append(f"Context: {self.context[:200]}")
        if self.command_example:
            parts.append(f"Example: {self.command_example[:300]}")
        if self.platform:
            parts.append(f"Platform: {self.platform}")
        return "\n".join(parts)

    def to_metadata(self) -> dict[str, Any]:
        return {
            "tool_name": self.tool_name,
            "gotcha_type": self.gotcha_type,
            "platform": self.platform,
            "session_id": self.session_id,
            "created_at": time.time(),
        }


class ToolMemory:
    """Manages tool usage memories.

    Usage::

        tool_mem = ToolMemory(long_term_memory)
        tool_mem.store_observation(ToolRecord(
            tool_name="git",
            observation="git rebase -i requires clean working tree",
            gotcha_type="pitfall",
            command_example="git stash && git rebase -i HEAD~3 && git stash pop",
        ))
        tips = tool_mem.get_tool_tips("git")
    """

    def __init__(self, long_term: Any) -> None:
        self._long_term = long_term

    def store_observation(self, record: ToolRecord) -> Memory:
        """Store a tool observation."""
        return self._long_term.store(
            content=record.to_memory_content(),
            category=MemoryCategory.TOOL,
            metadata=record.to_metadata(),
            source_session_id=record.session_id,
        )

    def get_tool_tips(self, tool_name: str, limit: int = 10) -> list[Memory]:
        """Get tips and observations for a specific tool."""
        embedding = self._long_term._embedder.embed(f"tool {tool_name} tips")
        memories = self._long_term.search(
            query_embedding=embedding,
            categories=[MemoryCategory.TOOL],
            limit=limit * 2,
        )
        return [m for m in memories if m.metadata.get("tool_name") == tool_name][:limit]

    def get_pitfalls(self, tool_name: str, limit: int = 5) -> list[Memory]:
        """Get known pitfalls for a tool."""
        tips = self.get_tool_tips(tool_name, limit=limit * 2)
        return [m for m in tips if m.metadata.get("gotcha_type") == "pitfall"][:limit]

    def get_workarounds(self, tool_name: str, limit: int = 5) -> list[Memory]:
        """Get known workarounds for a tool."""
        tips = self.get_tool_tips(tool_name, limit=limit * 2)
        return [m for m in tips if m.metadata.get("gotcha_type") == "workaround"][:limit]

    def get_best_practices(self, tool_name: str, limit: int = 5) -> list[Memory]:
        """Get best practices for a tool."""
        tips = self.get_tool_tips(tool_name, limit=limit * 2)
        return [m for m in tips if m.metadata.get("gotcha_type") == "best_practice"][:limit]

    def search_tool_help(self, query: str, limit: int = 5) -> list[Memory]:
        """Search across all tool memories for help with a query."""
        embedding = self._long_term._embedder.embed(query)
        return self._long_term.search(
            query_embedding=embedding,
            categories=[MemoryCategory.TOOL],
            limit=limit,
        )
