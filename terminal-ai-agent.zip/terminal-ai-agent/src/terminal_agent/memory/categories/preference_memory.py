"""Preference memory: user style preferences and conventions.

Stores user-specific preferences that affect how the agent generates
code, formats output, names variables, structures files, and makes
design decisions.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.categories.preference")


@dataclass
class PreferenceRecord:
    """A user preference or style choice."""

    category: str  # code_style, naming, formatting, architecture, tool, general
    preference: str  # Description of the preference
    example_correct: str = ""
    example_incorrect: str = ""
    scope: str = "global"  # global, project, language
    language: str = ""
    project: str = ""
    strength: float = 1.0  # 0.0-1.0, how strongly the user feels
    source: str = "observed"  # observed, explicit, inferred
    session_id: str = ""

    def to_memory_content(self) -> str:
        parts = [
            f"Preference [{self.category}]: {self.preference}",
            f"Scope: {self.scope}",
        ]
        if self.language:
            parts.append(f"Language: {self.language}")
        if self.example_correct:
            parts.append(f"Do: {self.example_correct[:200]}")
        if self.example_incorrect:
            parts.append(f"Don't: {self.example_incorrect[:200]}")
        return "\n".join(parts)

    def to_metadata(self) -> dict[str, Any]:
        return {
            "pref_category": self.category,
            "scope": self.scope,
            "language": self.language,
            "project": self.project,
            "strength": self.strength,
            "source": self.source,
            "session_id": self.session_id,
            "created_at": time.time(),
        }


class PreferenceMemory:
    """Manages user preference memories.

    Usage::

        pref_mem = PreferenceMemory(long_term_memory)
        pref_mem.store_preference(PreferenceRecord(
            category="naming",
            preference="Use snake_case for Python variables",
            language="python",
            example_correct="user_name",
            example_incorrect="userName",
        ))
        prefs = pref_mem.get_preferences("naming", language="python")
    """

    def __init__(self, long_term: Any) -> None:
        self._long_term = long_term

    def store_preference(self, record: PreferenceRecord) -> Memory:
        """Store a preference."""
        return self._long_term.store(
            content=record.to_memory_content(),
            category=MemoryCategory.PREFERENCE,
            metadata=record.to_metadata(),
            source_session_id=record.session_id,
        )

    def get_preferences(
        self,
        category: str | None = None,
        language: str | None = None,
        scope: str | None = None,
        limit: int = 20,
    ) -> list[Memory]:
        """Get preferences, optionally filtered."""
        query = f"preference {category or ''} {language or ''}".strip()
        embedding = self._long_term._embedder.embed(query)
        memories = self._long_term.search(
            query_embedding=embedding,
            categories=[MemoryCategory.PREFERENCE],
            limit=limit * 2,
        )

        if category:
            memories = [m for m in memories if m.metadata.get("pref_category") == category]
        if language:
            memories = [m for m in memories if m.metadata.get("language", "") in ("", language)]
        if scope:
            memories = [m for m in memories if m.metadata.get("scope") == scope]

        return memories[:limit]

    def get_code_style_preferences(self, language: str) -> list[Memory]:
        """Get code style preferences for a language."""
        return self.get_preferences(category="code_style", language=language)

    def get_naming_preferences(self, language: str) -> list[Memory]:
        """Get naming convention preferences for a language."""
        return self.get_preferences(category="naming", language=language)

    def get_formatting_preferences(self) -> list[Memory]:
        """Get formatting preferences."""
        return self.get_preferences(category="formatting")
