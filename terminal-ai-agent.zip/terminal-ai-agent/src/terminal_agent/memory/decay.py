"""Memory relevance decay.

Reduces the relevance score of memories over time based on access
patterns. Memories that are frequently accessed decay slowly, while
unused memories fade, ensuring the most useful memories surface first.
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.decay")


@dataclass
class DecayReport:
    """Report of a decay run."""

    memories_processed: int = 0
    memories_decayed: int = 0
    memories_purged: int = 0  # Dropped below threshold
    avg_score_before: float = 0.0
    avg_score_after: float = 0.0
    duration_ms: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "memories_processed": self.memories_processed,
            "memories_decayed": self.memories_decayed,
            "memories_purged": self.memories_purged,
            "avg_score_before": round(self.avg_score_before, 4),
            "avg_score_after": round(self.avg_score_after, 4),
            "duration_ms": round(self.duration_ms, 1),
        }


class MemoryDecay:
    """Applies time-based relevance decay to long-term memories.

    Uses exponential decay with access-frequency modulation:
        new_score = old_score * e^(-rate * age * frequency_factor)

    Where:
        - rate is the base decay rate
        - age is time since last access (not creation)
        - frequency_factor reduces decay for frequently-accessed memories

    Memories that are accessed frequently are "refreshed" and decay
    slowly. Memories that are never accessed decay quickly.

    Args:
        rate: Base decay rate (higher = faster decay).
        min_score: Minimum relevance score (below this, memory is purgeable).
        access_bonus: Score bonus applied each time a memory is accessed.
        purge_threshold: Score below which memories are auto-purged.
    """

    def __init__(
        self,
        rate: float = 0.1,
        min_score: float = 0.01,
        access_bonus: float = 0.05,
        purge_threshold: float = 0.05,
    ) -> None:
        self._rate = rate
        self._min_score = min_score
        self._access_bonus = access_bonus
        self._purge_threshold = purge_threshold

    def apply(self, long_term: Any) -> dict[str, Any]:
        """Apply decay to all long-term memories.

        Args:
            long_term: LongTermMemory instance.

        Returns:
            Decay report.
        """
        start = time.time()
        report = DecayReport()

        all_memories = long_term.get_all_for_consolidation()
        report.memories_processed = len(all_memories)

        if not all_memories:
            report.duration_ms = (time.time() - start) * 1000
            return report.to_dict()

        scores_before: list[float] = []
        scores_after: list[float] = []
        updates: dict[str, float] = {}
        purge_ids: list[str] = []

        now = time.time()

        for memory in all_memories:
            old_score = memory.relevance_score
            scores_before.append(old_score)

            # Calculate decay
            new_score = self._compute_decayed_score(memory, now)
            scores_after.append(new_score)

            if abs(new_score - old_score) > 0.001:
                updates[memory.id] = new_score
                report.memories_decayed += 1

            if new_score < self._purge_threshold:
                purge_ids.append(memory.id)

        # Batch update scores
        if updates:
            long_term.batch_update_relevance(updates)

        # Purge very low-score memories
        for mem_id in purge_ids:
            try:
                long_term.delete(mem_id)
                report.memories_purged += 1
            except Exception as e:
                logger.warning("Failed to purge memory %s: %s", mem_id, e)

        # Compute averages
        if scores_before:
            report.avg_score_before = sum(scores_before) / len(scores_before)
        if scores_after:
            report.avg_score_after = sum(scores_after) / len(scores_after)

        report.duration_ms = (time.time() - start) * 1000

        logger.info(
            "Decay: %d processed, %d decayed, %d purged (avg %.3f → %.3f)",
            report.memories_processed,
            report.memories_decayed,
            report.memories_purged,
            report.avg_score_before,
            report.avg_score_after,
        )

        return report.to_dict()

    def compute_score(
        self,
        base_score: float,
        created_at: float,
        last_accessed: float,
        access_count: int,
    ) -> float:
        """Compute decayed score for a single memory.

        Args:
            base_score: Original relevance score.
            created_at: Creation timestamp.
            last_accessed: Last access timestamp.
            access_count: Number of times accessed.

        Returns:
            Decayed relevance score.
        """
        now = time.time()
        age = now - last_accessed
        return self._compute_score(base_score, age, access_count)

    def refresh_memory(self, memory: Memory) -> float:
        """Compute a refreshed score after access.

        Called when a memory is recalled to boost its score.

        Args:
            memory: The accessed memory.

        Returns:
            New relevance score after refresh boost.
        """
        new_score = min(1.0, memory.relevance_score + self._access_bonus)
        return new_score

    def _compute_decayed_score(self, memory: Memory, now: float) -> float:
        """Compute the decayed score for a memory."""
        last_accessed = memory.metadata.get("last_accessed", memory.metadata.get("created_at", now))
        age = now - last_accessed
        access_count = memory.access_count
        return self._compute_score(memory.relevance_score, age, access_count)

    def _compute_score(self, base_score: float, age: float, access_count: int) -> float:
        """Core decay computation.

        Args:
            base_score: Starting relevance score.
            age: Time since last access in seconds.
            access_count: Number of prior accesses.

        Returns:
            Decayed score, clamped to [min_score, 1.0].
        """
        # Frequency factor: more accesses = slower decay
        # log2(access_count + 1) gives: 0→0, 1→1, 3→2, 7→3, 15→4
        frequency_factor = 1.0 / (1.0 + math.log2(max(access_count, 1) + 1))

        # Exponential decay
        decay = math.exp(-self._rate * age * frequency_factor / 86400.0)  # Normalize to days
        new_score = base_score * decay

        # Clamp
        return max(self._min_score, min(1.0, new_score))

    def estimate_time_to_purge(
        self,
        current_score: float,
        access_count: int,
    ) -> float:
        """Estimate seconds until a memory would be purged.

        Useful for predicting memory lifetime.

        Args:
            current_score: Current relevance score.
            access_count: Current access count.

        Returns:
            Estimated seconds until purge threshold.
        """
        if current_score <= self._purge_threshold:
            return 0.0

        frequency_factor = 1.0 / (1.0 + math.log2(max(access_count, 1) + 1))

        # Solve: purge_threshold = current_score * e^(-rate * t * freq / 86400)
        # t = -ln(threshold / score) * 86400 / (rate * freq)
        ratio = self._purge_threshold / current_score
        if ratio <= 0:
            return float("inf")

        t = -math.log(ratio) * 86400.0 / (self._rate * frequency_factor)
        return max(0.0, t)
