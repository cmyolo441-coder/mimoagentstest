"""Memory retrieval with semantic search and ranking.

Combines vector similarity search with metadata-based filtering,
recency boosting, and access-frequency weighting to surface the
most relevant memories for a given query.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.memory.embedder import MemoryEmbedder
from terminal_agent.types import Memory, MemoryCategory

logger = logging.getLogger("terminal_agent.memory.retriever")


@dataclass
class RetrievalConfig:
    """Configuration for memory retrieval."""

    # Scoring weights
    similarity_weight: float = 0.6
    recency_weight: float = 0.2
    frequency_weight: float = 0.1
    relevance_weight: float = 0.1

    # Recency decay
    recency_half_life: float = 86400.0  # 24 hours in seconds

    # Result limits
    default_limit: int = 5
    max_limit: int = 50

    # Minimum scores
    min_similarity: float = 0.3


class MemoryRetriever:
    """Retrieves and ranks memories by relevance to a query.

    Uses a composite scoring function:
        score = w_sim * similarity
              + w_rec * recency_score
              + w_freq * frequency_score
              + w_rel * relevance_score

    Args:
        long_term: LongTermMemory instance for vector search.
        short_term: ShortTermMemory instance for recent context.
        memories_per_query: Default number of memories to retrieve.
        config: Optional retrieval configuration.
    """

    def __init__(
        self,
        long_term: Any,
        short_term: Any,
        memories_per_query: int = 5,
        config: RetrievalConfig | None = None,
    ) -> None:
        self._long_term = long_term
        self._short_term = short_term
        self._memories_per_query = memories_per_query
        self._config = config or RetrievalConfig()

    def retrieve(
        self,
        query: str,
        categories: list[MemoryCategory] | None = None,
        limit: int | None = None,
        min_similarity: float | None = None,
    ) -> list[Memory]:
        """Retrieve memories relevant to a query.

        Args:
            query: The search query text.
            categories: Optional category filter.
            limit: Maximum memories to return.
            min_similarity: Minimum similarity threshold.

        Returns:
            List of memories sorted by composite relevance score.
        """
        limit = limit or self._memories_per_query
        min_sim = min_similarity or self._config.min_similarity

        # Get query embedding
        try:
            from terminal_agent.memory.embedder import MemoryEmbedder
            embedder = self._long_term._embedder
            query_embedding = embedder.embed(query)
        except Exception as e:
            logger.error("Failed to embed query: %s", e)
            return []

        # Vector search (cast wider net for re-ranking)
        search_limit = min(limit * 3, self._config.max_limit)
        candidates = self._long_term.search(
            query_embedding=query_embedding,
            categories=categories,
            limit=search_limit,
            min_score=min_sim,
        )

        if not candidates:
            return []

        # Re-rank with composite scoring
        ranked = self._rank_memories(candidates, query)

        # Return top N
        return ranked[:limit]

    def retrieve_by_category(
        self,
        query: str,
        category: MemoryCategory,
        limit: int = 5,
    ) -> list[Memory]:
        """Retrieve memories from a specific category."""
        return self.retrieve(query, categories=[category], limit=limit)

    def retrieve_recent(
        self,
        limit: int = 10,
        categories: list[MemoryCategory] | None = None,
    ) -> list[Memory]:
        """Retrieve most recently created memories.

        Uses the in-memory index directly (no vector search).
        """
        all_memories = self._long_term.list_memories(
            category=categories[0] if categories and len(categories) == 1 else None,
            limit=limit * 2,
        )
        # Sort by created_at descending
        all_memories.sort(
            key=lambda m: m.metadata.get("created_at", 0),
            reverse=True,
        )
        return all_memories[:limit]

    def retrieve_similar_to_memory(
        self,
        memory: Memory,
        limit: int = 5,
        exclude_self: bool = True,
    ) -> list[Memory]:
        """Find memories similar to an existing memory.

        Useful for finding related memories or checking for duplicates.
        """
        results = self.retrieve(memory.content, limit=limit + 1)
        if exclude_self and memory.id:
            results = [m for m in results if m.id != memory.id]
        return results[:limit]

    def _rank_memories(self, memories: list[Memory], query: str) -> list[Memory]:
        """Re-rank memories using composite scoring."""
        now = time.time()
        cfg = self._config

        scored: list[tuple[float, Memory]] = []
        for mem in memories:
            # Similarity score (already from vector search)
            sim_score = mem.relevance_score

            # Recency score (exponential decay)
            created = mem.metadata.get("created_at", now)
            age = now - created
            recency_score = 2 ** (-age / cfg.recency_half_life)

            # Frequency score (log-scaled access count)
            freq_score = min(1.0, (mem.access_count + 1) / 20.0)

            # Base relevance (stored relevance_score, separate from sim)
            relevance_score = mem.metadata.get("relevance_score", 0.5)

            # Composite score
            composite = (
                cfg.similarity_weight * sim_score
                + cfg.recency_weight * recency_score
                + cfg.frequency_weight * freq_score
                + cfg.relevance_weight * relevance_score
            )

            scored.append((composite, mem))

        # Sort by composite score descending
        scored.sort(key=lambda x: x[0], reverse=True)

        # Update relevance scores on returned memories
        result: list[Memory] = []
        for score, mem in scored:
            mem.relevance_score = score
            result.append(mem)

        return result

    def explain_ranking(self, memory: Memory, query: str) -> dict[str, float]:
        """Explain how a memory was ranked for debugging.

        Returns a breakdown of score components.
        """
        now = time.time()
        cfg = self._config

        sim_score = memory.relevance_score
        created = memory.metadata.get("created_at", now)
        age = now - created
        recency_score = 2 ** (-age / cfg.recency_half_life)
        freq_score = min(1.0, (memory.access_count + 1) / 20.0)
        relevance_score = memory.metadata.get("relevance_score", 0.5)

        composite = (
            cfg.similarity_weight * sim_score
            + cfg.recency_weight * recency_score
            + cfg.frequency_weight * freq_score
            + cfg.relevance_weight * relevance_score
        )

        return {
            "similarity": sim_score,
            "recency": recency_score,
            "frequency": freq_score,
            "relevance": relevance_score,
            "composite": composite,
            "weights": {
                "similarity": cfg.similarity_weight,
                "recency": cfg.recency_weight,
                "frequency": cfg.frequency_weight,
                "relevance": cfg.relevance_weight,
            },
        }
