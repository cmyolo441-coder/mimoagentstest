"""Parameter validation for tool calls.

Validates tool parameters against JSON Schema definitions before
execution.  Supports type checking, required fields, enums, numeric
bounds, string patterns, and array constraints.
"""

from __future__ import annotations

import re
from typing import Any


class ParameterValidator:
    """Validate parameters against a JSON Schema-like definition.

    Supports a practical subset of JSON Schema:
    - ``type``: string, integer, number, boolean, array, object
    - ``required``: list of required property names
    - ``properties``: nested object schemas
    - ``enum``: allowed values
    - ``minimum`` / ``maximum``: numeric bounds
    - ``minLength`` / ``maxLength``: string length
    - ``pattern``: regex for strings
    - ``minItems`` / ``maxItems``: array length
    - ``items``: schema for array items
    """

    @staticmethod
    def validate(params: dict[str, Any], schema: dict[str, Any]) -> str | None:
        """Validate *params* against *schema*.

        Returns ``None`` on success, or a human-readable error message.
        """
        if not schema:
            return None

        # Check required fields
        required = schema.get("required", [])
        for field in required:
            if field not in params:
                return f"Missing required parameter: '{field}'"

        # Validate each provided parameter
        properties = schema.get("properties", {})
        for key, value in params.items():
            if key in properties:
                error = ParameterValidator._check_value(key, value, properties[key])
                if error:
                    return error
            elif not schema.get("additionalProperties", True):
                return f"Unknown parameter: '{key}'"

        return None

    @staticmethod
    def _check_value(name: str, value: Any, spec: dict[str, Any]) -> str | None:
        """Validate a single value against its schema spec."""
        expected_type = spec.get("type")

        if expected_type:
            type_ok = ParameterValidator._check_type(value, expected_type)
            if not type_ok:
                return f"Parameter '{name}' expected type '{expected_type}', got '{type(value).__name__}'"

        if value is None:
            return None  # type check already handled nullable

        # Enum check
        if "enum" in spec and value not in spec["enum"]:
            return f"Parameter '{name}' must be one of {spec['enum']}, got {value!r}"

        # Numeric bounds
        if expected_type in ("integer", "number"):
            if "minimum" in spec and value < spec["minimum"]:
                return f"Parameter '{name}' must be >= {spec['minimum']}, got {value}"
            if "maximum" in spec and value > spec["maximum"]:
                return f"Parameter '{name}' must be <= {spec['maximum']}, got {value}"

        # String constraints
        if expected_type == "string" and isinstance(value, str):
            if "minLength" in spec and len(value) < spec["minLength"]:
                return f"Parameter '{name}' must have at least {spec['minLength']} characters"
            if "maxLength" in spec and len(value) > spec["maxLength"]:
                return f"Parameter '{name}' must have at most {spec['maxLength']} characters"
            if "pattern" in spec and not re.search(spec["pattern"], value):
                return f"Parameter '{name}' does not match pattern '{spec['pattern']}'"

        # Array constraints
        if expected_type == "array" and isinstance(value, list):
            if "minItems" in spec and len(value) < spec["minItems"]:
                return f"Parameter '{name}' must have at least {spec['minItems']} items"
            if "maxItems" in spec and len(value) > spec["maxItems"]:
                return f"Parameter '{name}' must have at most {spec['maxItems']} items"
            if "items" in spec:
                for i, item in enumerate(value):
                    err = ParameterValidator._check_value(f"{name}[{i}]", item, spec["items"])
                    if err:
                        return err

        # Nested object
        if expected_type == "object" and isinstance(value, dict) and "properties" in spec:
            return ParameterValidator.validate(value, spec)

        return None

    @staticmethod
    def _check_type(value: Any, expected: str) -> bool:
        """Check if *value* matches the expected JSON Schema type."""
        if value is None:
            return True  # null is allowed unless explicitly forbidden
        mapping = {
            "string": str,
            "integer": int,
            "number": (int, float),
            "boolean": bool,
            "array": list,
            "object": dict,
        }
        python_type = mapping.get(expected)
        if python_type is None:
            return True  # unknown type → accept
        # bool is a subclass of int in Python, so check bool first
        if expected == "integer" and isinstance(value, bool):
            return False
        return isinstance(value, python_type)


class SafetyChecker:
    """Check tool parameters for safety concerns."""

    # Paths that should never be accessed
    RESTRICTED_PATHS = frozenset({
        "/etc/shadow",
        "/etc/passwd",
        "/etc/sudoers",
        "/boot",
        "/dev",
        "/proc",
        "/sys",
    })

    # Command patterns that are always dangerous
    DANGEROUS_PATTERNS = [
        r"rm\s+-rf\s+/",
        r"dd\s+if=/dev/(zero|urandom|random)",
        r"mkfs\.",
        r":\(\)\s*\{.*\|.*&\s*\};\s*:",  # fork bomb
        r"chmod\s+777",
        r">\s*/dev/sd",
        r"shutdown",
        r"reboot",
        r"init\s+0",
        r"halt",
        r"poweroff",
    ]

    @staticmethod
    def check_command_safety(command: str, safety_level: int) -> str | None:
        """Check if a shell command is safe.

        Returns ``None`` if safe, or a reason string to block.
        """
        if safety_level <= 1:
            return None  # unrestricted / minimal

        for pattern in SafetyChecker.DANGEROUS_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                return f"Command matches dangerous pattern: {pattern}"

        if safety_level >= 3:
            # Moderate+: check for destructive keywords
            destructive = ["rm ", "rmdir ", "mv ", "chmod ", "chown ", "kill", "pkill"]
            for keyword in destructive:
                if keyword in command:
                    return f"Command contains potentially destructive keyword: '{keyword.strip()}'"

        return None

    @staticmethod
    def check_path_safety(path: str) -> str | None:
        """Check if a filesystem path is safe to access.

        Returns ``None`` if safe, or a reason string to block.
        """
        from pathlib import Path

        resolved = str(Path(path).resolve())
        for restricted in SafetyChecker.RESTRICTED_PATHS:
            if resolved.startswith(restricted):
                return f"Access to restricted path: {restricted}"
        return None
