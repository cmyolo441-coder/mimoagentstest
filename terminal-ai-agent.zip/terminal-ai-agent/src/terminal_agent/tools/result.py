"""Tool result builder for consistent result construction."""

from __future__ import annotations

from typing import Any

from terminal_agent.types import ToolResult, ToolResultStatus


class ToolResultBuilder:
    """Fluent builder for creating ToolResult instances.

    Usage:
        result = (ToolResultBuilder()
            .success("File created successfully")
            .with_output("contents...")
            .with_side_effect("created file: /path/to/file")
            .build())
    """

    def __init__(self) -> None:
        self._status = ToolResultStatus.SUCCESS
        self._output = ""
        self._error: str | None = None
        self._exit_code = 0
        self._duration_ms = 0.0
        self._side_effects: list[str] = []
        self._metadata: dict[str, Any] = {}

    def success(self, output: str = "") -> ToolResultBuilder:
        """Mark result as success."""
        self._status = ToolResultStatus.SUCCESS
        self._output = output
        self._exit_code = 0
        return self

    def partial(self, output: str = "") -> ToolResultBuilder:
        """Mark result as partial success."""
        self._status = ToolResultStatus.PARTIAL
        self._output = output
        return self

    def failure(self, error: str) -> ToolResultBuilder:
        """Mark result as failure."""
        self._status = ToolResultStatus.FAILURE
        self._error = error
        self._exit_code = 1
        return self

    def error(self, error: str, exit_code: int = 1) -> ToolResultBuilder:
        """Mark result as error."""
        self._status = ToolResultStatus.ERROR
        self._error = error
        self._exit_code = exit_code
        return self

    def timeout(self, error: str = "Operation timed out") -> ToolResultBuilder:
        """Mark result as timeout."""
        self._status = ToolResultStatus.TIMEOUT
        self._error = error
        self._exit_code = 124
        return self

    def blocked(self, reason: str) -> ToolResultBuilder:
        """Mark result as blocked by safety system."""
        self._status = ToolResultStatus.BLOCKED
        self._error = reason
        self._exit_code = 1
        return self

    def with_output(self, output: str) -> ToolResultBuilder:
        """Set the output text."""
        self._output = output
        return self

    def with_exit_code(self, code: int) -> ToolResultBuilder:
        """Set the exit code."""
        self._exit_code = code
        if code != 0 and self._status == ToolResultStatus.SUCCESS:
            self._status = ToolResultStatus.ERROR
        return self

    def with_duration(self, ms: float) -> ToolResultBuilder:
        """Set the duration in milliseconds."""
        self._duration_ms = ms
        return self

    def with_side_effect(self, effect: str) -> ToolResultBuilder:
        """Add a side effect description."""
        self._side_effects.append(effect)
        return self

    def with_side_effects(self, effects: list[str]) -> ToolResultBuilder:
        """Add multiple side effect descriptions."""
        self._side_effects.extend(effects)
        return self

    def with_metadata(self, key: str, value: Any) -> ToolResultBuilder:
        """Add metadata entry."""
        self._metadata[key] = value
        return self

    def with_metadata_dict(self, metadata: dict[str, Any]) -> ToolResultBuilder:
        """Add multiple metadata entries."""
        self._metadata.update(metadata)
        return self

    def build(self) -> ToolResult:
        """Build the ToolResult."""
        return ToolResult(
            status=self._status,
            output=self._output,
            error=self._error,
            exit_code=self._exit_code,
            duration_ms=self._duration_ms,
            side_effects=self._side_effects,
            metadata=self._metadata,
        )

    # Convenience class methods
    @classmethod
    def ok(cls, output: str = "", **metadata: Any) -> ToolResult:
        """Quick success result."""
        builder = cls().success(output)
        for k, v in metadata.items():
            builder.with_metadata(k, v)
        return builder.build()

    @classmethod
    def fail(cls, error: str, **metadata: Any) -> ToolResult:
        """Quick failure result."""
        builder = cls().failure(error)
        for k, v in metadata.items():
            builder.with_metadata(k, v)
        return builder.build()

    @classmethod
    def err(cls, error: str, exit_code: int = 1, **metadata: Any) -> ToolResult:
        """Quick error result."""
        builder = cls().error(error, exit_code)
        for k, v in metadata.items():
            builder.with_metadata(k, v)
        return builder.build()
