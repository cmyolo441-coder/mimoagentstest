"""Tool registry — discovery, registration, and lookup.

Central catalog of all available tools.  Tools register themselves
either by explicit ``register()`` calls or via auto-discovery at
startup.  The registry is the single source of truth for the
dispatcher and for LLM function-calling schemas.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
from typing import Any

from terminal_agent.tools.base_tool import BaseTool
from terminal_agent.types import SafetyLevel

logger = logging.getLogger("terminal_agent.tools.registry")


class ToolRegistry:
    """Manages the collection of available tools.

    Typical usage::

        registry = ToolRegistry()
        registry.register(my_tool)
        tool = registry.get("shell.execute")
        schemas = registry.get_schemas()
    """

    def __init__(self) -> None:
        self._tools: dict[str, BaseTool] = {}
        self._categories: dict[str, list[str]] = {}

    # ── registration ──────────────────────────────────────────────

    def register(self, tool: BaseTool) -> None:
        """Register a single tool instance.

        Raises ``ValueError`` if a tool with the same name is already
        registered (prevents accidental shadowing).
        """
        if tool.name in self._tools:
            raise ValueError(
                f"Tool '{tool.name}' is already registered. "
                "Use unregister() first if replacement is intended."
            )
        self._tools[tool.name] = tool
        self._categories.setdefault(tool.category, []).append(tool.name)
        logger.debug("Registered tool: %s (category=%s)", tool.name, tool.category)

    def unregister(self, name: str) -> None:
        """Remove a tool from the registry."""
        tool = self._tools.pop(name, None)
        if tool and tool.category in self._categories:
            cat_list = self._categories[tool.category]
            if name in cat_list:
                cat_list.remove(name)
            if not cat_list:
                del self._categories[tool.category]

    # ── lookup ────────────────────────────────────────────────────

    def get(self, name: str) -> BaseTool | None:
        """Get a tool by name, or ``None`` if not found."""
        return self._tools.get(name)

    def get_required(self, name: str) -> BaseTool:
        """Get a tool by name, raising ``KeyError`` if not found."""
        tool = self._tools.get(name)
        if tool is None:
            raise KeyError(f"Tool '{name}' not found in registry")
        return tool

    def has(self, name: str) -> bool:
        """Check whether a tool is registered."""
        return name in self._tools

    # ── listing ───────────────────────────────────────────────────

    def list_tools(self) -> list[str]:
        """Return sorted list of all registered tool names."""
        return sorted(self._tools.keys())

    def list_categories(self) -> list[str]:
        """Return sorted list of all categories."""
        return sorted(self._categories.keys())

    def get_tools_by_category(self, category: str) -> list[BaseTool]:
        """Return all tools in a given category."""
        names = self._categories.get(category, [])
        return [self._tools[n] for n in names if n in self._tools]

    def get_schemas(self, safety_level: SafetyLevel = SafetyLevel.UNRESTRICTED) -> list[dict[str, Any]]:
        """Return JSON schemas for all tools allowed at *safety_level*.

        Used by the LLM engine to build function-calling definitions.
        """
        schemas = []
        for tool in sorted(self._tools.values(), key=lambda t: t.name):
            if tool.min_safety_level <= safety_level:
                schemas.append(tool.get_schema())
        return schemas

    def count(self) -> int:
        """Number of registered tools."""
        return len(self._tools)

    # ── auto-discovery ────────────────────────────────────────────

    def discover(
        self,
        *package_names: str,
        safety_level: SafetyLevel = SafetyLevel.UNRESTRICTED,
    ) -> int:
        """Auto-discover and register tools from Python packages.

        Each package is scanned for modules that define a top-level
        ``TOOL_INSTANCE: BaseTool`` variable.  Returns the number of
        tools registered.
        """
        count = 0
        for pkg_name in package_names:
            try:
                count += self._discover_package(pkg_name, safety_level)
            except Exception:
                logger.exception("Failed to discover tools in package: %s", pkg_name)
        return count

    def _discover_package(
        self,
        pkg_name: str,
        safety_level: SafetyLevel,
    ) -> int:
        """Scan a single package for tool instances."""
        try:
            package = importlib.import_module(pkg_name)
        except ImportError:
            logger.warning("Package not found: %s", pkg_name)
            return 0

        if not hasattr(package, "__path__"):
            return 0

        count = 0
        for importer, modname, _ispkg in pkgutil.walk_packages(
            path=package.__path__,
            prefix=package.__name__ + ".",
        ):
            try:
                module = importlib.import_module(modname)
                instance = getattr(module, "TOOL_INSTANCE", None)
                if isinstance(instance, BaseTool):
                    if instance.min_safety_level <= safety_level:
                        if not self.has(instance.name):
                            self.register(instance)
                            count += 1
            except Exception:
                logger.debug("Skipping module %s (import error)", modname, exc_info=True)

        return count

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __repr__(self) -> str:
        return f"<ToolRegistry tools={len(self._tools)} categories={len(self._categories)}>"
