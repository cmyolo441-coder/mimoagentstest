"""Tool infrastructure for Terminal Agent.

This package provides the tool registry, dispatcher, base classes,
and built-in tool implementations for shell, filesystem, and more.

Quick start::

    from terminal_agent.tools import ToolRegistry, ToolDispatcher

    registry = ToolRegistry()
    registry.discover("terminal_agent.tools.shell", "terminal_agent.tools.filesystem")
    dispatcher = ToolDispatcher(registry)
    result = await dispatcher.dispatch(tool_call)
"""

from terminal_agent.tools.base_tool import BaseTool
from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.resource_limiter import ResourceLimiter, ResourceLimits, ResourceTracker
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import ToolResultStatus, ToolResult
from terminal_agent.tools.timeout import TimeoutBudget, TimeoutConfig, with_timeout
from terminal_agent.tools.validator import ParameterValidator, SafetyChecker

__all__ = [
    "BaseTool",
    "ParameterValidator",
    "ResourceLimiter",
    "ResourceLimits",
    "ResourceTracker",
    "ToolResultStatus",
    "SafetyChecker",
    "TimeoutBudget",
    "TimeoutConfig",
    "ToolDispatcher",
    "ToolRegistry",
    "ToolResult",
    "with_timeout",
]
