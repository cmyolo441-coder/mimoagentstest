"""Tool dispatcher — routes tool calls to the correct tool instance.

The dispatcher sits between the orchestrator/LLM and the tool registry.
It resolves tool names, validates parameters, enforces safety, applies
timeouts, and returns structured ``ToolResult`` objects.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResult
from terminal_agent.types import SafetyLevel, ToolCall

logger = logging.getLogger("terminal_agent.tools.dispatcher")


class ToolDispatcher:
    """Route ``ToolCall`` objects to registered tools and return results.

    Usage::

        dispatcher = ToolDispatcher(registry, safety_level=SafetyLevel.STANDARD)
        result = await dispatcher.dispatch(ToolCall(name="shell.execute", parameters={"command": "ls"}))
    """

    def __init__(
        self,
        registry: ToolRegistry,
        safety_level: SafetyLevel = SafetyLevel.STANDARD,
    ) -> None:
        self.registry = registry
        self.safety_level = safety_level
        self._call_history: list[dict[str, Any]] = []

    async def dispatch(self, call: ToolCall) -> ToolResult:
        """Dispatch a single tool call.

        Steps:
        1. Look up the tool in the registry
        2. Check safety level
        3. Delegate to ``tool.run()`` (validation + safety + execution)
        4. Record the call in history
        5. Return the ``ToolResult``
        """
        start = time.monotonic()

        # 1. Lookup
        tool = self.registry.get(call.name)
        if tool is None:
            return ToolResult.error(
                f"Unknown tool: '{call.name}'. "
                f"Available: {', '.join(self.registry.list_tools()[:20])}…",
                duration_ms=_ms(start),
            )

        # 2. Safety level gate
        if tool.min_safety_level > self.safety_level:
            return ToolResult.blocked(
                f"Tool '{call.name}' requires safety level "
                f"{tool.min_safety_level.name}, current level is {self.safety_level.name}",
                duration_ms=_ms(start),
            )

        # 3. Execute (validation + safety + timeout handled by BaseTool.run)
        logger.info("Dispatching tool: %s", call.name)
        logger.debug("Parameters: %s", call.parameters)
        result = await tool.run(**call.parameters)

        # 4. Record
        self._call_history.append({
            "tool": call.name,
            "parameters": call.parameters,
            "status": result.status.value,
            "exit_code": result.exit_code,
            "duration_ms": result.duration_ms,
            "truncated": result.truncated,
        })

        logger.info(
            "Tool %s completed: status=%s duration=%.1fms",
            call.name,
            result.status.value,
            result.duration_ms,
        )

        return result

    async def dispatch_many(self, calls: list[ToolCall]) -> list[ToolResult]:
        """Dispatch multiple tool calls sequentially.

        For parallel execution, use ``dispatch_parallel``.
        """
        return [await self.dispatch(call) for call in calls]

    async def dispatch_parallel(
        self,
        calls: list[ToolCall],
        max_concurrency: int = 5,
    ) -> list[ToolResult]:
        """Dispatch multiple tool calls concurrently.

        Uses a semaphore to limit concurrency.
        """
        import asyncio

        semaphore = asyncio.Semaphore(max_concurrency)

        async def _limited(call: ToolCall) -> ToolResult:
            async with semaphore:
                return await self.dispatch(call)

        return await asyncio.gather(*[_limited(c) for c in calls])

    @property
    def call_history(self) -> list[dict[str, Any]]:
        """Return the full call history for this dispatcher."""
        return list(self._call_history)

    def reset_history(self) -> None:
        """Clear call history."""
        self._call_history.clear()


def _ms(start: float) -> float:
    return (time.monotonic() - start) * 1000
