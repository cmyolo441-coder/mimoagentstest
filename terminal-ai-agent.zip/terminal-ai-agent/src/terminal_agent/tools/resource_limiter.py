"""Resource limiter for tool execution.

Enforces limits on memory, CPU time, output size, file size, and
process counts to prevent runaway tools from consuming system resources.
"""

from __future__ import annotations

import asyncio
import os
import resource
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.constants import DEFAULT_SHELL_MAX_OUTPUT, DEFAULT_FILESYSTEM_MAX_READ


@dataclass
class ResourceLimits:
    """Resource limits for a single tool execution.

    Attributes:
        max_output_bytes: Maximum output size in bytes (stdout + stderr).
        max_read_bytes: Maximum bytes to read from a single file.
        max_memory_mb: Maximum RSS memory in MB (0 = unlimited).
        max_cpu_seconds: Maximum CPU seconds (0 = unlimited).
        max_open_files: Maximum number of open file descriptors.
        max_processes: Maximum child processes (0 = unlimited).
    """

    max_output_bytes: int = DEFAULT_SHELL_MAX_OUTPUT
    max_read_bytes: int = DEFAULT_FILESYSTEM_MAX_READ
    max_memory_mb: int = 0
    max_cpu_seconds: int = 0
    max_open_files: int = 256
    max_processes: int = 0

    @classmethod
    def conservative(cls) -> ResourceLimits:
        """Conservative limits for untrusted code execution."""
        return cls(
            max_output_bytes=50_000,
            max_read_bytes=500_000,
            max_memory_mb=256,
            max_cpu_seconds=60,
            max_open_files=64,
            max_processes=4,
        )

    @classmethod
    def permissive(cls) -> ResourceLimits:
        """Permissive limits for trusted operations."""
        return cls(
            max_output_bytes=5_000_000,
            max_read_bytes=50_000_000,
            max_memory_mb=0,
            max_cpu_seconds=0,
            max_open_files=1024,
            max_processes=0,
        )


class ResourceLimiter:
    """Enforce resource limits on child processes (Unix only).

    Uses ``resource.setrlimit`` on the forked child via ``preexec_fn``
    so the parent process is unaffected.
    """

    def __init__(self, limits: ResourceLimits | None = None) -> None:
        self.limits = limits or ResourceLimits()

    def get_preexec_fn(self) -> callable | None:
        """Return a ``preexec_fn`` for ``asyncio.create_subprocess_exec``.

        Returns ``None`` on non-Unix platforms or when no limits are set.
        """
        if os.name != "nt":
            return None  # Windows doesn't support setrlimit

        limits = self.limits

        def _set_limits() -> None:
            # CPU time
            if limits.max_cpu_seconds > 0:
                resource.setrlimit(
                    resource.RLIMIT_CPU,
                    (limits.max_cpu_seconds, limits.max_cpu_seconds),
                )
            # Memory
            if limits.max_memory_mb > 0:
                mem_bytes = limits.max_memory_mb * 1024 * 1024
                resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
            # Open files
            if limits.max_open_files > 0:
                resource.setrlimit(
                    resource.RLIMIT_NOFILE,
                    (limits.max_open_files, limits.max_open_files),
                )
            # File size (prevent writing huge files)
            resource.setrlimit(
                resource.RLIMIT_FSIZE,
                (limits.max_output_bytes, limits.max_output_bytes),
            )

        return _set_limits

    def truncate_output(self, data: bytes) -> tuple[bytes, bool]:
        """Truncate *data* to ``max_output_bytes``.

        Returns ``(truncated_data, was_truncated)``.
        """
        if len(data) <= self.limits.max_output_bytes:
            return data, False
        half = self.limits.max_output_bytes // 2
        return (
            data[:half]
            + f"\n\n... [truncated {len(data) - self.limits.max_output_bytes} bytes] ...\n\n".encode()
            + data[-half:],
            True,
        )

    def truncate_text(self, text: str) -> tuple[str, bool]:
        """Truncate a string to ``max_output_bytes`` (approximate char count).

        Returns ``(truncated_text, was_truncated)``.
        """
        max_chars = self.limits.max_output_bytes
        if len(text) <= max_chars:
            return text, False
        half = max_chars // 2
        return (
            text[:half]
            + f"\n\n... [truncated {len(text) - max_chars} chars] ...\n\n"
            + text[-half:],
            True,
        )


@dataclass
class ResourceTracker:
    """Track cumulative resource usage across multiple tool calls.

    Useful for monitoring total cost of a session.
    """

    total_output_bytes: int = 0
    total_read_bytes: int = 0
    total_cpu_seconds: float = 0.0
    total_wall_seconds: float = 0.0
    tool_calls: int = 0

    def record(
        self,
        *,
        output_bytes: int = 0,
        read_bytes: int = 0,
        cpu_seconds: float = 0.0,
        wall_seconds: float = 0.0,
    ) -> None:
        """Record resource usage from a single tool call."""
        self.total_output_bytes += output_bytes
        self.total_read_bytes += read_bytes
        self.total_cpu_seconds += cpu_seconds
        self.total_wall_seconds += wall_seconds
        self.tool_calls += 1

    def summary(self) -> dict[str, Any]:
        """Return a summary dict."""
        return {
            "tool_calls": self.tool_calls,
            "total_output_bytes": self.total_output_bytes,
            "total_read_bytes": self.total_read_bytes,
            "total_cpu_seconds": round(self.total_cpu_seconds, 2),
            "total_wall_seconds": round(self.total_wall_seconds, 2),
        }
