"""Timeout management for tool execution.

Provides configurable timeout enforcement for async operations,
including per-tool overrides and a global default.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Awaitable

from terminal_agent.constants import DEFAULT_SHELL_TIMEOUT


@dataclass
class TimeoutConfig:
    """Timeout configuration for a tool or category.

    Attributes:
        timeout_seconds: Maximum wall-clock seconds before cancellation.
        kill_after: Seconds after SIGTERM before SIGKILL (process tools).
        warn_at: Fraction (0-1) of timeout at which to emit a warning.
    """

    timeout_seconds: float = float(DEFAULT_SHELL_TIMEOUT)
    kill_after: float = 5.0
    warn_at: float = 0.8

    @classmethod
    def quick(cls) -> TimeoutConfig:
        """Short timeout for fast operations (metadata, stat)."""
        return cls(timeout_seconds=10.0)

    @classmethod
    def standard(cls) -> TimeoutConfig:
        """Standard timeout for normal operations."""
        return cls(timeout_seconds=300.0)

    @classmethod
    def long(cls) -> TimeoutConfig:
        """Long timeout for build/test operations."""
        return cls(timeout_seconds=1800.0)

    @classmethod
    def infinite(cls) -> TimeoutConfig:
        """No timeout (use with caution)."""
        return cls(timeout_seconds=0.0)


async def with_timeout(
    coro: Awaitable[Any],
    *,
    timeout_seconds: float,
    tool_name: str = "unknown",
) -> Any:
    """Await *coro* with a wall-clock timeout.

    Raises ``TimeoutError`` if the coroutine does not complete within
    *timeout_seconds*.  A timeout of 0 or negative means no limit.
    """
    if timeout_seconds <= 0:
        return await coro

    try:
        return await asyncio.wait_for(coro, timeout=timeout_seconds)
    except asyncio.TimeoutError:
        raise TimeoutError(
            f"Tool '{tool_name}' timed out after {timeout_seconds}s"
        ) from None


async def run_with_timeout_and_kill(
    proc: asyncio.subprocess.Process,
    *,
    timeout_seconds: float,
    kill_after: float = 5.0,
) -> tuple[bytes, bytes]:
    """Run a subprocess with timeout, escalating from SIGTERM to SIGKILL.

    Returns ``(stdout, stderr)``.
    Raises ``TimeoutError`` if the process cannot be killed within the grace period.
    """
    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=timeout_seconds
        )
        return stdout, stderr
    except asyncio.TimeoutError:
        # Graceful termination
        proc.terminate()
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=kill_after
            )
            return stdout, stderr
        except asyncio.TimeoutError:
            # Force kill
            proc.kill()
            stdout, stderr = await proc.communicate()
            return stdout, stderr


class TimeoutBudget:
    """Track cumulative time spent and enforce a total budget.

    Useful when a tool makes multiple sub-calls that together must
    not exceed a total time limit.
    """

    def __init__(self, total_seconds: float) -> None:
        self._total = total_seconds
        self._start = asyncio.get_event_loop().time() if asyncio.get_event_loop().is_running() else 0.0
        self._paused_at: float | None = None
        self._paused_elapsed: float = 0.0

    @property
    def elapsed(self) -> float:
        """Seconds elapsed since creation (excluding paused time)."""
        if self._paused_at is not None:
            return self._paused_elapsed
        return self._paused_elapsed + (asyncio.get_event_loop().time() - self._start)

    @property
    def remaining(self) -> float:
        """Seconds remaining in the budget. 0 if exhausted."""
        return max(0.0, self._total - self.elapsed)

    @property
    def exhausted(self) -> bool:
        """Whether the budget has been used up."""
        return self.remaining <= 0

    def pause(self) -> None:
        """Pause the budget clock."""
        if self._paused_at is None:
            self._paused_at = asyncio.get_event_loop().time()

    def resume(self) -> None:
        """Resume the budget clock."""
        if self._paused_at is not None:
            self._paused_elapsed += asyncio.get_event_loop().time() - self._paused_at
            self._paused_at = None
