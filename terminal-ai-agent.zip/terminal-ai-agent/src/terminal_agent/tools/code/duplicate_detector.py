"""Duplicate code detection.

Identifies copy-pasted or near-duplicate code blocks using token-based
comparison and normalized hashing.
"""

from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class DuplicateBlock:
    """A block of duplicated code."""

    file_path: str
    start_line: int
    end_line: int
    content: str
    hash: str = ""

    @property
    def line_count(self) -> int:
        return self.end_line - self.start_line + 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "file_path": self.file_path,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "line_count": self.line_count,
            "hash": self.hash,
        }


@dataclass
class DuplicateGroup:
    """A group of duplicate code blocks."""

    blocks: list[DuplicateBlock] = field(default_factory=list)
    hash: str = ""
    line_count: int = 0

    @property
    def occurrence_count(self) -> int:
        return len(self.blocks)

    @property
    def files_involved(self) -> list[str]:
        return list(set(b.file_path for b in self.blocks))

    @property
    def total_duplicate_lines(self) -> int:
        return self.line_count * (self.occurrence_count - 1)

    def to_dict(self) -> dict[str, Any]:
        return {
            "hash": self.hash,
            "line_count": self.line_count,
            "occurrence_count": self.occurrence_count,
            "files_involved": self.files_involved,
            "total_duplicate_lines": self.total_duplicate_lines,
            "blocks": [b.to_dict() for b in self.blocks],
        }


@dataclass
class DuplicateReport:
    """Report of duplicate code in a project."""

    groups: list[DuplicateGroup] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def total_groups(self) -> int:
        return len(self.groups)

    @property
    def total_duplicate_lines(self) -> int:
        return sum(g.total_duplicate_lines for g in self.groups)

    @property
    def worst_offenders(self) -> list[DuplicateGroup]:
        """Return groups sorted by total duplicate lines (descending)."""
        return sorted(self.groups, key=lambda g: g.total_duplicate_lines, reverse=True)

    def summary(self) -> str:
        lines = [
            f"Duplicate code report: {self.total_groups} group(s), "
            f"{self.total_duplicate_lines} duplicate line(s)",
        ]
        for group in self.worst_offenders[:10]:
            lines.append(
                f"  {group.line_count} lines x {group.occurrence_count} occurrences "
                f"in {', '.join(group.files_involved)}"
            )
        return "\n".join(lines)


class DuplicateDetector:
    """Detect duplicate code blocks.

    Usage::

        detector = DuplicateDetector()

        # Detect duplicates in a directory
        report = detector.detect(Path("src/"))

        # Show results
        print(report.summary())
        for group in report.worst_offenders:
            for block in group.blocks:
                print(f"  {block.file_path}:{block.start_line}-{block.end_line}")
    """

    def __init__(self, *, min_lines: int = 5, min_tokens: int = 20) -> None:
        """Initialize the detector.

        Parameters:
            min_lines: Minimum number of consecutive lines to consider.
            min_tokens: Minimum number of tokens in a block to consider.
        """
        self.min_lines = min_lines
        self.min_tokens = min_tokens

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def detect(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        max_files: int = 2000,
    ) -> DuplicateReport:
        """Detect duplicate code in *directory*.

        Parameters:
            directory: Root directory to scan.
            extensions: File extensions to include.
            exclude_patterns: Path substrings to skip.
            max_files: Maximum number of files to process.

        Returns:
            A :class:`DuplicateReport`.
        """
        if extensions is None:
            extensions = {".py", ".js", ".ts", ".go", ".rs", ".java", ".c", ".cpp",
                         ".rb", ".php", ".swift", ".kt", ".scala", ".lua", ".dart"}
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build", ".tox"}

        # Collect all code blocks
        blocks: list[DuplicateBlock] = []
        file_count = 0

        for path in sorted(directory.rglob("*")):
            if file_count >= max_files:
                break
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue
            file_count += 1

            file_blocks = self._extract_blocks(path)
            blocks.extend(file_blocks)

        if not blocks:
            return DuplicateReport(errors=["No code blocks found"])

        # Group blocks by hash
        hash_groups: dict[str, list[DuplicateBlock]] = {}
        for block in blocks:
            hash_groups.setdefault(block.hash, []).append(block)

        # Build duplicate groups (only groups with 2+ occurrences)
        groups: list[DuplicateGroup] = []
        for hash_val, group_blocks in hash_groups.items():
            if len(group_blocks) >= 2:
                groups.append(DuplicateGroup(
                    blocks=group_blocks,
                    hash=hash_val,
                    line_count=group_blocks[0].line_count,
                ))

        return DuplicateReport(groups=groups)

    def detect_in_files(self, paths: list[Path]) -> DuplicateReport:
        """Detect duplicates across specific files."""
        blocks: list[DuplicateBlock] = []
        for path in paths:
            if path.is_file():
                blocks.extend(self._extract_blocks(path))

        hash_groups: dict[str, list[DuplicateBlock]] = {}
        for block in blocks:
            hash_groups.setdefault(block.hash, []).append(block)

        groups: list[DuplicateGroup] = []
        for hash_val, group_blocks in hash_groups.items():
            if len(group_blocks) >= 2:
                groups.append(DuplicateGroup(
                    blocks=group_blocks,
                    hash=hash_val,
                    line_count=group_blocks[0].line_count,
                ))

        return DuplicateReport(groups=groups)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _extract_blocks(self, path: Path) -> list[DuplicateBlock]:
        """Extract normalized code blocks from a file."""
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            return []

        lines = source.splitlines()
        blocks: list[DuplicateBlock] = []

        # Slide a window of min_lines over the file
        for i in range(len(lines) - self.min_lines + 1):
            window = lines[i : i + self.min_lines]

            # Normalize the block (strip whitespace, remove comments)
            normalized = self._normalize_block(window, path.suffix.lower())

            # Skip trivially small blocks
            if len(normalized.strip()) < 50:
                continue

            # Compute hash
            block_hash = hashlib.md5(normalized.encode("utf-8")).hexdigest()[:16]

            content = "\n".join(window)
            blocks.append(DuplicateBlock(
                file_path=str(path),
                start_line=i + 1,
                end_line=i + self.min_lines,
                content=content,
                hash=block_hash,
            ))

        return blocks

    @staticmethod
    def _normalize_block(lines: list[str], ext: str) -> str:
        """Normalize a code block for comparison.

        Strips whitespace, removes comments, and normalizes variable names
        to reduce false negatives from trivial differences.
        """
        normalized = []

        for line in lines:
            # Strip leading/trailing whitespace
            stripped = line.strip()

            # Skip empty lines and comments
            if not stripped:
                continue
            if ext in (".py", ".rb", ".r", ".R", ".lua") and stripped.startswith("#"):
                continue
            if ext in (".js", ".ts", ".java", ".c", ".cpp", ".go", ".rs", ".swift", ".kt") and stripped.startswith("//"):
                continue

            # Normalize: collapse multiple spaces
            stripped = re.sub(r"\s+", " ", stripped)

            normalized.append(stripped)

        return "\n".join(normalized)

    def _tokenize(self, source: str) -> list[str]:
        """Tokenize source code into identifier-neutral tokens."""
        # Replace all identifiers with a generic placeholder
        # This allows detecting duplicates even with different variable names
        tokens = []
        current = []
        for ch in source:
            if ch.isalnum() or ch == "_":
                current.append(ch)
            else:
                if current:
                    word = "".join(current)
                    if word[0].isalpha() or word[0] == "_":
                        tokens.append("ID")  # Identifier placeholder
                    else:
                        tokens.append(word)
                    current = []
                tokens.append(ch)
        if current:
            word = "".join(current)
            tokens.append("ID" if (word[0].isalpha() or word[0] == "_") else word)
        return tokens
