"""Code formatting integration.

Wraps external formatters (black, prettier, gofmt, rustfmt, clang-format,
etc.) with a unified interface and provides a built-in fallback formatter.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Map of file extensions to formatter commands and their args
_FORMATTER_MAP: dict[str, dict[str, Any]] = {
    ".py": {"cmd": ["black", "--quiet", "--line-length", "88"], "name": "black"},
    ".pyi": {"cmd": ["black", "--quiet", "--line-length", "88"], "name": "black"},
    ".js": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".jsx": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".ts": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".tsx": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".mjs": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".css": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".scss": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".html": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".json": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".yaml": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".yml": {"cmd": ["prettier", "--write"], "name": "prettier"},
    ".md": {"cmd": ["prettier", "--write", "--prose-wrap", "always"], "name": "prettier"},
    ".go": {"cmd": ["gofmt", "-w"], "name": "gofmt"},
    ".rs": {"cmd": ["rustfmt"], "name": "rustfmt"},
    ".c": {"cmd": ["clang-format", "-i", "--style=file"], "name": "clang-format"},
    ".h": {"cmd": ["clang-format", "-i", "--style=file"], "name": "clang-format"},
    ".cpp": {"cmd": ["clang-format", "-i", "--style=file"], "name": "clang-format"},
    ".cxx": {"cmd": ["clang-format", "-i", "--style=file"], "name": "clang-format"},
    ".cc": {"cmd": ["clang-format", "-i", "--style=file"], "name": "clang-format"},
    ".hpp": {"cmd": ["clang-format", "-i", "--style=file"], "name": "clang-format"},
    ".java": {"cmd": ["google-java-format", "-i"], "name": "google-java-format"},
    ".rb": {"cmd": ["rubocop", "-A", "--format", "quiet"], "name": "rubocop"},
    ".swift": {"cmd": ["swift-format", "format", "-i"], "name": "swift-format"},
    ".dart": {"cmd": ["dart", "format"], "name": "dart format"},
    ".lua": {"cmd": ["stylua"], "name": "stylua"},
    ".zig": {"cmd": ["zig", "fmt"], "name": "zig fmt"},
    ".ex": {"cmd": ["mix", "format"], "name": "mix format"},
    ".exs": {"cmd": ["mix", "format"], "name": "mix format"},
    ".r": {"cmd": ["Rscript", "-e", "styler::style_file('{file}')"], "name": "styler"},
    ".R": {"cmd": ["Rscript", "-e", "styler::style_file('{file}')"], "name": "styler"},
    ".scala": {"cmd": ["scalafmt"], "name": "scalafmt"},
    ".hs": {"cmd": ["ormolu", "--mode", "inplace"], "name": "ormolu"},
    ".php": {"cmd": ["php-cs-fixer", "fix", "--quiet"], "name": "php-cs-fixer"},
    ".cs": {"cmd": ["dotnet", "format"], "name": "dotnet format"},
    ".kt": {"cmd": ["ktlint", "-F"], "name": "ktlint"},
    ".kts": {"cmd": ["ktlint", "-F"], "name": "ktlint"},
}


@dataclass
class FormatResult:
    """Result of a formatting operation."""

    success: bool
    file_path: str = ""
    formatter: str = ""
    changed: bool = False
    original: str = ""
    formatted: str = ""
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def diff(self) -> str:
        """Return a simple diff of the changes."""
        if not self.changed:
            return "(no changes)"
        import difflib
        diff = difflib.unified_diff(
            self.original.splitlines(keepends=True),
            self.formatted.splitlines(keepends=True),
            fromfile=f"a/{self.file_path}",
            tofile=f"b/{self.file_path}",
        )
        return "".join(diff)

    def summary(self) -> str:
        status = "formatted" if self.changed else "already formatted"
        lines = [f"{self.file_path}: {status} ({self.formatter})"]
        if self.errors:
            for e in self.errors:
                lines.append(f"  Error: {e}")
        return "\n".join(lines)


class CodeFormatter:
    """Format source code using language-specific formatters.

    Usage::

        formatter = CodeFormatter()

        # Format a file (modifies on disk)
        result = formatter.format_file(Path("main.py"))

        # Format in-memory (returns formatted string)
        result = formatter.format_source(source, language="python")

        # Check if a file is formatted
        is_ok = formatter.check_file(Path("main.py"))
    """

    def __init__(self, *, line_length: int = 88) -> None:
        self.line_length = line_length

    # ------------------------------------------------------------------
    # File formatting
    # ------------------------------------------------------------------

    def format_file(self, path: Path, *, in_place: bool = True) -> FormatResult:
        """Format a file on disk.

        Parameters:
            path: File to format.
            in_place: If *True*, modify the file. Otherwise return the result.

        Returns:
            A :class:`FormatResult`.
        """
        try:
            original = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as exc:
            return FormatResult(success=False, file_path=str(path), errors=[str(exc)])

        ext = path.suffix.lower()
        formatter_info = _FORMATTER_MAP.get(ext)

        if formatter_info and shutil.which(formatter_info["cmd"][0]):
            result = self._run_external(formatter_info, path, original)
        else:
            result = self._run_builtin(path, original, ext)

        if result.success and result.changed and in_place:
            try:
                path.write_text(result.formatted, encoding="utf-8")
            except OSError as exc:
                result.success = False
                result.errors.append(f"Cannot write: {exc}")

        return result

    def format_source(self, source: str, *, language: str | None = None, path: Path | None = None) -> FormatResult:
        """Format source code from a string.

        Parameters:
            source: The source code to format.
            language: Language name or extension.
            path: Optional path (used for language detection).

        Returns:
            A :class:`FormatResult` with ``formatted`` containing the result.
        """
        if language:
            ext = language if language.startswith(".") else f".{language}"
        elif path:
            ext = path.suffix.lower()
        else:
            return FormatResult(success=False, errors=["No language or path specified"])

        formatter_info = _FORMATTER_MAP.get(ext)
        if formatter_info and shutil.which(formatter_info["cmd"][0]):
            # Write to temp file, format, read back
            import tempfile
            with tempfile.NamedTemporaryFile(mode="w", suffix=ext, delete=False) as f:
                f.write(source)
                tmp_path = Path(f.name)
            try:
                result = self._run_external(formatter_info, tmp_path, source)
                if result.success:
                    result.file_path = str(path) if path else "<string>"
                return result
            finally:
                tmp_path.unlink(missing_ok=True)
        else:
            return self._run_builtin(path or Path(f"<string>{ext}"), source, ext)

    # ------------------------------------------------------------------
    # Checking
    # ------------------------------------------------------------------

    def check_file(self, path: Path) -> bool:
        """Check if *path* is already formatted.

        Returns *True* if the file is properly formatted.
        """
        result = self.format_file(path, in_place=False)
        return result.success and not result.changed

    def check_directory(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
    ) -> dict[str, bool]:
        """Check all files in *directory* for formatting.

        Returns:
            A dict mapping file paths to *True* (formatted) / *False* (needs formatting).
        """
        if extensions is None:
            extensions = set(_FORMATTER_MAP.keys())
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

        results: dict[str, bool] = {}
        for path in sorted(directory.rglob("*")):
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue
            results[str(path)] = self.check_file(path)

        return results

    # ------------------------------------------------------------------
    # Formatter availability
    # ------------------------------------------------------------------

    def available_formatters(self) -> dict[str, bool]:
        """Return which formatters are available on the system."""
        seen: dict[str, bool] = {}
        for info in _FORMATTER_MAP.values():
            name = info["name"]
            if name not in seen:
                seen[name] = shutil.which(info["cmd"][0]) is not None
        return seen

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run_external(self, formatter_info: dict[str, Any], path: Path, original: str) -> FormatResult:
        """Run an external formatter."""
        cmd = list(formatter_info["cmd"])

        # Handle formatters that need the file path appended
        if "{file}" in " ".join(cmd):
            cmd = [c.replace("{file}", str(path)) for c in cmd]
        else:
            cmd.append(str(path))

        name = formatter_info["name"]

        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )
        except subprocess.TimeoutExpired:
            return FormatResult(
                success=False,
                file_path=str(path),
                formatter=name,
                original=original,
                errors=[f"Formatter '{name}' timed out"],
            )
        except FileNotFoundError:
            return FormatResult(
                success=False,
                file_path=str(path),
                formatter=name,
                original=original,
                errors=[f"Formatter '{name}' not found"],
            )

        if proc.returncode != 0:
            return FormatResult(
                success=False,
                file_path=str(path),
                formatter=name,
                original=original,
                errors=[f"Formatter '{name}' failed: {proc.stderr.strip()}"],
            )

        try:
            formatted = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            formatted = original

        return FormatResult(
            success=True,
            file_path=str(path),
            formatter=name,
            changed=original != formatted,
            original=original,
            formatted=formatted,
        )

    def _run_builtin(self, path: Path, original: str, ext: str) -> FormatResult:
        """Run the built-in formatter (basic whitespace normalization)."""
        lines = original.splitlines(keepends=True)
        formatted_lines = []

        for line in lines:
            # Strip trailing whitespace
            stripped = line.rstrip()
            formatted_lines.append(stripped + "\n" if stripped else "")

        # Ensure file ends with exactly one newline
        while formatted_lines and formatted_lines[-1] == "":
            formatted_lines.pop()
        if formatted_lines:
            formatted_lines[-1] = formatted_lines[-1].rstrip("\n") + "\n"

        formatted = "".join(formatted_lines)

        return FormatResult(
            success=True,
            file_path=str(path),
            formatter="builtin",
            changed=original != formatted,
            original=original,
            formatted=formatted,
        )
