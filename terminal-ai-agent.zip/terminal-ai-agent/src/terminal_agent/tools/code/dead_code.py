"""Dead code detection.

Identifies unused functions, variables, imports, and other symbols
that are defined but never referenced in the codebase.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser
from .reference_finder import ReferenceFinder
from .symbol_extractor import Symbol, SymbolExtractor

logger = logging.getLogger(__name__)


@dataclass
class DeadSymbol:
    """A symbol that appears to be unused."""

    name: str
    kind: str  # function, variable, import, class, etc.
    file_path: str
    line: int
    confidence: str = "high"  # "high", "medium", "low"
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind,
            "file_path": self.file_path,
            "line": self.line,
            "confidence": self.confidence,
            "reason": self.reason,
        }


@dataclass
class DeadCodeReport:
    """Report of dead code in a project."""

    dead_symbols: list[DeadSymbol] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.dead_symbols)

    @property
    def by_kind(self) -> dict[str, list[DeadSymbol]]:
        groups: dict[str, list[DeadSymbol]] = {}
        for ds in self.dead_symbols:
            groups.setdefault(ds.kind, []).append(ds)
        return groups

    @property
    def high_confidence(self) -> list[DeadSymbol]:
        return [ds for ds in self.dead_symbols if ds.confidence == "high"]

    def summary(self) -> str:
        lines = [f"Dead code report: {self.total} potentially unused symbol(s)"]
        by_kind = self.by_kind
        for kind, symbols in sorted(by_kind.items()):
            lines.append(f"  {kind}: {len(symbols)}")
        if self.high_confidence:
            lines.append("High-confidence dead code:")
            for ds in self.high_confidence[:20]:
                lines.append(f"  {ds.name} ({ds.file_path}:{ds.line}) - {ds.reason}")
        return "\n".join(lines)


class DeadCodeDetector:
    """Detect unused code in a project.

    Usage::

        detector = DeadCodeDetector()

        # Analyze a directory
        report = detector.detect(Path("src/"))

        # Show results
        print(report.summary())
        for ds in report.high_confidence:
            print(f"  {ds.name} at {ds.file_path}:{ds.line}")
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()
        self._extractor = SymbolExtractor(self._parser)
        self._finder = ReferenceFinder(self._parser)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def detect(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        include_imports: bool = True,
        include_variables: bool = True,
        include_functions: bool = True,
        include_classes: bool = True,
        skip_private: bool = True,
    ) -> DeadCodeReport:
        """Detect dead code in *directory*.

        Parameters:
            directory: Root directory to analyze.
            extensions: File extensions to include.
            exclude_patterns: Path substrings to skip.
            include_imports: Check for unused imports.
            include_variables: Check for unused variables.
            include_functions: Check for unused functions.
            include_classes: Check for unused classes.
            skip_private: Skip symbols starting with ``_``.

        Returns:
            A :class:`DeadCodeReport`.
        """
        # Extract all symbols
        all_symbols = self._extractor.extract_from_directory(
            directory, extensions=extensions, exclude_patterns=exclude_patterns
        )

        if not all_symbols:
            return DeadCodeReport(errors=["No symbols found"])

        # Build a set of all names that are referenced anywhere
        referenced_names = self._build_reference_set(directory, all_symbols, extensions, exclude_patterns)

        # Check each symbol
        dead: list[DeadSymbol] = []
        errors: list[str] = []

        for sym in all_symbols:
            # Filter by kind
            if sym.kind in ("import", "require", "use", "include", "using", "library") and not include_imports:
                continue
            if sym.kind in ("variable", "constant", "property", "field", "val", "var") and not include_variables:
                continue
            if sym.kind in ("function", "method") and not include_functions:
                continue
            if sym.kind in ("class", "struct", "interface", "trait", "enum") and not include_classes:
                continue

            # Skip private symbols if requested
            if skip_private and sym.name.startswith("_"):
                continue

            # Skip special names
            if self._is_special_name(sym.name, sym.kind):
                continue

            # Check if referenced
            if sym.name not in referenced_names:
                dead.append(DeadSymbol(
                    name=sym.name,
                    kind=sym.kind,
                    file_path=sym.file_path,
                    line=sym.line,
                    confidence=self._assess_confidence(sym),
                    reason=f"Defined but never referenced",
                ))

        return DeadCodeReport(dead_symbols=dead, errors=errors)

    def detect_unused_imports(self, path: Path) -> list[DeadSymbol]:
        """Detect unused imports in a single file."""
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            return []

        symbols = self._extractor.extract_from_file(path)
        imports = [s for s in symbols if s.kind in ("import", "require", "use", "include", "using", "library", "source")]

        dead: list[DeadSymbol] = []
        for imp in imports:
            # Count references excluding the import line itself
            refs = self._finder.find_references_in_file(path, imp.name)
            usage_refs = [r for r in refs if r.line != imp.line and r.context != "import"]
            if not usage_refs:
                dead.append(DeadSymbol(
                    name=imp.name,
                    kind="import",
                    file_path=str(path),
                    line=imp.line,
                    confidence="high",
                    reason="Imported but never used",
                ))

        return dead

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _build_reference_set(
        self,
        directory: Path,
        symbols: list[Symbol],
        extensions: set[str] | None,
        exclude_patterns: set[str] | None,
    ) -> set[str]:
        """Build a set of all symbol names that are referenced anywhere.

        This is an efficient approach: instead of searching for each
        symbol individually, we scan all files once and collect all
        identifier names.
        """
        referenced: set[str] = set()

        if extensions is None:
            extensions = self._parser.supported_extensions()
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

        import re
        identifier_pattern = re.compile(r"\b([a-zA-Z_]\w*)\b")

        for path in directory.rglob("*"):
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue

            try:
                source = path.read_text(encoding="utf-8", errors="replace")
            except (OSError, UnicodeDecodeError):
                continue

            for m in identifier_pattern.finditer(source):
                referenced.add(m.group(1))

        return referenced

    @staticmethod
    def _is_special_name(name: str, kind: str) -> bool:
        """Check if a symbol name is special (shouldn't be flagged as dead)."""
        # Python special methods
        if name.startswith("__") and name.endswith("__"):
            return True
        # main functions
        if name == "main":
            return True
        # Common entry points
        if name in ("init", "setup", "teardown", "setUp", "tearDown", "before", "after",
                    "beforeEach", "afterEach", "beforeAll", "afterAll", "configure", "create_app"):
            return True
        # Module-level names that are typically exported
        if kind in ("class", "struct", "interface", "trait") and name[0].isupper():
            return False  # These are fine to check
        return False

    @staticmethod
    def _assess_confidence(sym: Symbol) -> str:
        """Assess confidence level for dead code detection."""
        # Public API symbols are harder to determine
        if sym.modifiers and any(m in sym.modifiers for m in ("public", "pub", "export")):
            return "low"
        # Test functions might be called by test runner
        if sym.name.startswith("test_") or sym.name.startswith("it_") or sym.name == "test":
            return "low"
        # Entry points
        if sym.name in ("main", "init", "setup", "configure"):
            return "low"
        # Regular private symbols
        if sym.name.startswith("_"):
            return "high"
        return "medium"
