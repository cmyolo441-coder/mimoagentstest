"""Security vulnerability scanning.

Detects common security vulnerabilities and anti-patterns in source code
using pattern matching and heuristic analysis.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SecurityIssue:
    """A detected security vulnerability."""

    vuln_type: str
    severity: str  # "critical", "high", "medium", "low", "info"
    file_path: str
    line: int
    message: str
    cwe_id: str = ""  # Common Weakness Enumeration ID
    suggestion: str = ""
    code_snippet: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "vuln_type": self.vuln_type,
            "severity": self.severity,
            "file_path": self.file_path,
            "line": self.line,
            "message": self.message,
            "cwe_id": self.cwe_id,
            "suggestion": self.suggestion,
            "code_snippet": self.code_snippet,
        }


@dataclass
class SecurityReport:
    """Report of security issues in a project."""

    issues: list[SecurityIssue] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.issues)

    @property
    def critical(self) -> list[SecurityIssue]:
        return [i for i in self.issues if i.severity == "critical"]

    @property
    def high(self) -> list[SecurityIssue]:
        return [i for i in self.issues if i.severity == "high"]

    @property
    def by_type(self) -> dict[str, list[SecurityIssue]]:
        groups: dict[str, list[SecurityIssue]] = {}
        for i in self.issues:
            groups.setdefault(i.vuln_type, []).append(i)
        return groups

    def summary(self) -> str:
        lines = [f"Security scan: {self.total} issue(s)"]
        if self.critical:
            lines.append(f"  CRITICAL: {len(self.critical)}")
        if self.high:
            lines.append(f"  HIGH: {len(self.high)}")
        by_type = self.by_type
        for vtype, issues in sorted(by_type.items(), key=lambda x: -len(x[1])):
            lines.append(f"  {vtype}: {len(issues)}")
        if self.critical or self.high:
            lines.append("Priority issues:")
            for issue in (self.critical + self.high)[:15]:
                lines.append(f"  [{issue.severity.upper()}] {issue.file_path}:{issue.line} - {issue.message}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Vulnerability patterns
# ---------------------------------------------------------------------------

_PATTERNS: list[dict[str, Any]] = [
    # SQL Injection
    {
        "pattern": re.compile(r"""(?:execute|cursor\.execute|query|raw)\s*\(\s*(?:f['"]|['"].*%s|['"].*\+\s*\w|['"].*\.format\()""", re.MULTILINE),
        "vuln_type": "sql_injection",
        "severity": "critical",
        "cwe_id": "CWE-89",
        "message": "Potential SQL injection — use parameterized queries",
        "suggestion": "Use parameterized queries: cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",
    },
    # Command injection
    {
        "pattern": re.compile(r"""(?:os\.system|os\.popen|subprocess\.call|subprocess\.run|subprocess\.Popen)\s*\(\s*(?:f['"]|['"].*%|['"].*\+\s*\w|['"].*\.format\()""", re.MULTILINE),
        "vuln_type": "command_injection",
        "severity": "critical",
        "cwe_id": "CWE-78",
        "message": "Potential command injection — validate and sanitize input",
        "suggestion": "Use subprocess with a list of arguments, never interpolate user input into shell commands",
    },
    # eval() usage
    {
        "pattern": re.compile(r"""\beval\s*\(""", re.MULTILINE),
        "vuln_type": "code_injection",
        "severity": "high",
        "cwe_id": "CWE-95",
        "message": "eval() usage — potential code injection",
        "suggestion": "Avoid eval(). Use ast.literal_eval() for data parsing or specific library functions",
    },
    # exec() usage
    {
        "pattern": re.compile(r"""\bexec\s*\(""", re.MULTILINE),
        "vuln_type": "code_injection",
        "severity": "high",
        "cwe_id": "CWE-95",
        "message": "exec() usage — potential code injection",
        "suggestion": "Avoid exec() with untrusted input",
    },
    # Hardcoded secrets
    {
        "pattern": re.compile(r"""(?:password|passwd|secret|token|api_key|apikey|access_key|private_key)\s*=\s*['"][^'"]{8,}['"]""", re.IGNORECASE),
        "vuln_type": "hardcoded_secret",
        "severity": "high",
        "cwe_id": "CWE-798",
        "message": "Hardcoded secret/credential detected",
        "suggestion": "Use environment variables or a secrets manager",
    },
    # Weak crypto
    {
        "pattern": re.compile(r"""\b(?:md5|sha1)\s*\(""", re.MULTILINE),
        "vuln_type": "weak_crypto",
        "severity": "medium",
        "cwe_id": "CWE-328",
        "message": "Weak cryptographic hash function (MD5/SHA1)",
        "suggestion": "Use SHA-256 or stronger: hashlib.sha256()",
    },
    # Insecure random
    {
        "pattern": re.compile(r"""\brandom\.(?:random|randint|choice|randrange)\s*\(""", re.MULTILINE),
        "vuln_type": "insecure_random",
        "severity": "medium",
        "cwe_id": "CWE-330",
        "message": "Non-cryptographic random for security-sensitive context",
        "suggestion": "Use secrets module for security: secrets.token_hex(), secrets.choice()",
    },
    # Path traversal
    {
        "pattern": re.compile(r"""(?:open|read|write)\s*\(\s*(?:\w+\s*\+|f['"]|os\.path\.join\()""", re.MULTILINE),
        "vuln_type": "path_traversal",
        "severity": "high",
        "cwe_id": "CWE-22",
        "message": "Potential path traversal vulnerability",
        "suggestion": "Validate and sanitize file paths. Use os.path.realpath() and check prefix",
    },
    # Unsafe deserialization
    {
        "pattern": re.compile(r"""\bpickle\.(?:loads?|Unpickler)\s*\(""", re.MULTILINE),
        "vuln_type": "unsafe_deserialization",
        "severity": "critical",
        "cwe_id": "CWE-502",
        "message": "Pickle deserialization of untrusted data — arbitrary code execution",
        "suggestion": "Use JSON or a safe serialization format. Never unpickle untrusted data",
    },
    # YAML load without safe_load
    {
        "pattern": re.compile(r"""\byaml\.load\s*\((?!.*Loader\s*=\s*yaml\.SafeLoader)""", re.MULTILINE),
        "vuln_type": "unsafe_deserialization",
        "severity": "high",
        "cwe_id": "CWE-502",
        "message": "yaml.load() without SafeLoader — potential code execution",
        "suggestion": "Use yaml.safe_load() or yaml.load(data, Loader=yaml.SafeLoader)",
    },
    # Debug mode in production
    {
        "pattern": re.compile(r"""(?:DEBUG\s*=\s*True|app\.run\([^)]*debug\s*=\s*True)""", re.MULTILINE),
        "vuln_type": "debug_enabled",
        "severity": "medium",
        "cwe_id": "CWE-489",
        "message": "Debug mode enabled — may expose sensitive information",
        "suggestion": "Disable debug mode in production: DEBUG = False",
    },
    # CORS wildcard
    {
        "pattern": re.compile(r"""(?:CORS|Access-Control-Allow-Origin).*['"][*]['"]""", re.MULTILINE),
        "vuln_type": "cors_wildcard",
        "severity": "medium",
        "cwe_id": "CWE-942",
        "message": "CORS wildcard allows any origin",
        "suggestion": "Restrict CORS to specific trusted origins",
    },
    # SSL verification disabled
    {
        "pattern": re.compile(r"""(?:verify\s*=\s*False|CERT_NONE|InsecureRequestWarning)""", re.MULTILINE),
        "vuln_type": "ssl_disabled",
        "severity": "high",
        "cwe_id": "CWE-295",
        "message": "SSL/TLS verification disabled",
        "suggestion": "Always verify SSL certificates in production",
    },
    # Temporary file with sensitive data
    {
        "pattern": re.compile(r"""(?:tempfile|mktemp|tmp).*password|password.*(?:tempfile|mktemp|tmp)""", re.MULTILINE | re.IGNORECASE),
        "vuln_type": "sensitive_in_temp",
        "severity": "medium",
        "cwe_id": "CWE-377",
        "message": "Sensitive data may be written to temporary files",
        "suggestion": "Use secure temp files and clean up immediately",
    },
    # XSS in web templates
    {
        "pattern": re.compile(r"""\{\{\s*\w+\s*\|?\s*safe\s*\}\}|\{\{\{.*?\}\}\}""", re.MULTILINE),
        "vuln_type": "xss",
        "severity": "high",
        "cwe_id": "CWE-79",
        "message": "Unescaped output in template — potential XSS",
        "suggestion": "Escape all user-provided content. Use |escape or auto-escaping templates",
    },
    # Open redirect
    {
        "pattern": re.compile(r"""(?:redirect|Redirect)\s*\(\s*(?:request\.(?:args|form|GET|POST)\.get|request\.args\[)""", re.MULTILINE),
        "vuln_type": "open_redirect",
        "severity": "medium",
        "cwe_id": "CWE-601",
        "message": "Potential open redirect vulnerability",
        "suggestion": "Validate redirect URLs against a whitelist of allowed domains",
    },
    # JavaScript: innerHTML
    {
        "pattern": re.compile(r"""\.innerHTML\s*=""", re.MULTILINE),
        "vuln_type": "xss",
        "severity": "medium",
        "cwe_id": "CWE-79",
        "message": "innerHTML assignment — potential XSS",
        "suggestion": "Use textContent for plain text or sanitize HTML with DOMPurify",
    },
    # JavaScript: document.write
    {
        "pattern": re.compile(r"""\bdocument\.write\s*\(""", re.MULTILINE),
        "vuln_type": "xss",
        "severity": "medium",
        "cwe_id": "CWE-79",
        "message": "document.write() — potential XSS",
        "suggestion": "Use DOM manipulation methods instead",
    },
]


class SecurityScanner:
    """Scan source code for security vulnerabilities.

    Usage::

        scanner = SecurityScanner()

        # Scan a directory
        report = scanner.scan(Path("src/"))

        # Show results
        print(report.summary())
        for issue in report.critical:
            print(f"  CRITICAL: {issue.message} at {issue.file_path}:{issue.line}")
    """

    def scan(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        max_files: int = 5000,
    ) -> SecurityReport:
        """Scan all files in *directory* for security issues."""
        if extensions is None:
            extensions = {".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".rb", ".php",
                         ".go", ".rs", ".c", ".cpp", ".swift", ".kt", ".lua", ".dart"}
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv",
                              "dist", "build", ".tox", "vendor", "target"}

        issues: list[SecurityIssue] = []
        errors: list[str] = []
        count = 0

        for path in sorted(directory.rglob("*")):
            if count >= max_files:
                break
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue
            count += 1

            file_issues = self._scan_file(path)
            issues.extend(file_issues)

        return SecurityReport(issues=issues, errors=errors)

    def scan_file(self, path: Path) -> SecurityReport:
        """Scan a single file for security issues."""
        issues = self._scan_file(path)
        return SecurityReport(issues=issues)

    def scan_source(self, source: str, *, language: str = "python", file_path: str = "<string>") -> SecurityReport:
        """Scan source code from a string."""
        issues = self._scan_source(source, file_path)
        return SecurityReport(issues=issues)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _scan_file(self, path: Path) -> list[SecurityIssue]:
        """Scan a single file."""
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            return []

        return self._scan_source(source, str(path))

    @staticmethod
    def _scan_source(source: str, file_path: str) -> list[SecurityIssue]:
        """Scan source code for security patterns."""
        issues: list[SecurityIssue] = []
        lines = source.splitlines()

        for pat_info in _PATTERNS:
            pattern = pat_info["pattern"]
            for m in pattern.finditer(source):
                line_num = source[: m.start()].count("\n") + 1
                snippet = ""
                if 0 < line_num <= len(lines):
                    snippet = lines[line_num - 1].strip()[:120]

                issues.append(SecurityIssue(
                    vuln_type=pat_info["vuln_type"],
                    severity=pat_info["severity"],
                    file_path=file_path,
                    line=line_num,
                    message=pat_info["message"],
                    cwe_id=pat_info.get("cwe_id", ""),
                    suggestion=pat_info.get("suggestion", ""),
                    code_snippet=snippet,
                ))

        return issues
