"""Type stub and annotation generation.

Generates type stubs (.pyi files) and inline type annotations for
Python code, and type definitions for other languages where applicable.
"""

from __future__ import annotations

import logging
import re
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser
from .symbol_extractor import Symbol, SymbolExtractor

logger = logging.getLogger(__name__)


@dataclass
class TypeStubResult:
    """Result of type stub generation."""

    success: bool
    source_file: str = ""
    stub_file: str = ""  # Path where stub would be written
    stub_content: str = ""
    annotations_added: int = 0
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"Type stub for {self.source_file}"]
        lines.append(f"Annotations: {self.annotations_added}")
        if self.warnings:
            for w in self.warnings:
                lines.append(f"  Warning: {w}")
        return "\n".join(lines)


class TypeGenerator:
    """Generate type stubs and annotations.

    Usage::

        generator = TypeGenerator()

        # Generate a .pyi stub for a Python file
        result = generator.generate_stub(Path("utils.py"))

        # Generate inline annotations
        result = generator.annotate_file(Path("utils.py"))

        # Apply the stub to disk
        if result.success:
            generator.write_stub(result)
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()
        self._extractor = SymbolExtractor(self._parser)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate_stub(self, path: Path) -> TypeStubResult:
        """Generate a .pyi type stub for a Python file.

        Parameters:
            path: Path to the Python source file.

        Returns:
            A :class:`TypeStubResult` with the generated stub content.
        """
        if path.suffix not in (".py", ".pyi"):
            return TypeStubResult(success=False, errors=["Only Python files are supported for stub generation"])

        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as exc:
            return TypeStubResult(success=False, errors=[str(exc)])

        symbols = self._extractor.extract_from_file(path)
        if not symbols:
            return TypeStubResult(
                success=False,
                source_file=str(path),
                errors=["No symbols found"],
            )

        stub_lines: list[str] = []
        annotations_added = 0
        warnings: list[str] = []

        # Module docstring
        stub_lines.append(f'"""Type stubs for {path.name}."""')
        stub_lines.append("")
        stub_lines.append("from __future__ import annotations")
        stub_lines.append("")

        # Collect imports
        imports = [s for s in symbols if s.kind in ("import", "require", "use")]
        for imp in imports:
            module = imp.metadata.get("module", "")
            if module:
                stub_lines.append(f"import {module}")
            else:
                stub_lines.append(f"import {imp.name}")
        if imports:
            stub_lines.append("")

        # Process symbols
        functions = [s for s in symbols if s.kind in ("function", "method")]
        classes = [s for s in symbols if s.kind in ("class", "struct", "interface")]
        variables = [s for s in symbols if s.kind in ("variable", "constant", "property", "field")]

        # Top-level functions
        for func in functions:
            if func.parent:
                continue  # Skip methods, handled with classes
            stub_line = self._generate_function_stub(func)
            stub_lines.append(stub_line)
            stub_lines.append("")
            annotations_added += 1

        # Classes
        for cls in classes:
            class_lines = self._generate_class_stub(cls, functions)
            stub_lines.extend(class_lines)
            stub_lines.append("")
            annotations_added += len(class_lines)

        # Top-level variables
        for var in variables:
            if var.parent:
                continue
            type_hint = self._infer_type(var)
            stub_lines.append(f"{var.name}: {type_hint}")
            annotations_added += 1

        stub_content = "\n".join(stub_lines) + "\n"
        stub_path = path.with_suffix(".pyi")

        return TypeStubResult(
            success=True,
            source_file=str(path),
            stub_file=str(stub_path),
            stub_content=stub_content,
            annotations_added=annotations_added,
            warnings=warnings,
        )

    def annotate_file(self, path: Path) -> TypeStubResult:
        """Generate inline type annotations for a Python file.

        Returns a :class:`TypeStubResult` with ``stub_content`` containing
        the annotated source (not yet applied to disk).
        """
        if path.suffix not in (".py",):
            return TypeStubResult(success=False, errors=["Only .py files supported"])

        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as exc:
            return TypeStubResult(success=False, errors=[str(exc)])

        symbols = self._extractor.extract_from_file(path)
        functions = [s for s in symbols if s.kind in ("function", "method") and not s.parent]

        lines = source.splitlines(keepends=True)
        annotations_added = 0

        for func in reversed(functions):
            # Skip if already has annotations
            if func.return_type or any(p.get("type") for p in func.params):
                continue

            line_idx = func.line - 1
            if line_idx >= len(lines):
                continue

            old_line = lines[line_idx]
            new_line = self._annotate_function_line(old_line, func)
            if new_line != old_line:
                lines[line_idx] = new_line
                annotations_added += 1

        annotated_source = "".join(lines)

        return TypeStubResult(
            success=True,
            source_file=str(path),
            stub_content=annotated_source,
            annotations_added=annotations_added,
        )

    @staticmethod
    def write_stub(result: TypeStubResult) -> None:
        """Write the generated stub to disk."""
        if not result.success or not result.stub_file:
            return
        path = Path(result.stub_file)
        path.write_text(result.stub_content, encoding="utf-8")
        logger.info("Wrote type stub to %s", path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _generate_function_stub(self, func: Symbol) -> str:
        """Generate a stub line for a function."""
        params = self._format_params(func.params)
        return_type = func.return_type or "Any"

        # Add type hints to params
        typed_params = []
        for p in func.params:
            name = p.get("name", "")
            ptype = p.get("type") or "Any"
            default = p.get("default")
            if default:
                typed_params.append(f"{name}: {ptype} = {default}")
            else:
                typed_params.append(f"{name}: {ptype}")

        param_str = ", ".join(typed_params)
        return f"def {func.name}({param_str}) -> {return_type}: ..."

    def _generate_class_stub(self, cls: Symbol, all_functions: list[Symbol]) -> list[str]:
        """Generate stub lines for a class."""
        lines: list[str] = []
        bases = cls.metadata.get("bases", [])
        base_str = f"({', '.join(bases)})" if bases else ""
        lines.append(f"class {cls.name}{base_str}:")

        # Get methods for this class
        methods = [f for f in all_functions if f.parent == cls.name]
        if not methods:
            lines.append("    pass")
        else:
            for method in methods:
                params = self._format_params(method.params)
                return_type = method.return_type or "Any"
                typed_params = []
                for p in method.params:
                    name = p.get("name", "")
                    ptype = p.get("type") or "Any"
                    typed_params.append(f"{name}: {ptype}")
                param_str = ", ".join(typed_params)
                prefix = "    @staticmethod\n    " if "static" in method.modifiers else "    "
                lines.append(f"{prefix}def {method.name}({param_str}) -> {return_type}: ...")

        return lines

    @staticmethod
    def _format_params(params: list[dict[str, Any]]) -> str:
        """Format parameters with type hints."""
        parts = []
        for p in params:
            name = p.get("name", "")
            ptype = p.get("type") or "Any"
            parts.append(f"{name}: {ptype}")
        return ", ".join(parts)

    @staticmethod
    def _infer_type(var: Symbol) -> str:
        """Infer a type hint for a variable."""
        if var.return_type:
            return var.return_type
        name = var.name.lower()
        if "count" in name or "num" in name or "size" in name or "length" in name:
            return "int"
        if "name" in name or "title" in name or "message" in name or "text" in name:
            return "str"
        if "flag" in name or "is_" in name or "has_" in name or "enabled" in name:
            return "bool"
        if "path" in name or "file" in name or "dir" in name:
            return "str"
        if "url" in name or "link" in name or "href" in name:
            return "str"
        return "Any"

    @staticmethod
    def _annotate_function_line(line: str, func: Symbol) -> str:
        """Add type annotations to a function definition line."""
        # Find the closing paren of params
        paren_start = line.index("(")
        depth = 0
        paren_end = -1
        for i in range(paren_start, len(line)):
            if line[i] == "(":
                depth += 1
            elif line[i] == ")":
                depth -= 1
                if depth == 0:
                    paren_end = i
                    break

        if paren_end == -1:
            return line

        # Build annotated params
        old_params = line[paren_start + 1 : paren_end]
        if not old_params.strip():
            new_params = ""
        else:
            param_parts = []
            for p, sym_p in zip(old_params.split(","), func.params):
                p = p.strip()
                if not p:
                    continue
                ptype = sym_p.get("type") or "Any"
                # Check if already annotated
                if ":" in p:
                    param_parts.append(p)
                else:
                    param_parts.append(f"{p}: {ptype}")
            new_params = ", ".join(param_parts)

        # Add return type
        after_paren = line[paren_end + 1 :]
        if "->" not in after_paren:
            return_type = func.return_type or "Any"
            colon_pos = after_paren.find(":")
            if colon_pos != -1:
                after_paren = f" -> {return_type}" + after_paren[colon_pos:]
                return line[: paren_start] + "(" + new_params + ")" + after_paren

        return line[: paren_start] + "(" + new_params + ")" + after_paren
