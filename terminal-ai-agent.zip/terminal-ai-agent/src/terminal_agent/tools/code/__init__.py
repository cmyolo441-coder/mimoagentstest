"""Code tools for understanding, analyzing, and transforming source code.

This package provides a comprehensive suite of code analysis and transformation
tools supporting 20+ programming languages via AST parsing (where available)
with regex fallback for unsupported cases.

Modules:
    ast_parser: Multi-language AST parsing abstraction
    symbol_extractor: Extract functions, classes, variables, and other symbols
    reference_finder: Find all references to a given symbol
    renamer: Safe symbol renaming across files
    extractor: Extract code blocks into new functions
    inliner: Inline function calls at call sites
    mover: Move code between files with import management
    formatter: Code formatting (black, prettier, gofmt, etc.)
    linter: Code linting integration (eslint, pylint, clippy, etc.)
    complexity: Cyclomatic and cognitive complexity analysis
    call_graph: Call graph generation
    dead_code: Dead code detection
    duplicate_detector: Duplicate/near-duplicate code detection
    smell_detector: Code smell and anti-pattern detection
    security_scanner: Security vulnerability scanning
    performance_analyzer: Performance issue detection
    dependency_analyzer: Import and dependency analysis
    type_generator: Type stub and annotation generation
    languages: Per-language AST analysis implementations
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .ast_parser import ASTParser, ParseResult
    from .symbol_extractor import Symbol, SymbolExtractor
    from .reference_finder import Reference, ReferenceFinder
    from .renamer import RenameResult, Renamer
    from .extractor import ExtractionResult, CodeExtractor
    from .inliner import InlineResult, Inliner
    from .mover import MoveResult, CodeMover
    from .formatter import FormatResult, CodeFormatter
    from .linter import LintResult, Linter
    from .complexity import ComplexityReport, ComplexityAnalyzer
    from .call_graph import CallGraph, CallGraphBuilder
    from .dead_code import DeadCodeReport, DeadCodeDetector
    from .duplicate_detector import DuplicateReport, DuplicateDetector
    from .smell_detector import SmellReport, SmellDetector
    from .security_scanner import SecurityReport, SecurityScanner
    from .performance_analyzer import PerformanceReport, PerformanceAnalyzer
    from .dependency_analyzer import DependencyReport, DependencyAnalyzer
    from .type_generator import TypeStubResult, TypeGenerator


__all__ = [
    # Core
    "ASTParser",
    "ParseResult",
    "SymbolExtractor",
    "Symbol",
    "ReferenceFinder",
    "Reference",
    # Refactoring
    "Renamer",
    "RenameResult",
    "CodeExtractor",
    "ExtractionResult",
    "Inliner",
    "InlineResult",
    "CodeMover",
    "MoveResult",
    # Quality
    "CodeFormatter",
    "FormatResult",
    "Linter",
    "LintResult",
    "ComplexityAnalyzer",
    "ComplexityReport",
    # Analysis
    "CallGraphBuilder",
    "CallGraph",
    "DeadCodeDetector",
    "DeadCodeReport",
    "DuplicateDetector",
    "DuplicateReport",
    "SmellDetector",
    "SmellReport",
    "SecurityScanner",
    "SecurityReport",
    "PerformanceAnalyzer",
    "PerformanceReport",
    "DependencyAnalyzer",
    "DependencyReport",
    # Generation
    "TypeGenerator",
    "TypeStubResult",
]
