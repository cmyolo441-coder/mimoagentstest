"""Safe symbol renaming across files.

Renames functions, classes, variables, and other symbols across an
entire project tree, updating all references consistently.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser
from .reference_finder import Reference, ReferenceFinder
from .symbol_extractor import Symbol, SymbolExtractor

logger = logging.getLogger(__name__)


@dataclass
class FileChange:
    """A change to a single file during renaming."""

    file_path: str
    old_content: str
    new_content: str
    replacements: int

    @property
    def diff(self) -> str:
        """Return a simple line-by-line diff."""
        old_lines = self.old_content.splitlines(keepends=True)
        new_lines = self.new_content.splitlines(keepends=True)
        diff_lines = []
        for i, (old, new) in enumerate(zip(old_lines, new_lines)):
            if old != new:
                diff_lines.append(f"-{i + 1}: {old.rstrip()}")
                diff_lines.append(f"+{i + 1}: {new.rstrip()}")
        # Handle length differences
        if len(old_lines) > len(new_lines):
            for line in old_lines[len(new_lines) :]:
                diff_lines.append(f"-: {line.rstrip()}")
        elif len(new_lines) > len(old_lines):
            for line in new_lines[len(old_lines) :]:
                diff_lines.append(f"+: {line.rstrip()}")
        return "\n".join(diff_lines)


@dataclass
class RenameResult:
    """Result of a rename operation."""

    success: bool
    old_name: str
    new_name: str
    files_changed: list[FileChange] = field(default_factory=list)
    total_replacements: int = 0
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def changed_files(self) -> list[str]:
        return [c.file_path for c in self.files_changed]

    def summary(self) -> str:
        lines = [
            f"Renamed '{self.old_name}' -> '{self.new_name}'",
            f"Files changed: {len(self.files_changed)}",
            f"Total replacements: {self.total_replacements}",
        ]
        for fc in self.files_changed:
            lines.append(f"  {fc.file_path}: {fc.replacements} replacement(s)")
        if self.errors:
            lines.append(f"Errors: {len(self.errors)}")
            for e in self.errors:
                lines.append(f"  - {e}")
        return "\n".join(lines)


class Renamer:
    """Rename symbols safely across a project.

    Usage::

        renamer = Renamer()

        # Rename by name
        result = renamer.rename(Path("src/"), "old_name", "new_name")

        # Rename a specific symbol
        symbols = SymbolExtractor().extract_from_file(Path("main.py"))
        sym = next(s for s in symbols if s.name == "old_name")
        result = renamer.rename_symbol(Path("src/"), sym, "new_name")

        # Apply changes to disk
        if result.success:
            renamer.apply_changes(result)
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()
        self._finder = ReferenceFinder(self._parser)
        self._extractor = SymbolExtractor(self._parser)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def rename(
        self,
        directory: Path,
        old_name: str,
        new_name: str,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        dry_run: bool = True,
    ) -> RenameResult:
        """Rename *old_name* to *new_name* across *directory*.

        Parameters:
            directory: Root directory to search.
            old_name: Current symbol name.
            new_name: Desired symbol name.
            extensions: File extensions to include.
            exclude_patterns: Path substrings to skip.
            dry_run: If *True*, compute changes without writing to disk.

        Returns:
            A :class:`RenameResult` with the computed or applied changes.
        """
        if old_name == new_name:
            return RenameResult(success=True, old_name=old_name, new_name=new_name)

        # Validate new name is a valid identifier
        if not self._is_valid_identifier(new_name):
            return RenameResult(
                success=False,
                old_name=old_name,
                new_name=new_name,
                errors=[f"'{new_name}' is not a valid identifier"],
            )

        # Find all references
        references = self._finder.find_references(
            directory, old_name, extensions=extensions, exclude_patterns=exclude_patterns
        )

        if not references:
            return RenameResult(
                success=False,
                old_name=old_name,
                new_name=new_name,
                errors=[f"No references to '{old_name}' found"],
            )

        # Group references by file
        refs_by_file: dict[str, list[Reference]] = {}
        for ref in references:
            refs_by_file.setdefault(ref.file_path, []).append(ref)

        # Compute changes
        changes: list[FileChange] = []
        errors: list[str] = []
        total_replacements = 0

        for file_path, file_refs in refs_by_file.items():
            path = Path(file_path)
            try:
                source = path.read_text(encoding="utf-8", errors="replace")
            except (OSError, UnicodeDecodeError) as exc:
                errors.append(f"Cannot read {file_path}: {exc}")
                continue

            new_source, count = self._replace_in_source(source, old_name, new_name, file_refs)
            if count > 0:
                changes.append(FileChange(
                    file_path=file_path,
                    old_content=source,
                    new_content=new_source,
                    replacements=count,
                ))
                total_replacements += count

        result = RenameResult(
            success=len(changes) > 0,
            old_name=old_name,
            new_name=new_name,
            files_changed=changes,
            total_replacements=total_replacements,
            errors=errors,
        )

        # Apply if not dry run
        if not dry_run and result.success:
            self.apply_changes(result)

        return result

    def rename_symbol(
        self,
        directory: Path,
        symbol: Symbol,
        new_name: str,
        *,
        dry_run: bool = True,
    ) -> RenameResult:
        """Rename a specific :class:`Symbol` to *new_name*.

        This is more precise than :meth:`rename` because it uses the
        symbol's metadata to avoid false positives.
        """
        return self.rename(
            directory,
            symbol.name,
            new_name,
            dry_run=dry_run,
        )

    @staticmethod
    def apply_changes(result: RenameResult) -> None:
        """Write the computed changes to disk.

        Only call this after reviewing the changes in *result*.
        """
        for change in result.files_changed:
            path = Path(change.file_path)
            try:
                path.write_text(change.new_content, encoding="utf-8")
                logger.info("Applied %d replacements in %s", change.replacements, path)
            except OSError as exc:
                result.errors.append(f"Cannot write {change.file_path}: {exc}")

    # ------------------------------------------------------------------
    # Preview
    # ------------------------------------------------------------------

    def preview(
        self,
        directory: Path,
        old_name: str,
        new_name: str,
        *,
        extensions: set[str] | None = None,
        context_lines: int = 2,
    ) -> str:
        """Return a human-readable preview of the rename changes.

        Shows context lines around each replacement for review.
        """
        result = self.rename(directory, old_name, new_name, extensions=extensions, dry_run=True)
        if not result.success:
            return f"Rename not possible: {'; '.join(result.errors)}"

        output = [result.summary(), "", "Changes:"]

        for change in result.files_changed:
            output.append(f"\n--- {change.file_path}")
            output.append(f"+++ {change.file_path}")
            output.append(change.diff)

        return "\n".join(output)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _replace_in_source(
        source: str,
        old_name: str,
        new_name: str,
        references: list[Reference],
    ) -> tuple[str, int]:
        """Replace *old_name* with *new_name* at specific reference locations.

        Processes replacements from end to start to preserve offsets.
        """
        lines = source.splitlines(keepends=True)
        count = 0

        # Sort references in reverse order (by line, then col descending)
        sorted_refs = sorted(references, key=lambda r: (r.line, r.col), reverse=True)

        for ref in sorted_refs:
            line_idx = ref.line - 1
            if line_idx < 0 or line_idx >= len(lines):
                continue

            line = lines[line_idx]
            col = ref.col

            # Verify the text at the position matches
            if col + len(old_name) <= len(line) and line[col : col + len(old_name)] == old_name:
                lines[line_idx] = line[:col] + new_name + line[col + len(old_name) :]
                count += 1

        return "".join(lines), count

    @staticmethod
    def _is_valid_identifier(name: str) -> bool:
        """Check if *name* is a valid identifier in most languages."""
        if not name:
            return False
        if not (name[0].isalpha() or name[0] == "_"):
            return False
        return all(c.isalnum() or c == "_" for c in name)
