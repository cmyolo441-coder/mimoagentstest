"""JavaScript language analyzer using regex-based parsing.

Falls back to regex when no AST library is available. Covers ES6+ syntax
including arrow functions, classes, destructuring, and modules.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

# ---------------------------------------------------------------------------
# Regex patterns for JS symbol extraction
# ---------------------------------------------------------------------------

_RE_FUNCTION_DECL = re.compile(
    r"(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)",
    re.MULTILINE,
)
_RE_ARROW_FUNC = re.compile(
    r"(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?\([^)]*\)\s*=>",
    re.MULTILINE,
)
_RE_CLASS_DECL = re.compile(
    r"(?:export\s+)?(?:abstract\s+)?class\s+(\w+)(?:\s+extends\s+(\w+))?\s*\{",
    re.MULTILINE,
)
_RE_METHOD = re.compile(
    r"(?:async\s+)?(\w+)\s*\(([^)]*)\)\s*\{",
    re.MULTILINE,
)
_RE_IMPORT = re.compile(
    r'import\s+(?:\{([^}]+)\}|(\w+))\s+from\s+["\']([^"\']+)["\']',
    re.MULTILINE,
)
_RE_REQUIRE = re.compile(
    r'(?:const|let|var)\s+(?:\{([^}]+)\}|(\w+))\s*=\s*require\s*\(\s*["\']([^"\']+)["\']\s*\)',
    re.MULTILINE,
)
_RE_VARIABLE = re.compile(
    r"(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=",
    re.MULTILINE,
)
_RE_JSDOC = re.compile(r"/\*\*(.*?)\*/", re.DOTALL)


class JavaScriptAnalyzer:
    """Regex-based analyzer for JavaScript source files."""

    language = "javascript"
    file_extensions = {".js", ".jsx", ".mjs", ".cjs"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        """Return the raw source (no AST available without external deps)."""
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []
        lines = source.splitlines()

        # Function declarations
        for m in _RE_FUNCTION_DECL.finditer(source):
            name = m.group(1)
            params_str = m.group(2)
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "function",
                "name": name,
                "line": line,
                "col": m.start() - source.rfind("\n", 0, m.start()) - 1,
                "end_line": line,
                "params": self._parse_params(params_str),
                "async": "async" in source[max(0, m.start() - 10) : m.start()],
                "docstring": self._find_jsdoc_above(source, m.start()),
            })

        # Arrow functions
        for m in _RE_ARROW_FUNC.finditer(source):
            name = m.group(1)
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "function",
                "name": name,
                "line": line,
                "col": m.start() - source.rfind("\n", 0, m.start()) - 1,
                "end_line": line,
                "params": [],
                "async": "async" in m.group(0),
                "arrow": True,
            })

        # Classes
        for m in _RE_CLASS_DECL.finditer(source):
            name = m.group(1)
            base = m.group(2)
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "class",
                "name": name,
                "line": line,
                "col": m.start() - source.rfind("\n", 0, m.start()) - 1,
                "end_line": line,
                "bases": [base] if base else [],
            })

        # Imports
        for m in _RE_IMPORT.finditer(source):
            named = m.group(1)
            default = m.group(2)
            module = m.group(3)
            line = source[: m.start()].count("\n") + 1
            if named:
                for name in named.split(","):
                    name = name.strip().split(" as ")[-1].strip()
                    if name:
                        symbols.append({"kind": "import", "name": name, "module": module, "line": line, "col": 0})
            if default:
                symbols.append({"kind": "import", "name": default, "module": module, "line": line, "col": 0})

        # require()
        for m in _RE_REQUIRE.finditer(source):
            named = m.group(1)
            default = m.group(2)
            module = m.group(3)
            line = source[: m.start()].count("\n") + 1
            if named:
                for name in named.split(","):
                    name = name.strip().split(" as ")[-1].strip()
                    if name:
                        symbols.append({"kind": "import", "name": name, "module": module, "line": line, "col": 0})
            if default:
                symbols.append({"kind": "import", "name": default, "module": module, "line": line, "col": 0})

        # Variables
        for m in _RE_VARIABLE.finditer(source):
            name = m.group(1)
            line = source[: m.start()].count("\n") + 1
            # Skip if already captured as arrow function
            if not any(s["name"] == name and s["kind"] == "function" for s in symbols):
                symbols.append({"kind": "variable", "name": name, "line": line, "col": 0})

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        pattern = re.compile(r"\b" + re.escape(symbol) + r"\b")
        for m in pattern.finditer(source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_params(params_str: str) -> list[dict[str, Any]]:
        params = []
        for p in params_str.split(","):
            p = p.strip()
            if not p:
                continue
            # Handle destructuring and defaults
            name = p.split("=")[0].strip().split(":")[0].strip()
            name = name.split("...")[-1].strip()
            if name:
                params.append({"name": name, "type": None, "default": None})
        return params

    @staticmethod
    def _find_jsdoc_above(source: str, pos: int) -> str | None:
        """Find a JSDoc comment immediately above *pos*."""
        before = source[:pos].rstrip()
        if before.endswith("*/"):
            start = before.rfind("/**")
            if start != -1:
                return before[start : len(before)]
        return None


_register(JavaScriptAnalyzer())
