"""C++ language analyzer using regex-based parsing.

Extends C analysis with classes, namespaces, templates, and modern C++ features.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register
from .c import CAnalyzer

_RE_CLASS = re.compile(
    r"(?:template\s*<[^>]*>\s*)?(?:class|struct)\s+(?:\w+\s+)?(\w+)(?:\s*:\s*(?:public|protected|private)\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_NAMESPACE = re.compile(
    r"namespace\s+(\w+)\s*\{",
    re.MULTILINE,
)
_RE_USING = re.compile(
    r"using\s+(?:namespace\s+)?([^;]+);",
    re.MULTILINE,
)
_RE_TEMPLATE = re.compile(
    r"template\s*<([^>]+)>",
    re.MULTILINE,
)
_RE_METHOD = re.compile(
    r"(?:virtual\s+)?(?:static\s+)?(?:const\s+)?"
    r"(\w+(?:::\w+)*(?:<[^>]*>)?(?:\s*\*|&)*)\s+"
    r"(\w+)::(\w+)\s*\(([^)]*)\)",
    re.MULTILINE,
)
_RE_OPERATOR = re.compile(
    r"(\w+)\s+operator\s*(\S+)\s*\(([^)]*)\)",
    re.MULTILINE,
)


class CppAnalyzer(CAnalyzer):
    """Regex-based analyzer for C++ source files."""

    language = "cpp"
    file_extensions = {".cpp", ".cxx", ".cc", ".hpp", ".hxx", ".hh", ".h", ".tpp", ".ipp"}

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        # Get C-level symbols first
        symbols = super().extract_symbols(source, path)

        # Namespaces
        for m in _RE_NAMESPACE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "namespace", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Classes and structs with inheritance
        for m in _RE_CLASS.finditer(source):
            name = m.group(1)
            bases_str = m.group(2)
            line = source[: m.start()].count("\n") + 1
            bases = []
            if bases_str:
                for b in bases_str.split(","):
                    b = b.strip()
                    # Remove access specifier
                    for spec in ("public", "protected", "private"):
                        if b.startswith(spec):
                            b = b[len(spec) :].strip()
                    if b:
                        bases.append(b)
            symbols.append({
                "kind": "class",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "bases": bases,
                "template": self._template_above(source, m.start()),
            })

        # Using declarations
        for m in _RE_USING.finditer(source):
            line = source[: m.start()].count("\n") + 1
            using_text = m.group(1).strip()
            if "namespace" in using_text:
                ns = using_text.replace("namespace", "").strip()
                symbols.append({"kind": "using", "name": ns, "namespace": True, "line": line, "col": 0, "end_line": line})
            else:
                symbols.append({"kind": "using", "name": using_text, "namespace": False, "line": line, "col": 0, "end_line": line})

        # Operators
        for m in _RE_OPERATOR.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "operator",
                "name": f"operator{m.group(2)}",
                "class": m.group(1),
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_c_params(m.group(3)),
            })

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        return super().find_references(source, symbol, path)

    @staticmethod
    def _template_above(source: str, pos: int) -> str | None:
        before = source[:pos].rstrip()
        if before.endswith(">"):
            depth = 0
            for i in range(len(before) - 1, -1, -1):
                if before[i] == ">":
                    depth += 1
                elif before[i] == "<":
                    depth -= 1
                    if depth == 0:
                        start = before.rfind("template", 0, i)
                        if start != -1:
                            return before[start : len(before)]
                        break
        return None


_register(CppAnalyzer())
