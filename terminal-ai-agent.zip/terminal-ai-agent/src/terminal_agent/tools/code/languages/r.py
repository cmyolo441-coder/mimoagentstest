"""R language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_FUNCTION = re.compile(
    r"(\w+)\s*(?:<-|=)\s*function\s*\(([^)]*)\)",
    re.MULTILINE,
)
_RE_S4_CLASS = re.compile(
    r"setClass\s*\(\s*['\"](\w+)['\"]",
    re.MULTILINE,
)
_RE_S4_METHOD = re.compile(
    r"setMethod\s*\(\s*['\"](\w+)['\"]",
    re.MULTILINE,
)
_RE_S4_GENERIC = re.compile(
    r"setGeneric\s*\(\s*['\"](\w+)['\"]",
    re.MULTILINE,
)
_RE_R6_CLASS = re.compile(
    r"(\w+)\s*(?:<-|=)\s*R6Class\s*\(\s*['\"](\w+)['\"]",
    re.MULTILINE,
)
_RE_S3_METHOD = re.compile(
    r"(\w+)\s*(?:<-|=)\s*function\s*\([^)]*\)\s*(?:UseMethod|NextMethod)\s*\(\s*['\"](\w+)['\"]",
    re.MULTILINE,
)
_RE_SOURCE = re.compile(
    r"(?:source|sys\.source)\s*\(\s*['\"]([^'\"]+)['\"]",
    re.MULTILINE,
)
_RE_LIBRARY = re.compile(
    r"(?:library|require)\s*\(\s*(\w+)",
    re.MULTILINE,
)
_RE_ASSIGNMENT = re.compile(
    r"^(\w+)\s*(?:<-|=)\s*(?!function)",
    re.MULTILINE,
)
_RE_LIST_ASSIGNMENT = re.compile(
    r"(\w+)\$(\w+)\s*(?:<-|=)",
    re.MULTILINE,
)


class RAnalyzer:
    """Regex-based analyzer for R source files."""

    language = "r"
    file_extensions = {".r", ".R", ".rmd", ".Rmd"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Library / require
        for m in _RE_LIBRARY.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "library", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Source
        for m in _RE_SOURCE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "source", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # S4 classes
        for m in _RE_S4_CLASS.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "class", "name": m.group(1), "line": line, "col": 0, "end_line": line, "system": "S4"})

        # R6 classes
        for m in _RE_R6_CLASS.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "class", "name": m.group(2), "line": line, "col": 0, "end_line": line, "system": "R6", "variable": m.group(1)})

        # S4 generics
        for m in _RE_S4_GENERIC.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "generic", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # S4 methods
        for m in _RE_S4_METHOD.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "method", "name": m.group(1), "line": line, "col": 0, "end_line": line, "system": "S4"})

        # Functions
        for m in _RE_FUNCTION.finditer(source):
            name = m.group(1)
            params_str = m.group(2)
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "function",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_r_params(params_str),
            })

        # Simple assignments (variables)
        for m in _RE_ASSIGNMENT.finditer(source):
            name = m.group(1)
            if not any(s["name"] == name for s in symbols):
                line = source[: m.start()].count("\n") + 1
                symbols.append({"kind": "variable", "name": name, "line": line, "col": 0, "end_line": line})

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_r_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        for p in params_str.split(","):
            p = p.strip()
            if not p:
                continue
            parts = p.split("=")
            name = parts[0].strip()
            default = parts[1].strip() if len(parts) > 1 else None
            if name:
                params.append({"name": name, "type": None, "default": default})
        return params


_register(RAnalyzer())
