"""Go language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_FUNC = re.compile(
    r"func\s+(?:\((\w+)\s+\*?(\w+)\)\s+)?(\w+)\s*\(([^)]*)\)\s*(?:\(([^)]*)\)|([^{]*))?\s*\{",
    re.MULTILINE,
)
_RE_TYPE = re.compile(
    r"type\s+(\w+)\s+(struct|interface)\s*\{",
    re.MULTILINE,
)
_RE_VAR = re.compile(
    r"(?:var|const)\s+(\w+)(?:\s+([^=]+))?\s*=",
    re.MULTILINE,
)
_RE_IMPORT_MULTI = re.compile(
    r"import\s*\((.*?)\)",
    re.DOTALL,
)
_RE_IMPORT_SINGLE = re.compile(
    r'import\s+(?:(\w+)\s+)?["\']([^"\']+)["\']',
    re.MULTILINE,
)
_RE_STRUCT_FIELD = re.compile(
    r"(\w+)\s+([^\n]+?)(?:\s+`[^`]+`)?\s*$",
    re.MULTILINE,
)


class GoAnalyzer:
    """Regex-based analyzer for Go source files."""

    language = "go"
    file_extensions = {".go"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Package declaration
        pkg_match = re.match(r"package\s+(\w+)", source)
        if pkg_match:
            symbols.append({"kind": "package", "name": pkg_match.group(1), "line": 1, "col": 0, "end_line": 1})

        # Imports (multi-line)
        for m in _RE_IMPORT_MULTI.finditer(source):
            block = m.group(1)
            line = source[: m.start()].count("\n") + 1
            for im in re.finditer(r'(?:(\w+)\s+)?["\']([^"\']+)["\']', block):
                alias = im.group(1)
                module = im.group(2)
                symbols.append({
                    "kind": "import",
                    "name": alias or module.split("/")[-1].strip("."),
                    "module": module,
                    "line": line + im.group(0).count("\n"),
                    "col": 0,
                })

        # Single imports
        for m in _RE_IMPORT_SINGLE.finditer(source):
            # Skip if inside a multi-line import block
            before = source[: m.start()]
            if "import" in before and "(" in before[before.rfind("import") :]:
                # Check if we're inside a parenthesized import
                last_open = before.rfind("(")
                last_close = before.rfind(")")
                if last_open > last_close:
                    continue
            alias = m.group(1)
            module = m.group(2)
            symbols.append({
                "kind": "import",
                "name": alias or module.split("/")[-1].strip("."),
                "module": module,
                "line": source[: m.start()].count("\n") + 1,
                "col": 0,
            })

        # Type declarations
        for m in _RE_TYPE.finditer(source):
            name = m.group(1)
            kind = m.group(2)  # struct or interface
            line = source[: m.start()].count("\n") + 1
            # Extract fields for structs
            fields = []
            if kind == "struct":
                brace_start = m.end() - 1
                brace_end = self._find_matching_brace(source, brace_start)
                if brace_end > brace_start:
                    body = source[brace_start + 1 : brace_end]
                    for fm in _RE_STRUCT_FIELD.finditer(body):
                        fields.append({"name": fm.group(1), "type": fm.group(2).strip()})
            symbols.append({
                "kind": kind,
                "name": name,
                "line": line,
                "col": m.start() - source.rfind("\n", 0, m.start()) - 1,
                "end_line": line,
                "fields": fields,
            })

        # Functions and methods
        for m in _RE_FUNC.finditer(source):
            receiver_type = m.group(2)
            name = m.group(3)
            params_str = m.group(4)
            returns_str = m.group(5) or m.group(6) or ""
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "method" if receiver_type else "function",
                "name": name,
                "receiver": receiver_type,
                "line": line,
                "col": m.start() - source.rfind("\n", 0, m.start()) - 1,
                "end_line": line,
                "params": self._parse_go_params(params_str),
                "returns": returns_str.strip(),
            })

        # Variables and constants
        for m in _RE_VAR.finditer(source):
            symbols.append({
                "kind": "variable",
                "name": m.group(1),
                "type": m.group(2).strip() if m.group(2) else None,
                "line": source[: m.start()].count("\n") + 1,
                "col": 0,
                "end_line": source[: m.start()].count("\n") + 1,
            })

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _find_matching_brace(source: str, open_pos: int) -> int:
        depth = 0
        for i in range(open_pos, len(source)):
            if source[i] == "{":
                depth += 1
            elif source[i] == "}":
                depth -= 1
                if depth == 0:
                    return i
        return -1

    @staticmethod
    def _parse_go_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        parts = params_str.split(",")
        current_type = ""
        for part in reversed(parts):
            part = part.strip()
            if not part:
                continue
            tokens = part.split()
            if len(tokens) >= 2:
                name = tokens[0]
                typ = " ".join(tokens[1:])
                current_type = typ
            elif len(tokens) == 1:
                name = tokens[0]
                typ = current_type
            else:
                continue
            params.insert(0, {"name": name, "type": typ, "default": None})
        return params


_register(GoAnalyzer())
