"""Python language analyzer using the ``ast`` module."""

from __future__ import annotations

import ast
import textwrap
from pathlib import Path
from typing import Any

from . import _register


class PythonAnalyzer:
    """AST-based analyzer for Python source files."""

    language = "python"
    file_extensions = {".py", ".pyw", ".pyi"}

    # ------------------------------------------------------------------
    # Protocol helpers
    # ------------------------------------------------------------------

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    # ------------------------------------------------------------------
    # Parsing
    # ------------------------------------------------------------------

    def parse(self, source: str, path: Path | None = None) -> ast.Module:
        """Parse *source* into a Python AST.

        Raises :class:`SyntaxError` on invalid Python.
        """
        return ast.parse(source, filename=str(path) if path else "<string>")

    # ------------------------------------------------------------------
    # Symbol extraction
    # ------------------------------------------------------------------

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        """Extract functions, classes, imports, and top-level assignments."""
        try:
            tree = self.parse(source, path)
        except SyntaxError:
            return []

        symbols: list[dict[str, Any]] = []
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                symbols.append(self._function_symbol(node))
            elif isinstance(node, ast.ClassDef):
                symbols.append(self._class_symbol(node))
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    symbols.append({
                        "kind": "import",
                        "name": alias.asname or alias.name,
                        "module": alias.name,
                        "line": node.lineno,
                        "col": node.col_offset,
                        "end_line": getattr(node, "end_lineno", node.lineno),
                        "end_col": getattr(node, "end_col_offset", 0),
                    })
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    symbols.append({
                        "kind": "import",
                        "name": alias.asname or alias.name,
                        "module": module,
                        "line": node.lineno,
                        "col": node.col_offset,
                        "end_line": getattr(node, "end_lineno", node.lineno),
                        "end_col": getattr(node, "end_col_offset", 0),
                        "from_import": True,
                    })
            elif isinstance(node, ast.Assign | ast.AnnAssign):
                targets = self._assign_targets(node)
                for target in targets:
                    symbols.append({
                        "kind": "variable",
                        "name": target,
                        "line": node.lineno,
                        "col": node.col_offset,
                        "end_line": getattr(node, "end_lineno", node.lineno),
                        "end_col": getattr(node, "end_col_offset", 0),
                    })
        return symbols

    # ------------------------------------------------------------------
    # Reference finding
    # ------------------------------------------------------------------

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        """Find all name references to *symbol* in *source*."""
        try:
            tree = self.parse(source, path)
        except SyntaxError:
            return []

        refs: list[dict[str, Any]] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and node.id == symbol:
                refs.append({
                    "line": node.lineno,
                    "col": node.col_offset,
                    "end_line": getattr(node, "end_lineno", node.lineno),
                    "end_col": getattr(node, "end_col_offset", 0),
                    "context": "name",
                })
            elif isinstance(node, ast.Attribute) and node.attr == symbol:
                refs.append({
                    "line": node.lineno,
                    "col": node.col_offset,
                    "end_line": getattr(node, "end_lineno", node.lineno),
                    "end_col": getattr(node, "end_col_offset", 0),
                    "context": "attribute",
                })
            elif isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef) and node.name == symbol:
                refs.append({
                    "line": node.lineno,
                    "col": node.col_offset,
                    "end_line": getattr(node, "end_lineno", node.lineno),
                    "end_col": getattr(node, "end_col_offset", 0),
                    "context": "definition",
                })
            elif isinstance(node, ast.ClassDef) and node.name == symbol:
                refs.append({
                    "line": node.lineno,
                    "col": node.col_offset,
                    "end_line": getattr(node, "end_lineno", node.lineno),
                    "end_col": getattr(node, "end_col_offset", 0),
                    "context": "definition",
                })
            elif isinstance(node, ast.arg) and node.arg == symbol:
                refs.append({
                    "line": node.lineno,
                    "col": node.col_offset,
                    "end_line": getattr(node, "end_lineno", node.lineno),
                    "end_col": getattr(node, "end_col_offset", 0),
                    "context": "parameter",
                })
        return refs

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _function_symbol(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> dict[str, Any]:
        decorators = [self._unparse_decorator(d) for d in node.decorator_list]
        params = self._extract_params(node.args)
        return_annotation = None
        if node.returns:
            try:
                return_annotation = ast.unparse(node.returns)
            except Exception:
                return_annotation = None
        return {
            "kind": "function",
            "name": node.name,
            "line": node.lineno,
            "col": node.col_offset,
            "end_line": getattr(node, "end_lineno", node.lineno),
            "end_col": getattr(node, "end_col_offset", 0),
            "async": isinstance(node, ast.AsyncFunctionDef),
            "decorators": decorators,
            "params": params,
            "return_type": return_annotation,
            "docstring": ast.get_docstring(node),
        }

    def _class_symbol(self, node: ast.ClassDef) -> dict[str, Any]:
        decorators = [self._unparse_decorator(d) for d in node.decorator_list]
        bases = []
        for base in node.bases:
            try:
                bases.append(ast.unparse(base))
            except Exception:
                bases.append("<unknown>")
        methods = []
        class_vars = []
        for child in ast.iter_child_nodes(node):
            if isinstance(child, ast.FunctionDef | ast.AsyncFunctionDef):
                methods.append(self._function_symbol(child))
            elif isinstance(child, ast.Assign | ast.AnnAssign):
                for t in self._assign_targets(child):
                    class_vars.append(t)
        return {
            "kind": "class",
            "name": node.name,
            "line": node.lineno,
            "col": node.col_offset,
            "end_line": getattr(node, "end_lineno", node.lineno),
            "end_col": getattr(node, "end_col_offset", 0),
            "decorators": decorators,
            "bases": bases,
            "methods": methods,
            "class_variables": class_vars,
            "docstring": ast.get_docstring(node),
        }

    @staticmethod
    def _extract_params(args: ast.arguments) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        defaults_offset = len(args.args) - len(args.defaults)
        for i, arg in enumerate(args.args):
            if arg.arg == "self" or arg.arg == "cls":
                continue
            annotation = None
            if arg.annotation:
                try:
                    annotation = ast.unparse(arg.annotation)
                except Exception:
                    annotation = None
            default = None
            di = i - defaults_offset
            if 0 <= di < len(args.defaults):
                try:
                    default = ast.unparse(args.defaults[di])
                except Exception:
                    default = None
            params.append({"name": arg.arg, "type": annotation, "default": default})
        if args.vararg:
            annotation = None
            if args.vararg.annotation:
                try:
                    annotation = ast.unparse(args.vararg.annotation)
                except Exception:
                    pass
            params.append({"name": f"*{args.vararg.arg}", "type": annotation, "default": None})
        if args.kwarg:
            annotation = None
            if args.kwarg.annotation:
                try:
                    annotation = ast.unparse(args.kwarg.annotation)
                except Exception:
                    pass
            params.append({"name": f"**{args.kwarg.arg}", "type": annotation, "default": None})
        return params

    @staticmethod
    def _assign_targets(node: ast.Assign | ast.AnnAssign) -> list[str]:
        targets = []
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    targets.append(target.id)
                elif isinstance(target, ast.Tuple | ast.List):
                    for elt in target.elts:
                        if isinstance(elt, ast.Name):
                            targets.append(elt.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            targets.append(node.target.id)
        return targets

    @staticmethod
    def _unparse_decorator(node: ast.expr) -> str:
        try:
            return ast.unparse(node)
        except Exception:
            return "<unknown>"


# Register on import
_register(PythonAnalyzer())
