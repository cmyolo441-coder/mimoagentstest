"""Java language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_CLASS = re.compile(
    r"(?:public\s+)?(?:abstract\s+)?(?:final\s+)?class\s+(\w+)(?:<[^>]*>)?(?:\s+extends\s+(\w+))?(?:\s+implements\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_INTERFACE = re.compile(
    r"(?:public\s+)?interface\s+(\w+)(?:<[^>]*>)?(?:\s+extends\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_ENUM = re.compile(
    r"(?:public\s+)?enum\s+(\w+)\s*(?:implements\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_METHOD = re.compile(
    r"(?:(?:public|private|protected|static|final|abstract|synchronized|native|default)\s+)*"
    r"(?:<[^>]*>\s+)?(\w+(?:<[^>]*>)?(?:\[\])*)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[^\{]+)?\s*\{",
    re.MULTILINE,
)
_RE_CONSTRUCTOR = re.compile(
    r"(?:public|private|protected)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[^\{]+)?\s*\{",
    re.MULTILINE,
)
_RE_FIELD = re.compile(
    r"(?:(?:public|private|protected|static|final|volatile|transient)\s+)*(\w+(?:<[^>]*>)?(?:\[\])*)\s+(\w+)\s*(?:=[^;]+)?;",
    re.MULTILINE,
)
_RE_IMPORT = re.compile(
    r"import\s+(?:static\s+)?([^;]+);",
    re.MULTILINE,
)
_RE_ANNOTATION = re.compile(
    r"@(\w+)(?:\(([^)]*)\))?",
    re.MULTILINE,
)


class JavaAnalyzer:
    """Regex-based analyzer for Java source files."""

    language = "java"
    file_extensions = {".java"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Package declaration
        pkg = re.match(r"package\s+([^;]+);", source)
        if pkg:
            symbols.append({"kind": "package", "name": pkg.group(1).strip(), "line": 1, "col": 0, "end_line": 1})

        # Imports
        for m in _RE_IMPORT.finditer(source):
            import_path = m.group(1).strip()
            name = import_path.split(".")[-1]
            if name == "*":
                name = import_path
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "import",
                "name": name,
                "module": import_path,
                "line": line,
                "col": 0,
                "static": "static" in source[max(0, m.start() - 10) : m.start()],
            })

        # Interfaces
        for m in _RE_INTERFACE.finditer(source):
            name = m.group(1)
            extends_str = m.group(2)
            line = source[: m.start()].count("\n") + 1
            extends = [e.strip() for e in extends_str.split(",")] if extends_str else []
            symbols.append({
                "kind": "interface",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "extends": extends,
                "annotations": self._annotations_above(source, m.start()),
            })

        # Classes
        for m in _RE_CLASS.finditer(source):
            name = m.group(1)
            base = m.group(2)
            impl_str = m.group(3)
            line = source[: m.start()].count("\n") + 1
            implements = [i.strip() for i in impl_str.split(",")] if impl_str else []
            symbols.append({
                "kind": "class",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "bases": [base] if base else [],
                "implements": implements,
                "annotations": self._annotations_above(source, m.start()),
            })

        # Enums
        for m in _RE_ENUM.finditer(source):
            symbols.append({
                "kind": "enum",
                "name": m.group(1),
                "line": source[: m.start()].count("\n") + 1,
                "col": 0,
                "end_line": source[: m.start()].count("\n") + 1,
            })

        # Constructors (must come before methods to avoid double-matching)
        constructor_names = set()
        for m in _RE_CONSTRUCTOR.finditer(source):
            name = m.group(1)
            # Only match if it's not a method (return type before name)
            before = source[max(0, m.start() - 50) : m.start()]
            if re.search(r"\b(void|int|long|double|float|boolean|char|byte|short|String|List|Map|Set|Optional)\b", before):
                continue
            constructor_names.add(name)
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "constructor",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_java_params(m.group(2)),
            })

        # Methods
        for m in _RE_METHOD.finditer(source):
            return_type = m.group(1)
            name = m.group(2)
            if name in constructor_names:
                continue
            params_str = m.group(3)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 100) : m.start()]
            symbols.append({
                "kind": "method",
                "name": name,
                "return_type": return_type,
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_java_params(params_str),
                "static": "static" in prefix,
                "abstract": "abstract" in prefix,
                "annotations": self._annotations_above(source, m.start()),
            })

        # Fields
        for m in _RE_FIELD.finditer(source):
            typ = m.group(1)
            name = m.group(2)
            # Skip if it looks like a method call
            if "(" in source[m.end() : m.end() + 2]:
                continue
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "field",
                "name": name,
                "type": typ,
                "line": line,
                "col": 0,
                "end_line": line,
            })

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_java_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        depth = 0
        current = ""
        for ch in params_str:
            if ch == "<":
                depth += 1
                current += ch
            elif ch == ">":
                depth -= 1
                current += ch
            elif ch == "," and depth == 0:
                params.append(current.strip())
                current = ""
            else:
                current += ch
        if current.strip():
            params.append(current.strip())

        result: list[dict[str, Any]] = []
        for p in params:
            p = p.strip()
            if not p:
                continue
            # Remove annotations
            p = re.sub(r"@\w+(?:\([^)]*\))?\s*", "", p).strip()
            parts = p.rsplit(None, 1)
            if len(parts) == 2:
                result.append({"name": parts[1], "type": parts[0], "default": None})
            else:
                result.append({"name": p, "type": None, "default": None})
        return result

    @staticmethod
    def _annotations_above(source: str, pos: int) -> list[str]:
        before = source[:pos].rstrip()
        annotations = []
        while before.endswith(")") or re.search(r"@\w+\s*$", before):
            # Find annotation start
            at_pos = before.rfind("@")
            if at_pos == -1:
                break
            ann = before[at_pos:].split("\n")[0].strip()
            annotations.insert(0, ann)
            before = before[:at_pos].rstrip()
        return annotations


_register(JavaAnalyzer())
