"""Kotlin language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_CLASS = re.compile(
    r"(?:(?:public|private|internal|protected|abstract|open|sealed|data|inner|inline|value)\s+)*"
    r"(?:class|object)\s+(\w+)(?:<[^>]*>)?(?:\s*\(([^)]*)\))?(?:\s*:\s*([^\{]+))?\s*\{?",
    re.MULTILINE,
)
_RE_INTERFACE = re.compile(
    r"(?:(?:public|private|internal|protected)\s+)*interface\s+(\w+)(?:<[^>]*>)?(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_ENUM = re.compile(
    r"(?:(?:public|private|internal|protected)\s+)*enum\s+class\s+(\w+)(?:\s*\([^)]*\))?(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_FUN = re.compile(
    r"(?:(?:public|private|internal|protected|open|override|abstract|suspend|inline|operator|infix|tailrec)\s+)*"
    r"fun\s+(?:<[^>]*>\s+)?(?:(\w+)\.)?(\w+)\s*(?:<[^>]*>)?\s*\(([^)]*)\)(?:\s*:\s*(.+?))?\s*(?:\{|=)",
    re.MULTILINE,
)
_RE_VAL = re.compile(
    r"(?:val|var)\s+(\w+)(?:\s*:\s*([^=]+))?\s*(?:=|by)",
    re.MULTILINE,
)
_RE_IMPORT = re.compile(
    r"import\s+([^;]+)",
    re.MULTILINE,
)
_RE_COMPANION = re.compile(
    r"companion\s+object\s*(?:\(\w+\))?\s*\{",
    re.MULTILINE,
)


class KotlinAnalyzer:
    """Regex-based analyzer for Kotlin source files."""

    language = "kotlin"
    file_extensions = {".kt", ".kts"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Imports
        for m in _RE_IMPORT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            imp = m.group(1).strip()
            name = imp.split(".")[-1]
            symbols.append({"kind": "import", "name": name, "module": imp, "line": line, "col": 0, "end_line": line})

        # Interfaces
        for m in _RE_INTERFACE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            bases = [b.strip() for b in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "interface", "name": m.group(1), "line": line, "col": 0, "end_line": line, "bases": bases})

        # Enums
        for m in _RE_ENUM.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "enum", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Classes / objects
        for m in _RE_CLASS.finditer(source):
            name = m.group(1)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 40) : m.start()]
            bases_str = m.group(3)
            bases = [b.strip().split("(")[0].strip() for b in bases_str.split(",")] if bases_str else []
            symbols.append({
                "kind": "object" if "object" in prefix else "class",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "bases": bases,
                "data": "data" in prefix,
                "sealed": "sealed" in prefix,
                "abstract": "abstract" in prefix,
            })

        # Functions
        for m in _RE_FUN.finditer(source):
            receiver = m.group(1)
            name = m.group(2)
            params_str = m.group(3)
            return_type = m.group(4)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 80) : m.start()]
            symbols.append({
                "kind": "function",
                "name": name,
                "receiver": receiver,
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_kotlin_params(params_str),
                "return_type": return_type.strip() if return_type else None,
                "suspend": "suspend" in prefix,
                "override": "override" in prefix,
                "operator": "operator" in prefix,
            })

        # Properties
        for m in _RE_VAL.finditer(source):
            name = m.group(1)
            typ = m.group(2)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 10) : m.start()]
            if not any(s["name"] == name for s in symbols):
                symbols.append({
                    "kind": "property",
                    "name": name,
                    "type": typ.strip() if typ else None,
                    "line": line,
                    "col": 0,
                    "end_line": line,
                    "mutable": "var" in prefix,
                })

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_kotlin_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        depth = 0
        current = ""
        for ch in params_str:
            if ch in "<(":
                depth += 1
                current += ch
            elif ch in ">)":
                depth -= 1
                current += ch
            elif ch == "," and depth == 0:
                params.append(current.strip())
                current = ""
            else:
                current += ch
        if current.strip():
            params.append(current.strip())

        result: list[dict[str, Any]] = []
        for p in params:
            p = p.strip()
            if not p:
                continue
            # Remove modifiers
            for mod in ("val", "var", "noinline", "crossinline", "vararg"):
                if p.startswith(mod + " "):
                    p = p[len(mod) + 1 :]
            parts = p.split(":")
            if len(parts) >= 2:
                name = parts[0].strip()
                rest = ":".join(parts[1:]).strip()
                typ = rest.split("=")[0].strip()
                default = rest.split("=")[1].strip() if "=" in rest else None
                result.append({"name": name, "type": typ, "default": default})
            else:
                result.append({"name": p, "type": None, "default": None})
        return result


_register(KotlinAnalyzer())
