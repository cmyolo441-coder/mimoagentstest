"""Haskell language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_FUNCTION_TYPE = re.compile(
    r"^(\w+(?:\s*,\s*\w+)*)\s*::\s*(.+)$",
    re.MULTILINE,
)
_RE_FUNCTION_DECL = re.compile(
    r"^(\w+)\s+(?:(?:(?:\w+|\(.*?\)|\[.*?\]|_)\s+)+)=(?!=)",
    re.MULTILINE,
)
_RE_DATA = re.compile(
    r"data\s+(?:family\s+)?(\w+)(?:\s+\w+)*\s*(?:=\s*([^|]+))?(?:\|(.+))?",
    re.MULTILINE,
)
_RE_TYPE = re.compile(
    r"type\s+(?:family\s+)?(\w+)(?:\s+\w+)*\s*(?:=\s*(.+))?",
    re.MULTILINE,
)
_RE_CLASS = re.compile(
    r"class\s+(?:\w+\s+=>\s+)?(\w+)\s+(\w+)(?:\s+where)?",
    re.MULTILINE,
)
_RE_INSTANCE = re.compile(
    r"instance\s+(?:\w+\s+=>\s+)?(\w+)\s+(\S+)\s+where",
    re.MULTILINE,
)
_RE_IMPORT = re.compile(
    r"^import\s+(?:qualified\s+)?(\S+)(?:\s+\(([^)]*)\))?(?:\s+as\s+(\w+))?",
    re.MULTILINE,
)
_RE_MODULE = re.compile(
    r"^module\s+(\S+)\s*(?:\(([^)]*)\))?\s+where",
    re.MULTILINE,
)
_RE_NEWTYPE = re.compile(
    r"newtype\s+(\w+)(?:\s+\w+)*\s*=\s*(\w+)\s+(.+)",
    re.MULTILINE,
)


class HaskellAnalyzer:
    """Regex-based analyzer for Haskell source files."""

    language = "haskell"
    file_extensions = {".hs", ".lhs", ".hs-boot"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Module declaration
        for m in _RE_MODULE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            exports = [e.strip() for e in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "module", "name": m.group(1), "line": line, "col": 0, "end_line": line, "exports": exports})

        # Imports
        for m in _RE_IMPORT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            module = m.group(1)
            imports_str = m.group(2)
            alias = m.group(3)
            symbols.append({
                "kind": "import",
                "name": alias or module.split(".")[-1],
                "module": module,
                "line": line,
                "col": 0,
                "end_line": line,
                "qualified": "qualified" in source[max(0, m.start() - 15) : m.start()],
                "explicit_imports": [i.strip() for i in imports_str.split(",")] if imports_str else None,
            })

        # Data declarations
        for m in _RE_DATA.finditer(source):
            line = source[: m.start()].count("\n") + 1
            constructors = []
            if m.group(2):
                constructors.append(m.group(2).strip())
            if m.group(3):
                constructors.extend(c.strip() for c in m.group(3).split("|") if c.strip())
            symbols.append({
                "kind": "data",
                "name": m.group(1),
                "line": line,
                "col": 0,
                "end_line": line,
                "constructors": constructors,
            })

        # Newtype declarations
        for m in _RE_NEWTYPE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "newtype",
                "name": m.group(1),
                "line": line,
                "col": 0,
                "end_line": line,
                "constructor": m.group(2),
            })

        # Type aliases
        for m in _RE_TYPE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "type",
                "name": m.group(1),
                "line": line,
                "col": 0,
                "end_line": line,
            })

        # Type classes
        for m in _RE_CLASS.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "class",
                "name": m.group(1),
                "param": m.group(2),
                "line": line,
                "col": 0,
                "end_line": line,
            })

        # Instances
        for m in _RE_INSTANCE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "instance",
                "name": f"{m.group(1)} {m.group(2)}",
                "class_name": m.group(1),
                "type": m.group(2),
                "line": line,
                "col": 0,
                "end_line": line,
            })

        # Function type signatures
        for m in _RE_FUNCTION_TYPE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            names = [n.strip() for n in m.group(1).split(",")]
            sig = m.group(2).strip()
            for name in names:
                if name and name[0].islower():
                    symbols.append({
                        "kind": "function",
                        "name": name,
                        "line": line,
                        "col": 0,
                        "end_line": line,
                        "type_signature": sig,
                    })

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs


_register(HaskellAnalyzer())
