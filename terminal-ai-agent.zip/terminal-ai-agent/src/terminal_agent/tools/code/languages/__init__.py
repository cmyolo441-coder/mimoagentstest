"""Per-language AST analysis implementations.

Each module exposes a ``LanguageAnalyzer`` class that implements the
:class:`BaseLanguageAnalyzer` protocol, providing language-specific
parsing, symbol extraction, and reference finding capabilities.

Supported languages:
    python, javascript, typescript, go, rust, java, c, cpp, csharp,
    ruby, php, swift, kotlin, scala, haskell, lua, zig, dart, r
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol, runtime_checkable


# ---------------------------------------------------------------------------
# Analyzer Protocol
# ---------------------------------------------------------------------------

@runtime_checkable
class BaseLanguageAnalyzer(Protocol):
    """Protocol that every language analyzer must satisfy."""

    @property
    def language(self) -> str:
        """Canonical language name (e.g. ``'python'``)."""
        ...

    @property
    def file_extensions(self) -> set[str]:
        """File extensions handled (e.g. ``{'.py', '.pyw', '.pyi'}``)."""
        ...

    def can_handle(self, path: Path) -> bool:
        """Return *True* if this analyzer can handle *path*."""
        ...

    def parse(self, source: str, path: Path | None = None) -> Any:
        """Parse *source* and return an AST or parsed representation."""
        ...

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        """Return a list of symbol dicts from *source*."""
        ...

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        """Return locations where *symbol* is referenced in *source*."""
        ...


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_ANALYZERS: dict[str, BaseLanguageAnalyzer] = {}


def _register(analyzer: BaseLanguageAnalyzer) -> None:
    for ext in analyzer.file_extensions:
        _ANALYZERS[ext] = analyzer


def get_analyzer(path: Path) -> BaseLanguageAnalyzer | None:
    """Return the analyzer registered for *path*'s extension, or *None*."""
    return _ANALYZERS.get(path.suffix.lower())


def get_analyzer_for_language(language: str) -> BaseLanguageAnalyzer | None:
    """Return the analyzer for the given language name, or *None*."""
    for analyzer in _ANALYZERS.values():
        if analyzer.language == language:
            return analyzer
    return None


def supported_languages() -> list[str]:
    """Return a sorted list of supported language names."""
    seen: set[str] = set()
    for a in _ANALYZERS.values():
        seen.add(a.language)
    return sorted(seen)


def supported_extensions() -> set[str]:
    """Return all supported file extensions."""
    return set(_ANALYZERS.keys())


# ---------------------------------------------------------------------------
# Eager registration — import every language module so analyzers register
# ---------------------------------------------------------------------------

def _load_all() -> None:
    """Import all language modules to trigger registration."""
    from . import (  # noqa: F401
        python,
        javascript,
        typescript,
        go,
        rust,
        java,
        c,
        cpp,
        csharp,
        ruby,
        php,
        swift,
        kotlin,
        scala,
        haskell,
        lua,
        zig,
        dart,
        r,
    )


_load_all()
