"""PHP language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_CLASS = re.compile(
    r"(?:abstract\s+|final\s+)?class\s+(\w+)(?:\s+extends\s+(\w+))?(?:\s+implements\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_INTERFACE = re.compile(
    r"interface\s+(\w+)(?:\s+extends\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_TRAIT = re.compile(
    r"trait\s+(\w+)\s*\{",
    re.MULTILINE,
)
_RE_FUNCTION = re.compile(
    r"(?:(?:public|protected|private|static|abstract|final)\s+)*function\s+(\w+)\s*\(([^)]*)\)(?:\s*:\s*(\??\w+))?",
    re.MULTILINE,
)
_RE_NAMESPACE = re.compile(
    r"namespace\s+([^;{]+)",
    re.MULTILINE,
)
_RE_USE = re.compile(
    r"use\s+([^;]+);",
    re.MULTILINE,
)
_RE_VARIABLE = re.compile(
    r"(?:(?:public|protected|private|static|const)\s+)*(\$\w+)\s*(?:=\s*[^;]+)?;",
    re.MULTILINE,
)
_RE_DEFINE = re.compile(
    r"define\s*\(\s*['\"](\w+)['\"]",
    re.MULTILINE,
)
_RE_INCLUDE = re.compile(
    r"(?:require|require_once|include|include_once)\s+(?:\(?['\"]([^'\"]+)['\"]\)?|(\$\w+))",
    re.MULTILINE,
)


class PHPAnalyzer:
    """Regex-based analyzer for PHP source files."""

    language = "php"
    file_extensions = {".php", ".phtml", ".php3", ".php4", ".php5", ".phps"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Namespace
        for m in _RE_NAMESPACE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "namespace", "name": m.group(1).strip(), "line": line, "col": 0, "end_line": line})

        # Use / use function / use const
        for m in _RE_USE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            for use in m.group(1).split(","):
                use = use.strip()
                if use:
                    name = use.split("\\")[-1].strip()
                    symbols.append({"kind": "use", "name": name, "fqn": use, "line": line, "col": 0, "end_line": line})

        # Includes
        for m in _RE_INCLUDE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "include", "name": m.group(1) or m.group(2), "line": line, "col": 0, "end_line": line})

        # Interfaces
        for m in _RE_INTERFACE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            extends = [e.strip() for e in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "interface", "name": m.group(1), "line": line, "col": 0, "end_line": line, "extends": extends})

        # Traits
        for m in _RE_TRAIT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "trait", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Classes
        for m in _RE_CLASS.finditer(source):
            line = source[: m.start()].count("\n") + 1
            bases = [m.group(2)] if m.group(2) else []
            implements = [i.strip() for i in m.group(3).split(",")] if m.group(3) else []
            symbols.append({
                "kind": "class",
                "name": m.group(1),
                "line": line,
                "col": 0,
                "end_line": line,
                "bases": bases,
                "implements": implements,
            })

        # Functions / methods
        for m in _RE_FUNCTION.finditer(source):
            name = m.group(1)
            params_str = m.group(2)
            return_type = m.group(3)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 50) : m.start()]
            is_method = any(kw in prefix for kw in ("public", "protected", "private", "static", "abstract", "final"))
            symbols.append({
                "kind": "method" if is_method else "function",
                "name": name,
                "return_type": return_type,
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_php_params(params_str),
                "static": "static" in prefix,
                "abstract": "abstract" in prefix,
            })

        # Class properties
        for m in _RE_VARIABLE.finditer(source):
            name = m.group(1)
            line = source[: m.start()].count("\n") + 1
            if not any(s["name"] == name for s in symbols):
                symbols.append({"kind": "variable", "name": name, "line": line, "col": 0, "end_line": line})

        # Constants
        for m in _RE_DEFINE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "constant", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        # Match $var, ClassName, method calls
        for m in re.finditer(r"[\$@]?" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_php_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        for p in params_str.split(","):
            p = p.strip()
            if not p:
                continue
            # PHP: type $name = default
            parts = p.split("=")
            default = parts[1].strip() if len(parts) > 1 else None
            decl = parts[0].strip()
            tokens = decl.split()
            if len(tokens) >= 2:
                typ = tokens[0]
                name = tokens[1].lstrip("$")
            else:
                typ = None
                name = tokens[0].lstrip("$")
            if name:
                params.append({"name": name, "type": typ, "default": default})
        return params


_register(PHPAnalyzer())
