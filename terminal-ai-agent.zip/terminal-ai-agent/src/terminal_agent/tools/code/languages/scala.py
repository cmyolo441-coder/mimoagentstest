"""Scala language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_CLASS = re.compile(
    r"(?:(?:abstract|sealed|case|open)\s+)*class\s+(\w+)(?:\[.*?\])?\s*(?:\(([^)]*)\))?(?:\s*(?:extends|with)\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_OBJECT = re.compile(
    r"(?:case\s+)?object\s+(\w+)(?:\s+extends\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_TRAIT = re.compile(
    r"(?:(?:sealed|open)\s+)*trait\s+(\w+)(?:\[.*?\])?(?:\s+extends\s+([^\{]+))?\s*(?:\{|$)",
    re.MULTILINE,
)
_RE_DEF = re.compile(
    r"(?:(?:override|abstract|final|implicit|lazy|inline)\s+)*def\s+(\w+)(?:\[.*?\])?\s*(?:\(([^)]*)\))?(?:\s*:\s*(.+?))?\s*=",
    re.MULTILINE,
)
_RE_VAL = re.compile(
    r"(?:(?:implicit|lazy|override)\s+)*val\s+(\w+)(?:\s*:\s*([^=]+))?\s*=",
    re.MULTILINE,
)
_RE_VAR = re.compile(
    r"(?:(?:implicit|lazy|override)\s+)*var\s+(\w+)(?:\s*:\s*([^=]+))?\s*=",
    re.MULTILINE,
)
_RE_IMPORT = re.compile(
    r"import\s+([^\n]+)",
    re.MULTILINE,
)
_RE_TYPE = re.compile(
    r"type\s+(\w+)(?:\[.*?\])?\s*=",
    re.MULTILINE,
)


class ScalaAnalyzer:
    """Regex-based analyzer for Scala source files."""

    language = "scala"
    file_extensions = {".scala", ".sc"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Imports
        for m in _RE_IMPORT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            imp = m.group(1).strip()
            parts = imp.split(".")
            name = parts[-1].strip()
            if name == "_":
                name = imp
            symbols.append({"kind": "import", "name": name, "module": imp, "line": line, "col": 0, "end_line": line})

        # Traits
        for m in _RE_TRAIT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            bases = [b.strip() for b in m.group(2).split("with")] if m.group(2) else []
            symbols.append({"kind": "trait", "name": m.group(1), "line": line, "col": 0, "end_line": line, "bases": bases})

        # Objects
        for m in _RE_OBJECT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 10) : m.start()]
            bases = [b.strip() for b in m.group(2).split("with")] if m.group(2) else []
            symbols.append({
                "kind": "object",
                "name": m.group(1),
                "line": line,
                "col": 0,
                "end_line": line,
                "bases": bases,
                "case": "case" in prefix,
            })

        # Classes
        for m in _RE_CLASS.finditer(source):
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 20) : m.start()]
            bases_str = m.group(3)
            bases = [b.strip().split("with")[-1].strip() for b in bases_str.split(",")] if bases_str else []
            symbols.append({
                "kind": "class",
                "name": m.group(1),
                "line": line,
                "col": 0,
                "end_line": line,
                "bases": bases,
                "case": "case" in prefix,
                "abstract": "abstract" in prefix,
                "sealed": "sealed" in prefix,
            })

        # Type aliases
        for m in _RE_TYPE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "type", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Functions
        for m in _RE_DEF.finditer(source):
            name = m.group(1)
            params_str = m.group(2)
            return_type = m.group(3)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 40) : m.start()]
            symbols.append({
                "kind": "function",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_scala_params(params_str or ""),
                "return_type": return_type.strip() if return_type else None,
                "override": "override" in prefix,
                "implicit": "implicit" in prefix,
            })

        # vals
        for m in _RE_VAL.finditer(source):
            name = m.group(1)
            typ = m.group(2)
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "val", "name": name, "type": typ.strip() if typ else None, "line": line, "col": 0, "end_line": line})

        # vars
        for m in _RE_VAR.finditer(source):
            name = m.group(1)
            typ = m.group(2)
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "var", "name": name, "type": typ.strip() if typ else None, "line": line, "col": 0, "end_line": line})

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_scala_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        depth = 0
        current = ""
        for ch in params_str:
            if ch in "[(":
                depth += 1
                current += ch
            elif ch in "])":
                depth -= 1
                current += ch
            elif ch == "," and depth == 0:
                params.append(current.strip())
                current = ""
            else:
                current += ch
        if current.strip():
            params.append(current.strip())

        result: list[dict[str, Any]] = []
        for p in params:
            p = p.strip()
            if not p:
                continue
            parts = p.split(":")
            if len(parts) >= 2:
                name = parts[0].strip().split()[-1]
                typ = ":".join(parts[1:]).strip().split("=")[0].strip()
                default = p.split("=")[1].strip() if "=" in p else None
                result.append({"name": name, "type": typ, "default": default})
            else:
                result.append({"name": p, "type": None, "default": None})
        return result


_register(ScalaAnalyzer())
