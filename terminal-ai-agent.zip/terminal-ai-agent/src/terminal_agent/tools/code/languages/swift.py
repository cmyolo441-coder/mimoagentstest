"""Swift language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_CLASS = re.compile(
    r"(?:(?:public|private|internal|open|final)\s+)*class\s+(\w+)(?:<[^>]*>)?(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_STRUCT = re.compile(
    r"(?:(?:public|private|internal)\s+)*struct\s+(\w+)(?:<[^>]*>)?(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_ENUM = re.compile(
    r"(?:(?:public|private|internal)\s+)*enum\s+(\w+)(?:<[^>]*>)?(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_PROTOCOL = re.compile(
    r"(?:(?:public|private|internal)\s+)*protocol\s+(\w+)(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_FUNC = re.compile(
    r"(?:(?:public|private|internal|open|static|class|mutating|override|convenience|required|throws|rethrows|async)\s+)*"
    r"func\s+(\w+)(?:<[^>]*>)?\s*\(([^)]*)\)(?:\s*(?:throws\s+)?(?:async\s+)?)?(?:->\s*(.+?))?\s*\{",
    re.MULTILINE,
)
_RE_INIT = re.compile(
    r"(?:(?:public|private|internal|open|convenience|required|failable)\s+)*(?:convenience\s+)?(?:required\s+)?init\??\s*\(([^)]*)\)",
    re.MULTILINE,
)
_RE_LET = re.compile(
    r"(?:let|var)\s+(\w+)\s*(?::\s*([^=]+))?\s*=",
    re.MULTILINE,
)
_RE_IMPORT = re.compile(
    r"import\s+(\w+)",
    re.MULTILINE,
)
_RE_EXTENSION = re.compile(
    r"extension\s+(\w+)(?:<[^>]*>)?(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_TYPEALIAS = re.compile(
    r"typealias\s+(\w+)\s*=\s*(.+)",
    re.MULTILINE,
)


class SwiftAnalyzer:
    """Regex-based analyzer for Swift source files."""

    language = "swift"
    file_extensions = {".swift"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Imports
        for m in _RE_IMPORT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "import", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Protocols
        for m in _RE_PROTOCOL.finditer(source):
            line = source[: m.start()].count("\n") + 1
            conformances = [c.strip() for c in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "protocol", "name": m.group(1), "line": line, "col": 0, "end_line": line, "conformances": conformances})

        # Extensions
        for m in _RE_EXTENSION.finditer(source):
            line = source[: m.start()].count("\n") + 1
            conformances = [c.strip() for c in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "extension", "name": m.group(1), "line": line, "col": 0, "end_line": line, "conformances": conformances})

        # Structs
        for m in _RE_STRUCT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            conformances = [c.strip() for c in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "struct", "name": m.group(1), "line": line, "col": 0, "end_line": line, "conformances": conformances})

        # Classes
        for m in _RE_CLASS.finditer(source):
            line = source[: m.start()].count("\n") + 1
            conformances = [c.strip() for c in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "class", "name": m.group(1), "line": line, "col": 0, "end_line": line, "conformances": conformances})

        # Enums
        for m in _RE_ENUM.finditer(source):
            line = source[: m.start()].count("\n") + 1
            conformances = [c.strip() for c in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "enum", "name": m.group(1), "line": line, "col": 0, "end_line": line, "conformances": conformances})

        # Functions
        for m in _RE_FUNC.finditer(source):
            name = m.group(1)
            params_str = m.group(2)
            return_type = m.group(3)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 80) : m.start()]
            symbols.append({
                "kind": "function",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_swift_params(params_str),
                "return_type": return_type.strip() if return_type else None,
                "static": "static" in prefix,
                "async": "async" in prefix,
                "throws": "throws" in prefix or "rethrows" in prefix,
            })

        # Type aliases
        for m in _RE_TYPEALIAS.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "typealias", "name": m.group(1), "type": m.group(2).strip(), "line": line, "col": 0, "end_line": line})

        # Properties (let/var)
        for m in _RE_LET.finditer(source):
            name = m.group(1)
            typ = m.group(2)
            line = source[: m.start()].count("\n") + 1
            if not any(s["name"] == name for s in symbols):
                symbols.append({"kind": "variable", "name": name, "type": typ.strip() if typ else None, "line": line, "col": 0, "end_line": line})

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_swift_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        depth = 0
        current = ""
        for ch in params_str:
            if ch in "<(":
                depth += 1
                current += ch
            elif ch in ">)":
                depth -= 1
                current += ch
            elif ch == "," and depth == 0:
                params.append(current.strip())
                current = ""
            else:
                current += ch
        if current.strip():
            params.append(current.strip())

        result: list[dict[str, Any]] = []
        for p in params:
            p = p.strip()
            if not p:
                continue
            # Swift: label name: Type = default
            parts = p.split(":")
            if len(parts) >= 2:
                label_name = parts[0].strip().split()[-1] if " " in parts[0] else parts[0].strip()
                rest = ":".join(parts[1:]).strip()
                typ = rest.split("=")[0].strip()
                default = rest.split("=")[1].strip() if "=" in rest else None
                result.append({"name": label_name, "type": typ, "default": default})
            else:
                result.append({"name": p, "type": None, "default": None})
        return result


_register(SwiftAnalyzer())
