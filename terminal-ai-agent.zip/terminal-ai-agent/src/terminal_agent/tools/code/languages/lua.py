"""Lua language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_FUNCTION = re.compile(
    r"(?:local\s+)?function\s+(\w+(?:\.\w+)*(?::\w+)?)\s*\(([^)]*)\)",
    re.MULTILINE,
)
_RE_LOCAL_VAR = re.compile(
    r"local\s+(\w+)\s*=",
    re.MULTILINE,
)
_RE_GLOBAL_VAR = re.compile(
    r"^(\w+)\s*=(?!.*function)",
    re.MULTILINE,
)
_RE_MODULE = re.compile(
    r"(?:local\s+(\w+)\s*=\s*)?require\s*[\(\"']([^\"']+)[\"\)']",
    re.MULTILINE,
)
_RE_TABLE = re.compile(
    r"local\s+(\w+)\s*=\s*\{",
    re.MULTILINE,
)
_RE_METATABLE = re.compile(
    r"(\w+)\.__index\s*=\s*(\w+)",
    re.MULTILINE,
)


class LuaAnalyzer:
    """Regex-based analyzer for Lua source files."""

    language = "lua"
    file_extensions = {".lua"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Requires / imports
        for m in _RE_MODULE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            alias = m.group(1)
            module = m.group(2)
            symbols.append({
                "kind": "require",
                "name": alias or module.split(".")[-1],
                "module": module,
                "line": line,
                "col": 0,
                "end_line": line,
            })

        # Functions
        for m in _RE_FUNCTION.finditer(source):
            full_name = m.group(1)
            params_str = m.group(2)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 10) : m.start()]
            parts = full_name.split(":")
            is_method = len(parts) > 1
            symbols.append({
                "kind": "method" if is_method else "function",
                "name": parts[-1],
                "receiver": parts[0] if is_method else None,
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_lua_params(params_str),
                "local": "local" in prefix,
            })

        # Tables (used as modules/namespaces)
        for m in _RE_TABLE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "table", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Local variables
        for m in _RE_LOCAL_VAR.finditer(source):
            name = m.group(1)
            if not any(s["name"] == name for s in symbols):
                line = source[: m.start()].count("\n") + 1
                symbols.append({"kind": "variable", "name": name, "line": line, "col": 0, "end_line": line, "local": True})

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_lua_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        for p in params_str.split(","):
            p = p.strip()
            if p:
                if p == "...":
                    params.append({"name": "...", "type": None, "default": None})
                else:
                    params.append({"name": p, "type": None, "default": None})
        return params


_register(LuaAnalyzer())
