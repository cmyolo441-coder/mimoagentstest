"""C language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_FUNCTION = re.compile(
    r"^(?:(?:static|inline|extern|const|volatile|unsigned|signed|void|int|long|double|float|char|short|size_t|ssize_t|uint\d+_t|int\d+_t|bool|_Bool)\s+)*"
    r"(\w+)\s*\(([^)]*)\)\s*\{",
    re.MULTILINE,
)
_RE_TYPEDEF = re.compile(
    r"typedef\s+(?:(?:struct|enum|union)\s+(\w+)\s*\{[^}]*\}\s*(\w+)|(?:(\w+(?:\s*\*)?)\s+(\w+)))",
    re.MULTILINE | re.DOTALL,
)
_RE_STRUCT = re.compile(
    r"(?:typedef\s+)?struct\s+(\w+)?\s*\{([^}]*)\}(?:\s*(\w+))?",
    re.DOTALL,
)
_RE_ENUM = re.compile(
    r"enum\s+(\w+)?\s*\{([^}]*)\}",
    re.DOTALL,
)
_RE_INCLUDE = re.compile(
    r'#include\s+[<"]([^>"]+)[>"]',
    re.MULTILINE,
)
_RE_DEFINE = re.compile(
    r"#define\s+(\w+)(?:\(([^)]*)\))?\s+(.+)?",
    re.MULTILINE,
)
_RE_VARIABLE = re.compile(
    r"^(?:(?:static|extern|const|volatile|unsigned|signed)\s+)*"
    r"(\w+(?:\s*\*)?)\s+(\w+)(?:\s*\[[^\]]*\])?\s*(?:=[^;]+)?;",
    re.MULTILINE,
)


class CAnalyzer:
    """Regex-based analyzer for C source files."""

    language = "c"
    file_extensions = {".c", ".h"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Includes
        for m in _RE_INCLUDE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            header = m.group(1)
            symbols.append({
                "kind": "include",
                "name": header,
                "line": line,
                "col": 0,
                "end_line": line,
                "system": source[m.start() : m.end()].find("<") != -1,
            })

        # Preprocessor defines
        for m in _RE_DEFINE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "macro",
                "name": m.group(1),
                "params": [p.strip() for p in m.group(2).split(",")] if m.group(2) else None,
                "value": (m.group(3) or "").strip(),
                "line": line,
                "col": 0,
                "end_line": line,
            })

        # Typedefs
        for m in _RE_TYPEDEF.finditer(source):
            line = source[: m.start()].count("\n") + 1
            if m.group(1) and m.group(2):
                # typedef struct/enum/union { ... } name
                symbols.append({"kind": "typedef", "name": m.group(2), "line": line, "col": 0, "end_line": line})
            elif m.group(3) and m.group(4):
                symbols.append({"kind": "typedef", "name": m.group(4), "line": line, "col": 0, "end_line": line})

        # Structs
        for m in _RE_STRUCT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            name = m.group(1) or m.group(3) or f"<anonymous_{line}>"
            fields = self._parse_c_fields(m.group(2) or "")
            symbols.append({"kind": "struct", "name": name, "line": line, "col": 0, "end_line": line, "fields": fields})

        # Enums
        for m in _RE_ENUM.finditer(source):
            line = source[: m.start()].count("\n") + 1
            name = m.group(1) or f"<anonymous_{line}>"
            symbols.append({"kind": "enum", "name": name, "line": line, "col": 0, "end_line": line})

        # Functions — match lines that have a name followed by parens then brace
        for m in re.finditer(
            r"^((?:(?:static|inline|extern|const|volatile|unsigned|signed|struct|enum|union)\s+)*"
            r"(?:\w+(?:\s*\*)?)\s+)"
            r"(\w+)\s*\(([^)]*)\)\s*\{",
            source,
            re.MULTILINE,
        ):
            return_type = m.group(1).strip()
            name = m.group(2)
            params_str = m.group(3)
            line = source[: m.start()].count("\n") + 1
            # Skip if this looks like a control flow keyword
            if name in ("if", "for", "while", "switch", "return"):
                continue
            symbols.append({
                "kind": "function",
                "name": name,
                "return_type": return_type,
                "line": line,
                "col": m.start() - source.rfind("\n", 0, m.start()) - 1,
                "end_line": line,
                "params": self._parse_c_params(params_str),
                "static": "static" in return_type,
            })

        # Global variables (simple heuristic)
        for m in _RE_VARIABLE.finditer(source):
            name = m.group(2)
            line = source[: m.start()].count("\n") + 1
            if not any(s["name"] == name and s["kind"] in ("function", "macro") for s in symbols):
                symbols.append({
                    "kind": "variable",
                    "name": name,
                    "type": m.group(1),
                    "line": line,
                    "col": 0,
                    "end_line": line,
                })

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_c_fields(block: str) -> list[dict[str, Any]]:
        fields = []
        for line in block.splitlines():
            line = line.strip().rstrip(";").strip()
            if not line or line.startswith("//") or line.startswith("/*"):
                continue
            parts = line.rsplit(None, 1)
            if len(parts) == 2:
                fields.append({"name": parts[1].strip("*"), "type": parts[0]})
        return fields

    @staticmethod
    def _parse_c_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip() or params_str.strip() == "void":
            return params
        for p in params_str.split(","):
            p = p.strip()
            if not p:
                continue
            parts = p.rsplit(None, 1)
            if len(parts) == 2:
                params.append({"name": parts[1].strip("*"), "type": parts[0], "default": None})
            elif p == "...":
                params.append({"name": "...", "type": "va_args", "default": None})
            else:
                params.append({"name": p, "type": None, "default": None})
        return params


_register(CAnalyzer())
