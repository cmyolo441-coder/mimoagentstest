"""Ruby language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_CLASS = re.compile(
    r"class\s+(\w+)(?:\s*<\s*(\w+))?\s*$",
    re.MULTILINE,
)
_RE_MODULE = re.compile(
    r"module\s+(\w+)",
    re.MULTILINE,
)
_RE_METHOD = re.compile(
    r"(?:(?:def\s+self\.(\w+))|(?:def\s+(\w+)(?:[?!])?))\s*(?:\(([^)]*)\))?",
    re.MULTILINE,
)
_RE_REQUIRE = re.compile(
    r"(?:require|require_relative|load)\s+['\"]([^'\"]+)['\"]",
    re.MULTILINE,
)
_RE_ATTR = re.compile(
    r"(?:attr_accessor|attr_reader|attr_writer)\s+(:\w+(?:\s*,\s*:\w+)*)",
    re.MULTILINE,
)
_RE_CONSTANT = re.compile(
    r"([A-Z][A-Z0-9_]*)\s*=",
    re.MULTILINE,
)
_RE_INSTANCE_VAR = re.compile(
    r"@(\w+)\s*=",
    re.MULTILINE,
)
_RE_INCLUDE = re.compile(
    r"(?:include|extend)\s+(\w+(?:::\w+)*)",
    re.MULTILINE,
)


class RubyAnalyzer:
    """Regex-based analyzer for Ruby source files."""

    language = "ruby"
    file_extensions = {".rb", ".rake", ".gemspec", ".ru"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Requires
        for m in _RE_REQUIRE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "require", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Modules
        for m in _RE_MODULE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "module", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Classes
        for m in _RE_CLASS.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "class",
                "name": m.group(1),
                "line": line,
                "col": 0,
                "end_line": line,
                "bases": [m.group(2)] if m.group(2) else [],
            })

        # Methods
        for m in _RE_METHOD.finditer(source):
            class_method = m.group(1) is not None
            name = m.group(1) or m.group(2)
            params_str = m.group(3) or ""
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "method",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "class_method": class_method,
                "params": self._parse_ruby_params(params_str),
            })

        # Attributes
        for m in _RE_ATTR.finditer(source):
            line = source[: m.start()].count("\n") + 1
            kind = m.group(0).split()[0]
            names = [n.strip().lstrip(":") for n in m.group(1).split(",")]
            for name in names:
                symbols.append({"kind": "attribute", "name": name, "line": line, "col": 0, "end_line": line, "accessor": kind})

        # Constants
        for m in _RE_CONSTANT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "constant", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Includes / extends
        for m in _RE_INCLUDE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "mixin", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"(?:[@:]?\b|:)" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_ruby_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        for p in params_str.split(","):
            p = p.strip()
            if not p:
                continue
            if p.startswith("*"):
                p = p[1:]
            if p.startswith("**"):
                p = p[2:]
            name = p.split("=")[0].strip().lstrip(":")
            default = None
            if "=" in p:
                default = p.split("=", 1)[1].strip()
            if name:
                params.append({"name": name, "type": None, "default": default})
        return params


_register(RubyAnalyzer())
