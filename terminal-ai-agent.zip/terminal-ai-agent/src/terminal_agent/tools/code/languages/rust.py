"""Rust language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_FN = re.compile(
    r"(?:pub\s+)?(?:async\s+)?(?:unsafe\s+)?fn\s+(\w+)(?:<[^>]*>)?\s*\(([^)]*)\)(?:\s*->\s*([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_STRUCT = re.compile(
    r"(?:pub\s+)?struct\s+(\w+)(?:<[^>]*>)?(?:\s*\(([^)]*)\))?\s*(?:where\s+[^{]*?)?\{",
    re.MULTILINE,
)
_RE_ENUM = re.compile(
    r"(?:pub\s+)?enum\s+(\w+)(?:<[^>]*>)?\s*\{",
    re.MULTILINE,
)
_RE_TRAIT = re.compile(
    r"(?:pub\s+)?trait\s+(\w+)(?:<[^>]*>)?(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_IMPL = re.compile(
    r"impl(?:<[^>]*>)?\s+(\w+)(?:<[^>]*>)?\s*(?:for\s+(\w+)(?:<[^>]*>)?)?\s*(?:where\s+[^{]*?)?\{",
    re.MULTILINE,
)
_RE_USE = re.compile(
    r"(?:pub\s+)?use\s+([^;]+);",
    re.MULTILINE,
)
_RE_CONST = re.compile(
    r"(?:pub\s+)?(?:static|const)\s+(?:mut\s+)?(\w+)\s*:\s*([^=]+)=",
    re.MULTILINE,
)
_RE_MACRO = re.compile(
    r"(?:pub\s+)?macro_rules!\s+(\w+)",
    re.MULTILINE,
)


class RustAnalyzer:
    """Regex-based analyzer for Rust source files."""

    language = "rust"
    file_extensions = {".rs"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Functions
        for m in _RE_FN.finditer(source):
            name = m.group(1)
            params_str = m.group(2)
            return_type = m.group(3)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 20) : m.start()]
            symbols.append({
                "kind": "function",
                "name": name,
                "line": line,
                "col": m.start() - source.rfind("\n", 0, m.start()) - 1,
                "end_line": line,
                "params": self._parse_rust_params(params_str),
                "return_type": return_type.strip() if return_type else None,
                "async": "async" in prefix,
                "public": "pub" in prefix,
            })

        # Structs
        for m in _RE_STRUCT.finditer(source):
            name = m.group(1)
            tuple_fields = m.group(2)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 10) : m.start()]
            fields = []
            if not tuple_fields:
                brace_start = m.end() - 1
                brace_end = self._find_matching_brace(source, brace_start)
                if brace_end > brace_start:
                    body = source[brace_start + 1 : brace_end]
                    for fm in re.finditer(r"(?:pub\s+)?(\w+)\s*:\s*([^\n,]+)", body):
                        fields.append({"name": fm.group(1), "type": fm.group(2).strip()})
            symbols.append({
                "kind": "struct",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "fields": fields,
                "public": "pub" in prefix,
            })

        # Enums
        for m in _RE_ENUM.finditer(source):
            symbols.append({
                "kind": "enum",
                "name": m.group(1),
                "line": source[: m.start()].count("\n") + 1,
                "col": 0,
                "end_line": source[: m.start()].count("\n") + 1,
            })

        # Traits
        for m in _RE_TRAIT.finditer(source):
            name = m.group(1)
            bounds = m.group(2)
            line = source[: m.start()].count("\n") + 1
            supertraits = [b.strip() for b in bounds.split("+")] if bounds else []
            symbols.append({
                "kind": "trait",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "supertraits": supertraits,
            })

        # Impl blocks
        for m in _RE_IMPL.finditer(source):
            type_name = m.group(1)
            trait_name = m.group(2)
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "impl",
                "name": type_name,
                "trait": trait_name,
                "line": line,
                "col": 0,
                "end_line": line,
            })

        # Use statements
        for m in _RE_USE.finditer(source):
            path_str = m.group(1).strip()
            line = source[: m.start()].count("\n") + 1
            # Extract final names
            names = self._extract_use_names(path_str)
            for n in names:
                symbols.append({"kind": "import", "name": n, "module": path_str, "line": line, "col": 0})

        # Constants / statics
        for m in _RE_CONST.finditer(source):
            symbols.append({
                "kind": "variable",
                "name": m.group(1),
                "type": m.group(2).strip(),
                "line": source[: m.start()].count("\n") + 1,
                "col": 0,
                "end_line": source[: m.start()].count("\n") + 1,
            })

        # Macros
        for m in _RE_MACRO.finditer(source):
            symbols.append({
                "kind": "macro",
                "name": m.group(1),
                "line": source[: m.start()].count("\n") + 1,
                "col": 0,
                "end_line": source[: m.start()].count("\n") + 1,
            })

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _find_matching_brace(source: str, open_pos: int) -> int:
        depth = 0
        for i in range(open_pos, len(source)):
            if source[i] == "{":
                depth += 1
            elif source[i] == "}":
                depth -= 1
                if depth == 0:
                    return i
        return -1

    @staticmethod
    def _parse_rust_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        depth = 0
        current = ""
        for ch in params_str:
            if ch in "<(":
                depth += 1
                current += ch
            elif ch in ">)":
                depth -= 1
                current += ch
            elif ch == "," and depth == 0:
                params.append(current.strip())
                current = ""
            else:
                current += ch
        if current.strip():
            params.append(current.strip())

        result: list[dict[str, Any]] = []
        for p in params:
            p = p.strip()
            if not p:
                continue
            if p == "self" or p == "&self" or p == "&mut self":
                continue
            parts = p.split(":", 1)
            if len(parts) == 2:
                name = parts[0].strip()
                typ = parts[1].strip()
                result.append({"name": name, "type": typ, "default": None})
            else:
                result.append({"name": p, "type": None, "default": None})
        return result

    @staticmethod
    def _extract_use_names(path_str: str) -> list[str]:
        """Extract names from a ``use`` path like ``std::io::{Read, Write}``."""
        if "{" in path_str:
            inner = path_str[path_str.index("{") + 1 : path_str.rindex("}")]
            return [n.strip().split(" as ")[-1].strip() for n in inner.split(",") if n.strip()]
        return [path_str.split("::")[-1].strip()]


_register(RustAnalyzer())
