"""Dart language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_CLASS = re.compile(
    r"(?:(?:abstract|sealed|final|base|mixin)\s+)*class\s+(\w+)(?:<[^>]*>)?(?:\s+extends\s+(\w+))?(?:\s+(?:implements|with|extends)\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_MIXIN = re.compile(
    r"mixin\s+(\w+)(?:<[^>]*>)?(?:\s+on\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_ENUM = re.compile(
    r"enum\s+(\w+)(?:<[^>]*>)?(?:\s+(?:implements|with)\s+([^\{]+))?\s*\{",
    re.MULTILINE,
)
_RE_FUNCTION = re.compile(
    r"(?:(?:static|abstract|external|covariant)\s+)*"
    r"(?:(\w+(?:<[^>]*>)?(?:\?)?)\s+)?"
    r"(\w+)\s*\(([^)]*)\)\s*(?:async\s*)?(?:\{|;)",
    re.MULTILINE,
)
_RE_IMPORT = re.compile(
    r"import\s+['\"]([^'\"]+)['\"](?:\s+as\s+(\w+))?",
    re.MULTILINE,
)
_RE_PART = re.compile(
    r"part\s+(?:of\s+)?['\"]([^'\"]+)['\"]",
    re.MULTILINE,
)
_RE_VARIABLE = re.compile(
    r"(?:(?:final|const|static|late|var)\s+)*(\w+(?:<[^>]*>)?(?:\?)?)\s+(\w+)\s*(?:=[^;]+)?;",
    re.MULTILINE,
)


class DartAnalyzer:
    """Regex-based analyzer for Dart source files."""

    language = "dart"
    file_extensions = {".dart"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Imports
        for m in _RE_IMPORT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({
                "kind": "import",
                "name": m.group(2) or m.group(1).split("/").last if "/" in m.group(1) else m.group(1),
                "module": m.group(1),
                "line": line,
                "col": 0,
                "end_line": line,
                "alias": m.group(2),
            })

        # Part directives
        for m in _RE_PART.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "part", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Enums
        for m in _RE_ENUM.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "enum", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Mixins
        for m in _RE_MIXIN.finditer(source):
            line = source[: m.start()].count("\n") + 1
            on = [b.strip() for b in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "mixin", "name": m.group(1), "line": line, "col": 0, "end_line": line, "on": on})

        # Classes
        for m in _RE_CLASS.finditer(source):
            name = m.group(1)
            base = m.group(2)
            impl_str = m.group(3)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 20) : m.start()]
            bases = [base] if base else []
            implements = [i.strip() for i in impl_str.split(",")] if impl_str else []
            symbols.append({
                "kind": "class",
                "name": name,
                "line": line,
                "col": 0,
                "end_line": line,
                "bases": bases,
                "implements": implements,
                "abstract": "abstract" in prefix,
                "sealed": "sealed" in prefix,
            })

        # Functions / methods
        for m in _RE_FUNCTION.finditer(source):
            return_type = m.group(1)
            name = m.group(2)
            params_str = m.group(3)
            line = source[: m.start()].count("\n") + 1
            # Skip keywords
            if name in ("if", "for", "while", "switch", "catch", "return", "import", "export", "part"):
                continue
            prefix = source[max(0, m.start() - 50) : m.start()]
            symbols.append({
                "kind": "function",
                "name": name,
                "return_type": return_type,
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_dart_params(params_str),
                "static": "static" in prefix,
                "abstract": "abstract" in prefix,
            })

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_dart_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        depth = 0
        current = ""
        for ch in params_str:
            if ch in "<(":
                depth += 1
                current += ch
            elif ch in ">)":
                depth -= 1
                current += ch
            elif ch == "," and depth == 0:
                params.append(current.strip())
                current = ""
            else:
                current += ch
        if current.strip():
            params.append(current.strip())

        result: list[dict[str, Any]] = []
        for p in params:
            p = p.strip()
            if not p:
                continue
            # Remove modifiers
            for mod in ("required", "final", "covariant", "this."):
                if p.startswith(mod + " "):
                    p = p[len(mod) + 1 :]
                elif p.startswith(mod):
                    p = p[len(mod) :]
            parts = p.split(":") if ":" in p else p.split("=")
            if len(parts) >= 2:
                typ = parts[0].strip()
                name_default = "=".join(parts[1:]).strip()
                name = name_default.split("=")[0].strip()
                default = name_default.split("=")[1].strip() if "=" in name_default else None
                result.append({"name": name, "type": typ, "default": default})
            else:
                tokens = p.split()
                if len(tokens) >= 2:
                    result.append({"name": tokens[-1], "type": " ".join(tokens[:-1]), "default": None})
                else:
                    result.append({"name": p, "type": None, "default": None})
        return result


_register(DartAnalyzer())
