"""C# language analyzer using regex-based parsing."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import _register

_RE_CLASS = re.compile(
    r"(?:\[.*?\]\s*)?(?:(?:public|private|protected|internal|abstract|sealed|static|partial)\s+)*"
    r"class\s+(\w+)(?:<[^>]*>)?(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE | re.DOTALL,
)
_RE_INTERFACE = re.compile(
    r"(?:\[.*?\]\s*)?(?:(?:public|private|protected|internal)\s+)*interface\s+(\w+)(?:<[^>]*>)?(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE | re.DOTALL,
)
_RE_STRUCT = re.compile(
    r"(?:\[.*?\]\s*)?(?:(?:public|private|protected|internal|readonly|partial)\s+)*struct\s+(\w+)(?:<[^>]*>)?(?:\s*:\s*([^\{]+))?\s*\{",
    re.MULTILINE | re.DOTALL,
)
_RE_ENUM = re.compile(
    r"(?:\[.*?\]\s*)?(?:(?:public|private|protected|internal)\s+)*enum\s+(\w+)\s*(?::\s*(\w+))?\s*\{",
    re.MULTILINE | re.DOTALL,
)
_RE_METHOD = re.compile(
    r"(?:\[.*?\]\s*)?(?:(?:public|private|protected|internal|static|virtual|override|abstract|async|sealed|new|extern)\s+)*"
    r"(?:<[^>]*>\s+)?(\w+(?:<[^>]*>)?(?:\[\])?(?:\?)?)\s+(\w+)\s*\(([^)]*)\)\s*(?:where\s+[^\{]+)?\s*(?:\{|;)",
    re.MULTILINE | re.DOTALL,
)
_RE_PROPERTY = re.compile(
    r"(?:(?:public|private|protected|internal|static|virtual|override|abstract|new)\s+)*"
    r"(\w+(?:<[^>]*>)?(?:\?)?)\s+(\w+)\s*\{(?:\s*get|set)",
    re.MULTILINE,
)
_RE_USING = re.compile(
    r"using\s+(?!.*=\s)([^;]+);",
    re.MULTILINE,
)
_RE_NAMESPACE = re.compile(
    r"namespace\s+([^\{;]+)",
    re.MULTILINE,
)
_RE_FIELD = re.compile(
    r"(?:(?:public|private|protected|internal|static|readonly|const|volatile)\s+)*"
    r"(\w+(?:<[^>]*>)?(?:\[\])?(?:\?)?)\s+(\w+)\s*(?:=[^;]+)?;",
    re.MULTILINE,
)


class CSharpAnalyzer:
    """Regex-based analyzer for C# source files."""

    language = "csharp"
    file_extensions = {".cs"}

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in self.file_extensions

    def parse(self, source: str, path: Path | None = None) -> str:
        return source

    def extract_symbols(self, source: str, path: Path | None = None) -> list[dict[str, Any]]:
        symbols: list[dict[str, Any]] = []

        # Namespace
        for m in _RE_NAMESPACE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "namespace", "name": m.group(1).strip(), "line": line, "col": 0, "end_line": line})

        # Using
        for m in _RE_USING.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "using", "name": m.group(1).strip(), "line": line, "col": 0, "end_line": line})

        # Interfaces
        for m in _RE_INTERFACE.finditer(source):
            line = source[: m.start()].count("\n") + 1
            bases = [b.strip() for b in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "interface", "name": m.group(1), "line": line, "col": 0, "end_line": line, "bases": bases})

        # Structs
        for m in _RE_STRUCT.finditer(source):
            line = source[: m.start()].count("\n") + 1
            bases = [b.strip() for b in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "struct", "name": m.group(1), "line": line, "col": 0, "end_line": line, "bases": bases})

        # Classes
        for m in _RE_CLASS.finditer(source):
            line = source[: m.start()].count("\n") + 1
            bases = [b.strip() for b in m.group(2).split(",")] if m.group(2) else []
            symbols.append({"kind": "class", "name": m.group(1), "line": line, "col": 0, "end_line": line, "bases": bases})

        # Enums
        for m in _RE_ENUM.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "enum", "name": m.group(1), "line": line, "col": 0, "end_line": line})

        # Methods
        for m in _RE_METHOD.finditer(source):
            return_type = m.group(1)
            name = m.group(2)
            params_str = m.group(3)
            line = source[: m.start()].count("\n") + 1
            prefix = source[max(0, m.start() - 100) : m.start()]
            symbols.append({
                "kind": "method",
                "name": name,
                "return_type": return_type,
                "line": line,
                "col": 0,
                "end_line": line,
                "params": self._parse_params(params_str),
                "static": "static" in prefix,
                "async": "async" in prefix,
            })

        # Properties
        for m in _RE_PROPERTY.finditer(source):
            line = source[: m.start()].count("\n") + 1
            symbols.append({"kind": "property", "name": m.group(2), "type": m.group(1), "line": line, "col": 0, "end_line": line})

        return symbols

    def find_references(self, source: str, symbol: str, path: Path | None = None) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        for m in re.finditer(r"\b" + re.escape(symbol) + r"\b", source):
            line = source[: m.start()].count("\n") + 1
            col = m.start() - source.rfind("\n", 0, m.start()) - 1
            refs.append({"line": line, "col": col, "end_line": line, "end_col": col + len(symbol), "context": "name"})
        return refs

    @staticmethod
    def _parse_params(params_str: str) -> list[dict[str, Any]]:
        params: list[dict[str, Any]] = []
        if not params_str.strip():
            return params
        depth = 0
        current = ""
        for ch in params_str:
            if ch in "<(":
                depth += 1
                current += ch
            elif ch in ">)":
                depth -= 1
                current += ch
            elif ch == "," and depth == 0:
                params.append(current.strip())
                current = ""
            else:
                current += ch
        if current.strip():
            params.append(current.strip())

        result: list[dict[str, Any]] = []
        for p in params:
            p = p.strip()
            if not p:
                continue
            # Remove attributes like [FromBody]
            p = re.sub(r"\[.*?\]\s*", "", p).strip()
            parts = p.rsplit(None, 1)
            if len(parts) == 2:
                typ = parts[0]
                name = parts[1].lstrip("@")
                default = None
                if "=" in name:
                    name, default = name.split("=", 1)
                result.append({"name": name.strip(), "type": typ.strip(), "default": default.strip() if default else None})
        return result


_register(CSharpAnalyzer())
