"""Extract symbols (functions, classes, variables, etc.) from source code.

Provides a high-level interface on top of the AST parser to extract
and query symbols from individual files or entire project trees.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser

logger = logging.getLogger(__name__)


@dataclass
class Symbol:
    """Represents a code symbol (function, class, variable, etc.)."""

    name: str
    kind: str  # function, method, class, struct, variable, constant, import, etc.
    language: str
    file_path: str
    line: int
    col: int = 0
    end_line: int = 0
    end_col: int = 0
    parent: str | None = None  # Enclosing class/module name
    return_type: str | None = None
    params: list[dict[str, Any]] = field(default_factory=list)
    docstring: str | None = None
    decorators: list[str] = field(default_factory=list)
    modifiers: list[str] = field(default_factory=list)  # public, static, async, etc.
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def qualified_name(self) -> str:
        """Return the fully-qualified name (e.g. ``MyClass.my_method``)."""
        if self.parent:
            return f"{self.parent}.{self.name}"
        return self.name

    @property
    def signature(self) -> str:
        """Return a human-readable signature string."""
        params = ", ".join(p.get("name", "?") for p in self.params)
        ret = f" -> {self.return_type}" if self.return_type else ""
        return f"{self.name}({params}){ret}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind,
            "language": self.language,
            "file_path": self.file_path,
            "line": self.line,
            "col": self.col,
            "end_line": self.end_line,
            "end_col": self.end_col,
            "parent": self.parent,
            "return_type": self.return_type,
            "params": self.params,
            "docstring": self.docstring,
            "decorators": self.decorators,
            "modifiers": self.modifiers,
        }


class SymbolExtractor:
    """Extract and query symbols from source files.

    Usage::

        extractor = SymbolExtractor()

        # From a single file
        symbols = extractor.extract_from_file(Path("main.py"))

        # From a project tree
        symbols = extractor.extract_from_directory(Path("src/"), extensions={".py"})

        # Query
        functions = extractor.filter_by_kind(symbols, "function")
        main_fn = extractor.find_by_name(symbols, "main")
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()

    # ------------------------------------------------------------------
    # Extraction
    # ------------------------------------------------------------------

    def extract_from_file(self, path: Path) -> list[Symbol]:
        """Extract all symbols from a single file.

        Returns:
            A list of :class:`Symbol` objects.
        """
        result = self._parser.parse_file(path)
        if not result.success:
            logger.warning("Failed to parse %s: %s", path, result.error)
            return []

        symbols = []
        for raw in result.symbols:
            sym = self._raw_to_symbol(raw, result.language, str(path))
            if sym:
                symbols.append(sym)
        return symbols

    def extract_from_source(
        self,
        source: str,
        *,
        language: str | None = None,
        path: Path | None = None,
    ) -> list[Symbol]:
        """Extract symbols from source code string."""
        result = self._parser.parse_source(source, path=path, language=language)
        if not result.success:
            return []
        symbols = []
        for raw in result.symbols:
            sym = self._raw_to_symbol(raw, result.language, str(path) if path else "<string>")
            if sym:
                symbols.append(sym)
        return symbols

    def extract_from_directory(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        max_files: int = 10_000,
    ) -> list[Symbol]:
        """Recursively extract symbols from all matching files in *directory*.

        Parameters:
            directory: Root directory to scan.
            extensions: File extensions to include. *None* = all supported.
            exclude_patterns: Path substrings to skip (e.g. ``{".git", "node_modules"}``).
            max_files: Maximum number of files to process.
        """
        if extensions is None:
            extensions = self._parser.supported_extensions()
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build", ".tox"}

        symbols: list[Symbol] = []
        count = 0

        for path in sorted(directory.rglob("*")):
            if count >= max_files:
                logger.info("Reached max_files=%d limit", max_files)
                break
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue
            count += 1
            symbols.extend(self.extract_from_file(path))

        return symbols

    # ------------------------------------------------------------------
    # Querying
    # ------------------------------------------------------------------

    @staticmethod
    def filter_by_kind(symbols: list[Symbol], kind: str) -> list[Symbol]:
        """Return symbols matching *kind* (e.g. ``"function"``, ``"class"``)."""
        return [s for s in symbols if s.kind == kind]

    @staticmethod
    def find_by_name(symbols: list[Symbol], name: str, *, exact: bool = True) -> list[Symbol]:
        """Find symbols by name.

        Parameters:
            exact: If *True*, require exact match. Otherwise substring match.
        """
        if exact:
            return [s for s in symbols if s.name == name]
        return [s for s in symbols if name in s.name]

    @staticmethod
    def find_by_qualified_name(symbols: list[Symbol], qname: str) -> list[Symbol]:
        """Find symbols by qualified name (e.g. ``MyClass.my_method``)."""
        return [s for s in symbols if s.qualified_name == qname]

    @staticmethod
    def group_by_file(symbols: list[Symbol]) -> dict[str, list[Symbol]]:
        """Group symbols by file path."""
        groups: dict[str, list[Symbol]] = {}
        for s in symbols:
            groups.setdefault(s.file_path, []).append(s)
        return groups

    @staticmethod
    def group_by_kind(symbols: list[Symbol]) -> dict[str, list[Symbol]]:
        """Group symbols by kind."""
        groups: dict[str, list[Symbol]] = {}
        for s in symbols:
            groups.setdefault(s.kind, []).append(s)
        return groups

    @staticmethod
    def get_imports(symbols: list[Symbol]) -> list[Symbol]:
        """Return only import/require/use symbols."""
        import_kinds = {"import", "require", "use", "include", "using", "library", "source", "part"}
        return [s for s in symbols if s.kind in import_kinds]

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _raw_to_symbol(raw: dict[str, Any], language: str, file_path: str) -> Symbol | None:
        """Convert a raw symbol dict from the analyzer into a Symbol."""
        name = raw.get("name")
        kind = raw.get("kind")
        if not name or not kind:
            return None

        # Extract modifiers from raw data
        modifiers = []
        for mod in ("public", "private", "protected", "static", "async", "abstract", "override", "final", "const", "pub", "open"):
            if raw.get(mod):
                modifiers.append(mod)

        return Symbol(
            name=name,
            kind=kind,
            language=language,
            file_path=file_path,
            line=raw.get("line", 0),
            col=raw.get("col", 0),
            end_line=raw.get("end_line", 0),
            end_col=raw.get("end_col", 0),
            parent=raw.get("receiver") or raw.get("class"),
            return_type=raw.get("return_type"),
            params=raw.get("params", []),
            docstring=raw.get("docstring"),
            decorators=raw.get("decorators", []),
            modifiers=modifiers,
            metadata={k: v for k, v in raw.items() if k not in {
                "name", "kind", "line", "col", "end_line", "end_col",
                "receiver", "class", "return_type", "params", "docstring",
                "decorators", "public", "private", "protected", "static",
                "async", "abstract", "override", "final", "const", "pub", "open",
            }},
        )
