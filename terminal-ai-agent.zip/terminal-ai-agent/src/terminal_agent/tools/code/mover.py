"""Move code between files with import management.

Moves functions, classes, and other code blocks between files while
updating imports and references appropriately.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser
from .renamer import Renamer
from .symbol_extractor import Symbol, SymbolExtractor

logger = logging.getLogger(__name__)


@dataclass
class MoveResult:
    """Result of moving code between files."""

    success: bool
    symbol_name: str = ""
    source_file: str = ""
    target_file: str = ""
    source_modified: str = ""
    target_modified: str = ""
    import_added: str = ""
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            f"Moved '{self.symbol_name}': {self.source_file} -> {self.target_file}",
        ]
        if self.import_added:
            lines.append(f"Import added to source: {self.import_added}")
        if self.errors:
            lines.append(f"Errors: {'; '.join(self.errors)}")
        return "\n".join(lines)


class CodeMover:
    """Move code between files.

    Usage::

        mover = CodeMover()

        # Move a function from one file to another
        result = mover.move_symbol(
            source_path=Path("utils.py"),
            target_path=Path("helpers.py"),
            symbol_name="process_data",
        )

        # Apply the changes
        if result.success:
            mover.apply(result)
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()
        self._extractor = SymbolExtractor(self._parser)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def move_symbol(
        self,
        source_path: Path,
        target_path: Path,
        symbol_name: str,
        *,
        add_import: bool = True,
        remove_from_source: bool = True,
    ) -> MoveResult:
        """Move *symbol_name* from *source_path* to *target_path*.

        Parameters:
            source_path: File currently containing the symbol.
            target_path: File to move the symbol to.
            symbol_name: Name of the function, class, or variable to move.
            add_import: If *True*, add an import in *source_path* for the moved symbol.
            remove_from_source: If *True*, remove the symbol from *source_path*.

        Returns:
            A :class:`MoveResult`.
        """
        # Read both files
        try:
            source_content = source_path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as exc:
            return MoveResult(success=False, errors=[f"Cannot read source: {exc}"])

        try:
            target_content = target_path.read_text(encoding="utf-8", errors="replace")
        except FileNotFoundError:
            target_content = ""
        except (OSError, UnicodeDecodeError) as exc:
            return MoveResult(success=False, errors=[f"Cannot read target: {exc}"])

        # Find the symbol in source
        source_symbols = self._extractor.extract_from_file(source_path)
        sym = next((s for s in source_symbols if s.name == symbol_name), None)

        if sym is None:
            return MoveResult(
                success=False,
                errors=[f"Symbol '{symbol_name}' not found in {source_path}"],
            )

        # Extract the symbol's source code
        code_block = self._extract_code(source_content, sym)
        if code_block is None:
            return MoveResult(
                success=False,
                errors=[f"Could not extract code for '{symbol_name}'"],
            )

        # Determine if target already imports from source
        import_statement = self._build_import(source_path, target_path, symbol_name)

        # Build modified target (append code)
        new_target = self._append_to_target(target_content, code_block, target_path)

        # Build modified source (remove code + add import)
        new_source = source_content
        if remove_from_source:
            new_source = self._remove_from_source(source_content, sym)

        if add_import and remove_from_source:
            new_source = self._add_import_to_source(new_source, import_statement, source_path)

        return MoveResult(
            success=True,
            symbol_name=symbol_name,
            source_file=str(source_path),
            target_file=str(target_path),
            source_modified=new_source,
            target_modified=new_target,
            import_added=import_statement if add_import and remove_from_source else "",
        )

    def move_symbols(
        self,
        source_path: Path,
        target_path: Path,
        symbol_names: list[str],
        *,
        add_import: bool = True,
    ) -> list[MoveResult]:
        """Move multiple symbols from *source_path* to *target_path*.

        Processes moves in reverse order of their position in the source
        file to preserve line numbers.
        """
        # Find all symbols and sort by line (descending)
        source_symbols = self._extractor.extract_from_file(source_path)
        to_move = [s for s in source_symbols if s.name in symbol_names]
        to_move.sort(key=lambda s: s.line, reverse=True)

        results: list[MoveResult] = []
        current_source = source_path.read_text(encoding="utf-8", errors="replace")
        current_target = target_path.read_text(encoding="utf-8", errors="replace") if target_path.exists() else ""

        for sym in to_move:
            result = self.move_symbol(
                source_path=source_path,
                target_path=target_path,
                symbol_name=sym.name,
                add_import=add_import,
            )
            results.append(result)

            if result.success:
                current_source = result.source_modified
                current_target = result.target_modified

        return results

    @staticmethod
    def apply(result: MoveResult) -> None:
        """Write the computed changes to disk."""
        if not result.success:
            return

        if result.source_modified:
            Path(result.source_file).write_text(result.source_modified, encoding="utf-8")
        if result.target_modified:
            Path(result.target_file).write_text(result.target_modified, encoding="utf-8")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_code(source: str, sym: Symbol) -> str | None:
        """Extract the source code block for *sym*."""
        lines = source.splitlines(keepends=True)
        start = sym.line - 1
        end = sym.end_line if sym.end_line > sym.line else start + 1

        # Extend end to include trailing blank lines and next definition
        while end < len(lines) and lines[end - 1].strip() == "":
            end += 1

        if start >= len(lines):
            return None

        block = "".join(lines[start:end])

        # Ensure block ends with a blank line separator
        if not block.endswith("\n\n"):
            block = block.rstrip("\n") + "\n\n"

        return block

    @staticmethod
    def _build_import(source_path: Path, target_path: Path, symbol_name: str) -> str:
        """Build an import statement for the moved symbol."""
        source_stem = source_path.stem
        # Determine relative import path
        try:
            rel = source_path.relative_to(target_path.parent)
            module = str(rel.with_suffix("")).replace("/", ".").replace("\\", ".")
            if module.startswith("."):
                return f"from {module} import {symbol_name}"
            return f"from .{module} import {symbol_name}" if module else f"from . import {symbol_name}"
        except ValueError:
            return f"from {source_stem} import {symbol_name}"

    @staticmethod
    def _append_to_target(target_content: str, code_block: str, target_path: Path) -> str:
        """Append *code_block* to the end of *target_content*."""
        if not target_content:
            return code_block

        # Ensure there's a separator
        content = target_content.rstrip("\n") + "\n\n"
        return content + code_block

    @staticmethod
    def _remove_from_source(source: str, sym: Symbol) -> str:
        """Remove the symbol's code block from *source*."""
        lines = source.splitlines(keepends=True)
        start = sym.line - 1
        end = sym.end_line if sym.end_line > sym.line else start + 1

        # Remove trailing blank lines
        while end < len(lines) and lines[end].strip() == "":
            end += 1

        new_lines = lines[:start] + lines[end:]
        return "".join(new_lines)

    @staticmethod
    def _add_import_to_source(source: str, import_stmt: str, source_path: Path) -> str:
        """Add an import statement to *source* (after existing imports)."""
        lines = source.splitlines(keepends=True)

        # Find the last import line
        last_import_idx = -1
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith(("import ", "from ")):
                last_import_idx = i
            elif last_import_idx >= 0 and stripped:
                break

        if last_import_idx >= 0:
            lines.insert(last_import_idx + 1, import_stmt + "\n")
        else:
            lines.insert(0, import_stmt + "\n\n")

        return "".join(lines)
