"""Performance issue detection.

Identifies common performance anti-patterns and bottlenecks in
source code using heuristic analysis.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PerformanceIssue:
    """A detected performance issue."""

    issue_type: str
    severity: str  # "high", "medium", "low"
    file_path: str
    line: int
    message: str
    suggestion: str = ""
    estimated_impact: str = ""  # "O(n)", "O(n^2)", etc.

    def to_dict(self) -> dict[str, Any]:
        return {
            "issue_type": self.issue_type,
            "severity": self.severity,
            "file_path": self.file_path,
            "line": self.line,
            "message": self.message,
            "suggestion": self.suggestion,
            "estimated_impact": self.estimated_impact,
        }


@dataclass
class PerformanceReport:
    """Report of performance issues in a project."""

    issues: list[PerformanceIssue] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.issues)

    @property
    def by_type(self) -> dict[str, list[PerformanceIssue]]:
        groups: dict[str, list[PerformanceIssue]] = {}
        for i in self.issues:
            groups.setdefault(i.issue_type, []).append(i)
        return groups

    def summary(self) -> str:
        lines = [f"Performance analysis: {self.total} issue(s)"]
        by_type = self.by_type
        for itype, issue_list in sorted(by_type.items(), key=lambda x: -len(x[1])):
            lines.append(f"  {itype}: {len(issue_list)}")
        high = [i for i in self.issues if i.severity == "high"]
        if high:
            lines.append("High-impact issues:")
            for issue in high[:15]:
                lines.append(f"  {issue.file_path}:{issue.line} - {issue.message}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Performance patterns
# ---------------------------------------------------------------------------

_PYTHON_PATTERNS: list[dict[str, Any]] = [
    # String concatenation in loops
    {
        "pattern": re.compile(r"""(?:for|while)\s+.*:(?:\s*\n\s+.*){0,5}\s+\w+\s*\+=\s*['"]""", re.MULTILINE),
        "issue_type": "string_concat_in_loop",
        "severity": "high",
        "message": "String concatenation in a loop — O(n^2) complexity",
        "suggestion": "Use ''.join(list) or io.StringIO for building strings",
        "impact": "O(n^2)",
    },
    # List append in loop (can be list comprehension)
    {
        "pattern": re.compile(r"""(\w+)\s*=\s*\[\]\s*\n\s*for\s+\w+\s+in\s+.*:\s*\n\s+\1\.append\(""", re.MULTILINE),
        "issue_type": "loop_append",
        "severity": "low",
        "message": "List building with append in loop — consider list comprehension",
        "suggestion": "Use a list comprehension: result = [f(x) for x in items]",
        "impact": "~2x slower than comprehension",
    },
    # Global variable access in loops
    {
        "pattern": re.compile(r"""(?:for|while)\s+.*:(?:\s*\n\s+.*){0,3}\s+(?:if|return)\s+\w+(?:\.\w+)*\s*(?:==|!=|in\s)""", re.MULTILINE),
        "issue_type": "global_access_in_loop",
        "severity": "low",
        "message": "Potential global variable access in loop",
        "suggestion": "Cache global lookups in local variables before loops",
        "impact": "~10-20% overhead per access",
    },
    # Repeated regex compilation
    {
        "pattern": re.compile(r"""(?:for|while)\s+.*:\s*(?:\s*\n\s+.*){0,3}\s+(?:re\.\w+|re\.compile)\s*\(""", re.MULTILINE),
        "issue_type": "regex_in_loop",
        "severity": "medium",
        "message": "Regex compilation inside loop",
        "suggestion": "Compile regex outside the loop: pattern = re.compile(...)",
        "impact": "Significant for complex patterns",
    },
    # Nested loops with list operations
    {
        "pattern": re.compile(r"""for\s+\w+\s+in\s+\w+:\s*\n\s+for\s+\w+\s+in\s+\w+:\s*\n\s+if\s+\w+\s+in\s+\w+""", re.MULTILINE),
        "issue_type": "nested_loop_linear_search",
        "severity": "high",
        "message": "Linear search in nested loop — O(n*m) complexity",
        "suggestion": "Convert inner list to a set for O(1) lookups",
        "impact": "O(n*m) -> O(n+m)",
    },
    # Large file read without chunking
    {
        "pattern": re.compile(r"""\.read\(\)(?!\s*\))""", re.MULTILINE),
        "issue_type": "unbounded_read",
        "severity": "medium",
        "message": "Unbounded file read — may cause memory issues with large files",
        "suggestion": "Read in chunks or use mmap for large files",
        "impact": "Memory proportional to file size",
    },
    # Synchronous I/O in async context
    {
        "pattern": re.compile(r"""async\s+def\s+.*:(?:\s*\n\s+.*){0,5}\s+(?:open|requests\.\w+|urllib)""", re.MULTILINE),
        "issue_type": "sync_in_async",
        "severity": "high",
        "message": "Synchronous I/O in async function — blocks the event loop",
        "suggestion": "Use aiohttp, aiofiles, or run_in_executor for blocking calls",
        "impact": "Blocks entire event loop",
    },
    # Inefficient membership test
    {
        "pattern": re.compile(r"""\bif\s+\w+\s+in\s+\[(?:[^]]+)\]""", re.MULTILINE),
        "issue_type": "list_membership",
        "severity": "low",
        "message": "Membership test on list literal — O(n) lookup",
        "suggestion": "Use a set literal for O(1) lookup: if x in {a, b, c}",
        "impact": "O(n) vs O(1)",
    },
    # pd.concat in loop
    {
        "pattern": re.compile(r"""(?:for|while)\s+.*:(?:\s*\n\s+.*){0,5}\s+\w+\s*=\s*pd\.concat\(""", re.MULTILINE),
        "issue_type": "concat_in_loop",
        "severity": "high",
        "message": "DataFrame concatenation in loop — O(n^2) memory copies",
        "suggestion": "Collect DataFrames in a list, then concat once: pd.concat(list_of_dfs)",
        "impact": "O(n^2) -> O(n)",
    },
]

_JS_PATTERNS: list[dict[str, Any]] = [
    # DOM manipulation in loops
    {
        "pattern": re.compile(r"""(?:for|while|forEach)\s*\([^)]*\)\s*\{(?:\s*\n\s+.*){0,3}\s+document\.(?:getElementById|querySelector|createElement)""", re.MULTILINE),
        "issue_type": "dom_in_loop",
        "severity": "high",
        "message": "DOM manipulation inside loop — causes layout thrashing",
        "suggestion": "Build DOM fragment offline, then insert once with appendChild(fragment)",
        "impact": "Multiple reflows/repaints",
    },
    # Array.filter().map() chains
    {
        "pattern": re.compile(r"""\.filter\([^)]+\)\s*\.map\(""", re.MULTILINE),
        "issue_type": "double_iteration",
        "severity": "low",
        "message": "Chained filter().map() iterates twice",
        "suggestion": "Use a single .reduce() or for loop to filter and transform in one pass",
        "impact": "2x iteration",
    },
    # Blocking alert/confirm
    {
        "pattern": re.compile(r"""\b(?:alert|confirm|prompt)\s*\(""", re.MULTILINE),
        "issue_type": "blocking_dialog",
        "severity": "medium",
        "message": "Blocking dialog — freezes the UI",
        "suggestion": "Use non-blocking modal dialogs or toast notifications",
        "impact": "Blocks main thread",
    },
    # JSON.parse in hot path
    {
        "pattern": re.compile(r"""(?:for|while|forEach|map|filter|reduce)\s*\([^)]*\)\s*\{(?:\s*\n\s+.*){0,3}\s+JSON\.parse\(""", re.MULTILINE),
        "issue_type": "json_parse_in_loop",
        "severity": "medium",
        "message": "JSON.parse() inside loop",
        "suggestion": "Parse JSON once before the loop",
        "impact": "Repeated parsing overhead",
    },
]


class PerformanceAnalyzer:
    """Analyze code for performance issues.

    Usage::

        analyzer = PerformanceAnalyzer()

        # Analyze a directory
        report = analyzer.analyze(Path("src/"))

        # Show results
        print(report.summary())
    """

    def analyze(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        max_files: int = 5000,
    ) -> PerformanceReport:
        """Analyze all files in *directory* for performance issues."""
        if extensions is None:
            extensions = {".py", ".js", ".ts", ".jsx", ".tsx"}
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

        issues: list[PerformanceIssue] = []
        count = 0

        for path in sorted(directory.rglob("*")):
            if count >= max_files:
                break
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue
            count += 1

            file_issues = self._analyze_file(path)
            issues.extend(file_issues)

        return PerformanceReport(issues=issues)

    def analyze_file(self, path: Path) -> PerformanceReport:
        """Analyze a single file."""
        issues = self._analyze_file(path)
        return PerformanceReport(issues=issues)

    def analyze_source(self, source: str, *, language: str = "python", file_path: str = "<string>") -> PerformanceReport:
        """Analyze source code from a string."""
        issues = self._analyze_source(source, language, file_path)
        return PerformanceReport(issues=issues)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _analyze_file(self, path: Path) -> list[PerformanceIssue]:
        """Analyze a single file."""
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            return []

        ext = path.suffix.lower()
        language = {
            ".py": "python", ".pyi": "python",
            ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript",
            ".ts": "typescript", ".tsx": "typescript",
        }.get(ext, "unknown")

        return self._analyze_source(source, language, str(path))

    @staticmethod
    def _analyze_source(source: str, language: str, file_path: str) -> list[PerformanceIssue]:
        """Analyze source code for performance patterns."""
        issues: list[PerformanceIssue] = []
        lines = source.splitlines()

        patterns = _PYTHON_PATTERNS if language == "python" else _JS_PATTERNS if language in ("javascript", "typescript") else []

        for pat_info in patterns:
            pattern = pat_info["pattern"]
            for m in pattern.finditer(source):
                line_num = source[: m.start()].count("\n") + 1
                issues.append(PerformanceIssue(
                    issue_type=pat_info["issue_type"],
                    severity=pat_info["severity"],
                    file_path=file_path,
                    line=line_num,
                    message=pat_info["message"],
                    suggestion=pat_info.get("suggestion", ""),
                    estimated_impact=pat_info.get("impact", ""),
                ))

        # Generic: very long functions (>200 lines)
        if language == "python":
            func_starts = [(m.start(), m.group(1)) for m in re.finditer(r"def\s+(\w+)\s*\(", source)]
            for i, (start, name) in enumerate(func_starts):
                end = func_starts[i + 1][0] if i + 1 < len(func_starts) else len(source)
                loc = source[start:end].count("\n")
                if loc > 200:
                    line_num = source[:start].count("\n") + 1
                    issues.append(PerformanceIssue(
                        issue_type="long_function",
                        severity="medium",
                        file_path=file_path,
                        line=line_num,
                        message=f"Function '{name}' is {loc} lines — may have hidden complexity",
                        suggestion="Break into smaller, testable functions",
                    ))

        return issues
