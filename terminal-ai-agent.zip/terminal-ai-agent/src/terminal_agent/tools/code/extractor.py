"""Extract code blocks into new functions.

Analyzes selected code and creates a new function with appropriate
parameters and return values, replacing the original code with a
function call.
"""

from __future__ import annotations

import logging
import re
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser

logger = logging.getLogger(__name__)


@dataclass
class ExtractionResult:
    """Result of extracting code into a function."""

    success: bool
    function_name: str = ""
    new_function_source: str = ""
    modified_source: str = ""
    parameters: list[dict[str, str]] = field(default_factory=list)
    return_variables: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"Extracted function: {self.function_name}"]
        if self.parameters:
            params = ", ".join(f"{p['name']}: {p.get('type', 'any')}" for p in self.parameters)
            lines.append(f"Parameters: {params}")
        if self.return_variables:
            lines.append(f"Returns: {', '.join(self.return_variables)}")
        if self.errors:
            lines.append(f"Errors: {'; '.join(self.errors)}")
        return "\n".join(lines)


class CodeExtractor:
    """Extract code blocks into new functions.

    Usage::

        extractor = CodeExtractor()

        # Extract lines 10-20 from a file into a new function
        result = extractor.extract_from_file(
            Path("main.py"),
            start_line=10,
            end_line=20,
            function_name="process_data",
        )

        # Or from source directly
        result = extractor.extract_from_source(
            source,
            start_line=5,
            end_line=15,
            function_name="helper",
            language="python",
        )
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def extract_from_file(
        self,
        path: Path,
        start_line: int,
        end_line: int,
        function_name: str,
        *,
        insert_before: int | None = None,
        indent: int = 0,
    ) -> ExtractionResult:
        """Extract lines *start_line*–*end_line* into a new function.

        Parameters:
            path: Source file path.
            start_line: First line to extract (1-indexed, inclusive).
            end_line: Last line to extract (1-indexed, inclusive).
            function_name: Name for the new function.
            insert_before: Line number to insert the function before.
                          *None* = insert before the extracted block.
            indent: Indentation level for the new function (0 = top-level).

        Returns:
            An :class:`ExtractionResult`.
        """
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as exc:
            return ExtractionResult(success=False, errors=[str(exc)])

        result = self.extract_from_source(
            source,
            start_line=start_line,
            end_line=end_line,
            function_name=function_name,
            language=None,
            path=path,
            insert_before=insert_before,
            indent=indent,
        )

        return result

    def extract_from_source(
        self,
        source: str,
        start_line: int,
        end_line: int,
        function_name: str,
        *,
        language: str | None = None,
        path: Path | None = None,
        insert_before: int | None = None,
        indent: int = 0,
    ) -> ExtractionResult:
        """Extract lines from source code into a new function.

        Parameters:
            source: The full source code.
            start_line: First line to extract (1-indexed, inclusive).
            end_line: Last line to extract (1-indexed, inclusive).
            function_name: Name for the new function.
            language: Source language (for syntax-aware extraction).
            path: Optional file path (for language detection).
            insert_before: Where to insert the function.
            indent: Indentation level.

        Returns:
            An :class:`ExtractionResult`.
        """
        # Validate inputs
        lines = source.splitlines(keepends=True)
        if start_line < 1 or end_line > len(lines) or start_line > end_line:
            return ExtractionResult(
                success=False,
                errors=[f"Invalid line range: {start_line}-{end_line} (file has {len(lines)} lines)"],
            )

        if not re.match(r"^[a-zA-Z_]\w*$", function_name):
            return ExtractionResult(
                success=False,
                errors=[f"Invalid function name: '{function_name}'"],
            )

        # Extract the code block
        extract_start = start_line - 1
        extract_end = end_line
        extracted_lines = lines[extract_start:extract_end]
        extracted_source = "".join(extracted_lines)

        # Detect language
        if language is None and path:
            analyzer = self._parser
            lang = path.suffix.lstrip(".")
        else:
            lang = language or "python"

        # Analyze the extracted code for variables
        params, return_vars = self._analyze_variables(source, extracted_source, start_line, end_line, lang)

        # Determine base indentation
        base_indent = self._detect_indent(extracted_lines)
        func_indent = " " * indent

        # Build the new function
        param_str = self._format_params(params, lang)
        return_str = self._format_return(return_vars, lang)

        new_func_lines = self._build_function(
            function_name, param_str, return_str, extracted_lines,
            base_indent, func_indent, lang,
        )

        # Build the function call
        call_args = self._format_call_args(params, return_vars, lang)
        call_line = self._build_call(function_name, call_args, return_vars, base_indent, lang)

        # Replace extracted lines with the call
        new_lines = list(lines[:extract_start])
        new_lines.append(call_line + "\n")
        new_lines.extend(lines[extract_end:])

        # Insert the function definition
        if insert_before is None:
            insert_before = start_line
        insert_idx = insert_before - 1

        final_lines = list(new_lines[:insert_idx])
        final_lines.extend(new_func_lines)
        final_lines.extend(new_lines[insert_idx:])

        modified_source = "".join(final_lines)

        return ExtractionResult(
            success=True,
            function_name=function_name,
            new_function_source="".join(new_func_lines),
            modified_source=modified_source,
            parameters=params,
            return_variables=return_vars,
        )

    # ------------------------------------------------------------------
    # Variable analysis
    # ------------------------------------------------------------------

    def _analyze_variables(
        self,
        full_source: str,
        extracted: str,
        start_line: int,
        end_line: int,
        language: str,
    ) -> tuple[list[dict[str, str]], list[str]]:
        """Analyze which variables need to be parameters and which are returned.

        Returns:
            (parameters, return_variables)
        """
        # Simple heuristic: find variables used in the extracted block
        # that are defined before it (parameters) and variables defined
        # in the block that are used after it (return values).

        full_lines = full_source.splitlines()
        before_lines = full_lines[: start_line - 1]
        after_lines = full_lines[end_line:]

        # Find variable assignments in the extracted block
        assigned_in_block = set()
        for line in extracted.splitlines():
            # Python-style assignment
            m = re.match(r"\s*(\w+)\s*=", line)
            if m:
                assigned_in_block.add(m.group(1))

        # Find variables used in the block that are assigned before
        used_names = set(re.findall(r"\b([a-zA-Z_]\w*)\b", extracted))
        assigned_before = set()
        for line in before_lines:
            m = re.match(r"\s*(\w+)\s*=", line)
            if m:
                assigned_before.add(m.group(1))

        # Parameters: assigned before, used in block
        param_names = (used_names & assigned_before) - {"self", "cls", "print", "len", "range", "True", "False", "None"}
        params = [{"name": name, "type": "any"} for name in sorted(param_names)]

        # Return variables: assigned in block, used after
        used_after = set()
        for line in after_lines:
            used_after.update(re.findall(r"\b([a-zA-Z_]\w*)\b", line))

        return_vars = sorted(assigned_in_block & used_after)

        return params, return_vars

    # ------------------------------------------------------------------
    # Code generation helpers
    # ------------------------------------------------------------------

    def _build_function(
        self,
        name: str,
        params: str,
        returns: str,
        body_lines: list[str],
        base_indent: str,
        func_indent: str,
        language: str,
    ) -> list[str]:
        """Build the new function definition."""
        if language in ("python", "py"):
            return self._build_python_func(name, params, returns, body_lines, base_indent, func_indent)
        elif language in ("js", "jsx", "mjs", "cjs", "javascript", "ts", "tsx", "typescript"):
            return self._build_js_func(name, params, returns, body_lines, base_indent, func_indent)
        else:
            return self._build_generic_func(name, params, returns, body_lines, base_indent, func_indent)

    def _build_python_func(
        self, name: str, params: str, returns: str,
        body_lines: list[str], base_indent: str, func_indent: str,
    ) -> list[str]:
        ret_hint = f" -> {returns}" if returns else ""
        header = f"{func_indent}def {name}({params}){ret_hint}:\n"
        # Re-indent body to function level
        new_body_indent = func_indent + "    "
        body = self._reindent(body_lines, base_indent, new_body_indent)
        if not body:
            body = [f"{new_body_indent}pass\n"]
        # Add return statement if needed
        if returns:
            body.append(f"{new_body_indent}return {returns}\n")
        return [header] + ["\n"] + body + ["\n"]

    def _build_js_func(
        self, name: str, params: str, returns: str,
        body_lines: list[str], base_indent: str, func_indent: str,
    ) -> list[str]:
        if returns:
            ret_stmt = f"  return {{ {returns} }};\n"
        else:
            ret_stmt = ""
        header = f"{func_indent}function {name}({params}) {{\n"
        body = self._reindent(body_lines, base_indent, func_indent + "  ")
        footer = f"{func_indent}}}\n"
        return [header] + body + ([ret_stmt] if ret_stmt else []) + [footer, "\n"]

    def _build_generic_func(
        self, name: str, params: str, returns: str,
        body_lines: list[str], base_indent: str, func_indent: str,
    ) -> list[str]:
        header = f"{func_indent}// Extracted function: {name}\n"
        body = self._reindent(body_lines, base_indent, func_indent + "  ")
        return [header] + body + ["\n"]

    @staticmethod
    def _reindent(lines: list[str], old_indent: str, new_indent: str) -> list[str]:
        """Re-indent lines from *old_indent* to *new_indent*."""
        result = []
        for line in lines:
            stripped = line.lstrip()
            if not stripped or stripped == "\n":
                result.append("\n")
                continue
            # Calculate relative indent
            current_indent = line[: len(line) - len(stripped)]
            extra = current_indent[len(old_indent) :] if current_indent.startswith(old_indent) else ""
            result.append(f"{new_indent}{extra}{stripped}")
        return result

    @staticmethod
    def _detect_indent(lines: list[str]) -> str:
        """Detect the common indentation of *lines*."""
        min_indent = ""
        for line in lines:
            stripped = line.lstrip()
            if not stripped:
                continue
            indent = line[: len(line) - len(stripped)]
            if not min_indent or len(indent) < len(min_indent):
                min_indent = indent
        return min_indent

    @staticmethod
    def _format_params(params: list[dict[str, str]], language: str) -> str:
        if not params:
            return ""
        if language in ("python", "py"):
            return ", ".join(f"{p['name']}" for p in params)
        return ", ".join(f"{p['name']}" for p in params)

    @staticmethod
    def _format_return(return_vars: list[str], language: str) -> str:
        if not return_vars:
            return ""
        if len(return_vars) == 1:
            return return_vars[0]
        return ", ".join(return_vars)

    @staticmethod
    def _format_call_args(params: list[dict[str, str]], return_vars: list[str], language: str) -> str:
        return ", ".join(p["name"] for p in params)

    @staticmethod
    def _build_call(name: str, args: str, return_vars: list[str], indent: str, language: str) -> str:
        if return_vars:
            if len(return_vars) == 1:
                return f"{indent}{return_vars[0]} = {name}({args})"
            return f"{indent}{', '.join(return_vars)} = {name}({args})"
        return f"{indent}{name}({args})"
