"""Dependency analysis.

Analyzes import/require statements and dependency relationships between
files and modules within a project.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser
from .symbol_extractor import Symbol, SymbolExtractor

logger = logging.getLogger(__name__)


@dataclass
class Dependency:
    """A dependency relationship between files."""

    source_file: str  # The file that imports
    target: str  # The imported module/package
    import_names: list[str] = field(default_factory=list)  # Specific names imported
    line: int = 0
    is_external: bool = False  # External package vs internal module
    is_relative: bool = False  # Relative import

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_file": self.source_file,
            "target": self.target,
            "import_names": self.import_names,
            "line": self.line,
            "is_external": self.is_external,
            "is_relative": self.is_relative,
        }


@dataclass
class FileDependencies:
    """Dependencies for a single file."""

    file_path: str
    imports: list[Dependency] = field(default_factory=list)
    imported_by: list[str] = field(default_factory=list)

    @property
    def external_deps(self) -> list[Dependency]:
        return [d for d in self.imports if d.is_external]

    @property
    def internal_deps(self) -> list[Dependency]:
        return [d for d in self.imports if not d.is_external]

    def to_dict(self) -> dict[str, Any]:
        return {
            "file_path": self.file_path,
            "import_count": len(self.imports),
            "external_count": len(self.external_deps),
            "internal_count": len(self.internal_deps),
            "imported_by_count": len(self.imported_by),
        }


@dataclass
class DependencyReport:
    """Report of dependency analysis for a project."""

    files: dict[str, FileDependencies] = field(default_factory=dict)
    external_packages: set[str] = field(default_factory=set)
    circular_deps: list[list[str]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def total_files(self) -> int:
        return len(self.files)

    @property
    def total_dependencies(self) -> int:
        return sum(len(f.imports) for f in self.files.values())

    @property
    def most_depended_on(self) -> list[tuple[str, int]]:
        """Files that are imported by the most other files."""
        counts: dict[str, int] = {}
        for fd in self.files.values():
            for dep in fd.imported_by:
                counts[dep] = counts.get(dep, 0) + 1
        return sorted(counts.items(), key=lambda x: -x[1])[:10]

    @property
    def most_dependencies(self) -> list[tuple[str, int]]:
        """Files with the most imports."""
        return sorted(
            [(f.file_path, len(f.imports)) for f in self.files.values()],
            key=lambda x: -x[1],
        )[:10]

    def summary(self) -> str:
        lines = [
            f"Dependency report: {self.total_files} files, {self.total_dependencies} dependencies",
            f"External packages: {len(self.external_packages)}",
        ]
        if self.circular_deps:
            lines.append(f"Circular dependencies: {len(self.circular_deps)}")
            for cycle in self.circular_deps[:5]:
                lines.append(f"  {' -> '.join(cycle)}")
        if self.most_depended_on:
            lines.append("Most depended-on files:")
            for path, count in self.most_depended_on[:5]:
                lines.append(f"  {path}: imported by {count} files")
        return "\n".join(lines)

    def to_mermaid(self) -> str:
        """Generate a Mermaid dependency diagram."""
        lines = ["graph LR"]
        node_map: dict[str, str] = {}
        counter = 0

        for fd in self.files.values():
            for dep in fd.imports:
                if dep.is_external:
                    continue
                src = fd.file_path
                tgt = dep.target
                if src not in node_map:
                    node_map[src] = f"n{counter}"
                    counter += 1
                if tgt not in node_map:
                    node_map[tgt] = f"n{counter}"
                    counter += 1
                src_short = Path(src).stem
                tgt_short = Path(tgt).stem
                lines.append(f"    {node_map[src]}[{src_short}] --> {node_map[tgt]}[{tgt_short}]")

        return "\n".join(lines)


class DependencyAnalyzer:
    """Analyze dependencies in a project.

    Usage::

        analyzer = DependencyAnalyzer()

        # Analyze a directory
        report = analyzer.analyze(Path("src/"))

        # Show results
        print(report.summary())
        for cycle in report.circular_deps:
            print(f"  Circular: {' -> '.join(cycle)}")
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()
        self._extractor = SymbolExtractor(self._parser)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
    ) -> DependencyReport:
        """Analyze dependencies in *directory*."""
        if extensions is None:
            extensions = {".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs", ".java",
                         ".rb", ".php", ".swift", ".kt", ".scala", ".lua", ".dart"}
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

        report = DependencyReport()
        all_files: list[Path] = []

        for path in sorted(directory.rglob("*")):
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue
            all_files.append(path)

        # Analyze each file
        for path in all_files:
            file_deps = self._analyze_file(path, directory)
            report.files[str(path)] = file_deps

            # Collect external packages
            for dep in file_deps.imports:
                if dep.is_external:
                    report.external_packages.add(dep.target.split(".")[0])

        # Build reverse dependencies (imported_by)
        for fd in report.files.values():
            for dep in fd.imports:
                # Try to find the target file
                target_path = self._resolve_target(dep.target, dep.source_file, directory)
                if target_path and str(target_path) in report.files:
                    report.files[str(target_path)].imported_by.append(fd.file_path)

        # Detect circular dependencies
        report.circular_deps = self._find_cycles(report.files)

        return report

    def analyze_file(self, path: Path, project_root: Path | None = None) -> FileDependencies:
        """Analyze dependencies for a single file."""
        root = project_root or path.parent
        return self._analyze_file(path, root)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _analyze_file(self, path: Path, project_root: Path) -> FileDependencies:
        """Analyze a single file's dependencies."""
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            return FileDependencies(file_path=str(path))

        symbols = self._extractor.extract_from_file(path)
        imports = [s for s in symbols if s.kind in ("import", "require", "use", "include", "using", "library", "source", "part")]

        deps: list[Dependency] = []
        for imp in imports:
            module = imp.metadata.get("module", imp.name)
            is_relative = module.startswith(".") if module else False
            is_external = not is_relative and "/" not in module and "\\" not in module

            deps.append(Dependency(
                source_file=str(path),
                target=module,
                import_names=[imp.name],
                line=imp.line,
                is_external=is_external,
                is_relative=is_relative,
            ))

        return FileDependencies(file_path=str(path), imports=deps)

    @staticmethod
    def _resolve_target(module: str, source_file: str, project_root: Path) -> Path | None:
        """Try to resolve a module name to a file path."""
        source_dir = Path(source_file).parent

        if module.startswith("."):
            # Relative import
            parts = module.lstrip(".").split(".")
            current = source_dir
            for _ in range(len(module) - len(module.lstrip("."))):
                current = current.parent
            candidate = current / "/".join(parts)
            # Try various extensions
            for ext in (".py", ".js", ".ts", ".go", ".rs", ".java"):
                if (candidate.with_suffix(ext)).exists():
                    return candidate.with_suffix(ext)
                if (candidate / f"__init__{ext}").exists():
                    return candidate / f"__init__{ext}"
        else:
            # Absolute import — try within project
            parts = module.split(".")
            candidate = project_root / "/".join(parts)
            for ext in (".py", ".js", ".ts", ".go", ".rs", ".java"):
                if (candidate.with_suffix(ext)).exists():
                    return candidate.with_suffix(ext)
                if (candidate / f"__init__{ext}").exists():
                    return candidate / f"__init__{ext}"

        return None

    @staticmethod
    def _find_cycles(files: dict[str, FileDependencies]) -> list[list[str]]:
        """Find circular dependencies using DFS."""
        # Build adjacency list
        graph: dict[str, set[str]] = {}
        for fd in files.values():
            graph[fd.file_path] = set()
            for dep in fd.imports:
                if not dep.is_external:
                    # Try to resolve target to a file path
                    target = dep.target
                    # Simple: check if target matches any known file
                    for fpath in files:
                        if target in fpath or Path(fpath).stem == target.split(".")[-1]:
                            graph[fd.file_path].add(fpath)

        cycles: list[list[str]] = []
        visited: set[str] = set()
        rec_stack: set[str] = set()
        path_stack: list[str] = []

        def dfs(node: str) -> None:
            visited.add(node)
            rec_stack.add(node)
            path_stack.append(node)

            for neighbor in graph.get(node, set()):
                if neighbor not in visited:
                    dfs(neighbor)
                elif neighbor in rec_stack:
                    # Found cycle
                    cycle_start = path_stack.index(neighbor)
                    cycles.append(list(path_stack[cycle_start:]) + [neighbor])

            path_stack.pop()
            rec_stack.discard(node)

        for node in graph:
            if node not in visited:
                dfs(node)

        return cycles
