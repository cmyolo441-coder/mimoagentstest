"""Code smell detection.

Identifies common code smells and anti-patterns using AST analysis
and heuristic pattern matching.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser
from .complexity import ComplexityAnalyzer, FunctionComplexity
from .symbol_extractor import Symbol, SymbolExtractor

logger = logging.getLogger(__name__)


@dataclass
class CodeSmell:
    """A detected code smell."""

    smell_type: str
    severity: str  # "high", "medium", "low"
    file_path: str
    line: int
    message: str
    end_line: int = 0
    suggestion: str = ""
    symbol_name: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "smell_type": self.smell_type,
            "severity": self.severity,
            "file_path": self.file_path,
            "line": self.line,
            "end_line": self.end_line,
            "message": self.message,
            "suggestion": self.suggestion,
            "symbol_name": self.symbol_name,
        }


@dataclass
class SmellReport:
    """Report of code smells in a project."""

    smells: list[CodeSmell] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.smells)

    @property
    def high_severity(self) -> list[CodeSmell]:
        return [s for s in self.smells if s.severity == "high"]

    @property
    def by_type(self) -> dict[str, list[CodeSmell]]:
        groups: dict[str, list[CodeSmell]] = {}
        for s in self.smells:
            groups.setdefault(s.smell_type, []).append(s)
        return groups

    def summary(self) -> str:
        lines = [f"Code smell report: {self.total} issue(s)"]
        by_type = self.by_type
        for smell_type, smell_list in sorted(by_type.items(), key=lambda x: -len(x[1])):
            lines.append(f"  {smell_type}: {len(smell_list)}")
        if self.high_severity:
            lines.append("High severity:")
            for s in self.high_severity[:15]:
                lines.append(f"  {s.file_path}:{s.line} - {s.message}")
        return "\n".join(lines)


class SmellDetector:
    """Detect code smells and anti-patterns.

    Usage::

        detector = SmellDetector()

        # Analyze a directory
        report = detector.detect(Path("src/"))

        # Show results
        print(report.summary())
        for smell in report.high_severity:
            print(f"  {smell.smell_type}: {smell.message} at {smell.file_path}:{smell.line}")
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()
        self._extractor = SymbolExtractor(self._parser)
        self._complexity = ComplexityAnalyzer(self._parser)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def detect(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        max_files: int = 5000,
    ) -> SmellReport:
        """Detect code smells in *directory*."""
        if extensions is None:
            extensions = {".py", ".js", ".ts", ".go", ".rs", ".java", ".c", ".cpp",
                         ".rb", ".php", ".swift", ".kt", ".scala", ".lua", ".dart"}
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

        smells: list[CodeSmell] = []
        errors: list[str] = []
        count = 0

        for path in sorted(directory.rglob("*")):
            if count >= max_files:
                break
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue
            count += 1

            file_smells = self._detect_in_file(path)
            smells.extend(file_smells)

        return SmellReport(smells=smells, errors=errors)

    def detect_in_file(self, path: Path) -> SmellReport:
        """Detect code smells in a single file."""
        smells = self._detect_in_file(path)
        return SmellReport(smells=smells)

    # ------------------------------------------------------------------
    # Detection methods
    # ------------------------------------------------------------------

    def _detect_in_file(self, path: Path) -> list[CodeSmell]:
        """Detect all code smells in a single file."""
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            return []

        smells: list[CodeSmell] = []
        ext = path.suffix.lower()
        file_path = str(path)
        lines = source.splitlines()

        # Long methods
        smells.extend(self._check_long_methods(source, path, file_path))

        # Long files
        if len(lines) > 500:
            smells.append(CodeSmell(
                smell_type="long_file",
                severity="medium" if len(lines) > 1000 else "low",
                file_path=file_path,
                line=1,
                end_line=len(lines),
                message=f"File has {len(lines)} lines (consider splitting)",
                suggestion="Break into smaller, focused modules",
            ))

        # Deep nesting
        smells.extend(self._check_deep_nesting(lines, file_path, ext))

        # Magic numbers
        smells.extend(self._check_magic_numbers(lines, file_path, ext))

        # God class / large functions
        smells.extend(self._check_large_functions(source, path, file_path))

        # Duplicate code patterns
        smells.extend(self._check_duplicate_patterns(lines, file_path, ext))

        # Naming conventions
        smells.extend(self._check_naming(source, path, file_path, ext))

        # Commented-out code
        smells.extend(self._check_commented_code(lines, file_path, ext))

        # Empty blocks
        smells.extend(self._check_empty_blocks(lines, file_path, ext))

        # TODO/FIXME comments
        smells.extend(self._check_todos(lines, file_path))

        return smells

    def _check_long_methods(self, source: str, path: Path, file_path: str) -> list[CodeSmell]:
        """Check for methods that are too long."""
        smells: list[CodeSmell] = []
        fc = self._complexity.analyze_file(path)

        for func in fc.functions:
            loc = func.lines_of_code
            if loc > 100:
                smells.append(CodeSmell(
                    smell_type="long_method",
                    severity="high" if loc > 200 else "medium",
                    file_path=file_path,
                    line=func.line,
                    end_line=func.end_line,
                    message=f"Method '{func.name}' has {loc} lines",
                    suggestion="Break into smaller methods",
                    symbol_name=func.name,
                ))

        return smells

    def _check_large_functions(self, source: str, path: Path, file_path: str) -> list[CodeSmell]:
        """Check for functions with too many parameters."""
        smells: list[CodeSmell] = []
        symbols = self._extractor.extract_from_file(path)

        for sym in symbols:
            if sym.kind in ("function", "method"):
                if len(sym.params) > 7:
                    smells.append(CodeSmell(
                        smell_type="too_many_parameters",
                        severity="high" if len(sym.params) > 10 else "medium",
                        file_path=file_path,
                        line=sym.line,
                        message=f"Function '{sym.name}' has {len(sym.params)} parameters",
                        suggestion="Use a config object, dataclass, or builder pattern",
                        symbol_name=sym.name,
                    ))

        return smells

    @staticmethod
    def _check_deep_nesting(lines: list[str], file_path: str, ext: str) -> list[CodeSmell]:
        """Check for deeply nested code."""
        smells: list[CodeSmell] = []
        max_depth = 0
        current_depth = 0

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if not stripped:
                continue

            indent = len(line) - len(line.lstrip())
            depth = indent // 4

            if depth > max_depth:
                max_depth = depth

            if depth > 4:
                smells.append(CodeSmell(
                    smell_type="deep_nesting",
                    severity="high" if depth > 6 else "medium",
                    file_path=file_path,
                    line=i,
                    message=f"Nesting depth is {depth} levels",
                    suggestion="Extract inner logic into separate functions or use early returns",
                ))

        return smells

    @staticmethod
    def _check_magic_numbers(lines: list[str], file_path: str, ext: str) -> list[CodeSmell]:
        """Check for magic numbers in code."""
        smells: list[CodeSmell] = []
        # Match numbers that aren't 0, 1, -1, 2, or part of common patterns
        magic_pattern = re.compile(r"(?<![a-zA-Z_\.\d])(\d{2,})(?![a-zA-Z_\.\d])")

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            # Skip comments, imports, constants
            if stripped.startswith(("#", "//", "/*", "*", "import", "from", "const ", "let ", "var ", "val ", "def ", "func ")):
                continue

            for m in magic_pattern.finditer(stripped):
                num = m.group(1)
                # Allow common non-magic numbers
                if num in ("10", "16", "20", "24", "60", "100", "200", "255", "256", "404", "500", "8080", "8888"):
                    continue
                smells.append(CodeSmell(
                    smell_type="magic_number",
                    severity="low",
                    file_path=file_path,
                    line=i,
                    message=f"Magic number {num}",
                    suggestion="Extract into a named constant",
                ))

        return smells

    @staticmethod
    def _check_duplicate_patterns(lines: list[str], file_path: str, ext: str) -> list[CodeSmell]:
        """Check for repeated code patterns within a file."""
        smells: list[CodeSmell] = []
        # Look for repeated identical blocks
        seen_blocks: dict[str, list[int]] = {}

        for i in range(len(lines) - 2):
            block = "\n".join(l.strip() for l in lines[i : i + 3])
            if len(block) < 20:
                continue
            if block not in seen_blocks:
                seen_blocks[block] = []
            seen_blocks[block].append(i + 1)

        for block, line_nums in seen_blocks.items():
            if len(line_nums) >= 3:
                smells.append(CodeSmell(
                    smell_type="duplicated_block",
                    severity="medium",
                    file_path=file_path,
                    line=line_nums[0],
                    message=f"Similar 3-line block appears {len(line_nums)} times (lines: {', '.join(map(str, line_nums[:5]))})",
                    suggestion="Extract into a shared function",
                ))

        return smells

    @staticmethod
    def _check_naming(source: str, path: Path, file_path: str, ext: str) -> list[CodeSmell]:
        """Check for naming convention violations."""
        smells: list[CodeSmell] = []

        if ext in (".py", ".pyi"):
            # Check for camelCase function names in Python
            for m in re.finditer(r"def\s+([a-z]+[A-Z]\w*)\s*\(", source):
                line = source[: m.start()].count("\n") + 1
                smells.append(CodeSmell(
                    smell_type="naming_convention",
                    severity="low",
                    file_path=file_path,
                    line=line,
                    message=f"Function '{m.group(1)}' uses camelCase (Python prefers snake_case)",
                    symbol_name=m.group(1),
                ))

            # Check for single-letter variable names (except common ones)
            for m in re.finditer(r"(?:^|\n)\s*(\w)\s*=", source):
                name = m.group(1)
                if name not in ("i", "j", "k", "x", "y", "z", "f", "e", "_"):
                    line = source[: m.start()].count("\n") + 1
                    smells.append(CodeSmell(
                        smell_type="poor_naming",
                        severity="low",
                        file_path=file_path,
                        line=line,
                        message=f"Single-letter variable name '{name}'",
                        suggestion="Use a descriptive name",
                    ))

        return smells

    @staticmethod
    def _check_commented_code(lines: list[str], file_path: str, ext: str) -> list[CodeSmell]:
        """Check for commented-out code."""
        smells: list[CodeSmell] = []
        code_comment_patterns = [
            re.compile(r"^\s*#\s*(def |class |import |from |if |for |while |return |print\()"),
            re.compile(r"^\s*//\s*(function |const |let |var |if |for |while |return |console\.)"),
            re.compile(r"^\s*//\s*\w+\s*[=(]"),
        ]

        for i, line in enumerate(lines, 1):
            for pattern in code_comment_patterns:
                if pattern.match(line):
                    smells.append(CodeSmell(
                        smell_type="commented_code",
                        severity="low",
                        file_path=file_path,
                        line=i,
                        message="Commented-out code detected",
                        suggestion="Remove commented-out code (use version control instead)",
                    ))
                    break

        return smells

    @staticmethod
    def _check_empty_blocks(lines: list[str], file_path: str, ext: str) -> list[CodeSmell]:
        """Check for empty code blocks."""
        smells: list[CodeSmell] = []

        for i, line in enumerate(lines):
            stripped = line.strip()
            # Check for pattern: { } or : pass
            if stripped.endswith("{}") or stripped.endswith("{ }"):
                smells.append(CodeSmell(
                    smell_type="empty_block",
                    severity="low",
                    file_path=file_path,
                    line=i + 1,
                    message="Empty code block",
                    suggestion="Add implementation or a comment explaining why it's empty",
                ))
            if stripped == "pass" and i + 1 < len(lines):
                next_line = lines[i + 1].strip() if i + 1 < len(lines) else ""
                if not next_line or next_line.startswith(("def ", "class ", "return")):
                    smells.append(CodeSmell(
                        smell_type="empty_block",
                        severity="low",
                        file_path=file_path,
                        line=i + 1,
                        message="Empty 'pass' block",
                        suggestion="Add implementation or a comment",
                    ))

        return smells

    @staticmethod
    def _check_todos(lines: list[str], file_path: str) -> list[CodeSmell]:
        """Check for TODO/FIXME/HACK comments."""
        smells: list[CodeSmell] = []

        for i, line in enumerate(lines, 1):
            for marker in ("TODO", "FIXME", "HACK", "XXX", "WORKAROUND"):
                if marker in line:
                    smells.append(CodeSmell(
                        smell_type="todo_comment",
                        severity="low",
                        file_path=file_path,
                        line=i,
                        message=f"{marker} comment: {line.strip()[:100]}",
                    ))

        return smells
