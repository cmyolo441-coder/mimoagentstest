"""Multi-language AST parsing abstraction.

Provides a unified interface for parsing source code into abstract syntax
trees across 20+ programming languages. Uses native AST modules where
available (Python), falls back to regex-based extraction otherwise.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .languages import get_analyzer, get_analyzer_for_language, supported_extensions, supported_languages

logger = logging.getLogger(__name__)


@dataclass
class ParseResult:
    """Result of parsing a source file."""

    success: bool
    language: str = ""
    path: str = ""
    source_length: int = 0
    tree: Any = None  # The raw AST / parsed representation
    symbols: list[dict[str, Any]] = field(default_factory=list)
    error: str | None = None
    parse_method: str = ""  # "ast" or "regex"

    @property
    def symbol_count(self) -> int:
        return len(self.symbols)

    @property
    def functions(self) -> list[dict[str, Any]]:
        return [s for s in self.symbols if s.get("kind") in ("function", "method")]

    @property
    def classes(self) -> list[dict[str, Any]]:
        return [s for s in self.symbols if s.get("kind") in ("class", "struct", "interface", "trait", "enum")]

    @property
    def imports(self) -> list[dict[str, Any]]:
        return [s for s in self.symbols if s.get("kind") in ("import", "require", "use", "include", "using", "library", "source", "part")]

    @property
    def variables(self) -> list[dict[str, Any]]:
        return [s for s in self.symbols if s.get("kind") in ("variable", "constant", "property", "field", "val", "var")]


class ASTParser:
    """Unified AST parser for multiple programming languages.

    Usage::

        parser = ASTParser()
        result = parser.parse_file(Path("main.py"))
        if result.success:
            for func in result.functions:
                print(func["name"], func["line"])

        result = parser.parse_source("def foo(): pass", language="python")
    """

    def __init__(self) -> None:
        self._cache: dict[str, ParseResult] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def parse_file(self, path: Path, *, use_cache: bool = True) -> ParseResult:
        """Parse a file from disk.

        Parameters:
            path: Path to the source file.
            use_cache: If *True*, cache results keyed by resolved path.

        Returns:
            A :class:`ParseResult` with the parsed symbols.
        """
        resolved = path.resolve()
        cache_key = str(resolved)

        if use_cache and cache_key in self._cache:
            return self._cache[cache_key]

        try:
            source = resolved.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as exc:
            result = ParseResult(success=False, path=str(path), error=str(exc))
            return result

        result = self.parse_source(source, path=path, language=None)
        if use_cache:
            self._cache[cache_key] = result
        return result

    def parse_source(
        self,
        source: str,
        *,
        path: Path | None = None,
        language: str | None = None,
    ) -> ParseResult:
        """Parse source code from a string.

        Parameters:
            source: The source code text.
            path: Optional file path (used for language detection and error messages).
            language: Override language detection.  If *None*, detected from *path*.

        Returns:
            A :class:`ParseResult`.
        """
        if language:
            analyzer = get_analyzer_for_language(language)
        elif path:
            analyzer = get_analyzer(path)
        else:
            return ParseResult(success=False, error="No path or language specified")

        if analyzer is None:
            lang_name = language or (path.suffix if path else "unknown")
            return ParseResult(
                success=False,
                language=lang_name,
                path=str(path) if path else "",
                error=f"No analyzer available for {lang_name}",
            )

        try:
            tree = analyzer.parse(source, path)
            symbols = analyzer.extract_symbols(source, path)
        except Exception as exc:
            logger.debug("Parse error for %s: %s", path, exc)
            return ParseResult(
                success=False,
                language=analyzer.language,
                path=str(path) if path else "",
                error=str(exc),
            )

        # Determine parse method
        parse_method = "ast" if analyzer.language == "python" else "regex"

        return ParseResult(
            success=True,
            language=analyzer.language,
            path=str(path) if path else "",
            source_length=len(source),
            tree=tree,
            symbols=symbols,
            parse_method=parse_method,
        )

    def find_references_in_file(self, path: Path, symbol: str) -> list[dict[str, Any]]:
        """Find all references to *symbol* in the file at *path*.

        Returns a list of reference dicts with ``line``, ``col``, etc.
        """
        analyzer = get_analyzer(path)
        if analyzer is None:
            return []
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            return []
        return analyzer.find_references(source, symbol, path)

    def find_references_in_source(
        self,
        source: str,
        symbol: str,
        *,
        path: Path | None = None,
        language: str | None = None,
    ) -> list[dict[str, Any]]:
        """Find all references to *symbol* in *source*."""
        if language:
            analyzer = get_analyzer_for_language(language)
        elif path:
            analyzer = get_analyzer(path)
        else:
            return []
        if analyzer is None:
            return []
        return analyzer.find_references(source, symbol, path)

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @staticmethod
    def supported_languages() -> list[str]:
        """Return sorted list of supported language names."""
        return supported_languages()

    @staticmethod
    def supported_extensions() -> set[str]:
        """Return all supported file extensions."""
        return supported_extensions()

    def can_parse(self, path: Path) -> bool:
        """Return *True* if an analyzer exists for *path*'s extension."""
        return get_analyzer(path) is not None

    def clear_cache(self) -> None:
        """Clear the parse result cache."""
        self._cache.clear()
