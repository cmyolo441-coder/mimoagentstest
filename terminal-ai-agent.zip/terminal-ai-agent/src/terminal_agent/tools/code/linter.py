"""Code linting integration.

Wraps external linters (pylint, eslint, golangci-lint, clippy, etc.)
with a unified interface and provides basic built-in lint checks.
"""

from __future__ import annotations

import json
import logging
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_LINTER_MAP: dict[str, dict[str, Any]] = {
    ".py": {"cmd": ["pylint", "--output-format=json", "--disable=C0114,C0115,C0116"], "name": "pylint"},
    ".pyi": {"cmd": ["pylint", "--output-format=json"], "name": "pylint"},
    ".js": {"cmd": ["eslint", "-f", "json"], "name": "eslint"},
    ".jsx": {"cmd": ["eslint", "-f", "json"], "name": "eslint"},
    ".ts": {"cmd": ["eslint", "-f", "json"], "name": "eslint"},
    ".tsx": {"cmd": ["eslint", "-f", "json"], "name": "eslint"},
    ".go": {"cmd": ["golangci-lint", "run", "--out-format=json"], "name": "golangci-lint"},
    ".rs": {"cmd": ["cargo", "clippy", "--message-format=json"], "name": "clippy"},
    ".c": {"cmd": ["cppcheck", "--enable=all", "--output-file=-"], "name": "cppcheck"},
    ".h": {"cmd": ["cppcheck", "--enable=all", "--output-file=-"], "name": "cppcheck"},
    ".cpp": {"cmd": ["cppcheck", "--enable=all", "--output-file=-"], "name": "cppcheck"},
    ".java": {"cmd": ["checkstyle", "-f", "json"], "name": "checkstyle"},
    ".rb": {"cmd": ["rubocop", "--format", "json"], "name": "rubocop"},
    ".php": {"cmd": ["phpcs", "--report=json"], "name": "phpcs"},
    ".swift": {"cmd": ["swiftlint", "--reporter", "json"], "name": "swiftlint"},
    ".dart": {"cmd": ["dart", "analyze", "--format=json"], "name": "dart analyze"},
    ".lua": {"cmd": ["luacheck", "--formatter", "JSON"], "name": "luacheck"},
    ".kt": {"cmd": ["ktlint", "--reporter=json"], "name": "ktlint"},
    ".cs": {"cmd": ["dotnet", "format", "verify-no-changes"], "name": "dotnet format"},
    ".scala": {"cmd": ["scalafmt", "--check"], "name": "scalafmt"},
    ".hs": {"cmd": ["hlint", "--json"], "name": "hlint"},
    ".zig": {"cmd": ["zig", "build", "--summary", "all"], "name": "zig build"},
    ".r": {"cmd": ["Rscript", "-e", "lintr::lint('{file}')"], "name": "lintr"},
}


@dataclass
class LintIssue:
    """A single lint issue."""

    file_path: str
    line: int
    col: int = 0
    severity: str = "warning"  # "error", "warning", "info", "convention"
    code: str = ""
    message: str = ""
    source: str = ""  # linter name

    def to_dict(self) -> dict[str, Any]:
        return {
            "file_path": self.file_path,
            "line": self.line,
            "col": self.col,
            "severity": self.severity,
            "code": self.code,
            "message": self.message,
            "source": self.source,
        }

    def __str__(self) -> str:
        loc = f"{self.file_path}:{self.line}:{self.col}"
        return f"{loc}: {self.severity}: {self.code}: {self.message}"


@dataclass
class LintResult:
    """Result of a linting operation."""

    success: bool
    file_path: str = ""
    linter: str = ""
    issues: list[LintIssue] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def error_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "error")

    @property
    def warning_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "warning")

    @property
    def is_clean(self) -> bool:
        return len(self.issues) == 0

    def summary(self) -> str:
        if self.is_clean:
            return f"{self.file_path}: clean ({self.linter})"
        parts = [f"{self.file_path}: {len(self.issues)} issue(s) ({self.linter})"]
        if self.error_count:
            parts.append(f"  Errors: {self.error_count}")
        if self.warning_count:
            parts.append(f"  Warnings: {self.warning_count}")
        for issue in self.issues[:20]:  # Show first 20
            parts.append(f"  {issue}")
        if len(self.issues) > 20:
            parts.append(f"  ... and {len(self.issues) - 20} more")
        return "\n".join(parts)

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "file_path": self.file_path,
            "linter": self.linter,
            "issue_count": len(self.issues),
            "error_count": self.error_count,
            "warning_count": self.warning_count,
            "issues": [i.to_dict() for i in self.issues],
        }


class Linter:
    """Run linters on source code.

    Usage::

        linter = Linter()

        # Lint a single file
        result = linter.lint_file(Path("main.py"))

        # Lint a directory
        results = linter.lint_directory(Path("src/"))

        # Run built-in checks (no external tool needed)
        result = linter.lint_builtin(Path("main.py"))
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def lint_file(self, path: Path, *, use_external: bool = True) -> LintResult:
        """Lint a single file.

        Parameters:
            path: File to lint.
            use_external: If *True*, use the external linter if available.
                         Otherwise use built-in checks only.

        Returns:
            A :class:`LintResult`.
        """
        ext = path.suffix.lower()
        linter_info = _LINTER_MAP.get(ext)

        if use_external and linter_info and shutil.which(linter_info["cmd"][0]):
            return self._run_external(linter_info, path)

        # Fall back to built-in
        return self.lint_builtin(path)

    def lint_source(self, source: str, *, language: str | None = None, path: Path | None = None) -> LintResult:
        """Lint source code from a string (built-in checks only)."""
        if language:
            ext = language if language.startswith(".") else f".{language}"
        elif path:
            ext = path.suffix.lower()
        else:
            return LintResult(success=False, errors=["No language or path specified"])

        file_path = str(path) if path else "<string>"
        issues = self._builtin_checks(source, ext, file_path)

        return LintResult(
            success=True,
            file_path=file_path,
            linter="builtin",
            issues=issues,
        )

    def lint_directory(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        max_files: int = 1000,
    ) -> list[LintResult]:
        """Lint all files in *directory*.

        Returns:
            A list of :class:`LintResult` for each file.
        """
        if extensions is None:
            extensions = set(_LINTER_MAP.keys())
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build", ".tox"}

        results: list[LintResult] = []
        count = 0

        for path in sorted(directory.rglob("*")):
            if count >= max_files:
                break
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue
            count += 1
            results.append(self.lint_file(path))

        return results

    def lint_builtin(self, path: Path) -> LintResult:
        """Run only built-in lint checks on *path*.

        These checks don't require any external tools.
        """
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as exc:
            return LintResult(success=False, file_path=str(path), errors=[str(exc)])

        issues = self._builtin_checks(source, path.suffix.lower(), str(path))

        return LintResult(
            success=True,
            file_path=str(path),
            linter="builtin",
            issues=issues,
        )

    def available_linters(self) -> dict[str, bool]:
        """Return which external linters are available."""
        seen: dict[str, bool] = {}
        for info in _LINTER_MAP.values():
            name = info["name"]
            if name not in seen:
                seen[name] = shutil.which(info["cmd"][0]) is not None
        return seen

    # ------------------------------------------------------------------
    # Built-in checks
    # ------------------------------------------------------------------

    def _builtin_checks(self, source: str, ext: str, file_path: str) -> list[LintIssue]:
        """Run built-in lint checks that work without external tools."""
        issues: list[LintIssue] = []
        lines = source.splitlines()

        for i, line in enumerate(lines, 1):
            # Trailing whitespace
            if line != line.rstrip():
                issues.append(LintIssue(
                    file_path=file_path, line=i, col=len(line.rstrip()),
                    severity="info", code="W001", message="Trailing whitespace",
                    source="builtin",
                ))

            # Line length
            if len(line) > 120:
                issues.append(LintIssue(
                    file_path=file_path, line=i, col=121,
                    severity="info", code="W002",
                    message=f"Line too long ({len(line)} > 120)",
                    source="builtin",
                ))

            # Tab characters
            if "\t" in line:
                issues.append(LintIssue(
                    file_path=file_path, line=i, col=line.index("\t") + 1,
                    severity="info", code="W003", message="Tab character in source",
                    source="builtin",
                ))

        # Missing final newline
        if source and not source.endswith("\n"):
            issues.append(LintIssue(
                file_path=file_path, line=len(lines), col=0,
                severity="info", code="W004", message="No final newline",
                source="builtin",
            ))

        # Language-specific checks
        if ext in (".py", ".pyi"):
            issues.extend(self._python_checks(source, file_path))
        elif ext in (".js", ".jsx", ".ts", ".tsx"):
            issues.extend(self._js_checks(source, file_path))

        return issues

    @staticmethod
    def _python_checks(source: str, file_path: str) -> list[LintIssue]:
        issues: list[LintIssue] = []
        lines = source.splitlines()

        for i, line in enumerate(lines, 1):
            # Bare except
            if line.strip() == "except:" or line.strip().startswith("except:"):
                issues.append(LintIssue(
                    file_path=file_path, line=i, col=1,
                    severity="warning", code="E001",
                    message="Bare 'except' clause — use 'except Exception' instead",
                    source="builtin",
                ))

            # Mutable default argument
            if "def " in line and ("=[]" in line or "={}" in line or "=set()" in line):
                issues.append(LintIssue(
                    file_path=file_path, line=i, col=1,
                    severity="warning", code="E002",
                    message="Mutable default argument",
                    source="builtin",
                ))

            # print statement (might be debug leftover)
            if re.match(r"\s*print\s*\(", line) and "debug" not in file_path.lower():
                issues.append(LintIssue(
                    file_path=file_path, line=i, col=1,
                    severity="info", code="W010",
                    message="print() statement — consider using logging",
                    source="builtin",
                ))

            # TODO/FIXME/HACK comments
            for marker in ("TODO", "FIXME", "HACK", "XXX"):
                if marker in line:
                    issues.append(LintIssue(
                        file_path=file_path, line=i, col=line.index(marker) + 1,
                        severity="info", code="W011",
                        message=f"{marker} comment found",
                        source="builtin",
                    ))
                    break

        return issues

    @staticmethod
    def _js_checks(source: str, file_path: str) -> list[LintIssue]:
        issues: list[LintIssue] = []
        lines = source.splitlines()

        for i, line in enumerate(lines, 1):
            # console.log (debug leftover)
            if "console.log(" in line:
                issues.append(LintIssue(
                    file_path=file_path, line=i, col=line.index("console.log") + 1,
                    severity="info", code="W020",
                    message="console.log() — consider removing for production",
                    source="builtin",
                ))

            # var usage
            if re.match(r"\s*var\s+", line):
                issues.append(LintIssue(
                    file_path=file_path, line=i, col=1,
                    severity="info", code="W021",
                    message="Use 'const' or 'let' instead of 'var'",
                    source="builtin",
                ))

            # == instead of ===
            if "==" in line and "===" not in line and "!=" in line and "!==" not in line:
                pass  # too many false positives
            if re.search(r"[^=!]==[^=]", line):
                issues.append(LintIssue(
                    file_path=file_path, line=i, col=1,
                    severity="info", code="W022",
                    message="Use '===' instead of '=='",
                    source="builtin",
                ))

        return issues

    # ------------------------------------------------------------------
    # External linter execution
    # ------------------------------------------------------------------

    def _run_external(self, linter_info: dict[str, Any], path: Path) -> LintResult:
        """Run an external linter and parse its output."""
        cmd = list(linter_info["cmd"])

        if "{file}" in " ".join(cmd):
            cmd = [c.replace("{file}", str(path)) for c in cmd]
        else:
            cmd.append(str(path))

        name = linter_info["name"]

        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            return LintResult(success=False, file_path=str(path), linter=name, errors=["Linter timed out"])
        except FileNotFoundError:
            return LintResult(success=False, file_path=str(path), linter=name, errors=[f"Linter '{name}' not found"])

        issues = self._parse_output(name, proc.stdout, proc.stderr, str(path))

        return LintResult(
            success=True,
            file_path=str(path),
            linter=name,
            issues=issues,
        )

    def _parse_output(self, linter_name: str, stdout: str, stderr: str, file_path: str) -> list[LintIssue]:
        """Parse linter output into :class:`LintIssue` objects."""
        issues: list[LintIssue] = []

        if linter_name == "pylint":
            issues.extend(self._parse_pylint(stdout, file_path))
        elif linter_name == "eslint":
            issues.extend(self._parse_eslint(stdout, file_path))
        elif linter_name == "hlint":
            issues.extend(self._parse_hlint(stdout, file_path))
        else:
            # Generic: try JSON, fall back to line-by-line
            issues.extend(self._parse_generic(stdout, stderr, file_path, linter_name))

        return issues

    @staticmethod
    def _parse_pylint(output: str, file_path: str) -> list[LintIssue]:
        issues: list[LintIssue] = []
        try:
            data = json.loads(output)
            for item in data:
                issues.append(LintIssue(
                    file_path=item.get("path", file_path),
                    line=item.get("line", 0),
                    col=item.get("column", 0),
                    severity={"E": "error", "W": "warning", "C": "convention", "R": "info"}.get(
                        item.get("type", "W")[0], "warning"
                    ),
                    code=item.get("message-id", ""),
                    message=item.get("message", ""),
                    source="pylint",
                ))
        except (json.JSONDecodeError, KeyError):
            pass
        return issues

    @staticmethod
    def _parse_eslint(output: str, file_path: str) -> list[LintIssue]:
        issues: list[LintIssue] = []
        try:
            data = json.loads(output)
            for file_data in data:
                for msg in file_data.get("messages", []):
                    issues.append(LintIssue(
                        file_path=file_data.get("filePath", file_path),
                        line=msg.get("line", 0),
                        col=msg.get("column", 0),
                        severity={2: "error", 1: "warning", 0: "info"}.get(msg.get("severity", 1), "warning"),
                        code=msg.get("ruleId", ""),
                        message=msg.get("message", ""),
                        source="eslint",
                    ))
        except (json.JSONDecodeError, KeyError):
            pass
        return issues

    @staticmethod
    def _parse_hlint(output: str, file_path: str) -> list[LintIssue]:
        issues: list[LintIssue] = []
        try:
            data = json.loads(output)
            for item in data:
                issues.append(LintIssue(
                    file_path=item.get("file", file_path),
                    line=item.get("startLine", 0),
                    col=item.get("startColumn", 0),
                    severity="info",
                    code=item.get("severity", "Suggestion"),
                    message=item.get("hint", ""),
                    source="hlint",
                ))
        except (json.JSONDecodeError, KeyError):
            pass
        return issues

    @staticmethod
    def _parse_generic(stdout: str, stderr: str, file_path: str, linter_name: str) -> list[LintIssue]:
        issues: list[LintIssue] = []
        # Try to parse common patterns: file:line:col: message
        import re
        pattern = re.compile(r"^(.+?):(\d+)(?::(\d+))?:\s*((?:error|warning|note|info):\s*.+)$", re.MULTILINE)
        for m in pattern.finditer(stdout + "\n" + stderr):
            issues.append(LintIssue(
                file_path=m.group(1),
                line=int(m.group(2)),
                col=int(m.group(3)) if m.group(3) else 0,
                severity="warning",
                message=m.group(4),
                source=linter_name,
            ))
        return issues


# Need re import for the static methods
import re
