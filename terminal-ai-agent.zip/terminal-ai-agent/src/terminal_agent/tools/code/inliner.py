"""Inline function calls at their call sites.

Replaces function calls with the function's body, performing
appropriate parameter substitution and scope management.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser
from .symbol_extractor import Symbol, SymbolExtractor

logger = logging.getLogger(__name__)


@dataclass
class InlineResult:
    """Result of inlining a function."""

    success: bool
    function_name: str = ""
    call_site_file: str = ""
    call_site_line: int = 0
    original_call: str = ""
    inlined_code: str = ""
    modified_source: str = ""
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"Inlined '{self.function_name}' at {self.call_site_file}:{self.call_site_line}"]
        if self.warnings:
            for w in self.warnings:
                lines.append(f"  Warning: {w}")
        if self.errors:
            for e in self.errors:
                lines.append(f"  Error: {e}")
        return "\n".join(lines)


class Inliner:
    """Inline function calls at their call sites.

    Usage::

        inliner = Inliner()

        # Inline a specific call
        result = inliner.inline_call(
            source_path=Path("main.py"),
            call_line=15,
            function_def_path=Path("utils.py"),
        )

        # Inline all calls to a function
        results = inliner.inline_all_calls(
            directory=Path("src/"),
            function_name="helper",
            function_def_path=Path("utils.py"),
        )
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()
        self._extractor = SymbolExtractor(self._parser)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def inline_call(
        self,
        source_path: Path,
        call_line: int,
        function_def_path: Path,
        *,
        function_name: str | None = None,
    ) -> InlineResult:
        """Inline a function call at *call_line* in *source_path*.

        Parameters:
            source_path: File containing the call site.
            call_line: Line number of the call (1-indexed).
            function_def_path: File containing the function definition.
            function_name: Function name. Auto-detected if *None*.

        Returns:
            An :class:`InlineResult`.
        """
        # Read both files
        try:
            source = source_path.read_text(encoding="utf-8", errors="replace")
            def_source = function_def_path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as exc:
            return InlineResult(success=False, errors=[str(exc)])

        # Find the function definition
        func_sym = self._find_function(def_source, function_name, function_def_path)
        if func_sym is None:
            return InlineResult(
                success=False,
                errors=[f"Function '{function_name}' not found in {function_def_path}"],
            )

        # Extract the function body
        body = self._extract_body(def_source, func_sym)
        if body is None:
            return InlineResult(
                success=False,
                errors=[f"Could not extract body of '{func_sym.name}'"],
            )

        # Find the call at the specified line
        lines = source.splitlines()
        if call_line < 1 or call_line > len(lines):
            return InlineResult(success=False, errors=[f"Line {call_line} out of range"])

        call_text = lines[call_line - 1]
        call_match = re.search(
            r"\b" + re.escape(func_sym.name) + r"\s*\(([^)]*)\)",
            call_text,
        )
        if not call_match:
            return InlineResult(
                success=False,
                errors=[f"No call to '{func_sym.name}' found on line {call_line}"],
            )

        # Get call arguments
        args_str = call_match.group(1)
        args = [a.strip() for a in args_str.split(",") if a.strip()] if args_str.strip() else []

        # Map parameters to arguments
        param_map = self._build_param_map(func_sym.params, args)

        # Substitute parameters in body
        inlined = self._substitute_params(body, param_map)

        # Determine indentation at call site
        call_indent = len(call_text) - len(call_text.lstrip())
        inlined = self._adjust_indent(inlined, call_indent)

        # Handle return values
        return_vars = self._detect_return_usage(source, call_line, func_sym.name)
        if return_vars:
            inlined = self._wrap_return(inlined, return_vars, call_indent)

        # Replace the call in source
        new_lines = list(lines)
        inlined_lines = inlined.splitlines(keepends=True)

        # Remove the call line and insert inlined code
        prefix = call_text[: call_match.start()]
        suffix = call_text[call_match.end() :]

        new_lines[call_line - 1] = ""
        for i, il in enumerate(inlined_lines):
            if i == 0:
                new_lines.insert(call_line - 1 + i, prefix + il)
            elif i == len(inlined_lines) - 1 and suffix.strip():
                new_lines.insert(call_line - 1 + i, il.rstrip("\n") + suffix + "\n")
            else:
                new_lines.insert(call_line - 1 + i, il)

        modified_source = "".join(new_lines)

        return InlineResult(
            success=True,
            function_name=func_sym.name,
            call_site_file=str(source_path),
            call_site_line=call_line,
            original_call=call_match.group(0),
            inlined_code=inlined,
            modified_source=modified_source,
        )

    def inline_all_calls(
        self,
        directory: Path,
        function_name: str,
        function_def_path: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
    ) -> list[InlineResult]:
        """Inline all calls to *function_name* across *directory*.

        Returns:
            A list of :class:`InlineResult` for each call site.
        """
        from .reference_finder import ReferenceFinder

        finder = ReferenceFinder(self._parser)
        refs = finder.get_callers(directory, function_name, extensions=extensions)

        results: list[InlineResult] = []
        # Process in reverse order within each file to preserve line numbers
        refs_by_file: dict[str, list] = {}
        for ref in refs:
            refs_by_file.setdefault(ref.file_path, []).append(ref)

        for file_path, file_refs in refs_by_file.items():
            sorted_refs = sorted(file_refs, key=lambda r: r.line, reverse=True)
            current_source = Path(file_path).read_text(encoding="utf-8", errors="replace")

            for ref in sorted_refs:
                result = self.inline_call(
                    source_path=Path(file_path),
                    call_line=ref.line,
                    function_def_path=function_def_path,
                    function_name=function_name,
                )
                results.append(result)

                # Update source for subsequent inlines in the same file
                if result.success:
                    current_source = result.modified_source
                    Path(file_path).write_text(current_source, encoding="utf-8")

        return results

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_function(self, source: str, name: str | None, path: Path) -> Symbol | None:
        """Find a function definition in *source*."""
        symbols = self._extractor.extract_from_source(source, path=path)
        functions = [s for s in symbols if s.kind in ("function", "method")]
        if name:
            matches = [f for f in functions if f.name == name]
            return matches[0] if matches else None
        return functions[0] if functions else None

    @staticmethod
    def _extract_body(source: str, func: Symbol) -> str | None:
        """Extract the body of a function."""
        lines = source.splitlines(keepends=True)
        start = func.line - 1  # function def line
        end = func.end_line if func.end_line > func.line else func.line

        if start >= len(lines):
            return None

        # Find the body (after the def line)
        body_lines = lines[start + 1 : end]
        if not body_lines:
            return None

        # Remove common indentation
        min_indent = min(
            (len(l) - len(l.lstrip()))
            for l in body_lines
            if l.strip()
        ) if body_lines else 0

        dedented = []
        for line in body_lines:
            if line.strip():
                dedented.append(line[min_indent:])
            else:
                dedented.append("\n")

        return "".join(dedented)

    @staticmethod
    def _build_param_map(params: list[dict[str, Any]], args: list[str]) -> dict[str, str]:
        """Build parameter name -> argument value mapping."""
        param_map: dict[str, str] = {}
        for i, param in enumerate(params):
            name = param.get("name", "")
            if i < len(args):
                param_map[name] = args[i]
            elif param.get("default"):
                param_map[name] = param["default"]
        return param_map

    @staticmethod
    def _substitute_params(body: str, param_map: dict[str, str]) -> str:
        """Replace parameter names with argument values in the body."""
        result = body
        # Sort by length descending to avoid partial replacements
        for name, value in sorted(param_map.items(), key=lambda x: -len(x[0])):
            result = re.sub(r"\b" + re.escape(name) + r"\b", value, result)
        return result

    @staticmethod
    def _adjust_indent(code: str, target_indent: int) -> str:
        """Adjust indentation of *code* to *target_indent*."""
        lines = code.splitlines(keepends=True)
        if not lines:
            return code
        current_indent = min(
            (len(l) - len(l.lstrip()))
            for l in lines
            if l.strip()
        )
        diff = target_indent - current_indent
        if diff == 0:
            return code
        result = []
        for line in lines:
            if line.strip():
                if diff > 0:
                    result.append(" " * diff + line)
                else:
                    stripped = line.lstrip()
                    result.append(stripped)
            else:
                result.append(line)
        return "".join(result)

    @staticmethod
    def _detect_return_usage(source: str, call_line: int, func_name: str) -> list[str]:
        """Detect if the call's return value is used."""
        lines = source.splitlines()
        if call_line < 1 or call_line > len(lines):
            return []
        line = lines[call_line - 1]
        # Check for assignment pattern: var = func(...)
        m = re.match(r"\s*(.+?)\s*=\s*" + re.escape(func_name), line)
        if m:
            lhs = m.group(1).strip()
            if "," in lhs:
                return [v.strip() for v in lhs.split(",")]
            return [lhs]
        return []

    @staticmethod
    def _wrap_return(body: str, return_vars: list[str], indent: int) -> str:
        """Wrap the body to capture return values."""
        # For Python, replace `return expr` with assignment
        # This is a simplified approach
        return body
