"""Cyclomatic and cognitive complexity analysis.

Measures code complexity at the function, class, and file level using
AST-based analysis where available and regex fallback otherwise.
"""

from __future__ import annotations

import logging
import re
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser
from .symbol_extractor import Symbol, SymbolExtractor

logger = logging.getLogger(__name__)

# Decision points that increase cyclomatic complexity
_DECISION_KEYWORDS = {
    ".py": {"if", "elif", "for", "while", "except", "with", "assert", "and", "or"},
    ".js": {"if", "else if", "for", "while", "catch", "switch", "case", "&&", "||", "?"},
    ".ts": {"if", "else if", "for", "while", "catch", "switch", "case", "&&", "||", "?"},
    ".go": {"if", "for", "switch", "case", "select", "&&", "||"},
    ".rs": {"if", "for", "while", "match", "loop", "&&", "||", "?"},
    ".java": {"if", "else if", "for", "while", "catch", "switch", "case", "&&", "||", "?"},
    ".c": {"if", "else if", "for", "while", "switch", "case", "&&", "||", "?"},
    ".cpp": {"if", "else if", "for", "while", "switch", "case", "catch", "&&", "||", "?"},
    ".rb": {"if", "elsif", "unless", "while", "until", "when", "rescue", "&&", "||"},
    ".php": {"if", "elseif", "for", "foreach", "while", "catch", "switch", "case", "&&", "||", "?"},
    ".swift": {"if", "for", "while", "guard", "switch", "case", "catch", "&&", "||", "?"},
    ".kt": {"if", "for", "while", "when", "catch", "&&", "||", "?"},
    ".scala": {"if", "for", "while", "match", "catch", "&&", "||", "?"},
    ".lua": {"if", "for", "while", "elseif", "and", "or"},
    ".dart": {"if", "for", "while", "switch", "case", "catch", "&&", "||", "?"},
    ".r": {"if", "for", "while", "&&", "||"},
}


@dataclass
class FunctionComplexity:
    """Complexity metrics for a single function."""

    name: str
    file_path: str
    line: int
    end_line: int
    cyclomatic: int = 1  # Base complexity is 1
    cognitive: int = 0
    lines_of_code: int = 0
    parameters: int = 0
    nesting_depth: int = 0
    maintainability_index: float = 0.0

    @property
    def rank(self) -> str:
        """Return a complexity rank (A-F)."""
        if self.cyclomatic <= 5:
            return "A"
        elif self.cyclomatic <= 10:
            return "B"
        elif self.cyclomatic <= 20:
            return "C"
        elif self.cyclomatic <= 30:
            return "D"
        elif self.cyclomatic <= 40:
            return "E"
        return "F"

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "file_path": self.file_path,
            "line": self.line,
            "end_line": self.end_line,
            "cyclomatic": self.cyclomatic,
            "cognitive": self.cognitive,
            "lines_of_code": self.lines_of_code,
            "parameters": self.parameters,
            "nesting_depth": self.nesting_depth,
            "maintainability_index": round(self.maintainability_index, 1),
            "rank": self.rank,
        }


@dataclass
class FileComplexity:
    """Complexity metrics for a file."""

    file_path: str
    language: str
    total_lines: int = 0
    code_lines: int = 0
    comment_lines: int = 0
    blank_lines: int = 0
    functions: list[FunctionComplexity] = field(default_factory=list)

    @property
    def avg_cyclomatic(self) -> float:
        if not self.functions:
            return 0.0
        return sum(f.cyclomatic for f in self.functions) / len(self.functions)

    @property
    def max_cyclomatic(self) -> int:
        if not self.functions:
            return 0
        return max(f.cyclomatic for f in self.functions)

    def to_dict(self) -> dict[str, Any]:
        return {
            "file_path": self.file_path,
            "language": self.language,
            "total_lines": self.total_lines,
            "code_lines": self.code_lines,
            "comment_lines": self.comment_lines,
            "blank_lines": self.blank_lines,
            "function_count": len(self.functions),
            "avg_cyclomatic": round(self.avg_cyclomatic, 1),
            "max_cyclomatic": self.max_cyclomatic,
            "functions": [f.to_dict() for f in self.functions],
        }


@dataclass
class ComplexityReport:
    """Complexity analysis report for a project."""

    files: list[FileComplexity] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def total_functions(self) -> int:
        return sum(len(f.functions) for f in self.files)

    @property
    def avg_cyclomatic(self) -> float:
        all_funcs = [fn for f in self.files for fn in f.functions]
        if not all_funcs:
            return 0.0
        return sum(fn.cyclomatic for fn in all_funcs) / len(all_funcs)

    @property
    def most_complex(self) -> list[FunctionComplexity]:
        """Return the top 10 most complex functions."""
        all_funcs = [fn for f in self.files for fn in f.functions]
        return sorted(all_funcs, key=lambda f: f.cyclomatic, reverse=True)[:10]

    def summary(self) -> str:
        lines = [
            f"Complexity Report: {len(self.files)} file(s), {self.total_functions} function(s)",
            f"Average cyclomatic complexity: {self.avg_cyclomatic:.1f}",
        ]
        most = self.most_complex
        if most:
            lines.append("Most complex functions:")
            for fn in most:
                lines.append(f"  {fn.name} ({fn.file_path}:{fn.line}): {fn.cyclomatic} [{fn.rank}]")
        return "\n".join(lines)


class ComplexityAnalyzer:
    """Analyze code complexity.

    Usage::

        analyzer = ComplexityAnalyzer()

        # Analyze a single file
        result = analyzer.analyze_file(Path("main.py"))

        # Analyze a directory
        report = analyzer.analyze_directory(Path("src/"))

        # Get most complex functions
        for fn in report.most_complex:
            print(f"{fn.name}: {fn.cyclomatic} [{fn.rank}]")
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()
        self._extractor = SymbolExtractor(self._parser)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze_file(self, path: Path) -> FileComplexity:
        """Analyze complexity of a single file."""
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as exc:
            return FileComplexity(file_path=str(path), language="unknown")

        ext = path.suffix.lower()
        language = self._detect_language(ext)

        # Count lines
        lines = source.splitlines()
        total_lines = len(lines)
        blank_lines = sum(1 for l in lines if not l.strip())
        comment_lines = self._count_comment_lines(lines, ext)
        code_lines = total_lines - blank_lines - comment_lines

        # Extract functions and compute complexity
        functions = self._analyze_functions(source, path, ext)

        return FileComplexity(
            file_path=str(path),
            language=language,
            total_lines=total_lines,
            code_lines=code_lines,
            comment_lines=comment_lines,
            blank_lines=blank_lines,
            functions=functions,
        )

    def analyze_directory(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        max_files: int = 5000,
    ) -> ComplexityReport:
        """Analyze complexity of all files in *directory*."""
        if extensions is None:
            extensions = {".py", ".js", ".ts", ".go", ".rs", ".java", ".c", ".cpp",
                         ".rb", ".php", ".swift", ".kt", ".scala", ".lua", ".dart"}
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

        files: list[FileComplexity] = []
        errors: list[str] = []
        count = 0

        for path in sorted(directory.rglob("*")):
            if count >= max_files:
                break
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue
            count += 1
            files.append(self.analyze_file(path))

        return ComplexityReport(files=files, errors=errors)

    def analyze_function(self, source: str, func: Symbol, language: str) -> FunctionComplexity:
        """Analyze complexity of a single function."""
        ext = f".{language}" if not language.startswith(".") else language
        return self._compute_complexity(source, func, ext)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _analyze_functions(self, source: str, path: Path, ext: str) -> list[FunctionComplexity]:
        """Extract functions and compute their complexity."""
        symbols = self._extractor.extract_from_file(path)
        functions = [s for s in symbols if s.kind in ("function", "method")]

        results = []
        for func in functions:
            fc = self._compute_complexity(source, func, ext)
            results.append(fc)

        return results

    def _compute_complexity(self, source: str, func: Symbol, ext: str) -> FunctionComplexity:
        """Compute cyclomatic and cognitive complexity for a function."""
        lines = source.splitlines()
        start = max(0, func.line - 1)
        end = min(len(lines), func.end_line if func.end_line > func.line else func.line + 50)

        func_lines = lines[start:end]
        func_source = "\n".join(func_lines)

        # Cyclomatic complexity
        cyclomatic = self._cyclomatic_complexity(func_source, ext)

        # Cognitive complexity
        cognitive = self._cognitive_complexity(func_source, ext)

        # Nesting depth
        nesting = self._max_nesting(func_source, ext)

        # Lines of code (non-blank, non-comment)
        loc = sum(1 for l in func_lines if l.strip() and not self._is_comment(l.strip(), ext))

        # Maintainability index (simplified Halstead-based)
        mi = self._maintainability_index(cyclomatic, loc, len(func.params))

        return FunctionComplexity(
            name=func.name,
            file_path=func.file_path,
            line=func.line,
            end_line=func.end_line,
            cyclomatic=cyclomatic,
            cognitive=cognitive,
            lines_of_code=loc,
            parameters=len(func.params),
            nesting_depth=nesting,
            maintainability_index=mi,
        )

    @staticmethod
    def _cyclomatic_complexity(source: str, ext: str) -> int:
        """Compute cyclomatic complexity.

        CC = 1 + number of decision points.
        """
        keywords = _DECISION_KEYWORDS.get(ext, _DECISION_KEYWORDS.get(".py", set()))
        cc = 1

        for kw in keywords:
            if len(kw) <= 2:
                # Operators like &&, ||, ?, and, or
                cc += source.count(kw)
            else:
                # Keywords
                pattern = r"\b" + re.escape(kw) + r"\b"
                cc += len(re.findall(pattern, source))

        # Subtract the function def line
        cc = max(1, cc)
        return cc

    @staticmethod
    def _cognitive_complexity(source: str, ext: str) -> int:
        """Compute cognitive complexity (simplified).

        Cognitive complexity increments for:
        - Control flow breaks (if, for, while, etc.)
        - Nesting level adds weight
        - Each additional boolean operator
        """
        lines = source.splitlines()
        complexity = 0
        nesting = 0

        control_keywords = {"if", "elif", "else if", "elsif", "elseif", "for", "while",
                          "do", "switch", "match", "catch", "except", "guard", "when"}
        increment_keywords = {"else", "default", "finally", "rescue"}

        for line in lines:
            stripped = line.strip()
            if not stripped or ComplexityAnalyzer._is_comment(stripped, ext):
                continue

            # Track nesting
            indent = len(line) - len(line.lstrip())

            for kw in control_keywords:
                if re.match(r"\b" + re.escape(kw) + r"\b", stripped):
                    complexity += 1 + nesting
                    nesting += 1
                    break

            for kw in increment_keywords:
                if re.match(r"\b" + re.escape(kw) + r"\b", stripped):
                    complexity += 1
                    break

            # Boolean operators
            complexity += stripped.count("&&") + stripped.count("||")
            complexity += len(re.findall(r"\b(and|or)\b", stripped))

        return max(0, complexity)

    @staticmethod
    def _max_nesting(source: str, ext: str) -> int:
        """Compute maximum nesting depth."""
        max_depth = 0
        current_depth = 0

        for line in source.splitlines():
            stripped = line.strip()
            if not stripped:
                continue

            # Simple heuristic: count leading spaces relative to function
            indent = len(line) - len(line.lstrip())
            depth = indent // 4  # Assume 4-space indent
            max_depth = max(max_depth, depth)

        return max_depth

    @staticmethod
    def _maintainability_index(cc: int, loc: int, params: int) -> float:
        """Compute a simplified maintainability index (0-100).

        MI = max(0, 171 - 5.2 * ln(HalsteadVolume) - 0.23 * CC - 16.2 * ln(LOC))
        Simplified: MI = max(0, 100 - CC * 3 - params * 2 - max(0, loc - 50) * 0.1)
        """
        mi = 100.0 - cc * 3.0 - params * 2.0 - max(0, loc - 50) * 0.1
        return max(0.0, min(100.0, mi))

    @staticmethod
    def _is_comment(line: str, ext: str) -> bool:
        """Check if a line is a comment."""
        if ext in (".py", ".rb", ".r", ".R", ".lua"):
            return line.startswith("#")
        if ext in (".js", ".ts", ".jsx", ".tsx", ".java", ".c", ".cpp", ".go", ".rs", ".swift", ".kt", ".scala", ".dart", ".php"):
            return line.startswith("//") or line.startswith("/*") or line.startswith("*")
        return False

    @staticmethod
    def _count_comment_lines(lines: list[str], ext: str) -> int:
        """Count comment lines in a file."""
        count = 0
        in_block = False
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            if ext in (".py", ".rb", ".r", ".R", ".lua"):
                if stripped.startswith("#"):
                    count += 1
            elif ext in (".js", ".ts", ".java", ".c", ".cpp", ".go", ".rs", ".swift", ".kt", ".scala", ".dart", ".php"):
                if in_block:
                    count += 1
                    if "*/" in stripped:
                        in_block = False
                elif stripped.startswith("//"):
                    count += 1
                elif stripped.startswith("/*"):
                    count += 1
                    if "*/" not in stripped:
                        in_block = True
        return count

    @staticmethod
    def _detect_language(ext: str) -> str:
        """Detect language from file extension."""
        _ext_map = {
            ".py": "python", ".pyi": "python", ".js": "javascript", ".jsx": "javascript",
            ".mjs": "javascript", ".ts": "typescript", ".tsx": "typescript",
            ".go": "go", ".rs": "rust", ".java": "java", ".c": "c", ".h": "c",
            ".cpp": "cpp", ".cxx": "cpp", ".cc": "cpp", ".hpp": "cpp",
            ".cs": "csharp", ".rb": "ruby", ".php": "php", ".swift": "swift",
            ".kt": "kotlin", ".scala": "scala", ".hs": "haskell", ".lua": "lua",
            ".zig": "zig", ".dart": "dart", ".r": "r", ".R": "r",
        }
        return _ext_map.get(ext, "unknown")
