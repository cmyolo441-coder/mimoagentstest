"""Call graph generation.

Builds a directed graph of function call relationships within and
across files, supporting both intra-file and inter-file analysis.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser
from .symbol_extractor import Symbol, SymbolExtractor

logger = logging.getLogger(__name__)


@dataclass
class CallEdge:
    """An edge in the call graph (caller -> callee)."""

    caller: str  # Fully qualified name
    callee: str  # Fully qualified name
    file_path: str
    line: int
    callee_file: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "caller": self.caller,
            "callee": self.callee,
            "file_path": self.file_path,
            "line": self.line,
            "callee_file": self.callee_file,
        }


@dataclass
class FunctionNode:
    """A node in the call graph."""

    name: str
    file_path: str
    line: int
    callers: list[str] = field(default_factory=list)  # Functions that call this
    callees: list[str] = field(default_factory=list)   # Functions this calls

    @property
    def in_degree(self) -> int:
        return len(self.callers)

    @property
    def out_degree(self) -> int:
        return len(self.callees)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "file_path": self.file_path,
            "line": self.line,
            "callers": self.callers,
            "callees": self.callees,
            "in_degree": self.in_degree,
            "out_degree": self.out_degree,
        }


@dataclass
class CallGraph:
    """A directed call graph for a codebase."""

    nodes: dict[str, FunctionNode] = field(default_factory=dict)
    edges: list[CallEdge] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def function_count(self) -> int:
        return len(self.nodes)

    @property
    def call_count(self) -> int:
        return len(self.edges)

    def get_node(self, name: str) -> FunctionNode | None:
        return self.nodes.get(name)

    def get_callers(self, name: str) -> list[FunctionNode]:
        """Return all functions that call *name*."""
        node = self.nodes.get(name)
        if not node:
            return []
        return [self.nodes[c] for c in node.callers if c in self.nodes]

    def get_callees(self, name: str) -> list[FunctionNode]:
        """Return all functions called by *name*."""
        node = self.nodes.get(name)
        if not node:
            return []
        return [self.nodes[c] for c in node.callees if c in self.nodes]

    def get_roots(self) -> list[FunctionNode]:
        """Return functions with no callers (entry points)."""
        return [n for n in self.nodes.values() if n.in_degree == 0]

    def get_leaves(self) -> list[FunctionNode]:
        """Return functions with no callees (leaf functions)."""
        return [n for n in self.nodes.values() if n.out_degree == 0]

    def get_cycles(self) -> list[list[str]]:
        """Find cycles in the call graph (mutual recursion)."""
        cycles: list[list[str]] = []
        visited: set[str] = set()
        rec_stack: set[str] = set()
        path: list[str] = []

        def dfs(node_name: str) -> None:
            visited.add(node_name)
            rec_stack.add(node_name)
            path.append(node_name)

            node = self.nodes.get(node_name)
            if node:
                for callee in node.callees:
                    if callee not in visited:
                        dfs(callee)
                    elif callee in rec_stack:
                        # Found a cycle
                        cycle_start = path.index(callee)
                        cycles.append(list(path[cycle_start:]) + [callee])

            path.pop()
            rec_stack.discard(node_name)

        for name in self.nodes:
            if name not in visited:
                dfs(name)

        return cycles

    def to_mermaid(self) -> str:
        """Generate a Mermaid diagram of the call graph."""
        lines = ["graph TD"]
        # Simplify names for display
        name_map: dict[str, str] = {}
        for i, name in enumerate(self.nodes):
            short = name.split(".")[-1]
            node_id = f"f{i}"
            name_map[name] = node_id
            lines.append(f"    {node_id}[\"{short}\"]")

        for edge in self.edges:
            caller_id = name_map.get(edge.caller, edge.caller)
            callee_id = name_map.get(edge.callee, edge.callee)
            lines.append(f"    {caller_id} --> {callee_id}")

        return "\n".join(lines)

    def to_dot(self) -> str:
        """Generate a Graphviz DOT representation."""
        lines = ["digraph call_graph {", '  rankdir=LR;', '  node [shape=box];']

        for name, node in self.nodes.items():
            short = name.split(".")[-1]
            lines.append(f'  "{name}" [label="{short}"];')

        for edge in self.edges:
            lines.append(f'  "{edge.caller}" -> "{edge.callee}";')

        lines.append("}")
        return "\n".join(lines)

    def summary(self) -> str:
        lines = [
            f"Call Graph: {self.function_count} functions, {self.call_count} calls",
        ]
        roots = self.get_roots()
        if roots:
            lines.append(f"Entry points ({len(roots)}):")
            for r in roots[:10]:
                lines.append(f"  {r.name} ({r.file_path}:{r.line})")
        leaves = self.get_leaves()
        if leaves:
            lines.append(f"Leaf functions ({len(leaves)}):")
            for l in leaves[:10]:
                lines.append(f"  {l.name} ({l.file_path}:{l.line})")
        return "\n".join(lines)


class CallGraphBuilder:
    """Build call graphs for a codebase.

    Usage::

        builder = CallGraphBuilder()

        # Build for a single file
        graph = builder.build_for_file(Path("main.py"))

        # Build for a directory
        graph = builder.build_for_directory(Path("src/"))

        # Query
        callers = graph.get_callers("my_function")
        roots = graph.get_roots()
        print(graph.to_mermaid())
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()
        self._extractor = SymbolExtractor(self._parser)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build_for_file(self, path: Path) -> CallGraph:
        """Build a call graph for a single file."""
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as exc:
            return CallGraph(errors=[str(exc)])

        symbols = self._extractor.extract_from_file(path)
        return self._build_graph(source, symbols, str(path))

    def build_for_directory(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
    ) -> CallGraph:
        """Build a call graph for all files in *directory*."""
        symbols = self._extractor.extract_from_directory(
            directory, extensions=extensions, exclude_patterns=exclude_patterns
        )

        # Read all source files
        sources: dict[str, str] = {}
        for sym in symbols:
            if sym.file_path not in sources:
                try:
                    sources[sym.file_path] = Path(sym.file_path).read_text(encoding="utf-8", errors="replace")
                except (OSError, UnicodeDecodeError):
                    pass

        # Build graph from all symbols
        graph = CallGraph()

        # Register all functions as nodes
        functions = [s for s in symbols if s.kind in ("function", "method")]
        for func in functions:
            qname = func.qualified_name
            graph.nodes[qname] = FunctionNode(
                name=qname,
                file_path=func.file_path,
                line=func.line,
            )

        # Find call edges
        for func in functions:
            source = sources.get(func.file_path, "")
            callees = self._find_callees_in_function(source, func, functions)

            qname = func.qualified_name
            for callee_name, call_line in callees:
                # Find the callee node
                callee_node = None
                for f in functions:
                    if f.name == callee_name or f.qualified_name == callee_name:
                        callee_node = f
                        break

                if callee_node:
                    callee_qname = callee_node.qualified_name
                    edge = CallEdge(
                        caller=qname,
                        callee=callee_qname,
                        file_path=func.file_path,
                        line=call_line,
                        callee_file=callee_node.file_path,
                    )
                    graph.edges.append(edge)

                    # Update node connections
                    if qname in graph.nodes:
                        graph.nodes[qname].callees.append(callee_qname)
                    if callee_qname in graph.nodes:
                        graph.nodes[callee_qname].callers.append(qname)

        return graph

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _build_graph(self, source: str, symbols: list[Symbol], file_path: str) -> CallGraph:
        """Build a call graph from symbols in a single file."""
        graph = CallGraph()
        functions = [s for s in symbols if s.kind in ("function", "method")]

        # Register nodes
        for func in functions:
            graph.nodes[func.name] = FunctionNode(
                name=func.name,
                file_path=file_path,
                line=func.line,
            )

        # Find edges
        for func in functions:
            callees = self._find_callees_in_function(source, func, functions)
            for callee_name, call_line in callees:
                edge = CallEdge(
                    caller=func.name,
                    callee=callee_name,
                    file_path=file_path,
                    line=call_line,
                )
                graph.edges.append(edge)

                if func.name in graph.nodes:
                    graph.nodes[func.name].callees.append(callee_name)
                if callee_name in graph.nodes:
                    graph.nodes[callee_name].callers.append(func.name)

        return graph

    @staticmethod
    def _find_callees_in_function(
        source: str,
        func: Symbol,
        all_functions: list[Symbol],
    ) -> list[tuple[str, int]]:
        """Find functions called within *func*'s body.

        Returns:
            List of (callee_name, call_line) tuples.
        """
        lines = source.splitlines()
        start = max(0, func.line)
        end = min(len(lines), func.end_line if func.end_line > func.line else func.line + 100)

        func_names = {f.name for f in all_functions}
        callees: list[tuple[str, int]] = []

        for i in range(start, end):
            line = lines[i]
            # Find function calls: name(...)
            for m in re.finditer(r"\b(\w+)\s*\(", line):
                name = m.group(1)
                if name in func_names and name != func.name:
                    callees.append((name, i + 1))

        return callees
