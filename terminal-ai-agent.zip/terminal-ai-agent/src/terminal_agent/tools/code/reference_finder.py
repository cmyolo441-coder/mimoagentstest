"""Find all references to a symbol across files.

Supports searching for references to functions, classes, variables, and
other symbols across an entire project tree, with language-aware analysis.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .ast_parser import ASTParser
from .symbol_extractor import Symbol, SymbolExtractor

logger = logging.getLogger(__name__)


@dataclass
class Reference:
    """A reference to a symbol in source code."""

    symbol_name: str
    file_path: str
    line: int
    col: int
    end_line: int = 0
    end_col: int = 0
    context: str = ""  # "name", "definition", "attribute", "import", "parameter"
    source_line: str = ""  # The actual source line for display

    def to_dict(self) -> dict[str, Any]:
        return {
            "symbol_name": self.symbol_name,
            "file_path": self.file_path,
            "line": self.line,
            "col": self.col,
            "end_line": self.end_line,
            "end_col": self.end_col,
            "context": self.context,
            "source_line": self.source_line,
        }


class ReferenceFinder:
    """Find all references to symbols across a codebase.

    Usage::

        finder = ReferenceFinder()

        # Find all references to "my_function" in a directory
        refs = finder.find_references(Path("src/"), "my_function")

        # Find references for a specific symbol object
        symbols = SymbolExtractor().extract_from_file(Path("main.py"))
        main_fn = next(s for s in symbols if s.name == "main")
        refs = finder.find_references_for_symbol(Path("src/"), main_fn)
    """

    def __init__(self, parser: ASTParser | None = None) -> None:
        self._parser = parser or ASTParser()
        self._extractor = SymbolExtractor(self._parser)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def find_references(
        self,
        directory: Path,
        symbol_name: str,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        definition_file: Path | None = None,
        max_files: int = 10_000,
    ) -> list[Reference]:
        """Find all references to *symbol_name* in *directory*.

        Parameters:
            directory: Root directory to search.
            symbol_name: The symbol name to find.
            extensions: File extensions to search. *None* = all supported.
            exclude_patterns: Path substrings to skip.
            definition_file: If provided, the definition location is tagged.
            max_files: Maximum number of files to process.

        Returns:
            A list of :class:`Reference` objects sorted by file and line.
        """
        if extensions is None:
            extensions = self._parser.supported_extensions()
        if exclude_patterns is None:
            exclude_patterns = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

        references: list[Reference] = []
        count = 0

        for path in sorted(directory.rglob("*")):
            if count >= max_files:
                break
            if not path.is_file():
                continue
            if path.suffix.lower() not in extensions:
                continue
            if any(pat in str(path) for pat in exclude_patterns):
                continue
            count += 1

            file_refs = self._find_in_file(path, symbol_name)
            references.extend(file_refs)

        return sorted(references, key=lambda r: (r.file_path, r.line, r.col))

    def find_references_for_symbol(
        self,
        directory: Path,
        symbol: Symbol,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
    ) -> list[Reference]:
        """Find all references to a specific :class:`Symbol` object.

        This is more precise than :meth:`find_references` because it
        can use the symbol's metadata (kind, file, line) to classify
        references as definitions vs usages.
        """
        refs = self.find_references(
            directory,
            symbol.name,
            extensions=extensions,
            exclude_patterns=exclude_patterns,
            definition_file=Path(symbol.file_path),
        )

        # Tag the definition reference
        for ref in refs:
            if (
                ref.file_path == symbol.file_path
                and ref.line == symbol.line
                and ref.context == "definition"
            ):
                ref.context = "definition"
            elif ref.file_path == symbol.file_path and ref.line == symbol.line:
                ref.context = "definition"

        return refs

    def find_references_in_file(self, path: Path, symbol_name: str) -> list[Reference]:
        """Find references to *symbol_name* in a single file."""
        return self._find_in_file(path, symbol_name)

    # ------------------------------------------------------------------
    # Cross-reference analysis
    # ------------------------------------------------------------------

    def find_unused_symbols(
        self,
        directory: Path,
        *,
        extensions: set[str] | None = None,
        exclude_patterns: set[str] | None = None,
        symbol_kinds: set[str] | None = None,
    ) -> list[Symbol]:
        """Find symbols that are defined but never referenced elsewhere.

        Parameters:
            symbol_kinds: Kinds to check (e.g. ``{"function", "class"}``).
                          *None* = all exportable kinds.
        """
        if symbol_kinds is None:
            symbol_kinds = {"function", "class", "method", "struct", "interface", "trait", "enum", "type_alias"}

        all_symbols = self._extractor.extract_from_directory(
            directory, extensions=extensions, exclude_patterns=exclude_patterns
        )

        # Filter to requested kinds and non-private names
        candidates = [
            s for s in all_symbols
            if s.kind in symbol_kinds and not s.name.startswith("_")
        ]

        unused: list[Symbol] = []
        for sym in candidates:
            refs = self.find_references(
                directory,
                sym.name,
                extensions=extensions,
                exclude_patterns=exclude_patterns,
            )
            # Count non-definition references
            usage_refs = [r for r in refs if r.context != "definition"]
            if not usage_refs:
                unused.append(sym)

        return unused

    def get_callers(
        self,
        directory: Path,
        function_name: str,
        *,
        extensions: set[str] | None = None,
    ) -> list[Reference]:
        """Find all call sites of *function_name*.

        Returns references where the symbol appears in a call context.
        """
        refs = self.find_references(directory, function_name, extensions=extensions)
        # Filter to non-definition references (approximation of call sites)
        return [r for r in refs if r.context not in ("definition", "import")]

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _find_in_file(self, path: Path, symbol_name: str) -> list[Reference]:
        """Find references to *symbol_name* in a single file."""
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            return []

        raw_refs = self._parser.find_references_in_source(source, symbol_name, path=path)
        lines = source.splitlines()

        references = []
        for raw in raw_refs:
            line_num = raw.get("line", 0)
            source_line = ""
            if 0 < line_num <= len(lines):
                source_line = lines[line_num - 1].strip()

            references.append(Reference(
                symbol_name=symbol_name,
                file_path=str(path),
                line=line_num,
                col=raw.get("col", 0),
                end_line=raw.get("end_line", line_num),
                end_col=raw.get("end_col", 0),
                context=raw.get("context", "name"),
                source_line=source_line,
            ))

        return references
