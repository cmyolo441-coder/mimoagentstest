"""Base tool class for all Terminal Agent tools.

Every tool in the system inherits from BaseTool, which provides
parameter validation, execution lifecycle, safety hooks, and
consistent result formatting.
"""

from __future__ import annotations

import abc
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

from terminal_agent.exceptions import ToolExecutionError, ToolTimeoutError, ToolValidationError
from terminal_agent.types import ToolCall, ToolResult, ToolResultStatus

logger = logging.getLogger(__name__)


class SafetyRequirement(str, Enum):
    """Safety requirements for tool execution."""
    NONE = "none"              # Safe, no confirmation needed
    LOW = "low"                # Minor side effects, logged
    MEDIUM = "medium"          # File modifications, may need confirmation
    HIGH = "high"              # Destructive operations, always confirm
    CRITICAL = "critical"      # System-level changes, double confirmation


@dataclass
class ToolParameter:
    """Definition of a tool parameter."""
    name: str
    type: str  # "string", "integer", "float", "boolean", "array", "object"
    description: str
    required: bool = True
    default: Any = None
    enum: list[str] | None = None
    min_value: float | None = None
    max_value: float | None = None
    pattern: str | None = None  # regex pattern for validation


@dataclass
class ToolDefinition:
    """Complete definition of a tool for registration."""
    name: str
    description: str
    category: str
    parameters: list[ToolParameter] = field(default_factory=list)
    safety_requirement: SafetyRequirement = SafetyRequirement.NONE
    timeout_seconds: float = 300.0
    requires_confirmation: bool = False
    idempotent: bool = True
    side_effects: list[str] = field(default_factory=list)
    examples: list[dict[str, Any]] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)


class BaseTool(abc.ABC):
    """Abstract base class for all tools.

    Subclasses must implement:
    - definition() -> ToolDefinition
    - execute(**kwargs) -> ToolResult

    Optional overrides:
    - validate_parameters(**kwargs) -> None (raise on invalid)
    - pre_execute(**kwargs) -> dict (transform params)
    - post_execute(result: ToolResult) -> ToolResult (transform result)
    - cleanup() -> None (called after execution, even on error)
    """

    def __init__(self) -> None:
        self._execution_count: int = 0
        self._total_duration_ms: float = 0.0
        self._error_count: int = 0

    @abc.abstractmethod
    def definition(self) -> ToolDefinition:
        """Return the tool definition for registration."""
        ...

    @abc.abstractmethod
    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool with validated parameters."""
        ...

    def validate_parameters(self, **kwargs: Any) -> None:
        """Validate parameters beyond schema checks.

        Raises ToolValidationError on invalid parameters.
        """
        defn = self.definition()
        for param in defn.parameters:
            if param.required and param.name not in kwargs:
                raise ToolValidationError(
                    f"Missing required parameter: {param.name}",
                    details={"parameter": param.name, "tool": defn.name},
                )
            if param.name in kwargs:
                value = kwargs[param.name]
                if param.enum and value not in param.enum:
                    raise ToolValidationError(
                        f"Parameter '{param.name}' must be one of {param.enum}, got: {value}",
                        details={"parameter": param.name, "value": value, "allowed": param.enum},
                    )
                if param.type == "integer" and not isinstance(value, int):
                    try:
                        kwargs[param.name] = int(value)
                    except (ValueError, TypeError):
                        raise ToolValidationError(
                            f"Parameter '{param.name}' must be an integer",
                            details={"parameter": param.name, "value": value},
                        )
                if param.type == "float" and not isinstance(value, (int, float)):
                    try:
                        kwargs[param.name] = float(value)
                    except (ValueError, TypeError):
                        raise ToolValidationError(
                            f"Parameter '{param.name}' must be a number",
                            details={"parameter": param.name, "value": value},
                        )
                if param.type == "boolean" and not isinstance(value, bool):
                    if isinstance(value, str):
                        kwargs[param.name] = value.lower() in ("true", "1", "yes")
                    else:
                        kwargs[param.name] = bool(value)

    def pre_execute(self, **kwargs: Any) -> dict[str, Any]:
        """Transform parameters before execution.

        Returns the (possibly modified) parameters dict.
        """
        return kwargs

    def post_execute(self, result: ToolResult) -> ToolResult:
        """Transform the result after execution.

        Default implementation adds timing metadata.
        """
        result.metadata["tool_name"] = self.definition().name
        result.metadata["execution_count"] = self._execution_count
        return result

    def cleanup(self) -> None:
        """Called after execution completes (success or failure).

        Override to release resources, close connections, etc.
        """

    async def run(self, **kwargs: Any) -> ToolResult:
        """Full execution lifecycle: validate -> pre -> execute -> post -> cleanup.

        This is the main entry point called by the dispatcher.
        """
        defn = self.definition()
        start_time = time.monotonic()

        try:
            # Apply defaults
            for param in defn.parameters:
                if param.name not in kwargs and param.default is not None:
                    kwargs[param.name] = param.default

            # Validate
            self.validate_parameters(**kwargs)

            # Pre-execute transform
            kwargs = self.pre_execute(**kwargs)

            # Execute
            result = await self.execute(**kwargs)

            # Post-execute transform
            result = self.post_execute(result)

            # Track metrics
            duration_ms = (time.monotonic() - start_time) * 1000
            result.duration_ms = duration_ms
            self._execution_count += 1
            self._total_duration_ms += duration_ms

            if result.status in (ToolResultStatus.ERROR, ToolResultStatus.FAILURE):
                self._error_count += 1

            logger.info(
                "Tool %s executed: status=%s duration=%.1fms",
                defn.name, result.status.value, duration_ms,
            )
            return result

        except ToolValidationError:
            raise
        except ToolTimeoutError:
            self._error_count += 1
            raise
        except Exception as exc:
            self._error_count += 1
            duration_ms = (time.monotonic() - start_time) * 1000
            logger.error("Tool %s failed: %s", defn.name, exc, exc_info=True)
            return ToolResult(
                status=ToolResultStatus.ERROR,
                error=str(exc),
                exit_code=1,
                duration_ms=duration_ms,
                metadata={"tool_name": defn.name, "error_type": type(exc).__name__},
            )
        finally:
            self.cleanup()

    @property
    def stats(self) -> dict[str, Any]:
        """Return execution statistics for this tool."""
        return {
            "name": self.definition().name,
            "execution_count": self._execution_count,
            "error_count": self._error_count,
            "total_duration_ms": self._total_duration_ms,
            "avg_duration_ms": (
                self._total_duration_ms / self._execution_count
                if self._execution_count > 0
                else 0.0
            ),
            "success_rate": (
                (self._execution_count - self._error_count) / self._execution_count
                if self._execution_count > 0
                else 0.0
            ),
        }

    def to_openai_function(self) -> dict[str, Any]:
        """Convert this tool to an OpenAI function-calling schema."""
        defn = self.definition()
        properties = {}
        required = []
        for param in defn.parameters:
            prop: dict[str, Any] = {"type": param.type, "description": param.description}
            if param.enum:
                prop["enum"] = param.enum
            if param.default is not None:
                prop["default"] = param.default
            properties[param.name] = prop
            if param.required:
                required.append(param.name)

        return {
            "type": "function",
            "function": {
                "name": defn.name,
                "description": defn.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        }

    def to_anthropic_schema(self) -> dict[str, Any]:
        """Convert this tool to an Anthropic tool-use schema."""
        defn = self.definition()
        properties = {}
        required = []
        for param in defn.parameters:
            prop: dict[str, Any] = {"type": param.type, "description": param.description}
            if param.enum:
                prop["enum"] = param.enum
            if param.default is not None:
                prop["default"] = param.default
            properties[param.name] = prop
            if param.required:
                required.append(param.name)

        return {
            "name": defn.name,
            "description": defn.description,
            "input_schema": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        }
