"""Context manager module — builds and manages the LLM context window.

Handles token counting, context assembly, compression, prioritisation,
and summarisation to fit within model context limits.
"""

from __future__ import annotations

from terminal_agent.context.assembler import ContextAssembler
from terminal_agent.context.compressor import ContextCompressor
from terminal_agent.context.environment import EnvironmentGatherer
from terminal_agent.context.manager import ContextManager
from terminal_agent.context.prioritizer import ContextPrioritizer
from terminal_agent.context.summarizer import ConversationSummarizer
from terminal_agent.context.token_budget import TokenBudget

__all__ = [
    "ContextManager",
    "ContextAssembler",
    "ContextCompressor",
    "ContextPrioritizer",
    "TokenBudget",
    "ConversationSummarizer",
    "EnvironmentGatherer",
]
