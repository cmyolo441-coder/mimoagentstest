"""Environment gatherer — collects system and project environment info.

Gathers information about the current OS, shell, runtime versions,
project type, and working directory for inclusion in context.
"""

from __future__ import annotations

import logging
import os
import platform
import subprocess
import sys
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class EnvironmentInfo:
    """Collected environment information."""
    os_name: str = ""
    os_version: str = ""
    architecture: str = ""
    shell: str = ""
    python_version: str = ""
    working_directory: str = ""
    home_directory: str = ""
    user: str = ""
    node_version: str = ""
    git_branch: str = ""
    git_status: str = ""
    project_type: str = ""
    package_manager: str = ""
    docker_available: bool = False
    extra: dict[str, Any] = field(default_factory=dict)

    def to_context_string(self) -> str:
        """Format as a context string for inclusion in prompts."""
        lines = [
            "ENVIRONMENT:",
            f"  OS: {self.os_name} {self.os_version} ({self.architecture})",
            f"  Shell: {self.shell}",
            f"  Python: {self.python_version}",
            f"  Working dir: {self.working_directory}",
            f"  User: {self.user}",
        ]
        if self.node_version:
            lines.append(f"  Node.js: {self.node_version}")
        if self.git_branch:
            lines.append(f"  Git branch: {self.git_branch}")
        if self.git_status:
            lines.append(f"  Git status: {self.git_status}")
        if self.project_type:
            lines.append(f"  Project type: {self.project_type}")
        if self.package_manager:
            lines.append(f"  Package manager: {self.package_manager}")
        if self.docker_available:
            lines.append("  Docker: available")
        for key, value in self.extra.items():
            lines.append(f"  {key}: {value}")
        return "\n".join(lines)


class EnvironmentGatherer:
    """Collects environment information for context assembly.

    Gathers data lazily and caches results.  Individual gatherers
    can be enabled/disabled to control overhead.
    """

    def __init__(
        self,
        include_git: bool = True,
        include_docker: bool = True,
        include_node: bool = True,
        include_project: bool = True,
    ) -> None:
        self._include_git = include_git
        self._include_docker = include_docker
        self._include_node = include_node
        self._include_project = include_project
        self._cache: EnvironmentInfo | None = None

    def gather(self, force_refresh: bool = False) -> EnvironmentInfo:
        """Gather environment information.

        Args:
            force_refresh: Ignore cache and re-gather.

        Returns:
            An EnvironmentInfo object.
        """
        if self._cache is not None and not force_refresh:
            return self._cache

        info = EnvironmentInfo(
            os_name=platform.system(),
            os_version=platform.release(),
            architecture=platform.machine(),
            shell=os.environ.get("SHELL", os.environ.get("COMSPEC", "unknown")),
            python_version=sys.version.split()[0],
            working_directory=os.getcwd(),
            home_directory=os.path.expanduser("~"),
            user=os.environ.get("USER", os.environ.get("USERNAME", "unknown")),
        )

        if self._include_node:
            info.node_version = self._run_cmd("node --version")

        if self._include_git:
            info.git_branch = self._run_cmd("git rev-parse --abbrev-ref HEAD")
            info.git_status = self._run_cmd("git status --porcelain")
            if info.git_status:
                # Summarise: just count changes
                lines = info.git_status.strip().splitlines()
                info.git_status = f"{len(lines)} changed files"

        if self._include_project:
            info.project_type = self._detect_project_type()
            info.package_manager = self._detect_package_manager()

        if self._include_docker:
            info.docker_available = self._cmd_exists("docker")

        self._cache = info
        return info

    def invalidate_cache(self) -> None:
        """Force re-gathering on next call."""
        self._cache = None

    # ── Private helpers ────────────────────────────────────────────────

    @staticmethod
    def _run_cmd(cmd: str) -> str:
        """Run a command and return stdout (trimmed)."""
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.stdout.strip()
        except Exception:
            return ""

    @staticmethod
    def _cmd_exists(cmd: str) -> bool:
        """Check if a command is available."""
        try:
            result = subprocess.run(
                f"which {cmd}",
                shell=True,
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.returncode == 0
        except Exception:
            return False

    @staticmethod
    def _detect_project_type() -> str:
        """Detect the project type from files in cwd."""
        markers = {
            "package.json": "node.js",
            "requirements.txt": "python",
            "setup.py": "python",
            "pyproject.toml": "python",
            "Cargo.toml": "rust",
            "go.mod": "go",
            "pom.xml": "java-maven",
            "build.gradle": "java-gradle",
            "Gemfile": "ruby",
            "composer.json": "php",
            "pubspec.yaml": "dart",
            "mix.exs": "elixir",
        }
        for marker, ptype in markers.items():
            if os.path.isfile(marker):
                return ptype
        return ""

    @staticmethod
    def _detect_package_manager() -> str:
        """Detect the package manager."""
        lock_files = {
            "package-lock.json": "npm",
            "yarn.lock": "yarn",
            "pnpm-lock.yaml": "pnpm",
            "bun.lockb": "bun",
            "Pipfile.lock": "pipenv",
            "poetry.lock": "poetry",
            "Cargo.lock": "cargo",
            "go.sum": "go",
            "Gemfile.lock": "bundler",
            "composer.lock": "composer",
        }
        for lock, mgr in lock_files.items():
            if os.path.isfile(lock):
                return mgr
        return ""
