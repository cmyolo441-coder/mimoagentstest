"""Token budget — manages token allocation across context components.

Divides the available context window into budgets for different
components (system prompt, plan, memory, history, etc.) and tracks
usage to prevent exceeding the model's limit.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


# Default context sizes per model family (tokens)
_MODEL_CONTEXT_SIZES: dict[str, int] = {
    "gpt-4o": 128_000,
    "gpt-4-turbo": 128_000,
    "gpt-4": 8_192,
    "gpt-3.5-turbo": 16_385,
    "claude-opus": 200_000,
    "claude-sonnet": 200_000,
    "claude-haiku": 200_000,
    "gemini-pro": 1_000_000,
    "gemini-flash": 1_000_000,
    "llama": 8_192,
    "mistral": 32_768,
    "deepseek": 65_536,
    "default": 8_192,
}


@dataclass
class BudgetAllocation:
    """Token budget allocation for a context component."""
    name: str
    allocated: int
    used: int = 0
    priority: int = 5  # 1 = highest, 10 = lowest

    @property
    def remaining(self) -> int:
        return max(0, self.allocated - self.used)

    @property
    def utilization(self) -> float:
        return (self.used / self.allocated * 100) if self.allocated > 0 else 0.0


class TokenBudget:
    """Manages token budget allocation across context components.

    The budget is divided among components based on priority and
    configurable ratios.  Components can borrow unused tokens from
    lower-priority allocations.
    """

    # Default allocation ratios (must sum to ~1.0, leaving headroom)
    DEFAULT_RATIOS: dict[str, float] = {
        "system_prompt": 0.15,
        "goal_and_plan": 0.10,
        "conversation_history": 0.25,
        "working_memory": 0.15,
        "long_term_memory": 0.10,
        "tool_results": 0.15,
        "environment": 0.05,
        "headroom": 0.05,
    }

    # Priority ordering (lower = higher priority)
    PRIORITIES: dict[str, int] = {
        "system_prompt": 1,
        "goal_and_plan": 2,
        "tool_results": 3,
        "conversation_history": 4,
        "working_memory": 5,
        "long_term_memory": 6,
        "environment": 7,
        "headroom": 10,
    }

    def __init__(
        self,
        model: str = "default",
        max_tokens: int | None = None,
        reserve_for_response: int = 4096,
        ratios: dict[str, float] | None = None,
    ) -> None:
        """
        Args:
            model: Model name (used to look up context size).
            max_tokens: Override for total context window size.
            reserve_for_response: Tokens to reserve for the LLM response.
            ratios: Custom allocation ratios (overrides defaults).
        """
        self._model = model
        self._total = max_tokens or self._resolve_context_size(model)
        self._reserve = reserve_for_response
        self._available = self._total - self._reserve
        self._ratios = ratios or dict(self.DEFAULT_RATIOS)

        self._allocations: dict[str, BudgetAllocation] = {}
        self._setup_allocations()

    @property
    def total_tokens(self) -> int:
        """Total context window size."""
        return self._total

    @property
    def available_tokens(self) -> int:
        """Tokens available for context (total minus response reserve)."""
        return self._available

    @property
    def used_tokens(self) -> int:
        """Total tokens currently used across all components."""
        return sum(a.used for a in self._allocations.values())

    @property
    def remaining_tokens(self) -> int:
        """Tokens still available."""
        return max(0, self._available - self.used_tokens)

    @property
    def utilization(self) -> float:
        """Overall utilisation as a percentage."""
        return (self.used_tokens / self._available * 100) if self._available > 0 else 0.0

    def get_allocation(self, name: str) -> BudgetAllocation | None:
        """Get the budget allocation for a component."""
        return self._allocations.get(name)

    def get_all_allocations(self) -> dict[str, BudgetAllocation]:
        """Get all budget allocations."""
        return dict(self._allocations)

    def record_usage(self, component: str, tokens: int) -> bool:
        """Record token usage for a component.

        Args:
            component: The component name.
            tokens: Number of tokens used.

        Returns:
            True if the usage fits within the budget, False if it would
            exceed the allocation (usage is still recorded).
        """
        alloc = self._allocations.get(component)
        if alloc is None:
            logger.warning("Unknown budget component: %s", component)
            return False

        alloc.used = tokens
        fits = tokens <= alloc.allocated

        if not fits:
            logger.debug(
                "Component %s exceeds budget: %d > %d tokens",
                component, tokens, alloc.allocated,
            )
        return fits

    def can_fit(self, component: str, tokens: int) -> bool:
        """Check if a component can fit the given tokens."""
        alloc = self._allocations.get(component)
        if alloc is None:
            return False
        return tokens <= alloc.remaining

    def borrow_tokens(self, component: str, tokens: int) -> int:
        """Borrow unused tokens from lower-priority components.

        Args:
            component: The component needing more tokens.
            tokens: How many tokens are needed.

        Returns:
            The number of tokens actually made available.
        """
        target = self._allocations.get(component)
        if target is None:
            return 0

        needed = tokens - target.remaining
        if needed <= 0:
            return tokens

        # Find lower-priority allocations with spare capacity
        donors = sorted(
            [
                a for a in self._allocations.values()
                if a.name != component and a.priority > target.priority
            ],
            key=lambda a: a.priority,
            reverse=True,  # lowest priority first
        )

        borrowed = 0
        for donor in donors:
            spare = donor.remaining
            if spare <= 0:
                continue
            take = min(spare, needed - borrowed)
            donor.allocated -= take
            target.allocated += take
            borrowed += take
            if borrowed >= needed:
                break

        return borrowed

    def reset(self) -> None:
        """Reset all usage counters to zero."""
        for alloc in self._allocations.values():
            alloc.used = 0

    def summary(self) -> str:
        """Human-readable budget summary."""
        lines = [
            f"Token Budget ({self._model}): {self.used_tokens}/{self._available} "
            f"({self.utilization:.1f}%)",
        ]
        for name, alloc in sorted(
            self._allocations.items(), key=lambda x: x[1].priority,
        ):
            bar_len = 20
            filled = int(bar_len * alloc.utilization / 100)
            bar = "█" * filled + "░" * (bar_len - filled)
            lines.append(
                f"  [{bar}] {name}: {alloc.used}/{alloc.allocated} "
                f"({alloc.utilization:.0f}%)"
            )
        return "\n".join(lines)

    # ── Private helpers ────────────────────────────────────────────────

    def _setup_allocations(self) -> None:
        """Create budget allocations from ratios."""
        for name, ratio in self._ratios.items():
            if name == "headroom":
                continue  # headroom is implicit
            allocated = int(self._available * ratio)
            priority = self.PRIORITIES.get(name, 5)
            self._allocations[name] = BudgetAllocation(
                name=name,
                allocated=allocated,
                priority=priority,
            )

    @staticmethod
    def _resolve_context_size(model: str) -> int:
        """Look up the context size for a model."""
        model_lower = model.lower()
        for key, size in _MODEL_CONTEXT_SIZES.items():
            if key in model_lower:
                return size
        return _MODEL_CONTEXT_SIZES["default"]
