"""Context prioritizer — ranks context components by relevance.

Assigns relevance scores to context components so the assembler
knows which pieces to include first when the budget is tight.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ContextComponent:
    """A piece of context with metadata for prioritisation."""
    name: str
    content: str
    token_count: int = 0
    priority: int = 5  # 1 = highest, 10 = lowest
    relevance_score: float = 0.5  # 0.0 – 1.0
    recency_score: float = 0.5  # 0.0 – 1.0 (1.0 = most recent)
    category: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def composite_score(self) -> float:
        """Weighted composite score for ranking."""
        # Priority weight (lower number = higher weight)
        priority_weight = 1.0 - (self.priority - 1) / 9.0
        return (
            0.4 * self.relevance_score
            + 0.3 * priority_weight
            + 0.3 * self.recency_score
        )


class ContextPrioritizer:
    """Ranks context components by composite relevance.

    Uses a weighted combination of:
      - Relevance (semantic similarity to the current goal)
      - Priority (component type priority)
      - Recency (how recently the component was created)
    """

    def __init__(
        self,
        relevance_weight: float = 0.4,
        priority_weight: float = 0.3,
        recency_weight: float = 0.3,
    ) -> None:
        self._w_relevance = relevance_weight
        self._w_priority = priority_weight
        self._w_recency = recency_weight

    def prioritize(
        self,
        components: list[ContextComponent],
        goal: str = "",
    ) -> list[ContextComponent]:
        """Sort components by composite score (highest first).

        Args:
            components: The components to rank.
            goal: The current goal (for relevance boosting).

        Returns:
            Components sorted by composite score, descending.
        """
        if goal:
            self._boost_relevance(components, goal)

        return sorted(
            components,
            key=lambda c: c.composite_score,
            reverse=True,
        )

    def select_within_budget(
        self,
        components: list[ContextComponent],
        token_budget: int,
        goal: str = "",
    ) -> list[ContextComponent]:
        """Select the highest-priority components that fit within a budget.

        Args:
            components: Available context components.
            token_budget: Maximum tokens to use.
            goal: The current goal.

        Returns:
            Selected components that fit within the budget.
        """
        ranked = self.prioritize(components, goal)
        selected: list[ContextComponent] = []
        remaining = token_budget

        for comp in ranked:
            if comp.token_count <= remaining:
                selected.append(comp)
                remaining -= comp.token_count
            elif comp.token_count > 0 and remaining > 0:
                # Partial fit — truncate
                truncated = ContextComponent(
                    name=comp.name,
                    content=comp.content[:remaining * 4],  # rough char estimate
                    token_count=remaining,
                    priority=comp.priority,
                    relevance_score=comp.relevance_score,
                    recency_score=comp.recency_score,
                    category=comp.category,
                    metadata={**comp.metadata, "truncated": True},
                )
                selected.append(truncated)
                remaining = 0
                break

        return selected

    # ── Private helpers ────────────────────────────────────────────────

    def _boost_relevance(
        self,
        components: list[ContextComponent],
        goal: str,
    ) -> None:
        """Boost relevance scores for components related to the goal."""
        goal_words = set(re.findall(r"\w{3,}", goal.lower()))
        if not goal_words:
            return

        for comp in components:
            content_words = set(re.findall(r"\w{3,}", comp.content.lower()))
            overlap = goal_words & content_words
            if overlap:
                boost = min(0.3, len(overlap) * 0.05)
                comp.relevance_score = min(1.0, comp.relevance_score + boost)
