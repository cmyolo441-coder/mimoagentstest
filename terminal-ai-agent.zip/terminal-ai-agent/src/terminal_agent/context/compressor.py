"""Context compressor — reduces context size when approaching limits.

Implements multiple compression strategies: truncation, summarisation,
and intelligent pruning to keep the most important information.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Protocol

logger = logging.getLogger(__name__)


class SummarizerProtocol(Protocol):
    """Protocol for text summarisation."""

    async def summarize(self, text: str, max_tokens: int = 200) -> str:
        """Summarise text to fit within max_tokens."""
        ...


class ContextCompressor:
    """Compresses context components to fit within token budgets.

    Strategies (applied in order):
      1. Truncate long tool outputs (keep head + tail).
      2. Summarise old conversation turns.
      3. Remove low-priority components.
      4. Compress file contents (keep relevant lines only).
    """

    def __init__(
        self,
        summarizer: SummarizerProtocol | None = None,
        tool_output_max_chars: int = 8000,
        tool_output_head_chars: int = 2000,
        tool_output_tail_chars: int = 1000,
    ) -> None:
        self._summarizer = summarizer
        self._tool_output_max = tool_output_max_chars
        self._tool_output_head = tool_output_head_chars
        self._tool_output_tail = tool_output_tail_chars

    async def compress(
        self,
        components: dict[str, str],
        target_tokens: int,
        estimate_fn: Any = None,
    ) -> dict[str, str]:
        """Compress components to fit within target_tokens.

        Args:
            components: {name: content} dict of context pieces.
            target_tokens: Maximum total tokens.
            estimate_fn: Callable(str) -> int for token estimation.
                         Defaults to len(text) // 4.

        Returns:
            Compressed components dict.
        """
        if estimate_fn is None:
            estimate_fn = lambda t: len(t) // 4

        total = sum(estimate_fn(v) for v in components.values())
        if total <= target_tokens:
            return components

        logger.info(
            "Compressing context: %d tokens → %d target",
            total, target_tokens,
        )

        result = dict(components)

        # Strategy 1: Truncate tool outputs
        result = self._truncate_tool_outputs(result, estimate_fn)
        total = sum(estimate_fn(v) for v in result.values())
        if total <= target_tokens:
            return result

        # Strategy 2: Summarise conversation history
        if "conversation_history" in result and self._summarizer:
            result["conversation_history"] = await self._summarize_text(
                result["conversation_history"],
                target_chars=estimate_fn("x") * (total - target_tokens) * 4,
            )
            total = sum(estimate_fn(v) for v in result.values())
            if total <= target_tokens:
                return result

        # Strategy 3: Truncate working memory / long-term memory
        for key in ("working_memory", "long_term_memory"):
            if key in result and total > target_tokens:
                excess = total - target_tokens
                chars_to_remove = excess * 4
                result[key] = self._smart_truncate(result[key], chars_to_remove)
                total = sum(estimate_fn(v) for v in result.values())

        # Strategy 4: Hard truncation of everything except system prompt
        if total > target_tokens:
            result = self._hard_compress(result, target_tokens, estimate_fn)

        return result

    def truncate_tool_output(self, output: str) -> str:
        """Truncate a single tool output intelligently.

        Keeps the head and tail, replacing the middle with a marker.
        """
        if len(output) <= self._tool_output_max:
            return output

        head = output[:self._tool_output_head]
        tail = output[-self._tool_output_tail:]
        omitted = len(output) - self._tool_output_head - self._tool_output_tail
        return f"{head}\n\n... [{omitted} characters omitted] ...\n\n{tail}"

    # ── Private helpers ────────────────────────────────────────────────

    def _truncate_tool_outputs(
        self,
        components: dict[str, str],
        estimate_fn: Any,
    ) -> dict[str, str]:
        """Truncate components that look like tool outputs."""
        result = {}
        for key, value in components.items():
            if "tool" in key.lower() or "output" in key.lower():
                result[key] = self.truncate_tool_output(value)
            else:
                result[key] = value
        return result

    async def _summarize_text(self, text: str, target_chars: int) -> str:
        """Summarise text to approximately target_chars."""
        if not self._summarizer:
            return self._smart_truncate(text, len(text) - target_chars)
        try:
            max_tokens = max(50, target_chars // 4)
            return await self._summarizer.summarize(text, max_tokens=max_tokens)
        except Exception:
            return self._smart_truncate(text, len(text) - target_chars)

    @staticmethod
    def _smart_truncate(text: str, chars_to_remove: int) -> str:
        """Remove characters from the middle of the text."""
        if chars_to_remove <= 0:
            return text
        if chars_to_remove >= len(text):
            return text[:100] + "\n[... content truncated ...]"

        mid_start = len(text) // 3
        mid_end = mid_start + chars_to_remove
        return (
            text[:mid_start]
            + "\n[... content compressed ...]\n"
            + text[mid_end:]
        )

    @staticmethod
    def _hard_compress(
        components: dict[str, str],
        target_tokens: int,
        estimate_fn: Any,
    ) -> dict[str, str]:
        """Last-resort: proportionally shrink everything except system_prompt."""
        total = sum(estimate_fn(v) for v in components.values())
        if total <= target_tokens:
            return components

        ratio = target_tokens / total
        result = {}
        for key, value in components.items():
            if key == "system_prompt":
                result[key] = value  # Never compress system prompt
            else:
                target_chars = int(len(value) * ratio)
                result[key] = value[:target_chars] if target_chars > 0 else ""
        return result
