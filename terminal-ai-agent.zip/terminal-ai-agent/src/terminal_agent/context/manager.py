"""Context manager — top-level facade for context window management.

Coordinates the assembler, compressor, prioritiser, budget, and
environment gatherer into a single `assemble()` call.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.context.assembler import ContextAssembler
from terminal_agent.context.compressor import ContextCompressor
from terminal_agent.context.environment import EnvironmentGatherer
from terminal_agent.context.prioritizer import ContextPrioritizer
from terminal_agent.context.summarizer import ConversationSummarizer
from terminal_agent.context.token_budget import TokenBudget
from terminal_agent.types import Plan

logger = logging.getLogger(__name__)


class ContextManager:
    """High-level facade for context window management.

    Usage::

        ctx = ContextManager(model="gpt-4o")
        prompt = await ctx.assemble(
            goal="Fix the login bug",
            plan=current_plan,
            conversation_history=recent_turns,
            memories=recalled_memories,
        )
    """

    def __init__(
        self,
        model: str = "default",
        max_tokens: int | None = None,
        reserve_for_response: int = 4096,
    ) -> None:
        self._budget = TokenBudget(
            model=model,
            max_tokens=max_tokens,
            reserve_for_response=reserve_for_response,
        )
        self._summarizer = ConversationSummarizer()
        self._compressor = ContextCompressor(summarizer=self._summarizer)
        self._prioritizer = ContextPrioritizer()
        self._env = EnvironmentGatherer()
        self._assembler = ContextAssembler(
            budget=self._budget,
            prioritizer=self._prioritizer,
            compressor=self._compressor,
            env_gatherer=self._env,
        )

    @property
    def budget(self) -> TokenBudget:
        """Access the token budget."""
        return self._budget

    async def assemble(
        self,
        goal: str,
        plan: Plan | None = None,
        system_prompt: str = "",
        conversation_history: list[dict[str, str]] | None = None,
        memories: list[str] | None = None,
        tool_results: list[str] | None = None,
        working_memory: dict[str, str] | None = None,
        extra_components: dict[str, str] | None = None,
    ) -> str:
        """Assemble the full context prompt.

        This is the primary interface.  It coordinates all sub-components
        to produce a prompt that fits within the model's context window.

        Args:
            goal: The user's goal.
            plan: Current plan (optional).
            system_prompt: System prompt text.
            conversation_history: Recent turns.
            memories: Recalled memories.
            tool_results: Recent tool outputs.
            working_memory: Active file contents.
            extra_components: Additional context pieces.

        Returns:
            The assembled prompt string.
        """
        self._budget.reset()
        return await self._assembler.assemble(
            goal=goal,
            plan=plan,
            system_prompt=system_prompt,
            conversation_history=conversation_history,
            memories=memories,
            tool_results=tool_results,
            working_memory=working_memory,
            extra_components=extra_components,
        )

    async def summarize_history(
        self,
        turns: list[dict[str, str]],
        max_tokens: int = 200,
    ) -> str:
        """Summarise old conversation turns."""
        return await self._summarizer.summarize_turns(turns, max_tokens)

    def get_environment(self, force_refresh: bool = False) -> str:
        """Get the environment info as a context string."""
        return self._env.gather(force_refresh).to_context_string()

    def budget_summary(self) -> str:
        """Get a human-readable budget summary."""
        return self._budget.summary()
