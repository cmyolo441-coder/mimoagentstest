"""Conversation summarizer — condenses old conversation turns.

Uses the LLM (when available) or a deterministic extraction approach
to create concise summaries of older conversation history.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Protocol

logger = logging.getLogger(__name__)


class LLMProvider(Protocol):
    """Minimal LLM interface for summarisation."""

    async def generate(self, prompt: str, **kwargs: Any) -> str:
        """Generate text from a prompt."""
        ...


class ConversationSummarizer:
    """Summarises conversation history to reduce context size.

    Supports two modes:
      - LLM-powered: sends conversation to the LLM for summarisation.
      - Deterministic: extracts key points without an LLM call.
    """

    def __init__(self, llm: LLMProvider | None = None) -> None:
        self._llm = llm

    async def summarize(
        self,
        text: str,
        max_tokens: int = 200,
    ) -> str:
        """Summarise the given text.

        Args:
            text: The text to summarise.
            max_tokens: Target maximum tokens for the summary.

        Returns:
            A condensed summary.
        """
        if not text.strip():
            return ""

        # If text is already short, return as-is
        estimated_tokens = len(text) // 4
        if estimated_tokens <= max_tokens:
            return text

        if self._llm is not None:
            return await self._llm_summarize(text, max_tokens)

        return self._deterministic_summarize(text, max_tokens)

    async def summarize_turns(
        self,
        turns: list[dict[str, str]],
        max_tokens: int = 200,
    ) -> str:
        """Summarise a list of conversation turns.

        Args:
            turns: List of {"role": ..., "content": ...} dicts.
            max_tokens: Target tokens for the summary.

        Returns:
            A summary string.
        """
        if not turns:
            return ""

        # Format turns for summarisation
        formatted = "\n".join(
            f"{t.get('role', 'unknown')}: {t.get('content', '')[:200]}"
            for t in turns
        )
        return await self.summarize(formatted, max_tokens)

    # ── Private helpers ────────────────────────────────────────────────

    async def _llm_summarize(self, text: str, max_tokens: int) -> str:
        """Use the LLM to create a summary."""
        prompt = (
            "Summarise the following conversation concisely, preserving "
            "key decisions, actions taken, and important context.\n\n"
            f"{text}\n\n"
            f"Summary (max {max_tokens} tokens):"
        )
        try:
            return await self._llm.generate(prompt, max_tokens=max_tokens)  # type: ignore[union-attr]
        except Exception:
            logger.warning("LLM summarisation failed, falling back to deterministic")
            return self._deterministic_summarize(text, max_tokens)

    @staticmethod
    def _deterministic_summarize(text: str, max_tokens: int) -> str:
        """Extractive summarisation without an LLM.

        Keeps the first and last portions, and extracts lines that
        look important (containing key markers).
        """
        lines = text.splitlines()
        if not lines:
            return text[: max_tokens * 4]

        target_chars = max_tokens * 4

        # Extract important lines
        important: list[str] = []
        markers = re.compile(
            r"\b(error|failed|success|created|modified|deleted|"
            r"result|output|warning|important|note|decision)\b",
            re.IGNORECASE,
        )
        for line in lines:
            if markers.search(line):
                important.append(line.strip())

        # Build summary: head + important lines + tail
        head_chars = target_chars // 3
        tail_chars = target_chars // 3

        head = text[:head_chars]
        tail = text[-tail_chars:] if len(text) > tail_chars else ""

        summary_parts = [head]
        if important:
            mid_budget = target_chars - head_chars - tail_chars
            mid_text = "\n".join(important)
            if len(mid_text) > mid_budget:
                mid_text = mid_text[:mid_budget]
            summary_parts.append(f"\n[Key points]\n{mid_text}")
        if tail:
            summary_parts.append(f"\n{tail}")

        return "".join(summary_parts)
