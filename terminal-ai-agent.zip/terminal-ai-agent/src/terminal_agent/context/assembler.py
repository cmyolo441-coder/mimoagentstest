"""Context assembler — builds the final prompt from components.

Combines system prompt, goal, plan, memory, history, tool results,
and environment info into a single prompt within token budget.
"""

from __future__ import annotations

import logging
from typing import Any, Protocol

from terminal_agent.context.compressor import ContextCompressor
from terminal_agent.context.environment import EnvironmentGatherer, EnvironmentInfo
from terminal_agent.context.prioritizer import ContextComponent, ContextPrioritizer
from terminal_agent.context.token_budget import TokenBudget
from terminal_agent.types import Plan

logger = logging.getLogger(__name__)


class ContextAssembler:
    """Assembles the final prompt from multiple context components.

    The assembler:
      1.  Gathers all available context components.
      2.  Estimates token counts.
      3.  Prioritises components by relevance.
      4.  Fits components within the token budget (compressing if needed).
      5.  Concatenates into a single prompt string.
    """

    def __init__(
        self,
        budget: TokenBudget,
        prioritizer: ContextPrioritizer | None = None,
        compressor: ContextCompressor | None = None,
        env_gatherer: EnvironmentGatherer | None = None,
    ) -> None:
        self._budget = budget
        self._prioritizer = prioritizer or ContextPrioritizer()
        self._compressor = compressor or ContextCompressor()
        self._env = env_gatherer or EnvironmentGatherer()

    async def assemble(
        self,
        goal: str,
        plan: Plan | None = None,
        system_prompt: str = "",
        conversation_history: list[dict[str, str]] | None = None,
        memories: list[str] | None = None,
        tool_results: list[str] | None = None,
        working_memory: dict[str, str] | None = None,
        extra_components: dict[str, str] | None = None,
    ) -> str:
        """Assemble all context into a single prompt string.

        Args:
            goal: The current goal.
            plan: The current plan (if any).
            system_prompt: The system prompt.
            conversation_history: Recent conversation turns.
            memories: Recalled long-term memories.
            tool_results: Recent tool outputs.
            working_memory: Active file contents / scratch pad.
            extra_components: Any additional context pieces.

        Returns:
            The assembled prompt string.
        """
        # Gather components
        components: dict[str, str] = {}

        if system_prompt:
            components["system_prompt"] = system_prompt

        # Goal and plan
        goal_section = f"GOAL:\n{goal}"
        if plan and plan.steps:
            step_lines = []
            for s in plan.steps:
                status_icon = {
                    "pending": "[ ]",
                    "running": "[→]",
                    "completed": "[✓]",
                    "failed": "[✗]",
                    "paused": "[‖]",
                    "cancelled": "[×]",
                }.get(s.status.value, "[ ]")
                step_lines.append(f"  {status_icon} {s.id}: {s.description}")
            goal_section += f"\n\nPLAN:\n" + "\n".join(step_lines)
        components["goal_and_plan"] = goal_section

        # Conversation history
        if conversation_history:
            hist_lines = []
            for turn in conversation_history[-10:]:  # last 10 turns
                role = turn.get("role", "unknown")
                content = turn.get("content", "")[:500]
                hist_lines.append(f"{role}: {content}")
            components["conversation_history"] = "\n".join(hist_lines)

        # Long-term memories
        if memories:
            mem_text = "\n".join(f"  - {m[:200]}" for m in memories[:5])
            components["long_term_memory"] = f"RELEVANT MEMORIES:\n{mem_text}"

        # Working memory
        if working_memory:
            wm_lines = []
            for name, content in working_memory.items():
                wm_lines.append(f"--- {name} ---\n{content[:1000]}")
            components["working_memory"] = "\n\n".join(wm_lines)

        # Tool results
        if tool_results:
            tr_text = "\n---\n".join(
                self._compressor.truncate_tool_output(r) for r in tool_results[-3:]
            )
            components["tool_results"] = f"RECENT TOOL OUTPUTS:\n{tr_text}"

        # Environment
        env_info = self._env.gather()
        components["environment"] = env_info.to_context_string()

        # Extra components
        if extra_components:
            components.update(extra_components)

        # Compress if over budget
        components = await self._compressor.compress(
            components,
            target_tokens=self._budget.available_tokens,
        )

        # Assemble final prompt
        ordered_keys = [
            "system_prompt",
            "goal_and_plan",
            "conversation_history",
            "working_memory",
            "long_term_memory",
            "tool_results",
            "environment",
        ]

        parts: list[str] = []
        for key in ordered_keys:
            if key in components and components[key]:
                parts.append(components[key])

        # Add any extra components not in the standard order
        for key, value in components.items():
            if key not in ordered_keys and value:
                parts.append(value)

        return "\n\n".join(parts)
