"""Logging configuration for Terminal Agent."""

import logging
import logging.handlers
import sys
from pathlib import Path

from terminal_agent.constants import GLOBAL_LOG_DIR


def setup_logging(
    level: str = "INFO",
    log_format: str = "json",
    log_file: str | None = None,
    console: bool = True,
) -> None:
    """Set up logging configuration."""
    root_logger = logging.getLogger("terminal_agent")
    root_logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Remove existing handlers
    root_logger.handlers.clear()

    # Console handler
    if console:
        console_handler = logging.StreamHandler(sys.stderr)
        if log_format == "json":
            console_handler.setFormatter(JsonFormatter())
        else:
            console_handler.setFormatter(
                logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
            )
        root_logger.addHandler(console_handler)

    # File handler
    if log_file:
        log_path = Path(log_file)
    else:
        GLOBAL_LOG_DIR.mkdir(parents=True, exist_ok=True)
        log_path = GLOBAL_LOG_DIR / "agent.log"

    log_path.parent.mkdir(parents=True, exist_ok=True)
    file_handler = logging.handlers.RotatingFileHandler(
        log_path,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5,
    )
    file_handler.setFormatter(JsonFormatter())
    root_logger.addHandler(file_handler)


class JsonFormatter(logging.Formatter):
    """JSON log formatter."""

    def format(self, record: logging.LogRecord) -> str:
        import json
        log_entry = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[0]:
            log_entry["exception"] = self.formatException(record.exc_info)
        if hasattr(record, "extra_data"):
            log_entry["data"] = record.extra_data
        return json.dumps(log_entry)


def get_logger(name: str) -> logging.Logger:
    """Get a logger for a specific module."""
    return logging.getLogger(f"terminal_agent.{name}")
