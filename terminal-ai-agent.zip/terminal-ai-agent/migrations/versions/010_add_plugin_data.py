"""010 - Add plugin data.

Revision ID: 010
Revises: 009
Create Date: 2024-05-15 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa

revision = "010"
down_revision = "009"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create plugin-related tables."""
    op.create_table(
        "plugins",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("slug", sa.String(100), nullable=False),
        sa.Column("version", sa.String(20), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("author", sa.String(100), nullable=True),
        sa.Column("config_schema", sa.JSON(), nullable=True),
        sa.Column("is_enabled", sa.Boolean(), server_default="true", nullable=False),
        sa.Column("installed_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("slug"),
    )

    op.create_table(
        "plugin_configs",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("plugin_id", sa.Integer(), nullable=False),
        sa.Column("key", sa.String(100), nullable=False),
        sa.Column("value", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["plugin_id"], ["plugins.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("plugin_id", "key", name="uq_plugin_configs_plugin_key"),
    )
    op.create_index("ix_plugin_configs_plugin_id", "plugin_configs", ["plugin_id"])

    op.create_table(
        "plugin_data",
        sa.Column("id", sa.BigInteger(), nullable=False, autoincrement=True),
        sa.Column("plugin_id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("data_key", sa.String(255), nullable=False),
        sa.Column("data_value", sa.JSON(), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["plugin_id"], ["plugins.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_plugin_data_plugin_id", "plugin_data", ["plugin_id"])
    op.create_index("ix_plugin_data_user_id", "plugin_data", ["user_id"])
    op.create_index("ix_plugin_data_data_key", "plugin_data", ["data_key"])
    op.create_index("ix_plugin_data_expires_at", "plugin_data", ["expires_at"])


def downgrade() -> None:
    """Drop plugin tables."""
    op.drop_table("plugin_data")
    op.drop_table("plugin_configs")
    op.drop_table("plugins")
