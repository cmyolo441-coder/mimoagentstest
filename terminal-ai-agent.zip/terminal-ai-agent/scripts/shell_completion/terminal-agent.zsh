# zsh completion for terminal-agent
_terminal_agent() {
    local -a commands
    local -a project_types
    local -a config_profiles
    local -a deploy_envs

    commands=(
        'help:Show help information'
        'version:Show version'
        'init:Initialize a new project'
        'new:Create from template'
        'run:Run a command'
        'test:Run tests'
        'build:Build project'
        'deploy:Deploy to environment'
        'config:Manage configuration'
        'setup:Setup development environment'
        'lint:Run linters'
        'format:Format code'
        'clean:Clean build artifacts'
        'doctor:Check system health'
    )

    project_types=(
        'python_cli:Python CLI application'
        'python_library:Python library'
        'python_web_flask:Flask web application'
        'python_web_django:Django web application'
        'python_web_fastapi:FastAPI web application'
        'javascript_node:Node.js application'
        'javascript_react:React application'
        'javascript_nextjs:Next.js application'
        'go_cli:Go CLI application'
        'go_web:Go web application'
        'rust_cli:Rust CLI application'
        'java_spring:Spring Boot application'
        'ruby_rails:Ruby on Rails application'
        'php_laravel:Laravel application'
        'docker_compose_webapp:Docker Compose stack'
        'kubernetes_basic:Kubernetes deployment'
        'terraform_aws:Terraform AWS infrastructure'
        'github_actions_ci:GitHub Actions CI/CD'
        'monorepo:Monorepo setup'
    )

    config_profiles=(
        'minimal:Minimal configuration'
        'standard:Standard configuration'
        'advanced:Advanced configuration'
        'enterprise:Enterprise configuration'
        'local_only:Local-only configuration'
        'ci_cd:CI/CD configuration'
    )

    deploy_envs=(
        'dev:Development environment'
        'staging:Staging environment'
        'production:Production environment'
    )

    _arguments -C \
        '1:command:->command' \
        '*::arg:->args'

    case $state in
        command)
            _describe -t commands 'terminal-agent command' commands
            ;;
        args)
            case $words[1] in
                init|new)
                    _describe -t project-types 'project type' project_types
                    ;;
                config)
                    _describe -t config-profiles 'config profile' config_profiles
                    ;;
                deploy)
                    _describe -t deploy-environments 'environment' deploy_envs
                    ;;
                run)
                    _values 'command' test lint format build serve deploy
                    ;;
            esac
            ;;
    esac
}

compdef _terminal_agent terminal-agent
compdef _terminal_agent ta
