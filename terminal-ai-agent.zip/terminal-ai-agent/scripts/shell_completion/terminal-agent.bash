# bash completion for terminal-agent
_terminal_agent_completions() {
    local cur prev commands
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"

    commands="help version init new run test build deploy config setup lint format clean doctor"

    if [[ ${cur} == -* ]] ; then
        COMPREPLY=( $(compgen -W "--help --version --verbose --quiet --config --output --format" -- ${cur}) )
        return 0
    fi

    case "${prev}" in
        init|new)
            COMPREPLY=( $(compgen -W "python_cli python_library python_web_flask python_web_django python_web_fastapi javascript_node javascript_react javascript_nextjs go_cli go_web rust_cli java_spring ruby_rails php_laravel docker_compose_webapp kubernetes_basic terraform_aws github_actions_ci monorepo" -- ${cur}) )
            return 0
            ;;
        config)
            COMPREPLY=( $(compgen -W "minimal standard advanced enterprise local_only ci_cd show set get reset" -- ${cur}) )
            return 0
            ;;
        run)
            COMPREPLY=( $(compgen -W "test lint format build serve deploy" -- ${cur}) )
            return 0
            ;;
        deploy)
            COMPREPLY=( $(compgen -W "dev staging production" -- ${cur}) )
            return 0
            ;;
        *)
            ;;
    esac

    COMPREPLY=( $(compgen -W "${commands}" -- ${cur}) )
    return 0
}

complete -F _terminal_agent_completions terminal-agent
complete -F _terminal_agent_completions ta
