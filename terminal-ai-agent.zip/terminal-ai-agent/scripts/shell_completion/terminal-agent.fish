# fish completion for terminal-agent

# Commands
complete -c terminal-agent -f
complete -c terminal-agent -n '__fish_use_subcommand' -a help -d 'Show help information'
complete -c terminal-agent -n '__fish_use_subcommand' -a version -d 'Show version'
complete -c terminal-agent -n '__fish_use_subcommand' -a init -d 'Initialize a new project'
complete -c terminal-agent -n '__fish_use_subcommand' -a new -d 'Create from template'
complete -c terminal-agent -n '__fish_use_subcommand' -a run -d 'Run a command'
complete -c terminal-agent -n '__fish_use_subcommand' -a test -d 'Run tests'
complete -c terminal-agent -n '__fish_use_subcommand' -a build -d 'Build project'
complete -c terminal-agent -n '__fish_use_subcommand' -a deploy -d 'Deploy to environment'
complete -c terminal-agent -n '__fish_use_subcommand' -a config -d 'Manage configuration'
complete -c terminal-agent -n '__fish_use_subcommand' -a setup -d 'Setup development environment'
complete -c terminal-agent -n '__fish_use_subcommand' -a lint -d 'Run linters'
complete -c terminal-agent -n '__fish_use_subcommand' -a format -d 'Format code'
complete -c terminal-agent -n '__fish_use_subcommand' -a clean -d 'Clean build artifacts'
complete -c terminal-agent -n '__fish_use_subcommand' -a doctor -d 'Check system health'

# Project types for init/new
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a python_cli -d 'Python CLI application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a python_library -d 'Python library'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a python_web_flask -d 'Flask web application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a python_web_django -d 'Django web application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a python_web_fastapi -d 'FastAPI web application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a javascript_node -d 'Node.js application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a javascript_react -d 'React application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a javascript_nextjs -d 'Next.js application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a go_cli -d 'Go CLI application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a go_web -d 'Go web application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a rust_cli -d 'Rust CLI application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a java_spring -d 'Spring Boot application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a ruby_rails -d 'Ruby on Rails application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a php_laravel -d 'Laravel application'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a docker_compose_webapp -d 'Docker Compose stack'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a kubernetes_basic -d 'Kubernetes deployment'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a terraform_aws -d 'Terraform AWS infrastructure'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a github_actions_ci -d 'GitHub Actions CI/CD'
complete -c terminal-agent -n '__fish_seen_subcommand_from init new' -a monorepo -d 'Monorepo setup'

# Config subcommands
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a minimal -d 'Minimal configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a standard -d 'Standard configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a advanced -d 'Advanced configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a enterprise -d 'Enterprise configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a local_only -d 'Local-only configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a ci_cd -d 'CI/CD configuration'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a show -d 'Show current config'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a set -d 'Set config value'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a get -d 'Get config value'
complete -c terminal-agent -n '__fish_seen_subcommand_from config' -a reset -d 'Reset to defaults'

# Deploy environments
complete -c terminal-agent -n '__fish_seen_subcommand_from deploy' -a dev -d 'Development environment'
complete -c terminal-agent -n '__fish_seen_subcommand_from deploy' -a staging -d 'Staging environment'
complete -c terminal-agent -n '__fish_seen_subcommand_from deploy' -a production -d 'Production environment'

# Run subcommands
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -a test -d 'Run tests'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -a lint -d 'Run linters'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -a format -d 'Format code'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -a build -d 'Build project'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -a serve -d 'Start dev server'
complete -c terminal-agent -n '__fish_seen_subcommand_from run' -a deploy -d 'Deploy'

# Global options
complete -c terminal-agent -l help -d 'Show help'
complete -c terminal-agent -l version -d 'Show version'
complete -c terminal-agent -l verbose -d 'Verbose output'
complete -c terminal-agent -l quiet -d 'Quiet output'
complete -c terminal-agent -l config -d 'Config file path'
complete -c terminal-agent -l output -d 'Output path'
complete -c terminal-agent -l format -d 'Output format'
