#!/usr/bin/env bash
# setup.sh - Initial project setup
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "=========================================="
echo "  Terminal AI Agent - Project Setup"
echo "=========================================="

# Detect OS
OS="$(uname -s)"
case "$OS" in
    Linux*)     PLATFORM="linux";;
    Darwin*)    PLATFORM="macos";;
    CYGWIN*|MINGW*|MSYS*) PLATFORM="windows";;
    *)          PLATFORM="unknown"
esac
echo "Detected platform: $PLATFORM"

# Check dependencies
check_command() {
    if ! command -v "$1" &>/dev/null; then
        echo "ERROR: $1 is not installed."
        return 1
    fi
    echo "✓ $1 found: $(command -v "$1")"
    return 0
}

echo ""
echo "Checking dependencies..."
MISSING=0
for cmd in python3 git; do
    check_command "$cmd" || MISSING=1
done

if [ "$MISSING" -eq 1 ]; then
    echo ""
    echo "Please install missing dependencies and try again."
    exit 1
fi

# Check Python version
PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PYTHON_MAJOR=$(echo "$PYTHON_VERSION" | cut -d. -f1)
PYTHON_MINOR=$(echo "$PYTHON_VERSION" | cut -d. -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 10 ]); then
    echo "ERROR: Python 3.10+ required, found $PYTHON_VERSION"
    exit 1
fi
echo "✓ Python $PYTHON_VERSION"

# Create virtual environment
echo ""
echo "Setting up virtual environment..."
if [ ! -d "$PROJECT_ROOT/venv" ]; then
    python3 -m venv "$PROJECT_ROOT/venv"
    echo "✓ Virtual environment created"
else
    echo "✓ Virtual environment already exists"
fi

# Activate venv
source "$PROJECT_ROOT/venv/bin/activate"

# Upgrade pip
echo ""
echo "Upgrading pip..."
pip install --upgrade pip setuptools wheel

# Install dependencies
echo ""
echo "Installing dependencies..."
if [ -f "$PROJECT_ROOT/requirements.txt" ]; then
    pip install -r "$PROJECT_ROOT/requirements.txt"
fi
if [ -f "$PROJECT_ROOT/pyproject.toml" ]; then
    pip install -e "$PROJECT_ROOT[dev]" 2>/dev/null || pip install -e "$PROJECT_ROOT"
fi

# Install pre-commit hooks
echo ""
echo "Setting up pre-commit..."
if command -v pre-commit &>/dev/null; then
    pre-commit install
    echo "✓ Pre-commit hooks installed"
else
    echo "⚠ pre-commit not found, skipping hooks"
fi

# Copy .env.example if .env doesn't exist
if [ -f "$PROJECT_ROOT/.env.example" ] && [ ! -f "$PROJECT_ROOT/.env" ]; then
    cp "$PROJECT_ROOT/.env.example" "$PROJECT_ROOT/.env"
    echo "✓ Created .env from .env.example"
fi

echo ""
echo "=========================================="
echo "  Setup complete!"
echo "=========================================="
echo ""
echo "Activate the virtual environment:"
echo "  source venv/bin/activate"
echo ""
echo "Run tests:"
echo "  pytest"
echo ""
