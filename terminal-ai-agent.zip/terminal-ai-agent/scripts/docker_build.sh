#!/usr/bin/env bash
# docker_build.sh - Build Docker images
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$PROJECT_ROOT"

IMAGE_NAME="${IMAGE_NAME:-$(basename "$PROJECT_ROOT")}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
DOCKERFILE="${DOCKERFILE:-Dockerfile}"
BUILD_ARGS=""
NO_CACHE=false
PUSH=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --tag|-t) IMAGE_TAG="$2"; shift 2 ;;
        --file|-f) DOCKERFILE="$2"; shift 2 ;;
        --no-cache) NO_CACHE=true; shift ;;
        --push) PUSH=true; shift ;;
        --name) IMAGE_NAME="$2"; shift 2 ;;
        --build-arg) BUILD_ARGS="$BUILD_ARGS --build-arg $2"; shift 2 ;;
        --help|-h)
            echo "Usage: docker_build.sh [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --tag, -t TAG    Image tag (default: latest)"
            echo "  --file, -f FILE  Dockerfile (default: Dockerfile)"
            echo "  --no-cache       Build without cache"
            echo "  --push           Push after building"
            echo "  --name NAME      Image name"
            echo "  --build-arg ARG  Build argument"
            echo "  --help           Show this help"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

# Build command
DOCKER_ARGS=("build" "-t" "${IMAGE_NAME}:${IMAGE_TAG}" "-f" "$DOCKERFILE")

if [ "$NO_CACHE" = true ]; then
    DOCKER_ARGS+=("--no-cache")
fi

if [ -n "$BUILD_ARGS" ]; then
    # shellcheck disable=SC2086
    DOCKER_ARGS+=($BUILD_ARGS)
fi

DOCKER_ARGS+=(".")

echo "Building Docker image: ${IMAGE_NAME}:${IMAGE_TAG}"
echo "Dockerfile: $DOCKERFILE"
echo ""

docker "${DOCKER_ARGS[@]}"

echo ""
echo "✓ Docker image built: ${IMAGE_NAME}:${IMAGE_TAG}"

# Push if requested
if [ "$PUSH" = true ]; then
    echo ""
    echo "Pushing image..."
    docker push "${IMAGE_NAME}:${IMAGE_TAG}"
    echo "✓ Image pushed"
fi

# Show image size
echo ""
echo "Image details:"
docker images "${IMAGE_NAME}:${IMAGE_TAG}" --format "  Repository: {{.Repository}}\n  Tag: {{.Tag}}\n  Size: {{.Size}}\n  Created: {{.CreatedSince}}"
