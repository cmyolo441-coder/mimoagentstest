#!/usr/bin/env bash
# install.sh - Install project and dependencies
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "Installing Terminal AI Agent..."

cd "$PROJECT_ROOT"

# Ensure virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

source venv/bin/activate

# Upgrade pip
pip install --upgrade pip setuptools wheel

# Install based on project type
if [ -f "pyproject.toml" ]; then
    echo "Installing from pyproject.toml..."
    pip install -e ".[dev]" 2>/dev/null || pip install -e .
elif [ -f "requirements.txt" ]; then
    echo "Installing from requirements.txt..."
    pip install -r requirements.txt
fi

if [ -f "requirements-dev.txt" ]; then
    echo "Installing dev dependencies..."
    pip install -r requirements-dev.txt
fi

# Install Node.js dependencies if present
if [ -f "package.json" ]; then
    echo "Installing Node.js dependencies..."
    if command -v npm &>/dev/null; then
        npm install
    elif command -v pnpm &>/dev/null; then
        pnpm install
    elif command -v yarn &>/dev/null; then
        yarn install
    fi
fi

# Install Go dependencies if present
if [ -f "go.mod" ]; then
    echo "Installing Go dependencies..."
    go mod download
fi

# Install Rust dependencies if present
if [ -f "Cargo.toml" ]; then
    echo "Installing Rust dependencies..."
    cargo fetch
fi

# Install Ruby dependencies if present
if [ -f "Gemfile" ]; then
    echo "Installing Ruby dependencies..."
    bundle install
fi

# Install PHP dependencies if present
if [ -f "composer.json" ]; then
    echo "Installing PHP dependencies..."
    composer install
fi

echo ""
echo "✓ Installation complete!"
