#!/usr/bin/env bash
# dev_setup.sh - Development environment setup
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "Setting up development environment..."

cd "$PROJECT_ROOT"

# Run the main setup
bash scripts/setup.sh

# Install additional dev tools
source venv/bin/activate

echo ""
echo "Installing development tools..."

# Python dev tools
pip install --quiet \
    ruff \
    mypy \
    pytest \
    pytest-cov \
    pytest-asyncio \
    pre-commit \
    ipython \
    ipdb

# Check for Docker
if command -v docker &>/dev/null; then
    echo "✓ Docker found"
else
    echo "⚠ Docker not found (optional)"
fi

# Check for Node.js (needed for some tools)
if command -v node &>/dev/null; then
    echo "✓ Node.js found: $(node --version)"
else
    echo "⚠ Node.js not found (optional)"
fi

# Set up git hooks
echo ""
echo "Configuring git..."
if [ -d ".git" ]; then
    # Set up git hooks directory
    git config core.hooksPath .githooks 2>/dev/null || true

    # Install pre-commit hooks
    if command -v pre-commit &>/dev/null; then
        pre-commit install
        pre-commit install --hook-type commit-msg
        echo "✓ Pre-commit hooks installed"
    fi
fi

# Create necessary directories
mkdir -p .openclaw/tmp
mkdir -p logs

echo ""
echo "=========================================="
echo "  Development setup complete!"
echo "=========================================="
echo ""
echo "Quick commands:"
echo "  make test        - Run tests"
echo "  make lint        - Run linter"
echo "  make format      - Format code"
echo "  make dev         - Start dev server"
