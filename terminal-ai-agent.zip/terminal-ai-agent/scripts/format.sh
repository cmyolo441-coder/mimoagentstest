#!/usr/bin/env bash
# format.sh - Format code
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$PROJECT_ROOT"

if [ -d "venv" ]; then
    source venv/bin/activate
fi

echo "Formatting code..."

# Python formatting
if command -v ruff &>/dev/null; then
    echo "Formatting Python with ruff..."
    ruff check --fix .
    ruff format .
    echo "✓ Python formatted"
fi

# JavaScript/TypeScript formatting
if [ -f "package.json" ] && command -v npm &>/dev/null; then
    if grep -q '"format"' package.json; then
        echo "Formatting JS/TS with prettier..."
        npm run format
        echo "✓ JS/TS formatted"
    fi
fi

# Go formatting
if [ -f "go.mod" ] && command -v gofmt &>/dev/null; then
    echo "Formatting Go..."
    gofmt -w .
    echo "✓ Go formatted"
fi

# Rust formatting
if [ -f "Cargo.toml" ] && command -v cargo &>/dev/null; then
    echo "Formatting Rust..."
    cargo fmt
    echo "✓ Rust formatted"
fi

# Ruby formatting
if [ -f "Gemfile" ] && command -v rubocop &>/dev/null; then
    echo "Formatting Ruby..."
    rubocop -A
    echo "✓ Ruby formatted"
fi

echo ""
echo "✓ Formatting complete!"
