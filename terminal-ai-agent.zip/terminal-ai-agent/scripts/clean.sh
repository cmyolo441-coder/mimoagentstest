#!/usr/bin/env bash
# clean.sh - Clean build artifacts
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$PROJECT_ROOT"

echo "Cleaning build artifacts..."

# Python
echo "Cleaning Python artifacts..."
rm -rf build/ dist/ *.egg-info src/*.egg-info
rm -rf .mypy_cache .ruff_cache .pytest_cache
rm -rf htmlcov/ .coverage coverage.xml
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find . -type f -name "*.pyc" -delete 2>/dev/null || true
echo "✓ Python artifacts cleaned"

# Node.js
if [ -d "node_modules" ]; then
    echo "Cleaning Node.js artifacts..."
    rm -rf node_modules/ dist/ build/ .next/ .turbo/
    echo "✓ Node.js artifacts cleaned"
fi

# Go
if [ -f "go.mod" ]; then
    echo "Cleaning Go artifacts..."
    rm -rf bin/
    go clean -cache -testcache 2>/dev/null || true
    echo "✓ Go artifacts cleaned"
fi

# Rust
if [ -f "Cargo.toml" ]; then
    echo "Cleaning Rust artifacts..."
    cargo clean 2>/dev/null || true
    echo "✓ Rust artifacts cleaned"
fi

# Docker
echo "Cleaning Docker artifacts..."
docker system prune -f 2>/dev/null || true
echo "✓ Docker artifacts cleaned"

# General
rm -rf logs/*.log
rm -rf test-results/
rm -rf .openclaw/tmp/*

echo ""
echo "✓ Clean complete!"
