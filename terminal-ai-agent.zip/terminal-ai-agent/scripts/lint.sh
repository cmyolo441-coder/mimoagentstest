#!/usr/bin/env bash
# lint.sh - Run linters
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$PROJECT_ROOT"

if [ -d "venv" ]; then
    source venv/bin/activate
fi

FIX=false
STRICT=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --fix) FIX=true; shift ;;
        --strict) STRICT=true; shift ;;
        --help|-h)
            echo "Usage: lint.sh [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --fix      Auto-fix issues"
            echo "  --strict   Fail on warnings"
            echo "  --help     Show this help"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

EXIT_CODE=0

# Python linting with ruff
if command -v ruff &>/dev/null; then
    echo "Running ruff..."
    if [ "$FIX" = true ]; then
        ruff check --fix . || EXIT_CODE=1
        ruff format . || EXIT_CODE=1
    else
        ruff check . || EXIT_CODE=1
        ruff format --check . || EXIT_CODE=1
    fi
    echo "✓ ruff passed"
else
    echo "⚠ ruff not found, skipping Python linting"
fi

# Type checking with mypy
if command -v mypy &>/dev/null && [ -d "src" ]; then
    echo ""
    echo "Running mypy..."
    MYPY_ARGS="--ignore-missing-imports"
    if [ "$STRICT" = true ]; then
        MYPY_ARGS="--strict"
    fi
    mypy $MYPY_ARGS src/ || EXIT_CODE=1
    echo "✓ mypy passed"
fi

# JavaScript/TypeScript linting
if [ -f "package.json" ] && command -v npm &>/dev/null; then
    if grep -q '"lint"' package.json; then
        echo ""
        echo "Running npm lint..."
        npm run lint || EXIT_CODE=1
        echo "✓ npm lint passed"
    fi
fi

# Go linting
if [ -f "go.mod" ] && command -v golangci-lint &>/dev/null; then
    echo ""
    echo "Running golangci-lint..."
    golangci-lint run || EXIT_CODE=1
    echo "✓ golangci-lint passed"
fi

# Rust linting
if [ -f "Cargo.toml" ] && command -v cargo &>/dev/null; then
    echo ""
    echo "Running cargo clippy..."
    cargo clippy -- -D warnings || EXIT_CODE=1
    echo "✓ clippy passed"

    echo ""
    echo "Checking formatting..."
    cargo fmt --check || EXIT_CODE=1
    echo "✓ formatting passed"
fi

echo ""
if [ $EXIT_CODE -eq 0 ]; then
    echo "✓ All linting passed!"
else
    echo "✗ Linting failed"
fi

exit $EXIT_CODE
