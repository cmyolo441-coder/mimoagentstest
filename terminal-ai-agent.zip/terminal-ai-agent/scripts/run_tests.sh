#!/usr/bin/env bash
# run_tests.sh - Run test suite
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$PROJECT_ROOT"

# Activate virtual environment if it exists
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# Default values
COVERAGE=true
VERBOSE=false
PARALLEL=false
MARKERS=""
FAIL_FAST=false
JUNIT_REPORT=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --no-coverage) COVERAGE=false; shift ;;
        --verbose|-v) VERBOSE=true; shift ;;
        --parallel|-p) PARALLEL=true; shift ;;
        -m) MARKERS="$2"; shift 2 ;;
        --fail-fast|-x) FAIL_FAST=true; shift ;;
        --junit) JUNIT_REPORT=true; shift ;;
        --help|-h)
            echo "Usage: run_tests.sh [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --no-coverage    Disable coverage reporting"
            echo "  --verbose, -v    Verbose output"
            echo "  --parallel, -p   Run tests in parallel"
            echo "  -m MARKER        Run tests with specific marker"
            echo "  --fail-fast, -x  Stop on first failure"
            echo "  --junit          Generate JUnit XML report"
            echo "  --help, -h       Show this help"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

# Build pytest command
PYTEST_ARGS=()

if [ "$VERBOSE" = true ]; then
    PYTEST_ARGS+=("-v")
fi

if [ "$FAIL_FAST" = true ]; then
    PYTEST_ARGS+=("-x")
fi

if [ "$PARALLEL" = true ]; then
    PYTEST_ARGS+=("-n" "auto")
fi

if [ -n "$MARKERS" ]; then
    PYTEST_ARGS+=("-m" "$MARKERS")
fi

if [ "$COVERAGE" = true ]; then
    PYTEST_ARGS+=("--cov" "--cov-report=term-missing" "--cov-report=html" "--cov-report=xml")
fi

if [ "$JUNIT_REPORT" = true ]; then
    PYTEST_ARGS+=("--junitxml=test-results/junit.xml")
    mkdir -p test-results
fi

echo "Running tests..."
echo "  Coverage: $COVERAGE"
echo "  Verbose: $VERBOSE"
echo "  Parallel: $PARALLEL"
echo ""

pytest "${PYTEST_ARGS[@]}"

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo ""
    echo "✓ All tests passed!"
    if [ "$COVERAGE" = true ]; then
        echo "  Coverage report: htmlcov/index.html"
    fi
else
    echo ""
    echo "✗ Tests failed (exit code: $EXIT_CODE)"
fi

exit $EXIT_CODE
