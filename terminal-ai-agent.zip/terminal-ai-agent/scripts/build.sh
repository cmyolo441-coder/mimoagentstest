#!/usr/bin/env bash
# build.sh - Build project
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$PROJECT_ROOT"

if [ -d "venv" ]; then
    source venv/bin/activate
fi

echo "Building project..."

# Python build
if [ -f "pyproject.toml" ]; then
    echo "Building Python package..."
    pip install --upgrade build
    python -m build
    echo "✓ Python package built in dist/"
fi

# Node.js build
if [ -f "package.json" ] && command -v npm &>/dev/null; then
    if grep -q '"build"' package.json; then
        echo "Building Node.js project..."
        npm run build
        echo "✓ Node.js project built"
    fi
fi

# Go build
if [ -f "go.mod" ]; then
    echo "Building Go binary..."
    mkdir -p bin
    go build -o bin/ .
    echo "✓ Go binary built in bin/"
fi

# Rust build
if [ -f "Cargo.toml" ]; then
    echo "Building Rust binary..."
    cargo build --release
    echo "✓ Rust binary built in target/release/"
fi

echo ""
echo "✓ Build complete!"
