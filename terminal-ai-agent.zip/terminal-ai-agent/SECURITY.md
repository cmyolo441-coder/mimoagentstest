# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | :white_check_mark: |

## Reporting a Vulnerability

We take security seriously. If you discover a security vulnerability in Terminal Agent, please report it responsibly.

### How to Report

**DO NOT** open a public GitHub issue for security vulnerabilities.

Instead, please email [security@terminal-agent.dev](mailto:security@terminal-agent.dev) with:

1. **Description** — A clear description of the vulnerability
2. **Impact** — What an attacker could achieve by exploiting this vulnerability
3. **Reproduction** — Step-by-step instructions to reproduce the issue
4. **Affected versions** — Which versions of Terminal Agent are affected
5. **Suggested fix** — If you have one (optional)

### What to Expect

- **Acknowledgment** within 48 hours
- **Initial assessment** within 5 business days
- **Status update** every 7 days until resolved
- **Credit** in the security advisory (unless you prefer anonymity)

### Response Timeline

| Severity | Response Time | Fix Timeline |
|----------|---------------|--------------|
| Critical | 24 hours      | 7 days       |
| High     | 48 hours      | 14 days      |
| Medium   | 5 business days | 30 days    |
| Low      | 5 business days | Next release |

## Security Architecture

### Safety Levels

Terminal Agent implements a six-level safety system:

| Level | Name | Description |
|-------|------|-------------|
| 0 | Unrestricted | No safety checks (development only) |
| 1 | Minimal | Blocks catastrophic commands only |
| 2 | Standard | Blocks destructive commands, confirms modifications (default) |
| 3 | Moderate | Confirms all writes and executions |
| 4 | Strict | Confirms everything, read-only by default |
| 5 | Review | Plan only, no execution without explicit approval |

### Built-in Protections

- **Command blocking** — Dangerous commands (rm -rf /, fork bombs, etc.) are blocked
- **Path restrictions** — Sensitive directories (/etc, /boot, SSH keys) are protected
- **Confirmation prompts** — Destructive actions require user confirmation
- **Audit logging** — All safety decisions are recorded
- **Sandbox mode** — Run in isolated environment for untrusted operations
- **Emergency stop** — Immediate halt capability (Ctrl+C)
- **Backup before edit** — Files are backed up before modification

### API Key Security

- API keys are encrypted at rest using AES-256-GCM
- Keys are stored in `~/.terminal-agent/keys/` with restricted permissions (0600)
- Keys are never logged or included in traces
- Keys are loaded only when needed and cleared from memory after use
- Environment variables take precedence over stored keys

### Network Security

- All LLM API calls use TLS/HTTPS
- Certificate validation is enforced
- Proxy support for corporate environments
- Rate limiting prevents accidental API abuse
- No data is sent to external services without explicit configuration

### Data Privacy

- All data is stored locally by default
- No telemetry without explicit opt-in
- Memory and traces are stored in local SQLite databases
- Vector embeddings are stored locally (ChromaDB)
- Cloud vector stores (Pinecone, etc.) are opt-in only

## Security Best Practices for Users

1. **Keep Terminal Agent updated** — `terminal-agent update`
2. **Use Standard safety level** (default) for daily use
3. **Review confirmation prompts** before approving destructive actions
4. **Use environment variables** for API keys in CI/CD environments
5. **Enable audit logging** in production environments
6. **Use sandbox mode** when running untrusted tasks
7. **Back up your data** before large-scale refactoring tasks
8. **Review traces** for sensitive operations

## Dependency Security

- Dependencies are scanned for vulnerabilities using `pip-audit` and GitHub Dependabot
- Security updates for dependencies are applied promptly
- The dependency tree is reviewed before each release
- Minimal dependency footprint — only essential packages are included

## Known Security Limitations

1. **Shell execution** — The agent can execute arbitrary shell commands. Safety guardrails mitigate but cannot eliminate all risks.
2. **LLM prompt injection** — Malicious content in files or web pages could potentially influence the agent's behavior. The safety system includes prompt injection detection.
3. **Local file access** — The agent can read and write files on the local system. Path restrictions and confirmation prompts provide protection.

## Security Advisories

Security advisories are published on the [GitHub Security Advisories](https://github.com/terminal-agent/terminal-agent/security/advisories) page.

## Contact

- Security issues: [security@terminal-agent.dev](mailto:security@terminal-agent.dev)
- General questions: [GitHub Discussions](https://github.com/terminal-agent/terminal-agent/discussions)
