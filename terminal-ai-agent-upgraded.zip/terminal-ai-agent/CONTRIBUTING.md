# Contributing to Terminal Agent

Thank you for your interest in contributing to Terminal Agent! This document provides guidelines and information for contributors.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [How to Contribute](#how-to-contribute)
- [Pull Request Process](#pull-request-process)
- [Coding Standards](#coding-standards)
- [Testing Requirements](#testing-requirements)
- [Documentation](#documentation)
- [Community](#community)

## Code of Conduct

This project follows our [Code of Conduct](CODE_OF_CONDUCT.md). By participating, you agree to uphold this code. Please report unacceptable behavior to [conduct@terminal-agent.dev](mailto:conduct@terminal-agent.dev).

## Getting Started

### Prerequisites

- Python 3.10+
- Git
- An LLM API key for testing (OpenAI, Anthropic, or Ollama for local development)

### Fork and Clone

1. Fork the repository on GitHub
2. Clone your fork:
   ```bash
   git clone https://github.com/YOUR_USERNAME/terminal-agent.git
   cd terminal-agent
   ```
3. Add the upstream remote:
   ```bash
   git remote add upstream https://github.com/terminal-agent/terminal-agent.git
   ```

## Development Setup

### Quick Setup

```bash
# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate   # Windows

# Install in development mode with all dev dependencies
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install

# Run the test suite to verify setup
make test
```

### Using the Dev Script

```bash
# Automated development environment setup
./scripts/dev_setup.sh
```

This script:
- Creates and configures the virtual environment
- Installs all dependencies
- Sets up pre-commit hooks
- Creates a default configuration file
- Runs the initial test suite

### Docker Development

```bash
# Build and start the development environment
docker-compose -f docker-compose.dev.yml up -d

# Run tests inside the container
docker-compose -f docker-compose.dev.yml exec agent make test

# Open a shell in the container
docker-compose -f docker-compose.dev.yml exec agent bash
```

## How to Contribute

### Reporting Bugs

1. Check existing [issues](https://github.com/terminal-agent/terminal-agent/issues) to avoid duplicates
2. Use the [bug report template](https://github.com/terminal-agent/terminal-agent/issues/new?template=bug_report.md)
3. Include:
   - Clear description of the bug
   - Steps to reproduce
   - Expected vs actual behavior
   - Terminal Agent version (`terminal-agent --version`)
   - Python version (`python --version`)
   - Operating system
   - Relevant logs or error messages

### Suggesting Features

1. Check existing [issues](https://github.com/terminal-agent/terminal-agent/issues) and [discussions](https://github.com/terminal-agent/terminal-agent/discussions)
2. Use the [feature request template](https://github.com/terminal-agent/terminal-agent/issues/new?template=feature_request.md)
3. Describe:
   - The problem your feature solves
   - Your proposed solution
   - Alternatives considered
   - Impact on existing functionality

### Contributing Code

1. **Find or create an issue** — All contributions should be tied to an issue
2. **Comment on the issue** — Let others know you're working on it
3. **Create a branch** from `main`:
   ```bash
   git checkout -b feature/your-feature-name
   # or
   git checkout -b fix/your-bug-fix
   ```
4. **Make your changes** following our coding standards
5. **Write or update tests** for your changes
6. **Update documentation** if needed
7. **Submit a pull request**

### Branch Naming

- `feature/description` — New features
- `fix/description` — Bug fixes
- `docs/description` — Documentation changes
- `refactor/description` — Code refactoring
- `test/description` — Test additions or fixes
- `perf/description` — Performance improvements

## Pull Request Process

### Before Submitting

- [ ] Code follows the project's coding standards
- [ ] All tests pass (`make test`)
- [ ] Linter passes (`make lint`)
- [ ] Type checking passes (`make type-check`)
- [ ] New code has tests (aim for >90% coverage)
- [ ] Documentation is updated if needed
- [ ] Commit messages follow our conventions
- [ ] Branch is up-to-date with `main`

### PR Guidelines

1. **One feature per PR** — Keep changes focused
2. **Clear description** — Explain what and why
3. **Reference issues** — Use `Fixes #123` or `Relates to #123`
4. **Small, focused commits** — Each commit should be a logical unit
5. **Update CHANGELOG.md** — Add your changes to the Unreleased section

### Review Process

1. A maintainer will review your PR within 5 business days
2. Address any requested changes
3. Once approved, a maintainer will merge your PR
4. Your contribution will be included in the next release

## Coding Standards

### Python Style

- **Formatter**: Ruff (replaces Black, isort, flake8)
- **Line length**: 100 characters
- **Target version**: Python 3.10
- **Type hints**: Required for all function signatures (mypy strict mode)
- **Docstrings**: Google style for all public functions and classes

```python
async def execute_tool(
    tool_name: str,
    parameters: dict[str, Any],
    timeout: float = 300.0,
) -> ToolResult:
    """Execute a tool by name with the given parameters.

    Args:
        tool_name: The registered name of the tool to execute.
        parameters: Parameters to pass to the tool.
        timeout: Maximum execution time in seconds.

    Returns:
        A ToolResult containing the output, exit code, and metadata.

    Raises:
        ToolNotFoundError: If the tool is not registered.
        ToolExecutionError: If the tool fails to execute.
        SafetyViolationError: If the tool call is blocked by safety rules.
    """
    ...
```

### Commit Messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
type(scope): description

[optional body]

[optional footer]
```

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Formatting (no code change)
- `refactor`: Code refactoring
- `test`: Adding or updating tests
- `perf`: Performance improvement
- `ci`: CI/CD changes
- `chore`: Maintenance tasks

Examples:
```
feat(tools): add database migration tool
fix(memory): prevent duplicate memory entries
docs(api): update tool API reference
test(git): add integration tests for merge conflicts
```

## Testing Requirements

### Test Types

| Type | Location | When to Run | Speed |
|------|----------|-------------|-------|
| Unit | `tests/unit/` | Every commit | <60s |
| Integration | `tests/integration/` | Every PR | <5min |
| E2E | `tests/e2e/` | Release candidates | <15min |
| Performance | `tests/performance/` | Release candidates | <10min |
| Chaos | `tests/chaos/` | Weekly | <10min |

### Writing Tests

```python
import pytest
from terminal_agent.tools.filesystem.read import ReadFileTool

class TestReadFileTool:
    """Tests for the ReadFileTool."""

    @pytest.fixture
    def tool(self):
        """Create a ReadFileTool instance."""
        return ReadFileTool()

    async def test_read_existing_file(self, tool, tmp_path):
        """Test reading a file that exists."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello, World!")

        result = await tool.execute(path=str(test_file))

        assert result.exit_code == 0
        assert result.output == "Hello, World!"

    async def test_read_nonexistent_file(self, tool, tmp_path):
        """Test reading a file that does not exist."""
        result = await tool.execute(path=str(tmp_path / "missing.txt"))

        assert result.exit_code != 0
        assert "not found" in result.error.lower()

    @pytest.mark.parametrize("content", [
        "",
        "a" * 1000000,
        "Unicode: 你好世界 🌍",
        "Special: \n\t\r\0",
    ])
    async def test_read_various_content(self, tool, tmp_path, content):
        """Test reading files with various content types."""
        test_file = tmp_path / "test.txt"
        test_file.write_text(content)

        result = await tool.execute(path=str(test_file))

        assert result.exit_code == 0
        assert result.output == content
```

### Running Tests

```bash
# All tests
make test

# Unit tests only
make test-unit

# Integration tests only
make test-integration

# Specific test file
pytest tests/unit/test_tools/test_filesystem/test_read.py

# With coverage
make test-cov

# Verbose output
pytest -xvs tests/unit/test_tools/test_filesystem/
```

## Documentation

### Types of Documentation

1. **Code comments** — Explain *why*, not *what*
2. **Docstrings** — Google style for all public APIs
3. **User guide** — `docs/user-guide/` for end users
4. **Developer guide** — `docs/developer-guide/` for contributors
5. **Architecture docs** — `docs/architecture/` for system design
6. **API reference** — `docs/api/` for programmatic interfaces
7. **Tutorials** — `docs/tutorials/` for step-by-step guides

### Building Docs

```bash
# Generate API documentation
./scripts/generate_docs.sh

# Check documentation links
make docs-check
```

## Community

### Getting Help

- [GitHub Discussions](https://github.com/terminal-agent/terminal-agent/discussions) — Ask questions and share ideas
- [Discord](https://discord.gg/terminal-agent) — Real-time chat with the community
- [Stack Overflow](https://stackoverflow.com/questions/tagged/terminal-agent) — Tagged questions

### Staying Updated

- Watch the repository for notifications
- Follow [@terminalagent](https://twitter.com/terminalagent) on Twitter
- Read the [blog](https://blog.terminal-agent.dev) for updates

## Recognition

Contributors are recognized in:
- The [CONTRIBUTORS](https://github.com/terminal-agent/terminal-agent/graphs/contributors) page
- Release notes for their contributions
- The project README (for significant contributions)

## Questions?

If you have questions about contributing, feel free to:
1. Open a [discussion](https://github.com/terminal-agent/terminal-agent/discussions)
2. Ask on [Discord](https://discord.gg/terminal-agent)
3. Email [contributors@terminal-agent.dev](mailto:contributors@terminal-agent.dev)

Thank you for contributing to Terminal Agent! 🎉
