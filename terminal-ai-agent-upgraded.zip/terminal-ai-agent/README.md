# Terminal AI Agent

[![CI](https://github.com/terminal-agent/terminal-agent/actions/workflows/ci.yml/badge.svg)](https://github.com/terminal-agent/terminal-agent/actions/workflows/ci.yml)
[![Tests](https://github.com/terminal-agent/terminal-agent/actions/workflows/tests.yml/badge.svg)](https://github.com/terminal-agent/terminal-agent/actions/workflows/tests.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

**The most powerful terminal-based autonomous AI agent.** Tell it what you want in plain English — it plans, executes, verifies, and learns until the job is done.

---

## What Is Terminal Agent?

Terminal Agent is a fully autonomous AI agent that operates inside your terminal. It accepts goals in natural language, creates multi-step plans, executes them using 40+ built-in tools, verifies every result, recovers from errors automatically, and continuously improves from every task it performs.

```bash
# Install
pip install terminal-agent

# Run a task
terminal-agent run "Add authentication to my Express API with JWT tokens"

# Interactive chat
terminal-agent chat
```

## Key Features

| Feature | Description |
|---------|-------------|
| **Autonomous Execution** | Plans and executes multi-step tasks without intervention |
| **40+ Built-in Tools** | Shell, filesystem, code, git, packages, databases, Docker, networking, testing, DevOps |
| **15+ LLM Providers** | OpenAI, Anthropic, Google, Ollama, LiteLLM, Azure, Bedrock, Groq, DeepSeek, and more |
| **Three-Tier Memory** | Short-term, working, and long-term memory with vector semantic search |
| **Self-Improving** | Learns patterns from every task; gets measurably better over time |
| **Safety First** | Six safety levels, destructive action blocking, confirmation prompts, audit trails |
| **Plugin System** | Extend with custom tools, providers, memory backends, and more |
| **MCP Integration** | Full Model Context Protocol client and server support |
| **Multi-Model** | Route different task types to different models for optimal quality, speed, and cost |
| **TUI Interface** | Rich terminal UI with themes, progress bars, diff views, and dashboards |

## Quick Start

### Prerequisites

- Python 3.10 or higher
- An LLM API key (OpenAI, Anthropic, Google, or a local Ollama instance)

### Install

```bash
pip install terminal-agent
```

### Configure

```bash
# Set your API key
terminal-agent config set llm.openai.api_key "sk-..."

# Or use Anthropic
terminal-agent config set llm.anthropic.api_key "sk-ant-..."

# Or use a local model
terminal-agent config set llm.primary_provider ollama
terminal-agent config set llm.ollama.model llama3
```

### Run

```bash
# One-shot task
terminal-agent run "Create a Python FastAPI server with user authentication"

# Interactive mode
terminal-agent chat

# Resume a previous session
terminal-agent sessions resume <session-id>
```

## How It Works

Terminal Agent follows the **Think → Act → Observe → Verify** loop:

1. **Goal Analysis** — Understands your request and generates a plan
2. **Context Assembly** — Gathers relevant files, memories, and environment info
3. **LLM Reasoning** — The model thinks about the next step and chooses a tool
4. **Safety Check** — Validates the action against safety rules
5. **Tool Execution** — Runs the tool (shell command, file edit, git operation, etc.)
6. **Verification** — Checks the result for correctness
7. **Memory Update** — Stores what was learned
8. **Progress Check** — Determines if the goal is achieved or if more steps are needed

This loop continues until the task is complete, an error requires human input, or termination conditions are met.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INTERFACE LAYER                       │
│         CLI (click)  │  TUI (textual)  │  Config (toml)      │
├─────────────────────────────────────────────────────────────┤
│                    INTELLIGENCE LAYER                         │
│  Orchestrator │ LLM Engine │ Memory │ Context │ Prompts      │
├─────────────────────────────────────────────────────────────┤
│                    CAPABILITY LAYER                           │
│  Shell │ Filesystem │ Code │ Git │ Packages │ Database       │
│  Docker │ Network │ Search │ Testing │ Docs │ DevOps         │
├─────────────────────────────────────────────────────────────┤
│                    FOUNDATION LAYER                           │
│  Safety │ Verification │ Error Recovery │ Self-Improvement   │
│  Persistence │ Cache │ Logging │ Tracing │ Metrics           │
│  Plugins │ MCP │ Rate Limiting │ Notifications               │
└─────────────────────────────────────────────────────────────┘
```

See [ARCHITECTURE.md](ARCHITECTURE.md) for the full architectural deep dive.

## Documentation

| Document | Description |
|----------|-------------|
| [Getting Started](docs/getting-started/installation.md) | Installation, quickstart, first task |
| [User Guide](docs/user-guide/cli-reference.md) | CLI reference, TUI guide, configuration |
| [Developer Guide](docs/developer-guide/architecture.md) | Contributing, extending, testing |
| [Architecture](docs/architecture/overview.md) | System design, agent loop, memory, safety |
| [API Reference](docs/api/cli-api.md) | Complete API documentation |
| [Tutorials](docs/tutorials/build-web-app.md) | Step-by-step guides for common tasks |
| [FAQ](docs/faq.md) | Frequently asked questions |

## Supported Technologies

### Languages

Python, JavaScript, TypeScript, Go, Rust, Java, C, C++, C#, Ruby, PHP, Swift, Kotlin, Scala, Haskell, Elixir, Lua, Zig, Dart, R

### Package Managers

npm, yarn, pnpm, bun, pip, pipenv, poetry, conda, uv, cargo, go mod, maven, gradle, composer, gem, bundler, pub, mix, apt, brew, choco, and more

### Databases

PostgreSQL, MySQL, MariaDB, SQLite, MongoDB, Redis, Elasticsearch, Cassandra, DynamoDB, CouchDB, Firestore

### Infrastructure

Docker, Docker Compose, Kubernetes, Terraform, Ansible, GitHub Actions, GitLab CI, Jenkins

## Examples

### Build a Web Application

```bash
terminal-agent run "Create a React dashboard with a Node.js API backend, 
PostgreSQL database, Docker Compose setup, and GitHub Actions CI/CD pipeline"
```

### Fix a Bug

```bash
terminal-agent run "The login endpoint returns 500 when the email field is missing. 
Find and fix the bug, add proper validation, and write tests for it."
```

### Refactor Code

```bash
terminal-agent run "Refactor the authentication module to use the strategy pattern 
so we can easily add OAuth, SAML, and API key auth methods."
```

### Database Migration

```bash
terminal-agent run "Create a database migration to add a 'roles' table and 
a 'user_roles' junction table. Update the User model accordingly."
```

## Contributing

We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

```bash
# Clone and setup
git clone https://github.com/terminal-agent/terminal-agent.git
cd terminal-agent
pip install -e ".[dev]"

# Run tests
make test

# Run linter
make lint
```

## License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

## Security

For security concerns, see [SECURITY.md](SECURITY.md). Please report vulnerabilities responsibly.

## Acknowledgments

Built on the shoulders of incredible open-source projects: [OpenAI](https://openai.com), [Anthropic](https://anthropic.com), [Textual](https://textual.textualize.io/), [Rich](https://rich.readthedocs.io/), [ChromaDB](https://www.trychroma.com/), [Click](https://click.palletsprojects.com/), and many more.
