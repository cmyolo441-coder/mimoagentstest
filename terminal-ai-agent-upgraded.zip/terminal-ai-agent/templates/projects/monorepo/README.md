# {{ project_name }}

Monorepo with multiple packages.

## Structure

```
├── packages/
│   ├── api/          # Backend API
│   ├── web/          # Frontend app
│   ├── shared/       # Shared library
│   └── cli/          # CLI tool
├── infrastructure/   # IaC configs
└── scripts/          # Build scripts
```

## Quick Start

```bash
# Install dependencies
npm install

# Run all packages in dev mode
npm run dev

# Build all packages
npm run build

# Run tests
npm run test
```

## Development

```bash
# Work on a specific package
cd packages/api
npm run dev

# Run a single package's tests
npm run test --workspace=packages/api
```

## License

{{ license }}
