export function formatDate(date: Date): string {
  return date.toISOString();
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export type Result<T> =
  | { success: true; data: T }
  | { success: false; error: string };
