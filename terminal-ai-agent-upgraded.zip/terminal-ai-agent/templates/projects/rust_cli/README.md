# {{ project_name }}

A Rust CLI application.

## Build

```bash
cargo build --release
```

## Run

```bash
cargo run -- --help
cargo run -- run --input data.txt
```

## Test

```bash
cargo test
cargo test -- --nocapture
```

## Lint

```bash
cargo clippy -- -D warnings
cargo fmt --check
```

## License

{{ license }}
