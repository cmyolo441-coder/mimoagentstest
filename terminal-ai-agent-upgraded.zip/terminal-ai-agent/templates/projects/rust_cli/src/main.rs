use anyhow::Result;
use clap::{Parser, Subcommand};
use tracing::info;
use tracing_subscriber::EnvFilter;

#[derive(Parser)]
#[command(name = "{{ project_slug }}")]
#[command(version = "{{ version }}")]
#[command(about = "{{ project_name }} - {{ description }}")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Run the main process
    Run {
        /// Input file path
        #[arg(short, long)]
        input: String,

        /// Output file path
        #[arg(short, long)]
        output: Option<String>,

        /// Enable verbose output
        #[arg(short, long)]
        verbose: bool,
    },
    /// Display system information
    Info,
}

fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env())
        .init();

    let cli = Cli::parse();

    match cli.command {
        Commands::Run {
            input,
            output,
            verbose,
        } => {
            if verbose {
                info!("Processing file: {}", input);
            }

            let data = std::fs::read_to_string(&input)?;
            let result = data.trim().to_lowercase();

            match output {
                Some(path) => {
                    std::fs::write(&path, &result)?;
                    println!("Output written to: {}", path);
                }
                None => println!("{}", result),
            }
        }
        Commands::Info => {
            println!("{{ project_name }} v{{ version }}");
            println!("Rust {}", env!("CARGO_PKG_RUST_VERSION"));
        }
    }

    Ok(())
}
