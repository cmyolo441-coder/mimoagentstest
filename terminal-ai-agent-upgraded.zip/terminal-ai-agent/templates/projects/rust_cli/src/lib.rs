#[cfg(test)]
mod tests {
    #[test]
    fn test_cli_help() {
        let mut cmd = assert_cmd::Command::cargo_bin("{{ project_slug }}").unwrap();
        cmd.arg("--help").assert().success();
    }

    #[test]
    fn test_cli_version() {
        let mut cmd = assert_cmd::Command::cargo_bin("{{ project_slug }}").unwrap();
        cmd.arg("--version").assert().success();
    }
}
