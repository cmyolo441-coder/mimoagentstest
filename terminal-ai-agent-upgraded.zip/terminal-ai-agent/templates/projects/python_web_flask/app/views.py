"""Main application views."""

from flask import Blueprint, jsonify

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index() -> dict[str, str]:
    """Root endpoint."""
    return jsonify(message="Welcome to {{ project_name }}")
