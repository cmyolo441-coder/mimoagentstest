"""API endpoints."""

from flask import Blueprint, jsonify, request

api_bp = Blueprint("api", __name__)


@api_bp.route("/status")
def status() -> dict[str, str]:
    """API status endpoint."""
    return jsonify(status="ok", version="1.0.0")


@api_bp.route("/items", methods=["GET"])
def list_items() -> dict[str, list]:
    """List all items."""
    # Replace with actual database query
    items = [
        {"id": 1, "name": "Item 1"},
        {"id": 2, "name": "Item 2"},
    ]
    return jsonify(items=items)


@api_bp.route("/items", methods=["POST"])
def create_item() -> tuple[dict, int]:
    """Create a new item."""
    data = request.get_json()
    if not data or "name" not in data:
        return jsonify(error="Name is required"), 400

    # Replace with actual database insert
    item = {"id": 3, "name": data["name"]}
    return jsonify(item=item), 201
