# {{ project_name }}

A Flask web application.

## Setup

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Configuration

Copy `.env.example` to `.env` and configure your settings:

```bash
cp .env.example .env
```

## Running

```bash
# Development
flask run --debug

# Production
gunicorn -w 4 -b 0.0.0.0:8000 "app:create_app()"
```

## Testing

```bash
pytest
```

## License

{{ license }}
