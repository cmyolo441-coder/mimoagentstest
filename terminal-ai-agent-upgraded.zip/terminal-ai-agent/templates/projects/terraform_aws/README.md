# {{ project_name }}

Terraform configuration for AWS infrastructure.

## Prerequisites

- Terraform >= 1.7
- AWS CLI configured

## Usage

```bash
terraform init
terraform plan
terraform apply
```

## Destroy

```bash
terraform destroy
```

## License

{{ license }}
