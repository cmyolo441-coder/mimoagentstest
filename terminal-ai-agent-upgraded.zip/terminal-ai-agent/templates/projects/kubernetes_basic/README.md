# {{ project_name }}

Kubernetes deployment manifests.

## Prerequisites

- kubectl configured
- Docker images pushed to registry

## Deploy

```bash
kubectl apply -f k8s/
```

## Verify

```bash
kubectl get pods
kubectl get services
kubectl get ingress
```

## Scale

```bash
kubectl scale deployment app --replicas=3
```

## Logs

```bash
kubectl logs -f deployment/app
```

## License

{{ license }}
