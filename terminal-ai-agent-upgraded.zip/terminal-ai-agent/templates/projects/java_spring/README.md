# {{ project_name }}

A Spring Boot Java application.

## Prerequisites

- Java 21+
- Maven 3.9+

## Setup

```bash
mvn clean install
```

## Run

```bash
mvn spring-boot:run
```

## Build

```bash
mvn clean package
java -jar target/{{ project_slug }}-{{ version }}.jar
```

## Test

```bash
mvn test
```

## API Endpoints

- `GET /health` - Health check
- `GET /api/v1/items` - List items
- `POST /api/v1/items` - Create item
- `GET /api/v1/items/{id}` - Get item

## License

{{ license }}
