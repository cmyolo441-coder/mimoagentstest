package com.example.{{ project_slug }}.repository;

import com.example.{{ project_slug }}.model.Item;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemRepository extends JpaRepository<Item, Long> {
}
