"""{{ project_name }} - Django Web Application."""
