# {{ project_name }}

A Django web application.

## Setup

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

## Configuration

```bash
cp .env.example .env
# Edit .env with your settings
```

## API Documentation

- Swagger UI: http://localhost:8000/api/docs/
- ReDoc: http://localhost:8000/api/redoc/

## Testing

```bash
python manage.py test
# or
pytest
```

## License

{{ license }}
