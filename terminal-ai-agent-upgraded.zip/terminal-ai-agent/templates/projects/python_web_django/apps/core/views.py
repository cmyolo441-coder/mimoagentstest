"""Core views."""
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Item
from .serializers import ItemSerializer


class ItemViewSet(viewsets.ModelViewSet):
    """ViewSet for Item model."""

    queryset = Item.objects.all()
    serializer_class = ItemSerializer

    @action(detail=False, methods=["get"])
    def active(self, request):
        """List active items only."""
        items = self.queryset.filter(active=True)
        serializer = self.get_serializer(items, many=True)
        return Response(serializer.data)
