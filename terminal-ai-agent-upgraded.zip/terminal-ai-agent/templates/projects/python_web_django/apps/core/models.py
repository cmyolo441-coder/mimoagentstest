"""Core models."""
from django.db import models


class TimestampedModel(models.Model):
    """Base model with timestamps."""

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Item(TimestampedModel):
    """Example item model."""

    name = models.CharField(max_length=255, db_index=True)
    description = models.TextField(blank=True)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return self.name
