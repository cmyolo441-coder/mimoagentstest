"""Core admin."""
from django.contrib import admin

from .models import Item


@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    list_display = ["name", "active", "created_at"]
    list_filter = ["active"]
    search_fields = ["name"]
