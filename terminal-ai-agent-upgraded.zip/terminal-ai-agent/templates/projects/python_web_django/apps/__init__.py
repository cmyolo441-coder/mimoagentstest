"""Core application."""
