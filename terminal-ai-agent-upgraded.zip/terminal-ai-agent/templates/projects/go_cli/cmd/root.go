package cmd

import (
	"fmt"

	"github.com/spf13/cobra"
)

var rootCmd = &cobra.Command{
	Use:   "{{ project_slug }}",
	Short: "{{ project_name }} - {{ description }}",
	Long:  `{{ project_name }} is a CLI application for {{ description }}.`,
}

func Execute() error {
	return rootCmd.Execute()
}

func init() {
	rootCmd.AddCommand(versionCmd)
	rootCmd.AddCommand(runCmd)
}

var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "Print version information",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Printf("{{ project_name }} v{{ version }}\n")
	},
}

var runCmd = &cobra.Command{
	Use:   "run",
	Short: "Run the main process",
	RunE: func(cmd *cobra.Command, args []string) error {
		input, _ := cmd.Flags().GetString("input")
		verbose, _ := cmd.Flags().GetBool("verbose")

		if verbose {
			fmt.Printf("Processing: %s\n", input)
		}

		// Add your logic here
		fmt.Println("Processing complete")
		return nil
	},
}

func init() {
	runCmd.Flags().StringP("input", "i", "", "Input file path")
	runCmd.Flags().BoolP("verbose", "v", false, "Enable verbose output")
}
