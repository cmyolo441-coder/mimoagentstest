package cmd

import (
	"testing"

	"github.com/spf13/cobra"
)

func TestVersionCommand(t *testing.T) {
	cmd := &cobra.Command{}
	cmd.AddCommand(versionCmd)

	cmd.SetArgs([]string{"version"})
	if err := cmd.Execute(); err != nil {
		t.Errorf("version command failed: %v", err)
	}
}
