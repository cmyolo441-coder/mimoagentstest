# {{ project_name }}

A Go CLI application built with Cobra.

## Setup

```bash
go mod download
```

## Build

```bash
go build -o bin/{{ project_slug }} .
```

## Run

```bash
./bin/{{ project_slug }} --help
./bin/{{ project_slug }} run --input data.txt
```

## Test

```bash
go test ./...
go test -cover ./...
```

## Lint

```bash
golangci-lint run
```

## License

{{ license }}
