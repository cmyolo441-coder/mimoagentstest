# {{ project_name }}

A Next.js application with TypeScript.

## Setup

```bash
npm install
```

## Development

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Build

```bash
npm run build
npm start
```

## Testing

```bash
npm test
```

## License

{{ license }}
