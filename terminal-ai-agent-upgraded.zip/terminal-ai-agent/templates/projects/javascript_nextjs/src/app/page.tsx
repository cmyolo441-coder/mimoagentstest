export default function Home() {
  return (
    <main>
      <h1>{{ project_name }}</h1>
      <p>Welcome to your Next.js application.</p>
    </main>
  );
}
