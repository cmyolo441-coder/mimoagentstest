"""{{ project_name }} - A Python CLI application."""

__version__ = "{{ version }}"
