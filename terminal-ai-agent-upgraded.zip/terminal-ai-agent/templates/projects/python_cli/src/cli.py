"""Command-line interface for {{ project_name }}."""

import sys

import click
from rich.console import Console

console = Console()


@click.group()
@click.version_option(package_name="{{ project_slug }}")
def main() -> None:
    """{{ project_name }} - {{ description }}"""
    pass


@main.command()
@click.argument("input_file", type=click.Path(exists=True))
@click.option("--output", "-o", type=click.Path(), help="Output file path")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
def run(input_file: str, output: str | None, verbose: bool) -> None:
    """Run the main process on INPUT_FILE."""
    if verbose:
        console.print(f"[bold blue]Processing:[/] {input_file}")

    try:
        with open(input_file) as f:
            data = f.read()

        # Process data here
        result = data.strip()

        if output:
            with open(output, "w") as f:
                f.write(result)
            console.print(f"[bold green]Output written to:[/] {output}")
        else:
            console.print(result)

    except Exception as e:
        console.print(f"[bold red]Error:[/] {e}")
        sys.exit(1)


@main.command()
def info() -> None:
    """Display system and configuration information."""
    console.print(f"[bold]{{ project_name }}[/] v{{ version }}")
    console.print(f"Python: {sys.version}")


if __name__ == "__main__":
    main()
