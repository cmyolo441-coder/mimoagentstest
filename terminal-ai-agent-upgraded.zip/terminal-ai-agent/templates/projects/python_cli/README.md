# {{ project_name }}

A Python CLI application built with Click.

## Installation

```bash
pip install -e ".[dev]"
```

## Usage

```bash
{{ project_slug }} --help
{{ project_slug }} run --input data.txt
```

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run linter
ruff check .

# Format code
ruff format .
```

## License

{{ license }}
