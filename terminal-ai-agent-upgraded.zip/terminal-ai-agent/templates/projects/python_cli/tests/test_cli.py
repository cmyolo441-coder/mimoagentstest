"""Tests for the CLI interface."""

from click.testing import CliRunner

from cli import main


def test_main_help() -> None:
    """Test that the help command works."""
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "Usage" in result.output


def test_info_command() -> None:
    """Test the info command."""
    runner = CliRunner()
    result = runner.invoke(main, ["info"])
    assert result.exit_code == 0


def test_run_with_missing_file() -> None:
    """Test run command with non-existent file."""
    runner = CliRunner()
    result = runner.invoke(main, ["run", "nonexistent.txt"])
    assert result.exit_code != 0
