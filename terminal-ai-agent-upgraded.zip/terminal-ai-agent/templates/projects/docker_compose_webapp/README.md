# {{ project_name }}

Docker Compose web application stack.

## Services

- **app** - Application server
- **db** - PostgreSQL database
- **redis** - Redis cache
- **nginx** - Reverse proxy

## Quick Start

```bash
docker compose up -d
```

## Development

```bash
docker compose -f docker-compose.yml up -d
docker compose logs -f app
```

## Stop

```bash
docker compose down
docker compose down -v  # also remove volumes
```

## License

{{ license }}
