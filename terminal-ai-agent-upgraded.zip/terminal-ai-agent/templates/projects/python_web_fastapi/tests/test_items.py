"""Tests for items endpoints."""

import pytest


@pytest.mark.asyncio
async def test_health(client):
    response = await client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


@pytest.mark.asyncio
async def test_create_item(client):
    response = await client.post(
        "/api/v1/items/",
        json={"name": "Test Item", "description": "A test item"},
    )
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Test Item"
    assert data["active"] is True


@pytest.mark.asyncio
async def test_list_items(client):
    await client.post("/api/v1/items/", json={"name": "Item 1"})
    await client.post("/api/v1/items/", json={"name": "Item 2"})

    response = await client.get("/api/v1/items/")
    assert response.status_code == 200
    assert len(response.json()) == 2


@pytest.mark.asyncio
async def test_get_item_not_found(client):
    response = await client.get("/api/v1/items/999")
    assert response.status_code == 404
