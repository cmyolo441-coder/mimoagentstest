"""{{ project_name }} - FastAPI Web Application."""
