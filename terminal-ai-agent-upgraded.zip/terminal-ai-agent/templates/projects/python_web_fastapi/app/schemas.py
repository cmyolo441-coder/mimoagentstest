"""Pydantic schemas."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ItemBase(BaseModel):
    """Base item schema."""
    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    active: bool = True


class ItemCreate(ItemBase):
    """Schema for creating items."""
    pass


class ItemUpdate(BaseModel):
    """Schema for updating items."""
    name: str | None = Field(None, min_length=1, max_length=255)
    description: str | None = None
    active: bool | None = None


class ItemResponse(ItemBase):
    """Schema for item responses."""
    id: int
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)
