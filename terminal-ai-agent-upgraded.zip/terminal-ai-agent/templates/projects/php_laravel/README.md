# {{ project_name }}

A Laravel application.

## Prerequisites

- PHP 8.3+
- Composer
- PostgreSQL

## Setup

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate
php artisan db:seed
```

## Run

```bash
php artisan serve
```

## Build Assets

```bash
npm install
npm run dev
npm run build
```

## Test

```bash
php artisan test
# or
vendor/bin/pest
```

## License

{{ license }}
