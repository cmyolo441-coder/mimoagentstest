<?php

use App\Http\Controllers\ItemController;
use Illuminate\Support\Facades\Route;

Route::get('/health', fn () => response()->json(['status' => 'ok']));

Route::prefix('api/v1')->group(function () {
    Route::apiResource('items', ItemController::class);
});
