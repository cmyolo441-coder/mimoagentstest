module {{ project_slug }}

go 1.22

require (
	github.com/gin-gonic/gin v1.10.0
	github.com/jackc/pgx/v5 v5.6.0
	go.uber.org/zap v1.27.0
	gorm.io/gorm v1.25.10
	gorm.io/driver/postgres v1.5.9
)
