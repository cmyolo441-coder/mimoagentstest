package main

import (
	"log"
	"os"

	"{{ project_slug }}/handler"
	"{{ project_slug }}/model"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func main() {
	logger, _ := zap.NewProduction()
	defer logger.Sync()

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	// Initialize database
	db, err := model.InitDB()
	if err != nil {
		log.Fatal("Failed to connect to database:", err)
	}

	// Auto-migrate
	if err := db.AutoMigrate(&model.Item{}); err != nil {
		log.Fatal("Failed to migrate:", err)
	}

	r := gin.Default()

	// Health check
	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})

	// API routes
	h := handler.NewItemHandler(db, logger)
	v1 := r.Group("/api/v1")
	{
		v1.GET("/items", h.ListItems)
		v1.POST("/items", h.CreateItem)
		v1.GET("/items/:id", h.GetItem)
		v1.PUT("/items/:id", h.UpdateItem)
		v1.DELETE("/items/:id", h.DeleteItem)
	}

	if err := r.Run(":" + port); err != nil {
		log.Fatal("Failed to start server:", err)
	}
}
