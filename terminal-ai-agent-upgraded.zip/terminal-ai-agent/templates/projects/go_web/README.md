# {{ project_name }}

A Go web application built with Gin.

## Setup

```bash
go mod download
```

## Run

```bash
go run main.go
```

## Build

```bash
go build -o bin/server .
./bin/server
```

## Test

```bash
go test ./...
```

## API Endpoints

- `GET /health` - Health check
- `GET /api/v1/items` - List items
- `POST /api/v1/items` - Create item
- `GET /api/v1/items/:id` - Get item

## License

{{ license }}
