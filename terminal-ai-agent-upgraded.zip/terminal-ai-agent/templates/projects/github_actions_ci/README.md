# {{ project_name }}

GitHub Actions CI/CD pipeline.

## Workflows

- **ci.yml** - Main CI pipeline (lint, test, build)
- **tests.yml** - Test suite with coverage
- **lint.yml** - Code linting and formatting
- **release.yml** - Automated releases

## Configuration

Add the following secrets to your repository:

- `DOCKER_USERNAME` - Docker Hub username
- `DOCKER_PASSWORD` - Docker Hub password
- `CODECOV_TOKEN` - Codecov upload token (optional)

## License

{{ license }}
