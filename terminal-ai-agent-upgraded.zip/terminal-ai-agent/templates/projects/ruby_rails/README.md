# {{ project_name }}

A Ruby on Rails application.

## Prerequisites

- Ruby 3.3+
- PostgreSQL

## Setup

```bash
bundle install
rails db:create db:migrate db:seed
```

## Run

```bash
bin/dev
# or
rails server
```

## Test

```bash
bundle exec rspec
```

## Lint

```bash
bundle exec rubocop
bundle exec rubocop -A  # auto-fix
```

## License

{{ license }}
