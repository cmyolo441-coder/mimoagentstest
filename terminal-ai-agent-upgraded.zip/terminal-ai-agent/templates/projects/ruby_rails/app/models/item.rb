class Item < ApplicationRecord
  validates :name, presence: true, length: { maximum: 255 }

  scope :active, -> { where(active: true) }
  scope :recent, -> { order(created_at: :desc) }
end
