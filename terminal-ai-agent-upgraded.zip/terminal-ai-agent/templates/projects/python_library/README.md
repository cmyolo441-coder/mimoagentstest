# {{ project_name }}

A Python library for {{ description }}.

## Installation

```bash
pip install {{ project_slug }}
```

## Quick Start

```python
from {{ project_slug }} import Example

result = Example.process("hello")
print(result)
```

## API Reference

### `Example.process(data: str) -> str`
Process the input data and return a result.

## Development

```bash
# Clone and install
git clone https://github.com/{{ github_org }}/{{ project_slug }}.git
cd {{ project_slug }}
pip install -e ".[dev]"

# Run tests
pytest

# Type checking
mypy src/

# Linting & formatting
ruff check .
ruff format .
```

## License

{{ license }}
