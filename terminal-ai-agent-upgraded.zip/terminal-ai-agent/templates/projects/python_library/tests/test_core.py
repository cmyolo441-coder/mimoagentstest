"""Tests for the core module."""

import pytest

from core import Config, Example, Result


class TestExample:
    """Tests for the Example class."""

    def test_process_success(self) -> None:
        """Test successful processing."""
        example = Example()
        result = example.process("Hello World")
        assert result.success is True
        assert result.data == "hello world"

    def test_process_with_config(self) -> None:
        """Test processing with custom config."""
        config = Config(debug=True, max_retries=5)
        example = Example(config=config)
        assert example.config.debug is True
        assert example.config.max_retries == 5

    def test_from_dict(self) -> None:
        """Test creating instance from dictionary."""
        config_dict = {"debug": True, "max_retries": 2}
        example = Example.from_dict(config_dict)
        assert example.config.debug is True


class TestResult:
    """Tests for the Result class."""

    def test_success_result(self) -> None:
        """Test a successful result."""
        result = Result(success=True, data="test")
        assert result.success is True
        assert result.data == "test"

    def test_error_result(self) -> None:
        """Test an error result."""
        result = Result(success=False, error="something went wrong")
        assert result.success is False
        assert result.error == "something went wrong"
