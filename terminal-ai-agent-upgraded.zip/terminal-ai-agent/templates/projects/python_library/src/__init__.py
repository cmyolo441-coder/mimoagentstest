"""{{ project_name }} - A Python library."""

__version__ = "{{ version }}"

from .core import Example

__all__ = ["Example"]
