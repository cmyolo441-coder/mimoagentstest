"""Core functionality for {{ project_name }}."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Config:
    """Configuration for the library."""

    debug: bool = False
    max_retries: int = 3
    timeout: float = 30.0


@dataclass
class Result:
    """Result container."""

    success: bool
    data: Any = None
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class Example:
    """Main class for {{ project_name }}."""

    def __init__(self, config: Config | None = None) -> None:
        self.config = config or Config()

    def process(self, data: str) -> Result:
        """Process input data and return a result.

        Args:
            data: Input string to process.

        Returns:
            Result object with processed data.
        """
        try:
            processed = data.strip().lower()
            return Result(
                success=True,
                data=processed,
                metadata={"length": len(processed)},
            )
        except Exception as e:
            return Result(success=False, error=str(e))

    @classmethod
    def from_dict(cls, config_dict: dict[str, Any]) -> Example:
        """Create an instance from a dictionary."""
        config = Config(**config_dict)
        return cls(config=config)
