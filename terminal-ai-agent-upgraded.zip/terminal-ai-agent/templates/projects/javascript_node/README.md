# {{ project_name }}

A Node.js application built with TypeScript.

## Setup

```bash
npm install
```

## Development

```bash
npm run dev
```

## Build

```bash
npm run build
npm start
```

## Testing

```bash
npm test
npm run test:coverage
```

## Linting

```bash
npm run lint
npm run format
```

## License

{{ license }}
