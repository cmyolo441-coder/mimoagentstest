import { env } from "./config.js";
import { logger } from "./logger.js";

async function main(): Promise<void> {
  logger.info({ env: env.NODE_ENV, port: env.PORT }, "Starting {{ project_name }}");

  // Your application logic here

  const shutdown = async (): Promise<void> => {
    logger.info("Shutting down...");
    process.exit(0);
  };

  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

main().catch((err) => {
  logger.fatal(err, "Failed to start");
  process.exit(1);
});
