import { describe, expect, it } from "vitest";

describe("{{ project_name }}", () => {
  it("should run tests", () => {
    expect(true).toBe(true);
  });
});
