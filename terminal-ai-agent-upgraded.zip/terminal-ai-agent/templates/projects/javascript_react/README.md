# {{ project_name }}

A React application built with Vite and TypeScript.

## Setup

```bash
npm install
```

## Development

```bash
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

## Testing

```bash
npm test
npm run test:coverage
```

## License

{{ license }}
