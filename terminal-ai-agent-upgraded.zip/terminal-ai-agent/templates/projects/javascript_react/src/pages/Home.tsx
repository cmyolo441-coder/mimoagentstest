export function Home() {
  return (
    <main>
      <h1>{{ project_name }}</h1>
      <p>Welcome to your React application.</p>
    </main>
  );
}
