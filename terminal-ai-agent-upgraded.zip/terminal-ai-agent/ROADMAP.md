# Roadmap

This document outlines the planned development trajectory for Terminal Agent. Timelines are estimates and may shift based on community feedback and priorities.

## Current Status

**Version**: 0.1.0 (Alpha)
**Phase**: Foundation complete, actively developing core capabilities

## Phase 1: Foundation (Weeks 1-2) ✅

- [x] Project scaffolding and directory structure
- [x] Build system configuration (pyproject.toml, hatch)
- [x] Linting and formatting (Ruff, mypy)
- [x] Pre-commit hooks
- [x] CI/CD pipeline basics (GitHub Actions)
- [x] Docker development environment
- [x] Global constants, types, exceptions
- [x] Logging configuration
- [x] Testing framework setup

## Phase 2: Configuration & CLI (Weeks 3-4) ✅

- [x] Configuration schema and validation
- [x] TOML configuration files
- [x] Configuration merging (CLI > env > project > global)
- [x] Configuration encryption for API keys
- [x] CLI argument parser with all subcommands
- [x] Shell completion scripts (bash, zsh, fish)
- [x] Output formatting (colored, structured, quiet)

## Phase 3: LLM Engine (Weeks 5-7) 🔄

- [x] LLM engine abstraction layer
- [x] Base provider interface
- [x] OpenAI provider
- [x] Anthropic provider
- [x] Ollama provider (local models)
- [x] Response parser
- [x] Token counter and cost tracker
- [ ] Streaming support (token-by-token)
- [ ] Provider fallback chains
- [ ] Google Gemini provider
- [ ] LiteLLM provider (100+ models)
- [ ] Azure OpenAI provider
- [ ] Rate limiting per provider
- [ ] Response caching

## Phase 4: Core Agent Loop (Weeks 8-10) ⬜

- [ ] Core agent loop (Think-Act-Observe)
- [ ] Goal parser
- [ ] Plan generator and executor
- [ ] Progress tracker
- [ ] Re-planner
- [ ] Session manager (start, pause, resume)
- [ ] Context assembler
- [ ] Prompt templates

## Phase 5: Core Tools (Weeks 11-14) ⬜

- [ ] Tool registry and dispatcher
- [ ] Shell tools (execute, background, pipeline)
- [ ] Filesystem tools (read, write, edit, search)
- [ ] Code tools (AST, symbols, formatting, linting)
- [ ] Safety guardrails
- [ ] Verification engine
- [ ] Error recovery

## Phase 6: Memory System (Weeks 15-17) ⬜

- [ ] Short-term memory (conversation)
- [ ] Working memory (active state)
- [ ] Long-term memory (persistent, vector-embedded)
- [ ] Vector store (ChromaDB, FAISS)
- [ ] Semantic search
- [ ] Memory consolidation and decay
- [ ] Context manager with token budget
- [ ] Prompt manager

## Phase 7: Extended Tools (Weeks 18-21) ⬜

- [ ] Git tools (full integration)
- [ ] Package manager tools (25+ managers)
- [ ] Database tools (PostgreSQL, MySQL, SQLite, MongoDB)
- [ ] Docker tools (build, run, compose)
- [ ] Network tools (HTTP, DNS, SSL)
- [ ] Search tools (regex, semantic, web)
- [ ] Testing tools (15+ frameworks)

## Phase 8: Safety & Verification (Weeks 22-24) ⬜

- [ ] Complete safety system (6 levels)
- [ ] Command pattern blocking
- [ ] Path access control
- [ ] Sandbox mode
- [ ] Complete verification pipeline
- [ ] Error taxonomy and recovery strategies
- [ ] Audit logging

## Phase 9: Self-Improvement (Weeks 25-27) ⬜

- [ ] Trace recording and storage
- [ ] Performance analyzer
- [ ] Pattern learner and matcher
- [ ] Prompt optimizer
- [ ] A/B testing framework
- [ ] Improvement metrics

## Phase 10: TUI, Plugins & MCP (Weeks 28-31) ⬜

- [ ] Complete TUI (all screens, widgets, themes)
- [ ] Real-time streaming display
- [ ] Plugin system (discovery, loading, sandboxing)
- [ ] Plugin API and documentation
- [ ] Example plugins (5+)
- [ ] MCP client
- [ ] MCP server

## Phase 11: Generation & DevOps (Weeks 32-35) ⬜

- [ ] Project scaffolding (20+ frameworks)
- [ ] Code generation (boilerplate, CRUD, APIs)
- [ ] Test generation
- [ ] Documentation generation
- [ ] DevOps tools (Kubernetes, Terraform, Ansible)
- [ ] CI/CD tools (GitHub Actions, GitLab CI)
- [ ] Cloud resource tools (AWS, GCP, Azure)

## Phase 12: Testing & Release (Weeks 36-40) ⬜

- [ ] Complete test suite (unit, integration, e2e, chaos, performance)
- [ ] Performance optimization
- [ ] Memory optimization
- [ ] Complete documentation
- [ ] Installation scripts (pip, brew, apt, Docker)
- [ ] Release automation
- [ ] Cross-platform testing
- [ ] Security audit
- [ ] v1.0 release

## Future Ideas (Post v1.0)

These are ideas being considered for future versions. Community feedback will shape priorities.

### Multi-Agent Collaboration
- Multiple agents working on different parts of a task simultaneously
- Agent-to-agent communication protocol
- Specialized agents (code agent, DevOps agent, testing agent)

### Voice Interface
- Speech-to-text for hands-free operation
- Text-to-speech for audio feedback
- Voice-activated commands

### IDE Integration
- VS Code extension
- JetBrains plugin
- Neovim integration
- Emacs integration

### Web UI
- Browser-based interface for remote access
- Dashboard for monitoring multiple agents
- Team collaboration features

### Cloud Features
- Cloud-hosted agent instances
- Shared memory across team members
- Centralized configuration management
- Usage analytics and reporting

### Advanced Self-Improvement
- Cross-project learning (learn from open-source codebases)
- Community pattern sharing
- Automated prompt evolution using genetic algorithms
- Reinforcement learning from human feedback

### Enterprise Features
- SSO/SAML authentication
- Role-based access control
- Audit log export to SIEM
- Compliance reporting (SOC 2, HIPAA)
- Air-gapped deployment support

## How to Influence the Roadmap

1. **Vote on issues** — Use 👍 reactions on GitHub issues to show priority
2. **Start discussions** — Share your use cases in [GitHub Discussions](https://github.com/terminal-agent/terminal-agent/discussions)
3. **Contribute code** — Implement features you want to see (see [CONTRIBUTING.md](CONTRIBUTING.md))
4. **Report bugs** — Help us stabilize existing features
5. **Write documentation** — Help others understand and use Terminal Agent

## Release Schedule

| Version | Target | Focus |
|---------|--------|-------|
| 0.1.0   | Q1 2025 | Foundation, CLI, LLM engine |
| 0.2.0   | Q2 2025 | Core loop, tools, memory |
| 0.3.0   | Q3 2025 | Extended tools, safety, self-improvement |
| 0.4.0   | Q4 2025 | TUI, plugins, MCP |
| 0.5.0   | Q1 2026 | Generation, DevOps |
| 1.0.0   | Q2 2026 | Production-ready release |
