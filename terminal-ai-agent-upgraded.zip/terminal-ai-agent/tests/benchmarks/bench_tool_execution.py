"""Benchmark tests: tool execution performance.

Measures and reports tool execution performance metrics.
Run with: pytest tests/benchmarks/bench_tool_execution.py -v --tb=short
"""

from __future__ import annotations

import asyncio
import statistics
import sys
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[2] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResultStatus


# ── Helpers ───────────────────────────────────────────────────────────

def _make_mock_tool(name: str, delay: float = 0.0) -> MagicMock:
    tool = MagicMock()
    tool.name = name
    tool.category = "benchmark"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": name, "parameters": {}}

    async def _execute(**kwargs):
        if delay > 0:
            await asyncio.sleep(delay)
        return ToolResultBuilder.ok(f"Result from {name}")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


# ── Benchmark Tests ───────────────────────────────────────────────────

class BenchToolExecution:
    """Tool execution benchmarks."""

    @pytest.mark.asyncio
    async def bench_single_tool_dispatch(self):
        """Benchmark: single tool dispatch latency."""
        tool = _make_mock_tool("bench.tool")
        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        iterations = 1000
        latencies = []

        for _ in range(iterations):
            start = time.monotonic()
            await dispatcher.dispatch(ToolCall(name="bench.tool", parameters={}))
            latencies.append((time.monotonic() - start) * 1000)

        stats = {
            "iterations": iterations,
            "mean_ms": statistics.mean(latencies),
            "median_ms": statistics.median(latencies),
            "p95_ms": sorted(latencies)[int(iterations * 0.95)],
            "p99_ms": sorted(latencies)[int(iterations * 0.99)],
            "min_ms": min(latencies),
            "max_ms": max(latencies),
            "stdev_ms": statistics.stdev(latencies) if len(latencies) > 1 else 0,
        }

        # Assert reasonable bounds
        assert stats["mean_ms"] < 5.0, f"Mean latency too high: {stats}"
        assert stats["p95_ms"] < 10.0, f"P95 latency too high: {stats}"

    @pytest.mark.asyncio
    async def bench_concurrent_tool_dispatch(self):
        """Benchmark: concurrent tool dispatch throughput."""
        tool = _make_mock_tool("bench.concurrent")
        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        batch_sizes = [10, 50, 100, 500]
        results = {}

        for batch_size in batch_sizes:
            start = time.monotonic()
            tasks = [
                dispatcher.dispatch(ToolCall(name="bench.concurrent", parameters={"i": i}))
                for i in range(batch_size)
            ]
            await asyncio.gather(*tasks)
            elapsed = time.monotonic() - start

            results[batch_size] = {
                "total_time_ms": elapsed * 1000,
                "ops_per_sec": batch_size / elapsed,
                "ms_per_op": (elapsed * 1000) / batch_size,
            }

        # Verify scaling
        assert results[10]["ops_per_sec"] > 1000
        assert results[100]["ops_per_sec"] > 5000

    @pytest.mark.asyncio
    async def bench_multi_tool_registry(self):
        """Benchmark: dispatch with many tools registered."""
        registry = ToolRegistry()
        n_tools = 100
        for i in range(n_tools):
            registry.register(_make_mock_tool(f"tool_{i:03d}"))

        dispatcher = ToolDispatcher(registry)
        tool_names = [f"tool_{i:03d}" for i in range(n_tools)]

        iterations = 1000
        start = time.monotonic()
        for i in range(iterations):
            await dispatcher.dispatch(
                ToolCall(name=tool_names[i % n_tools], parameters={})
            )
        elapsed = time.monotonic() - start

        ops_per_sec = iterations / elapsed
        assert ops_per_sec > 1000, f"Throughput with {n_tools} tools: {ops_per_sec:.0f} ops/sec"

    @pytest.mark.asyncio
    async def bench_dispatch_with_parameters(self):
        """Benchmark: dispatch with varying parameter sizes."""
        tool = _make_mock_tool("bench.params")
        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        param_sizes = [0, 10, 100, 1000]
        results = {}

        for size in param_sizes:
            params = {f"key_{i}": f"value_{i}" for i in range(size)}
            latencies = []
            for _ in range(100):
                start = time.monotonic()
                await dispatcher.dispatch(ToolCall(name="bench.params", parameters=params))
                latencies.append((time.monotonic() - start) * 1000)

            results[size] = {
                "mean_ms": statistics.mean(latencies),
                "p95_ms": sorted(latencies)[94],
            }

        # Parameter size shouldn't dramatically affect latency
        assert results[1000]["mean_ms"] < results[0]["mean_ms"] * 5

    @pytest.mark.asyncio
    async def bench_error_path_performance(self):
        """Benchmark: error handling performance."""
        registry = ToolRegistry()
        dispatcher = ToolDispatcher(registry)

        iterations = 1000
        start = time.monotonic()
        for _ in range(iterations):
            await dispatcher.dispatch(ToolCall(name="nonexistent.tool", parameters={}))
        elapsed = time.monotonic() - start

        ops_per_sec = iterations / elapsed
        assert ops_per_sec > 5000, f"Error path throughput: {ops_per_sec:.0f} ops/sec"

    @pytest.mark.asyncio
    async def bench_mixed_tool_types(self):
        """Benchmark: dispatch to multiple different tools."""
        registry = ToolRegistry()
        tools = {}
        for i in range(10):
            name = f"type_{i}.tool"
            tools[name] = _make_mock_tool(name)
            registry.register(tools[name])

        dispatcher = ToolDispatcher(registry)
        tool_names = list(tools.keys())

        iterations = 1000
        start = time.monotonic()
        for i in range(iterations):
            await dispatcher.dispatch(
                ToolCall(name=tool_names[i % len(tool_names)], parameters={"data": "x" * 100})
            )
        elapsed = time.monotonic() - start

        ops_per_sec = iterations / elapsed
        assert ops_per_sec > 1000
