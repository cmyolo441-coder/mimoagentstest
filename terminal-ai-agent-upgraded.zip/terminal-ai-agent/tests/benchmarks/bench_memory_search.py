"""Benchmark tests: memory search performance.

Measures and reports memory search/retrieval performance metrics.
Run with: pytest tests/benchmarks/bench_memory_search.py -v --tb=short
"""

from __future__ import annotations

import statistics
import sys
import time
from pathlib import Path
from unittest.mock import MagicMock

import pytest

_src = Path(__file__).resolve().parents[2] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.memory.short_term import ShortTermMemory
from terminal_agent.memory.working_memory import WorkingMemory
from terminal_agent.types import Memory, MemoryCategory


# ── Helpers ───────────────────────────────────────────────────────────

class MockLongTermStore:
    """In-memory store simulating long-term memory for benchmarks."""

    def __init__(self):
        self._memories: dict[str, Memory] = {}
        self._counter = 0

    def store(self, content: str, category: MemoryCategory) -> Memory:
        self._counter += 1
        mem = Memory(
            id=f"mem_{self._counter}",
            category=category,
            content=content,
            relevance_score=1.0,
        )
        self._memories[mem.id] = mem
        return mem

    def search(self, query: str, limit: int = 5) -> list[Memory]:
        query_lower = query.lower()
        results = []
        for mem in self._memories.values():
            # Simple keyword overlap scoring
            overlap = sum(1 for word in query_lower.split() if word in mem.content.lower())
            if overlap > 0:
                results.append((overlap, mem))
        results.sort(key=lambda x: x[0], reverse=True)
        return [mem for _, mem in results[:limit]]

    def count(self) -> int:
        return len(self._memories)


# ── Benchmark Tests ───────────────────────────────────────────────────

class BenchShortTermMemorySearch:
    """Short-term memory search benchmarks."""

    def bench_get_turns_various_sizes(self):
        """Benchmark: get_turns at various memory sizes."""
        sizes = [10, 50, 100, 500]
        results = {}

        for size in sizes:
            stm = ShortTermMemory(max_turns=size)
            for i in range(size):
                stm.add_turn("user" if i % 2 == 0 else "assistant", f"Message content {i} with some text")

            iterations = 10000
            start = time.monotonic()
            for _ in range(iterations):
                stm.get_turns()
            elapsed = time.monotonic() - start

            results[size] = {
                "ops_per_sec": iterations / elapsed,
                "mean_us": (elapsed / iterations) * 1_000_000,
            }

        # All sizes should be fast
        for size, stats in results.items():
            assert stats["ops_per_sec"] > 10000, f"Size {size}: {stats}"

    def bench_get_as_messages(self):
        """Benchmark: get_as_messages conversion."""
        stm = ShortTermMemory(max_turns=100)
        for i in range(100):
            stm.add_turn("user" if i % 2 == 0 else "assistant", f"Content {i}")

        iterations = 10000
        start = time.monotonic()
        for _ in range(iterations):
            stm.get_as_messages()
        elapsed = time.monotonic() - start

        ops_per_sec = iterations / elapsed
        assert ops_per_sec > 10000

    def bench_get_last_n(self):
        """Benchmark: get_last with various N values."""
        stm = ShortTermMemory(max_turns=100)
        for i in range(100):
            stm.add_turn("user", f"Message {i}")

        results = {}
        for n in [1, 5, 10, 50]:
            iterations = 10000
            start = time.monotonic()
            for _ in range(iterations):
                stm.get_last(n)
            elapsed = time.monotonic() - start
            results[n] = iterations / elapsed

        # All should be fast
        for n, ops in results.items():
            assert ops > 10000, f"get_last({n}): {ops:.0f} ops/sec"

    def bench_summarize_for_context(self):
        """Benchmark: summarize_for_context with various sizes."""
        stm = ShortTermMemory(max_turns=100)
        for i in range(100):
            stm.add_turn("user" if i % 2 == 0 else "assistant", f"Message {i}: " + "x" * 200)

        iterations = 1000
        start = time.monotonic()
        for _ in range(iterations):
            stm.summarize_for_context(max_chars=2000)
        elapsed = time.monotonic() - start

        ops_per_sec = iterations / elapsed
        assert ops_per_sec > 1000


class BenchWorkingMemorySearch:
    """Working memory search benchmarks."""

    def bench_get_various_sizes(self):
        """Benchmark: working memory get at various sizes."""
        sizes = [10, 100, 1000]
        results = {}

        for size in sizes:
            wm = WorkingMemory()
            for i in range(size):
                wm.set(f"key_{i}", f"value_{i}")

            iterations = 100000
            start = time.monotonic()
            for i in range(iterations):
                wm.get(f"key_{i % size}")
            elapsed = time.monotonic() - start

            results[size] = iterations / elapsed

        for size, ops in results.items():
            assert ops > 50000, f"Size {size}: {ops:.0f} ops/sec"

    def bench_file_access(self):
        """Benchmark: file content access."""
        wm = WorkingMemory(max_files=50)
        for i in range(50):
            wm.add_file(f"file_{i}.py", f"# Content of file {i}\n" + "x" * 1000)

        iterations = 100000
        start = time.monotonic()
        for i in range(iterations):
            wm.get_file(f"file_{i % 50}.py")
        elapsed = time.monotonic() - start

        ops_per_sec = iterations / elapsed
        assert ops_per_sec > 50000

    def bench_scratch_access(self):
        """Benchmark: scratch pad access."""
        wm = WorkingMemory()
        for i in range(100):
            wm.set_scratch(f"note_{i}", f"content_{i}")

        iterations = 100000
        start = time.monotonic()
        for i in range(iterations):
            wm.get_scratch(f"note_{i % 100}")
        elapsed = time.monotonic() - start

        ops_per_sec = iterations / elapsed
        assert ops_per_sec > 50000


class BenchLongTermMemorySearch:
    """Long-term memory search benchmarks."""

    def bench_keyword_search_scalability(self):
        """Benchmark: keyword search scalability."""
        store = MockLongTermStore()

        # Populate with memories
        categories = [MemoryCategory.TASK, MemoryCategory.ERROR, MemoryCategory.PATTERN,
                      MemoryCategory.PREFERENCE, MemoryCategory.PROJECT]
        for i in range(1000):
            store.store(
                f"Memory {i}: This is about {categories[i % 5].value} related to Python and testing",
                categories[i % 5],
            )

        queries = ["Python", "testing", "error", "pattern", "preference"]
        results = {}

        for query in queries:
            iterations = 1000
            start = time.monotonic()
            for _ in range(iterations):
                store.search(query, limit=5)
            elapsed = time.monotonic() - start
            results[query] = iterations / elapsed

        # All queries should be reasonably fast
        for query, ops in results.items():
            assert ops > 100, f"Query '{query}': {ops:.0f} ops/sec"

    def bench_search_with_various_limits(self):
        """Benchmark: search with different result limits."""
        store = MockLongTermStore()
        for i in range(500):
            store.store(f"Memory about Python topic {i}", MemoryCategory.TASK)

        limits = [1, 5, 10, 50, 100]
        results = {}

        for limit in limits:
            iterations = 1000
            start = time.monotonic()
            for _ in range(iterations):
                store.search("Python", limit=limit)
            elapsed = time.monotonic() - start
            results[limit] = iterations / elapsed

        # Larger limits should still be fast
        for limit, ops in results.items():
            assert ops > 100, f"Limit {limit}: {ops:.0f} ops/sec"

    def bench_store_throughput(self):
        """Benchmark: memory store throughput."""
        store = MockLongTermStore()
        categories = list(MemoryCategory)

        iterations = 10000
        start = time.monotonic()
        for i in range(iterations):
            store.store(
                f"Memory content {i} with relevant information about topic {i % 100}",
                categories[i % len(categories)],
            )
        elapsed = time.monotonic() - start

        ops_per_sec = iterations / elapsed
        assert ops_per_sec > 10000
        assert store.count() == iterations
