"""Performance tests: memory usage measurements.

Verifies that memory-intensive operations stay within reasonable
memory bounds.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

_src = Path(__file__).resolve().parents[2] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.memory.short_term import ShortTermMemory
from terminal_agent.memory.working_memory import WorkingMemory
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.types import SafetyLevel


# ── Memory Usage Tests ────────────────────────────────────────────────

class TestShortTermMemoryUsage:
    """Short-term memory usage tests."""

    def test_token_estimation_accuracy(self):
        """Token estimation is within 50% of actual."""
        stm = ShortTermMemory()

        # Known text: ~100 chars ≈ 25 tokens (4 chars/token)
        stm.add_turn("user", "a" * 100)
        tokens = stm.estimate_tokens()
        assert 15 <= tokens <= 40, f"Token estimate {tokens} outside expected range"

    def test_memory_bounded_by_max_turns(self):
        """Memory usage is bounded by max_turns setting."""
        stm = ShortTermMemory(max_turns=10)

        for i in range(1000):
            stm.add_turn("user", f"Message {i} " * 100)

        # Should only keep last 10 turns
        assert stm.count() == 10

        # Token estimate should be bounded
        tokens = stm.estimate_tokens()
        # 10 turns × ~250 tokens each ≈ 2500
        assert tokens < 10000

    def test_eviction_releases_memory(self):
        """Evicted turns are separate from active turns."""
        stm = ShortTermMemory(max_turns=5)

        for i in range(20):
            stm.add_turn("user", f"Large message content here number {i} " * 50)

        assert stm.count() == 5
        evicted = stm.get_evicted()
        assert len(evicted) == 15

        # After getting evicted, they're cleared
        evicted2 = stm.get_evicted()
        assert len(evicted2) == 0

    def test_clear_frees_all_memory(self):
        """Clear releases all stored data."""
        stm = ShortTermMemory(max_turns=100)
        for i in range(100):
            stm.add_turn("user", "x" * 1000)

        stm.clear()
        assert stm.count() == 0
        assert stm.estimate_tokens() == 0


class TestWorkingMemoryUsage:
    """Working memory usage tests."""

    def test_file_storage_bounded(self):
        """File storage is bounded by max_files."""
        wm = WorkingMemory(max_files=10)

        for i in range(100):
            wm.add_file(f"file_{i}.py", "x" * 10000)

        files = wm.get_file_list()
        assert len(files) == 10

    def test_scratch_pad_unbounded(self):
        """Scratch pad has no explicit bound (by design)."""
        wm = WorkingMemory()

        for i in range(1000):
            wm.set_scratch(f"note_{i}", f"content_{i}")

        assert wm.scratch_count() == 1000

    def test_store_overwrite_reduces_memory(self):
        """Overwriting a key doesn't increase memory."""
        wm = WorkingMemory()

        wm.set("key", "small")
        wm.set("key", "x" * 100000)

        # Only one entry, despite overwrite
        assert wm.get("key") == "x" * 100000

    def test_clear_frees_working_memory(self):
        """Clear releases all working memory data."""
        wm = WorkingMemory()
        for i in range(50):
            wm.set(f"key_{i}", "data" * 100)
            wm.add_file(f"file_{i}.py", "content" * 100)
            wm.set_scratch(f"note_{i}", "scratch" * 100)

        wm.clear()
        assert wm.get("key_0") is None
        assert wm.get_file("file_0.py") is None
        assert wm.get_scratch("note_0") is None


class TestRegistryMemoryUsage:
    """Registry memory usage tests."""

    def test_registry_scales_linearly(self):
        """Registry memory scales linearly with tool count."""
        registry = ToolRegistry()

        for i in range(1000):
            tool = MagicMock()
            tool.name = f"tool_{i:04d}"
            tool.category = f"cat_{i % 10}"
            tool.min_safety_level = SafetyLevel.UNRESTRICTED
            tool.get_schema.return_value = {"name": f"tool_{i:04d}", "parameters": {}}
            registry.register(tool)

        assert registry.count() == 1000
        assert len(registry.list_categories()) == 10

    def test_unregister_frees_registry_memory(self):
        """Unregistering tools frees registry slots."""
        registry = ToolRegistry()

        for i in range(100):
            tool = MagicMock()
            tool.name = f"tool_{i}"
            tool.category = "test"
            tool.min_safety_level = SafetyLevel.UNRESTRICTED
            tool.get_schema.return_value = {"name": f"tool_{i}", "parameters": {}}
            registry.register(tool)

        for i in range(100):
            registry.unregister(f"tool_{i}")

        assert registry.count() == 0


class TestEstimationAccuracy:
    """Token estimation accuracy tests."""

    def test_empty_content_minimal_tokens(self):
        """Empty content estimates minimal tokens."""
        stm = ShortTermMemory()
        stm.add_turn("user", "")
        # Even empty content should estimate at least 1 token
        assert stm.estimate_tokens() >= 0

    def test_long_content_proportional_estimate(self):
        """Longer content produces proportionally larger estimates."""
        stm = ShortTermMemory()

        stm.add_turn("user", "short")
        tokens_short = stm.estimate_tokens()

        stm.add_turn("user", "x" * 10000)
        tokens_long = stm.estimate_tokens()

        assert tokens_long > tokens_short * 10

    def test_multilingual_token_estimation(self):
        """Token estimation works for non-ASCII text."""
        stm = ShortTermMemory()
        stm.add_turn("user", "你好世界 " * 100)
        tokens = stm.estimate_tokens()
        assert tokens > 0
