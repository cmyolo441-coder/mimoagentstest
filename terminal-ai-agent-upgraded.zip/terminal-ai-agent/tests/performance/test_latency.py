"""Performance tests: latency measurements.

Measures latency of critical operations — tool dispatch, memory
recall, safety checks, etc. — and asserts they stay within bounds.
"""

from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[2] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.memory.short_term import ShortTermMemory
from terminal_agent.memory.working_memory import WorkingMemory
from terminal_agent.support.safety.blocked_commands import BlockedCommandRegistry
from terminal_agent.support.safety.guardrails import SafetyGuardrails
from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResultStatus


# ── Helpers ───────────────────────────────────────────────────────────

def _make_instant_tool(name: str = "test.tool") -> MagicMock:
    """Tool that returns instantly."""
    tool = MagicMock()
    tool.name = name
    tool.category = "test"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": name, "parameters": {}}
    tool.run = AsyncMock(return_value=ToolResultBuilder.ok("done"))
    return tool


# ── Latency Tests ─────────────────────────────────────────────────────

class TestToolDispatchLatency:
    """Tool dispatch latency tests."""

    @pytest.mark.asyncio
    async def test_single_dispatch_latency(self):
        """Single tool dispatch completes in < 10ms."""
        tool = _make_instant_tool()
        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        start = time.monotonic()
        result = await dispatcher.dispatch(ToolCall(name="test.tool", parameters={}))
        elapsed_ms = (time.monotonic() - start) * 1000

        assert result.status == ToolResultStatus.SUCCESS
        assert elapsed_ms < 10.0, f"Dispatch took {elapsed_ms:.1f}ms, expected < 10ms"

    @pytest.mark.asyncio
    async def test_dispatch_latency_percentiles(self):
        """Measure dispatch latency across many calls."""
        tool = _make_instant_tool()
        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        latencies = []
        for _ in range(100):
            start = time.monotonic()
            await dispatcher.dispatch(ToolCall(name="test.tool", parameters={}))
            latencies.append((time.monotonic() - start) * 1000)

        latencies.sort()
        p50 = latencies[50]
        p95 = latencies[94]
        p99 = latencies[98]

        assert p50 < 5.0, f"P50 latency {p50:.1f}ms too high"
        assert p95 < 20.0, f"P95 latency {p95:.1f}ms too high"
        assert p99 < 50.0, f"P99 latency {p99:.1f}ms too high"

    @pytest.mark.asyncio
    async def test_unknown_tool_dispatch_latency(self):
        """Unknown tool dispatch returns quickly with error."""
        registry = ToolRegistry()
        dispatcher = ToolDispatcher(registry)

        start = time.monotonic()
        result = await dispatcher.dispatch(ToolCall(name="nonexistent", parameters={}))
        elapsed_ms = (time.monotonic() - start) * 1000

        assert result.status == ToolResultStatus.ERROR
        assert elapsed_ms < 5.0, f"Error dispatch took {elapsed_ms:.1f}ms"


class TestSafetyCheckLatency:
    """Safety check latency tests."""

    def test_blocked_command_check_latency(self):
        """Blocked command check completes in < 1ms."""
        registry = BlockedCommandRegistry()

        start = time.monotonic()
        for _ in range(1000):
            registry.is_blocked("rm -rf /")
            registry.is_blocked("ls -la")
            registry.is_blocked(":(){ :|:& };:")
        elapsed_ms = (time.monotonic() - start) * 1000

        per_check_us = elapsed_ms / 3000 * 1000
        assert per_check_us < 100, f"Per-check latency {per_check_us:.1f}µs too high"

    def test_guardrails_evaluate_latency(self):
        """Guardrails evaluation completes in < 5ms."""
        guardrails = SafetyGuardrails(safety_level=SafetyLevel.STANDARD)
        call = ToolCall(name="shell.execute", parameters={"command": "ls -la"})

        start = time.monotonic()
        for _ in range(100):
            guardrails.evaluate(call)
        elapsed_ms = (time.monotonic() - start) * 1000

        per_eval_ms = elapsed_ms / 100
        assert per_eval_ms < 5.0, f"Per-eval latency {per_eval_ms:.1f}ms too high"


class TestMemoryLatency:
    """Memory operation latency tests."""

    def test_short_term_write_latency(self):
        """Short-term memory write completes in < 1ms."""
        stm = ShortTermMemory(max_turns=100)

        start = time.monotonic()
        for _ in range(1000):
            stm.add_turn("user", "test message")
        elapsed_ms = (time.monotonic() - start) * 1000

        per_write_us = elapsed_ms / 1000 * 1000
        assert per_write_us < 100, f"Per-write latency {per_write_us:.1f}µs too high"

    def test_short_term_read_latency(self):
        """Short-term memory read completes in < 1ms."""
        stm = ShortTermMemory(max_turns=100)
        for i in range(50):
            stm.add_turn("user", f"Message {i}")

        start = time.monotonic()
        for _ in range(1000):
            stm.get_turns()
            stm.get_as_messages()
        elapsed_ms = (time.monotonic() - start) * 1000

        per_read_us = elapsed_ms / 2000 * 1000
        assert per_read_us < 100, f"Per-read latency {per_read_us:.1f}µs too high"

    def test_working_memory_get_latency(self):
        """Working memory get completes in < 1ms."""
        wm = WorkingMemory()
        for i in range(50):
            wm.set(f"key_{i}", f"value_{i}")

        start = time.monotonic()
        for _ in range(1000):
            wm.get(f"key_{25}")
        elapsed_ms = (time.monotonic() - start) * 1000

        per_get_us = elapsed_ms / 1000 * 1000
        assert per_get_us < 100, f"Per-get latency {per_get_us:.1f}µs too high"

    def test_working_memory_file_access_latency(self):
        """Working memory file access completes in < 1ms."""
        wm = WorkingMemory()
        for i in range(10):
            wm.add_file(f"file_{i}.py", f"# Content {i}\n" * 100)

        start = time.monotonic()
        for _ in range(1000):
            wm.get_file("file_5.py")
        elapsed_ms = (time.monotonic() - start) * 1000

        per_access_us = elapsed_ms / 1000 * 1000
        assert per_access_us < 100, f"Per-access latency {per_access_us:.1f}µs too high"


class TestRegistryLookupLatency:
    """Registry lookup latency tests."""

    def test_registry_get_latency(self):
        """Registry get completes in < 1ms."""
        registry = ToolRegistry()
        for i in range(50):
            tool = MagicMock()
            tool.name = f"tool_{i}"
            tool.category = "test"
            tool.min_safety_level = SafetyLevel.UNRESTRICTED
            tool.get_schema.return_value = {"name": f"tool_{i}", "parameters": {}}
            registry.register(tool)

        start = time.monotonic()
        for _ in range(10000):
            registry.get("tool_25")
        elapsed_ms = (time.monotonic() - start) * 1000

        per_lookup_us = elapsed_ms / 10000 * 1000
        assert per_lookup_us < 10, f"Per-lookup latency {per_lookup_us:.1f}µs too high"

    def test_registry_has_latency(self):
        """Registry has-check completes in < 1ms."""
        registry = ToolRegistry()
        for i in range(50):
            tool = MagicMock()
            tool.name = f"tool_{i}"
            tool.category = "test"
            tool.min_safety_level = SafetyLevel.UNRESTRICTED
            tool.get_schema.return_value = {"name": f"tool_{i}", "parameters": {}}
            registry.register(tool)

        start = time.monotonic()
        for _ in range(10000):
            registry.has("tool_25")
        elapsed_ms = (time.monotonic() - start) * 1000

        per_check_us = elapsed_ms / 10000 * 1000
        assert per_check_us < 10, f"Per-check latency {per_check_us:.1f}µs too high"
