"""Performance tests: throughput measurements.

Measures how many operations per second the system can handle
for critical paths.
"""

from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[2] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.memory.short_term import ShortTermMemory
from terminal_agent.memory.working_memory import WorkingMemory
from terminal_agent.support.safety.blocked_commands import BlockedCommandRegistry
from terminal_agent.support.safety.guardrails import SafetyGuardrails
from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResultStatus


# ── Helpers ───────────────────────────────────────────────────────────

def _make_instant_tool(name: str = "test.tool") -> MagicMock:
    tool = MagicMock()
    tool.name = name
    tool.category = "test"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": name, "parameters": {}}
    tool.run = AsyncMock(return_value=ToolResultBuilder.ok("done"))
    return tool


# ── Throughput Tests ──────────────────────────────────────────────────

class TestToolDispatchThroughput:
    """Tool dispatch throughput tests."""

    @pytest.mark.asyncio
    async def test_sequential_dispatch_throughput(self):
        """Sequential dispatches achieve > 1000 ops/sec."""
        tool = _make_instant_tool()
        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        n = 1000
        start = time.monotonic()
        for _ in range(n):
            await dispatcher.dispatch(ToolCall(name="test.tool", parameters={}))
        elapsed = time.monotonic() - start

        ops_per_sec = n / elapsed
        assert ops_per_sec > 1000, f"Throughput {ops_per_sec:.0f} ops/sec, expected > 1000"

    @pytest.mark.asyncio
    async def test_concurrent_dispatch_throughput(self):
        """Concurrent dispatches achieve > 5000 ops/sec."""
        tool = _make_instant_tool()
        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        n = 5000
        start = time.monotonic()
        tasks = [
            dispatcher.dispatch(ToolCall(name="test.tool", parameters={"i": i}))
            for i in range(n)
        ]
        await asyncio.gather(*tasks)
        elapsed = time.monotonic() - start

        ops_per_sec = n / elapsed
        assert ops_per_sec > 5000, f"Throughput {ops_per_sec:.0f} ops/sec, expected > 5000"


class TestSafetyCheckThroughput:
    """Safety check throughput tests."""

    def test_blocked_command_check_throughput(self):
        """Blocked command checks achieve > 100K ops/sec."""
        registry = BlockedCommandRegistry()
        commands = ["rm -rf /", "ls -la", "echo hello", ":(){ :|:& };:", "python script.py"]

        n = 100000
        start = time.monotonic()
        for i in range(n):
            registry.is_blocked(commands[i % len(commands)])
        elapsed = time.monotonic() - start

        ops_per_sec = n / elapsed
        assert ops_per_sec > 100000, f"Throughput {ops_per_sec:.0f} ops/sec, expected > 100K"

    def test_guardrails_evaluate_throughput(self):
        """Guardrails evaluation achieves > 10K ops/sec."""
        guardrails = SafetyGuardrails(safety_level=SafetyLevel.STANDARD)
        calls = [
            ToolCall(name="read_file", parameters={"path": "file.txt"}),
            ToolCall(name="shell.execute", parameters={"command": "ls"}),
            ToolCall(name="write_file", parameters={"path": "f.txt", "content": "x"}),
        ]

        n = 10000
        start = time.monotonic()
        for i in range(n):
            guardrails.evaluate(calls[i % len(calls)])
        elapsed = time.monotonic() - start

        ops_per_sec = n / elapsed
        assert ops_per_sec > 500, f"Throughput {ops_per_sec:.0f} ops/sec, expected > 500"


class TestMemoryThroughput:
    """Memory operation throughput tests."""

    def test_short_term_write_throughput(self):
        """Short-term memory writes achieve > 50K ops/sec."""
        stm = ShortTermMemory(max_turns=1000)

        n = 50000
        start = time.monotonic()
        for i in range(n):
            stm.add_turn("user", f"Message {i}")
        elapsed = time.monotonic() - start

        ops_per_sec = n / elapsed
        assert ops_per_sec > 50000, f"Throughput {ops_per_sec:.0f} ops/sec, expected > 50K"

    def test_short_term_read_throughput(self):
        """Short-term memory reads achieve > 50K ops/sec."""
        stm = ShortTermMemory(max_turns=100)
        for i in range(100):
            stm.add_turn("user", f"Message {i}")

        n = 100000
        start = time.monotonic()
        for _ in range(n):
            stm.get_turns()
        elapsed = time.monotonic() - start

        ops_per_sec = n / elapsed
        assert ops_per_sec > 50000, f"Throughput {ops_per_sec:.0f} ops/sec, expected > 50K"

    def test_working_memory_write_throughput(self):
        """Working memory writes achieve > 50K ops/sec."""
        wm = WorkingMemory()

        n = 50000
        start = time.monotonic()
        for i in range(n):
            wm.set(f"key_{i % 1000}", f"value_{i}")
        elapsed = time.monotonic() - start

        ops_per_sec = n / elapsed
        assert ops_per_sec > 50000, f"Throughput {ops_per_sec:.0f} ops/sec, expected > 50K"

    def test_working_memory_read_throughput(self):
        """Working memory reads achieve > 100K ops/sec."""
        wm = WorkingMemory()
        for i in range(100):
            wm.set(f"key_{i}", f"value_{i}")

        n = 100000
        start = time.monotonic()
        for i in range(n):
            wm.get(f"key_{i % 100}")
        elapsed = time.monotonic() - start

        ops_per_sec = n / elapsed
        assert ops_per_sec > 100000, f"Throughput {ops_per_sec:.0f} ops/sec, expected > 100K"


class TestRegistryThroughput:
    """Registry lookup throughput tests."""

    def test_registry_get_throughput(self):
        """Registry get achieves > 500K ops/sec."""
        registry = ToolRegistry()
        for i in range(50):
            tool = MagicMock()
            tool.name = f"tool_{i}"
            tool.category = "test"
            tool.min_safety_level = SafetyLevel.UNRESTRICTED
            tool.get_schema.return_value = {"name": f"tool_{i}", "parameters": {}}
            registry.register(tool)

        n = 500000
        start = time.monotonic()
        for i in range(n):
            registry.get(f"tool_{i % 50}")
        elapsed = time.monotonic() - start

        ops_per_sec = n / elapsed
        assert ops_per_sec > 500000, f"Throughput {ops_per_sec:.0f} ops/sec, expected > 500K"
