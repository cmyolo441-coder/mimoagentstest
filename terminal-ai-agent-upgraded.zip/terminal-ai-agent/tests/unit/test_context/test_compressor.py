"""Tests for terminal_agent.context.compressor — context compression."""

from __future__ import annotations

import pytest
import asyncio

from terminal_agent.context.compressor import ContextCompressor


@pytest.fixture
def compressor():
    return ContextCompressor(
        tool_output_max_chars=100,
        tool_output_head_chars=30,
        tool_output_tail_chars=20,
    )


class TestTruncateToolOutput:
    def test_short_output_unchanged(self, compressor):
        output = "short output"
        assert compressor.truncate_tool_output(output) == output

    def test_long_output_truncated(self, compressor):
        output = "x" * 200
        result = compressor.truncate_tool_output(output)
        assert len(result) < len(output)
        assert "omitted" in result

    def test_preserves_head_and_tail(self, compressor):
        output = "HEAD" + "x" * 200 + "TAIL"
        result = compressor.truncate_tool_output(output)
        assert "HEAD" in result
        assert "TAIL" in result


class TestCompress:
    @pytest.mark.asyncio
    async def test_no_compression_needed(self, compressor):
        components = {"system_prompt": "short text"}
        result = await compressor.compress(components, target_tokens=1000)
        assert result == components

    @pytest.mark.asyncio
    async def test_compression_runs_when_over_budget(self, compressor):
        large_text = "word " * 10000
        components = {
            "system_prompt": "keep this",
            "tool_results": large_text,
        }
        result = await compressor.compress(components, target_tokens=100)
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_preserves_system_prompt(self, compressor):
        large_text = "word " * 10000
        components = {
            "system_prompt": "important system prompt",
            "other": large_text,
        }
        result = await compressor.compress(components, target_tokens=50)
        assert result.get("system_prompt") == "important system prompt"


class TestSmartTruncate:
    def test_removes_from_middle(self):
        text = "A" * 100 + "B" * 100
        result = ContextCompressor._smart_truncate(text, 50)
        assert "A" in result
        assert "B" in result
        assert "compressed" in result

    def test_zero_removal(self):
        text = "hello"
        assert ContextCompressor._smart_truncate(text, 0) == text

    def test_excessive_removal(self):
        text = "x" * 1000
        result = ContextCompressor._smart_truncate(text, 2000)
        assert "truncated" in result


class TestHardCompress:
    def test_proportional_shrink(self):
        components = {
            "system_prompt": "A" * 1000,
            "other": "B" * 1000,
        }
        estimate_fn = lambda t: len(t) // 4
        result = ContextCompressor._hard_compress(components, target_tokens=100, estimate_fn=estimate_fn)
        assert len(result["system_prompt"]) == 1000  # never compressed
        assert len(result["other"]) < 1000

    def test_within_budget_passthrough(self):
        components = {"a": "short"}
        estimate_fn = lambda t: len(t) // 4
        result = ContextCompressor._hard_compress(components, target_tokens=1000, estimate_fn=estimate_fn)
        assert result == components
