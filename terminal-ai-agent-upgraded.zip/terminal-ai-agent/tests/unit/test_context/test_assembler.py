"""Tests for terminal_agent.context.assembler — context assembly."""

from __future__ import annotations

import pytest
import asyncio
from unittest.mock import MagicMock

from terminal_agent.context.assembler import ContextAssembler
from terminal_agent.context.token_budget import TokenBudget
from terminal_agent.context.compressor import ContextCompressor
from terminal_agent.context.environment import EnvironmentGatherer
from terminal_agent.types import Plan, PlanStep, SessionStatus


@pytest.fixture
def budget():
    return TokenBudget(model="gpt-4o", reserve_for_response=4096)


@pytest.fixture
def assembler(budget):
    env = MagicMock(spec=EnvironmentGatherer)
    env_info = MagicMock()
    env_info.to_context_string.return_value = "OS: Linux\nShell: bash"
    env.gather.return_value = env_info
    return ContextAssembler(
        budget=budget,
        compressor=ContextCompressor(),
        env_gatherer=env,
    )


class TestContextAssemblerAssemble:
    @pytest.mark.asyncio
    async def test_basic_assembly(self, assembler):
        result = await assembler.assemble(goal="Fix the bug")
        assert isinstance(result, str)
        assert "Fix the bug" in result

    @pytest.mark.asyncio
    async def test_with_system_prompt(self, assembler):
        result = await assembler.assemble(
            goal="Test",
            system_prompt="You are a helpful assistant.",
        )
        assert "You are a helpful assistant." in result

    @pytest.mark.asyncio
    async def test_with_plan(self, assembler):
        plan = Plan(
            goal="Test",
            steps=[
                PlanStep(id="step_1", description="Read file", status=SessionStatus.PENDING),
                PlanStep(id="step_2", description="Edit file", status=SessionStatus.COMPLETED),
            ],
        )
        result = await assembler.assemble(goal="Test", plan=plan)
        assert "Read file" in result or "step_1" in result

    @pytest.mark.asyncio
    async def test_with_conversation_history(self, assembler):
        history = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi!"},
        ]
        result = await assembler.assemble(goal="Test", conversation_history=history)
        assert isinstance(result, str)

    @pytest.mark.asyncio
    async def test_with_memories(self, assembler):
        memories = ["Use sorted() for lists", "Always handle exceptions"]
        result = await assembler.assemble(goal="Test", memories=memories)
        assert isinstance(result, str)

    @pytest.mark.asyncio
    async def test_with_working_memory(self, assembler):
        wm = {"main.py": "print('hello')", "notes": "fix this later"}
        result = await assembler.assemble(goal="Test", working_memory=wm)
        assert isinstance(result, str)

    @pytest.mark.asyncio
    async def test_with_tool_results(self, assembler):
        results = ["command output 1", "command output 2"]
        result = await assembler.assemble(goal="Test", tool_results=results)
        assert isinstance(result, str)

    @pytest.mark.asyncio
    async def test_with_extra_components(self, assembler):
        extras = {"custom_section": "Extra context here"}
        result = await assembler.assemble(goal="Test", extra_components=extras)
        assert "Extra context here" in result

    @pytest.mark.asyncio
    async def test_includes_environment(self, assembler):
        result = await assembler.assemble(goal="Test")
        assert "Linux" in result or "bash" in result
