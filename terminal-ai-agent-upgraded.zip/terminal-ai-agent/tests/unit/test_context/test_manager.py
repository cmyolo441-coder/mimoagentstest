"""Tests for terminal_agent.context.manager — context management facade."""

from __future__ import annotations

import pytest
import asyncio
from unittest.mock import MagicMock, patch

from terminal_agent.context.manager import ContextManager


@pytest.fixture
def ctx_manager():
    return ContextManager(model="gpt-4o", reserve_for_response=4096)


class TestContextManagerInit:
    def test_default_init(self):
        ctx = ContextManager()
        assert ctx.budget is not None

    def test_custom_model(self):
        ctx = ContextManager(model="gpt-4o")
        assert ctx.budget.total_tokens == 128_000

    def test_custom_max_tokens(self):
        ctx = ContextManager(model="custom", max_tokens=50000)
        assert ctx.budget.total_tokens == 50000


class TestContextManagerAssemble:
    @pytest.mark.asyncio
    async def test_basic_assembly(self, ctx_manager):
        result = await ctx_manager.assemble(goal="Fix the bug")
        assert isinstance(result, str)
        assert "Fix the bug" in result

    @pytest.mark.asyncio
    async def test_with_system_prompt(self, ctx_manager):
        result = await ctx_manager.assemble(
            goal="Test",
            system_prompt="You are a Python expert.",
        )
        assert isinstance(result, str)

    @pytest.mark.asyncio
    async def test_resets_budget(self, ctx_manager):
        """Each assemble call should reset the budget."""
        await ctx_manager.assemble(goal="First call")
        # Budget should be reset for the second call
        await ctx_manager.assemble(goal="Second call")
        assert ctx_manager.budget.used_tokens >= 0


class TestContextManagerEnvironment:
    def test_get_environment(self, ctx_manager):
        env = ctx_manager.get_environment()
        assert isinstance(env, str)


class TestContextManagerBudgetSummary:
    def test_budget_summary(self, ctx_manager):
        summary = ctx_manager.budget_summary()
        assert "Token Budget" in summary
