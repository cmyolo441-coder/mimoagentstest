"""Tests for terminal_agent.context.token_budget — token budget allocation."""

from __future__ import annotations

import pytest

from terminal_agent.context.token_budget import TokenBudget, BudgetAllocation


@pytest.fixture
def budget():
    return TokenBudget(model="gpt-4o", reserve_for_response=4096)


class TestTokenBudgetInit:
    def test_default_model(self):
        b = TokenBudget(model="default")
        assert b.total_tokens == 8_192

    def test_known_model(self):
        b = TokenBudget(model="gpt-4o")
        assert b.total_tokens == 128_000

    def test_custom_max_tokens(self):
        b = TokenBudget(model="custom", max_tokens=50000)
        assert b.total_tokens == 50000

    def test_available_tokens(self):
        b = TokenBudget(model="gpt-4o", reserve_for_response=4096)
        assert b.available_tokens == 128_000 - 4096


class TestTokenBudgetAllocations:
    def test_has_allocations(self, budget):
        allocs = budget.get_all_allocations()
        assert len(allocs) > 0

    def test_system_prompt_allocation(self, budget):
        alloc = budget.get_allocation("system_prompt")
        assert alloc is not None
        assert alloc.allocated > 0

    def test_goal_and_plan_allocation(self, budget):
        alloc = budget.get_allocation("goal_and_plan")
        assert alloc is not None

    def test_conversation_history_allocation(self, budget):
        alloc = budget.get_allocation("conversation_history")
        assert alloc is not None


class TestTokenBudgetUsage:
    def test_record_usage(self, budget):
        result = budget.record_usage("system_prompt", 100)
        assert result is True
        alloc = budget.get_allocation("system_prompt")
        assert alloc.used == 100

    def test_record_usage_exceeds(self, budget):
        alloc = budget.get_allocation("system_prompt")
        result = budget.record_usage("system_prompt", alloc.allocated + 1)
        assert result is False  # exceeds but still recorded

    def test_used_tokens(self, budget):
        budget.record_usage("system_prompt", 100)
        budget.record_usage("goal_and_plan", 200)
        assert budget.used_tokens == 300

    def test_remaining_tokens(self, budget):
        budget.record_usage("system_prompt", 100)
        assert budget.remaining_tokens == budget.available_tokens - 100


class TestTokenBudgetCanFit:
    def test_can_fit(self, budget):
        assert budget.can_fit("system_prompt", 100) is True

    def test_cannot_fit(self, budget):
        alloc = budget.get_allocation("system_prompt")
        assert budget.can_fit("system_prompt", alloc.allocated + 1) is False

    def test_unknown_component(self, budget):
        assert budget.can_fit("nonexistent", 100) is False


class TestTokenBudgetBorrow:
    def test_borrow_from_lower_priority(self, budget):
        # system_prompt (priority 1) should be able to borrow from environment (priority 7)
        alloc = budget.get_allocation("system_prompt")
        original_allocated = alloc.allocated
        borrowed = budget.borrow_tokens("system_prompt", alloc.allocated + 1000)
        assert borrowed >= 0


class TestTokenBudgetReset:
    def test_reset_clears_usage(self, budget):
        budget.record_usage("system_prompt", 100)
        budget.reset()
        alloc = budget.get_allocation("system_prompt")
        assert alloc.used == 0


class TestTokenBudgetSummary:
    def test_summary_string(self, budget):
        summary = budget.summary()
        assert "Token Budget" in summary
        assert "gpt-4o" in summary


class TestBudgetAllocation:
    def test_remaining(self):
        alloc = BudgetAllocation(name="test", allocated=100, used=30)
        assert alloc.remaining == 70

    def test_remaining_floor(self):
        alloc = BudgetAllocation(name="test", allocated=100, used=150)
        assert alloc.remaining == 0

    def test_utilization(self):
        alloc = BudgetAllocation(name="test", allocated=100, used=50)
        assert alloc.utilization == 50.0

    def test_utilization_zero_allocation(self):
        alloc = BudgetAllocation(name="test", allocated=0, used=0)
        assert alloc.utilization == 0.0
