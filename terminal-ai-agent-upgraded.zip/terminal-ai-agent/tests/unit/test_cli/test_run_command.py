"""Tests for terminal_agent.cli.commands.run — the run command."""

from __future__ import annotations

import pytest
from click.testing import CliRunner

from terminal_agent.cli.commands.run import run_command
from terminal_agent.cli.output import reset_output


@pytest.fixture(autouse=True)
def _reset_output():
    reset_output()
    yield
    reset_output()


@pytest.fixture
def runner():
    return CliRunner()


class TestRunCommand:
    def test_no_goal_shows_error(self, runner):
        result = runner.invoke(run_command, [])
        assert result.exit_code != 0

    def test_goal_argument(self, runner):
        result = runner.invoke(run_command, ["echo hello"])
        # Should accept the goal (exit 0 or fail at orchestrator placeholder)
        assert result.exit_code == 0 or result.exception is not None

    def test_dry_run_flag(self, runner):
        result = runner.invoke(run_command, ["--dry-run", "test goal"])
        assert result.exit_code == 0

    def test_plan_only_flag(self, runner):
        result = runner.invoke(run_command, ["--plan-only", "test goal"])
        assert result.exit_code == 0

    def test_verbose_flag(self, runner):
        result = runner.invoke(run_command, ["--verbose", "test goal"])
        assert result.exit_code == 0

    def test_provider_option(self, runner):
        result = runner.invoke(run_command, ["--provider", "anthropic", "test goal"])
        assert result.exit_code == 0

    def test_model_option(self, runner):
        result = runner.invoke(run_command, ["--model", "gpt-4o-mini", "test goal"])
        assert result.exit_code == 0

    def test_safety_level_option(self, runner):
        result = runner.invoke(run_command, ["--safety-level", "3", "test goal"])
        assert result.exit_code == 0

    def test_parallel_flag(self, runner):
        result = runner.invoke(run_command, ["--parallel", "test goal"])
        assert result.exit_code == 0
