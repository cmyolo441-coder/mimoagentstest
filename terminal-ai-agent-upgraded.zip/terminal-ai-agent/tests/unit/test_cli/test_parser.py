"""Tests for terminal_agent.cli.parser — argument parsing and validation."""

from __future__ import annotations

import click
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from terminal_agent.cli.parser import (
    DurationParamType,
    KeyValueParamType,
    validate_goal,
    validate_file_path,
    validate_directory,
    validate_safety_level,
    merge_options,
    read_goal_from_file,
    DURATION,
    KEY_VALUE,
)
from terminal_agent.types import SafetyLevel


# ── validate_goal ─────────────────────────────────────────────────────

class TestValidateGoal:
    def test_valid_goal(self):
        assert validate_goal("  Fix the login bug  ") == "Fix the login bug"

    def test_empty_goal_raises(self):
        with pytest.raises(click.BadParameter, match="cannot be empty"):
            validate_goal("")

    def test_whitespace_only_raises(self):
        with pytest.raises(click.BadParameter, match="cannot be empty"):
            validate_goal("   ")

    def test_max_length_exceeded(self):
        long_goal = "a" * 50_001
        with pytest.raises(click.BadParameter, match="too long"):
            validate_goal(long_goal)

    def test_exactly_max_length(self):
        goal = "a" * 50_000
        assert validate_goal(goal) == goal


# ── validate_file_path ────────────────────────────────────────────────

class TestValidateFilePath:
    def test_existing_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        result = validate_file_path(str(f))
        assert result == f.resolve()

    def test_nonexistent_file_raises(self, tmp_path):
        with pytest.raises(click.BadParameter, match="File not found"):
            validate_file_path(str(tmp_path / "missing.txt"))

    def test_directory_not_file_raises(self, tmp_path):
        with pytest.raises(click.BadParameter, match="Not a file"):
            validate_file_path(str(tmp_path))

    def test_must_exist_false(self, tmp_path):
        result = validate_file_path(str(tmp_path / "nope.txt"), must_exist=False)
        assert isinstance(result, Path)

    def test_expands_user(self):
        with patch.object(Path, "exists", return_value=False):
            with pytest.raises(click.BadParameter):
                validate_file_path("~/somefile.txt")


# ── validate_directory ────────────────────────────────────────────────

class TestValidateDirectory:
    def test_existing_directory(self, tmp_path):
        result = validate_directory(str(tmp_path))
        assert result == tmp_path.resolve()

    def test_nonexistent_raises(self, tmp_path):
        with pytest.raises(click.BadParameter, match="Directory not found"):
            validate_directory(str(tmp_path / "nope"))

    def test_file_not_dir_raises(self, tmp_path):
        f = tmp_path / "file.txt"
        f.write_text("x")
        with pytest.raises(click.BadParameter, match="Not a directory"):
            validate_directory(str(f))


# ── validate_safety_level ─────────────────────────────────────────────

class TestValidateSafetyLevel:
    @pytest.mark.parametrize("level", range(6))
    def test_valid_levels(self, level):
        result = validate_safety_level(level)
        assert isinstance(result, SafetyLevel)
        assert result.value == level

    def test_invalid_level_raises(self):
        with pytest.raises(click.BadParameter):
            validate_safety_level(6)

    def test_negative_level_raises(self):
        with pytest.raises(click.BadParameter):
            validate_safety_level(-1)


# ── DurationParamType ─────────────────────────────────────────────────

class TestDurationParamType:
    def test_seconds(self):
        assert DURATION.convert("30s", None, None) == 30.0

    def test_minutes(self):
        assert DURATION.convert("5m", None, None) == 300.0

    def test_hours(self):
        assert DURATION.convert("2h", None, None) == 7200.0

    def test_days(self):
        assert DURATION.convert("1d", None, None) == 86400.0

    def test_bare_number_assumes_seconds(self):
        assert DURATION.convert("42", None, None) == 42.0

    def test_float(self):
        assert DURATION.convert("1.5m", None, None) == 90.0

    def test_empty_raises(self):
        with pytest.raises(click.BadParameter):
            DURATION.convert("", None, None)

    def test_invalid_suffix_raises(self):
        with pytest.raises(click.BadParameter):
            DURATION.convert("5x", None, None)

    def test_negative_raises(self):
        with pytest.raises(click.BadParameter):
            DURATION.convert("-5m", None, None)

    def test_numeric_passthrough(self):
        assert DURATION.convert(10, None, None) == 10.0


# ── KeyValueParamType ─────────────────────────────────────────────────

class TestKeyValueParamType:
    def test_simple_pair(self):
        assert KEY_VALUE.convert("key=value", None, None) == ("key", "value")

    def test_value_with_equals(self):
        assert KEY_VALUE.convert("key=a=b", None, None) == ("key", "a=b")

    def test_strips_whitespace(self):
        assert KEY_VALUE.convert("  key = value  ", None, None) == ("key", "value")

    def test_no_equals_raises(self):
        with pytest.raises(click.BadParameter):
            KEY_VALUE.convert("noequalssign", None, None)

    def test_empty_key_raises(self):
        with pytest.raises(click.BadParameter):
            KEY_VALUE.convert("=value", None, None)


# ── merge_options ─────────────────────────────────────────────────────

class TestMergeOptions:
    def test_cli_overrides_take_precedence(self):
        ctx = MagicMock()
        ctx.obj = {"provider": "anthropic", "model": "claude-3"}
        result = merge_options(ctx, provider="openai", model=None)
        assert result["provider"] == "openai"
        assert result["model"] == "claude-3"

    def test_none_filtered_out(self):
        ctx = MagicMock()
        ctx.obj = {}
        result = merge_options(ctx, provider=None, model=None)
        assert result == {}

    def test_empty_context(self):
        ctx = MagicMock()
        ctx.obj = None
        result = merge_options(ctx, provider="openai")
        assert result == {"provider": "openai"}


# ── read_goal_from_file ───────────────────────────────────────────────

class TestReadGoalFromFile:
    def test_reads_content(self, tmp_path):
        f = tmp_path / "goal.txt"
        f.write_text("  Build a REST API  ")
        assert read_goal_from_file(str(f)) == "Build a REST API"

    def test_empty_file_raises(self, tmp_path):
        f = tmp_path / "empty.txt"
        f.write_text("")
        with pytest.raises(click.BadParameter, match="empty"):
            read_goal_from_file(str(f))

    def test_nonexistent_raises(self):
        with pytest.raises(click.BadParameter):
            read_goal_from_file("/nonexistent/file.txt")
