"""Tests for terminal_agent.cli.commands.chat — the chat command."""

from __future__ import annotations

import pytest
from click.testing import CliRunner
from unittest.mock import patch, MagicMock

from terminal_agent.cli.commands.chat import chat_command
from terminal_agent.cli.output import reset_output


@pytest.fixture(autouse=True)
def _reset_output():
    reset_output()
    yield
    reset_output()


@pytest.fixture
def runner():
    return CliRunner()


class TestChatCommand:
    def test_requires_interactive_terminal(self, runner):
        """Chat should reject non-interactive terminals."""
        with patch("terminal_agent.cli.commands.chat.sys") as mock_sys:
            mock_sys.stdin.isatty.return_value = False
            result = runner.invoke(chat_command, [])
            assert result.exit_code != 0

    def test_system_prompt_option(self, runner):
        """Chat should accept a system prompt option."""
        with patch("terminal_agent.cli.commands.chat.sys") as mock_sys:
            mock_sys.stdin.isatty.return_value = False
            result = runner.invoke(chat_command, ["--system", "You are a Python expert"])
            assert result.exit_code != 0
