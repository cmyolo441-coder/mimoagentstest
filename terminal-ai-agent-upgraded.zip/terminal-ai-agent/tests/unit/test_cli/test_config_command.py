"""Tests for terminal_agent.cli.commands.config — the config command."""

from __future__ import annotations

import pytest
from click.testing import CliRunner

from terminal_agent.cli.commands.config import config_command
from terminal_agent.cli.output import reset_output


@pytest.fixture(autouse=True)
def _reset_output():
    """Reset global output before each test to avoid stale stream references."""
    reset_output()
    yield
    reset_output()


@pytest.fixture
def runner():
    return CliRunner()


class TestConfigCommand:
    def test_show_subcommand(self, runner):
        result = runner.invoke(config_command, ["show"])
        assert result.exit_code == 0

    def test_get_subcommand(self, runner):
        result = runner.invoke(config_command, ["get", "llm.provider"])
        assert result.exit_code == 0

    def test_set_subcommand(self, runner):
        result = runner.invoke(config_command, ["set", "llm.provider", "openai"])
        assert result.exit_code == 0

    def test_validate_subcommand(self, runner):
        result = runner.invoke(config_command, ["validate"])
        assert result.exit_code == 0

    def test_profiles_subcommand(self, runner):
        result = runner.invoke(config_command, ["profiles"])
        assert result.exit_code == 0

    def test_use_profile_subcommand(self, runner):
        result = runner.invoke(config_command, ["use-profile", "development"])
        assert result.exit_code == 0

    def test_show_global_only(self, runner):
        result = runner.invoke(config_command, ["show", "--global-only"])
        assert result.exit_code == 0

    def test_show_project_only(self, runner):
        result = runner.invoke(config_command, ["show", "--project-only"])
        assert result.exit_code == 0

    def test_set_with_project_scope(self, runner):
        result = runner.invoke(config_command, ["set", "--project", "llm.model", "gpt-4o"])
        assert result.exit_code == 0
