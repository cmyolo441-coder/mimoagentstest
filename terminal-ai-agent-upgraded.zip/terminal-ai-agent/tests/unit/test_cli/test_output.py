"""Tests for terminal_agent.cli.output — output formatting."""

from __future__ import annotations

import io
import json

import pytest

from terminal_agent.cli.output import (
    Output,
    OutputFormat,
    Verbosity,
    get_output,
    init_output,
    reset_output,
)


@pytest.fixture
def out_stream():
    return io.StringIO()


@pytest.fixture
def colored_output(out_stream):
    return Output(format=OutputFormat.COLORED, stream=out_stream)


@pytest.fixture
def json_output(out_stream):
    return Output(format=OutputFormat.JSON, stream=out_stream)


@pytest.fixture
def quiet_output(out_stream):
    return Output(format=OutputFormat.QUIET, stream=out_stream)


class TestOutputFormat:
    def test_default_format(self):
        o = Output()
        assert o.format == OutputFormat.COLORED

    def test_set_format(self, out_stream):
        o = Output(format=OutputFormat.COLORED, stream=out_stream)
        o.set_format(OutputFormat.JSON)
        assert o.format == OutputFormat.JSON


class TestOutputPrint:
    def test_print_basic(self, colored_output, out_stream):
        colored_output.print("hello world")
        assert "hello world" in out_stream.getvalue()

    def test_print_quiet_suppressed(self, out_stream):
        o = Output(format=OutputFormat.QUIET, verbosity=Verbosity.QUIET, stream=out_stream)
        o.print("should not appear")
        assert out_stream.getvalue() == ""

    def test_print_verbose(self, out_stream):
        o = Output(format=OutputFormat.COLORED, verbosity=Verbosity.VERBOSE, stream=out_stream)
        o.print("visible")
        assert "visible" in out_stream.getvalue()


class TestOutputSuccess:
    def test_success_message(self, colored_output, out_stream):
        colored_output.success("done!")
        text = out_stream.getvalue()
        assert "done!" in text

    def test_success_json(self, json_output, out_stream):
        json_output.success("all good")
        data = json.loads(out_stream.getvalue().strip())
        assert data["type"] == "success"
        assert data["message"] == "all good"


class TestOutputError:
    def test_error_writes_to_stderr(self):
        stderr = io.StringIO()
        o = Output(format=OutputFormat.COLORED, stream=io.StringIO())
        # error() writes to sys.stderr by default
        import sys
        old_stderr = sys.stderr
        sys.stderr = stderr
        try:
            o.error("bad thing")
        finally:
            sys.stderr = old_stderr
        assert "bad thing" in stderr.getvalue()

    def test_error_json(self, json_output, out_stream):
        json_output.error("oops")
        data = json.loads(out_stream.getvalue().strip())
        assert data["type"] == "error"
        assert data["message"] == "oops"


class TestOutputWarning:
    def test_warning_message(self, colored_output, out_stream):
        colored_output.warning("careful")
        assert "careful" in out_stream.getvalue()


class TestOutputInfo:
    def test_info_message(self, colored_output, out_stream):
        colored_output.info("fyi")
        assert "fyi" in out_stream.getvalue()

    def test_info_quiet_suppressed(self, out_stream):
        o = Output(format=OutputFormat.QUIET, verbosity=Verbosity.QUIET, stream=out_stream)
        o.info("hidden")
        assert out_stream.getvalue() == ""


class TestOutputDebug:
    def test_debug_only_in_debug_mode(self, out_stream):
        o = Output(format=OutputFormat.COLORED, verbosity=Verbosity.NORMAL, stream=out_stream)
        o.debug("trace info")
        assert out_stream.getvalue() == ""

    def test_debug_visible_in_debug_mode(self, out_stream):
        o = Output(format=OutputFormat.COLORED, verbosity=Verbosity.DEBUG, stream=out_stream)
        o.debug("trace info")
        assert "trace info" in out_stream.getvalue()


class TestOutputStatus:
    def test_status_line(self, colored_output, out_stream):
        colored_output.status("Provider", "openai", status="success")
        text = out_stream.getvalue()
        assert "Provider" in text
        assert "openai" in text

    def test_status_json(self, json_output, out_stream):
        json_output.status("Model", "gpt-4o", status="info")
        data = json.loads(out_stream.getvalue().strip())
        assert data["type"] == "status"
        assert data["label"] == "Model"


class TestOutputTable:
    def test_table_basic(self, colored_output, out_stream):
        colored_output.table(["Name", "Age"], [["Alice", "30"], ["Bob", "25"]])
        text = out_stream.getvalue()
        assert "Alice" in text
        assert "Bob" in text

    def test_table_json(self, json_output, out_stream):
        json_output.table(["A", "B"], [["1", "2"]], title="Test")
        data = json.loads(out_stream.getvalue().strip())
        assert data["type"] == "table"
        assert len(data["data"]) == 1

    def test_table_quiet_suppressed(self, out_stream):
        o = Output(format=OutputFormat.QUIET, verbosity=Verbosity.QUIET, stream=out_stream)
        o.table(["A"], [["1"]])
        assert out_stream.getvalue() == ""


class TestOutputKeyValue:
    def test_key_value(self, colored_output, out_stream):
        colored_output.key_value({"key": "value", "other": "data"})
        text = out_stream.getvalue()
        assert "key" in text
        assert "value" in text

    def test_key_value_json(self, json_output, out_stream):
        json_output.key_value({"a": 1}, title="Info")
        data = json.loads(out_stream.getvalue().strip())
        assert data["type"] == "key_value"


class TestOutputListItems:
    def test_list_items(self, colored_output, out_stream):
        colored_output.list_items(["item1", "item2"])
        text = out_stream.getvalue()
        assert "item1" in text
        assert "item2" in text


class TestOutputProgress:
    def test_progress(self, colored_output, out_stream):
        colored_output.progress(5, 10, "Loading")
        text = out_stream.getvalue()
        assert "50%" in text

    def test_progress_done(self, colored_output, out_stream):
        colored_output.progress(10, 10)
        colored_output.progress_done()
        # Just verify no exceptions


class TestOutputHeader:
    def test_header(self, colored_output, out_stream):
        colored_output.header("Section")
        assert "Section" in out_stream.getvalue()

    def test_subheader(self, colored_output, out_stream):
        colored_output.subheader("Sub")
        assert "Sub" in out_stream.getvalue()


class TestOutputDivider:
    def test_divider(self, colored_output, out_stream):
        colored_output.divider()
        text = out_stream.getvalue()
        assert "─" in text


class TestOutputJsonPretty:
    def test_json_pretty(self, json_output, out_stream):
        json_output.json_pretty({"key": "value"})
        data = json.loads(out_stream.getvalue())
        assert data["key"] == "value"


class TestGlobalOutput:
    def test_get_output_singleton(self):
        reset_output()
        o1 = get_output()
        o2 = get_output()
        assert o1 is o2
        reset_output()

    def test_init_output(self):
        o = init_output(format=OutputFormat.JSON)
        assert o.format == OutputFormat.JSON
        reset_output()

    def test_reset_output(self):
        init_output()
        reset_output()
        assert get_output().format == OutputFormat.COLORED  # fresh default
        reset_output()
