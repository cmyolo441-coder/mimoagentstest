"""Tests for the top-level main.py launcher."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest

_ROOT = Path(__file__).resolve().parents[2]
_MAIN_PATH = _ROOT / "main.py"


def _load_main():
    """Load main.py as an isolated module (it lives outside the package)."""
    spec = importlib.util.spec_from_file_location("ta_main_launcher", _MAIN_PATH)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TestMainLauncher:
    def test_main_py_exists_at_root(self):
        assert _MAIN_PATH.is_file()

    def test_load_module(self):
        mod = _load_main()
        assert hasattr(mod, "main")
        assert callable(mod.main)

    def test_version_returns_zero(self):
        mod = _load_main()
        rc = mod.main(["--version"])
        assert rc == 0

    def test_help_returns_zero(self):
        mod = _load_main()
        rc = mod.main(["--help"])
        assert rc == 0

    def test_unknown_command_returns_nonzero(self):
        mod = _load_main()
        rc = mod.main(["definitely-not-a-real-command"])
        assert rc != 0

    def test_src_is_on_path_after_import(self):
        _load_main()
        src = str(_ROOT / "src")
        assert src in sys.path

    def test_self_check_imports_every_module(self):
        """--self-check must pass: every module in the project imports cleanly.

        This is a regression guard — it catches circular imports, syntax
        errors, and tools that crash on instantiation, none of which the rest
        of the suite reliably surfaces.
        """
        mod = _load_main()
        rc = mod.main(["--self-check"])
        assert rc == 0

    def test_iter_package_modules_is_comprehensive(self):
        mod = _load_main()
        names = mod._iter_package_modules()
        # Sanity: we discover hundreds of modules, including known core ones.
        assert len(names) > 500
        assert "terminal_agent.cli.app" in names
        assert "terminal_agent.tools.filesystem.read" in names
