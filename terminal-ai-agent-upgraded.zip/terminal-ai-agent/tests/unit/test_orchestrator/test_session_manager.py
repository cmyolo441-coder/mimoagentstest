"""Tests for terminal_agent.orchestrator.session_manager — session lifecycle."""

from __future__ import annotations

import pytest

from terminal_agent.orchestrator.session_manager import SessionManager
from terminal_agent.types import Session, SessionStatus, TraceEntry
from terminal_agent.exceptions import SessionError


@pytest.fixture
def mgr():
    return SessionManager()


class TestSessionManagerCreate:
    def test_create_session(self, mgr):
        session = mgr.create_session("Fix the bug")
        assert isinstance(session, Session)
        assert session.goal == "Fix the bug"
        assert session.status == SessionStatus.PENDING
        assert session.id is not None

    def test_create_with_model(self, mgr):
        session = mgr.create_session("Test", model="gpt-4o")
        assert session.model_used == "gpt-4o"

    def test_unique_ids(self, mgr):
        s1 = mgr.create_session("Goal 1")
        s2 = mgr.create_session("Goal 2")
        assert s1.id != s2.id


class TestSessionManagerLifecycle:
    def test_start_session(self, mgr):
        session = mgr.create_session("Test")
        started = mgr.start_session(session.id)
        assert started.status == SessionStatus.RUNNING

    def test_start_non_pending_raises(self, mgr):
        session = mgr.create_session("Test")
        mgr.start_session(session.id)
        with pytest.raises(SessionError):
            mgr.start_session(session.id)

    def test_complete_session(self, mgr):
        session = mgr.create_session("Test")
        mgr.start_session(session.id)
        completed = mgr.complete_session(session.id, outcome="Done")
        assert completed.status == SessionStatus.COMPLETED
        assert completed.end_time > 0

    def test_fail_session(self, mgr):
        session = mgr.create_session("Test")
        mgr.start_session(session.id)
        failed = mgr.fail_session(session.id, error_message="Something broke")
        assert failed.status == SessionStatus.FAILED
        assert failed.error_message == "Something broke"

    def test_cancel_session(self, mgr):
        session = mgr.create_session("Test")
        mgr.start_session(session.id)
        cancelled = mgr.cancel_session(session.id)
        assert cancelled.status == SessionStatus.CANCELLED

    def test_timeout_session(self, mgr):
        session = mgr.create_session("Test")
        mgr.start_session(session.id)
        timed_out = mgr.timeout_session(session.id)
        assert timed_out.status == SessionStatus.TIMEOUT


class TestSessionManagerPauseResume:
    def test_pause_and_resume(self, mgr):
        session = mgr.create_session("Test")
        mgr.start_session(session.id)
        paused = mgr.pause_session(session.id)
        assert paused.status == SessionStatus.PAUSED

        resumed = mgr.resume_session(session.id)
        assert resumed.status == SessionStatus.RUNNING

    def test_pause_non_running_raises(self, mgr):
        session = mgr.create_session("Test")
        with pytest.raises(SessionError):
            mgr.pause_session(session.id)

    def test_resume_non_paused_raises(self, mgr):
        with pytest.raises(SessionError):
            mgr.resume_session("nonexistent")


class TestSessionManagerQueries:
    def test_get_session(self, mgr):
        session = mgr.create_session("Test")
        assert mgr.get_session(session.id) is session

    def test_get_nonexistent(self, mgr):
        assert mgr.get_session("nonexistent") is None

    def test_get_active_sessions(self, mgr):
        mgr.create_session("Goal 1")
        mgr.create_session("Goal 2")
        active = mgr.get_active_sessions()
        assert len(active) == 2

    def test_get_paused_sessions(self, mgr):
        session = mgr.create_session("Test")
        mgr.start_session(session.id)
        mgr.pause_session(session.id)
        paused = mgr.get_paused_sessions()
        assert len(paused) == 1


class TestSessionManagerTraces:
    def test_add_trace(self, mgr):
        session = mgr.create_session("Test")
        entry = TraceEntry(
            timestamp=100.0,
            entry_type="thought",
            content="Analyzing...",
        )
        mgr.add_trace(session.id, entry)
        s = mgr.get_session(session.id)
        assert len(s.traces) == 1


class TestSessionManagerTokens:
    def test_update_tokens(self, mgr):
        session = mgr.create_session("Test")
        mgr.update_tokens(session.id, tokens=100, cost=0.005)
        s = mgr.get_session(session.id)
        assert s.total_tokens == 100
        assert s.total_cost == 0.005

    def test_increment_steps(self, mgr):
        session = mgr.create_session("Test")
        mgr.increment_steps(session.id)
        mgr.increment_steps(session.id)
        s = mgr.get_session(session.id)
        assert s.total_steps == 2
