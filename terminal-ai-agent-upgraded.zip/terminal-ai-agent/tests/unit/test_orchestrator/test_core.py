"""Tests for terminal_agent.orchestrator.core — the main agent loop."""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock

from terminal_agent.orchestrator.core import AgentLoop
from terminal_agent.types import SessionStatus


class TestAgentLoopInit:
    def test_default_init(self):
        loop = AgentLoop()
        assert loop._termination is not None

    def test_custom_params(self):
        loop = AgentLoop(max_iterations=50, max_cost=10.0, parallel=True)
        assert loop._parallel is True

    def test_session_none_initially(self):
        loop = AgentLoop()
        assert loop.session is None

    def test_lifecycle_accessible(self):
        loop = AgentLoop()
        assert loop.lifecycle is not None

    def test_with_mock_llm(self):
        llm = MagicMock()
        loop = AgentLoop(llm=llm)
        assert loop._llm is llm
