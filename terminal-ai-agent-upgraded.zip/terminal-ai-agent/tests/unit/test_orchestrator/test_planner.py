"""Tests for terminal_agent.orchestrator.planner — plan generation."""

from __future__ import annotations

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock

from terminal_agent.orchestrator.planner import Planner
from terminal_agent.orchestrator.goal_parser import GoalParser, GoalType, ParsedGoal
from terminal_agent.types import GoalComplexity, Plan, PlanStep, SessionStatus


@pytest.fixture
def planner():
    return Planner(llm=None)


@pytest.fixture
def parser():
    return GoalParser()


@pytest.mark.asyncio
class TestPlannerTemplatePlan:
    async def test_file_operation_plan(self, planner):
        parsed = ParsedGoal(
            raw_text="Create config.toml",
            goal_type=GoalType.FILE_OPERATION,
            complexity=GoalComplexity.SIMPLE,
        )
        plan = await planner.generate_plan(parsed)
        assert isinstance(plan, Plan)
        assert len(plan.steps) >= 2
        assert plan.goal == "Create config.toml"

    async def test_code_generation_plan(self, planner):
        parsed = ParsedGoal(
            raw_text="Write a REST API",
            goal_type=GoalType.CODE_GENERATION,
            complexity=GoalComplexity.MODERATE,
        )
        plan = await planner.generate_plan(parsed)
        assert len(plan.steps) >= 3

    async def test_debugging_plan(self, planner):
        parsed = ParsedGoal(
            raw_text="Fix the login bug",
            goal_type=GoalType.DEBUGGING,
            complexity=GoalComplexity.MODERATE,
        )
        plan = await planner.generate_plan(parsed)
        assert len(plan.steps) >= 3

    async def test_unknown_type_plan(self, planner):
        parsed = ParsedGoal(
            raw_text="Do something",
            goal_type=GoalType.UNKNOWN,
            complexity=GoalComplexity.MODERATE,
        )
        plan = await planner.generate_plan(parsed)
        assert len(plan.steps) >= 1

    async def test_all_steps_pending(self, planner):
        parsed = ParsedGoal(
            raw_text="Test",
            goal_type=GoalType.TESTING,
            complexity=GoalComplexity.SIMPLE,
        )
        plan = await planner.generate_plan(parsed)
        for step in plan.steps:
            assert step.status == SessionStatus.PENDING

    async def test_steps_have_dependencies(self, planner):
        parsed = ParsedGoal(
            raw_text="Build API",
            goal_type=GoalType.CODE_GENERATION,
            complexity=GoalComplexity.MODERATE,
        )
        plan = await planner.generate_plan(parsed)
        if len(plan.steps) > 1:
            assert len(plan.steps[1].dependencies) > 0


@pytest.mark.asyncio
class TestPlannerSubGoals:
    async def test_uses_sub_goals(self, planner):
        parsed = ParsedGoal(
            raw_text="Do A and then B",
            goal_type=GoalType.UNKNOWN,
            complexity=GoalComplexity.MODERATE,
            sub_goals=["Step A", "Step B"],
        )
        plan = await planner.generate_plan(parsed)
        assert len(plan.steps) == 2


@pytest.mark.asyncio
class TestPlannerRegenerate:
    async def test_regenerate_keeps_completed(self, planner):
        original = Plan(
            goal="test",
            steps=[
                PlanStep(id="step_1", description="A", status=SessionStatus.COMPLETED),
                PlanStep(id="step_2", description="B", status=SessionStatus.PENDING),
            ],
        )
        new_plan = await planner.regenerate_plan(
            original, completed_steps=["step_1"], failed_step="step_2"
        )
        assert new_plan.steps[0].status == SessionStatus.COMPLETED


class TestPlannerParsePlanResponse:
    def test_parse_steps(self):
        response = "STEP: Read the file\nDEPENDS_ON: none\nSTEP: Edit the file\nDEPENDS_ON: 1"
        steps = Planner._parse_plan_response(response)
        assert len(steps) == 2
        assert steps[0].description == "Read the file"
        assert steps[1].dependencies == ["step_1"]

    def test_parse_single_step(self):
        response = "STEP: Do something"
        steps = Planner._parse_plan_response(response)
        assert len(steps) == 1

    def test_parse_empty(self):
        steps = Planner._parse_plan_response("")
        assert len(steps) == 0
