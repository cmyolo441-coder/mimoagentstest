"""Tests for terminal_agent.orchestrator.goal_parser — goal parsing."""

from __future__ import annotations

import pytest

from terminal_agent.orchestrator.goal_parser import GoalParser, GoalType, ParsedGoal
from terminal_agent.types import GoalComplexity


@pytest.fixture
def parser():
    return GoalParser()


class TestGoalParserParse:
    def test_empty_goal(self, parser):
        result = parser.parse("")
        assert result.raw_text == ""
        assert result.confidence == 0.0

    def test_simple_goal(self, parser):
        result = parser.parse("Fix the login bug")
        assert result.raw_text == "Fix the login bug"
        assert result.goal_type != GoalType.UNKNOWN or result.confidence > 0

    def test_returns_parsed_goal(self, parser):
        result = parser.parse("Create a Python script")
        assert isinstance(result, ParsedGoal)


class TestGoalTypeClassification:
    def test_file_operation(self, parser):
        result = parser.parse("Create a new file called config.toml")
        assert result.goal_type == GoalType.FILE_OPERATION

    def test_code_generation(self, parser):
        result = parser.parse("Write a function to calculate fibonacci numbers")
        assert result.goal_type == GoalType.CODE_GENERATION

    def test_debugging(self, parser):
        result = parser.parse("Fix the error in auth module")
        assert result.goal_type in (GoalType.DEBUGGING, GoalType.CODE_MODIFICATION, GoalType.MULTI_STEP)

    def test_testing(self, parser):
        result = parser.parse("Write tests for the user module")
        assert result.goal_type in (GoalType.TESTING, GoalType.MULTI_STEP)

    def test_git_operation(self, parser):
        result = parser.parse("Commit the changes with a message")
        assert result.goal_type == GoalType.GIT_OPERATION

    def test_package_management(self, parser):
        result = parser.parse("Install the requests library")
        assert result.goal_type == GoalType.PACKAGE_MANAGEMENT

    def test_docker_operation(self, parser):
        result = parser.parse("Build the docker image")
        assert result.goal_type == GoalType.DOCKER_OPERATION

    def test_documentation(self, parser):
        result = parser.parse("Write documentation for the API")
        assert result.goal_type in (GoalType.DOCUMENTATION, GoalType.MULTI_STEP)

    def test_refactoring(self, parser):
        result = parser.parse("Refactor the database module")
        assert result.goal_type in (GoalType.REFACTORING, GoalType.MULTI_STEP)

    def test_project_setup(self, parser):
        result = parser.parse("Set up a new Python project")
        assert result.goal_type == GoalType.PROJECT_SETUP

    def test_search(self, parser):
        result = parser.parse("Find all TODO comments in the codebase")
        assert result.goal_type == GoalType.SEARCH

    def test_analysis(self, parser):
        result = parser.parse("Analyze the performance of the API")
        assert result.goal_type == GoalType.ANALYSIS

    def test_unknown_goal(self, parser):
        result = parser.parse("xyzzy")
        assert result.goal_type == GoalType.UNKNOWN


class TestGoalComplexity:
    def test_simple_goal(self, parser):
        result = parser.parse("Fix typo")
        assert result.complexity == GoalComplexity.SIMPLE

    def test_complex_goal(self, parser):
        result = parser.parse("Refactor the entire system and then deploy to production")
        assert result.complexity in (GoalComplexity.COMPLEX, GoalComplexity.MULTI_SYSTEM)

    def test_multi_system_goal(self, parser):
        result = parser.parse("Set up frontend and backend with database")
        assert result.complexity in (GoalComplexity.COMPLEX, GoalComplexity.MULTI_SYSTEM)


class TestGoalSubGoals:
    def test_extract_sub_goals(self, parser):
        result = parser.parse("Create the file and then write the tests")
        # Should detect multiple sub-goals
        assert len(result.sub_goals) >= 1

    def test_single_goal_no_sub_goals(self, parser):
        result = parser.parse("Fix the bug")
        # Simple single goal should have no sub-goals
        assert isinstance(result.sub_goals, list)


class TestGoalConstraints:
    def test_negative_constraint(self, parser):
        result = parser.parse("Deploy without downtime")
        assert any("without" in c.lower() for c in result.constraints)

    def test_requirement(self, parser):
        result = parser.parse("Build the API must use FastAPI")
        assert any("must" in c.lower() for c in result.constraints)


class TestGoalEntities:
    def test_file_entities(self, parser):
        result = parser.parse("Edit main.py and test_main.py")
        assert "files" in result.entities
        assert any("main.py" in f for f in result.entities["files"])

    def test_tool_entities(self, parser):
        result = parser.parse("Use git to commit the changes")
        assert "tools" in result.entities
        assert "git" in result.entities["tools"]


class TestGoalConfirmation:
    def test_destructive_needs_confirmation(self, parser):
        result = parser.parse("Delete the old database files")
        assert result.requires_confirmation is True

    def test_safe_goal_no_confirmation(self, parser):
        result = parser.parse("Read the README file")
        assert result.requires_confirmation is False


class TestGoalLanguageDetection:
    def test_detect_python(self, parser):
        result = parser.parse("Write a Python function")
        assert result.language_hint == "python"

    def test_detect_javascript(self, parser):
        result = parser.parse("Create a React component")
        assert result.language_hint == "javascript"

    def test_no_language_hint(self, parser):
        result = parser.parse("Fix the bug")
        # Might or might not detect a language
        assert result.language_hint is None or isinstance(result.language_hint, str)


class TestGoalConfidence:
    def test_unknown_low_confidence(self, parser):
        result = parser.parse("xyzzy")
        assert result.confidence <= 0.5

    def test_typed_goal_higher_confidence(self, parser):
        result = parser.parse("Create a Python function for sorting")
        assert result.confidence > 0.5
