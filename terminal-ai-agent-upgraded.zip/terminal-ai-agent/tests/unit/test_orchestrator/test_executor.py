"""Tests for terminal_agent.orchestrator.executor — step execution."""

from __future__ import annotations

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock

from terminal_agent.orchestrator.executor import StepExecutor
from terminal_agent.types import (
    PlanStep, SessionStatus, ToolCall, ToolResult, ToolResultStatus, LLMResponse,
)
from terminal_agent.exceptions import ExecutionError


@pytest.fixture
def mock_dispatcher():
    dispatcher = AsyncMock()
    dispatcher.dispatch = AsyncMock(return_value=ToolResult(
        status=ToolResultStatus.SUCCESS,
        output="success",
        exit_code=0,
    ))
    return dispatcher


@pytest.fixture
def executor(mock_dispatcher):
    return StepExecutor(tool_dispatcher=mock_dispatcher, max_retries=2, step_timeout=10.0)


@pytest.fixture
def simple_step():
    return PlanStep(id="step_1", description="Test step")


class TestStepExecutorExecute:
    @pytest.mark.asyncio
    async def test_successful_execution(self, executor, simple_step):
        result = await executor.execute(simple_step)
        assert result.status in (ToolResultStatus.SUCCESS, ToolResultStatus.PARTIAL)
        assert simple_step.status == SessionStatus.COMPLETED

    @pytest.mark.asyncio
    async def test_with_tool_hint(self, executor):
        step = PlanStep(id="step_1", description="Test", tool_hint="shell.execute")
        result = await executor.execute(step)
        assert step.status == SessionStatus.COMPLETED

    @pytest.mark.asyncio
    async def test_failure_after_retries(self, mock_dispatcher):
        mock_dispatcher.dispatch.return_value = ToolResult(
            status=ToolResultStatus.ERROR,
            error="command failed",
            exit_code=1,
        )
        executor = StepExecutor(tool_dispatcher=mock_dispatcher, max_retries=1)
        step = PlanStep(id="step_1", description="Test")
        with pytest.raises(ExecutionError):
            await executor.execute(step)
        assert step.status == SessionStatus.FAILED


class TestStepExecutorDetermineToolCall:
    @pytest.mark.asyncio
    async def test_with_tool_hint(self, executor):
        step = PlanStep(id="step_1", description="Test", tool_hint="shell.execute")
        call = await executor.determine_tool_call(step)
        assert call.name == "shell.execute"

    @pytest.mark.asyncio
    async def test_without_tool_hint(self, executor):
        step = PlanStep(id="step_1", description="Run tests")
        call = await executor.determine_tool_call(step)
        assert call.name == "shell.execute"


class TestStepExecutorParseToolCallResponse:
    def test_parse_json_response(self):
        content = '{"tool": "filesystem.read", "parameters": {"path": "/tmp/test.txt"}}'
        call = StepExecutor._parse_tool_call_response(content)
        assert call.name == "filesystem.read"
        assert call.parameters["path"] == "/tmp/test.txt"

    def test_parse_fallback(self):
        content = "just run this command"
        call = StepExecutor._parse_tool_call_response(content)
        assert call.name == "shell.execute"
