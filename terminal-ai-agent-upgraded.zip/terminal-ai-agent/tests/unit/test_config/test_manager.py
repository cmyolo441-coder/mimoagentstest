"""Tests for terminal_agent.config.manager — configuration manager."""

from __future__ import annotations

import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from terminal_agent.config.manager import ConfigManager
from terminal_agent.config.schema import AgentConfig
from terminal_agent.exceptions import ConfigError


@pytest.fixture(autouse=True)
def reset_manager():
    """Reset ConfigManager singleton before each test."""
    ConfigManager.reset()
    yield
    ConfigManager.reset()


class TestConfigManagerInit:
    def test_creates_with_defaults(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        assert mgr._config is not None
        assert isinstance(mgr._config, AgentConfig)

    def test_singleton_get(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        ConfigManager.init(global_path=cfg_path, watch=False)
        cfg = ConfigManager.get()
        assert isinstance(cfg, AgentConfig)

    def test_reset_clears_singleton(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        ConfigManager.init(global_path=cfg_path, watch=False)
        ConfigManager.reset()
        assert ConfigManager._instance is None


class TestConfigManagerGetValue:
    def test_get_dotted_key(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        assert mgr.get_value("llm.provider") == "openai"

    def test_get_nested_key(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        assert mgr.get_value("safety.level") == 2

    def test_get_missing_key_returns_default(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        assert mgr.get_value("nonexistent.key", "fallback") == "fallback"

    def test_get_deeply_nested(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        assert mgr.get_value("tools.shell.timeout") == 300


class TestConfigManagerSet:
    def test_set_value(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        mgr.set_value("llm.model", "gpt-4-turbo")
        assert mgr.get_value("llm.model") == "gpt-4-turbo"

    def test_set_creates_nested(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        mgr.set_value("custom.new.key", "value")
        assert mgr.get_value("custom.new.key") == "value"


class TestConfigManagerProfiles:
    def test_list_profiles_empty(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        profiles = mgr.list_profiles()
        assert isinstance(profiles, list)


class TestConfigManagerDiff:
    def test_diff_from_defaults_empty(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        diff = mgr.diff_from_defaults()
        # When using defaults, diff should be minimal
        assert isinstance(diff, dict)


class TestConfigManagerExplain:
    def test_explain_known_key(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        result = mgr.explain("llm.provider")
        assert "openai" in result or "LLM" in result or "provider" in result.lower()

    def test_explain_unknown_key(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        result = mgr.explain("unknown.key")
        assert isinstance(result, str)


class TestConfigManagerRaw:
    def test_get_raw(self, tmp_path):
        cfg_path = tmp_path / "config.toml"
        mgr = ConfigManager(global_path=cfg_path, watch=False)
        raw = mgr.get_raw()
        assert isinstance(raw, dict)
        assert "llm" in raw
