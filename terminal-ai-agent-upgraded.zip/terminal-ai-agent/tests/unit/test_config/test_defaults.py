"""Tests for terminal_agent.config.defaults — default configuration values."""

from __future__ import annotations

import pytest

from terminal_agent.config.defaults import get_defaults, get_defaults_flat


class TestGetDefaults:
    def test_returns_dict(self):
        d = get_defaults()
        assert isinstance(d, dict)

    def test_has_required_sections(self):
        d = get_defaults()
        for section in ("llm", "memory", "safety", "tools", "cache", "logging", "ui", "cost"):
            assert section in d, f"Missing section: {section}"

    def test_llm_defaults(self):
        d = get_defaults()
        assert d["llm"]["provider"] == "openai"
        assert d["llm"]["model"] == "gpt-4o"
        assert d["llm"]["temperature"] == 0.0
        assert d["llm"]["max_tokens"] == 4096
        assert d["llm"]["stream"] is True

    def test_safety_defaults(self):
        d = get_defaults()
        assert d["safety"]["level"] == 2
        assert d["safety"]["confirm_destructive"] is True
        assert isinstance(d["safety"]["blocked_commands"], list)
        assert len(d["safety"]["blocked_commands"]) > 0

    def test_memory_defaults(self):
        d = get_defaults()
        assert d["memory"]["backend"] == "chroma"
        assert d["memory"]["short_term_turns"] == 20
        assert d["memory"]["embedding_dimensions"] == 1536

    def test_cost_defaults(self):
        d = get_defaults()
        assert d["cost"]["max_cost_per_task"] == 5.0
        assert d["cost"]["warning_threshold"] == 0.8
        assert d["cost"]["currency"] == "USD"

    def test_config_version(self):
        d = get_defaults()
        assert d["config_version"] == 1

    def test_all_values_are_serializable(self):
        """All defaults should be TOML-compatible (no complex objects)."""
        import json
        d = get_defaults()
        # Should not raise
        json.dumps(d)


class TestGetDefaultsFlat:
    def test_returns_dict(self):
        d = get_defaults_flat()
        assert isinstance(d, dict)

    def test_dotted_keys(self):
        d = get_defaults_flat()
        assert "llm.provider" in d
        assert "llm.model" in d
        assert "safety.level" in d
        assert "memory.backend" in d

    def test_values_match_nested(self):
        nested = get_defaults()
        flat = get_defaults_flat()
        assert flat["llm.provider"] == nested["llm"]["provider"]
        assert flat["safety.level"] == nested["safety"]["level"]

    def test_no_empty_keys(self):
        d = get_defaults_flat()
        for key in d:
            assert key, f"Empty key found"
            assert "." in key or key == "config_version" or key == "active_profile"
