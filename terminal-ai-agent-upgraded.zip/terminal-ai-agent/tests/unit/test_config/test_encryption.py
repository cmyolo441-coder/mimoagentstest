"""Tests for terminal_agent.config.encryption — encrypt/decrypt sensitive values."""

from __future__ import annotations

import pytest

from terminal_agent.config.encryption import ConfigEncryption, _ENCRYPTED_PREFIX


class TestConfigEncryptionDisabled:
    def test_no_passphrase_disables_encryption(self):
        enc = ConfigEncryption()
        assert enc.enabled is False

    def test_encrypt_value_passthrough(self):
        enc = ConfigEncryption()
        assert enc.encrypt_value("my-api-key") == "my-api-key"

    def test_decrypt_value_passthrough(self):
        enc = ConfigEncryption()
        assert enc.decrypt_value("plaintext") == "plaintext"

    def test_decrypt_non_prefixed_passthrough(self):
        enc = ConfigEncryption()
        assert enc.decrypt_value("some-value") == "some-value"


class TestConfigEncryptionEnabled:
    @pytest.fixture
    def enc(self):
        return ConfigEncryption(passphrase="test-passphrase-123")

    def test_enabled(self, enc):
        assert enc.enabled is True

    def test_encrypt_decrypt_roundtrip(self, enc):
        plaintext = "sk-secret-api-key-12345"
        encrypted = enc.encrypt_value(plaintext)
        assert encrypted != plaintext
        assert encrypted.startswith(_ENCRYPTED_PREFIX)
        decrypted = enc.decrypt_value(encrypted)
        assert decrypted == plaintext

    def test_encrypt_empty_string(self, enc):
        encrypted = enc.encrypt_value("")
        assert enc.decrypt_value(encrypted) == ""

    def test_encrypt_unicode(self, enc):
        plaintext = "日本語テスト🔑"
        encrypted = enc.encrypt_value(plaintext)
        assert enc.decrypt_value(encrypted) == plaintext

    def test_decrypt_wrong_passphrase_fails(self):
        enc1 = ConfigEncryption(passphrase="passphrase-one")
        encrypted = enc1.encrypt_value("secret")
        enc2 = ConfigEncryption(passphrase="passphrase-two")
        with pytest.raises(Exception):
            enc2.decrypt_value(encrypted)


class TestSensitiveFieldDetection:
    @pytest.fixture
    def enc(self):
        return ConfigEncryption(passphrase="test-pass")

    def test_encrypts_api_key(self, enc):
        cfg = {"llm": {"api_key": "sk-12345"}}
        result = enc.encrypt_sensitive_fields(cfg)
        assert result["llm"]["api_key"] != "sk-12345"
        assert result["llm"]["api_key"].startswith(_ENCRYPTED_PREFIX)

    def test_encrypts_token(self, enc):
        cfg = {"service": {"token": "my-token"}}
        result = enc.encrypt_sensitive_fields(cfg)
        assert result["service"]["token"].startswith(_ENCRYPTED_PREFIX)

    def test_leaves_non_sensitive_alone(self, enc):
        cfg = {"llm": {"model": "gpt-4o", "provider": "openai"}}
        result = enc.encrypt_sensitive_fields(cfg)
        assert result["llm"]["model"] == "gpt-4o"
        assert result["llm"]["provider"] == "openai"

    def test_decrypt_sensitive_fields_roundtrip(self, enc):
        cfg = {"llm": {"api_key": "sk-12345", "model": "gpt-4o"}}
        encrypted = enc.encrypt_sensitive_fields(cfg)
        decrypted = enc.decrypt_sensitive_fields(encrypted)
        assert decrypted["llm"]["api_key"] == "sk-12345"
        assert decrypted["llm"]["model"] == "gpt-4o"

    def test_nested_sensitive_fields(self, enc):
        cfg = {
            "providers": {
                "openai": {"api_key": "sk-openai"},
                "anthropic": {"api_key": "sk-anthropic"},
            }
        }
        result = enc.encrypt_sensitive_fields(cfg)
        assert result["providers"]["openai"]["api_key"].startswith(_ENCRYPTED_PREFIX)
        assert result["providers"]["anthropic"]["api_key"].startswith(_ENCRYPTED_PREFIX)

    def test_does_not_mutate_original(self, enc):
        cfg = {"llm": {"api_key": "sk-12345"}}
        enc.encrypt_sensitive_fields(cfg)
        assert cfg["llm"]["api_key"] == "sk-12345"


class TestGeneratePassphrase:
    def test_generates_string(self):
        pp = ConfigEncryption.generate_passphrase()
        assert isinstance(pp, str)

    def test_length(self):
        pp = ConfigEncryption.generate_passphrase()
        assert len(pp) >= 24

    def test_unique(self):
        pps = {ConfigEncryption.generate_passphrase() for _ in range(10)}
        assert len(pps) == 10
