"""Tests for terminal_agent.config.merger — config merging with precedence."""

from __future__ import annotations

import os
import pytest

from terminal_agent.config.merger import ConfigMerger


class TestConfigMergerMerge:
    def test_empty_merge(self):
        result = ConfigMerger.merge()
        assert result == {}

    def test_global_only(self):
        result = ConfigMerger.merge(global_cfg={"llm": {"model": "gpt-4"}})
        assert result["llm"]["model"] == "gpt-4"

    def test_project_overrides_global(self):
        result = ConfigMerger.merge(
            global_cfg={"llm": {"model": "gpt-4", "provider": "openai"}},
            project_cfg={"llm": {"model": "gpt-4o"}},
        )
        assert result["llm"]["model"] == "gpt-4o"
        assert result["llm"]["provider"] == "openai"

    def test_env_overrides_project(self):
        result = ConfigMerger.merge(
            global_cfg={"llm": {"model": "gpt-4"}},
            project_cfg={"llm": {"model": "gpt-4o"}},
            env_overrides={"llm": {"model": "claude-3"}},
        )
        assert result["llm"]["model"] == "claude-3"

    def test_cli_overrides_all(self):
        result = ConfigMerger.merge(
            global_cfg={"llm": {"model": "gpt-4"}},
            project_cfg={"llm": {"model": "gpt-4o"}},
            env_overrides={"llm": {"model": "claude-3"}},
            cli_overrides={"llm": {"model": "o1"}},
        )
        assert result["llm"]["model"] == "o1"

    def test_none_layers_skipped(self):
        result = ConfigMerger.merge(
            global_cfg=None,
            project_cfg=None,
            env_overrides=None,
            cli_overrides=None,
        )
        assert result == {}

    def test_deep_merge_preserves_keys(self):
        result = ConfigMerger.merge(
            global_cfg={"a": {"b": 1, "c": 2}},
            project_cfg={"a": {"c": 3}},
        )
        assert result["a"]["b"] == 1
        assert result["a"]["c"] == 3


class TestConfigMergerReadEnv:
    def test_reads_env_vars(self, monkeypatch):
        monkeypatch.setenv("TA_LLM__PROVIDER", "anthropic")
        monkeypatch.setenv("TA_LLM__MODEL", "claude-3")
        result = ConfigMerger.read_env(prefix="TA_")
        assert result["llm"]["provider"] == "anthropic"
        assert result["llm"]["model"] == "claude-3"

    def test_coerces_boolean(self, monkeypatch):
        monkeypatch.setenv("TA_LLM__STREAM", "true")
        result = ConfigMerger.read_env(prefix="TA_")
        assert result["llm"]["stream"] is True

    def test_coerces_int(self, monkeypatch):
        monkeypatch.setenv("TA_SAFETY__LEVEL", "3")
        result = ConfigMerger.read_env(prefix="TA_")
        assert result["safety"]["level"] == 3

    def test_coerces_float(self, monkeypatch):
        monkeypatch.setenv("TA_COST__MAX_COST_PER_TASK", "10.5")
        result = ConfigMerger.read_env(prefix="TA_")
        assert result["cost"]["max_cost_per_task"] == 10.5

    def test_coerces_list(self, monkeypatch):
        monkeypatch.setenv("TA_LLM__FALLBACK_PROVIDERS", "anthropic,google")
        result = ConfigMerger.read_env(prefix="TA_")
        assert result["llm"]["fallback_providers"] == ["anthropic", "google"]

    def test_ignores_non_prefixed(self, monkeypatch):
        monkeypatch.setenv("OTHER_VAR", "value")
        result = ConfigMerger.read_env(prefix="TA_")
        assert "other" not in result

    def test_single_part_key_ignored(self, monkeypatch):
        monkeypatch.setenv("TA_NOPREFIX", "value")
        result = ConfigMerger.read_env(prefix="TA_")
        assert result == {}


class TestConfigMergerFlatToNested:
    def test_simple(self):
        result = ConfigMerger.flat_to_nested({"llm.model": "gpt-4o"})
        assert result == {"llm": {"model": "gpt-4o"}}

    def test_nested(self):
        result = ConfigMerger.flat_to_nested({"tools.shell.timeout": "300"})
        assert result == {"tools": {"shell": {"timeout": "300"}}}

    def test_multiple_keys(self):
        result = ConfigMerger.flat_to_nested({
            "llm.model": "gpt-4o",
            "llm.provider": "openai",
        })
        assert result["llm"]["model"] == "gpt-4o"
        assert result["llm"]["provider"] == "openai"


class TestDeepMerge:
    def test_mutates_base(self):
        base = {"a": 1}
        ConfigMerger._deep_merge(base, {"b": 2})
        assert base == {"a": 1, "b": 2}

    def test_deep_nested(self):
        base = {"a": {"b": {"c": 1}}}
        ConfigMerger._deep_merge(base, {"a": {"b": {"d": 2}}})
        assert base["a"]["b"] == {"c": 1, "d": 2}

    def test_override_replaces_non_dict(self):
        base = {"a": [1, 2]}
        ConfigMerger._deep_merge(base, {"a": [3, 4]})
        assert base["a"] == [3, 4]
