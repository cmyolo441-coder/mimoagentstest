"""Tests for terminal_agent.config.schema — dataclass schema definitions."""

from __future__ import annotations

import pytest
from dataclasses import fields

from terminal_agent.config.schema import (
    AgentConfig,
    LLMConfig,
    MemoryConfig,
    SafetyConfig,
    ToolsConfig,
    CacheConfig,
    LoggingConfig,
    UIConfig,
    CostConfig,
    LLMProviderConfig,
    MCPServerConfig,
)


class TestLLMConfig:
    def test_defaults(self):
        cfg = LLMConfig()
        assert cfg.provider == "openai"
        assert cfg.model == "gpt-4o"
        assert cfg.temperature == 0.0
        assert cfg.max_tokens == 4096
        assert cfg.stream is True

    def test_custom_values(self):
        cfg = LLMConfig(provider="anthropic", model="claude-3", temperature=0.5)
        assert cfg.provider == "anthropic"
        assert cfg.temperature == 0.5

    def test_fallback_providers_default_empty(self):
        cfg = LLMConfig()
        assert cfg.fallback_providers == []


class TestMemoryConfig:
    def test_defaults(self):
        cfg = MemoryConfig()
        assert cfg.backend == "chroma"
        assert cfg.short_term_turns == 20
        assert cfg.embedding_dimensions == 1536


class TestSafetyConfig:
    def test_defaults(self):
        cfg = SafetyConfig()
        assert cfg.level == 2
        assert cfg.confirm_destructive is True
        assert cfg.sandbox_mode is False

    def test_blocked_commands_default(self):
        cfg = SafetyConfig()
        assert isinstance(cfg.blocked_commands, list)


class TestToolsConfig:
    def test_defaults(self):
        cfg = ToolsConfig()
        assert cfg.shell.timeout == 300
        assert cfg.filesystem.backup_before_edit is True


class TestCacheConfig:
    def test_defaults(self):
        cfg = CacheConfig()
        assert cfg.backend == "memory"
        assert cfg.ttl == 3600
        assert cfg.eviction_policy == "lru"


class TestLoggingConfig:
    def test_defaults(self):
        cfg = LoggingConfig()
        assert cfg.level == "INFO"
        assert cfg.console is True


class TestCostConfig:
    def test_defaults(self):
        cfg = CostConfig()
        assert cfg.max_cost_per_task == 5.0
        assert cfg.warning_threshold == 0.8
        assert cfg.currency == "USD"


class TestAgentConfig:
    def test_defaults(self):
        cfg = AgentConfig()
        assert cfg.config_version == 1
        assert cfg.llm.provider == "openai"
        assert cfg.memory.backend == "chroma"
        assert cfg.safety.level == 2

    def test_to_dict_roundtrip(self):
        cfg = AgentConfig()
        d = cfg.to_dict()
        assert isinstance(d, dict)
        assert d["config_version"] == 1
        assert d["llm"]["provider"] == "openai"
        assert d["safety"]["level"] == 2

    def test_from_dict_roundtrip(self):
        cfg = AgentConfig()
        d = cfg.to_dict()
        cfg2 = AgentConfig.from_dict(d)
        assert cfg2.config_version == cfg.config_version
        assert cfg2.llm.provider == cfg.llm.provider
        assert cfg2.safety.level == cfg.safety.level
        assert cfg2.memory.backend == cfg.memory.backend

    def test_from_dict_partial(self):
        d = {"config_version": 1, "llm": {"provider": "anthropic"}}
        cfg = AgentConfig.from_dict(d)
        assert cfg.llm.provider == "anthropic"
        assert cfg.safety.level == 2  # default

    def test_nested_provider_configs(self):
        d = {
            "llm": {
                "providers": {
                    "openai": {"provider": "openai", "model": "gpt-4o"},
                }
            }
        }
        cfg = AgentConfig.from_dict(d)
        assert "openai" in cfg.llm.providers
        assert cfg.llm.providers["openai"].model == "gpt-4o"

    def test_nested_mcp_servers(self):
        d = {
            "mcp": {
                "servers": {
                    "myserver": {"command": "node", "args": ["server.js"]},
                }
            }
        }
        cfg = AgentConfig.from_dict(d)
        assert "myserver" in cfg.mcp.servers
        assert cfg.mcp.servers["myserver"].command == "node"


class TestLLMProviderConfig:
    def test_defaults(self):
        cfg = LLMProviderConfig()
        assert cfg.temperature == 0.0
        assert cfg.max_tokens == 4096


class TestMCPServerConfig:
    def test_defaults(self):
        cfg = MCPServerConfig()
        assert cfg.enabled is True
        assert cfg.timeout == 30
