"""Tests for terminal_agent.project.framework_detector."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.project.framework_detector import FrameworkDetector, FRAMEWORK_INDICATORS


class TestFrameworkDetector:
    """Tests for FrameworkDetector."""

    @pytest.fixture
    def detector(self):
        return FrameworkDetector()

    def test_framework_indicators(self):
        assert "django" in FRAMEWORK_INDICATORS
        assert "flask" in FRAMEWORK_INDICATORS
        assert "fastapi" in FRAMEWORK_INDICATORS
        assert "react" in FRAMEWORK_INDICATORS
        assert "vue" in FRAMEWORK_INDICATORS
        assert "angular" in FRAMEWORK_INDICATORS

    def test_detect_django(self, detector, tmp_path):
        (tmp_path / "manage.py").write_text("# Django manage.py")
        (tmp_path / "requirements.txt").write_text("Django>=4.0\n")
        result = detector.detect(tmp_path)
        assert "django" in result

    def test_detect_react(self, detector, tmp_path):
        (tmp_path / "package.json").write_text('{"dependencies": {"react": "^18.0.0"}}')
        result = detector.detect(tmp_path)
        assert "react" in result

    def test_detect_none(self, detector, tmp_path):
        empty = tmp_path / "empty"
        empty.mkdir()
        result = detector.detect(empty)
        assert isinstance(result, list)
