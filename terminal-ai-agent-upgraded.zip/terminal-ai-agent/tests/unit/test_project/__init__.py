"""Unit tests for project module."""
