"""Tests for terminal_agent.project.language_detector."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.project.language_detector import LanguageDetector, EXTENSION_MAP


class TestLanguageDetector:
    """Tests for LanguageDetector."""

    @pytest.fixture
    def detector(self):
        return LanguageDetector()

    def test_extension_map(self):
        assert EXTENSION_MAP[".py"] == "python"
        assert EXTENSION_MAP[".js"] == "javascript"
        assert EXTENSION_MAP[".ts"] == "typescript"
        assert EXTENSION_MAP[".go"] == "go"
        assert EXTENSION_MAP[".rs"] == "rust"
        assert EXTENSION_MAP[".java"] == "java"

    def test_detect_python_project(self, detector, tmp_path):
        (tmp_path / "main.py").write_text("print('hello')")
        (tmp_path / "utils.py").write_text("def helper(): pass")
        result = detector.detect(tmp_path)
        assert "python" in result

    def test_detect_javascript_project(self, detector, tmp_path):
        (tmp_path / "index.js").write_text("console.log('hello')")
        (tmp_path / "utils.js").write_text("module.exports = {}")
        result = detector.detect(tmp_path)
        assert "javascript" in result

    def test_detect_empty_project(self, detector, tmp_path):
        empty = tmp_path / "empty"
        empty.mkdir()
        result = detector.detect(empty)
        assert isinstance(result, list)

    def test_detect_mixed_project(self, detector, tmp_path):
        (tmp_path / "main.py").write_text("pass")
        (tmp_path / "app.js").write_text("var x = 1;")
        result = detector.detect(tmp_path)
        assert "python" in result
        assert "javascript" in result
