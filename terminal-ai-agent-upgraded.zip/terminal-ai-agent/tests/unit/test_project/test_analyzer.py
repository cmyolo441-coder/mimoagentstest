"""Tests for terminal_agent.project.analyzer."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.project.analyzer import ProjectProfile
from terminal_agent.types import ProjectInfo


class TestProjectAnalyzer:
    """Tests for ProjectAnalyzer and ProjectProfile."""

    def test_profile_to_project_info(self):
        profile = ProjectProfile(
            root_dir="/test",
            languages=["python"],
            primary_language="python",
            frameworks=["django"],
            build_system="setuptools",
            test_framework="pytest",
            package_manager="pip",
        )
        info = profile.to_project_info()
        assert isinstance(info, ProjectInfo)
        assert info.languages == ["python"]
        assert info.frameworks == ["django"]

    def test_profile_summary(self):
        profile = ProjectProfile(
            root_dir="/test/project",
            primary_language="python",
            frameworks=["django"],
            test_framework="pytest",
        )
        summary = profile.summary()
        assert "python" in summary
        assert "django" in summary

    def test_profile_defaults(self):
        profile = ProjectProfile()
        assert profile.languages == []
        assert profile.frameworks == []
        assert profile.build_system is None
        assert profile.test_framework is None
