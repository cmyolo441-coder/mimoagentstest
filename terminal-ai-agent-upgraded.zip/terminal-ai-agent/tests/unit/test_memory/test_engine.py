"""Tests for terminal_agent.memory.engine — the main memory engine."""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch

from terminal_agent.memory.engine import MemoryEngine, MemoryEngineConfig, MemoryStats
from terminal_agent.types import MemoryCategory


@pytest.fixture
def config():
    return MemoryEngineConfig(
        max_short_term_turns=5,
        max_working_files=3,
        max_memories=100,
        memories_per_query=3,
        vector_backend="memory",
    )


@pytest.fixture
def engine(config, tmp_path):
    with patch("terminal_agent.memory.engine.LongTermMemory") as MockLTM:
        mock_ltm = MagicMock()
        mock_ltm.count.return_value = 0
        mock_ltm.count_by_category.return_value = {}
        mock_ltm.list_memories.return_value = []
        mock_ltm.store.return_value = MagicMock(
            id="mem-1", content="test", category=MemoryCategory.TASK,
            relevance_score=1.0, access_count=0, metadata={},
        )
        mock_ltm.search.return_value = []
        MockLTM.return_value = mock_ltm
        eng = MemoryEngine(config)
        yield eng


class TestMemoryEngineStoreTurn:
    def test_store_turn(self, engine):
        engine.store_turn("user", "Hello")
        history = engine.get_conversation_history()
        assert len(history) == 1
        assert history[0]["role"] == "user"

    def test_get_history_as_messages(self, engine):
        engine.store_turn("user", "Hello")
        engine.store_turn("assistant", "Hi!")
        messages = engine.get_history_as_messages()
        assert len(messages) == 2
        assert messages[0]["role"] == "user"


class TestMemoryEngineWorkingMemory:
    def test_store_and_get_working(self, engine):
        engine.store_working("key", "value")
        assert engine.get_working("key") == "value"

    def test_get_working_default(self, engine):
        assert engine.get_working("missing", "default") == "default"

    def test_store_file_content(self, engine):
        engine.store_file_content("test.py", "print('hello')")
        assert engine.get_file_content("test.py") == "print('hello')"

    def test_get_active_files(self, engine):
        engine.store_file_content("a.py", "a")
        files = engine.get_active_files()
        assert "a.py" in files

    def test_scratch_pad(self, engine):
        engine.store_scratch("note", "remember this")
        assert engine.get_scratch("note") == "remember this"


class TestMemoryEngineLongTerm:
    def test_store_memory(self, engine):
        mem = engine.store_memory("Test memory", MemoryCategory.TASK)
        assert mem is not None

    def test_recall(self, engine):
        engine._long_term.search.return_value = []
        memories = engine.recall("test query")
        assert isinstance(memories, list)


class TestMemoryEngineContext:
    def test_get_context_for_llm(self, engine):
        engine.store_file_content("main.py", "print('hello')")
        engine.store_scratch("todo", "fix bug")
        ctx = engine.get_context_for_llm()
        assert isinstance(ctx, str)


class TestMemoryEngineStats:
    def test_get_stats(self, engine):
        stats = engine.get_stats()
        assert isinstance(stats, MemoryStats)
        assert stats.short_term_count == 0


class TestMemoryEngineSession:
    def test_clear_session(self, engine):
        engine.store_turn("user", "Hello")
        engine.store_working("key", "value")
        engine.clear_session()
        assert engine.get_conversation_history() == []
