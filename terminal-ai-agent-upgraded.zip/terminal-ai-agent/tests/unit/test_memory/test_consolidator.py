"""Tests for terminal_agent.memory.consolidator — memory consolidation."""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from terminal_agent.memory.consolidator import MemoryConsolidator, ConsolidationReport
from terminal_agent.types import Memory, MemoryCategory


@pytest.fixture
def consolidator():
    return MemoryConsolidator(interval=0.0)  # always runnable


class TestConsolidationReport:
    def test_to_dict(self):
        report = ConsolidationReport(turns_summarized=5, memories_merged=2)
        d = report.to_dict()
        assert d["turns_summarized"] == 5
        assert d["memories_merged"] == 2


class TestMemoryConsolidatorShouldRun:
    def test_should_run_with_zero_interval(self):
        c = MemoryConsolidator(interval=0.0)
        assert c.should_run() is True

    def test_should_not_run_immediately(self):
        c = MemoryConsolidator(interval=9999.0)
        c._last_run = 1e18  # far future
        assert c.should_run() is False


class TestMemoryConsolidatorConsolidate:
    def test_consolidate_returns_report(self, consolidator):
        short_term = MagicMock()
        short_term.get_evicted.return_value = []

        long_term = MagicMock()
        long_term.get_all_for_consolidation.return_value = []

        working = MagicMock()
        working.get_all_scratch.return_value = {}

        report = consolidator.consolidate(short_term, long_term, working)
        assert isinstance(report, dict)
        assert "turns_summarized" in report
        assert "memories_merged" in report
        assert "memories_pruned" in report

    def test_summarize_evicted_turns(self, consolidator):
        from terminal_agent.memory.short_term import Turn
        evicted = [
            Turn(role="user", content="How do I sort?"),
            Turn(role="assistant", content="Use sorted()"),
        ]

        short_term = MagicMock()
        short_term.get_evicted.return_value = evicted

        long_term = MagicMock()
        long_term.store.return_value = MagicMock()

        count = consolidator._summarize_evicted_turns(short_term, long_term)
        assert count == 2
        long_term.store.assert_called_once()

    def test_summarize_no_evicted(self, consolidator):
        short_term = MagicMock()
        short_term.get_evicted.return_value = []
        long_term = MagicMock()
        count = consolidator._summarize_evicted_turns(short_term, long_term)
        assert count == 0


class TestContentSimilarity:
    def test_identical(self):
        score = MemoryConsolidator._content_similarity("hello world", "hello world")
        assert score == 1.0

    def test_no_overlap(self):
        score = MemoryConsolidator._content_similarity("hello", "goodbye")
        assert score == 0.0

    def test_partial_overlap(self):
        score = MemoryConsolidator._content_similarity("hello world", "hello there")
        assert 0.0 < score < 1.0

    def test_empty_strings(self):
        score = MemoryConsolidator._content_similarity("", "hello")
        assert score == 0.0


class TestCategorizeFromContent:
    def test_error_category(self, consolidator):
        cat = consolidator._categorize_from_content("Traceback error in line 5")
        assert cat == MemoryCategory.ERROR

    def test_pattern_category(self, consolidator):
        cat = consolidator._categorize_from_content("Always use context managers")
        assert cat == MemoryCategory.PATTERN

    def test_tool_category(self, consolidator):
        cat = consolidator._categorize_from_content("Run docker build command")
        assert cat == MemoryCategory.TOOL

    def test_default_task_category(self, consolidator):
        cat = consolidator._categorize_from_content("Implement the feature")
        assert cat == MemoryCategory.TASK
