"""Tests for terminal_agent.memory.short_term — conversation turn storage."""

from __future__ import annotations

import pytest

from terminal_agent.memory.short_term import ShortTermMemory, Turn


@pytest.fixture
def stm():
    return ShortTermMemory(max_turns=5)


class TestShortTermMemoryAddTurn:
    def test_add_turn(self, stm):
        turn = stm.add_turn("user", "Hello")
        assert isinstance(turn, Turn)
        assert turn.role == "user"
        assert turn.content == "Hello"

    def test_count(self, stm):
        stm.add_turn("user", "Hello")
        stm.add_turn("assistant", "Hi!")
        assert stm.count() == 2

    def test_eviction(self, stm):
        for i in range(10):
            stm.add_turn("user", f"Message {i}")
        assert stm.count() == 5  # max_turns=5

    def test_evicted_turns_saved(self, stm):
        for i in range(7):
            stm.add_turn("user", f"Message {i}")
        evicted = stm.get_evicted()
        assert len(evicted) == 2


class TestShortTermMemoryGetTurns:
    def test_get_all_turns(self, stm):
        stm.add_turn("user", "Hello")
        stm.add_turn("assistant", "Hi!")
        turns = stm.get_turns()
        assert len(turns) == 2
        assert turns[0]["role"] == "user"

    def test_get_limited_turns(self, stm):
        for i in range(5):
            stm.add_turn("user", f"Msg {i}")
        turns = stm.get_turns(max_turns=3)
        assert len(turns) == 3

    def test_get_as_messages(self, stm):
        stm.add_turn("user", "Hello")
        stm.add_turn("assistant", "Hi!")
        messages = stm.get_as_messages()
        assert len(messages) == 2
        assert messages[0] == {"role": "user", "content": "Hello"}


class TestShortTermMemoryHelpers:
    def test_get_last_user_message(self, stm):
        stm.add_turn("user", "first")
        stm.add_turn("assistant", "reply")
        stm.add_turn("user", "second")
        assert stm.get_last_user_message() == "second"

    def test_get_last_assistant_message(self, stm):
        stm.add_turn("user", "Hello")
        stm.add_turn("assistant", "Hi!")
        assert stm.get_last_assistant_message() == "Hi!"

    def test_no_user_message(self, stm):
        assert stm.get_last_user_message() is None

    def test_is_empty(self, stm):
        assert stm.is_empty() is True
        stm.add_turn("user", "Hello")
        assert stm.is_empty() is False

    def test_clear(self, stm):
        stm.add_turn("user", "Hello")
        stm.clear()
        assert stm.count() == 0
        assert stm.is_empty() is True

    def test_estimate_tokens(self, stm):
        stm.add_turn("user", "Hello world this is a test message")
        tokens = stm.estimate_tokens()
        assert tokens > 0


class TestShortTermMemorySystemPrompt:
    def test_replace_system_prompt_new(self, stm):
        stm.replace_system_prompt("You are helpful")
        turns = stm.get_turns()
        assert turns[0]["role"] == "system"
        assert turns[0]["content"] == "You are helpful"

    def test_replace_system_prompt_existing(self, stm):
        stm.replace_system_prompt("Old prompt")
        stm.replace_system_prompt("New prompt")
        turns = stm.get_turns()
        assert turns[0]["content"] == "New prompt"
        assert stm.count() == 1


class TestShortTermMemorySummarize:
    def test_summarize_for_context(self, stm):
        stm.add_turn("user", "How do I sort a list?")
        stm.add_turn("assistant", "Use sorted()")
        summary = stm.summarize_for_context()
        assert "user" in summary
        assert "assistant" in summary

    def test_summarize_empty(self, stm):
        assert stm.summarize_for_context() == ""


class TestTurnDataclass:
    def test_token_estimate_auto(self):
        turn = Turn(role="user", content="Hello world this is a test")
        assert turn.token_estimate > 0

    def test_to_dict(self):
        turn = Turn(role="user", content="Hello")
        d = turn.to_dict()
        assert d["role"] == "user"
        assert d["content"] == "Hello"
        assert "timestamp" in d

    def test_to_message(self):
        turn = Turn(role="assistant", content="Hi!")
        msg = turn.to_message()
        assert msg == {"role": "assistant", "content": "Hi!"}
