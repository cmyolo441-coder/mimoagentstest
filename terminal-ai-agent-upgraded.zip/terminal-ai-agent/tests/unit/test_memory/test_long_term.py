"""Tests for terminal_agent.memory.long_term — persistent memory with vectors."""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch

from terminal_agent.memory.long_term import LongTermMemory
from terminal_agent.types import Memory, MemoryCategory


@pytest.fixture
def mock_embedder():
    with patch("terminal_agent.memory.long_term.MemoryEmbedder") as MockEmbedder:
        embedder = MockEmbedder.return_value
        embedder.embed.return_value = [0.1] * 1536
        yield embedder


@pytest.fixture
def ltm(mock_embedder, tmp_path):
    """Create a LongTermMemory with mocked vector store."""
    with patch("terminal_agent.memory.long_term.LongTermMemory._ensure_vector_store") as mock_ensure:
        store = MagicMock()
        store.upsert = MagicMock()
        store.query = MagicMock(return_value=[])
        store.delete = MagicMock(return_value=True)
        store.get = MagicMock(return_value=[])
        store.update_metadata = MagicMock()
        mock_ensure.return_value = store
        ltm = LongTermMemory(
            max_memories=100,
            vector_backend="memory",
            vector_store_path=str(tmp_path / "vectors"),
        )
        ltm._vector_store = store
        ltm._vector_store_initialized = True
        yield ltm


class TestLongTermMemoryStore:
    def test_store_memory(self, ltm):
        mem = ltm.store("Use sorted() for lists", MemoryCategory.PATTERN)
        assert isinstance(mem, Memory)
        assert mem.content == "Use sorted() for lists"
        assert mem.category == MemoryCategory.PATTERN
        assert mem.id is not None

    def test_store_with_metadata(self, ltm):
        mem = ltm.store("test", metadata={"source": "test"})
        assert mem.metadata.get("source") == "test"

    def test_count(self, ltm):
        ltm.store("memory 1")
        ltm.store("memory 2")
        assert ltm.count() == 2

    def test_count_by_category(self, ltm):
        ltm.store("task memory", MemoryCategory.TASK)
        ltm.store("error memory", MemoryCategory.ERROR)
        counts = ltm.count_by_category()
        assert counts.get("task", 0) == 1
        assert counts.get("error", 0) == 1


class TestLongTermMemoryRetrieval:
    def test_get_by_id(self, ltm):
        mem = ltm.store("test memory")
        retrieved = ltm.get(mem.id)
        assert retrieved is not None
        assert retrieved.content == "test memory"

    def test_get_missing(self, ltm):
        assert ltm.get("nonexistent") is None

    def test_list_memories(self, ltm):
        ltm.store("memory 1")
        ltm.store("memory 2")
        memories = ltm.list_memories()
        assert len(memories) == 2

    def test_list_by_category(self, ltm):
        ltm.store("task", MemoryCategory.TASK)
        ltm.store("error", MemoryCategory.ERROR)
        tasks = ltm.list_memories(category=MemoryCategory.TASK)
        assert len(tasks) == 1
        assert tasks[0].category == MemoryCategory.TASK


class TestLongTermMemoryUpdate:
    def test_update_content(self, ltm):
        mem = ltm.store("original")
        updated = ltm.update(mem.id, content="updated")
        assert updated is not None
        assert updated.content == "updated"

    def test_update_nonexistent(self, ltm):
        assert ltm.update("nonexistent", content="x") is None


class TestLongTermMemoryDelete:
    def test_delete_memory(self, ltm):
        mem = ltm.store("to delete")
        assert ltm.delete(mem.id) is True
        assert ltm.get(mem.id) is None

    def test_delete_nonexistent(self, ltm):
        # Should not raise
        result = ltm.delete("nonexistent")
        assert result is True  # delete returns True even if not found in index


class TestLongTermMemoryBatchUpdate:
    def test_batch_update_relevance(self, ltm):
        mem = ltm.store("test")
        count = ltm.batch_update_relevance({mem.id: 0.5})
        assert count == 1


class TestLongTermMemoryForConsolidation:
    def test_get_all_for_consolidation(self, ltm):
        ltm.store("memory 1")
        ltm.store("memory 2")
        memories = ltm.get_all_for_consolidation()
        assert len(memories) == 2
