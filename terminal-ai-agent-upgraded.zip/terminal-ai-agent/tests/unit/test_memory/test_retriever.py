"""Tests for terminal_agent.memory.retriever — memory retrieval and ranking."""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from terminal_agent.memory.retriever import MemoryRetriever, RetrievalConfig
from terminal_agent.types import Memory, MemoryCategory


@pytest.fixture
def config():
    return RetrievalConfig(
        similarity_weight=0.6,
        recency_weight=0.2,
        frequency_weight=0.1,
        relevance_weight=0.1,
    )


@pytest.fixture
def mock_long_term():
    lt = MagicMock()
    lt._embedder = MagicMock()
    lt._embedder.embed.return_value = [0.1] * 1536
    lt.search.return_value = []
    lt.list_memories.return_value = []
    return lt


@pytest.fixture
def mock_short_term():
    return MagicMock()


@pytest.fixture
def retriever(mock_long_term, mock_short_term, config):
    return MemoryRetriever(
        long_term=mock_long_term,
        short_term=mock_short_term,
        memories_per_query=5,
        config=config,
    )


class TestRetrievalConfig:
    def test_defaults(self):
        cfg = RetrievalConfig()
        assert cfg.similarity_weight == 0.6
        assert cfg.recency_weight == 0.2
        assert cfg.default_limit == 5
        assert cfg.min_similarity == 0.3


class TestMemoryRetrieverRetrieve:
    def test_returns_list(self, retriever, mock_long_term):
        mock_long_term.search.return_value = []
        results = retriever.retrieve("test query")
        assert isinstance(results, list)

    def test_with_candidates(self, retriever, mock_long_term):
        mem = Memory(
            id="m1", content="test", category=MemoryCategory.TASK,
            relevance_score=0.8, access_count=3,
            metadata={"created_at": 1000.0},
        )
        mock_long_term.search.return_value = [mem]
        results = retriever.retrieve("test query")
        assert len(results) == 1

    def test_with_category_filter(self, retriever, mock_long_term):
        mock_long_term.search.return_value = []
        retriever.retrieve("query", categories=[MemoryCategory.TASK])
        call_kwargs = mock_long_term.search.call_args
        assert call_kwargs.kwargs.get("categories") == [MemoryCategory.TASK]


class TestMemoryRetrieverRanking:
    def test_rank_memories(self, retriever):
        mems = [
            Memory(id="m1", content="old", relevance_score=0.9, access_count=10,
                   metadata={"created_at": 100.0}),
            Memory(id="m2", content="new", relevance_score=0.5, access_count=0,
                   metadata={"created_at": 999999.0}),
        ]
        ranked = retriever._rank_memories(mems, "query")
        assert len(ranked) == 2
        # Higher composite score should come first
        assert ranked[0].relevance_score >= ranked[1].relevance_score

    def test_explain_ranking(self, retriever):
        mem = Memory(
            id="m1", content="test", relevance_score=0.8, access_count=5,
            metadata={"created_at": 100.0},
        )
        explanation = retriever.explain_ranking(mem, "query")
        assert "similarity" in explanation
        assert "recency" in explanation
        assert "frequency" in explanation
        assert "composite" in explanation


class TestMemoryRetrieverByCategory:
    def test_retrieve_by_category(self, retriever, mock_long_term):
        mock_long_term.search.return_value = []
        retriever.retrieve_by_category("query", MemoryCategory.ERROR)
        mock_long_term.search.assert_called()


class TestMemoryRetrieverRecent:
    def test_retrieve_recent(self, retriever, mock_long_term):
        mock_long_term.list_memories.return_value = []
        results = retriever.retrieve_recent(limit=5)
        assert isinstance(results, list)
