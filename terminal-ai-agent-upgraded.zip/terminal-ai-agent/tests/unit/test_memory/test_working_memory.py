"""Tests for terminal_agent.memory.working_memory — session-scoped working memory."""

from __future__ import annotations

import time
import pytest

from terminal_agent.memory.working_memory import WorkingMemory, WorkingEntry


@pytest.fixture
def wm():
    return WorkingMemory(max_files=3)


class TestWorkingMemoryStore:
    def test_set_and_get(self, wm):
        wm.set("key1", "value1")
        assert wm.get("key1") == "value1"

    def test_get_default(self, wm):
        assert wm.get("missing", "default") == "default"

    def test_has(self, wm):
        assert wm.has("key1") is False
        wm.set("key1", "value1")
        assert wm.has("key1") is True

    def test_delete(self, wm):
        wm.set("key1", "value1")
        assert wm.delete("key1") is True
        assert wm.get("key1") is None

    def test_delete_missing(self, wm):
        assert wm.delete("missing") is False

    def test_keys(self, wm):
        wm.set("a", 1)
        wm.set("b", 2)
        keys = wm.keys()
        assert "a" in keys
        assert "b" in keys


class TestWorkingMemoryTTL:
    def test_expired_entry(self):
        wm = WorkingMemory()
        wm.set("temp", "value", ttl=0.01)
        time.sleep(0.02)
        assert wm.get("temp") is None

    def test_not_expired(self):
        wm = WorkingMemory()
        wm.set("temp", "value", ttl=60.0)
        assert wm.get("temp") == "value"

    def test_has_expired(self):
        wm = WorkingMemory()
        wm.set("temp", "value", ttl=0.01)
        time.sleep(0.02)
        assert wm.has("temp") is False


class TestWorkingMemoryFiles:
    def test_add_and_get_file(self, wm):
        wm.add_file("test.py", "print('hello')")
        assert wm.get_file("test.py") == "print('hello')"

    def test_file_list(self, wm):
        wm.add_file("a.py", "a")
        wm.add_file("b.py", "b")
        files = wm.get_file_list()
        assert "a.py" in files
        assert "b.py" in files

    def test_file_eviction(self, wm):
        """max_files=3, adding 4 should evict the oldest."""
        wm.add_file("a.py", "a")
        wm.add_file("b.py", "b")
        wm.add_file("c.py", "c")
        wm.add_file("d.py", "d")
        assert wm.get_file("a.py") is None  # evicted
        assert wm.get_file("d.py") == "d"

    def test_remove_file(self, wm):
        wm.add_file("test.py", "content")
        assert wm.remove_file("test.py") is True
        assert wm.get_file("test.py") is None

    def test_remove_missing_file(self, wm):
        assert wm.remove_file("missing.py") is False

    def test_file_summary(self, wm):
        wm.add_file("a.py", "hello")
        summary = wm.get_file_summary()
        assert summary["a.py"] == 5

    def test_lru_ordering(self, wm):
        wm.add_file("a.py", "a")
        wm.add_file("b.py", "b")
        wm.add_file("c.py", "c")
        # Access a.py to make it most recently used
        wm.get_file("a.py")
        # Now add d.py — should evict b.py (LRU)
        wm.add_file("d.py", "d")
        assert wm.get_file("b.py") is None
        assert wm.get_file("a.py") == "a"


class TestWorkingMemoryScratch:
    def test_set_and_get_scratch(self, wm):
        wm.set_scratch("note", "remember this")
        assert wm.get_scratch("note") == "remember this"

    def test_get_missing_scratch(self, wm):
        assert wm.get_scratch("missing") is None

    def test_delete_scratch(self, wm):
        wm.set_scratch("note", "value")
        assert wm.delete_scratch("note") is True
        assert wm.get_scratch("note") is None

    def test_get_all_scratch(self, wm):
        wm.set_scratch("a", "1")
        wm.set_scratch("b", "2")
        all_scratch = wm.get_all_scratch()
        assert all_scratch == {"a": "1", "b": "2"}

    def test_scratch_count(self, wm):
        wm.set_scratch("a", "1")
        wm.set_scratch("b", "2")
        assert wm.scratch_count() == 2


class TestWorkingMemoryMaintenance:
    def test_clear(self, wm):
        wm.set("key", "value")
        wm.add_file("file.py", "content")
        wm.set_scratch("note", "value")
        wm.clear()
        assert wm.size() == 0

    def test_size(self, wm):
        wm.set("key", "value")
        wm.add_file("file.py", "content")
        wm.set_scratch("note", "value")
        assert wm.size() == 3

    def test_to_context_string(self, wm):
        wm.add_file("main.py", "print('hello')")
        wm.set_scratch("todo", "fix bug")
        ctx = wm.to_context_string()
        assert "main.py" in ctx
        assert "todo" in ctx


class TestWorkingEntry:
    def test_not_expired_no_ttl(self):
        entry = WorkingEntry(key="k", value="v")
        assert entry.is_expired() is False

    def test_expired_with_ttl(self):
        entry = WorkingEntry(key="k", value="v", ttl=0.01)
        time.sleep(0.02)
        assert entry.is_expired() is True

    def test_touch(self):
        entry = WorkingEntry(key="k", value="v")
        assert entry.access_count == 0
        entry.touch()
        assert entry.access_count == 1
