"""Tests for terminal_agent.support.safety.patterns.CommandPatternMatcher."""

from __future__ import annotations

import pytest

from terminal_agent.support.safety.patterns import DangerousPattern, _BUILTIN_PATTERNS


class TestCommandPatterns:
    """Tests for command pattern matching."""

    def test_builtin_patterns_exist(self):
        assert len(_BUILTIN_PATTERNS) > 0

    def test_dangerous_pattern_dataclass(self):
        p = DangerousPattern(
            name="test", regex=r"\brm\b", severity="high", description="test pattern",
        )
        assert p.name == "test"
        assert p.severity == "high"

    def test_dangerous_pattern_compiled(self):
        p = DangerousPattern(
            name="test", regex=r"\brm\b", severity="high", description="test",
        )
        compiled = p.compiled()
        assert compiled.search("rm -rf /") is not None
        assert compiled.search("hello world") is None

    def test_rm_root_pattern(self):
        p = next(x for x in _BUILTIN_PATTERNS if x.name == "rm_root")
        assert p.severity == "critical"
        compiled = p.compiled()
        assert compiled.search("rm -rf /") is not None

    def test_fork_bomb_pattern(self):
        p = next(x for x in _BUILTIN_PATTERNS if x.name == "fork_bomb")
        assert p.severity == "critical"
        compiled = p.compiled()
        assert compiled.search(":(){ :|:& };:") is not None

    def test_dd_zero_pattern(self):
        p = next(x for x in _BUILTIN_PATTERNS if x.name == "dd_zero_disk")
        assert p.severity == "critical"
        compiled = p.compiled()
        assert compiled.search("dd if=/dev/zero of=/dev/sda") is not None

    def test_mkfs_format_pattern(self):
        p = next(x for x in _BUILTIN_PATTERNS if x.name == "mkfs_format")
        compiled = p.compiled()
        assert compiled.search("mkfs.ext4 /dev/sda1") is not None

    def test_severity_levels(self):
        severities = {p.severity for p in _BUILTIN_PATTERNS}
        assert "critical" in severities
        assert "high" in severities

    def test_all_patterns_compile(self):
        for p in _BUILTIN_PATTERNS:
            compiled = p.compiled()
            assert compiled is not None
