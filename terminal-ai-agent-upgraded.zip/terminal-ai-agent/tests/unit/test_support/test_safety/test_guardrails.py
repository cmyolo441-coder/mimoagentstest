"""Tests for terminal_agent.support.safety.guardrails."""

from __future__ import annotations

import pytest

from terminal_agent.support.safety.guardrails import SafetyGuardrails, SafetyDecision, SafetyVerdict
from terminal_agent.types import SafetyLevel, ToolCall


class TestSafetyGuardrails:
    """Tests for SafetyGuardrails."""

    @pytest.fixture
    def guardrails(self):
        return SafetyGuardrails(safety_level=SafetyLevel.STANDARD)

    def test_verdict_allowed(self):
        tc = ToolCall(name="test", parameters={})
        v = SafetyVerdict(
            decision=SafetyDecision.ALLOW, reason="ok",
            tool_call=tc, safety_level=SafetyLevel.STANDARD,
        )
        assert v.allowed is True
        assert v.needs_confirmation is False
        assert v.blocked is False

    def test_verdict_confirm(self):
        tc = ToolCall(name="test", parameters={})
        v = SafetyVerdict(
            decision=SafetyDecision.CONFIRM, reason="risky",
            tool_call=tc, safety_level=SafetyLevel.STANDARD,
        )
        assert v.allowed is False
        assert v.needs_confirmation is True
        assert v.blocked is False

    def test_verdict_blocked(self):
        tc = ToolCall(name="test", parameters={})
        v = SafetyVerdict(
            decision=SafetyDecision.BLOCK, reason="dangerous",
            tool_call=tc, safety_level=SafetyLevel.STANDARD,
        )
        assert v.allowed is False
        assert v.blocked is True

    def test_verdict_emergency_stop(self):
        tc = ToolCall(name="test", parameters={})
        v = SafetyVerdict(
            decision=SafetyDecision.EMERGENCY_STOP, reason="critical",
            tool_call=tc, safety_level=SafetyLevel.STANDARD,
        )
        assert v.blocked is True

    def test_safety_decision_enum(self):
        assert SafetyDecision.ALLOW.value == "allow"
        assert SafetyDecision.BLOCK.value == "block"
        assert SafetyDecision.CONFIRM.value == "confirm"
        assert SafetyDecision.EMERGENCY_STOP.value == "emergency_stop"
