"""Tests for terminal_agent.support.safety.confirmation.ConfirmationManager."""

from __future__ import annotations

import pytest

from terminal_agent.support.safety.confirmation import ConfirmationManager, ConfirmationRequest
from terminal_agent.types import ToolCall


class TestConfirmationManager:
    """Tests for ConfirmationManager."""

    @pytest.fixture
    def manager(self):
        return ConfirmationManager()

    def test_build_request(self, manager):
        tc = ToolCall(name="execute_command", parameters={"command": "rm -rf /tmp/test"})
        request = manager.build_request(tc, risk_level="high", reason="recursive deletion")
        assert isinstance(request, ConfirmationRequest)
        assert request.risk_level == "high"
        assert request.tool_call is tc

    def test_build_request_with_details(self, manager):
        tc = ToolCall(name="write_file", parameters={"path": "/etc/hosts"})
        request = manager.build_request(
            tc, risk_level="critical",
            details=["Modifying system file"],
            consequences=["System networking may break"],
            alternatives=["Edit in /tmp first"],
        )
        assert len(request.details) == 1
        assert len(request.consequences) == 1
        assert len(request.alternatives) == 1

    def test_confirmation_request_dataclass(self):
        tc = ToolCall(name="test", parameters={})
        req = ConfirmationRequest(
            tool_call=tc, risk_level="medium", summary="test",
        )
        assert req.risk_level == "medium"
        assert req.requires_reason is False
