"""Tests for terminal_agent.support.safety.path_controller.PathController."""

from __future__ import annotations

import pytest

from terminal_agent.support.safety.path_controller import PathController


class TestPathController:
    """Tests for PathController."""

    def test_default_restricted(self):
        ctrl = PathController()
        assert ctrl.is_allowed("/etc/shadow") is False
        assert ctrl.is_allowed("/etc/passwd") is False
        assert ctrl.is_allowed("/boot") is False

    def test_default_allowed(self):
        ctrl = PathController()
        assert ctrl.is_allowed("/tmp/test") is True

    def test_custom_allowed(self):
        ctrl = PathController(allowed_paths=["/home/user/project"])
        assert ctrl.is_allowed("/home/user/project/src/main.py") is True

    def test_custom_restricted(self):
        ctrl = PathController(restricted_paths=["/secret"])
        assert ctrl.is_allowed("/secret/data") is False

    def test_subpath_checking(self):
        ctrl = PathController(allowed_paths=["/home/user/project"])
        assert ctrl.is_allowed("/home/user/project/sub/dir") is True

    def test_path_not_in_either_list(self):
        ctrl = PathController(allowed_paths=["/tmp"], restricted_paths=["/etc"])
        # Paths not in either list should be allowed (default-allow)
        result = ctrl.is_allowed("/var/log/test")
        assert isinstance(result, bool)
