"""Tests for terminal_agent.support.persistence.database.Database."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.support.persistence.database import Database


class TestDatabase:
    """Tests for Database."""

    @pytest.fixture
    def db(self, tmp_path):
        return Database(tmp_path / "test.db")

    def test_init(self, db):
        assert db._initialized is False

    def test_initialize(self, db):
        db.initialize()
        assert db._initialized is True
        assert db._path.exists()

    def test_close_without_init(self, db):
        # Should not raise
        db.close()

    def test_execute_after_init(self, db):
        db.initialize()
        result = db.execute("SELECT 1 as val")
        assert result is not None

    def test_transaction(self, db):
        db.initialize()
        with db.transaction() as tx:
            tx.execute("CREATE TABLE IF NOT EXISTS test_tbl (id INTEGER PRIMARY KEY, name TEXT)")
            tx.execute("INSERT INTO test_tbl (name) VALUES (?)", ("test",))
        rows = db.execute("SELECT * FROM test_tbl").fetchall()
        assert len(rows) == 1

    def test_pragmas_applied(self, db):
        db.initialize()
        result = db.execute("PRAGMA journal_mode")
        # WAL mode may or may not be set depending on platform
        assert result is not None
