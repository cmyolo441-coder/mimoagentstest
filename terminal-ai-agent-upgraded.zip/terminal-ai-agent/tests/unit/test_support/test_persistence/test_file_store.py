"""Tests for terminal_agent.support.persistence.file_store.FileStore."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.support.persistence.file_store import FileStore
from terminal_agent.exceptions import FileStoreError


class TestFileStore:
    """Tests for FileStore."""

    @pytest.fixture
    def store(self, tmp_path):
        s = FileStore(base_dir=tmp_path / "store")
        s.initialize()
        return s

    def test_initialize(self, store):
        assert store._initialized is True

    def test_put_and_get(self, store):
        store.put("tmp", "test.txt", "hello world")
        data = store.get("tmp", "test.txt")
        assert data is not None
        assert b"hello world" in data

    def test_put_bytes(self, store):
        store.put("tmp", "binary.dat", b"\x00\x01\x02")
        data = store.get("tmp", "binary.dat")
        assert data is not None
        assert b"\x00\x01\x02" in data

    def test_get_nonexistent_raises(self, store):
        with pytest.raises(FileStoreError):
            store.get("tmp", "nonexistent.txt")

    def test_register_directory(self, store, tmp_path):
        custom = tmp_path / "custom"
        store.register_directory("custom", custom)
        assert custom.exists()

    def test_list_files(self, store):
        store.put("tmp", "a.txt", "a")
        store.put("tmp", "b.txt", "b")
        files = store.list_files("tmp")
        names = [f.name for f in files]
        assert "a.txt" in names
        assert "b.txt" in names

    def test_delete(self, store):
        store.put("tmp", "del.txt", "delete me")
        store.delete("tmp", "del.txt")
        with pytest.raises(FileStoreError):
            store.get("tmp", "del.txt")
