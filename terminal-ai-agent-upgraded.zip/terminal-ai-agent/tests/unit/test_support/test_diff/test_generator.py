"""Tests for terminal_agent.support.diff.generator.DiffGenerator."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.support.diff.generator import DiffGenerator


class TestDiffGenerator:
    """Tests for DiffGenerator."""

    @pytest.fixture
    def gen(self):
        return DiffGenerator()

    def test_diff_strings_unified(self, gen):
        diff = gen.diff_strings("line1\nline2\n", "line1\nLINE2\n", "test.py")
        assert "line2" in diff or "LINE2" in diff
        assert "---" in diff
        assert "+++" in diff

    def test_diff_strings_no_change(self, gen):
        diff = gen.diff_strings("same\n", "same\n")
        assert diff == ""

    def test_diff_strings_context_format(self, gen):
        diff = gen.diff_strings("a\n", "b\n", format="context")
        assert "***" in diff or "---" in diff

    def test_diff_strings_ndiff(self, gen):
        diff = gen.diff_strings("hello\n", "world\n", format="ndiff")
        assert "hello" in diff or "world" in diff

    def test_diff_strings_unknown_format(self, gen):
        with pytest.raises(ValueError, match="Unknown diff format"):
            gen.diff_strings("a", "b", format="invalid")

    def test_diff_files(self, gen, tmp_path):
        old = tmp_path / "old.txt"
        new = tmp_path / "new.txt"
        old.write_text("old content\n")
        new.write_text("new content\n")
        diff = gen.diff_files(old, new)
        assert "old content" in diff or "new content" in diff

    def test_changed_lines(self, gen):
        changes = gen.changed_lines("line1\nline2\n", "line1\nLINE2\n")
        assert len(changes) > 0
