"""Tests for terminal_agent.support.diff.applier.DiffApplier."""

from __future__ import annotations

import pytest

from terminal_agent.support.diff.applier import DiffApplier, ApplyResult


class TestDiffApplier:
    """Tests for DiffApplier."""

    @pytest.fixture
    def applier(self):
        return DiffApplier()

    def test_apply_no_diff(self, applier):
        result = applier.apply("hello\n", "")
        assert result.success is True
        assert result.content == "hello\n"

    def test_apply_result_dataclass(self):
        result = ApplyResult(success=True, content="new", lines_applied=1)
        assert result.success is True
        assert result.lines_applied == 1
        assert result.conflicts == []

    def test_apply_result_failure(self):
        result = ApplyResult(success=False, error="parse error")
        assert result.success is False
        assert result.error == "parse error"
