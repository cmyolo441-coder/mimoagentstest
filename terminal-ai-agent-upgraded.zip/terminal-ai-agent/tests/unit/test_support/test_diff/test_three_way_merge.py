"""Tests for terminal_agent.support.diff.three_way_merge.ThreeWayMerger."""

from __future__ import annotations

import pytest

from terminal_agent.support.diff.three_way_merge import ThreeWayMerger, MergeResult


class TestThreeWayMerger:
    """Tests for ThreeWayMerger."""

    @pytest.fixture
    def merger(self):
        return ThreeWayMerger()

    def test_merge_no_changes(self, merger):
        base = "line1\nline2\n"
        result = merger.merge(base, base, base)
        assert result.success is True
        assert result.conflict_count == 0

    def test_merge_result_dataclass(self):
        result = MergeResult(success=True, content="merged", lines_merged=3)
        assert result.success is True
        assert result.conflict_count == 0

    def test_merge_conflict_count_default(self):
        result = MergeResult(success=True, content="ok")
        assert result.conflicts == []
        assert result.lines_merged == 0
