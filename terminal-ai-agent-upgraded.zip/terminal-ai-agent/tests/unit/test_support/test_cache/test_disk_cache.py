"""Tests for terminal_agent.support.cache.disk_cache.DiskCache."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.support.cache.disk_cache import DiskCache


class TestDiskCache:
    """Tests for DiskCache."""

    @pytest.fixture
    def cache(self, tmp_path):
        return DiskCache(cache_dir=tmp_path / "cache", max_size_mb=10, default_ttl=60.0)

    def test_set_and_get(self, cache):
        cache.set("key", {"data": 42})
        assert cache.get("key") == {"data": 42}

    def test_get_missing(self, cache):
        assert cache.get("missing") is None

    def test_delete(self, cache):
        cache.set("key", "value")
        cache.delete("key")
        assert cache.get("key") is None

    def test_clear(self, cache):
        cache.set("a", 1)
        cache.set("b", 2)
        cache.clear()
        assert cache.get("a") is None
        assert cache.get("b") is None

    def test_overwrite(self, cache):
        cache.set("key", "old")
        cache.set("key", "new")
        assert cache.get("key") == "new"

    def test_persistence_across_instances(self, tmp_path):
        cache_dir = tmp_path / "persistent_cache"
        c1 = DiskCache(cache_dir=cache_dir, max_size_mb=10, default_ttl=60.0)
        c1.set("key", "persistent_value")
        c2 = DiskCache(cache_dir=cache_dir, max_size_mb=10, default_ttl=60.0)
        assert c2.get("key") == "persistent_value"
