"""Tests for terminal_agent.support.cache.eviction."""

from __future__ import annotations

import pytest

from terminal_agent.support.cache.eviction import (
    LRUEviction, LFUEviction, create_eviction_policy,
)


class TestEvictionPolicies:
    """Tests for eviction policies."""

    def test_lru_eviction_order(self):
        lru = LRUEviction()
        lru.record_insert("a")
        lru.record_insert("b")
        lru.record_insert("c")
        # Evict order: a (oldest)
        assert lru.evict() == "a"
        assert lru.evict() == "b"
        assert lru.evict() == "c"
        assert lru.evict() is None

    def test_lru_access_moves_to_end(self):
        lru = LRUEviction()
        lru.record_insert("a")
        lru.record_insert("b")
        lru.record_access("a")  # "a" is now most recent
        assert lru.evict() == "b"  # "b" should be evicted first

    def test_lru_remove(self):
        lru = LRUEviction()
        lru.record_insert("a")
        lru.record_insert("b")
        lru.remove("a")
        assert lru.evict() == "b"
        assert lru.evict() is None

    def test_lru_clear(self):
        lru = LRUEviction()
        lru.record_insert("a")
        lru.record_insert("b")
        lru.clear()
        assert lru.evict() is None

    def test_lru_keys(self):
        lru = LRUEviction()
        lru.record_insert("a")
        lru.record_insert("b")
        lru.record_insert("c")
        keys = lru.keys()
        assert keys == ["a", "b", "c"]

    def test_lfu_eviction(self):
        lfu = LFUEviction()
        lfu.record_insert("a")
        lfu.record_insert("b")
        lfu.record_access("b")
        lfu.record_access("b")
        # "a" has 0 accesses, "b" has 2
        assert lfu.evict() == "a"

    def test_create_eviction_policy_lru(self):
        policy = create_eviction_policy("lru")
        assert isinstance(policy, LRUEviction)

    def test_create_eviction_policy_lfu(self):
        policy = create_eviction_policy("lfu")
        assert isinstance(policy, LFUEviction)

    def test_create_eviction_policy_unknown(self):
        with pytest.raises(ValueError):
            create_eviction_policy("unknown_policy")
