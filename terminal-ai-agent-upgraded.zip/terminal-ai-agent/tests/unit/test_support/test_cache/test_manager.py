"""Tests for terminal_agent.support.cache.manager.CacheManager."""

from __future__ import annotations

import pytest

from terminal_agent.support.cache.manager import CacheManager


class TestCacheManager:
    """Tests for CacheManager."""

    @pytest.fixture
    def cache(self):
        return CacheManager(default_ttl=60.0)

    def test_set_and_get(self, cache):
        cache.set("key1", {"data": 42})
        value = cache.get("key1")
        assert value == {"data": 42}

    def test_get_missing(self, cache):
        assert cache.get("nonexistent") is None

    def test_delete(self, cache):
        cache.set("key1", "value")
        cache.delete("key1")
        assert cache.get("key1") is None

    def test_clear(self, cache):
        cache.set("a", 1)
        cache.set("b", 2)
        cache.clear()
        assert cache.get("a") is None
        assert cache.get("b") is None

    def test_key_generator(self, cache):
        kg = cache.key_generator
        assert kg is not None

    def test_invalidation(self, cache):
        inv = cache.invalidation
        assert inv is not None

    def test_warmer(self, cache):
        w = cache.warmer
        assert w is not None
