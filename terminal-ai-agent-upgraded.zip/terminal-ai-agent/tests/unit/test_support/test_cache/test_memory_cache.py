"""Tests for terminal_agent.support.cache.memory_cache.MemoryCache."""

from __future__ import annotations

import time
import pytest

from terminal_agent.support.cache.memory_cache import MemoryCache


class TestMemoryCache:
    """Tests for MemoryCache."""

    @pytest.fixture
    def cache(self):
        return MemoryCache(max_size=100, default_ttl=60.0)

    def test_set_and_get(self, cache):
        cache.set("key", "value")
        assert cache.get("key") == "value"

    def test_get_missing(self, cache):
        assert cache.get("missing") is None

    def test_ttl_expiry(self):
        cache = MemoryCache(max_size=100, default_ttl=0.1)
        cache.set("key", "value")
        time.sleep(0.2)
        assert cache.get("key") is None

    def test_delete(self, cache):
        cache.set("key", "value")
        cache.delete("key")
        assert cache.get("key") is None

    def test_clear(self, cache):
        cache.set("a", 1)
        cache.set("b", 2)
        cache.clear()
        assert cache.get("a") is None
        assert cache.get("b") is None

    def test_max_size_eviction(self):
        cache = MemoryCache(max_size=3, default_ttl=60.0)
        cache.set("a", 1)
        cache.set("b", 2)
        cache.set("c", 3)
        cache.set("d", 4)  # Should evict "a"
        assert cache.get("a") is None
        assert cache.get("d") == 4

    def test_stats(self, cache):
        cache.set("key", "value")
        cache.get("key")
        cache.get("missing")
        assert cache._hits > 0
        assert cache._misses > 0

    def test_overwrite(self, cache):
        cache.set("key", "old")
        cache.set("key", "new")
        assert cache.get("key") == "new"

    def test_size(self, cache):
        cache.set("a", 1)
        cache.set("b", 2)
        # size() method may not exist; check via internal store
        assert len(cache._store) >= 2
