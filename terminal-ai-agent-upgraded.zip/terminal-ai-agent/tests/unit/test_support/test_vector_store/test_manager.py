"""Tests for terminal_agent.support.vector_store.manager.VectorStoreManager."""

from __future__ import annotations

import pytest

from terminal_agent.support.vector_store.manager import VectorStoreManager


class TestVectorStoreManager:
    """Tests for VectorStoreManager."""

    @pytest.fixture
    def manager(self):
        return VectorStoreManager()

    def test_get_memory_backend(self, manager):
        store = manager.get_backend("memory")
        assert store is not None

    def test_get_backend_cached(self, manager):
        s1 = manager.get_backend("memory")
        s2 = manager.get_backend("memory")
        assert s1 is s2

    def test_get_unknown_backend(self, manager):
        with pytest.raises(ValueError, match="Unknown vector store backend"):
            manager.get_backend("nonexistent_backend_xyz")

    def test_backend_registry(self):
        assert "memory" in VectorStoreManager._BACKENDS
        assert "chroma" in VectorStoreManager._BACKENDS
