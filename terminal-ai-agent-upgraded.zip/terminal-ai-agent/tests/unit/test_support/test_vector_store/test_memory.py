"""Tests for terminal_agent.support.vector_store.backends.memory.Backend."""

from __future__ import annotations

import pytest

from terminal_agent.support.vector_store.backends.memory import Backend


class TestMemoryVectorBackend:
    """Tests for in-memory vector store backend."""

    @pytest.fixture
    def backend(self):
        return Backend(dimensions=3)

    def test_upsert_and_query(self, backend):
        backend.upsert("1", [1.0, 0.0, 0.0], document="first")
        backend.upsert("2", [0.0, 1.0, 0.0], document="second")
        results = backend.query([1.0, 0.0, 0.0], top_k=2)
        assert len(results) == 2
        assert results[0]["id"] == "1"  # Most similar

    def test_query_empty(self, backend):
        results = backend.query([1.0, 0.0, 0.0], top_k=5)
        assert results == []

    def test_upsert_overwrite(self, backend):
        backend.upsert("1", [1.0, 0.0, 0.0], document="old")
        backend.upsert("1", [0.0, 1.0, 0.0], document="new")
        results = backend.query([0.0, 1.0, 0.0], top_k=1)
        assert results[0]["document"] == "new"

    def test_query_with_filter(self, backend):
        backend.upsert("1", [1.0, 0.0, 0.0], metadata={"type": "a"}, document="a")
        backend.upsert("2", [0.9, 0.1, 0.0], metadata={"type": "b"}, document="b")
        results = backend.query([1.0, 0.0, 0.0], top_k=5, where={"type": "a"})
        assert len(results) == 1
        assert results[0]["id"] == "1"

    def test_delete(self, backend):
        backend.upsert("1", [1.0, 0.0, 0.0], document="to delete")
        backend.delete("1")
        results = backend.query([1.0, 0.0, 0.0], top_k=5)
        assert len(results) == 0

    def test_count(self, backend):
        assert backend.count() == 0
        backend.upsert("1", [1.0, 0.0, 0.0])
        backend.upsert("2", [0.0, 1.0, 0.0])
        assert backend.count() == 2

    def test_cosine_similarity(self, backend):
        # Same vector → similarity = 1.0
        sim = backend._cosine_similarity([1.0, 0.0, 0.0], [1.0, 0.0, 0.0])
        assert abs(sim - 1.0) < 1e-6

        # Orthogonal vectors → similarity = 0.0
        sim = backend._cosine_similarity([1.0, 0.0, 0.0], [0.0, 1.0, 0.0])
        assert abs(sim) < 1e-6

    def test_metadata_in_results(self, backend):
        backend.upsert("1", [1.0, 0.0, 0.0], metadata={"key": "val"}, document="doc")
        results = backend.query([1.0, 0.0, 0.0], top_k=1)
        assert results[0]["metadata"]["key"] == "val"
        assert results[0]["document"] == "doc"
