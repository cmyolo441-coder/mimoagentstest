"""Unit tests for vector store module."""
