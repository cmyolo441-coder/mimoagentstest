"""Unit tests for safety support."""
