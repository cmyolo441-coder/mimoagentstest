"""Tests for terminal_agent.support.rate_limiter.token_bucket.TokenBucket."""

from __future__ import annotations

import time
import pytest

from terminal_agent.support.rate_limiter.token_bucket import TokenBucket


class TestTokenBucket:
    """Tests for TokenBucket."""

    def test_acquire_success(self):
        bucket = TokenBucket(rate=10.0, capacity=5)
        assert bucket.acquire() is True

    def test_acquire_exhausted(self):
        bucket = TokenBucket(rate=0.001, capacity=2)
        assert bucket.acquire() is True
        assert bucket.acquire() is True
        assert bucket.acquire() is False  # Exhausted

    def test_refill(self):
        bucket = TokenBucket(rate=100.0, capacity=1)
        bucket.acquire()
        time.sleep(0.05)  # Wait for refill
        assert bucket.acquire() is True

    def test_acquire_multiple_tokens(self):
        bucket = TokenBucket(rate=0.001, capacity=10)
        assert bucket.acquire(5) is True
        assert bucket.acquire(5) is True
        assert bucket.acquire(1) is False  # Exhausted

    def test_name(self):
        bucket = TokenBucket(rate=10.0, capacity=5, name="test_bucket")
        assert bucket.name == "test_bucket"

    def test_tokens_property(self):
        bucket = TokenBucket(rate=10.0, capacity=5)
        assert abs(bucket.tokens - 5.0) < 0.01
        bucket.acquire(2)
        assert abs(bucket.tokens - 3.0) < 0.01

    def test_reset(self):
        bucket = TokenBucket(rate=0.001, capacity=5)
        bucket.acquire(5)
        assert bucket.acquire() is False
        bucket.reset()
        assert bucket.acquire() is True

    def test_try_acquire_returns_float(self):
        bucket = TokenBucket(rate=0.001, capacity=2)
        consumed = bucket.try_acquire(1)
        assert consumed == 1.0
        consumed = bucket.try_acquire(1)
        assert consumed == 1.0
        consumed = bucket.try_acquire(1)
        assert consumed < 0.01  # Essentially zero (tiny refill may occur)

    def test_capacity_property(self):
        bucket = TokenBucket(rate=10.0, capacity=100)
        assert bucket.capacity == 100.0

    def test_rate_property(self):
        bucket = TokenBucket(rate=50.0, capacity=100)
        assert bucket.rate == 50.0
