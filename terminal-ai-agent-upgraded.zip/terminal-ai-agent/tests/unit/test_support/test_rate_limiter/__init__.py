"""Unit tests for rate limiter module."""
