"""Tests for terminal_agent.support.rate_limiter.sliding_window.SlidingWindowLimiter."""

from __future__ import annotations

import pytest

from terminal_agent.support.rate_limiter.sliding_window import SlidingWindowLimiter


class TestSlidingWindowLimiter:
    """Tests for SlidingWindowLimiter."""

    def test_allow_within_limit(self):
        limiter = SlidingWindowLimiter(max_requests=5, window_seconds=1.0)
        for _ in range(5):
            assert limiter.allow() is True

    def test_deny_over_limit(self):
        limiter = SlidingWindowLimiter(max_requests=3, window_seconds=1.0)
        for _ in range(3):
            assert limiter.allow() is True
        assert limiter.allow() is False

    def test_peek_does_not_consume(self):
        limiter = SlidingWindowLimiter(max_requests=1, window_seconds=1.0)
        assert limiter.peek() is True
        assert limiter.peek() is True  # Still available
        limiter.allow()  # Now consume
        assert limiter.peek() is False

    def test_current_count(self):
        limiter = SlidingWindowLimiter(max_requests=10, window_seconds=1.0)
        assert limiter.current_count() == 0
        limiter.allow()
        limiter.allow()
        assert limiter.current_count() == 2

    def test_wait_time_no_wait(self):
        limiter = SlidingWindowLimiter(max_requests=10, window_seconds=1.0)
        assert limiter.wait_time() == 0.0

    def test_name(self):
        limiter = SlidingWindowLimiter(max_requests=10, window_seconds=1.0, name="test")
        assert limiter.name == "test"

    def test_reset(self):
        limiter = SlidingWindowLimiter(max_requests=1, window_seconds=60.0)
        limiter.allow()
        assert limiter.allow() is False
        limiter.reset()
        assert limiter.allow() is True
