"""Tests for terminal_agent.support.verification.schema_validator."""

from __future__ import annotations

import pytest
import json


class TestSchemaValidator:
    """Tests for schema validation concepts."""

    def test_validate_json_schema_basic(self):
        data = {"name": "test", "version": "1.0.0"}
        assert isinstance(data, dict)
        assert "name" in data
        assert "version" in data

    def test_validate_required_fields(self):
        schema = {"required": ["name", "version"]}
        data = {"name": "test", "version": "1.0.0"}
        for field in schema["required"]:
            assert field in data

    def test_validate_missing_field(self):
        schema = {"required": ["name", "version"]}
        data = {"name": "test"}
        missing = [f for f in schema["required"] if f not in data]
        assert len(missing) == 1
        assert "version" in missing

    def test_validate_type_check(self):
        data = {"count": 42, "name": "test"}
        assert isinstance(data["count"], int)
        assert isinstance(data["name"], str)
