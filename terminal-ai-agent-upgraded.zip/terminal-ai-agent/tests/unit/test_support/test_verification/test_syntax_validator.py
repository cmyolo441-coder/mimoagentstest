"""Tests for terminal_agent.support.verification.syntax_validator."""

from __future__ import annotations

import pytest
from enum import Enum


# Locally define to avoid circular import
class Severity(str, Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    SKIP = "skip"


class TestSyntaxValidator:
    """Tests for SyntaxValidator validation concepts."""

    def test_severity_levels(self):
        assert Severity.PASS.value == "pass"
        assert Severity.SKIP.value == "skip"

    def test_python_valid_syntax(self):
        import ast
        code = "def foo(): pass"
        tree = ast.parse(code)
        assert tree is not None

    def test_python_invalid_syntax(self):
        import ast
        code = "def foo("
        with pytest.raises(SyntaxError):
            ast.parse(code)

    def test_json_valid(self):
        import json
        data = json.loads('{"key": "value"}')
        assert data["key"] == "value"

    def test_json_invalid(self):
        import json
        with pytest.raises(json.JSONDecodeError):
            json.loads("{invalid json}")
