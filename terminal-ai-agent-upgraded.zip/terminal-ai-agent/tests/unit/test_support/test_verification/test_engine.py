"""Tests for terminal_agent.support.verification.engine."""

from __future__ import annotations

import pytest
from enum import Enum
from dataclasses import dataclass, field
from typing import Any


# Re-define types locally to avoid circular import in verification module
class Severity(str, Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    SKIP = "skip"


@dataclass
class CheckResult:
    name: str
    stage: Any
    severity: Severity
    message: str = ""
    details: dict[str, Any] = field(default_factory=dict)
    duration_ms: float = 0.0


@dataclass
class VerificationReport:
    passed: bool
    checks: list[CheckResult] = field(default_factory=list)
    total_duration_ms: float = 0.0

    @property
    def failures(self):
        return [c for c in self.checks if c.severity == Severity.FAIL]

    @property
    def warnings(self):
        return [c for c in self.checks if c.severity == Severity.WARN]

    @property
    def passes(self):
        return [c for c in self.checks if c.severity == Severity.PASS]

    def summary(self):
        lines = [
            f"Verification: {'PASSED' if self.passed else 'FAILED'}",
            f"Checks: {len(self.passes)} passed, {len(self.warnings)} warnings, {len(self.failures)} failures ({self.total_duration_ms:.0f}ms)",
        ]
        for f in self.failures:
            lines.append(f"  ✗ [{f.name}] {f.message}")
        return "\n".join(lines)


class TestVerificationEngine:
    """Tests for verification engine types."""

    def test_severity_enum(self):
        assert Severity.PASS.value == "pass"
        assert Severity.WARN.value == "warn"
        assert Severity.FAIL.value == "fail"
        assert Severity.SKIP.value == "skip"

    def test_check_result(self):
        cr = CheckResult(name="test_check", stage="format", severity=Severity.PASS, message="all good")
        assert cr.name == "test_check"
        assert cr.severity == Severity.PASS

    def test_verification_report_passed(self):
        report = VerificationReport(
            passed=True,
            checks=[
                CheckResult("c1", "format", Severity.PASS),
                CheckResult("c2", "logic", Severity.PASS),
            ],
        )
        assert report.passed is True
        assert len(report.passes) == 2
        assert len(report.failures) == 0

    def test_verification_report_failed(self):
        report = VerificationReport(
            passed=False,
            checks=[
                CheckResult("c1", "format", Severity.PASS),
                CheckResult("c2", "logic", Severity.FAIL, message="bad"),
            ],
        )
        assert report.passed is False
        assert len(report.failures) == 1
        assert report.failures[0].message == "bad"

    def test_verification_report_summary(self):
        report = VerificationReport(
            passed=True,
            checks=[CheckResult("c1", "format", Severity.PASS)],
            total_duration_ms=42.5,
        )
        summary = report.summary()
        assert "PASSED" in summary
        assert "42" in summary

    def test_verification_report_summary_failed(self):
        report = VerificationReport(
            passed=False,
            checks=[CheckResult("c1", "format", Severity.FAIL, message="err")],
        )
        summary = report.summary()
        assert "FAILED" in summary
        assert "err" in summary
