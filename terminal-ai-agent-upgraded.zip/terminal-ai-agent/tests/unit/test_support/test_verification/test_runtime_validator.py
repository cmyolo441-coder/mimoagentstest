"""Tests for terminal_agent.support.verification.runtime_validator."""

from __future__ import annotations

import pytest
import subprocess


class TestRuntimeValidator:
    """Tests for runtime validation concepts."""

    def test_python_runtime_valid(self):
        result = subprocess.run(
            ["python3", "-c", "print('hello')"],
            capture_output=True, text=True, timeout=5,
        )
        assert result.returncode == 0
        assert "hello" in result.stdout

    def test_python_runtime_error(self):
        result = subprocess.run(
            ["python3", "-c", "raise ValueError('test')"],
            capture_output=True, text=True, timeout=5,
        )
        assert result.returncode != 0

    def test_timeout_handling(self):
        with pytest.raises(subprocess.TimeoutExpired):
            subprocess.run(
                ["python3", "-c", "import time; time.sleep(10)"],
                capture_output=True, text=True, timeout=1,
            )
