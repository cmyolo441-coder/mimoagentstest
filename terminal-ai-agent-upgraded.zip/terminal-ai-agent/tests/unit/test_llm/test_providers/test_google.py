"""Tests for terminal_agent.llm.providers.google_provider — Google Gemini provider."""

from __future__ import annotations

import pytest


class TestGoogleProviderCapabilities:
    def test_provider_module_importable(self):
        from terminal_agent.llm.providers import google_provider
        assert hasattr(google_provider, "GoogleProvider")

    def test_provider_id(self):
        from terminal_agent.llm.providers.google_provider import GoogleProvider
        assert GoogleProvider.provider_id == "google"
