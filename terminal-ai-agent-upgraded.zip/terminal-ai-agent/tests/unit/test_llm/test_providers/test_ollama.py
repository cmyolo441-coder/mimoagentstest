"""Tests for terminal_agent.llm.providers.ollama_provider — Ollama provider."""

from __future__ import annotations

import pytest


class TestOllamaProviderCapabilities:
    def test_provider_module_importable(self):
        from terminal_agent.llm.providers import ollama_provider
        assert hasattr(ollama_provider, "OllamaProvider")

    def test_provider_id(self):
        from terminal_agent.llm.providers.ollama_provider import OllamaProvider
        assert OllamaProvider.provider_id == "ollama"
