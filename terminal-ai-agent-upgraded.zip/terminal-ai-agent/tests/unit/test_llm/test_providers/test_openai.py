"""Tests for terminal_agent.llm.providers.openai_provider — OpenAI provider."""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from terminal_agent.types import ProviderConfig


class TestOpenAIProviderConfig:
    def test_default_config(self):
        cfg = ProviderConfig(provider="openai", model="gpt-4o", api_key="test")
        assert cfg.provider == "openai"
        assert cfg.model == "gpt-4o"
        assert cfg.temperature == 0.0
        assert cfg.max_tokens == 4096

    def test_config_with_base_url(self):
        cfg = ProviderConfig(
            provider="openai", model="gpt-4o", api_key="test",
            base_url="https://custom.openai.com/v1",
        )
        assert cfg.base_url == "https://custom.openai.com/v1"


class TestOpenAIProviderCapabilities:
    def test_model_caps_defined(self):
        from terminal_agent.llm.providers.openai_provider import _MODEL_CAPS
        assert "gpt-4o" in _MODEL_CAPS
        assert "gpt-4o-mini" in _MODEL_CAPS
        assert "o1" in _MODEL_CAPS
        assert "o3" in _MODEL_CAPS

    def test_gpt4o_caps(self):
        from terminal_agent.llm.providers.openai_provider import _MODEL_CAPS
        caps = _MODEL_CAPS["gpt-4o"]
        assert caps["max_context_tokens"] == 128_000
        assert caps["vision"] is True
        assert caps["json_mode"] is True

    def test_o1_caps(self):
        from terminal_agent.llm.providers.openai_provider import _MODEL_CAPS
        caps = _MODEL_CAPS["o1"]
        assert caps["max_context_tokens"] == 200_000
        assert caps["supports_system_message"] is False
        assert caps["supports_temperature"] is False


class TestOpenAIProviderBuildRequest:
    """Test request building logic."""

    def test_provider_id(self):
        from terminal_agent.llm.providers.openai_provider import OpenAIProvider
        assert OpenAIProvider.provider_id == "openai"
