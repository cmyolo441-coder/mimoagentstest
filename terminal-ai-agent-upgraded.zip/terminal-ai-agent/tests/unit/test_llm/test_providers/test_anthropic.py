"""Tests for terminal_agent.llm.providers.anthropic_provider — Anthropic provider."""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock

from terminal_agent.types import ProviderConfig


class TestAnthropicProviderConfig:
    def test_default_config(self):
        cfg = ProviderConfig(provider="anthropic", model="claude-3-5-sonnet-20241022", api_key="test")
        assert cfg.provider == "anthropic"
        assert cfg.model == "claude-3-5-sonnet-20241022"


class TestAnthropicProviderCapabilities:
    def test_model_caps_defined(self):
        from terminal_agent.llm.providers.anthropic_provider import _MODEL_CAPS
        assert "claude-opus-4" in _MODEL_CAPS
        assert "claude-sonnet-4" in _MODEL_CAPS
        assert "claude-3-5-sonnet" in _MODEL_CAPS
        assert "claude-3-5-haiku" in _MODEL_CAPS

    def test_claude_sonnet_caps(self):
        from terminal_agent.llm.providers.anthropic_provider import _MODEL_CAPS
        caps = _MODEL_CAPS["claude-sonnet-4"]
        assert caps["max_context_tokens"] == 200_000
        assert caps["vision"] is True

    def test_provider_id(self):
        from terminal_agent.llm.providers.anthropic_provider import AnthropicProvider
        assert AnthropicProvider.provider_id == "anthropic"

    def test_api_version(self):
        from terminal_agent.llm.providers.anthropic_provider import _API_VERSION
        assert _API_VERSION == "2023-06-01"
