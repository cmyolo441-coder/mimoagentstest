"""Tests for terminal_agent.llm.response_parser — parsing LLM responses."""

from __future__ import annotations

import json
import pytest
from pathlib import Path

from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.exceptions import ResponseParseError
from terminal_agent.types import LLMResponse


@pytest.fixture
def parser():
    return ResponseParser()


@pytest.fixture
def openai_response_data():
    return {
        "id": "chatcmpl-abc",
        "model": "gpt-4o",
        "choices": [{
            "index": 0,
            "message": {
                "role": "assistant",
                "content": "Hello! How can I help?",
            },
            "finish_reason": "stop",
        }],
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 8,
            "total_tokens": 18,
        },
    }


@pytest.fixture
def anthropic_response_data():
    return {
        "id": "msg_001",
        "type": "message",
        "role": "assistant",
        "content": [
            {"type": "text", "text": "Sure, I can help."},
        ],
        "model": "claude-3-5-sonnet-20241022",
        "stop_reason": "end_turn",
        "usage": {"input_tokens": 12, "output_tokens": 10},
    }


@pytest.fixture
def google_response_data():
    return {
        "candidates": [{
            "content": {
                "parts": [{"text": "Here's the answer."}],
            },
            "finishReason": "STOP",
        }],
        "usageMetadata": {
            "promptTokenCount": 15,
            "candidatesTokenCount": 10,
        },
    }


@pytest.fixture
def ollama_response_data():
    return {
        "model": "llama3",
        "message": {
            "role": "assistant",
            "content": "Hello from Ollama!",
        },
        "done": True,
        "prompt_eval_count": 20,
        "eval_count": 15,
    }


# ── OpenAI parsing ────────────────────────────────────────────────────

class TestParseOpenAI:
    def test_basic_response(self, parser, openai_response_data):
        result = parser.parse_openai(openai_response_data)
        assert isinstance(result, LLMResponse)
        assert result.content == "Hello! How can I help?"
        assert result.finish_reason == "stop"
        assert result.tokens_in == 10
        assert result.tokens_out == 8
        assert result.provider == "openai"

    def test_with_tool_calls(self, parser):
        data = {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": None,
                    "tool_calls": [{
                        "id": "call_001",
                        "type": "function",
                        "function": {
                            "name": "shell.execute",
                            "arguments": '{"command": "ls"}',
                        },
                    }],
                },
                "finish_reason": "tool_calls",
            }],
            "usage": {"prompt_tokens": 50, "completion_tokens": 25},
        }
        result = parser.parse_openai(data)
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].name == "shell.execute"
        assert result.tool_calls[0].parameters == {"command": "ls"}
        assert result.finish_reason == "tool_calls"

    def test_empty_choices_raises(self, parser):
        with pytest.raises(ResponseParseError):
            parser.parse_openai({"choices": []})

    def test_missing_choices_raises(self, parser):
        with pytest.raises(ResponseParseError):
            parser.parse_openai({})

    def test_with_reasoning(self, parser):
        data = {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": "Answer",
                    "reasoning_content": "Let me think...",
                },
                "finish_reason": "stop",
            }],
            "usage": {},
        }
        result = parser.parse_openai(data)
        assert result.reasoning == "Let me think..."


# ── Anthropic parsing ─────────────────────────────────────────────────

class TestParseAnthropic:
    def test_basic_response(self, parser, anthropic_response_data):
        result = parser.parse_anthropic(anthropic_response_data)
        assert result.content == "Sure, I can help."
        assert result.finish_reason == "end_turn"
        assert result.tokens_in == 12
        assert result.tokens_out == 10
        assert result.provider == "anthropic"

    def test_with_tool_use(self, parser):
        data = {
            "content": [
                {"type": "text", "text": "I'll check that."},
                {
                    "type": "tool_use",
                    "id": "toolu_001",
                    "name": "read_file",
                    "input": {"path": "/tmp/test.txt"},
                },
            ],
            "stop_reason": "tool_use",
            "usage": {"input_tokens": 20, "output_tokens": 15},
        }
        result = parser.parse_anthropic(data)
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].name == "read_file"
        assert result.tool_calls[0].parameters == {"path": "/tmp/test.txt"}

    def test_with_thinking(self, parser):
        data = {
            "content": [
                {"type": "thinking", "thinking": "Analyzing..."},
                {"type": "text", "text": "Here's the result."},
            ],
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 10, "output_tokens": 20},
        }
        result = parser.parse_anthropic(data)
        assert result.reasoning == "Analyzing..."
        assert result.content == "Here's the result."

    def test_multiple_text_blocks(self, parser):
        data = {
            "content": [
                {"type": "text", "text": "Part 1."},
                {"type": "text", "text": "Part 2."},
            ],
            "stop_reason": "end_turn",
            "usage": {},
        }
        result = parser.parse_anthropic(data)
        assert "Part 1." in result.content
        assert "Part 2." in result.content


# ── Google parsing ────────────────────────────────────────────────────

class TestParseGoogle:
    def test_basic_response(self, parser, google_response_data):
        result = parser.parse_google(google_response_data)
        assert result.content == "Here's the answer."
        assert result.tokens_in == 15
        assert result.tokens_out == 10
        assert result.provider == "google"

    def test_with_function_call(self, parser):
        data = {
            "candidates": [{
                "content": {
                    "parts": [{
                        "functionCall": {
                            "name": "search",
                            "args": {"query": "test"},
                        },
                    }],
                },
                "finishReason": "STOP",
            }],
            "usageMetadata": {},
        }
        result = parser.parse_google(data)
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].name == "search"

    def test_empty_candidates_raises(self, parser):
        with pytest.raises(ResponseParseError):
            parser.parse_google({"candidates": []})


# ── Ollama parsing ────────────────────────────────────────────────────

class TestParseOllama:
    def test_basic_response(self, parser, ollama_response_data):
        result = parser.parse_ollama(ollama_response_data)
        assert result.content == "Hello from Ollama!"
        assert result.finish_reason == "stop"
        assert result.tokens_in == 20
        assert result.tokens_out == 15
        assert result.provider == "ollama"

    def test_incomplete_response(self, parser):
        data = {
            "model": "llama3",
            "message": {"role": "assistant", "content": "partial"},
            "done": False,
        }
        result = parser.parse_ollama(data)
        assert result.finish_reason == "length"


# ── Utility methods ───────────────────────────────────────────────────

class TestResponseParserUtils:
    def test_is_complete(self, parser):
        resp = LLMResponse(finish_reason="stop")
        assert parser.is_complete(resp) is True

    def test_is_complete_end_turn(self, parser):
        resp = LLMResponse(finish_reason="end_turn")
        assert parser.is_complete(resp) is True

    def test_is_truncated(self, parser):
        resp = LLMResponse(finish_reason="length")
        assert parser.is_truncated(resp) is True

    def test_has_tool_calls(self, parser):
        from terminal_agent.types import ToolCall
        resp = LLMResponse(tool_calls=[ToolCall(name="test", parameters={})])
        assert parser.has_tool_calls(resp) is True

    def test_no_tool_calls(self, parser):
        resp = LLMResponse(tool_calls=[])
        assert parser.has_tool_calls(resp) is False


# ── Streaming chunk parsing ───────────────────────────────────────────

class TestStreamingChunks:
    def test_parse_openai_chunk(self, parser):
        chunk = {
            "choices": [{
                "delta": {"content": "Hello"},
                "finish_reason": None,
            }],
        }
        result = parser.parse_openai_chunk(chunk)
        assert result["delta_content"] == "Hello"
        assert result["finish_reason"] is None

    def test_parse_openai_chunk_finish(self, parser):
        chunk = {
            "choices": [{
                "delta": {},
                "finish_reason": "stop",
            }],
        }
        result = parser.parse_openai_chunk(chunk)
        assert result["finish_reason"] == "stop"

    def test_parse_anthropic_chunk_text_delta(self, parser):
        data = {"delta": {"type": "text_delta", "text": "Hi"}}
        result = parser.parse_anthropic_chunk("content_block_delta", data)
        assert result["delta_content"] == "Hi"

    def test_parse_anthropic_chunk_stop(self, parser):
        result = parser.parse_anthropic_chunk("message_stop", {})
        assert result["finish_reason"] == "end_turn"

    def test_merge_streaming_chunks(self, parser):
        chunks = [
            {"delta_content": "Hello", "finish_reason": None},
            {"delta_content": " world", "finish_reason": None},
            {"delta_content": None, "finish_reason": "stop"},
        ]
        result = parser.merge_streaming_chunks(chunks)
        assert result.content == "Hello world"
        assert result.finish_reason == "stop"
