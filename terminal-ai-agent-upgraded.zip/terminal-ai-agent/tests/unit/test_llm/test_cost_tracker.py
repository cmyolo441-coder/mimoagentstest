"""Tests for terminal_agent.llm.cost_tracker — cost tracking and budgets."""

from __future__ import annotations

import pytest

from terminal_agent.llm.cost_tracker import CostTracker, CostRecord
from terminal_agent.exceptions import CostLimitError


@pytest.fixture
def tracker():
    return CostTracker(max_cost_per_task=1.0, warning_threshold=0.8)


class TestCostTrackerRecord:
    def test_record_basic(self, tracker):
        rec = tracker.record(
            provider="openai", model="gpt-4o",
            tokens_in=100, tokens_out=50,
            cost_usd=0.001, latency_ms=200.0,
        )
        assert isinstance(rec, CostRecord)
        assert rec.provider == "openai"
        assert rec.cost_usd == 0.001

    def test_accumulates_cost(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=100, tokens_out=50, cost_usd=0.1)
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=200, tokens_out=100, cost_usd=0.2)
        assert tracker.total_cost == pytest.approx(0.3)

    def test_accumulates_tokens(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=100, tokens_out=50, cost_usd=0.001)
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=200, tokens_out=100, cost_usd=0.002)
        assert tracker.total_tokens_in == 300
        assert tracker.total_tokens_out == 150
        assert tracker.total_tokens == 450

    def test_call_count(self, tracker):
        assert tracker.call_count == 0
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=10, tokens_out=5, cost_usd=0.001)
        assert tracker.call_count == 1


class TestCostTrackerBudget:
    def test_raises_on_exceed(self, tracker):
        with pytest.raises(CostLimitError):
            tracker.record(provider="openai", model="gpt-4o",
                           tokens_in=1000, tokens_out=500, cost_usd=1.5)

    def test_near_limit_property(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=1000, tokens_out=500, cost_usd=0.85)
        assert tracker.is_near_limit is True

    def test_not_near_limit_initially(self, tracker):
        assert tracker.is_near_limit is False

    def test_budget_remaining(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=100, tokens_out=50, cost_usd=0.3)
        assert tracker.budget_remaining == pytest.approx(0.7)

    def test_budget_remaining_zero_floor(self, tracker):
        """Remaining should never go below zero."""
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=100, tokens_out=50, cost_usd=0.99)
        assert tracker.budget_remaining >= 0


class TestCostTrackerQueries:
    def test_records_list(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=10, tokens_out=5, cost_usd=0.001)
        records = tracker.records
        assert len(records) == 1

    def test_cost_by_model(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=10, tokens_out=5, cost_usd=0.1)
        tracker.record(provider="openai", model="gpt-4o-mini",
                       tokens_in=10, tokens_out=5, cost_usd=0.05)
        by_model = tracker.cost_by_model()
        assert "gpt-4o" in by_model
        assert "gpt-4o-mini" in by_model

    def test_cost_by_provider(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=10, tokens_out=5, cost_usd=0.1)
        tracker.record(provider="anthropic", model="claude-3",
                       tokens_in=10, tokens_out=5, cost_usd=0.2)
        by_provider = tracker.cost_by_provider()
        assert "openai" in by_provider
        assert "anthropic" in by_provider

    def test_average_latency(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=10, tokens_out=5, cost_usd=0.001, latency_ms=100.0)
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=10, tokens_out=5, cost_usd=0.001, latency_ms=200.0)
        assert tracker.average_latency_ms == pytest.approx(150.0)

    def test_average_latency_empty(self, tracker):
        assert tracker.average_latency_ms == 0.0


class TestCostTrackerSummary:
    def test_summary_structure(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=100, tokens_out=50, cost_usd=0.05)
        summary = tracker.summary()
        assert "total_cost_usd" in summary
        assert "total_calls" in summary
        assert "total_tokens" in summary
        assert summary["total_calls"] == 1

    def test_summary_empty(self, tracker):
        summary = tracker.summary()
        assert summary["total_cost_usd"] == 0.0


class TestCostTrackerSession:
    def test_set_session(self, tracker):
        tracker.set_session("session-123")
        rec = tracker.record(provider="openai", model="gpt-4o",
                             tokens_in=10, tokens_out=5, cost_usd=0.001)
        assert rec.session_id == "session-123"

    def test_reset(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=10, tokens_out=5, cost_usd=0.1)
        tracker.reset()
        assert tracker.total_cost == 0.0
        assert tracker.call_count == 0


class TestCostTrackerExport:
    def test_export_records(self, tracker):
        tracker.record(provider="openai", model="gpt-4o",
                       tokens_in=100, tokens_out=50, cost_usd=0.05)
        exported = tracker.export_records()
        assert len(exported) == 1
        assert exported[0]["provider"] == "openai"
        assert "timestamp" in exported[0]
