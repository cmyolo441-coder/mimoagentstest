"""Tests for terminal_agent.llm.token_counter — token counting and budget."""

from __future__ import annotations

import pytest

from terminal_agent.llm.token_counter import (
    TokenCounter,
    MODEL_CONTEXT_LIMITS,
    MODEL_COSTS,
)
from terminal_agent.exceptions import TokenLimitError


@pytest.fixture
def counter_openai():
    return TokenCounter(model="gpt-4o", provider="openai")


@pytest.fixture
def counter_anthropic():
    return TokenCounter(model="claude-3-5-sonnet-20241022", provider="anthropic")


@pytest.fixture
def counter_google():
    return TokenCounter(model="gemini-2.5-pro", provider="google")


@pytest.fixture
def counter_unknown():
    return TokenCounter(model="unknown-model", provider="unknown")


class TestTokenCounting:
    def test_count_text_nonzero(self, counter_openai):
        count = counter_openai.count_text("Hello, world!")
        assert count > 0

    def test_count_text_empty(self, counter_openai):
        count = counter_openai.count_text("")
        # Should return at least 1 for empty text (heuristic)
        assert count >= 0

    def test_count_text_longer_is_more(self, counter_openai):
        short = counter_openai.count_text("hi")
        long = counter_openai.count_text("hello world this is a much longer text")
        assert long > short

    def test_count_messages_basic(self, counter_openai):
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
        ]
        count = counter_openai.count_messages(messages)
        assert count > 0

    def test_count_messages_empty(self, counter_openai):
        count = counter_openai.count_messages([])
        assert count >= 3  # priming tokens

    def test_count_messages_multimodal(self, counter_openai):
        messages = [{
            "role": "user",
            "content": [
                {"type": "text", "text": "What's in this image?"},
                {"type": "image_url", "image_url": {"url": "http://example.com/img.png"}},
            ],
        }]
        count = counter_openai.count_messages(messages)
        assert count > 0

    def test_anthropic_estimate(self, counter_anthropic):
        count = counter_anthropic.count_text("Hello, world!")
        assert count > 0

    def test_google_estimate(self, counter_google):
        count = counter_google.count_text("Hello, world!")
        assert count > 0

    def test_unknown_provider_uses_heuristic(self, counter_unknown):
        count = counter_unknown.count_text("Hello!")
        assert count > 0


class TestContextLimits:
    def test_known_model(self, counter_openai):
        assert counter_openai.get_context_limit() == 128_000

    def test_anthropic_model(self, counter_anthropic):
        assert counter_anthropic.get_context_limit() == 200_000

    def test_google_model(self, counter_google):
        assert counter_google.get_context_limit() == 1_048_576

    def test_unknown_model_default(self, counter_unknown):
        assert counter_unknown.get_context_limit() == 128_000

    def test_model_context_limits_not_empty(self):
        assert len(MODEL_CONTEXT_LIMITS) > 10


class TestCostRates:
    def test_known_model_costs(self, counter_openai):
        in_rate, out_rate = counter_openai.get_cost_rates()
        assert in_rate > 0
        assert out_rate > in_rate  # output costs more

    def test_unknown_model_zero_cost(self, counter_unknown):
        in_rate, out_rate = counter_unknown.get_cost_rates()
        assert in_rate == 0.0
        assert out_rate == 0.0

    def test_estimate_cost(self, counter_openai):
        cost = counter_openai.estimate_cost(1000, 500)
        assert cost > 0

    def test_model_costs_not_empty(self):
        assert len(MODEL_COSTS) > 10


class TestCheckBudget:
    def test_within_budget(self, counter_openai):
        messages = [{"role": "user", "content": "Hello"}]
        # Should not raise for small messages
        counter_openai.check_budget(messages, max_output_tokens=4096)

    def test_exceeds_budget_raises(self):
        counter = TokenCounter(model="gpt-4", provider="openai")
        # gpt-4 has 8192 context limit
        huge_content = "x " * 100_000  # ~25000 tokens
        messages = [{"role": "user", "content": huge_content}]
        with pytest.raises(TokenLimitError):
            counter.check_budget(messages, max_output_tokens=4096)


class TestMaxOutputTokens:
    def test_openai_output(self, counter_openai):
        assert counter_openai.get_max_output_tokens() > 0

    def test_anthropic_output(self, counter_anthropic):
        assert counter_anthropic.get_max_output_tokens() > 0
