"""Tests for terminal_agent.llm.fallback — provider fallback chain."""

from __future__ import annotations

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock

from terminal_agent.llm.fallback import FallbackChain, ProviderHealth
from terminal_agent.types import LLMResponse, ProviderConfig
from terminal_agent.exceptions import (
    ProviderError,
    ProviderNotAvailableError,
    RateLimitError,
)


def _make_provider(provider_id="openai"):
    p = AsyncMock()
    p.provider_id = provider_id
    p.config = ProviderConfig(provider=provider_id, model="test")
    return p


@pytest.fixture
def provider_a():
    return _make_provider("openai")


@pytest.fixture
def provider_b():
    return _make_provider("anthropic")


@pytest.fixture
def success_response():
    return LLMResponse(content="ok", finish_reason="stop", tokens_in=5, tokens_out=3)


class TestProviderHealth:
    def test_initial_state(self):
        p = _make_provider()
        h = ProviderHealth(provider=p)
        assert h.is_available is True
        assert h.consecutive_failures == 0

    def test_record_success(self):
        p = _make_provider()
        h = ProviderHealth(provider=p)
        h.record_failure()
        h.record_success()
        assert h.consecutive_failures == 0
        assert h.total_calls == 2

    def test_record_failure_disables(self):
        p = _make_provider()
        h = ProviderHealth(provider=p, cooldown_seconds=60.0)
        h.record_failure()
        assert h.is_available is False

    def test_exponential_backoff(self):
        p = _make_provider()
        h = ProviderHealth(provider=p, cooldown_seconds=60.0)
        h.record_failure()
        assert h.consecutive_failures == 1
        h.record_failure()
        assert h.consecutive_failures == 2


class TestFallbackChain:
    def test_requires_providers(self):
        with pytest.raises(ValueError):
            FallbackChain([])

    def test_primary(self, provider_a, provider_b):
        chain = FallbackChain([provider_a, provider_b])
        assert chain.primary is provider_a

    def test_providers_list(self, provider_a, provider_b):
        chain = FallbackChain([provider_a, provider_b])
        assert len(chain.providers) == 2

    def test_active_provider(self, provider_a, provider_b):
        chain = FallbackChain([provider_a, provider_b])
        assert chain.active_provider is provider_a


@pytest.mark.asyncio
class TestFallbackChainExecution:
    async def test_primary_succeeds(self, provider_a, provider_b, success_response):
        provider_a.send_prompt.return_value = success_response
        chain = FallbackChain([provider_a, provider_b])
        result = await chain.send_prompt([{"role": "user", "content": "hi"}])
        assert result.content == "ok"
        provider_a.send_prompt.assert_called_once()
        provider_b.send_prompt.assert_not_called()

    async def test_fallback_on_failure(self, provider_a, provider_b, success_response):
        provider_a.send_prompt.side_effect = ProviderError("fail")
        provider_b.send_prompt.return_value = success_response
        chain = FallbackChain([provider_a, provider_b], max_retries_per_provider=1)
        result = await chain.send_prompt([{"role": "user", "content": "hi"}])
        assert result.content == "ok"

    async def test_all_fail_raises(self, provider_a, provider_b):
        provider_a.send_prompt.side_effect = ProviderError("fail a")
        provider_b.send_prompt.side_effect = ProviderError("fail b")
        chain = FallbackChain([provider_a, provider_b], max_retries_per_provider=1)
        with pytest.raises(ProviderNotAvailableError, match="All providers"):
            await chain.send_prompt([{"role": "user", "content": "hi"}])

    async def test_rate_limit_skips_provider(self, provider_a, provider_b, success_response):
        provider_a.send_prompt.side_effect = RateLimitError("limited")
        provider_b.send_prompt.return_value = success_response
        chain = FallbackChain([provider_a, provider_b], max_retries_per_provider=1)
        result = await chain.send_prompt([{"role": "user", "content": "hi"}])
        assert result.content == "ok"


class TestFallbackHealth:
    def test_get_health_report(self, provider_a, provider_b):
        chain = FallbackChain([provider_a, provider_b])
        report = chain.get_health_report()
        assert len(report) == 2
        assert report[0]["provider"] == "openai"
        assert report[0]["available"] is True

    def test_reset_health(self, provider_a):
        chain = FallbackChain([provider_a])
        chain._health[0].record_failure()
        chain.reset_health()
        assert chain._health[0].consecutive_failures == 0
