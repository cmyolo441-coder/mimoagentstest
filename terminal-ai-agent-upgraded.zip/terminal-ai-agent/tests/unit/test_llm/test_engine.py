"""Tests for terminal_agent.llm.engine — the unified LLM engine."""

from __future__ import annotations

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from terminal_agent.llm.engine import LLMEngine
from terminal_agent.types import LLMResponse, ProviderConfig, ToolCall
from terminal_agent.exceptions import ProviderNotAvailableError


@pytest.fixture
def mock_provider():
    provider = AsyncMock()
    provider.provider_id = "openai"
    provider.config = ProviderConfig(
        provider="openai", model="gpt-4o", api_key="test", temperature=0.0, max_tokens=4096,
    )
    provider.send_prompt = AsyncMock(return_value=LLMResponse(
        content="Hello!", tool_calls=[], finish_reason="stop",
        tokens_in=10, tokens_out=5, cost=0.001, provider="openai", model="gpt-4o",
    ))
    provider.send_prompt_streaming = AsyncMock(return_value=iter(["Hello", "!"]))
    provider.validate_config = AsyncMock(return_value=True)
    provider.close = AsyncMock()
    provider.get_model_info = MagicMock(return_value=MagicMock(
        max_context_tokens=128000, max_output_tokens=16384,
    ))
    provider.count_tokens = MagicMock(return_value=10)
    return provider


@pytest.fixture
def engine(mock_provider):
    return LLMEngine([mock_provider])


class TestLLMEngineInit:
    def test_requires_providers(self):
        with pytest.raises(ValueError, match="At least one"):
            LLMEngine([])

    def test_single_provider(self, mock_provider):
        engine = LLMEngine([mock_provider])
        assert engine.primary_provider is mock_provider


class TestLLMEngineProperties:
    def test_cost_tracker(self, engine):
        assert engine.cost_tracker is not None

    def test_token_counter(self, engine):
        assert engine.token_counter is not None

    def test_parser(self, engine):
        assert engine.parser is not None


class TestLLMEngineProviderManagement:
    def test_get_provider(self, engine, mock_provider):
        assert engine.get_provider("openai") is mock_provider

    def test_get_unknown_provider(self, engine):
        assert engine.get_provider("nonexistent") is None

    def test_switch_primary_unknown_raises(self, engine):
        with pytest.raises(ProviderNotAvailableError):
            engine.switch_primary("nonexistent")


@pytest.mark.asyncio
class TestLLMEngineSendPrompt:
    async def test_basic_call(self, engine, mock_provider):
        response = await engine.send_prompt([{"role": "user", "content": "Hi"}])
        assert response.content == "Hello!"
        mock_provider.send_prompt.assert_called_once()

    async def test_temperature_override(self, engine, mock_provider):
        await engine.send_prompt(
            [{"role": "user", "content": "Hi"}],
            temperature=0.5,
        )
        call_kwargs = mock_provider.send_prompt.call_args
        assert call_kwargs.kwargs["temperature"] == 0.5

    async def test_max_tokens_override(self, engine, mock_provider):
        await engine.send_prompt(
            [{"role": "user", "content": "Hi"}],
            max_tokens=1000,
        )
        call_kwargs = mock_provider.send_prompt.call_args
        assert call_kwargs.kwargs["max_tokens"] == 1000

    async def test_force_provider(self, engine, mock_provider):
        response = await engine.send_prompt(
            [{"role": "user", "content": "Hi"}],
            provider="openai",
        )
        assert response.content == "Hello!"

    async def test_unknown_provider_raises(self, engine):
        with pytest.raises(ProviderNotAvailableError):
            await engine.send_prompt(
                [{"role": "user", "content": "Hi"}],
                provider="nonexistent",
            )

    async def test_records_cost(self, engine):
        await engine.send_prompt([{"role": "user", "content": "Hi"}])
        assert engine.cost_tracker.call_count == 1


@pytest.mark.asyncio
class TestLLMEngineSendPromptAndParse:
    async def test_extracts_tool_calls_from_text(self, engine, mock_provider):
        mock_provider.send_prompt.return_value = LLMResponse(
            content='```json\n{"name": "shell.execute", "parameters": {"command": "ls"}}\n```',
            tool_calls=[],
            finish_reason="stop",
            tokens_in=10, tokens_out=5, provider="openai", model="gpt-4o",
        )
        tools = [{"type": "function", "function": {"name": "shell.execute"}}]
        response = await engine.send_prompt_and_parse(
            [{"role": "user", "content": "list files"}],
            tools=tools,
        )
        # Should have extracted tool calls from text
        assert len(response.tool_calls) > 0


@pytest.mark.asyncio
class TestLLMEngineLifecycle:
    async def test_close(self, engine, mock_provider):
        await engine.close()
        mock_provider.close.assert_called_once()

    async def test_validate_all(self, engine, mock_provider):
        results = await engine.validate_all()
        assert results["openai"] is True

    async def test_get_cost_summary(self, engine):
        summary = engine.get_cost_summary()
        assert "total_cost_usd" in summary

    async def test_get_health_report(self, engine):
        report = engine.get_health_report()
        assert len(report) == 1
        assert report[0]["provider"] == "openai"


class TestLLMEngineCallbacks:
    def test_on_response(self, engine):
        callback = MagicMock()
        engine.on_response(callback)
        assert len(engine._on_response_callbacks) == 1
