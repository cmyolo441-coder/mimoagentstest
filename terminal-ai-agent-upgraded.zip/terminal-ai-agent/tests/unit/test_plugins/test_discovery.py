"""Tests for terminal_agent.plugins.discovery.PluginDiscovery."""

from __future__ import annotations

import json
import pytest
from pathlib import Path

from terminal_agent.plugins.discovery import (
    PluginDiscovery, PluginManifest, DiscoveredPlugin,
    MANIFEST_FILENAME, ALT_MANIFEST_FILENAME,
)


@pytest.fixture
def plugin_dir(tmp_path):
    """Create a directory with a valid plugin structure."""
    pdir = tmp_path / "test_plugin"
    pdir.mkdir()
    manifest = {
        "name": "test-plugin",
        "version": "1.0.0",
        "author": "Test Author",
        "description": "A test plugin",
        "entry_point": "main.py",
        "dependencies": [],
        "tags": ["test"],
    }
    (pdir / "plugin.json").write_text(json.dumps(manifest, indent=2))
    (pdir / "main.py").write_text("# Plugin entry point\n")
    return pdir


@pytest.fixture
def plugin_dir_alt_manifest(tmp_path):
    """Create a plugin directory using manifest.json (alternate name)."""
    pdir = tmp_path / "alt_plugin"
    pdir.mkdir()
    manifest = {
        "name": "alt-plugin",
        "version": "0.5.0",
        "description": "Alternate manifest plugin",
    }
    (pdir / "manifest.json").write_text(json.dumps(manifest))
    (pdir / "main.py").write_text("# alt entry\n")
    return pdir


class TestPluginDiscovery:
    """Tests for PluginDiscovery."""

    def test_discover_valid_plugin(self, plugin_dir):
        discovery = PluginDiscovery(plugin_dirs=[plugin_dir.parent])
        plugins = discovery.discover()
        names = [p.manifest.name for p in plugins]
        assert "test-plugin" in names

    def test_discover_alt_manifest(self, plugin_dir_alt_manifest):
        discovery = PluginDiscovery(plugin_dirs=[plugin_dir_alt_manifest.parent])
        plugins = discovery.discover()
        names = [p.manifest.name for p in plugins]
        assert "alt-plugin" in names

    def test_discover_empty_dir(self, tmp_path):
        empty = tmp_path / "empty_plugins"
        empty.mkdir()
        discovery = PluginDiscovery(plugin_dirs=[empty])
        plugins = discovery.discover()
        assert len(plugins) == 0

    def test_discover_nonexistent_dir(self):
        discovery = PluginDiscovery(plugin_dirs=["/nonexistent/path/xyz"])
        plugins = discovery.discover()
        assert len(plugins) == 0

    def test_add_directory(self, plugin_dir):
        discovery = PluginDiscovery()
        discovery.add_directory(plugin_dir.parent)
        assert len(discovery.directories) == 1

    def test_plugin_manifest_dataclass(self):
        manifest = PluginManifest(
            name="test", version="1.0.0", description="A test plugin",
        )
        assert manifest.name == "test"
        assert manifest.entry_point == "main.py"
        assert manifest.dependencies == []

    def test_discovered_plugin_dataclass(self):
        manifest = PluginManifest(name="test", version="1.0.0")
        dp = DiscoveredPlugin(manifest=manifest, path=Path("/test"))
        assert dp.valid is True
        assert dp.errors == []

    def test_manifest_filenames(self):
        assert MANIFEST_FILENAME == "plugin.json"
        assert ALT_MANIFEST_FILENAME == "manifest.json"
