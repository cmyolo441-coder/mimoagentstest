"""Tests for terminal_agent.plugins.sandbox."""

from __future__ import annotations

import pytest

from terminal_agent.plugins.sandbox import (
    PluginSandbox, SandboxConfig, SandboxViolation,
)


class TestPluginSandbox:
    """Tests for PluginSandbox."""

    def test_default_config(self):
        config = SandboxConfig()
        assert config.max_memory_mb == 256
        assert config.allow_network is False
        assert config.allow_subprocess is False
        assert config.restrict_builtins is True

    def test_sandbox_init(self):
        sandbox = PluginSandbox()
        assert sandbox.is_active is False

    def test_sandbox_config(self):
        config = SandboxConfig(allow_network=True, max_memory_mb=512)
        sandbox = PluginSandbox(config=config)
        assert sandbox.config.allow_network is True
        assert sandbox.config.max_memory_mb == 512

    def test_sandbox_violation_exception(self):
        with pytest.raises(SandboxViolation):
            raise SandboxViolation("test violation")

    def test_blocked_paths_default(self):
        config = SandboxConfig()
        assert "/etc" in config.blocked_paths
        assert "/sys" in config.blocked_paths

    def test_execute_context_manager(self):
        sandbox = PluginSandbox()
        with sandbox.execute():
            assert sandbox.is_active is True
        assert sandbox.is_active is False
