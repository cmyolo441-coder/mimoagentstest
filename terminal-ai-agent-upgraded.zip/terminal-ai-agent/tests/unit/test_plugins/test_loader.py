"""Tests for terminal_agent.plugins.loader.PluginLoader."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.plugins.loader import PluginLoader, PluginModule
from terminal_agent.plugins.discovery import DiscoveredPlugin, PluginManifest
from terminal_agent.exceptions import PluginLoadError


class TestPluginLoader:
    """Tests for PluginLoader."""

    @pytest.fixture
    def loader(self):
        return PluginLoader()

    def test_loaded_plugins_empty(self, loader):
        assert loader.loaded_plugins == {}

    def test_failed_plugins_empty(self, loader):
        assert loader.failed_plugins == {}

    def test_load_nonexistent_raises(self, loader, tmp_path):
        manifest = PluginManifest(name="bad", version="1.0.0", entry_point="missing.py")
        bad_dir = tmp_path / "bad_plugin"
        bad_dir.mkdir()
        dp = DiscoveredPlugin(manifest=manifest, path=bad_dir)
        with pytest.raises(PluginLoadError):
            loader.load(dp)

    def test_plugin_module_properties(self):
        manifest = PluginManifest(name="test", version="1.0.0")
        pm = PluginModule(manifest=manifest, module=None)
        assert pm.loaded is False
        assert pm.get_tools() == []
        assert pm.get_hooks() == {}
