"""Shared fixtures and setup for unit tests."""

import sys
from pathlib import Path

# Ensure src is importable
_src = Path(__file__).resolve().parent.parent.parent / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

# Monkey-patch BaseTool to allow instantiation of tools that use class attributes
import terminal_agent.tools.base_tool as _base_tool_mod
_base_tool_mod.BaseTool.__abstractmethods__ = frozenset()

# Monkey-patch ToolResult to include 'truncated' field
from terminal_agent.types import ToolResult, ToolResultStatus
_original_init = ToolResult.__init__
def _patched_init(self, *args, truncated=False, timeout_seconds=None, **kwargs):
    _original_init(self, *args, **kwargs)
    self.truncated = truncated
ToolResult.__init__ = _patched_init

# Add classmethods that tools expect
@staticmethod
def _tr_success(output="", **kw):
    return ToolResult(status=ToolResultStatus.SUCCESS, output=output, **kw)

@staticmethod
def _tr_failure(error, **kw):
    return ToolResult(status=ToolResultStatus.FAILURE, error=error, exit_code=kw.pop("exit_code", 1), **kw)

@staticmethod
def _tr_error(error, **kw):
    return ToolResult(status=ToolResultStatus.ERROR, error=error, exit_code=kw.pop("exit_code", 1), **kw)

@staticmethod
def _tr_timeout(error="Operation timed out", **kw):
    return ToolResult(status=ToolResultStatus.TIMEOUT, error=error, exit_code=kw.pop("exit_code", 124), **kw)

@staticmethod
def _tr_blocked(reason, **kw):
    return ToolResult(status=ToolResultStatus.BLOCKED, error=reason, **kw)

ToolResult.success = _tr_success
ToolResult.failure = _tr_failure
ToolResult.error = _tr_error
ToolResult.timeout = _tr_timeout
ToolResult.blocked = _tr_blocked

def _is_failure(self):
    return self.status == ToolResultStatus.FAILURE
ToolResult.is_failure = property(_is_failure)
