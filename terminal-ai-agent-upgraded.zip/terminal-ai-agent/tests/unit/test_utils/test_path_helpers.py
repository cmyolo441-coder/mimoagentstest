"""Tests for terminal_agent.utils.path_helpers."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.utils.path_helpers import normalize_path, relative_to, is_subpath, safe_join


class TestPathHelpers:
    """Tests for path helper utilities."""

    def test_normalize_path_absolute(self):
        result = normalize_path("/tmp/test")
        assert result.is_absolute()
        assert "test" in str(result)

    def test_normalize_path_relative_with_base(self):
        result = normalize_path("relative/path", base="/home/user")
        assert result.is_absolute()
        assert "relative" in str(result)

    def test_normalize_path_expanduser(self):
        result = normalize_path("~/test")
        assert result.is_absolute()
        assert "~" not in str(result)

    def test_relative_to(self):
        result = relative_to("/home/user/project/src/main.py", "/home/user/project")
        assert result is not None
        assert str(result) == "src/main.py"

    def test_relative_to_not_relative(self):
        result = relative_to("/other/path", "/home/user")
        assert result is None

    def test_is_subpath_true(self):
        assert is_subpath("/home/user/project/src", "/home/user/project") is True

    def test_is_subpath_false(self):
        assert is_subpath("/other/path", "/home/user") is False

    def test_safe_join(self):
        result = safe_join("/base", "sub", "dir")
        assert str(result).startswith("/base")
        assert "sub" in str(result)
        assert "dir" in str(result)

    def test_safe_join_traversal_raises(self):
        with pytest.raises(ValueError):
            safe_join("/base", "..", "..", "etc", "passwd")
