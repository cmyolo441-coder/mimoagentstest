"""Tests for terminal_agent.utils.async_helpers."""

from __future__ import annotations

import asyncio
import pytest

from terminal_agent.utils.async_helpers import run_sync, gather_with_concurrency, retry_async


class TestAsyncHelpers:
    """Tests for async helper utilities."""

    @pytest.mark.asyncio
    async def test_run_sync(self):
        def add(a, b):
            return a + b

        result = await run_sync(add, 2, 3)
        assert result == 5

    @pytest.mark.asyncio
    async def test_run_sync_with_kwargs(self):
        def greet(name, greeting="hello"):
            return f"{greeting} {name}"

        result = await run_sync(greet, "world", greeting="hi")
        assert result == "hi world"

    @pytest.mark.asyncio
    async def test_gather_with_concurrency(self):
        results = []
        call_order = []

        async def task(i):
            call_order.append(i)
            return i * 2

        results = await gather_with_concurrency(
            *[task(i) for i in range(5)],
            max_concurrency=2,
        )
        assert results == [0, 2, 4, 6, 8]

    @pytest.mark.asyncio
    async def test_retry_async_success(self):
        call_count = 0

        async def flaky():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("not yet")
            return "success"

        result = await retry_async(flaky, max_retries=5, delay=0.01)
        assert result == "success"
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_retry_async_exhausted(self):
        async def always_fail():
            raise ValueError("always fails")

        with pytest.raises(ValueError, match="always fails"):
            await retry_async(always_fail, max_retries=2, delay=0.01)
