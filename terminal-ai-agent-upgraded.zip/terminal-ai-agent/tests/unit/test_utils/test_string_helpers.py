"""Tests for terminal_agent.utils.string_helpers."""

from __future__ import annotations

import pytest

from terminal_agent.utils.string_helpers import (
    truncate, slugify, camel_to_snake, snake_to_camel, strip_ansi,
)


class TestStringHelpers:
    """Tests for string helper utilities."""

    def test_truncate_short(self):
        assert truncate("hello", max_length=10) == "hello"

    def test_truncate_long(self):
        result = truncate("hello world", max_length=8)
        assert len(result) == 8
        assert result.endswith("...")

    def test_truncate_custom_suffix(self):
        result = truncate("hello world", max_length=8, suffix="~")
        assert result.endswith("~")

    def test_slugify(self):
        assert slugify("Hello World") == "hello-world"
        assert slugify("  spaces  ") == "spaces"
        assert slugify("special!@#chars") == "specialchars"

    def test_slugify_separator(self):
        assert slugify("hello world", separator="_") == "hello_world"

    def test_camel_to_snake(self):
        assert camel_to_snake("camelCase") == "camel_case"
        assert camel_to_snake("CamelCase") == "camel_case"
        assert camel_to_snake("simpleXML") == "simple_xml"

    def test_snake_to_camel(self):
        assert snake_to_camel("snake_case") == "snakeCase"
        assert snake_to_camel("snake_case", upper=True) == "SnakeCase"

    def test_strip_ansi(self):
        text = "\x1b[31mred\x1b[0m normal"
        assert strip_ansi(text) == "red normal"

    def test_strip_ansi_no_codes(self):
        assert strip_ansi("plain text") == "plain text"
