"""Tests for terminal_agent.utils.file_helpers."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.utils.file_helpers import read_file_safe, write_file_safe


class TestFileHelpers:
    """Tests for file helper utilities."""

    def test_read_file_safe(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        assert read_file_safe(f) == "hello"

    def test_read_file_safe_missing(self, tmp_path):
        result = read_file_safe(tmp_path / "missing.txt", default="fallback")
        assert result == "fallback"

    def test_read_file_safe_permission(self, tmp_path):
        f = tmp_path / "noperm.txt"
        f.write_text("secret")
        f.chmod(0o000)
        try:
            result = read_file_safe(f, default="no access")
            # May or may not be readable depending on user
            assert isinstance(result, str)
        finally:
            f.chmod(0o644)

    def test_write_file_safe(self, tmp_path):
        f = tmp_path / "output.txt"
        result = write_file_safe(f, "content")
        assert result is True
        assert f.read_text() == "content"

    def test_write_file_safe_creates_dirs(self, tmp_path):
        f = tmp_path / "a" / "b" / "c.txt"
        result = write_file_safe(f, "nested")
        assert result is True
        assert f.read_text() == "nested"

    def test_write_file_safe_atomic(self, tmp_path):
        f = tmp_path / "atomic.txt"
        result = write_file_safe(f, "atomic content", atomic=True)
        assert result is True
        assert f.read_text() == "atomic content"

    def test_write_file_safe_with_backup(self, tmp_path):
        f = tmp_path / "backup.txt"
        f.write_text("original")
        result = write_file_safe(f, "updated", backup=True)
        assert result is True
        assert f.read_text() == "updated"
