"""Tests for terminal_agent.mcp.server.handler.MCPRequestHandler."""

from __future__ import annotations

import pytest

from terminal_agent.mcp.server.handler import MCPRequestHandler, RequestLog


class TestMCPServerHandler:
    """Tests for MCPRequestHandler."""

    @pytest.fixture
    def handler(self):
        return MCPRequestHandler()

    @pytest.mark.asyncio
    async def test_handle_list_tools_empty(self, handler):
        result = await handler.handle_list_tools()
        assert "tools" in result
        assert isinstance(result["tools"], list)

    @pytest.mark.asyncio
    async def test_handle_call_tool_not_found(self, handler):
        result = await handler.handle_call_tool({"name": "nonexistent", "arguments": {}})
        assert result.get("isError") is True

    def test_request_log_dataclass(self):
        log = RequestLog(method="test", params={"key": "val"})
        assert log.method == "test"
        assert log.error is None
        assert log.duration_ms == 0.0

    def test_registration_property(self, handler):
        assert handler.registration is not None
