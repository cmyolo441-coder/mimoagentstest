"""Tests for terminal_agent.mcp.client.connection."""

from __future__ import annotations

import pytest

from terminal_agent.mcp.client.connection import (
    TransportType, ConnectionState, MCPServerConfig,
    JSONRPCRequest, JSONRPCResponse,
)


class TestMCPClientConnection:
    """Tests for MCP client connection types."""

    def test_transport_type_enum(self):
        assert TransportType.STDIO.value == "stdio"
        assert TransportType.HTTP.value == "http"
        assert TransportType.SSE.value == "sse"

    def test_connection_state_enum(self):
        assert ConnectionState.DISCONNECTED.value == "disconnected"
        assert ConnectionState.CONNECTED.value == "connected"
        assert ConnectionState.CLOSED.value == "closed"

    def test_server_config_defaults(self):
        config = MCPServerConfig(name="test-server")
        assert config.name == "test-server"
        assert config.transport == TransportType.STDIO
        assert config.timeout == 30.0
        assert config.max_retries == 3

    def test_server_config_custom(self):
        config = MCPServerConfig(
            name="custom", transport=TransportType.HTTP,
            url="http://localhost:8080", timeout=60.0,
        )
        assert config.transport == TransportType.HTTP
        assert config.url == "http://localhost:8080"

    def test_jsonrpc_request(self):
        req = JSONRPCRequest(method="tools/list", params={})
        d = req.to_dict()
        assert d["jsonrpc"] == "2.0"
        assert d["method"] == "tools/list"
        assert "id" in d

    def test_jsonrpc_response_success(self):
        resp = JSONRPCResponse(id="1", result={"tools": []})
        assert resp.is_error is False
        assert resp.result == {"tools": []}

    def test_jsonrpc_response_error(self):
        resp = JSONRPCResponse(id="1", error={"code": -32600, "message": "Invalid"})
        assert resp.is_error is True

    def test_jsonrpc_request_id_generation(self):
        r1 = JSONRPCRequest(method="test")
        r2 = JSONRPCRequest(method="test")
        assert r1.id != r2.id
