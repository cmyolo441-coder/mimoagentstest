"""Tests for terminal_agent.tools.result.ToolResultBuilder."""

from __future__ import annotations

import pytest

from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import ToolResult, ToolResultStatus


class TestToolResultBuilder:
    """Tests for ToolResultBuilder fluent API."""

    def test_success(self):
        result = ToolResultBuilder().success("all good").build()
        assert result.status == ToolResultStatus.SUCCESS
        assert result.output == "all good"
        assert result.exit_code == 0

    def test_failure(self):
        result = ToolResultBuilder().failure("something broke").build()
        assert result.status == ToolResultStatus.FAILURE
        assert result.error == "something broke"
        assert result.exit_code == 1

    def test_error(self):
        result = ToolResultBuilder().error("bad", exit_code=42).build()
        assert result.status == ToolResultStatus.ERROR
        assert result.error == "bad"
        assert result.exit_code == 42

    def test_timeout(self):
        result = ToolResultBuilder().timeout("timed out").build()
        assert result.status == ToolResultStatus.TIMEOUT
        assert result.exit_code == 124

    def test_blocked(self):
        result = ToolResultBuilder().blocked("safety block").build()
        assert result.status == ToolResultStatus.BLOCKED
        assert result.error == "safety block"

    def test_partial(self):
        result = ToolResultBuilder().partial("half done").build()
        assert result.status == ToolResultStatus.PARTIAL
        assert result.output == "half done"

    def test_with_output(self):
        result = ToolResultBuilder().success().with_output("data").build()
        assert result.output == "data"

    def test_with_exit_code_changes_status(self):
        result = ToolResultBuilder().success().with_exit_code(1).build()
        assert result.status == ToolResultStatus.ERROR
        assert result.exit_code == 1

    def test_with_exit_code_zero_keeps_success(self):
        result = ToolResultBuilder().success().with_exit_code(0).build()
        assert result.status == ToolResultStatus.SUCCESS

    def test_with_duration(self):
        result = ToolResultBuilder().success().with_duration(123.4).build()
        assert result.duration_ms == 123.4

    def test_with_side_effect(self):
        result = ToolResultBuilder().success().with_side_effect("created file").build()
        assert "created file" in result.side_effects

    def test_with_side_effects(self):
        result = ToolResultBuilder().success().with_side_effects(["a", "b"]).build()
        assert result.side_effects == ["a", "b"]

    def test_with_metadata(self):
        result = ToolResultBuilder().success().with_metadata("key", "val").build()
        assert result.metadata["key"] == "val"

    def test_with_metadata_dict(self):
        result = ToolResultBuilder().success().with_metadata_dict({"a": 1, "b": 2}).build()
        assert result.metadata == {"a": 1, "b": 2}

    def test_chaining(self):
        result = (
            ToolResultBuilder()
            .success("output")
            .with_duration(50.0)
            .with_side_effect("effect1")
            .with_metadata("k", "v")
            .build()
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert result.output == "output"
        assert result.duration_ms == 50.0
        assert result.side_effects == ["effect1"]
        assert result.metadata["k"] == "v"

    def test_ok_classmethod(self):
        result = ToolResultBuilder.ok("quick ok", extra="data")
        assert result.status == ToolResultStatus.SUCCESS
        assert result.output == "quick ok"
        assert result.metadata["extra"] == "data"

    def test_fail_classmethod(self):
        result = ToolResultBuilder.fail("quick fail", code=42)
        assert result.status == ToolResultStatus.FAILURE
        assert result.error == "quick fail"
        assert result.metadata["code"] == 42

    def test_err_classmethod(self):
        result = ToolResultBuilder.err("quick err", exit_code=99)
        assert result.status == ToolResultStatus.ERROR
        assert result.exit_code == 99
