"""Tests for terminal_agent.tools.network.http_client.HTTPClientTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.network.http_client import HTTPClientTool


class TestHTTPClientTool:
    """Tests for HTTPClientTool."""

    @pytest.fixture
    def tool(self):
        return HTTPClientTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "http_client"
        assert defn.category == "network"

    def test_parameters_in_definition(self, tool):
        defn = tool.definition()
        param_names = [p.name for p in defn.parameters]
        assert "url" in param_names
        assert "method" in param_names
        assert "headers" in param_names
        assert "timeout" in param_names
