"""Tests for terminal_agent.tools.network.ssl.SSLCheckTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.network.ssl import SSLCheckTool


class TestSSLCheckTool:
    """Tests for SSLCheckTool."""

    @pytest.fixture
    def tool(self):
        return SSLCheckTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "ssl_check"
        assert defn.category == "network"

    def test_parameters_in_definition(self, tool):
        defn = tool.definition()
        param_names = [p.name for p in defn.parameters]
        assert "action" in param_names
        assert "hostname" in param_names
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "check" in action_param.enum
        assert "expiry" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown", hostname="example.com")
        assert result.status.value == "failure"
