"""Tests for terminal_agent.tools.network.dns.DNSLookupTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.network.dns import DNSLookupTool


class TestDNSLookupTool:
    """Tests for DNSLookupTool."""

    @pytest.fixture
    def tool(self):
        return DNSLookupTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "dns_lookup"
        assert defn.category == "network"

    def test_parameters_in_definition(self, tool):
        defn = tool.definition()
        param_names = [p.name for p in defn.parameters]
        assert "action" in param_names
        assert "hostname" in param_names
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "lookup" in action_param.enum
        assert "reverse" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown", hostname="localhost")
        assert result.status.value == "failure"
