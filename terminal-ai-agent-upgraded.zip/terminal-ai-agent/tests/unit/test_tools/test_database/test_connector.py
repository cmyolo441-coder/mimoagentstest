"""Tests for terminal_agent.tools.database.connector.DatabaseConnector."""

from __future__ import annotations

import pytest

from terminal_agent.tools.database.connector import DatabaseConnector, DRIVER_MAP
from terminal_agent.types import ToolResultStatus


class TestDatabaseConnector:
    """Tests for DatabaseConnector."""

    @pytest.fixture
    def connector(self):
        return DatabaseConnector()

    def test_definition(self, connector):
        defn = connector.definition()
        assert defn.name == "database_connect"
        assert defn.category == "database"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "connect" in action_param.enum
        assert "disconnect" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, connector):
        result = await connector.execute(action="unknown")
        assert result.status == ToolResultStatus.FAILURE

    def test_driver_map(self):
        assert DRIVER_MAP["postgresql://"] == "postgresql"
        assert DRIVER_MAP["mysql://"] == "mysql"
        assert DRIVER_MAP["sqlite://"] == "sqlite"
        assert DRIVER_MAP["mongodb://"] == "mongodb"
        assert DRIVER_MAP["redis://"] == "redis"

    @pytest.mark.asyncio
    async def test_list_connections_empty(self, connector):
        result = await connector.execute(action="list")
        assert result.status == ToolResultStatus.SUCCESS
