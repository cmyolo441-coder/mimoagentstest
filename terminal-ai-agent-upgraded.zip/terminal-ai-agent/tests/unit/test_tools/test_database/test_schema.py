"""Tests for terminal_agent.tools.database.schema.SchemaManager."""

from __future__ import annotations

import pytest

from terminal_agent.tools.database.schema import SchemaManager
from terminal_agent.types import ToolResultStatus


class TestSchemaManager:
    """Tests for SchemaManager."""

    @pytest.fixture
    def manager(self):
        return SchemaManager()

    def test_definition(self, manager):
        defn = manager.definition()
        assert defn.name == "database_schema"
        assert defn.category == "database"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "describe" in action_param.enum
        assert "list_tables" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, manager):
        result = await manager.execute(action="unknown")
        assert result.status == ToolResultStatus.FAILURE
