"""Tests for terminal_agent.tools.database.executor.QueryExecutor."""

from __future__ import annotations

import pytest

from terminal_agent.tools.database.executor import QueryExecutor, DESTRUCTIVE_PATTERNS
from terminal_agent.types import ToolResultStatus


class TestQueryExecutor:
    """Tests for QueryExecutor."""

    @pytest.fixture
    def executor(self):
        return QueryExecutor()

    def test_definition(self, executor):
        defn = executor.definition()
        assert defn.name == "database_query"
        assert defn.category == "database"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "execute" in action_param.enum
        assert "select" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, executor):
        result = await executor.execute(action="unknown", query="SELECT 1")
        assert result.status == ToolResultStatus.FAILURE

    def test_destructive_patterns(self):
        assert len(DESTRUCTIVE_PATTERNS) > 0
        import re
        for pattern in DESTRUCTIVE_PATTERNS:
            assert re.compile(pattern)  # Should compile without error
