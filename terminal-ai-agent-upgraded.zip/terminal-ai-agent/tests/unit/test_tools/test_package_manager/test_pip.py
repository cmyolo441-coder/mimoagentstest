"""Tests for terminal_agent.tools.package_manager.pip.PipManager."""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, patch

from terminal_agent.tools.package_manager.pip import PipManager
from terminal_agent.types import ToolResultStatus
from terminal_agent.tools.result import ToolResultBuilder


class TestPipManager:
    """Tests for PipManager."""

    @pytest.fixture
    def manager(self):
        return PipManager()

    def test_properties(self, manager):
        assert manager.name == "pip"
        assert manager.executable == "pip3"

    def test_definition(self, manager):
        defn = manager.definition()
        assert defn.name == "pip"

    @pytest.mark.asyncio
    async def test_install_no_packages(self, manager):
        result = await manager._install(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_uninstall_no_packages(self, manager):
        result = await manager._uninstall(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_update_no_packages(self, manager):
        result = await manager._update(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_info_no_package(self, manager):
        result = await manager._info(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_search_deprecated(self, manager):
        result = await manager._search(packages=["requests"])
        assert result.status == ToolResultStatus.SUCCESS
        assert "deprecated" in result.output.lower() or "pypi" in result.output.lower()
