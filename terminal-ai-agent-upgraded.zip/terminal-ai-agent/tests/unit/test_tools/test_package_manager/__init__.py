"""Unit tests for package manager tools."""
