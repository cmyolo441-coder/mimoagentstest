"""Tests for terminal_agent.tools.package_manager.cargo.CargoManager."""

from __future__ import annotations

import pytest

from terminal_agent.tools.package_manager.cargo import CargoManager
from terminal_agent.types import ToolResultStatus


class TestCargoManager:
    """Tests for CargoManager."""

    @pytest.fixture
    def manager(self):
        return CargoManager()

    def test_properties(self, manager):
        assert manager.name == "cargo"
        assert manager.executable == "cargo"
        assert manager.lockfile == "Cargo.lock"

    def test_definition(self, manager):
        defn = manager.definition()
        assert defn.name == "cargo"

    @pytest.mark.asyncio
    async def test_uninstall_no_packages(self, manager):
        result = await manager._uninstall(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_update_no_packages(self, manager):
        result = await manager._update(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_info_no_package(self, manager):
        result = await manager._info(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_search_no_term(self, manager):
        result = await manager._search(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_run_script_no_name(self, manager):
        result = await manager._run_script()
        assert result.status == ToolResultStatus.FAILURE
