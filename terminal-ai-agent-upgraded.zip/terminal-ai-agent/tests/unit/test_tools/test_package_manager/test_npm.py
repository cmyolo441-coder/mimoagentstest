"""Tests for terminal_agent.tools.package_manager.npm.NpmManager."""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, patch

from terminal_agent.tools.package_manager.npm import NpmManager
from terminal_agent.types import ToolResultStatus


class TestNpmManager:
    """Tests for NpmManager."""

    @pytest.fixture
    def manager(self):
        return NpmManager()

    def test_properties(self, manager):
        assert manager.name == "npm"
        assert manager.executable == "npm"
        assert manager.lockfile == "package-lock.json"

    def test_definition(self, manager):
        defn = manager.definition()
        assert defn.name == "npm"
        assert defn.category == "package_manager"

    @pytest.mark.asyncio
    async def test_install_no_packages(self, manager):
        with patch.object(manager, "_run_command", new_callable=AsyncMock, return_value=(0, "ok", "")):
            with patch.object(manager, "_result_from_command") as mock_result:
                mock_result.return_value = ToolResultBuilder.ok("installed")
                result = await manager._install()
                assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_uninstall_no_packages(self, manager):
        result = await manager._uninstall(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_update_no_packages(self, manager):
        result = await manager._update(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_info_no_package(self, manager):
        result = await manager._info(packages=[])
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_search_no_term(self, manager):
        result = await manager._search(packages=[])
        assert result.status == ToolResultStatus.FAILURE


# Need this import for the test
from terminal_agent.tools.result import ToolResultBuilder
