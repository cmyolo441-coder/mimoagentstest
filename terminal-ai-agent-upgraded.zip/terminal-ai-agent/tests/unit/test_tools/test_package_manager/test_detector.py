"""Tests for terminal_agent.tools.package_manager.detector.PackageManagerDetector."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.package_manager.detector import PackageManagerDetector, DETECTION_RULES
from terminal_agent.types import ToolResultStatus


class TestPackageManagerDetector:
    """Tests for PackageManagerDetector."""

    @pytest.fixture
    def detector(self):
        return PackageManagerDetector()

    def test_definition(self, detector):
        defn = detector.definition()
        assert defn.name == "package_manager_detect"
        assert defn.category == "package_manager"

    @pytest.mark.asyncio
    async def test_detect_npm(self, detector, tmp_path):
        (tmp_path / "package.json").write_text('{"name": "test"}')
        (tmp_path / "package-lock.json").write_text("{}")
        result = await detector.execute(action="detect", path=str(tmp_path))
        assert result.status == ToolResultStatus.SUCCESS
        assert result.metadata.get("manager") == "npm"

    @pytest.mark.asyncio
    async def test_detect_poetry(self, detector, tmp_path):
        (tmp_path / "pyproject.toml").write_text("[tool.poetry]\n")
        (tmp_path / "poetry.lock").write_text("")
        result = await detector.execute(action="detect", path=str(tmp_path))
        assert result.status == ToolResultStatus.SUCCESS
        assert result.metadata.get("manager") == "poetry"

    @pytest.mark.asyncio
    async def test_detect_cargo(self, detector, tmp_path):
        (tmp_path / "Cargo.toml").write_text('[package]\nname = "test"\n')
        result = await detector.execute(action="detect", path=str(tmp_path))
        assert result.status == ToolResultStatus.SUCCESS
        assert result.metadata.get("manager") == "cargo"

    @pytest.mark.asyncio
    async def test_detect_pip(self, detector, tmp_path):
        (tmp_path / "requirements.txt").write_text("requests>=2.28\n")
        result = await detector.execute(action="detect", path=str(tmp_path))
        assert result.status == ToolResultStatus.SUCCESS
        assert result.metadata.get("manager") == "pip"

    @pytest.mark.asyncio
    async def test_detect_none(self, detector, tmp_path):
        empty = tmp_path / "empty"
        empty.mkdir()
        result = await detector.execute(action="detect", path=str(empty))
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_list_action(self, detector, tmp_path):
        (tmp_path / "package.json").write_text("{}")
        result = await detector.execute(action="list", path=str(tmp_path))
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_unknown_action(self, detector, tmp_path):
        result = await detector.execute(action="unknown", path=str(tmp_path))
        assert result.status == ToolResultStatus.FAILURE

    def test_detection_rules_not_empty(self):
        assert len(DETECTION_RULES) > 0
        assert all(len(r) == 3 for r in DETECTION_RULES)
