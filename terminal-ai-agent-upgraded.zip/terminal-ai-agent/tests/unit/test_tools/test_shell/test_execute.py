"""Tests for terminal_agent.tools.shell.execute.ShellExecuteTool."""

from __future__ import annotations

import asyncio
import pytest
from unittest.mock import patch, AsyncMock

from terminal_agent.tools.shell.execute import ShellExecuteTool
from terminal_agent.types import ToolResultStatus


class TestShellExecuteTool:
    """Tests for ShellExecuteTool."""

    @pytest.fixture
    def tool(self):
        return ShellExecuteTool()

    @pytest.mark.asyncio
    async def test_simple_command(self, tool):
        result = await tool.execute(command="echo hello")
        assert result.status == ToolResultStatus.SUCCESS
        assert "hello" in result.output
        assert result.exit_code == 0

    @pytest.mark.asyncio
    async def test_command_with_exit_code(self, tool):
        result = await tool.execute(command="exit 42")
        assert result.exit_code == 42
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_command_with_stderr(self, tool):
        result = await tool.execute(command="echo err >&2")
        assert result.error is not None
        assert "err" in result.error

    @pytest.mark.asyncio
    async def test_command_with_cwd(self, tool, tmp_path):
        result = await tool.execute(command="pwd", cwd=str(tmp_path))
        assert str(tmp_path) in result.output

    @pytest.mark.asyncio
    async def test_command_with_env(self, tool):
        result = await tool.execute(command="echo $TEST_VAR", env={"TEST_VAR": "hello_world"})
        assert "hello_world" in result.output

    @pytest.mark.asyncio
    async def test_timeout(self, tool):
        result = await tool.execute(command="sleep 10", timeout=1)
        # May timeout or error depending on platform
        assert result.status in (ToolResultStatus.TIMEOUT, ToolResultStatus.ERROR)

    @pytest.mark.asyncio
    async def test_command_not_found(self, tool):
        result = await tool.execute(command="nonexistent_command_xyz_12345")
        assert result.status in (ToolResultStatus.ERROR, ToolResultStatus.FAILURE)

    @pytest.mark.asyncio
    async def test_shell_mode_false(self, tool):
        result = await tool.execute(command="echo hello", shell=False)
        assert result.status == ToolResultStatus.SUCCESS
        assert "hello" in result.output

    def test_metadata(self, tool):
        assert tool.name == "shell.execute"
        assert tool.category == "shell"

    def test_parameters_schema(self, tool):
        params = tool.parameters
        assert "command" in params["properties"]
        assert "command" in params["required"]
