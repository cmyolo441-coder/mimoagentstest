"""Tests for terminal_agent.tools.shell.pipeline.PipelineTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.shell.pipeline import PipelineTool
from terminal_agent.types import ToolResultStatus


class TestPipelineTool:
    """Tests for PipelineTool."""

    @pytest.fixture
    def tool(self):
        return PipelineTool()

    @pytest.mark.asyncio
    async def test_simple_pipeline(self, tool):
        result = await tool.execute(command="echo hello | cat")
        assert result.status == ToolResultStatus.SUCCESS
        assert "hello" in result.output

    @pytest.mark.asyncio
    async def test_pipeline_with_grep(self, tool):
        result = await tool.execute(command="echo -e 'line1\nline2\nline3' | grep line2")
        assert result.status == ToolResultStatus.SUCCESS
        assert "line2" in result.output

    @pytest.mark.asyncio
    async def test_pipeline_count(self, tool):
        result = await tool.execute(command="echo -e 'a\nb\nc' | wc -l")
        assert result.status == ToolResultStatus.SUCCESS
        assert "3" in result.output

    @pytest.mark.asyncio
    async def test_empty_pipeline(self, tool):
        result = await tool.execute(command="")
        assert result.status == ToolResultStatus.ERROR

    @pytest.mark.asyncio
    async def test_pipeline_failure(self, tool):
        result = await tool.execute(command="echo hello | false", fail_fast=True)
        assert result.status in (ToolResultStatus.FAILURE, ToolResultStatus.ERROR)

    def test_parse_stages(self):
        stages = PipelineTool._parse_stages("cat file | grep err | wc -l")
        assert len(stages) == 3
        assert stages[0] == "cat file"
        assert stages[1] == "grep err"
        assert stages[2] == "wc -l"

    def test_parse_stages_with_quotes(self):
        stages = PipelineTool._parse_stages('echo "hello | world" | cat')
        assert len(stages) == 2
        assert "hello | world" in stages[0]

    def test_metadata(self, tool):
        assert tool.name == "shell.pipeline"
        assert tool.category == "shell"
