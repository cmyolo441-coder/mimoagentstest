"""Tests for terminal_agent.tools.shell.background.BackgroundTool."""

from __future__ import annotations

import asyncio
import pytest

from terminal_agent.tools.shell.background import BackgroundTool, BackgroundJob
from terminal_agent.types import ToolResultStatus


class TestBackgroundTool:
    """Tests for BackgroundTool."""

    @pytest.fixture
    def tool(self):
        # Reset class-level state
        BackgroundTool._jobs.clear()
        BackgroundTool._counter = 0
        return BackgroundTool()

    @pytest.mark.asyncio
    async def test_launch_background_job(self, tool):
        result = await tool.execute(command="echo bg_test")
        assert result.status == ToolResultStatus.SUCCESS
        assert "bg-" in result.output
        assert result.metadata.get("job_id") is not None

    @pytest.mark.asyncio
    async def test_job_stored(self, tool):
        result = await tool.execute(command="echo stored")
        job_id = result.metadata["job_id"]
        job = BackgroundTool.get_job(job_id)
        assert job is not None
        assert job.command == "echo stored"

    @pytest.mark.asyncio
    async def test_list_jobs(self, tool):
        await tool.execute(command="echo job1")
        await tool.execute(command="echo job2")
        jobs = BackgroundTool.list_jobs()
        assert len(jobs) >= 2
        assert all("job_id" in j for j in jobs)

    @pytest.mark.asyncio
    async def test_job_finishes(self, tool):
        result = await tool.execute(command="echo done")
        job_id = result.metadata["job_id"]
        # Wait for background task to complete
        await asyncio.sleep(0.5)
        job = BackgroundTool.get_job(job_id)
        assert job.finished is True
        assert job.exit_code == 0

    def test_metadata(self, tool):
        assert tool.name == "shell.background"
        assert tool.category == "shell"

    @pytest.mark.asyncio
    async def test_job_id_increments(self, tool):
        r1 = await tool.execute(command="echo a")
        r2 = await tool.execute(command="echo b")
        assert r1.metadata["job_id"] != r2.metadata["job_id"]
