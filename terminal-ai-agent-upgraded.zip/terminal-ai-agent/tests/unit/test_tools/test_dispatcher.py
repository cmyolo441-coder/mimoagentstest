"""Tests for terminal_agent.tools.dispatcher.ToolDispatcher."""

from __future__ import annotations

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock

from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.base_tool import BaseTool
from terminal_agent.types import SafetyLevel, ToolCall, ToolResult, ToolResultStatus


def _make_tool(name: str, min_safety: SafetyLevel = SafetyLevel.UNRESTRICTED):
    tool = MagicMock()
    tool.name = name
    tool.min_safety_level = min_safety
    tool.run = AsyncMock(return_value=ToolResult(
        status=ToolResultStatus.SUCCESS, output="ok", exit_code=0,
    ))
    return tool


@pytest.fixture
def tool_registry() -> ToolRegistry:
    return ToolRegistry()


class TestToolDispatcher:
    """Tests for ToolDispatcher dispatch logic."""

    @pytest.mark.asyncio
    async def test_dispatch_success(self, tool_registry: ToolRegistry):
        tool = _make_tool("shell.execute")
        tool_registry.register(tool)
        dispatcher = ToolDispatcher(tool_registry)
        call = ToolCall(name="shell.execute", parameters={"command": "echo hi"})

        result = await dispatcher.dispatch(call)
        assert result.status == ToolResultStatus.SUCCESS
        tool.run.assert_awaited_once_with(command="echo hi")

    @pytest.mark.asyncio
    async def test_dispatch_unknown_tool(self, tool_registry: ToolRegistry):
        dispatcher = ToolDispatcher(tool_registry)
        call = ToolCall(name="nonexistent", parameters={})
        result = await dispatcher.dispatch(call)
        assert result.status == ToolResultStatus.ERROR
        assert "Unknown tool" in (result.error or "")

    @pytest.mark.asyncio
    async def test_dispatch_safety_blocked(self, tool_registry: ToolRegistry):
        tool = _make_tool("dangerous.tool", min_safety=SafetyLevel.REVIEW)
        tool_registry.register(tool)
        dispatcher = ToolDispatcher(tool_registry, safety_level=SafetyLevel.STANDARD)
        call = ToolCall(name="dangerous.tool", parameters={})
        result = await dispatcher.dispatch(call)
        assert result.status == ToolResultStatus.BLOCKED
        assert "safety level" in (result.error or "").lower()

    @pytest.mark.asyncio
    async def test_dispatch_many(self, tool_registry: ToolRegistry):
        tool = _make_tool("t1")
        tool_registry.register(tool)
        dispatcher = ToolDispatcher(tool_registry)
        calls = [
            ToolCall(name="t1", parameters={"a": 1}),
            ToolCall(name="t1", parameters={"a": 2}),
        ]
        results = await dispatcher.dispatch_many(calls)
        assert len(results) == 2
        assert all(r.status == ToolResultStatus.SUCCESS for r in results)

    @pytest.mark.asyncio
    async def test_dispatch_parallel(self, tool_registry: ToolRegistry):
        tool = _make_tool("t1")
        tool_registry.register(tool)
        dispatcher = ToolDispatcher(tool_registry)
        calls = [ToolCall(name="t1", parameters={"i": i}) for i in range(5)]
        results = await dispatcher.dispatch_parallel(calls, max_concurrency=3)
        assert len(results) == 5

    def test_call_history(self, tool_registry: ToolRegistry):
        dispatcher = ToolDispatcher(tool_registry)
        assert dispatcher.call_history == []

    @pytest.mark.asyncio
    async def test_call_history_recorded(self, tool_registry: ToolRegistry):
        tool = _make_tool("t1")
        tool_registry.register(tool)
        dispatcher = ToolDispatcher(tool_registry)
        await dispatcher.dispatch(ToolCall(name="t1", parameters={}))
        assert len(dispatcher.call_history) == 1
        assert dispatcher.call_history[0]["tool"] == "t1"

    def test_reset_history(self, tool_registry: ToolRegistry):
        dispatcher = ToolDispatcher(tool_registry)
        dispatcher._call_history = [{"tool": "x"}]
        dispatcher.reset_history()
        assert dispatcher.call_history == []
