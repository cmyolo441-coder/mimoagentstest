"""Tests for terminal_agent.tools.search.regex_search.RegexSearchTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.search.regex_search import RegexSearchTool


class TestRegexSearchTool:
    """Tests for RegexSearchTool."""

    @pytest.fixture
    def tool(self):
        return RegexSearchTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "regex_search"
        assert defn.category == "search"

    def test_parameters_in_definition(self, tool):
        defn = tool.definition()
        param_names = [p.name for p in defn.parameters]
        assert "pattern" in param_names
        assert "ignore_case" in param_names
        assert "multiline" in param_names
        assert "max_results" in param_names
