"""Tests for terminal_agent.tools.search.semantic_search.SemanticSearchTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.search.semantic_search import SemanticSearchTool


class TestSemanticSearchTool:
    """Tests for SemanticSearchTool."""

    @pytest.fixture
    def tool(self):
        return SemanticSearchTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "semantic_search"
        assert defn.category == "search"

    def test_parameters_in_definition(self, tool):
        defn = tool.definition()
        param_names = [p.name for p in defn.parameters]
        assert "query" in param_names
        assert "min_score" in param_names
        assert "chunk_size" in param_names
