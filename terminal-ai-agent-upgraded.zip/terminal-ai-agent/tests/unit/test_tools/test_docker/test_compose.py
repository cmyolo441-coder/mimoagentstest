"""Tests for terminal_agent.tools.docker.compose.DockerComposeTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.docker.compose import DockerComposeTool
from terminal_agent.types import ToolResultStatus


class TestDockerComposeTool:
    """Tests for DockerComposeTool."""

    @pytest.fixture
    def tool(self):
        return DockerComposeTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "docker_compose"
        assert defn.category == "docker"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "up" in action_param.enum
        assert "down" in action_param.enum
        assert "logs" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown")
        assert result.status == ToolResultStatus.FAILURE
