"""Tests for terminal_agent.tools.docker.containers.DockerContainerTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.docker.containers import DockerContainerTool
from terminal_agent.types import ToolResultStatus


class TestDockerContainerTool:
    """Tests for DockerContainerTool."""

    @pytest.fixture
    def tool(self):
        return DockerContainerTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "docker_container"
        assert defn.category == "docker"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "run" in action_param.enum
        assert "list" in action_param.enum
        assert "stop" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown")
        assert result.status == ToolResultStatus.FAILURE
