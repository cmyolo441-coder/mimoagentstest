"""Tests for terminal_agent.tools.docker.images.DockerImageTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.docker.images import DockerImageTool
from terminal_agent.types import ToolResultStatus


class TestDockerImageTool:
    """Tests for DockerImageTool."""

    @pytest.fixture
    def tool(self):
        return DockerImageTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "docker_image"
        assert defn.category == "docker"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "build" in action_param.enum
        assert "list" in action_param.enum
        assert "pull" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown")
        assert result.status == ToolResultStatus.FAILURE
