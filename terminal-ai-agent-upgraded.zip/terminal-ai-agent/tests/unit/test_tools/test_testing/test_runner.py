"""Tests for terminal_agent.tools.testing.runner.TestRunnerTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.testing.runner import TestRunnerTool, _detect_framework
from terminal_agent.types import ToolResultStatus


class TestTestRunnerTool:
    """Tests for TestRunnerTool."""

    @pytest.fixture
    def tool(self):
        return TestRunnerTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "test_runner"
        assert defn.category == "testing"

    def test_detect_framework_pytest(self, tmp_path):
        (tmp_path / "conftest.py").write_text("")
        fw = _detect_framework(str(tmp_path))
        assert fw == "pytest"

    def test_detect_framework_jest(self, tmp_path):
        (tmp_path / "jest.config.js").write_text("")
        fw = _detect_framework(str(tmp_path))
        assert fw == "jest"

    def test_detect_framework_cargo(self, tmp_path):
        (tmp_path / "Cargo.toml").write_text("")
        fw = _detect_framework(str(tmp_path))
        assert fw == "cargo test"

    def test_detect_framework_none(self, tmp_path):
        empty = tmp_path / "empty"
        empty.mkdir()
        fw = _detect_framework(str(empty))
        assert fw is None
