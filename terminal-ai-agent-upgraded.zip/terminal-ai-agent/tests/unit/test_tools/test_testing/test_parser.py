"""Tests for terminal_agent.tools.testing.parser.TestParserTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.testing.parser import TestParserTool
from terminal_agent.types import ToolResultStatus


class TestTestParserTool:
    """Tests for TestParserTool."""

    @pytest.fixture
    def tool(self):
        return TestParserTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "test_parser"
        assert defn.category == "testing"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "parse" in action_param.enum
        assert "summary" in action_param.enum

    @pytest.mark.asyncio
    async def test_parse_pytest_output(self, tool):
        output = "=== 5 passed, 1 failed in 2.3s ==="
        result = await tool.execute(action="parse", output=output, framework="pytest")
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_summary_action(self, tool):
        output = "=== 3 passed in 1.0s ==="
        result = await tool.execute(action="summary", output=output)
        assert result.status == ToolResultStatus.SUCCESS
