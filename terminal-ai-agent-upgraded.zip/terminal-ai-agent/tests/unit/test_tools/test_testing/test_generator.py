"""Tests for terminal_agent.tools.testing.generator.TestGeneratorTool."""

from __future__ import annotations

import pytest

from terminal_agent.tools.testing.generator import TestGeneratorTool
from terminal_agent.types import ToolResultStatus


class TestTestGeneratorTool:
    """Tests for TestGeneratorTool."""

    @pytest.fixture
    def tool(self):
        return TestGeneratorTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "test_generator"
        assert defn.category == "testing"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "generate" in action_param.enum
        assert "suggest" in action_param.enum
        assert "scaffold" in action_param.enum

    def test_detect_lang(self, tool):
        assert tool._detect_lang("test.py") == "python"
        assert tool._detect_lang("test.js") == "javascript"
        assert tool._detect_lang("test.ts") == "typescript"
        assert tool._detect_lang("test.go") == "go"
        assert tool._detect_lang("test.rs") == "rust"
        assert tool._detect_lang("test.java") == "java"
        assert tool._detect_lang("test.rb") == "ruby"
        assert tool._detect_lang("test.xyz") is None

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown", source_file="test.py")
        assert result.status == ToolResultStatus.FAILURE
