"""Tests for terminal_agent.tools.git.staging.GitStagingTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.git.staging import GitStagingTool
from terminal_agent.types import ToolResultStatus


class TestGitStagingTool:
    """Tests for GitStagingTool."""

    @pytest.fixture
    def tool(self):
        return GitStagingTool()

    @pytest.fixture
    def repo_dir(self, tmp_path):
        import git
        d = tmp_path / "repo"
        d.mkdir()
        repo = git.Repo.init(d)
        (d / "f.txt").write_text("content")
        repo.index.add(["f.txt"])
        repo.index.commit("initial")
        return d

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "git_staging"

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown")
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_add_no_files(self, tool, repo_dir):
        result = await tool.execute(action="add", path=str(repo_dir))
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_diff_staged_empty(self, tool, repo_dir):
        result = await tool.execute(action="diff_staged", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_clean_requires_force(self, tool, repo_dir):
        result = await tool.execute(action="clean", path=str(repo_dir), force=False)
        # Should either block or error when force is not set
        assert result.status in (ToolResultStatus.BLOCKED, ToolResultStatus.ERROR)
