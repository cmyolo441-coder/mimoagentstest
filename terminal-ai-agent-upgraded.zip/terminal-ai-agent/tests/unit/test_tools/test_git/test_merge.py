"""Tests for terminal_agent.tools.git.merge.GitMergeTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.git.merge import GitMergeTool
from terminal_agent.types import ToolResultStatus


class TestGitMergeTool:
    """Tests for GitMergeTool."""

    @pytest.fixture
    def tool(self):
        return GitMergeTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "git_merge"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "merge" in action_param.enum
        assert "abort" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown")
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_merge_no_branch(self, tool, tmp_path):
        import git
        d = tmp_path / "repo"
        d.mkdir()
        repo = git.Repo.init(d)
        (d / "f.txt").write_text("content")
        repo.index.add(["f.txt"])
        repo.index.commit("initial")
        result = await tool.execute(action="merge", path=str(d))
        assert result.status == ToolResultStatus.FAILURE
