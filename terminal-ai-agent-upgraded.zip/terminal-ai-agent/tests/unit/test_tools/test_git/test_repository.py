"""Tests for terminal_agent.tools.git.repository.GitRepositoryTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.git.repository import GitRepositoryTool
from terminal_agent.types import ToolResultStatus


def _init_repo(path):
    """Initialize a git repo with an initial commit."""
    import git
    repo = git.Repo.init(path)
    (path / "init.txt").write_text("init")
    repo.index.add(["init.txt"])
    repo.index.commit("initial commit")
    return repo


class TestGitRepositoryTool:
    """Tests for GitRepositoryTool."""

    @pytest.fixture
    def tool(self):
        return GitRepositoryTool()

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "git_repository"
        assert defn.category == "git"

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown_action")
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_init_creates_repo(self, tool, tmp_path):
        repo_dir = tmp_path / "newrepo"
        repo_dir.mkdir()
        result = await tool.execute(action="init", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS
        assert (repo_dir / ".git").exists()

    @pytest.mark.asyncio
    async def test_init_already_repo(self, tool, tmp_path):
        repo_dir = tmp_path / "existing"
        repo_dir.mkdir()
        _init_repo(repo_dir)
        result = await tool.execute(action="init", path=str(repo_dir))
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_status_on_clean_repo(self, tool, tmp_path):
        repo_dir = tmp_path / "clean"
        repo_dir.mkdir()
        _init_repo(repo_dir)
        result = await tool.execute(action="status", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_current_branch(self, tool, tmp_path):
        repo_dir = tmp_path / "branch_repo"
        repo_dir.mkdir()
        _init_repo(repo_dir)
        result = await tool.execute(action="current_branch", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_is_dirty(self, tool, tmp_path):
        repo_dir = tmp_path / "dirty_repo"
        repo_dir.mkdir()
        _init_repo(repo_dir)
        result = await tool.execute(action="is_dirty", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_info(self, tool, tmp_path):
        repo_dir = tmp_path / "info_repo"
        repo_dir.mkdir()
        _init_repo(repo_dir)
        result = await tool.execute(action="info", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS
