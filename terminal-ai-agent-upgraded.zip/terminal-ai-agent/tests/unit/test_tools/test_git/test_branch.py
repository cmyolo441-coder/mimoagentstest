"""Tests for terminal_agent.tools.git.branch.GitBranchTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.git.branch import GitBranchTool
from terminal_agent.types import ToolResultStatus


class TestGitBranchTool:
    """Tests for GitBranchTool."""

    @pytest.fixture
    def tool(self):
        return GitBranchTool()

    @pytest.fixture
    def repo_dir(self, tmp_path):
        import git
        d = tmp_path / "repo"
        d.mkdir()
        repo = git.Repo.init(d)
        (d / "f.txt").write_text("content")
        repo.index.add(["f.txt"])
        repo.index.commit("initial")
        return d

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "git_branch"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "create" in action_param.enum
        assert "list" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown")
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_create_branch(self, tool, repo_dir):
        result = await tool.execute(action="create", name="feature", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS
        assert "feature" in result.output

    @pytest.mark.asyncio
    async def test_create_branch_no_name(self, tool, repo_dir):
        result = await tool.execute(action="create", path=str(repo_dir))
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_list_branches(self, tool, repo_dir):
        result = await tool.execute(action="list", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_rename_branch(self, tool, repo_dir):
        result = await tool.execute(action="rename", new_name="renamed", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_rename_no_name(self, tool, repo_dir):
        result = await tool.execute(action="rename", path=str(repo_dir))
        assert result.status == ToolResultStatus.FAILURE
