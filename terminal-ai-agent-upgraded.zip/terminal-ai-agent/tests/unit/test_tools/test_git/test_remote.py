"""Tests for terminal_agent.tools.git.remote.GitRemoteTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.git.remote import GitRemoteTool
from terminal_agent.types import ToolResultStatus


class TestGitRemoteTool:
    """Tests for GitRemoteTool."""

    @pytest.fixture
    def tool(self):
        return GitRemoteTool()

    @pytest.fixture
    def repo_dir(self, tmp_path):
        import git
        d = tmp_path / "repo"
        d.mkdir()
        repo = git.Repo.init(d)
        (d / "f.txt").write_text("content")
        repo.index.add(["f.txt"])
        repo.index.commit("initial")
        return d

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "git_remote"
        action_param = next(p for p in defn.parameters if p.name == "action")
        assert "push" in action_param.enum
        assert "list" in action_param.enum

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown")
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_list_empty(self, tool, repo_dir):
        result = await tool.execute(action="list", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_add_remote(self, tool, repo_dir):
        result = await tool.execute(
            action="add", remote="origin",
            url="https://example.com/repo.git", path=str(repo_dir),
        )
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_add_remote_no_url(self, tool, repo_dir):
        result = await tool.execute(action="add", remote="origin", path=str(repo_dir))
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_remove_remote(self, tool, repo_dir):
        import git
        repo = git.Repo(repo_dir)
        repo.create_remote("origin", "https://example.com/repo.git")
        result = await tool.execute(action="remove", remote="origin", path=str(repo_dir))
        assert result.status == ToolResultStatus.SUCCESS
