"""Tests for terminal_agent.tools.git.commit.GitCommitTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.git.commit import GitCommitTool
from terminal_agent.types import ToolResultStatus


class TestGitCommitTool:
    """Tests for GitCommitTool."""

    @pytest.fixture
    def tool(self):
        return GitCommitTool()

    @pytest.fixture
    def repo_dir(self, tmp_path):
        import git
        d = tmp_path / "repo"
        d.mkdir()
        repo = git.Repo.init(d)
        (d / "f.txt").write_text("content")
        repo.index.add(["f.txt"])
        repo.index.commit("initial")
        return d

    def test_definition(self, tool):
        defn = tool.definition()
        assert defn.name == "git_commit"

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool):
        result = await tool.execute(action="unknown")
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_commit_requires_message(self, tool, repo_dir):
        result = await tool.execute(action="commit", path=str(repo_dir))
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_commit_with_files(self, tool, repo_dir):
        (repo_dir / "new.txt").write_text("new content")
        result = await tool.execute(
            action="commit", message="test commit",
            files=["new.txt"], path=str(repo_dir),
        )
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_squash_count_too_low(self, tool, repo_dir):
        result = await tool.execute(action="squash", count=1, path=str(repo_dir))
        assert result.status == ToolResultStatus.FAILURE
