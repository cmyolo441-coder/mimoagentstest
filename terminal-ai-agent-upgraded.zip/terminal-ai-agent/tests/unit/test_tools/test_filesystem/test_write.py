"""Tests for terminal_agent.tools.filesystem.write.WriteTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.filesystem.write import WriteTool
from terminal_agent.types import ToolResultStatus


class TestWriteTool:
    """Tests for WriteTool."""

    @pytest.fixture
    def tool(self):
        return WriteTool()

    @pytest.mark.asyncio
    async def test_write_new_file(self, tool, tmp_path):
        f = tmp_path / "new.txt"
        result = await tool.execute(path=str(f), content="hello", backup=False)
        assert result.status == ToolResultStatus.SUCCESS
        assert f.read_text() == "hello"

    @pytest.mark.asyncio
    async def test_write_creates_dirs(self, tool, tmp_path):
        f = tmp_path / "a" / "b" / "c.txt"
        result = await tool.execute(path=str(f), content="nested", backup=False)
        assert result.status == ToolResultStatus.SUCCESS
        assert f.read_text() == "nested"

    @pytest.mark.asyncio
    async def test_write_append(self, tool, tmp_path):
        f = tmp_path / "append.txt"
        f.write_text("first\n")
        result = await tool.execute(path=str(f), content="second\n", mode="append", backup=False)
        assert result.status == ToolResultStatus.SUCCESS
        assert "first" in f.read_text()
        assert "second" in f.read_text()

    @pytest.mark.asyncio
    async def test_write_crlf(self, tool, tmp_path):
        f = tmp_path / "crlf.txt"
        result = await tool.execute(path=str(f), content="a\nb", newline="crlf", backup=False)
        raw = f.read_bytes()
        assert b"\r\n" in raw

    @pytest.mark.asyncio
    async def test_write_overwrite(self, tool, tmp_path):
        f = tmp_path / "overwrite.txt"
        f.write_text("old")
        result = await tool.execute(path=str(f), content="new", mode="overwrite", backup=False)
        assert f.read_text() == "new"

    @pytest.mark.asyncio
    async def test_write_with_backup(self, tool, tmp_path):
        f = tmp_path / "backup.txt"
        f.write_text("original")
        result = await tool.execute(path=str(f), content="changed", backup=True)
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_write_executable(self, tool, tmp_path):
        f = tmp_path / "script.sh"
        result = await tool.execute(path=str(f), content="#!/bin/bash\necho hi", make_executable=True, backup=False)
        assert result.status == ToolResultStatus.SUCCESS
        import stat
        assert f.stat().st_mode & stat.S_IXUSR

    def test_metadata(self, tool):
        assert tool.name == "filesystem.write"
        assert tool.category == "filesystem"
