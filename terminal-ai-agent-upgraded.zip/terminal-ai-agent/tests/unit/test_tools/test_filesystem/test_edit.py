"""Tests for terminal_agent.tools.filesystem.edit.EditTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.filesystem.edit import EditTool
from terminal_agent.types import ToolResultStatus


class TestEditTool:
    """Tests for EditTool."""

    @pytest.fixture
    def tool(self):
        return EditTool()

    @pytest.fixture
    def sample_file(self, tmp_path):
        f = tmp_path / "edit.txt"
        f.write_text("line1\nline2\nline3\nline4\nline5\n")
        return f

    @pytest.mark.asyncio
    async def test_replace_lines(self, tool, sample_file):
        result = await tool.execute(
            path=str(sample_file), action="replace_lines",
            start_line=2, end_line=3, content="new_line2\nnew_line3", backup=False,
        )
        assert result.status == ToolResultStatus.SUCCESS
        content = sample_file.read_text()
        assert "new_line2" in content
        assert "new_line3" in content

    @pytest.mark.asyncio
    async def test_insert(self, tool, sample_file):
        result = await tool.execute(
            path=str(sample_file), action="insert",
            start_line=3, content="inserted", backup=False,
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert "inserted" in sample_file.read_text()

    @pytest.mark.asyncio
    async def test_delete_lines(self, tool, sample_file):
        result = await tool.execute(
            path=str(sample_file), action="delete_lines",
            start_line=2, end_line=3, backup=False,
        )
        assert result.status == ToolResultStatus.SUCCESS
        content = sample_file.read_text()
        assert "line2" not in content
        assert "line3" not in content

    @pytest.mark.asyncio
    async def test_search_replace(self, tool, sample_file):
        result = await tool.execute(
            path=str(sample_file), action="search_replace",
            search="line2", replace="LINE2", backup=False,
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert "LINE2" in sample_file.read_text()

    @pytest.mark.asyncio
    async def test_search_replace_regex(self, tool, sample_file):
        result = await tool.execute(
            path=str(sample_file), action="search_replace",
            search=r"line(\d)", replace=r"LINE\1", use_regex=True, backup=False,
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert "LINE1" in sample_file.read_text()

    @pytest.mark.asyncio
    async def test_search_replace_not_found(self, tool, sample_file):
        result = await tool.execute(
            path=str(sample_file), action="search_replace",
            search="nonexistent_xyz", replace="repl", backup=False,
        )
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_edit_nonexistent(self, tool):
        result = await tool.execute(
            path="/nonexistent/file.txt", action="search_replace",
            search="a", replace="b",
        )
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_unknown_action(self, tool, sample_file):
        result = await tool.execute(
            path=str(sample_file), action="invalid_action",
        )
        assert result.status == ToolResultStatus.ERROR

    def test_metadata(self, tool):
        assert tool.name == "filesystem.edit"
        assert tool.category == "filesystem"
