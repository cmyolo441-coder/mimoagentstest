"""Tests for terminal_agent.tools.filesystem.read.ReadTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.filesystem.read import ReadTool
from terminal_agent.types import ToolResultStatus


class TestReadTool:
    """Tests for ReadTool."""

    @pytest.fixture
    def tool(self):
        return ReadTool()

    @pytest.mark.asyncio
    async def test_read_simple_file(self, tool, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello world\n")
        result = await tool.execute(path=str(f))
        assert result.status == ToolResultStatus.SUCCESS
        assert "hello world" in result.output

    @pytest.mark.asyncio
    async def test_read_with_offset(self, tool, tmp_path):
        f = tmp_path / "lines.txt"
        f.write_text("line1\nline2\nline3\nline4\n")
        result = await tool.execute(path=str(f), offset=3)
        assert "line3" in result.output
        assert "line4" in result.output

    @pytest.mark.asyncio
    async def test_read_with_limit(self, tool, tmp_path):
        f = tmp_path / "lines.txt"
        f.write_text("line1\nline2\nline3\nline4\n")
        result = await tool.execute(path=str(f), limit=2)
        assert "line1" in result.output
        assert "line2" in result.output

    @pytest.mark.asyncio
    async def test_read_nonexistent(self, tool):
        result = await tool.execute(path="/nonexistent/file.txt")
        assert result.status == ToolResultStatus.FAILURE
        assert "not found" in result.error.lower()

    @pytest.mark.asyncio
    async def test_read_directory(self, tool, tmp_path):
        result = await tool.execute(path=str(tmp_path))
        assert result.status == ToolResultStatus.FAILURE
        assert "not a file" in result.error.lower()

    @pytest.mark.asyncio
    async def test_read_tail(self, tool, tmp_path):
        f = tmp_path / "tail.txt"
        f.write_text("a\nb\nc\nd\ne\n")
        result = await tool.execute(path=str(f), tail=2)
        assert "d" in result.output
        assert "e" in result.output

    @pytest.mark.asyncio
    async def test_read_binary(self, tool, tmp_path):
        f = tmp_path / "bin.dat"
        f.write_bytes(b"\x00\x01\x02\x03")
        result = await tool.execute(path=str(f), binary=True)
        assert result.status == ToolResultStatus.SUCCESS
        assert "00" in result.output

    def test_metadata(self, tool):
        assert tool.name == "filesystem.read"
        assert tool.category == "filesystem"

    def test_detect_encoding_utf8(self, tmp_path):
        f = tmp_path / "utf8.txt"
        f.write_text("hello", encoding="utf-8")
        enc = ReadTool._detect_encoding(f)
        assert enc == "utf-8"

    def test_detect_encoding_bom(self, tmp_path):
        f = tmp_path / "bom.txt"
        f.write_bytes(b"\xef\xbb\xbfhello")
        enc = ReadTool._detect_encoding(f)
        assert enc == "utf-8-sig"
