"""Tests for terminal_agent.tools.filesystem.search.SearchTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.filesystem.search import SearchTool
from terminal_agent.types import ToolResultStatus


class TestSearchTool:
    """Tests for SearchTool."""

    @pytest.fixture
    def tool(self):
        return SearchTool()

    @pytest.fixture
    def search_dir(self, tmp_path):
        (tmp_path / "a.py").write_text("def hello():\n    pass\n")
        (tmp_path / "b.py").write_text("def world():\n    pass\n")
        (tmp_path / "c.txt").write_text("hello world\n")
        (tmp_path / "sub").mkdir()
        (tmp_path / "sub" / "d.py").write_text("import os\n")
        return tmp_path

    @pytest.mark.asyncio
    async def test_content_search(self, tool, search_dir):
        result = await tool.execute(
            pattern="def ", path=str(search_dir), file_pattern="*.py",
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert "hello" in result.output or "world" in result.output

    @pytest.mark.asyncio
    async def test_filename_search(self, tool, search_dir):
        result = await tool.execute(
            pattern="\\.py$", search_type="filename", path=str(search_dir),
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert ".py" in result.output

    @pytest.mark.asyncio
    async def test_case_insensitive(self, tool, search_dir):
        (search_dir / "upper.py").write_text("HELLO WORLD\n")
        result = await tool.execute(
            pattern="hello world", path=str(search_dir), case_sensitive=False,
        )
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_no_matches(self, tool, search_dir):
        result = await tool.execute(
            pattern="zzzznonexistent", path=str(search_dir),
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert "no matches" in result.output.lower()

    @pytest.mark.asyncio
    async def test_max_results(self, tool, search_dir):
        for i in range(10):
            (search_dir / f"f{i}.py").write_text("match_target\n")
        result = await tool.execute(
            pattern="match_target", path=str(search_dir), max_results=3,
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert result.metadata.get("match_count", 0) <= 3

    @pytest.mark.asyncio
    async def test_invalid_regex(self, tool, search_dir):
        result = await tool.execute(
            pattern="[invalid", path=str(search_dir), use_regex=True,
        )
        assert result.status == ToolResultStatus.ERROR

    def test_metadata(self, tool):
        assert tool.name == "filesystem.search"
        assert tool.category == "filesystem"
