"""Tests for terminal_agent.tools.filesystem.delete.DeleteTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.filesystem.delete import DeleteTool
from terminal_agent.types import ToolResultStatus


class TestDeleteTool:
    """Tests for DeleteTool."""

    @pytest.fixture
    def tool(self):
        return DeleteTool()

    @pytest.mark.asyncio
    async def test_delete_file(self, tool, tmp_path):
        f = tmp_path / "del.txt"
        f.write_text("delete me")
        result = await tool.execute(path=str(f), backup=False)
        assert result.status == ToolResultStatus.SUCCESS
        assert not f.exists()

    @pytest.mark.asyncio
    async def test_delete_nonexistent_force(self, tool, tmp_path):
        result = await tool.execute(
            path=str(tmp_path / "nope.txt"), force=True, backup=False,
        )
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_delete_nonexistent_no_force(self, tool, tmp_path):
        result = await tool.execute(
            path=str(tmp_path / "nope.txt"), force=False, backup=False,
        )
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_delete_directory_recursive(self, tool, tmp_path):
        d = tmp_path / "dir"
        d.mkdir()
        (d / "f.txt").write_text("inside")
        result = await tool.execute(path=str(d), recursive=True, backup=False)
        assert result.status == ToolResultStatus.SUCCESS
        assert not d.exists()

    @pytest.mark.asyncio
    async def test_delete_directory_no_recursive(self, tool, tmp_path):
        d = tmp_path / "dir"
        d.mkdir()
        result = await tool.execute(path=str(d), recursive=False, backup=False)
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_delete_critical_path_blocked(self, tool):
        result = await tool.execute(path="/", backup=False)
        assert result.status == ToolResultStatus.BLOCKED

    @pytest.mark.asyncio
    async def test_delete_with_backup(self, tool, tmp_path):
        f = tmp_path / "backup_me.txt"
        f.write_text("important")
        result = await tool.execute(path=str(f), backup=True)
        assert result.status == ToolResultStatus.SUCCESS

    def test_metadata(self, tool):
        assert tool.name == "filesystem.delete"
        assert tool.category == "filesystem"
        assert tool.requires_confirmation is True
