"""Tests for terminal_agent.tools.filesystem.move.MoveTool."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.filesystem.move import MoveTool
from terminal_agent.types import ToolResultStatus


class TestMoveTool:
    """Tests for MoveTool."""

    @pytest.fixture
    def tool(self):
        return MoveTool()

    @pytest.mark.asyncio
    async def test_move_file(self, tool, tmp_path):
        src = tmp_path / "src.txt"
        src.write_text("content")
        dst = tmp_path / "dst.txt"
        result = await tool.execute(source=str(src), destination=str(dst))
        assert result.status == ToolResultStatus.SUCCESS
        assert not src.exists()
        assert dst.exists()
        assert dst.read_text() == "content"

    @pytest.mark.asyncio
    async def test_move_nonexistent(self, tool, tmp_path):
        result = await tool.execute(
            source=str(tmp_path / "nope.txt"),
            destination=str(tmp_path / "dst.txt"),
        )
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_move_overwrite_false(self, tool, tmp_path):
        src = tmp_path / "src.txt"
        src.write_text("new")
        dst = tmp_path / "dst.txt"
        dst.write_text("old")
        result = await tool.execute(
            source=str(src), destination=str(dst), overwrite=False,
        )
        assert result.status == ToolResultStatus.FAILURE

    @pytest.mark.asyncio
    async def test_move_overwrite_true(self, tool, tmp_path):
        src = tmp_path / "src.txt"
        src.write_text("new")
        dst = tmp_path / "dst.txt"
        dst.write_text("old")
        result = await tool.execute(
            source=str(src), destination=str(dst), overwrite=True,
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert dst.read_text() == "new"

    @pytest.mark.asyncio
    async def test_move_creates_dirs(self, tool, tmp_path):
        src = tmp_path / "src.txt"
        src.write_text("data")
        dst = tmp_path / "a" / "b" / "dst.txt"
        result = await tool.execute(source=str(src), destination=str(dst))
        assert result.status == ToolResultStatus.SUCCESS
        assert dst.exists()

    @pytest.mark.asyncio
    async def test_move_directory(self, tool, tmp_path):
        src_dir = tmp_path / "srcdir"
        src_dir.mkdir()
        (src_dir / "f.txt").write_text("in dir")
        dst_dir = tmp_path / "dstdir"
        result = await tool.execute(source=str(src_dir), destination=str(dst_dir))
        assert result.status == ToolResultStatus.SUCCESS
        assert dst_dir.exists()

    def test_metadata(self, tool):
        assert tool.name == "filesystem.move"
        assert tool.category == "filesystem"
