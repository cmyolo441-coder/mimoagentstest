"""Tests for terminal_agent.tools.registry.ToolRegistry."""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.base_tool import BaseTool, ToolDefinition, SafetyRequirement
from terminal_agent.types import SafetyLevel, ToolResult, ToolResultStatus


@pytest.fixture
def tool_registry() -> ToolRegistry:
    return ToolRegistry()


def _make_tool(name: str, category: str = "test", safety: SafetyRequirement = SafetyRequirement.NONE):
    """Create a minimal mock tool."""
    tool = MagicMock()
    tool.name = name
    tool.category = category
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": name, "description": f"Tool {name}"}
    return tool


class TestToolRegistry:
    """Tests for ToolRegistry registration and lookup."""

    def test_register_and_get(self, tool_registry: ToolRegistry):
        tool = _make_tool("test.tool")
        tool_registry.register(tool)
        assert tool_registry.get("test.tool") is tool

    def test_register_duplicate_raises(self, tool_registry: ToolRegistry):
        tool = _make_tool("test.tool")
        tool_registry.register(tool)
        with pytest.raises(ValueError, match="already registered"):
            tool_registry.register(tool)

    def test_get_missing_returns_none(self, tool_registry: ToolRegistry):
        assert tool_registry.get("nonexistent") is None

    def test_get_required_raises_on_missing(self, tool_registry: ToolRegistry):
        with pytest.raises(KeyError, match="not found"):
            tool_registry.get_required("nonexistent")

    def test_get_required_returns_tool(self, tool_registry: ToolRegistry):
        tool = _make_tool("test.tool")
        tool_registry.register(tool)
        assert tool_registry.get_required("test.tool") is tool

    def test_has(self, tool_registry: ToolRegistry):
        tool = _make_tool("test.tool")
        tool_registry.register(tool)
        assert tool_registry.has("test.tool") is True
        assert tool_registry.has("other.tool") is False

    def test_unregister(self, tool_registry: ToolRegistry):
        tool = _make_tool("test.tool")
        tool_registry.register(tool)
        tool_registry.unregister("test.tool")
        assert tool_registry.get("test.tool") is None
        assert tool_registry.count() == 0

    def test_unregister_nonexistent_is_noop(self, tool_registry: ToolRegistry):
        tool_registry.unregister("nonexistent")  # Should not raise

    def test_list_tools_sorted(self, tool_registry: ToolRegistry):
        tool_registry.register(_make_tool("b.tool"))
        tool_registry.register(_make_tool("a.tool"))
        tool_registry.register(_make_tool("c.tool"))
        assert tool_registry.list_tools() == ["a.tool", "b.tool", "c.tool"]

    def test_list_categories(self, tool_registry: ToolRegistry):
        tool_registry.register(_make_tool("t1", category="alpha"))
        tool_registry.register(_make_tool("t2", category="beta"))
        tool_registry.register(_make_tool("t3", category="alpha"))
        cats = tool_registry.list_categories()
        assert cats == ["alpha", "beta"]

    def test_get_tools_by_category(self, tool_registry: ToolRegistry):
        t1 = _make_tool("t1", category="shell")
        t2 = _make_tool("t2", category="fs")
        t3 = _make_tool("t3", category="shell")
        tool_registry.register(t1)
        tool_registry.register(t2)
        tool_registry.register(t3)
        shell_tools = tool_registry.get_tools_by_category("shell")
        assert len(shell_tools) == 2
        assert t1 in shell_tools and t3 in shell_tools

    def test_get_tools_by_category_empty(self, tool_registry: ToolRegistry):
        assert tool_registry.get_tools_by_category("nonexistent") == []

    def test_count(self, tool_registry: ToolRegistry):
        assert tool_registry.count() == 0
        tool_registry.register(_make_tool("t1"))
        assert tool_registry.count() == 1
        tool_registry.register(_make_tool("t2"))
        assert tool_registry.count() == 2

    def test_len(self, tool_registry: ToolRegistry):
        assert len(tool_registry) == 0
        tool_registry.register(_make_tool("t1"))
        assert len(tool_registry) == 1

    def test_contains(self, tool_registry: ToolRegistry):
        tool_registry.register(_make_tool("t1"))
        assert "t1" in tool_registry
        assert "t2" not in tool_registry

    def test_repr(self, tool_registry: ToolRegistry):
        tool_registry.register(_make_tool("t1"))
        r = repr(tool_registry)
        assert "ToolRegistry" in r
        assert "1" in r

    def test_get_schemas(self, tool_registry: ToolRegistry):
        t1 = _make_tool("t1")
        t1.get_schema.return_value = {"name": "t1"}
        tool_registry.register(t1)
        schemas = tool_registry.get_schemas()
        assert len(schemas) == 1
        assert schemas[0] == {"name": "t1"}

    def test_unregister_cleans_categories(self, tool_registry: ToolRegistry):
        tool = _make_tool("t1", category="only_one")
        tool_registry.register(tool)
        assert "only_one" in tool_registry.list_categories()
        tool_registry.unregister("t1")
        assert "only_one" not in tool_registry.list_categories()

    def test_discover_package_not_found(self, tool_registry: ToolRegistry):
        count = tool_registry.discover("nonexistent_package_xyz_12345")
        assert count == 0
