"""Tests for terminal_agent.tools.code.formatter.CodeFormatter."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.code.formatter import CodeFormatter, FormatResult


class TestCodeFormatter:
    """Tests for CodeFormatter."""

    @pytest.fixture
    def formatter(self):
        return CodeFormatter()

    def test_format_source_builtin(self, formatter):
        source = "hello  \nworld  \n"
        result = formatter.format_source(source, language="python")
        assert result.success is True
        assert result.formatter == "builtin"
        # Trailing whitespace should be stripped
        for line in result.formatted.splitlines():
            assert line == line.rstrip()

    def test_format_source_no_change(self, formatter):
        source = "hello\nworld\n"
        result = formatter.format_source(source, language="python")
        assert result.success is True
        assert result.changed is False

    def test_format_file(self, formatter, tmp_path):
        f = tmp_path / "test.py"
        f.write_text("hello  \nworld  \n")
        result = formatter.format_file(f, in_place=False)
        assert result.success is True
        # File should NOT be modified with in_place=False
        assert "hello  " in f.read_text()

    def test_format_file_in_place(self, formatter, tmp_path):
        f = tmp_path / "test.py"
        f.write_text("hello  \nworld  \n")
        result = formatter.format_file(f, in_place=True)
        assert result.success is True
        # File should be modified
        content = f.read_text()
        for line in content.splitlines():
            assert line == line.rstrip()

    def test_format_result_diff(self):
        result = FormatResult(
            success=True, changed=True,
            original="old\n", formatted="new\n", file_path="test.py",
        )
        diff = result.diff
        assert "old" in diff or "new" in diff

    def test_format_result_no_changes_diff(self):
        result = FormatResult(success=True, changed=False)
        assert result.diff == "(no changes)"

    def test_format_result_summary(self):
        result = FormatResult(success=True, changed=True, formatter="builtin", file_path="test.py")
        summary = result.summary()
        assert "formatted" in summary

    def test_check_file(self, formatter, tmp_path):
        f = tmp_path / "clean.py"
        f.write_text("clean code\n")
        assert formatter.check_file(f) is True

    def test_available_formatters(self, formatter):
        available = formatter.available_formatters()
        assert isinstance(available, dict)
        # 'builtin' is always available through fallback
