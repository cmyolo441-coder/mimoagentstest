"""Unit tests for code tools."""
