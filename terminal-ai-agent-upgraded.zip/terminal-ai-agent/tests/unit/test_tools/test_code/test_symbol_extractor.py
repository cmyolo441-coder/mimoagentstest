"""Tests for terminal_agent.tools.code.symbol_extractor."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.code.symbol_extractor import SymbolExtractor, Symbol


class TestSymbolExtractor:
    """Tests for SymbolExtractor."""

    @pytest.fixture
    def extractor(self):
        return SymbolExtractor()

    def test_extract_from_source(self, extractor):
        source = "def hello():\n    pass\n\nclass Foo:\n    pass\n"
        symbols = extractor.extract_from_source(source, language="python")
        assert len(symbols) >= 2
        names = [s.name for s in symbols]
        assert "hello" in names
        assert "Foo" in names

    def test_extract_from_file(self, extractor, sample_python_file):
        symbols = extractor.extract_from_file(sample_python_file)
        assert len(symbols) > 0
        names = [s.name for s in symbols]
        assert "ConfigManager" in names
        assert "create_client" in names

    def test_filter_by_kind(self, extractor):
        source = "def foo(): pass\nclass Bar: pass\nx = 1\n"
        symbols = extractor.extract_from_source(source, language="python")
        functions = SymbolExtractor.filter_by_kind(symbols, "function")
        assert all(s.kind == "function" for s in functions)
        classes = SymbolExtractor.filter_by_kind(symbols, "class")
        assert all(s.kind == "class" for s in classes)

    def test_find_by_name(self, extractor):
        source = "def foo(): pass\ndef bar(): pass\n"
        symbols = extractor.extract_from_source(source, language="python")
        found = SymbolExtractor.find_by_name(symbols, "foo")
        assert len(found) == 1
        assert found[0].name == "foo"

    def test_find_by_name_substring(self, extractor):
        source = "def foo_bar(): pass\ndef baz(): pass\n"
        symbols = extractor.extract_from_source(source, language="python")
        found = SymbolExtractor.find_by_name(symbols, "foo", exact=False)
        assert len(found) >= 1

    def test_group_by_file(self, extractor, sample_python_file):
        symbols = extractor.extract_from_file(sample_python_file)
        groups = SymbolExtractor.group_by_file(symbols)
        assert len(groups) >= 1
        assert all(isinstance(v, list) for v in groups.values())

    def test_group_by_kind(self, extractor):
        source = "def foo(): pass\nclass Bar: pass\n"
        symbols = extractor.extract_from_source(source, language="python")
        groups = SymbolExtractor.group_by_kind(symbols)
        assert "function" in groups or "class" in groups

    def test_symbol_qualified_name(self):
        sym = Symbol(name="method", kind="method", language="python", file_path="x.py", line=1, parent="MyClass")
        assert sym.qualified_name == "MyClass.method"

    def test_symbol_qualified_name_no_parent(self):
        sym = Symbol(name="func", kind="function", language="python", file_path="x.py", line=1)
        assert sym.qualified_name == "func"

    def test_symbol_signature(self):
        sym = Symbol(
            name="foo", kind="function", language="python",
            file_path="x.py", line=1,
            params=[{"name": "a"}, {"name": "b"}],
            return_type="str",
        )
        assert "foo(a, b) -> str" == sym.signature

    def test_symbol_to_dict(self):
        sym = Symbol(name="foo", kind="function", language="python", file_path="x.py", line=5)
        d = sym.to_dict()
        assert d["name"] == "foo"
        assert d["kind"] == "function"
        assert d["line"] == 5

    def test_get_imports(self, extractor):
        source = "import os\ndef foo(): pass\nfrom sys import argv\n"
        symbols = extractor.extract_from_source(source, language="python")
        imports = SymbolExtractor.get_imports(symbols)
        assert len(imports) >= 2

    def test_extract_from_directory(self, extractor, project_dir):
        symbols = extractor.extract_from_directory(project_dir, extensions={".py"})
        assert len(symbols) > 0
