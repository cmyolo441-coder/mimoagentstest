"""Tests for terminal_agent.tools.code.renamer.Renamer."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.code.renamer import Renamer, RenameResult, FileChange


class TestRenamer:
    """Tests for Renamer."""

    @pytest.fixture
    def renamer(self):
        return Renamer()

    def test_is_valid_identifier(self):
        assert Renamer._is_valid_identifier("foo") is True
        assert Renamer._is_valid_identifier("_bar") is True
        assert Renamer._is_valid_identifier("foo123") is True
        assert Renamer._is_valid_identifier("123foo") is False
        assert Renamer._is_valid_identifier("") is False
        assert Renamer._is_valid_identifier("foo-bar") is False

    def test_rename_same_name(self, renamer, tmp_path):
        result = renamer.rename(tmp_path, "foo", "foo")
        assert result.success is True
        assert result.total_replacements == 0

    def test_rename_invalid_new_name(self, renamer, tmp_path):
        result = renamer.rename(tmp_path, "foo", "123invalid")
        assert result.success is False
        assert any("not a valid identifier" in e for e in result.errors)

    def test_rename_no_references(self, renamer, tmp_path):
        (tmp_path / "test.py").write_text("x = 1\n")
        result = renamer.rename(tmp_path, "nonexistent", "new_name")
        assert result.success is False
        assert any("no references" in e.lower() for e in result.errors)

    def test_rename_dry_run(self, renamer, tmp_path):
        f = tmp_path / "test.py"
        f.write_text("def old_func():\n    pass\n\nold_func()\n")
        result = renamer.rename(tmp_path, "old_func", "new_func", dry_run=True)
        # File should NOT be modified on dry run
        assert "old_func" in f.read_text()

    def test_rename_result_summary(self):
        result = RenameResult(
            success=True, old_name="a", new_name="b",
            files_changed=[FileChange("f.py", "old", "new", 2)],
            total_replacements=2,
        )
        summary = result.summary()
        assert "a" in summary
        assert "b" in summary
        assert "2" in summary

    def test_rename_result_properties(self):
        fc = FileChange("test.py", "old", "new", 1)
        result = RenameResult(
            success=True, old_name="a", new_name="b",
            files_changed=[fc], total_replacements=1,
        )
        assert result.changed_files == ["test.py"]

    def test_file_change_diff(self):
        fc = FileChange("f.py", "line1\nline2\n", "line1\nLINE2\n", 1)
        diff = fc.diff
        assert "line2" in diff or "LINE2" in diff
