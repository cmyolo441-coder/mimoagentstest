"""Tests for terminal_agent.tools.code.linter.Linter."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.code.linter import Linter, LintResult, LintIssue


class TestLinter:
    """Tests for Linter."""

    @pytest.fixture
    def linter(self):
        return Linter()

    def test_lint_builtin_clean(self, linter, tmp_path):
        f = tmp_path / "clean.py"
        f.write_text("def foo():\n    return 1\n")
        result = linter.lint_builtin(f)
        assert result.success is True
        assert result.is_clean is True

    def test_lint_builtin_trailing_whitespace(self, linter, tmp_path):
        f = tmp_path / "trailing.py"
        f.write_text("hello   \n")
        result = linter.lint_builtin(f)
        assert result.success is True
        assert any(i.code == "W001" for i in result.issues)

    def test_lint_builtin_long_line(self, linter, tmp_path):
        f = tmp_path / "long.py"
        f.write_text("x = '" + "a" * 200 + "'\n")
        result = linter.lint_builtin(f)
        assert any(i.code == "W002" for i in result.issues)

    def test_lint_builtin_tab(self, linter, tmp_path):
        f = tmp_path / "tab.py"
        f.write_text("\thello\n")
        result = linter.lint_builtin(f)
        assert any(i.code == "W003" for i in result.issues)

    def test_lint_builtin_no_final_newline(self, linter, tmp_path):
        f = tmp_path / "no_newline.py"
        f.write_text("x = 1")
        result = linter.lint_builtin(f)
        assert any(i.code == "W004" for i in result.issues)

    def test_lint_python_bare_except(self, linter, tmp_path):
        f = tmp_path / "bare.py"
        f.write_text("try:\n    pass\nexcept:\n    pass\n")
        result = linter.lint_builtin(f)
        assert any(i.code == "E001" for i in result.issues)

    def test_lint_python_mutable_default(self, linter, tmp_path):
        f = tmp_path / "mutable.py"
        f.write_text("def foo(x=[]):\n    pass\n")
        result = linter.lint_builtin(f)
        assert any(i.code == "E002" for i in result.issues)

    def test_lint_source(self, linter):
        source = "x = 1\n"
        result = linter.lint_source(source, language="python")
        assert result.success is True

    def test_lint_source_no_language(self, linter):
        result = linter.lint_source("code")
        assert result.success is False

    def test_lint_result_properties(self):
        result = LintResult(
            success=True,
            issues=[
                LintIssue("f.py", 1, severity="error", message="err"),
                LintIssue("f.py", 2, severity="warning", message="warn"),
            ],
        )
        assert result.error_count == 1
        assert result.warning_count == 1
        assert result.is_clean is False

    def test_lint_result_clean(self):
        result = LintResult(success=True, issues=[])
        assert result.is_clean is True

    def test_lint_result_summary(self):
        result = LintResult(
            success=True, linter="builtin",
            issues=[LintIssue("f.py", 1, severity="error", code="E001", message="bad")],
        )
        summary = result.summary()
        assert "1 issue" in summary

    def test_lint_result_to_dict(self):
        result = LintResult(
            success=True, linter="builtin",
            issues=[LintIssue("f.py", 1, severity="warning", code="W001", message="whitespace")],
        )
        d = result.to_dict()
        assert d["issue_count"] == 1
        assert d["success"] is True

    def test_lint_issue_str(self):
        issue = LintIssue("f.py", 10, col=5, severity="error", code="E001", message="bad")
        s = str(issue)
        assert "f.py:10:5" in s
        assert "error" in s

    def test_available_linters(self, linter):
        available = linter.available_linters()
        assert isinstance(available, dict)
