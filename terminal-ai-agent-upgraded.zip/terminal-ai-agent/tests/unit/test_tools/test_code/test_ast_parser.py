"""Tests for terminal_agent.tools.code.ast_parser.ASTParser."""

from __future__ import annotations

import pytest
from pathlib import Path

from terminal_agent.tools.code.ast_parser import ASTParser, ParseResult


class TestASTParser:
    """Tests for ASTParser."""

    @pytest.fixture
    def parser(self):
        return ASTParser()

    def test_parse_python_source(self, parser):
        source = "def hello():\n    pass\n\nclass Foo:\n    pass\n"
        result = parser.parse_source(source, language="python")
        assert result.success is True
        assert result.language == "python"
        assert result.symbol_count > 0

    def test_parse_source_functions(self, parser):
        source = "def foo():\n    pass\n\ndef bar():\n    pass\n"
        result = parser.parse_source(source, language="python")
        assert result.success is True
        func_names = [s["name"] for s in result.functions]
        assert "foo" in func_names
        assert "bar" in func_names

    def test_parse_source_classes(self, parser):
        source = "class MyClass:\n    pass\n"
        result = parser.parse_source(source, language="python")
        assert result.success is True
        class_names = [s["name"] for s in result.classes]
        assert "MyClass" in class_names

    def test_parse_source_imports(self, parser):
        source = "import os\nfrom pathlib import Path\n"
        result = parser.parse_source(source, language="python")
        assert result.success is True
        assert len(result.imports) >= 2

    def test_parse_file(self, parser, sample_python_file):
        result = parser.parse_file(sample_python_file)
        assert result.success is True
        assert result.symbol_count > 0
        func_names = [s["name"] for s in result.functions]
        assert "create_client" in func_names
        assert "fetch_data" in func_names

    def test_parse_file_caching(self, parser, sample_python_file):
        r1 = parser.parse_file(sample_python_file, use_cache=True)
        r2 = parser.parse_file(sample_python_file, use_cache=True)
        assert r1 is r2  # Same object from cache

    def test_parse_nonexistent_file(self, parser):
        result = parser.parse_file(Path("/nonexistent/file.py"))
        assert result.success is False

    def test_parse_no_language_or_path(self, parser):
        result = parser.parse_source("code")
        assert result.success is False

    def test_supported_languages(self):
        langs = ASTParser.supported_languages()
        assert "python" in langs

    def test_supported_extensions(self):
        exts = ASTParser.supported_extensions()
        assert ".py" in exts

    def test_can_parse(self, parser, sample_python_file):
        assert parser.can_parse(sample_python_file) is True
        assert parser.can_parse(Path("unknown.xyz")) is False

    def test_clear_cache(self, parser, sample_python_file):
        parser.parse_file(sample_python_file, use_cache=True)
        assert len(parser._cache) > 0
        parser.clear_cache()
        assert len(parser._cache) == 0

    def test_parse_result_properties(self, parser):
        source = "import os\ndef foo(): pass\nclass Bar: pass\nx = 1\n"
        result = parser.parse_source(source, language="python")
        assert result.success is True
        assert len(result.imports) >= 1
        assert len(result.functions) >= 1
        assert len(result.classes) >= 1

    def test_parse_empty_source(self, parser):
        result = parser.parse_source("", language="python")
        assert result.success is True
        assert result.symbol_count == 0
