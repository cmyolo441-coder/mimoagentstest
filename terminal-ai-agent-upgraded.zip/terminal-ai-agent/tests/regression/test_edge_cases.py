"""Regression tests: edge cases.

Tests boundary conditions and unusual inputs that could cause
unexpected behavior.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[2] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.memory.short_term import ShortTermMemory
from terminal_agent.memory.working_memory import WorkingMemory
from terminal_agent.support.safety.blocked_commands import BlockedCommandRegistry
from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResult, ToolResultStatus


# ── Edge Case Tests ───────────────────────────────────────────────────

class TestEdgeCases:
    """Edge case regression tests."""

    # ── Empty/None inputs ─────────────────────────────────────────

    def test_empty_string_command(self):
        """Empty string command is not blocked."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("") is False

    def test_whitespace_only_command(self):
        """Whitespace-only command is not blocked."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("   ") is False
        assert registry.is_blocked("\t\n") is False

    def test_none_content_in_turn(self):
        """None content in turn doesn't crash."""
        stm = ShortTermMemory()
        # This should work without error
        stm.add_turn("user", "")
        assert stm.count() == 1

    def test_empty_working_memory_get(self):
        """Getting from empty working memory returns default."""
        wm = WorkingMemory()
        assert wm.get("anything") is None
        assert wm.get("anything", 42) == 42

    # ── Very large inputs ─────────────────────────────────────────

    def test_very_long_command(self):
        """Very long command string is handled."""
        registry = BlockedCommandRegistry()
        long_cmd = "echo " + "x" * 100000
        assert registry.is_blocked(long_cmd) is False

    def test_very_large_turn_content(self):
        """Very large turn content is handled."""
        stm = ShortTermMemory(max_turns=5)
        large_content = "x" * 1000000  # 1MB
        stm.add_turn("user", large_content)
        assert stm.count() == 1
        assert stm.estimate_tokens() > 0

    def test_many_working_memory_entries(self):
        """Many working memory entries are handled."""
        wm = WorkingMemory()
        for i in range(10000):
            wm.set(f"key_{i}", f"value_{i}")

        # All values should be retrievable
        assert wm.get("key_0") == "value_0"
        assert wm.get("key_9999") == "value_9999"

    # ── Unicode/special characters ────────────────────────────────

    def test_unicode_in_command(self):
        """Unicode in commands is handled."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("echo '你好世界'") is False

    def test_unicode_in_turn_content(self):
        """Unicode in turn content is handled."""
        stm = ShortTermMemory()
        stm.add_turn("user", "日本語のメッセージ 🎉")
        turns = stm.get_turns()
        assert "日本語" in turns[0]["content"]

    def test_unicode_in_working_memory(self):
        """Unicode in working memory is handled."""
        wm = WorkingMemory()
        wm.set("key", "值: émojis 🚀 and ñ")
        assert "émojis" in wm.get("key")

    def test_special_characters_in_file_path(self):
        """Special characters in file paths are handled."""
        wm = WorkingMemory()
        wm.add_file("path/with spaces/file (1).py", "content")
        assert wm.get_file("path/with spaces/file (1).py") == "content"

    # ── Boundary values ──────────────────────────────────────────

    def test_max_turns_zero(self):
        """max_turns=0 means no turns stored."""
        stm = ShortTermMemory(max_turns=0)
        stm.add_turn("user", "hello")
        assert stm.count() == 0

    def test_max_turns_one(self):
        """max_turns=1 stores only the latest turn."""
        stm = ShortTermMemory(max_turns=1)
        stm.add_turn("user", "first")
        stm.add_turn("assistant", "second")
        assert stm.count() == 1
        assert stm.get_turns()[0]["content"] == "second"

    def test_max_files_zero(self):
        """max_files=0 means no files stored."""
        wm = WorkingMemory(max_files=0)
        wm.add_file("test.py", "content")
        assert wm.get_file("test.py") is None

    def test_zero_ttl_expires_immediately(self):
        """TTL of 0 means entry expires immediately."""
        import time
        wm = WorkingMemory()
        wm.set("key", "value", ttl=0.0)
        time.sleep(0.001)
        assert wm.get("key") is None

    # ── Concurrent edge cases ────────────────────────────────────

    def test_get_turns_max_greater_than_stored(self):
        """Getting more turns than stored returns all stored."""
        stm = ShortTermMemory()
        stm.add_turn("user", "one")
        turns = stm.get_turns(max_turns=100)
        assert len(turns) == 1

    def test_get_last_more_than_available(self):
        """Getting last N turns where N > count returns all."""
        stm = ShortTermMemory()
        stm.add_turn("user", "one")
        stm.add_turn("assistant", "two")
        last = stm.get_last(100)
        assert len(last) == 2

    def test_working_memory_get_file_list_empty(self):
        """File list from empty working memory is empty."""
        wm = WorkingMemory()
        assert wm.get_file_list() == []

    # ── Tool result edge cases ───────────────────────────────────

    def test_tool_result_empty_output(self):
        """ToolResult with empty output is valid."""
        result = ToolResultBuilder.ok("")
        assert result.status == ToolResultStatus.SUCCESS
        assert result.output == ""

    def test_tool_result_none_error(self):
        """ToolResult with None error is valid for success."""
        result = ToolResultBuilder.ok("output")
        assert result.error is None

    def test_tool_result_max_side_effects(self):
        """ToolResult with many side effects is handled."""
        builder = ToolResultBuilder().success("ok")
        for i in range(1000):
            builder.with_side_effect(f"effect_{i}")
        result = builder.build()
        assert len(result.side_effects) == 1000

    def test_tool_result_metadata_with_none_values(self):
        """ToolResult metadata can contain None values."""
        result = (ToolResultBuilder()
                  .success("ok")
                  .with_metadata("key", None)
                  .build())
        assert result.metadata["key"] is None

    # ── Registry edge cases ──────────────────────────────────────

    def test_empty_registry_list_tools(self):
        """Empty registry returns empty tool list."""
        registry = ToolRegistry()
        assert registry.list_tools() == []
        assert registry.list_categories() == []
        assert registry.count() == 0

    def test_registry_get_nonexistent(self):
        """Getting nonexistent tool returns None."""
        registry = ToolRegistry()
        assert registry.get("nonexistent") is None

    def test_registry_has_nonexistent(self):
        """has() returns False for nonexistent tools."""
        registry = ToolRegistry()
        assert registry.has("nonexistent") is False

    def test_registry_unregister_nonexistent(self):
        """Unregistering nonexistent tool doesn't crash."""
        registry = ToolRegistry()
        registry.unregister("nonexistent")  # Should not raise

    def test_registry_len(self):
        """Registry len() returns correct count."""
        registry = ToolRegistry()
        assert len(registry) == 0

        for i in range(5):
            tool = MagicMock()
            tool.name = f"tool_{i}"
            tool.category = "test"
            tool.min_safety_level = SafetyLevel.UNRESTRICTED
            tool.get_schema.return_value = {"name": f"tool_{i}", "parameters": {}}
            registry.register(tool)

        assert len(registry) == 5

    def test_registry_contains(self):
        """Registry __contains__ works correctly."""
        registry = ToolRegistry()
        tool = MagicMock()
        tool.name = "my.tool"
        tool.category = "test"
        tool.min_safety_level = SafetyLevel.UNRESTRICTED
        tool.get_schema.return_value = {"name": "my.tool", "parameters": {}}
        registry.register(tool)

        assert "my.tool" in registry
        assert "other.tool" not in registry

    # ── Safety edge cases ────────────────────────────────────────

    def test_command_with_newlines(self):
        """Commands with newlines are handled."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("echo hello\necho world") is False

    def test_command_with_tabs(self):
        """Commands with tabs are handled."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("echo\thello") is False

    def test_blocked_pattern_partial_match(self):
        """Blocked patterns match as substrings."""
        registry = BlockedCommandRegistry()
        # "rm -rf /" should match within a larger command
        assert registry.is_blocked("cd /tmp && rm -rf /") is True
