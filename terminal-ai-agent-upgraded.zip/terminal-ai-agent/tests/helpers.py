"""Shared test helpers for Terminal Agent test suite."""

from __future__ import annotations

from terminal_agent.types import ToolResult, ToolResultStatus


def make_tool_result(
    status: ToolResultStatus = ToolResultStatus.SUCCESS,
    output: str = "",
    error: str | None = None,
    exit_code: int = 0,
    duration_ms: float = 0.0,
    **extra_metadata,
) -> ToolResult:
    """Create a ToolResult compatible with the dispatcher.

    The dispatcher accesses ``result.truncated`` which is not part of
    the ToolResult dataclass. This helper returns a ToolResult with
    ``truncated`` monkey-patched onto the instance.
    """
    result = ToolResult(
        status=status,
        output=output,
        error=error,
        exit_code=exit_code,
        duration_ms=duration_ms,
        metadata=extra_metadata,
    )
    # The dispatcher accesses result.truncated which doesn't exist on ToolResult
    result.truncated = False
    return result
