"""Chaos tests: network failure scenarios.

Tests the system's behavior when network operations fail — DNS
failures, connection drops, partial responses, etc.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

_src = Path(__file__).resolve().parents[2] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.exceptions import (
    MCPConnectionError,
    ProviderError,
    ProviderNotAvailableError,
    RateLimitError,
)
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResult, ToolResultStatus


# ── Helpers ───────────────────────────────────────────────────────────

def _make_network_tool(name: str = "network.http") -> MagicMock:
    """Tool that simulates network operations."""
    tool = MagicMock()
    tool.name = name
    tool.category = "network"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": name, "parameters": {}}
    return tool


# ── Tests ─────────────────────────────────────────────────────────────

class TestNetworkFailureScenarios:
    """Network failure chaos tests."""

    @pytest.mark.asyncio
    async def test_connection_refused_handling(self):
        """Connection refused error is handled gracefully."""
        tool = _make_network_tool()
        tool.run = AsyncMock(return_value=ToolResultBuilder.err(
            "Connection refused to api.example.com:443",
            exit_code=7,
        ))

        from terminal_agent.tools.dispatcher import ToolDispatcher
        from terminal_agent.tools.registry import ToolRegistry

        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        result = await dispatcher.dispatch(
            ToolCall(name="network.http", parameters={"url": "https://api.example.com"})
        )
        assert result.status == ToolResultStatus.ERROR
        assert "refused" in result.error.lower()

    @pytest.mark.asyncio
    async def test_dns_resolution_failure(self):
        """DNS resolution failure is handled."""
        tool = _make_network_tool()
        tool.run = AsyncMock(return_value=ToolResultBuilder.err(
            "DNS resolution failed: NXDOMAIN for nonexistent.example.com",
            exit_code=1,
        ))

        from terminal_agent.tools.dispatcher import ToolDispatcher
        from terminal_agent.tools.registry import ToolRegistry

        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        result = await dispatcher.dispatch(
            ToolCall(name="network.http", parameters={"url": "https://nonexistent.example.com"})
        )
        assert result.status == ToolResultStatus.ERROR
        assert "DNS" in result.error

    @pytest.mark.asyncio
    async def test_timeout_handling(self):
        """Network timeout is handled gracefully."""
        tool = _make_network_tool()
        tool.run = AsyncMock(return_value=ToolResult(
            status=ToolResultStatus.TIMEOUT,
            error="Request timed out after 30s",
            exit_code=124,
        ))

        from terminal_agent.tools.dispatcher import ToolDispatcher
        from terminal_agent.tools.registry import ToolRegistry

        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        result = await dispatcher.dispatch(
            ToolCall(name="network.http", parameters={"url": "https://slow.example.com", "timeout": 30})
        )
        assert result.status == ToolResultStatus.TIMEOUT

    @pytest.mark.asyncio
    async def test_partial_response_handling(self):
        """Partial/incomplete response is handled."""
        tool = _make_network_tool()
        tool.run = AsyncMock(return_value=ToolResult(
            status=ToolResultStatus.PARTIAL,
            output='{"incomplete": true',  # truncated JSON
            error="Connection reset by peer after 1024 bytes",
        ))

        from terminal_agent.tools.dispatcher import ToolDispatcher
        from terminal_agent.tools.registry import ToolRegistry

        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        result = await dispatcher.dispatch(
            ToolCall(name="network.http", parameters={"url": "https://flaky.example.com"})
        )
        assert result.status == ToolResultStatus.PARTIAL

    @pytest.mark.asyncio
    async def test_retry_on_transient_network_error(self):
        """Transient network errors trigger retries."""
        call_count = 0
        tool = _make_network_tool()

        async def flaky_network(**kwargs):
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                return ToolResultBuilder.err("Connection reset", exit_code=104)
            return ToolResultBuilder.ok("Success after retry")

        tool.run = AsyncMock(side_effect=flaky_network)

        from terminal_agent.tools.dispatcher import ToolDispatcher
        from terminal_agent.tools.registry import ToolRegistry

        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        # First two calls fail
        r1 = await dispatcher.dispatch(ToolCall(name="network.http", parameters={}))
        assert r1.status == ToolResultStatus.ERROR

        r2 = await dispatcher.dispatch(ToolCall(name="network.http", parameters={}))
        assert r2.status == ToolResultStatus.ERROR

        # Third call succeeds
        r3 = await dispatcher.dispatch(ToolCall(name="network.http", parameters={}))
        assert r3.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_rate_limit_from_external_api(self):
        """External API rate limiting is handled."""
        tool = _make_network_tool()
        tool.run = AsyncMock(return_value=ToolResult(
            status=ToolResultStatus.ERROR,
            error="429 Too Many Requests - Retry-After: 60",
            exit_code=429,
            metadata={"retry_after": 60},
        ))

        from terminal_agent.tools.dispatcher import ToolDispatcher
        from terminal_agent.tools.registry import ToolRegistry

        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        result = await dispatcher.dispatch(
            ToolCall(name="network.http", parameters={"url": "https://api.example.com"})
        )
        assert result.status == ToolResultStatus.ERROR
        assert "429" in result.error

    @pytest.mark.asyncio
    async def test_ssl_certificate_error(self):
        """SSL certificate errors are handled."""
        tool = _make_network_tool()
        tool.run = AsyncMock(return_value=ToolResultBuilder.err(
            "SSL: CERTIFICATE_VERIFY_FAILED",
            exit_code=60,
        ))

        from terminal_agent.tools.dispatcher import ToolDispatcher
        from terminal_agent.tools.registry import ToolRegistry

        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        result = await dispatcher.dispatch(
            ToolCall(name="network.http", parameters={"url": "https://bad-cert.example.com"})
        )
        assert result.status == ToolResultStatus.ERROR
        assert "SSL" in result.error or "CERTIFICATE" in result.error

    @pytest.mark.asyncio
    async def test_concurrent_network_failures(self):
        """Multiple concurrent network failures are handled independently."""
        call_count = {"n": 0}
        tool = _make_network_tool()

        async def sometimes_fails(**kwargs):
            call_count["n"] += 1
            if call_count["n"] % 2 == 0:
                return ToolResultBuilder.err("Connection failed")
            return ToolResultBuilder.ok("Success")

        tool.run = AsyncMock(side_effect=sometimes_fails)

        from terminal_agent.tools.dispatcher import ToolDispatcher
        from terminal_agent.tools.registry import ToolRegistry

        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        # Run multiple concurrent dispatches
        tasks = [
            dispatcher.dispatch(ToolCall(name="network.http", parameters={"url": f"https://api.example.com/{i}"}))
            for i in range(10)
        ]
        results = await asyncio.gather(*tasks)

        # Some should succeed, some should fail
        successes = sum(1 for r in results if r.status == ToolResultStatus.SUCCESS)
        failures = sum(1 for r in results if r.status == ToolResultStatus.ERROR)
        assert successes + failures == 10

    @pytest.mark.asyncio
    async def test_mcp_connection_failure(self):
        """MCP connection failure is handled."""
        from terminal_agent.exceptions import MCPConnectionError

        error = MCPConnectionError("Failed to connect to MCP server")
        assert "MCP" in str(error)

    @pytest.mark.asyncio
    async def test_network_tool_timeout_metadata(self):
        """Timeout results include timing metadata."""
        tool = _make_network_tool()
        tool.run = AsyncMock(return_value=ToolResult(
            status=ToolResultStatus.TIMEOUT,
            error="Connection timed out",
            exit_code=124,
            duration_ms=30000.0,
        ))

        from terminal_agent.tools.dispatcher import ToolDispatcher
        from terminal_agent.tools.registry import ToolRegistry

        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        result = await dispatcher.dispatch(
            ToolCall(name="network.http", parameters={"url": "https://timeout.example.com"})
        )
        assert result.status == ToolResultStatus.TIMEOUT
        assert result.duration_ms == 30000.0
