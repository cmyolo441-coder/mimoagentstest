"""Chaos tests: concurrent access scenarios.

Tests the system's behavior under concurrent access — multiple
simultaneous tool dispatches, parallel memory operations, etc.
"""

from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[2] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.memory.short_term import ShortTermMemory
from terminal_agent.memory.working_memory import WorkingMemory
from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResultStatus


# ── Helpers ───────────────────────────────────────────────────────────

def _make_slow_tool(name: str, delay: float = 0.01) -> MagicMock:
    tool = MagicMock()
    tool.name = name
    tool.category = "test"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": name, "parameters": {}}

    async def _execute(**kwargs):
        await asyncio.sleep(delay)
        return ToolResultBuilder.ok(f"Done: {name}")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


# ── Tests ─────────────────────────────────────────────────────────────

class TestConcurrentToolDispatch:
    """Concurrent tool dispatch tests."""

    @pytest.mark.asyncio
    async def test_concurrent_dispatches_to_same_tool(self):
        """Multiple concurrent dispatches to the same tool work."""
        tool = _make_slow_tool("test.tool", delay=0.01)
        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        tasks = [
            dispatcher.dispatch(ToolCall(name="test.tool", parameters={"i": i}))
            for i in range(20)
        ]
        results = await asyncio.gather(*tasks)

        assert len(results) == 20
        assert all(r.status == ToolResultStatus.SUCCESS for r in results)

    @pytest.mark.asyncio
    async def test_concurrent_dispatches_to_different_tools(self):
        """Concurrent dispatches to different tools work."""
        registry = ToolRegistry()
        for i in range(5):
            registry.register(_make_slow_tool(f"tool_{i}"))
        dispatcher = ToolDispatcher(registry)

        tasks = [
            dispatcher.dispatch(ToolCall(name=f"tool_{i % 5}", parameters={}))
            for i in range(25)
        ]
        results = await asyncio.gather(*tasks)

        assert len(results) == 25
        assert all(r.status == ToolResultStatus.SUCCESS for r in results)

    @pytest.mark.asyncio
    async def test_concurrent_with_mixed_success_failure(self):
        """Concurrent dispatches with mixed outcomes."""
        registry = ToolRegistry()

        ok_tool = _make_slow_tool("ok.tool")
        fail_tool = MagicMock()
        fail_tool.name = "fail.tool"
        fail_tool.category = "test"
        fail_tool.min_safety_level = SafetyLevel.UNRESTRICTED
        fail_tool.get_schema.return_value = {"name": "fail.tool", "parameters": {}}
        fail_tool.run = AsyncMock(return_value=ToolResultBuilder.err("Failed"))

        registry.register(ok_tool)
        registry.register(fail_tool)
        dispatcher = ToolDispatcher(registry)

        tasks = []
        for i in range(20):
            name = "ok.tool" if i % 3 == 0 else "fail.tool"
            tasks.append(dispatcher.dispatch(ToolCall(name=name, parameters={})))

        results = await asyncio.gather(*tasks)
        successes = sum(1 for r in results if r.status == ToolResultStatus.SUCCESS)
        failures = sum(1 for r in results if r.status == ToolResultStatus.ERROR)
        assert successes + failures == 20

    @pytest.mark.asyncio
    async def test_concurrent_unknown_tool_dispatches(self):
        """Concurrent dispatches to unknown tools all return errors."""
        registry = ToolRegistry()
        dispatcher = ToolDispatcher(registry)

        tasks = [
            dispatcher.dispatch(ToolCall(name=f"nonexistent_{i}", parameters={}))
            for i in range(10)
        ]
        results = await asyncio.gather(*tasks)

        assert all(r.status == ToolResultStatus.ERROR for r in results)


class TestConcurrentMemoryAccess:
    """Concurrent memory access tests."""

    def test_concurrent_short_term_writes(self):
        """Multiple threads writing to short-term memory."""
        stm = ShortTermMemory(max_turns=100)

        # Simulate concurrent writes (sequential in async context, but tests ordering)
        for i in range(50):
            stm.add_turn("user", f"Message {i}")

        assert stm.count() == 50

    def test_concurrent_working_memory_writes(self):
        """Multiple writes to working memory don't corrupt state."""
        wm = WorkingMemory(max_files=100)

        for i in range(50):
            wm.set(f"key_{i}", f"value_{i}")

        for i in range(50):
            assert wm.get(f"key_{i}") == f"value_{i}"

    def test_concurrent_file_writes_to_working_memory(self):
        """Concurrent file writes to working memory."""
        wm = WorkingMemory(max_files=100)

        for i in range(20):
            wm.add_file(f"file_{i}.py", f"# Content of file {i}\n")

        files = wm.get_file_list()
        assert len(files) == 20

    def test_concurrent_scratch_writes(self):
        """Concurrent scratch pad writes."""
        wm = WorkingMemory()

        for i in range(30):
            wm.set_scratch(f"note_{i}", f"Scratch note {i}")

        for i in range(30):
            assert wm.get_scratch(f"note_{i}") == f"Scratch note {i}"

    def test_eviction_under_concurrent_load(self):
        """Eviction works correctly under heavy write load."""
        stm = ShortTermMemory(max_turns=10)

        for i in range(100):
            stm.add_turn("user", f"Message {i}")

        assert stm.count() == 10
        turns = stm.get_turns()
        assert turns[0]["content"] == "Message 90"

    def test_working_memory_file_eviction_under_load(self):
        """File eviction works under heavy load."""
        wm = WorkingMemory(max_files=5)

        for i in range(20):
            wm.add_file(f"file_{i}.py", f"content_{i}")

        files = wm.get_file_list()
        assert len(files) == 5
        assert "file_19.py" in files
        assert "file_0.py" not in files


class TestConcurrentRegistryAccess:
    """Concurrent tool registry access tests."""

    def test_concurrent_registration(self):
        """Registering multiple tools sequentially works."""
        registry = ToolRegistry()

        for i in range(50):
            tool = MagicMock()
            tool.name = f"tool_{i}"
            tool.category = "test"
            tool.min_safety_level = SafetyLevel.UNRESTRICTED
            tool.get_schema.return_value = {"name": f"tool_{i}", "parameters": {}}
            registry.register(tool)

        assert registry.count() == 50

    def test_concurrent_get_operations(self):
        """Concurrent get operations on registry."""
        registry = ToolRegistry()
        for i in range(10):
            tool = MagicMock()
            tool.name = f"tool_{i}"
            tool.category = "test"
            tool.min_safety_level = SafetyLevel.UNRESTRICTED
            tool.get_schema.return_value = {"name": f"tool_{i}", "parameters": {}}
            registry.register(tool)

        # All gets should work
        for i in range(10):
            assert registry.get(f"tool_{i}") is not None
            assert registry.has(f"tool_{i}") is True

    @pytest.mark.asyncio
    async def test_concurrent_dispatch_stress(self):
        """Stress test: many concurrent dispatches."""
        tool = _make_slow_tool("stress.tool", delay=0.001)
        registry = ToolRegistry()
        registry.register(tool)
        dispatcher = ToolDispatcher(registry)

        start = time.monotonic()
        tasks = [
            dispatcher.dispatch(ToolCall(name="stress.tool", parameters={"i": i}))
            for i in range(100)
        ]
        results = await asyncio.gather(*tasks)
        elapsed = time.monotonic() - start

        assert len(results) == 100
        assert all(r.status == ToolResultStatus.SUCCESS for r in results)
        # Should complete in reasonable time (not 100 * 0.001 = 0.1s sequentially)
        assert elapsed < 5.0  # generous timeout for CI
