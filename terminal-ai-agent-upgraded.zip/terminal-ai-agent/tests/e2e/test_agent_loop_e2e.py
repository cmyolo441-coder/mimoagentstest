"""End-to-end tests for the agent loop.

Tests the core orchestrator loop: goal → plan → execute → verify,
using fully mocked LLM and tools.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[2] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.types import (
    LLMResponse,
    Plan,
    PlanStep,
    SafetyLevel,
    Session,
    SessionStatus,
    ToolCall,
    ToolResult,
    ToolResultStatus,
    TraceEntry,
)


# ── Helpers ───────────────────────────────────────────────────────────

def _make_mock_tool(name: str, response: str = "ok") -> MagicMock:
    tool = MagicMock()
    tool.name = name
    tool.category = "test"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": name, "parameters": {}}
    tool.run = AsyncMock(return_value=ToolResult(
        status=ToolResultStatus.SUCCESS,
        output=response,
        exit_code=0,
    ))
    return tool


# ── Tests ─────────────────────────────────────────────────────────────

class TestAgentLoopE2E:
    """Agent loop end-to-end tests."""

    def test_plan_creation(self):
        """Create a plan with steps."""
        plan = Plan(
            goal="Create a hello world script",
            steps=[
                PlanStep(id="1", description="Create main.py", tool_hint="filesystem.write"),
                PlanStep(id="2", description="Run the script", tool_hint="shell.execute"),
            ],
            complexity="simple",
            estimated_steps=2,
        )
        assert plan.goal == "Create a hello world script"
        assert len(plan.steps) == 2
        assert plan.steps[0].tool_hint == "filesystem.write"

    def test_plan_step_status_transitions(self):
        """PlanStep status transitions work correctly."""
        step = PlanStep(id="1", description="Test step")
        assert step.status == SessionStatus.PENDING

        step.status = SessionStatus.RUNNING
        assert step.status == SessionStatus.RUNNING

        step.status = SessionStatus.COMPLETED
        assert step.status == SessionStatus.COMPLETED

    def test_session_lifecycle(self):
        """Session goes through the expected lifecycle."""
        session = Session(
            goal="Test goal",
            status=SessionStatus.PENDING,
        )
        assert session.status == SessionStatus.PENDING

        session.status = SessionStatus.RUNNING
        session.start_time = 1000.0
        assert session.status == SessionStatus.RUNNING

        session.status = SessionStatus.COMPLETED
        session.end_time = 1010.0
        session.outcome = "Goal achieved"
        assert session.status == SessionStatus.COMPLETED
        assert session.outcome == "Goal achieved"

    def test_session_failure_lifecycle(self):
        """Session failure lifecycle."""
        session = Session(
            goal="Impossible goal",
            status=SessionStatus.RUNNING,
        )
        session.status = SessionStatus.FAILED
        session.error_message = "Max iterations reached"
        assert session.status == SessionStatus.FAILED
        assert session.error_message == "Max iterations reached"

    def test_trace_entry_creation(self):
        """TraceEntry captures execution details."""
        entry = TraceEntry(
            timestamp=1000.0,
            entry_type="action",
            content="Executed shell.execute with command='ls'",
            metadata={"tool": "shell.execute", "duration_ms": 50.0},
        )
        assert entry.entry_type == "action"
        assert entry.metadata["tool"] == "shell.execute"

    @pytest.mark.asyncio
    async def test_tool_execution_through_plan(self):
        """Execute plan steps through mock tools."""
        write_tool = _make_mock_tool("filesystem.write", "Wrote 10 bytes")
        shell_tool = _make_mock_tool("shell.execute", "hello world\n")

        # Execute step 1
        result1 = await write_tool.run(path="main.py", content="print('hello')")
        assert result1.status == ToolResultStatus.SUCCESS

        # Execute step 2
        result2 = await shell_tool.run(command="python main.py")
        assert result2.status == ToolResultStatus.SUCCESS
        assert "hello world" in result2.output

    @pytest.mark.asyncio
    async def test_plan_with_dependencies(self):
        """Plan steps can reference dependencies."""
        plan = Plan(
            goal="Build and test",
            steps=[
                PlanStep(id="build", description="Build the project", tool_hint="shell.execute"),
                PlanStep(id="test", description="Run tests", tool_hint="shell.execute", dependencies=["build"]),
            ],
        )
        assert "build" in plan.steps[1].dependencies

    @pytest.mark.asyncio
    async def test_tool_error_handling_in_loop(self):
        """Agent handles tool errors gracefully."""
        tool = MagicMock()
        tool.name = "failing.tool"
        tool.category = "test"
        tool.min_safety_level = SafetyLevel.UNRESTRICTED
        tool.run = AsyncMock(return_value=ToolResult(
            status=ToolResultStatus.ERROR,
            error="Something went wrong",
            exit_code=1,
        ))

        result = await tool.run(param="value")
        assert result.status == ToolResultStatus.ERROR
        assert "went wrong" in result.error

    @pytest.mark.asyncio
    async def test_multi_step_execution_tracking(self):
        """Track execution across multiple steps."""
        steps_results = []
        tools = {
            "step1": _make_mock_tool("tool1", "step1 done"),
            "step2": _make_mock_tool("tool2", "step2 done"),
            "step3": _make_mock_tool("tool3", "step3 done"),
        }

        for step_name, tool in tools.items():
            result = await tool.run()
            steps_results.append((step_name, result))

        assert len(steps_results) == 3
        assert all(r.status == ToolResultStatus.SUCCESS for _, r in steps_results)

    def test_session_token_tracking(self):
        """Session tracks token usage."""
        session = Session(goal="test")
        session.total_tokens = 1500
        session.total_cost = 0.05
        session.total_steps = 5

        assert session.total_tokens == 1500
        assert session.total_cost == 0.05
        assert session.total_steps == 5

    @pytest.mark.asyncio
    async def test_llm_response_drives_tool_calls(self):
        """LLM response with tool calls drives the next action."""
        tool = _make_mock_tool("filesystem.write", "created")

        # Simulate LLM response with a tool call
        response = LLMResponse(
            content="I'll create the file.",
            tool_calls=[
                ToolCall(name="filesystem.write", parameters={"path": "test.py", "content": "x = 1\n"})
            ],
        )

        # Execute the tool call
        for tc in response.tool_calls:
            result = await tool.run(**tc.parameters)
            assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_llm_response_without_tool_calls(self):
        """LLM response without tool calls means task is done."""
        response = LLMResponse(
            content="The task is complete. All files have been created.",
            tool_calls=[],
        )

        assert len(response.tool_calls) == 0
        assert "complete" in response.content.lower()

    def test_goal_complexity_levels(self):
        """Goal complexity affects planning."""
        from terminal_agent.types import GoalComplexity

        simple = Plan(goal="echo hello", complexity=GoalComplexity.SIMPLE)
        complex_plan = Plan(goal="build microservice", complexity=GoalComplexity.COMPLEX)
        multi = Plan(goal="refactor monolith", complexity=GoalComplexity.MULTI_SYSTEM)

        assert simple.complexity == GoalComplexity.SIMPLE
        assert complex_plan.complexity == GoalComplexity.COMPLEX
        assert multi.complexity == GoalComplexity.MULTI_SYSTEM

    @pytest.mark.asyncio
    async def test_verification_after_execution(self):
        """Verify results after tool execution."""
        tool = _make_mock_tool("shell.execute", "===== 5 passed =====")
        result = await tool.run(command="pytest")

        # Verification checks
        assert result.status == ToolResultStatus.SUCCESS
        assert "passed" in result.output
        assert result.exit_code == 0
