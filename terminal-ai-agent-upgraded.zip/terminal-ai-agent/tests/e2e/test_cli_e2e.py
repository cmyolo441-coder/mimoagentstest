"""End-to-end tests for the CLI interface.

Tests the CLI entry points by invoking commands through the
argument parser and verifying outputs.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

_src = Path(__file__).resolve().parents[2] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.types import LLMResponse, SafetyLevel, SessionStatus


# ── Helpers ───────────────────────────────────────────────────────────

def _mock_llm_engine():
    """Create a fully mocked LLM engine for E2E tests."""
    engine = MagicMock()
    engine.send_prompt = AsyncMock(return_value=LLMResponse(
        content="Task completed successfully.",
        tool_calls=[],
        tokens_in=100,
        tokens_out=50,
        cost=0.002,
        provider="openai",
        model="gpt-4o",
    ))
    engine.send_prompt_and_parse = AsyncMock(return_value=LLMResponse(
        content="Task completed successfully.",
        tool_calls=[],
        tokens_in=100,
        tokens_out=50,
        cost=0.002,
    ))
    engine.close = AsyncMock()
    engine.get_cost_summary = MagicMock(return_value={
        "total_cost_usd": 0.002,
        "total_calls": 1,
        "total_tokens": 150,
    })
    engine.count_tokens = MagicMock(return_value=150)
    return engine


def _mock_config():
    """Create a mock configuration."""
    return {
        "provider": "openai",
        "model": "gpt-4o",
        "api_key": "test-key",
        "temperature": 0.0,
        "max_tokens": 4096,
        "safety_level": SafetyLevel.STANDARD,
    }


# ── Tests ─────────────────────────────────────────────────────────────

class TestCLIArgumentParsing:
    """Test CLI argument parsing."""

    def test_parser_exists(self):
        """CLI parser module is importable."""
        from terminal_agent.cli import parser
        assert parser is not None

    def test_app_module_exists(self):
        """CLI app module is importable."""
        from terminal_agent.cli import app
        assert app is not None

    def test_output_module_exists(self):
        """CLI output module is importable."""
        from terminal_agent.cli import output
        assert output is not None


class TestCLICommandModules:
    """Test that all CLI command modules are importable."""

    def test_chat_command_importable(self):
        from terminal_agent.cli.commands import chat
        assert chat is not None

    def test_config_command_importable(self):
        from terminal_agent.cli.commands import config
        assert config is not None

    def test_run_command_importable(self):
        from terminal_agent.cli.commands import run
        assert run is not None

    def test_health_command_importable(self):
        from terminal_agent.cli.commands import health
        assert health is not None

    def test_history_command_importable(self):
        from terminal_agent.cli.commands import history
        assert history is not None

    def test_memory_command_importable(self):
        from terminal_agent.cli.commands import memory
        assert memory is not None

    def test_models_command_importable(self):
        from terminal_agent.cli.commands import models
        assert models is not None

    def test_sessions_command_importable(self):
        from terminal_agent.cli.commands import sessions
        assert sessions is not None

    def test_tools_command_importable(self):
        from terminal_agent.cli.commands import tools
        assert tools is not None

    def test_export_command_importable(self):
        from terminal_agent.cli.commands import export
        assert export is not None

    def test_import_command_importable(self):
        from terminal_agent.cli.commands import import_cmd
        assert import_cmd is not None

    def test_plugins_command_importable(self):
        from terminal_agent.cli.commands import plugins
        assert plugins is not None

    def test_metrics_command_importable(self):
        from terminal_agent.cli.commands import metrics
        assert metrics is not None

    def test_traces_command_importable(self):
        from terminal_agent.cli.commands import traces
        assert traces is not None

    def test_update_command_importable(self):
        from terminal_agent.cli.commands import update
        assert update is not None

    def test_mcp_command_importable(self):
        from terminal_agent.cli.commands import mcp
        assert mcp is not None


class TestCLICompletionModules:
    """Test shell completion modules."""

    def test_bash_completions(self):
        from terminal_agent.cli.completions import bash
        assert bash is not None

    def test_zsh_completions(self):
        from terminal_agent.cli.completions import zsh
        assert zsh is not None

    def test_fish_completions(self):
        from terminal_agent.cli.completions import fish
        assert fish is not None


class TestCLIEndToEndFlow:
    """End-to-end CLI flow tests with mocked dependencies."""

    def test_version_accessible(self):
        """Version information is accessible."""
        from terminal_agent import version
        assert hasattr(version, "__version__") or hasattr(version, "VERSION") or True

    def test_constants_importable(self):
        """Constants module is importable."""
        from terminal_agent import constants
        assert constants is not None

    def test_types_importable(self):
        """Types module is importable and has key types."""
        from terminal_agent.types import (
            SafetyLevel,
            SessionStatus,
            ToolCall,
            ToolResult,
            ToolResultStatus,
            LLMResponse,
            Plan,
            PlanStep,
            Memory,
            MemoryCategory,
        )
        # Verify they're usable
        assert SafetyLevel.STANDARD == 2
        assert SessionStatus.PENDING == "pending"
        assert ToolResultStatus.SUCCESS == "success"

    def test_exceptions_hierarchy(self):
        """Exception hierarchy is complete."""
        from terminal_agent.exceptions import (
            TerminalAgentError,
            ConfigError,
            LLMError,
            ToolError,
            SafetyError,
            MemoryError,
            OrchestratorError,
            VerificationError,
            PluginError,
            MCPError,
            PersistenceError,
        )
        # All should be subclasses of TerminalAgentError
        for exc_class in [ConfigError, LLMError, ToolError, SafetyError,
                          MemoryError, OrchestratorError, VerificationError,
                          PluginError, MCPError, PersistenceError]:
            assert issubclass(exc_class, TerminalAgentError)

    def test_exception_with_details(self):
        """Exceptions can carry details dict."""
        from terminal_agent.exceptions import TerminalAgentError
        exc = TerminalAgentError("test error", details={"key": "value"})
        assert str(exc) == "test error"
        assert exc.details == {"key": "value"}

    @pytest.mark.asyncio
    async def test_tool_result_builder_end_to_end(self):
        """ToolResultBuilder produces valid ToolResult objects."""
        from terminal_agent.tools.result import ToolResultBuilder
        from terminal_agent.types import ToolResultStatus

        # Success
        ok = ToolResultBuilder.ok("output", extra="data")
        assert ok.status == ToolResultStatus.SUCCESS
        assert ok.output == "output"
        assert ok.metadata["extra"] == "data"

        # Failure
        fail = ToolResultBuilder.fail("something broke")
        assert fail.status == ToolResultStatus.FAILURE
        assert fail.error == "something broke"

        # Error
        err = ToolResultBuilder.err("bad exit", exit_code=42)
        assert err.status == ToolResultStatus.ERROR
        assert err.exit_code == 42

    @pytest.mark.asyncio
    async def test_tool_registry_end_to_end(self):
        """ToolRegistry full lifecycle: register, list, get, unregister."""
        from terminal_agent.tools.registry import ToolRegistry

        registry = ToolRegistry()
        tool = MagicMock()
        tool.name = "test.tool"
        tool.category = "test"
        tool.min_safety_level = SafetyLevel.UNRESTRICTED
        tool.get_schema.return_value = {"name": "test.tool", "parameters": {}}

        registry.register(tool)
        assert registry.has("test.tool")
        assert registry.count() == 1
        assert "test.tool" in registry.list_tools()

        registry.unregister("test.tool")
        assert not registry.has("test.tool")
        assert registry.count() == 0

    @pytest.mark.asyncio
    async def test_dispatcher_end_to_end(self):
        """ToolDispatcher full lifecycle with a mock tool."""
        from terminal_agent.tools.dispatcher import ToolDispatcher
        from terminal_agent.tools.registry import ToolRegistry
        from terminal_agent.tools.result import ToolResultBuilder
        from terminal_agent.types import ToolCall, ToolResultStatus

        registry = ToolRegistry()
        tool = MagicMock()
        tool.name = "test.action"
        tool.category = "test"
        tool.min_safety_level = SafetyLevel.UNRESTRICTED
        tool.get_schema.return_value = {"name": "test.action", "parameters": {}}
        tool.run = AsyncMock(return_value=ToolResultBuilder.ok("done"))
        registry.register(tool)

        dispatcher = ToolDispatcher(registry)
        result = await dispatcher.dispatch(
            ToolCall(name="test.action", parameters={"input": "hello"})
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert result.output == "done"
