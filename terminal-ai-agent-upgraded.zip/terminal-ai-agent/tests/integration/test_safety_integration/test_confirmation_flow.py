"""Integration tests: confirmation flow.

Tests the full confirmation workflow: safety system identifies risky
operations, generates confirmation prompts, and handles user responses.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.support.safety.confirmation import ConfirmationManager, ConfirmationRequest
from terminal_agent.support.safety.guardrails import SafetyDecision, SafetyGuardrails, SafetyVerdict
from terminal_agent.types import SafetyLevel, ToolCall


# ── Tests ─────────────────────────────────────────────────────────────

class TestConfirmationManager:
    """Tests for the confirmation manager."""

    @pytest.fixture
    def manager(self):
        return ConfirmationManager()

    def test_build_request_for_shell_command(self, manager):
        """Build confirmation request for a shell command."""
        call = ToolCall(name="execute_command", parameters={"command": "sudo apt install nginx"})
        request = manager.build_request(call, risk_level="high", reason="System package install")

        assert request.risk_level == "high"
        assert "sudo" in request.summary.lower() or "nginx" in request.summary.lower()
        assert any("root" in c.lower() or "privilege" in c.lower() for c in request.consequences)

    def test_build_request_for_file_delete(self, manager):
        """Build confirmation request for file deletion."""
        call = ToolCall(name="delete_file", parameters={"path": "/important/data.csv"})
        request = manager.build_request(call, risk_level="critical")

        assert request.risk_level == "critical"
        assert "permanently deleted" in " ".join(request.consequences).lower() or "deleted" in " ".join(request.consequences).lower()
        assert len(request.alternatives) > 0  # should suggest trash

    def test_build_request_for_git_push(self, manager):
        """Build confirmation request for git push."""
        call = ToolCall(
            name="git_push",
            parameters={"remote": "origin", "branch": "main", "force": True},
        )
        request = manager.build_request(call, risk_level="high")

        assert "force" in " ".join(request.consequences).lower() or "overwrite" in " ".join(request.consequences).lower()

    def test_build_request_for_database_query(self, manager):
        """Build confirmation request for database query."""
        call = ToolCall(
            name="database_execute",
            parameters={"query": "DROP TABLE users;"},
        )
        request = manager.build_request(call, risk_level="critical")

        assert "DROP TABLE" in request.summary

    def test_format_prompt_contains_approve(self, manager):
        """Formatted prompt contains approval prompt."""
        call = ToolCall(name="execute_command", parameters={"command": "ls"})
        request = manager.build_request(call, risk_level="medium")
        prompt = manager.format_prompt(request)

        assert "Approve" in prompt
        assert "[y/N]" in prompt

    def test_format_prompt_contains_details(self, manager):
        """Formatted prompt includes details when provided."""
        call = ToolCall(name="execute_command", parameters={"command": "rm old_file.txt"})
        request = manager.build_request(
            call,
            risk_level="medium",
            reason="File is no longer needed",
            details=["File was last modified 6 months ago"],
        )
        prompt = manager.format_prompt(request)

        assert "Details:" in prompt
        assert "6 months ago" in prompt

    def test_format_prompt_contains_consequences(self, manager):
        """Formatted prompt includes consequences."""
        call = ToolCall(name="delete_file", parameters={"path": "data.csv"})
        request = manager.build_request(call, risk_level="high")
        prompt = manager.format_prompt(request)

        assert "Consequences:" in prompt

    def test_format_prompt_contains_alternatives(self, manager):
        """Formatted prompt includes alternatives when available."""
        call = ToolCall(name="delete_file", parameters={"path": "data.csv"})
        request = manager.build_request(call, risk_level="high")
        prompt = manager.format_prompt(request)

        assert "Alternatives:" in prompt

    def test_critical_risk_requires_reason(self, manager):
        """Critical risk level sets requires_reason flag."""
        call = ToolCall(name="execute_command", parameters={"command": "rm -rf /var/data"})
        request = manager.build_request(call, risk_level="critical")

        assert request.requires_reason is True

    def test_low_risk_no_reason_required(self, manager):
        """Low risk level does not require reason."""
        call = ToolCall(name="write_file", parameters={"path": "notes.txt", "content": "hello"})
        request = manager.build_request(call, risk_level="low")

        assert request.requires_reason is False


class TestConfirmationFlowIntegration:
    """Integration tests for the full confirmation flow."""

    def test_guardrails_confirm_for_destructive_at_moderate(self):
        """Guardrails produce CONFIRM verdict for destructive ops at MODERATE level."""
        guardrails = SafetyGuardrails(safety_level=SafetyLevel.MODERATE)
        call = ToolCall(name="execute_command", parameters={"command": "rm temp.txt"})
        verdict = guardrails.evaluate(call)

        assert verdict.needs_confirmation is True

    def test_guardrails_confirm_for_high_risk_at_standard(self):
        """Guardrails produce CONFIRM for high-risk tools at STANDARD level."""
        guardrails = SafetyGuardrails(safety_level=SafetyLevel.STANDARD)
        call = ToolCall(name="delete_file", parameters={"path": "old.log"})
        verdict = guardrails.evaluate(call)

        assert verdict.needs_confirmation is True

    def test_guardrails_allow_read_only_at_moderate(self):
        """Read-only tools are ALLOWED at MODERATE level without confirmation."""
        guardrails = SafetyGuardrails(safety_level=SafetyLevel.MODERATE)
        call = ToolCall(name="read_file", parameters={"path": "README.md"})
        verdict = guardrails.evaluate(call)

        assert verdict.allowed is True

    def test_full_confirm_flow_with_approval(self):
        """Full flow: evaluate → confirm → user approves → execute."""
        guardrails = SafetyGuardrails(safety_level=SafetyLevel.STANDARD)
        manager = ConfirmationManager()

        call = ToolCall(name="execute_command", parameters={"command": "pip install flask"})
        verdict = guardrails.evaluate(call)

        assert verdict.needs_confirmation is True

        # Build confirmation prompt
        request = manager.build_request(
            call,
            risk_level="medium",
            reason=verdict.reason,
        )
        prompt = manager.format_prompt(request)
        assert "Approve" in prompt

        # Simulate user approval (in real system, user types 'y')
        # The test verifies the flow works up to the approval point

    def test_full_confirm_flow_with_rejection(self):
        """Full flow: evaluate → confirm → user rejects → blocked."""
        guardrails = SafetyGuardrails(safety_level=SafetyLevel.STRICT)
        call = ToolCall(name="execute_command", parameters={"command": "some command"})
        verdict = guardrails.evaluate(call)

        assert verdict.needs_confirmation is True

        # Simulate user rejection (don't execute)
        # The test verifies the flow correctly identifies need for confirmation

    def test_multiple_risky_commands_all_require_confirmation(self):
        """All risky commands at STRICT level require confirmation."""
        guardrails = SafetyGuardrails(safety_level=SafetyLevel.STRICT)
        risky_calls = [
            ToolCall(name="write_file", parameters={"path": "f.txt", "content": "x"}),
            ToolCall(name="execute_command", parameters={"command": "echo hi"}),
            ToolCall(name="git_push", parameters={}),
        ]
        for call in risky_calls:
            verdict = guardrails.evaluate(call)
            assert verdict.needs_confirmation is True, f"Should require confirmation: {call.name}"

    def test_read_only_bypasses_strict(self):
        """Read-only tools bypass STRICT level confirmation."""
        guardrails = SafetyGuardrails(safety_level=SafetyLevel.STRICT)
        read_tools = [
            ToolCall(name="read_file", parameters={"path": "file.txt"}),
            ToolCall(name="list_directory", parameters={}),
            ToolCall(name="git_status", parameters={}),
            ToolCall(name="git_log", parameters={}),
        ]
        for call in read_tools:
            verdict = guardrails.evaluate(call)
            assert verdict.allowed is True, f"Should be allowed: {call.name}"

    def test_verdict_details_populated(self):
        """Verdict contains useful details for the confirmation flow."""
        guardrails = SafetyGuardrails(safety_level=SafetyLevel.STANDARD)
        call = ToolCall(name="execute_command", parameters={"command": "rm -rf /"})
        verdict = guardrails.evaluate(call)

        assert verdict.blocked is True
        assert verdict.tool_call is call
        assert verdict.safety_level == SafetyLevel.STANDARD
        assert len(verdict.reason) > 0
