"""Integration tests: dangerous command blocking.

Tests that the safety system correctly blocks dangerous shell commands
through the full tool dispatch pipeline.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.support.safety.blocked_commands import BlockedCommandRegistry
from terminal_agent.support.safety.guardrails import SafetyDecision, SafetyGuardrails, SafetyVerdict
from terminal_agent.types import SafetyLevel, ToolCall


# ── Tests ─────────────────────────────────────────────────────────────

class TestBlockedCommandRegistry:
    """Tests for the blocked command registry."""

    def test_rm_rf_root_blocked(self):
        """rm -rf / is blocked."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("rm -rf /") is True
        assert registry.is_blocked("rm -rf /*") is True

    def test_fork_bomb_blocked(self):
        """Fork bomb is blocked."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked(":(){ :|:& };:") is True

    def test_dd_overwrite_blocked(self):
        """dd disk overwrite is blocked."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("dd if=/dev/zero of=/dev/sda") is True
        assert registry.is_blocked("dd if=/dev/urandom of=/dev/sda") is True

    def test_mkfs_blocked(self):
        """mkfs (filesystem format) is blocked."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("mkfs") is True

    def test_safe_commands_not_blocked(self):
        """Safe commands are not blocked."""
        registry = BlockedCommandRegistry()
        safe_commands = [
            "ls -la",
            "cat file.txt",
            "echo hello",
            "python script.py",
            "git status",
            "npm install",
            "docker ps",
            "pip install requests",
        ]
        for cmd in safe_commands:
            assert registry.is_blocked(cmd) is False, f"False positive: {cmd}"

    def test_shutdown_blocked_by_pattern(self):
        """Shutdown/reboot commands are blocked by pattern."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("shutdown -h now") is True
        assert registry.is_blocked("reboot") is True
        assert registry.is_blocked("halt") is True
        assert registry.is_blocked("poweroff") is True

    def test_firewall_flush_blocked(self):
        """iptables -F (firewall flush) is blocked."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("iptables -F") is True

    def test_why_blocked_returns_reason(self):
        """why_blocked returns a reason for blocked commands."""
        registry = BlockedCommandRegistry()
        reason = registry.why_blocked("rm -rf /")
        assert reason is not None
        assert len(reason) > 0

    def test_why_blocked_returns_none_for_safe(self):
        """why_blocked returns None for safe commands."""
        registry = BlockedCommandRegistry()
        assert registry.why_blocked("ls") is None

    def test_add_custom_exact_block(self):
        """Custom exact-match blocks work."""
        registry = BlockedCommandRegistry()
        registry.add_exact("dangerous-custom-cmd")
        assert registry.is_blocked("dangerous-custom-cmd") is True

    def test_add_custom_pattern_block(self):
        """Custom pattern blocks work."""
        registry = BlockedCommandRegistry()
        registry.add_pattern(r"\bcustom-evil\b", "Custom evil command")
        assert registry.is_blocked("run custom-evil now") is True

    def test_remove_exact_block(self):
        """Removing an exact block unblocks the command."""
        registry = BlockedCommandRegistry()
        registry.add_exact("temp-block")
        assert registry.is_blocked("temp-block") is True
        registry.remove_exact("temp-block")
        assert registry.is_blocked("temp-block") is False

    def test_clear_removes_all_blocks(self):
        """Clear removes all blocks (use with caution)."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("rm -rf /") is True
        registry.clear()
        assert registry.is_blocked("rm -rf /") is False

    def test_reset_to_defaults(self):
        """Reset restores default blocks."""
        registry = BlockedCommandRegistry()
        registry.clear()
        assert registry.is_blocked("rm -rf /") is False
        registry.reset_to_defaults()
        assert registry.is_blocked("rm -rf /") is True

    def test_case_insensitive_matching(self):
        """Pattern matching is case-insensitive."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("SHUTDOWN -h now") is True
        assert registry.is_blocked("Shutdown") is True

    def test_list_exact_commands(self):
        """list_exact returns all exact-match blocks."""
        registry = BlockedCommandRegistry()
        exact = registry.list_exact()
        assert len(exact) > 0
        assert "rm -rf /" in exact

    def test_list_patterns(self):
        """list_patterns returns all pattern blocks."""
        registry = BlockedCommandRegistry()
        patterns = registry.list_patterns()
        assert len(patterns) > 0
        assert all("regex" in p and "description" in p for p in patterns)

    def test_wget_pipe_blocked(self):
        """wget | sh (remote code execution) is blocked."""
        registry = BlockedCommandRegistry()
        assert registry.is_blocked("wget -O- | sh") is True
        assert registry.is_blocked("curl -sL | bash") is True


class TestSafetyGuardrailsBlocking:
    """Tests for safety guardrails blocking dangerous commands."""

    def _make_guardrails(self, level: SafetyLevel = SafetyLevel.STANDARD) -> SafetyGuardrails:
        return SafetyGuardrails(safety_level=level)

    def test_blocked_command_at_standard_level(self):
        """Dangerous commands are blocked at STANDARD level."""
        guardrails = self._make_guardrails(SafetyLevel.STANDARD)
        call = ToolCall(name="shell.execute", parameters={"command": "rm -rf /"})
        verdict = guardrails.evaluate(call)
        assert verdict.blocked is True

    def test_blocked_command_at_minimal_level(self):
        """Dangerous commands are blocked even at MINIMAL level."""
        guardrails = self._make_guardrails(SafetyLevel.MINIMAL)
        call = ToolCall(name="shell.execute", parameters={"command": ":(){ :|:& };:"})
        verdict = guardrails.evaluate(call)
        assert verdict.blocked is True

    def test_safe_command_allowed_at_standard(self):
        """Safe commands are allowed at STANDARD level."""
        guardrails = self._make_guardrails(SafetyLevel.STANDARD)
        call = ToolCall(name="read_file", parameters={"path": "README.md"})
        verdict = guardrails.evaluate(call)
        assert verdict.allowed is True

    def test_unrestricted_allows_everything(self):
        """UNRESTRICTED level allows everything."""
        guardrails = self._make_guardrails(SafetyLevel.UNRESTRICTED)
        call = ToolCall(name="shell.execute", parameters={"command": "rm -rf /"})
        verdict = guardrails.evaluate(call)
        assert verdict.allowed is True

    def test_review_level_requires_confirmation(self):
        """REVIEW level requires confirmation for everything."""
        guardrails = self._make_guardrails(SafetyLevel.REVIEW)
        call = ToolCall(name="read_file", parameters={"path": "README.md"})
        verdict = guardrails.evaluate(call)
        assert verdict.needs_confirmation is True

    def test_emergency_stop_blocks_all(self):
        """Emergency stop blocks all commands regardless of safety level."""
        from terminal_agent.support.safety.emergency_stop import EmergencyStop
        emergency = EmergencyStop()
        emergency.activate("Test emergency")

        guardrails = SafetyGuardrails(
            safety_level=SafetyLevel.UNRESTRICTED,
            emergency_stop=emergency,
        )
        call = ToolCall(name="read_file", parameters={"path": "README.md"})
        verdict = guardrails.evaluate(call)
        assert verdict.decision == SafetyDecision.EMERGENCY_STOP

    def test_high_risk_tool_needs_confirmation_at_standard(self):
        """High-risk tools need confirmation at STANDARD level."""
        guardrails = self._make_guardrails(SafetyLevel.STANDARD)
        call = ToolCall(name="execute_command", parameters={"command": "ls"})
        verdict = guardrails.evaluate(call)
        assert verdict.needs_confirmation is True

    def test_read_only_tools_allowed_at_moderate(self):
        """Read-only tools are allowed at MODERATE level."""
        guardrails = self._make_guardrails(SafetyLevel.MODERATE)
        call = ToolCall(name="read_file", parameters={"path": "file.txt"})
        verdict = guardrails.evaluate(call)
        assert verdict.allowed is True

    def test_multiple_dangerous_commands_all_blocked(self):
        """Multiple different dangerous commands are all blocked."""
        guardrails = self._make_guardrails(SafetyLevel.STANDARD)
        dangerous = [
            ToolCall(name="shell.execute", parameters={"command": "rm -rf /"}),
            ToolCall(name="shell.execute", parameters={"command": "mkfs /dev/sda"}),
            ToolCall(name="shell.execute", parameters={"command": "dd if=/dev/zero of=/dev/sda"}),
            ToolCall(name="shell.execute", parameters={"command": ":(){ :|:& };:"}),
            ToolCall(name="shell.execute", parameters={"command": "shutdown -h now"}),
        ]
        for call in dangerous:
            verdict = guardrails.evaluate(call)
            assert verdict.blocked is True, f"Should be blocked: {call.parameters['command']}"
