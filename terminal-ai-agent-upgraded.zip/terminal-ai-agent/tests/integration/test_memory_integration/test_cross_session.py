"""Integration tests: cross-session memory persistence.

Tests that memories persist across session boundaries and can be
recalled in new sessions.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.memory.short_term import ShortTermMemory
from terminal_agent.memory.working_memory import WorkingMemory
from terminal_agent.types import Memory, MemoryCategory


# ── Helpers ───────────────────────────────────────────────────────────

class InMemoryLongTermStore:
    """Simple in-memory long-term store for testing cross-session persistence."""

    def __init__(self):
        self._memories: dict[str, Memory] = {}
        self._counter = 0

    def store(self, content: str, category: MemoryCategory, metadata: dict | None = None) -> Memory:
        self._counter += 1
        mem = Memory(
            id=f"mem_{self._counter}",
            category=category,
            content=content,
            metadata=metadata or {},
            relevance_score=1.0,
        )
        self._memories[mem.id] = mem
        return mem

    def search(self, query: str, limit: int = 5) -> list[Memory]:
        """Simple keyword search for testing."""
        results = []
        query_lower = query.lower()
        for mem in self._memories.values():
            if query_lower in mem.content.lower():
                results.append(mem)
        results.sort(key=lambda m: m.relevance_score, reverse=True)
        return results[:limit]

    def get_all(self) -> list[Memory]:
        return list(self._memories.values())

    def count(self) -> int:
        return len(self._memories)

    def delete(self, memory_id: str) -> bool:
        if memory_id in self._memories:
            del self._memories[memory_id]
            return True
        return False


# ── Tests ─────────────────────────────────────────────────────────────

class TestCrossSessionMemory:
    """Cross-session memory persistence tests."""

    def test_memories_persist_after_session_clear(self):
        """Long-term memories survive session clearing."""
        store = InMemoryLongTermStore()

        # Session 1: Store memories
        store.store("User prefers Python over JavaScript", MemoryCategory.PREFERENCE)
        store.store("Project uses FastAPI with SQLAlchemy", MemoryCategory.PROJECT)

        # Clear session (simulates session end)
        stm = ShortTermMemory()
        wm = WorkingMemory()
        stm.clear()
        wm.clear()

        # Session 2: Recall memories
        results = store.search("Python")
        assert len(results) >= 1
        assert "Python" in results[0].content

    def test_recall_project_context_in_new_session(self):
        """Project context stored in session 1 is available in session 2."""
        store = InMemoryLongTermStore()

        # Session 1: Learn about the project
        store.store("This project uses pytest for testing", MemoryCategory.PROJECT)
        store.store("Database migrations use Alembic", MemoryCategory.PROJECT)
        store.store("CI/CD runs on GitHub Actions", MemoryCategory.PROJECT)

        # Session 2: New agent session
        stm2 = ShortTermMemory()
        stm2.add_turn("user", "How do I run the tests?")

        # Recall project context
        memories = store.search("testing")
        assert len(memories) >= 1
        assert "pytest" in memories[0].content.lower()

    def test_error_memory_across_sessions(self):
        """Errors from session 1 help avoid them in session 2."""
        store = InMemoryLongTermStore()

        # Session 1: Encounter an error
        store.store(
            "ERROR: pip install fails with 'Microsoft Visual C++ 14.0 required' on Windows for package xyz",
            MemoryCategory.ERROR,
        )

        # Session 2: Recall the error
        errors = store.search("pip install fails")
        assert len(errors) >= 1
        assert "Visual C++" in errors[0].content

    def test_pattern_learning_across_sessions(self):
        """Learned patterns from session 1 are available in session 2."""
        store = InMemoryLongTermStore()

        # Session 1: Learn a pattern
        store.store(
            "PATTERN: When user says 'deploy', run: git push, then trigger CI/CD pipeline",
            MemoryCategory.PATTERN,
        )

        # Session 2: Apply the pattern
        patterns = store.search("deploy")
        assert len(patterns) >= 1
        assert "git push" in patterns[0].content

    def test_multiple_sessions_incremental_learning(self):
        """Each session adds knowledge that builds on previous sessions."""
        store = InMemoryLongTermStore()

        # Session 1: Initial project setup
        store.store("Project is a REST API using FastAPI", MemoryCategory.PROJECT)

        # Session 2: Added authentication
        store.store("Authentication uses JWT tokens with RS256", MemoryCategory.PROJECT)

        # Session 3: Added database
        store.store("Database is PostgreSQL with asyncpg driver", MemoryCategory.PROJECT)

        # Verify accumulated knowledge
        all_memories = store.get_all()
        assert len(all_memories) == 3

        # Search for specific knowledge
        auth_memories = store.search("JWT")
        assert len(auth_memories) == 1

        db_memories = store.search("PostgreSQL")
        assert len(db_memories) == 1

    def test_preference_memory_persistence(self):
        """User preferences persist across sessions."""
        store = InMemoryLongTermStore()

        # Session 1: Learn preferences
        store.store("User prefers dark theme in terminal", MemoryCategory.PREFERENCE)
        store.store("User likes concise responses, no fluff", MemoryCategory.PREFERENCE)
        store.store("User's timezone is UTC+8", MemoryCategory.PREFERENCE)

        # Session 2: Apply preferences
        prefs = store.search("prefers")
        assert len(prefs) == 1  # dark theme

        concise = store.search("concise")
        assert len(concise) == 1  # concise responses

        tz = store.search("timezone")
        assert len(tz) == 1
        assert "UTC+8" in tz[0].content

    def test_tool_memory_across_sessions(self):
        """Tool usage patterns persist across sessions."""
        store = InMemoryLongTermStore()

        # Session 1: Learn tool patterns
        store.store(
            "TOOL: Use 'black' for Python formatting, not autopep8",
            MemoryCategory.TOOL,
        )
        store.store(
            "TOOL: Use 'ruff' for linting, much faster than pylint",
            MemoryCategory.TOOL,
        )

        # Session 2: Recall tool preferences
        tool_memories = store.search("formatting")
        assert len(tool_memories) >= 1
        assert "black" in tool_memories[0].content

    def test_memory_isolation_between_unrelated_queries(self):
        """Unrelated queries don't return irrelevant memories."""
        store = InMemoryLongTermStore()

        store.store("The database uses connection pooling", MemoryCategory.PROJECT)
        store.store("The frontend uses React with TypeScript", MemoryCategory.PROJECT)
        store.store("Deployment is via Docker containers", MemoryCategory.PROJECT)

        # Query about frontend shouldn't return database memories
        frontend = store.search("React")
        assert len(frontend) == 1
        assert "React" in frontend[0].content

        # Query about deployment shouldn't return frontend memories
        deploy = store.search("Docker")
        assert len(deploy) == 1
        assert "Docker" in deploy[0].content

    def test_memory_deletion_across_sessions(self):
        """Deleting a memory in one session makes it unavailable in the next."""
        store = InMemoryLongTermStore()

        mem = store.store("Temporary note: check server status", MemoryCategory.TASK)
        assert store.count() == 1

        # Delete the memory
        store.delete(mem.id)
        assert store.count() == 0

        # Session 2: Should not find it
        results = store.search("server status")
        assert len(results) == 0

    def test_memory_metadata_preservation(self):
        """Metadata is preserved across sessions."""
        store = InMemoryLongTermStore()

        mem = store.store(
            "Important configuration change: switched from SQLite to PostgreSQL",
            MemoryCategory.PROJECT,
            metadata={"session_id": "session_abc", "importance": "high"},
        )

        assert mem.metadata["session_id"] == "session_abc"
        assert mem.metadata["importance"] == "high"

        # Recall and verify metadata
        results = store.search("PostgreSQL")
        assert len(results) == 1
        assert results[0].metadata["importance"] == "high"
