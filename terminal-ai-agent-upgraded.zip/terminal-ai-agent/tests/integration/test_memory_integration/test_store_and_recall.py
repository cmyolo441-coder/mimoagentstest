"""Integration tests: memory store and recall.

Tests the full lifecycle of storing memories, recalling them by
query, and verifying the three-tier memory system works together.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.memory.short_term import ShortTermMemory
from terminal_agent.memory.working_memory import WorkingMemory
from terminal_agent.types import MemoryCategory


# ── Tests ─────────────────────────────────────────────────────────────

class TestShortTermStoreAndRecall:
    """Short-term memory store and recall tests."""

    def test_store_and_retrieve_single_turn(self):
        """Store a single turn and retrieve it."""
        stm = ShortTermMemory(max_turns=10)
        stm.add_turn("user", "How do I sort a list in Python?")

        turns = stm.get_turns()
        assert len(turns) == 1
        assert turns[0]["role"] == "user"
        assert "sort" in turns[0]["content"]

    def test_store_multiple_turns_in_order(self):
        """Multiple turns are stored in chronological order."""
        stm = ShortTermMemory(max_turns=10)
        stm.add_turn("user", "Hello")
        stm.add_turn("assistant", "Hi! How can I help?")
        stm.add_turn("user", "Sort a list")
        stm.add_turn("assistant", "Use sorted()")

        turns = stm.get_turns()
        assert len(turns) == 4
        assert turns[0]["role"] == "user"
        assert turns[3]["role"] == "assistant"

    def test_max_turns_eviction(self):
        """Oldest turns are evicted when max_turns is exceeded."""
        stm = ShortTermMemory(max_turns=3)
        stm.add_turn("user", "First")
        stm.add_turn("assistant", "Second")
        stm.add_turn("user", "Third")
        stm.add_turn("assistant", "Fourth")

        turns = stm.get_turns()
        assert len(turns) == 3
        assert "First" not in turns[0]["content"]
        assert turns[0]["content"] == "Second"

    def test_evicted_turns_available_for_consolidation(self):
        """Evicted turns are available via get_evicted()."""
        stm = ShortTermMemory(max_turns=2)
        stm.add_turn("user", "Old message")
        stm.add_turn("assistant", "Old response")
        stm.add_turn("user", "New message")

        evicted = stm.get_evicted()
        assert len(evicted) == 1
        assert evicted[0].content == "Old message"

    def test_get_as_messages_format(self):
        """get_as_messages returns LLM-compatible format."""
        stm = ShortTermMemory()
        stm.add_turn("system", "You are helpful")
        stm.add_turn("user", "Hello")
        stm.add_turn("assistant", "Hi!")

        messages = stm.get_as_messages()
        assert len(messages) == 3
        assert all("role" in m and "content" in m for m in messages)
        assert messages[0]["role"] == "system"

    def test_get_last_n_turns(self):
        """get_last returns only the last N turns."""
        stm = ShortTermMemory()
        for i in range(10):
            stm.add_turn("user", f"Message {i}")

        last_3 = stm.get_last(3)
        assert len(last_3) == 3
        assert last_3[0].content == "Message 7"
        assert last_3[2].content == "Message 9"

    def test_get_last_user_message(self):
        """get_last_user_message returns the most recent user message."""
        stm = ShortTermMemory()
        stm.add_turn("user", "What is Python?")
        stm.add_turn("assistant", "Python is a programming language.")
        stm.add_turn("user", "How do I use it?")

        assert stm.get_last_user_message() == "How do I use it?"

    def test_get_last_assistant_message(self):
        """get_last_assistant_message returns the most recent assistant message."""
        stm = ShortTermMemory()
        stm.add_turn("user", "Hello")
        stm.add_turn("assistant", "Hi there!")
        stm.add_turn("user", "Help me")

        assert stm.get_last_assistant_message() == "Hi there!"

    def test_clear_resets_all(self):
        """Clear removes all turns and evicted queue."""
        stm = ShortTermMemory(max_turns=2)
        stm.add_turn("user", "a")
        stm.add_turn("assistant", "b")
        stm.add_turn("user", "c")  # evicts "a"

        stm.clear()
        assert stm.count() == 0
        assert stm.get_evicted() == []

    def test_token_estimation(self):
        """Token estimation provides a rough count."""
        stm = ShortTermMemory()
        stm.add_turn("user", "hello world " * 100)  # ~1200 chars → ~300 tokens

        tokens = stm.estimate_tokens()
        assert tokens > 0
        assert tokens < 1000  # reasonable for ~1200 chars

    def test_summarize_for_context(self):
        """summarize_for_context produces a compact summary."""
        stm = ShortTermMemory()
        stm.add_turn("user", "I need help with Python sorting")
        stm.add_turn("assistant", "Sure! Use sorted() for lists.")
        stm.add_turn("user", "What about reverse sorting?")

        summary = stm.summarize_for_context(max_chars=500)
        assert "user" in summary
        assert "assistant" in summary
        assert len(summary) <= 500


class TestWorkingMemoryStoreAndRecall:
    """Working memory store and recall tests."""

    def test_set_and_get(self):
        """Basic set and get operations."""
        wm = WorkingMemory()
        wm.set("key1", "value1")
        assert wm.get("key1") == "value1"

    def test_get_missing_returns_default(self):
        """Getting a missing key returns the default."""
        wm = WorkingMemory()
        assert wm.get("missing") is None
        assert wm.get("missing", "fallback") == "fallback"

    def test_overwrite_key(self):
        """Setting the same key overwrites the value."""
        wm = WorkingMemory()
        wm.set("key", "old")
        wm.set("key", "new")
        assert wm.get("key") == "new"

    def test_ttl_expiration(self):
        """Entries with TTL expire after the specified duration."""
        import time
        wm = WorkingMemory()
        wm.set("temp", "data", ttl=0.1)  # 100ms TTL
        assert wm.get("temp") == "data"

        time.sleep(0.15)
        assert wm.get("temp") is None

    def test_file_storage(self):
        """Store and retrieve file contents."""
        wm = WorkingMemory()
        wm.add_file("main.py", "print('hello')\n")
        wm.add_file("utils.py", "def helper(): pass\n")

        assert wm.get_file("main.py") == "print('hello')\n"
        assert wm.get_file("utils.py") == "def helper(): pass\n"
        assert wm.get_file("nonexistent.py") is None

    def test_file_list(self):
        """get_file_list returns all stored file paths."""
        wm = WorkingMemory()
        wm.add_file("a.py", "")
        wm.add_file("b.py", "")
        wm.add_file("c.py", "")

        files = wm.get_file_list()
        assert len(files) == 3
        assert "a.py" in files

    def test_max_files_eviction(self):
        """Oldest files are evicted when max_files is exceeded."""
        wm = WorkingMemory(max_files=2)
        wm.add_file("first.py", "first")
        wm.add_file("second.py", "second")
        wm.add_file("third.py", "third")

        assert wm.get_file("first.py") is None  # evicted
        assert wm.get_file("second.py") == "second"
        assert wm.get_file("third.py") == "third"

    def test_scratch_pad(self):
        """Scratch pad stores ephemeral notes."""
        wm = WorkingMemory()
        wm.set_scratch("todo", "fix the bug")
        wm.set_scratch("note", "remember to test")

        assert wm.get_scratch("todo") == "fix the bug"
        assert wm.get_scratch("note") == "remember to test"
        assert wm.get_scratch("missing") is None

    def test_clear_resets_working_memory(self):
        """Clear removes all store, files, and scratch data."""
        wm = WorkingMemory()
        wm.set("key", "value")
        wm.add_file("file.py", "content")
        wm.set_scratch("note", "data")

        wm.clear()
        assert wm.get("key") is None
        assert wm.get_file("file.py") is None
        assert wm.get_scratch("note") is None


class TestMemoryIntegrationAcrossTiers:
    """Tests for cross-tier memory interactions."""

    def test_short_term_to_working_memory_flow(self):
        """Data flows from short-term to working memory."""
        stm = ShortTermMemory()
        wm = WorkingMemory()

        # Conversation happens
        stm.add_turn("user", "Remember that my database URL is sqlite:///prod.db")
        stm.add_turn("assistant", "Got it! I'll remember that.")

        # Extract key info to working memory
        last_user = stm.get_last_user_message()
        assert last_user is not None
        wm.set("db_url", "sqlite:///prod.db")

        # Later retrieval
        assert wm.get("db_url") == "sqlite:///prod.db"

    def test_working_memory_scratch_for_debugging(self):
        """Use scratch pad during debugging workflow."""
        stm = ShortTermMemory()
        wm = WorkingMemory()

        # Agent discovers a bug
        stm.add_turn("user", "The app crashes on startup")
        stm.add_turn("assistant", "Found it: missing import in main.py")

        # Store debugging notes
        wm.set_scratch("bug_location", "main.py:5")
        wm.set_scratch("bug_type", "ImportError")
        wm.set_scratch("fix_status", "applied")

        assert wm.get_scratch("bug_location") == "main.py:5"
        assert wm.get_scratch("bug_type") == "ImportError"

    def test_file_context_tracking(self):
        """Track which files the agent is actively working on."""
        wm = WorkingMemory()

        # Agent opens files for editing
        wm.add_file("src/auth.py", "def login(user, pass): pass\n")
        wm.add_file("src/models.py", "class User: pass\n")
        wm.add_file("tests/test_auth.py", "def test_login(): pass\n")

        active = wm.get_file_list()
        assert len(active) == 3
        assert "src/auth.py" in active

        # Agent can reference file contents
        assert "def login" in wm.get_file("src/auth.py")

    def test_conversation_context_building(self):
        """Build LLM context from conversation history."""
        stm = ShortTermMemory()
        stm.add_turn("system", "You are a Python expert.")
        stm.add_turn("user", "Write a function to parse JSON")
        stm.add_turn("assistant", "Here's a JSON parser:")
        stm.add_turn("user", "Now add error handling")

        messages = stm.get_as_messages(max_turns=4)
        assert len(messages) == 4
        assert messages[0]["role"] == "system"
        assert messages[-1]["content"] == "Now add error handling"

    def test_memory_stats(self):
        """Verify memory stats tracking."""
        stm = ShortTermMemory(max_turns=100)
        wm = WorkingMemory(max_files=10)

        # Populate
        for i in range(5):
            stm.add_turn("user", f"Message {i}")
        wm.set("a", 1)
        wm.set("b", 2)
        wm.add_file("test.py", "content")
        wm.set_scratch("note", "data")

        assert stm.count() == 5
        assert stm.estimate_tokens() > 0
        assert len(wm.get_file_list()) == 1
        assert wm.scratch_count() >= 1
