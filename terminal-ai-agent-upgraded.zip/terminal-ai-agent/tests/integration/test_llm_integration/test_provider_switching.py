"""Integration tests: LLM provider switching.

Tests that the LLM engine can switch between providers at runtime
and that the fallback chain works correctly.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.exceptions import ProviderNotAvailableError
from terminal_agent.llm.engine import LLMEngine
from terminal_agent.llm.fallback import FallbackChain, ProviderHealth
from terminal_agent.types import LLMResponse, ProviderConfig


# ── Helpers ───────────────────────────────────────────────────────────

def _make_provider(
    provider_id: str,
    model: str = "test-model",
    response_content: str = "response",
    fail: bool = False,
) -> MagicMock:
    """Create a mock LLM provider."""
    provider = MagicMock()
    provider.provider_id = provider_id
    provider.config = ProviderConfig(
        provider=provider_id,
        model=model,
        api_key="test-key",
        temperature=0.0,
        max_tokens=4096,
    )

    if fail:
        provider.send_prompt = AsyncMock(side_effect=ProviderNotAvailableError(f"{provider_id} down"))
    else:
        provider.send_prompt = AsyncMock(return_value=LLMResponse(
            content=response_content,
            tokens_in=50,
            tokens_out=100,
            cost=0.001,
            provider=provider_id,
            model=model,
        ))

    provider.send_prompt_streaming = AsyncMock(return_value=iter([]))
    provider.validate_config = AsyncMock(return_value=True)
    provider.get_model_info = MagicMock(return_value=MagicMock(
        streaming=True,
        tool_calling=True,
        max_context_tokens=128000,
        max_output_tokens=4096,
    ))
    provider.close = AsyncMock()
    return provider


# ── Tests ─────────────────────────────────────────────────────────────

class TestProviderSwitching:
    """Provider switching integration tests."""

    @pytest.mark.asyncio
    async def test_switch_primary_provider(self):
        """Switch primary provider and verify subsequent calls use it."""
        openai = _make_provider("openai", response_content="openai response")
        anthropic = _make_provider("anthropic", response_content="anthropic response")

        engine = LLMEngine([openai, anthropic])
        assert engine.primary_provider.provider_id == "openai"

        engine.switch_primary("anthropic")
        assert engine.primary_provider.provider_id == "anthropic"

        response = await engine.send_prompt([{"role": "user", "content": "test"}])
        assert response.provider == "anthropic"

    @pytest.mark.asyncio
    async def test_switch_to_nonexistent_provider_raises(self):
        """Switching to an unregistered provider raises an error."""
        openai = _make_provider("openai")
        engine = LLMEngine([openai])

        with pytest.raises(ProviderNotAvailableError, match="not registered"):
            engine.switch_primary("nonexistent")

    @pytest.mark.asyncio
    async def test_force_specific_provider(self):
        """Force a specific provider for a single call."""
        openai = _make_provider("openai", response_content="openai")
        anthropic = _make_provider("anthropic", response_content="anthropic")

        engine = LLMEngine([openai, anthropic])

        # Force anthropic for this call
        response = await engine.send_prompt(
            [{"role": "user", "content": "test"}],
            provider="anthropic",
        )
        assert response.provider == "anthropic"

    @pytest.mark.asyncio
    async def test_get_provider_by_id(self):
        """Retrieve a provider by its ID."""
        openai = _make_provider("openai")
        anthropic = _make_provider("anthropic")

        engine = LLMEngine([openai, anthropic])
        assert engine.get_provider("openai") is openai
        assert engine.get_provider("anthropic") is anthropic
        assert engine.get_provider("nonexistent") is None

    @pytest.mark.asyncio
    async def test_validate_all_providers(self):
        """Validate configuration for all providers."""
        p1 = _make_provider("openai")
        p2 = _make_provider("anthropic")
        p1.validate_config = AsyncMock(return_value=True)
        p2.validate_config = AsyncMock(return_value=False)

        engine = LLMEngine([p1, p2])
        results = await engine.validate_all()

        assert results["openai"] is True
        assert results["anthropic"] is False

    @pytest.mark.asyncio
    async def test_cost_tracking_across_providers(self):
        """Cost tracker records usage from all providers."""
        openai = _make_provider("openai", response_content="r1")
        anthropic = _make_provider("anthropic", response_content="r2")

        engine = LLMEngine([openai, anthropic])

        await engine.send_prompt([{"role": "user", "content": "test1"}], provider="openai")
        await engine.send_prompt([{"role": "user", "content": "test2"}], provider="anthropic")

        summary = engine.get_cost_summary()
        assert summary["total_calls"] == 2

    @pytest.mark.asyncio
    async def test_health_report(self):
        """Health report includes all providers."""
        p1 = _make_provider("openai")
        p2 = _make_provider("anthropic")

        engine = LLMEngine([p1, p2])
        report = engine.get_health_report()

        assert len(report) == 2
        provider_ids = {r["provider"] for r in report}
        assert "openai" in provider_ids
        assert "anthropic" in provider_ids

    @pytest.mark.asyncio
    async def test_response_callback_fires(self):
        """Response callback fires after each call."""
        p = _make_provider("openai")
        engine = LLMEngine([p])

        callback_results = []
        engine.on_response(lambda r: callback_results.append(r))

        await engine.send_prompt([{"role": "user", "content": "test"}])

        assert len(callback_results) == 1
        assert callback_results[0].content == "response"

    @pytest.mark.asyncio
    async def test_close_closes_all_providers(self):
        """Engine close releases all providers."""
        p1 = _make_provider("openai")
        p2 = _make_provider("anthropic")

        engine = LLMEngine([p1, p2])
        await engine.close()

        p1.close.assert_awaited_once()
        p2.close.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_engine_requires_at_least_one_provider(self):
        """Creating an engine with no providers raises ValueError."""
        with pytest.raises(ValueError, match="At least one provider"):
            LLMEngine([])
