"""Integration tests: LLM fallback chain.

Tests the fallback mechanism: when the primary provider fails,
the chain automatically tries the next provider.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.exceptions import (
    ProviderError,
    ProviderNotAvailableError,
    RateLimitError,
)
from terminal_agent.llm.fallback import FallbackChain, ProviderHealth
from terminal_agent.types import LLMResponse, ProviderConfig


# ── Helpers ───────────────────────────────────────────────────────────

def _make_provider(
    provider_id: str,
    response: str = "ok",
    fail: bool = False,
    error_type: str = "provider",
) -> MagicMock:
    provider = MagicMock()
    provider.provider_id = provider_id
    provider.config = ProviderConfig(provider=provider_id, model=f"{provider_id}-model", api_key="key")

    if fail:
        if error_type == "rate_limit":
            provider.send_prompt = AsyncMock(side_effect=RateLimitError(f"Rate limited by {provider_id}"))
        elif error_type == "not_available":
            provider.send_prompt = AsyncMock(side_effect=ProviderNotAvailableError(f"{provider_id} down"))
        else:
            provider.send_prompt = AsyncMock(side_effect=ProviderError(f"{provider_id} error"))
    else:
        provider.send_prompt = AsyncMock(return_value=LLMResponse(
            content=response, provider=provider_id, model=f"{provider_id}-model",
            tokens_in=10, tokens_out=20, cost=0.001,
        ))
    return provider


# ── Tests ─────────────────────────────────────────────────────────────

class TestFallbackChain:
    """Fallback chain integration tests."""

    @pytest.mark.asyncio
    async def test_primary_succeeds_no_fallback(self):
        """When primary succeeds, fallback is not invoked."""
        primary = _make_provider("openai", response="primary ok")
        fallback = _make_provider("anthropic", response="fallback ok")

        chain = FallbackChain([primary, fallback])
        result = await chain.send_prompt([{"role": "user", "content": "test"}])

        assert result.content == "primary ok"
        primary.send_prompt.assert_awaited_once()
        fallback.send_prompt.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_primary_fails_fallback_succeeds(self):
        """When primary fails, the chain falls back to the next provider."""
        primary = _make_provider("openai", fail=True, error_type="provider")
        fallback = _make_provider("anthropic", response="fallback ok")

        chain = FallbackChain([primary, fallback], max_retries_per_provider=1, retry_delay=0)
        result = await chain.send_prompt([{"role": "user", "content": "test"}])

        assert result.content == "fallback ok"
        assert fallback.send_prompt.await_count == 1

    @pytest.mark.asyncio
    async def test_all_providers_fail_raises(self):
        """When all providers fail, the chain raises the last error."""
        p1 = _make_provider("openai", fail=True, error_type="provider")
        p2 = _make_provider("anthropic", fail=True, error_type="provider")

        chain = FallbackChain([p1, p2], max_retries_per_provider=1, retry_delay=0)

        with pytest.raises(ProviderNotAvailableError, match="All providers"):
            await chain.send_prompt([{"role": "user", "content": "test"}])

    @pytest.mark.asyncio
    async def test_rate_limit_skips_to_next_provider(self):
        """Rate limit on primary immediately tries the next provider."""
        primary = _make_provider("openai", fail=True, error_type="rate_limit")
        fallback = _make_provider("anthropic", response="fallback ok")

        chain = FallbackChain([primary, fallback], max_retries_per_provider=1, retry_delay=0)
        result = await chain.send_prompt([{"role": "user", "content": "test"}])

        assert result.content == "fallback ok"

    @pytest.mark.asyncio
    async def test_three_provider_chain(self):
        """Chain with three providers: first two fail, third succeeds."""
        p1 = _make_provider("openai", fail=True, error_type="provider")
        p2 = _make_provider("anthropic", fail=True, error_type="provider")
        p3 = _make_provider("google", response="google ok")

        chain = FallbackChain([p1, p2, p3], max_retries_per_provider=1, retry_delay=0)
        result = await chain.send_prompt([{"role": "user", "content": "test"}])

        assert result.content == "google ok"

    @pytest.mark.asyncio
    async def test_health_tracking(self):
        """Health is tracked for each provider after calls."""
        p1 = _make_provider("openai", response="ok")
        p2 = _make_provider("anthropic", response="ok")

        chain = FallbackChain([p1, p2])
        await chain.send_prompt([{"role": "user", "content": "test"}])

        report = chain.get_health_report()
        assert len(report) == 2
        assert report[0]["total_calls"] == 1
        assert report[0]["success_rate"] == 1.0

    @pytest.mark.asyncio
    async def test_health_tracking_on_failure(self):
        """Failure is recorded in health tracking."""
        p1 = _make_provider("openai", fail=True, error_type="provider")
        p2 = _make_provider("anthropic", response="ok")

        chain = FallbackChain([p1, p2], max_retries_per_provider=1, retry_delay=0)
        await chain.send_prompt([{"role": "user", "content": "test"}])

        report = chain.get_health_report()
        openai_health = next(r for r in report if r["provider"] == "openai")
        assert openai_health["total_failures"] >= 1

    @pytest.mark.asyncio
    async def test_reset_health(self):
        """Reset health clears all failure counters."""
        p1 = _make_provider("openai", fail=True, error_type="provider")
        p2 = _make_provider("anthropic", response="ok")

        chain = FallbackChain([p1, p2], max_retries_per_provider=1, retry_delay=0)
        await chain.send_prompt([{"role": "user", "content": "test"}])

        chain.reset_health()
        report = chain.get_health_report()
        for r in report:
            assert r["consecutive_failures"] == 0

    @pytest.mark.asyncio
    async def test_primary_property(self):
        """Primary property returns the first provider."""
        p1 = _make_provider("openai")
        p2 = _make_provider("anthropic")

        chain = FallbackChain([p1, p2])
        assert chain.primary is p1

    @pytest.mark.asyncio
    async def test_active_provider_skips_disabled(self):
        """Active provider skips disabled providers."""
        p1 = _make_provider("openai")
        p2 = _make_provider("anthropic")

        chain = FallbackChain([p1, p2])
        # Manually disable p1
        chain._health[0].disabled_until = 9999999999.0

        assert chain.active_provider.provider_id == "anthropic"

    @pytest.mark.asyncio
    async def test_chain_requires_providers(self):
        """Creating a chain with no providers raises ValueError."""
        with pytest.raises(ValueError, match="At least one provider"):
            FallbackChain([])

    @pytest.mark.asyncio
    async def test_retry_on_transient_error(self):
        """Provider is retried on transient errors before fallback."""
        call_count = 0

        p1 = _make_provider("openai")
        original_side_effect = p1.send_prompt.side_effect

        async def fail_then_succeed(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise ProviderError("transient error")
            return LLMResponse(content="recovered", provider="openai", model="openai-model")

        p1.send_prompt = AsyncMock(side_effect=fail_then_succeed)
        p2 = _make_provider("anthropic", response="fallback")

        chain = FallbackChain([p1, p2], max_retries_per_provider=2, retry_delay=0)
        result = await chain.send_prompt([{"role": "user", "content": "test"}])

        assert result.content == "recovered"
        assert call_count == 2  # retried once
