# Integration tests for Terminal Agent.
