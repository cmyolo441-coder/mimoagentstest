"""Integration tests: code generation workflow.

Simulates the agent receiving a code-generation goal, calling the LLM
to produce code, writing files, and verifying the output.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import (
    LLMResponse,
    SafetyLevel,
    ToolCall,
    ToolResult,
    ToolResultStatus,
)


# ── Helpers ───────────────────────────────────────────────────────────

def _make_write_tool() -> MagicMock:
    tool = MagicMock()
    tool.name = "filesystem.write"
    tool.category = "filesystem"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "filesystem.write", "parameters": {}}
    written: dict[str, str] = {}

    async def _execute(**kwargs):
        path = kwargs.get("path", "")
        content = kwargs.get("content", "")
        written[path] = content
        return ToolResultBuilder.ok(f"Wrote {len(content)} bytes")

    tool.run = AsyncMock(side_effect=_execute)
    tool._written = written
    return tool


def _make_shell_tool() -> MagicMock:
    tool = MagicMock()
    tool.name = "shell.execute"
    tool.category = "shell"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "shell.execute", "parameters": {}}
    commands_run: list[str] = []

    async def _execute(**kwargs):
        cmd = kwargs.get("command", "")
        commands_run.append(cmd)
        if "pytest" in cmd:
            return ToolResultBuilder.ok("===== 5 passed =====")
        if "python" in cmd:
            return ToolResultBuilder.ok("OK")
        return ToolResultBuilder.ok("done")

    tool.run = AsyncMock(side_effect=_execute)
    tool._commands = commands_run
    return tool


def _make_llm_response(content: str = "", tool_calls: list | None = None) -> LLMResponse:
    return LLMResponse(
        content=content,
        tool_calls=tool_calls or [],
        tokens_in=100,
        tokens_out=200,
        cost=0.005,
        provider="test",
        model="test-model",
    )


# ── Tests ─────────────────────────────────────────────────────────────

class TestCodeGenerationWorkflow:
    """Code generation workflow integration tests."""

    @pytest.fixture
    def setup(self):
        registry = ToolRegistry()
        write_tool = _make_write_tool()
        shell_tool = _make_shell_tool()
        registry.register(write_tool)
        registry.register(shell_tool)
        dispatcher = ToolDispatcher(registry)
        return registry, dispatcher, write_tool, shell_tool

    @pytest.mark.asyncio
    async def test_generate_and_write_python_module(self, setup):
        """Generate a Python module and write it to disk."""
        registry, dispatcher, write_tool, shell_tool = setup

        # Simulate LLM producing code and a tool call
        generated_code = (
            "def fibonacci(n: int) -> list[int]:\n"
            "    \"\"\"Return first n Fibonacci numbers.\"\"\"\n"
            "    if n <= 0:\n"
            "        return []\n"
            "    seq = [0, 1]\n"
            "    while len(seq) < n:\n"
            "        seq.append(seq[-1] + seq[-2])\n"
            "    return seq[:n]\n"
        )

        # Write the generated code
        result = await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "fib.py", "content": generated_code})
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert "fib.py" in write_tool._written
        assert "fibonacci" in write_tool._written["fib.py"]

    @pytest.mark.asyncio
    async def test_generate_module_with_tests_and_run(self, setup):
        """Generate a module and its tests, then run the tests."""
        registry, dispatcher, write_tool, shell_tool = setup

        # Write module
        module_code = "def add(a, b):\n    return a + b\n"
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "math_utils.py", "content": module_code})
        )

        # Write tests
        test_code = (
            "from math_utils import add\n\n"
            "def test_add():\n"
            "    assert add(1, 2) == 3\n"
            "    assert add(-1, 1) == 0\n"
        )
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "test_math_utils.py", "content": test_code})
        )

        # Run tests
        result = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "pytest test_math_utils.py -v"})
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert "passed" in result.output

    @pytest.mark.asyncio
    async def test_generate_api_endpoint(self, setup):
        """Generate a REST API endpoint file."""
        registry, dispatcher, write_tool, shell_tool = setup

        api_code = '''from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()

class Item(BaseModel):
    name: str
    price: float

@router.post("/items/")
async def create_item(item: Item):
    return {"id": 1, **item.dict()}

@router.get("/items/{item_id}")
async def get_item(item_id: int):
    if item_id < 1:
        raise HTTPException(status_code=404, detail="Not found")
    return {"id": item_id, "name": "example", "price": 9.99}
'''

        result = await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "api/routes.py", "content": api_code})
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert "APIRouter" in write_tool._written["api/routes.py"]

    @pytest.mark.asyncio
    async def test_generate_and_format_workflow(self, setup):
        """Generate code, then run formatter."""
        registry, dispatcher, write_tool, shell_tool = setup

        # Write unformatted code
        code = "def foo( x,y ):return x+y"
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "messy.py", "content": code})
        )

        # Run black formatter
        result = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "python -m black messy.py"})
        )
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_multi_file_generation_with_dependency(self, setup):
        """Generate multiple files where one imports from another."""
        registry, dispatcher, write_tool, shell_tool = setup

        # Base module
        base_code = "DATABASE_URL = 'sqlite:///app.db'\nDEBUG = True\n"
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "config.py", "content": base_code})
        )

        # Module that imports base
        app_code = "from config import DATABASE_URL, DEBUG\n\nprint(f'Connecting to {DATABASE_URL}')\n"
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "app.py", "content": app_code})
        )

        # Verify both files written
        assert "config.py" in write_tool._written
        assert "app.py" in write_tool._written
        assert "from config import" in write_tool._written["app.py"]

        # Run app
        result = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "python app.py"})
        )
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_llm_response_parsing_for_tool_calls(self):
        """Verify LLMResponse with tool_calls can drive the dispatcher."""
        registry = ToolRegistry()
        write_tool = _make_write_tool()
        registry.register(write_tool)
        dispatcher = ToolDispatcher(registry)

        # Simulate an LLM response that includes a tool call
        llm_response = _make_llm_response(
            content="I'll create the file for you.",
            tool_calls=[
                ToolCall(name="filesystem.write", parameters={"path": "output.py", "content": "x = 42\n"})
            ],
        )

        # Execute the tool call from the LLM response
        for tc in llm_response.tool_calls:
            result = await dispatcher.dispatch(tc)
            assert result.status == ToolResultStatus.SUCCESS

        assert "output.py" in write_tool._written
