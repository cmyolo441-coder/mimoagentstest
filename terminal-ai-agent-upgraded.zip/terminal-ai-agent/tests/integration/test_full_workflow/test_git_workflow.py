"""Integration tests: git workflow.

Tests the full git workflow: init → add → commit → branch → merge,
using mock tools wired through the dispatcher.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResultStatus


# ── Helpers ───────────────────────────────────────────────────────────

class GitState:
    """Simulated git repository state."""

    def __init__(self):
        self.initialized = False
        self.current_branch = "main"
        self.branches: dict[str, list[str]] = {"main": []}
        self.staged: list[str] = []
        self.committed: list[list[str]] = []
        self.remotes: dict[str, str] = {}

    def status_summary(self) -> str:
        lines = [f"On branch {self.current_branch}"]
        if self.staged:
            lines.append("Changes to be committed:")
            for f in self.staged:
                lines.append(f"  new file:   {f}")
        else:
            lines.append("nothing to commit, working tree clean")
        return "\n".join(lines)


def _make_git_tool(state: GitState) -> MagicMock:
    tool = MagicMock()
    tool.name = "git"
    tool.category = "git"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "git", "parameters": {}}

    async def _execute(**kwargs):
        action = kwargs.get("action", kwargs.get("command", ""))

        if action == "init":
            state.initialized = True
            return ToolResultBuilder.ok("Initialized empty Git repository")

        if action == "add":
            files = kwargs.get("files", [])
            state.staged.extend(files)
            return ToolResultBuilder.ok(f"Added {len(files)} file(s)")

        if action == "commit":
            msg = kwargs.get("message", "no message")
            state.committed.append(list(state.staged))
            state.staged = []
            return ToolResultBuilder.ok(f"[{state.current_branch} abc1234] {msg}")

        if action == "status":
            return ToolResultBuilder.ok(state.status_summary())

        if action == "branch":
            name = kwargs.get("name", "")
            if name:
                state.branches[name] = list(state.branches.get(state.current_branch, []))
                return ToolResultBuilder.ok(f"Created branch '{name}'")
            return ToolResultBuilder.ok("\n".join(f"  {b}" for b in state.branches))

        if action == "checkout":
            branch = kwargs.get("branch", "")
            if branch in state.branches:
                state.current_branch = branch
                return ToolResultBuilder.ok(f"Switched to branch '{branch}'")
            return ToolResultBuilder.err(f"Branch '{branch}' not found")

        if action == "merge":
            branch = kwargs.get("branch", "")
            if branch in state.branches:
                state.committed.append([f"merge-{branch}"])
                return ToolResultBuilder.ok(f"Merge made by 'ort' strategy")
            return ToolResultBuilder.err(f"Cannot merge '{branch}'")

        if action == "push":
            remote = kwargs.get("remote", "origin")
            return ToolResultBuilder.ok(f"To {remote}: pushed {state.current_branch}")

        if action == "log":
            return ToolResultBuilder.ok("abc1234 Initial commit\ndef5678 Second commit")

        return ToolResultBuilder.err(f"Unknown git action: {action}")

    tool.run = AsyncMock(side_effect=_execute)
    tool._state = state
    return tool


def _make_write_tool() -> MagicMock:
    tool = MagicMock()
    tool.name = "filesystem.write"
    tool.category = "filesystem"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "filesystem.write", "parameters": {}}

    async def _execute(**kwargs):
        return ToolResultBuilder.ok(f"Wrote to {kwargs.get('path', '?')}")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


# ── Tests ─────────────────────────────────────────────────────────────

class TestGitWorkflow:
    """Git workflow integration tests."""

    @pytest.fixture
    def git_setup(self):
        state = GitState()
        git_tool = _make_git_tool(state)
        write_tool = _make_write_tool()
        registry = ToolRegistry()
        registry.register(git_tool)
        registry.register(write_tool)
        dispatcher = ToolDispatcher(registry)
        return dispatcher, git_tool, write_tool, state

    @pytest.mark.asyncio
    async def test_init_add_commit_workflow(self, git_setup):
        """Full init → add → commit workflow."""
        dispatcher, git_tool, write_tool, state = git_setup

        # Init
        r1 = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "init"})
        )
        assert r1.status == ToolResultStatus.SUCCESS
        assert state.initialized is True

        # Write a file
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "README.md", "content": "# Project\n"})
        )

        # Add
        r2 = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "add", "files": ["README.md"]})
        )
        assert r2.status == ToolResultStatus.SUCCESS
        assert "README.md" in state.staged

        # Commit
        r3 = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "commit", "message": "Initial commit"})
        )
        assert r3.status == ToolResultStatus.SUCCESS
        assert len(state.committed) == 1
        assert len(state.staged) == 0

    @pytest.mark.asyncio
    async def test_branch_and_merge_workflow(self, git_setup):
        """Create feature branch, make changes, merge back."""
        dispatcher, git_tool, _, state = git_setup

        # Init and initial commit
        await dispatcher.dispatch(ToolCall(name="git", parameters={"action": "init"}))
        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "add", "files": ["main.py"]})
        )
        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "commit", "message": "Initial"})
        )

        # Create feature branch
        r = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "branch", "name": "feature/auth"})
        )
        assert r.status == ToolResultStatus.SUCCESS
        assert "feature/auth" in state.branches

        # Checkout feature branch
        r = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "checkout", "branch": "feature/auth"})
        )
        assert r.status == ToolResultStatus.SUCCESS
        assert state.current_branch == "feature/auth"

        # Make changes on feature branch
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "auth.py", "content": "def login(): pass\n"})
        )
        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "add", "files": ["auth.py"]})
        )
        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "commit", "message": "Add auth module"})
        )

        # Switch back to main
        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "checkout", "branch": "main"})
        )
        assert state.current_branch == "main"

        # Merge
        r = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "merge", "branch": "feature/auth"})
        )
        assert r.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_multiple_commits(self, git_setup):
        """Make multiple sequential commits."""
        dispatcher, _, _, state = git_setup

        await dispatcher.dispatch(ToolCall(name="git", parameters={"action": "init"}))

        for i in range(5):
            await dispatcher.dispatch(
                ToolCall(name="filesystem.write", parameters={"path": f"file_{i}.py", "content": f"# File {i}\n"})
            )
            await dispatcher.dispatch(
                ToolCall(name="git", parameters={"action": "add", "files": [f"file_{i}.py"]})
            )
            await dispatcher.dispatch(
                ToolCall(name="git", parameters={"action": "commit", "message": f"Add file {i}"})
            )

        assert len(state.committed) == 5

    @pytest.mark.asyncio
    async def test_git_status_reflects_changes(self, git_setup):
        """Git status reflects staged files."""
        dispatcher, _, _, state = git_setup

        await dispatcher.dispatch(ToolCall(name="git", parameters={"action": "init"}))
        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "add", "files": ["new_file.py"]})
        )

        r = await dispatcher.dispatch(ToolCall(name="git", parameters={"action": "status"}))
        assert r.status == ToolResultStatus.SUCCESS
        assert "new_file.py" in r.output

    @pytest.mark.asyncio
    async def test_push_workflow(self, git_setup):
        """Full workflow ending with push."""
        dispatcher, _, _, state = git_setup

        await dispatcher.dispatch(ToolCall(name="git", parameters={"action": "init"}))
        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "add", "files": ["main.py"]})
        )
        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "commit", "message": "Initial commit"})
        )

        r = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "push", "remote": "origin"})
        )
        assert r.status == ToolResultStatus.SUCCESS
        assert "pushed" in r.output

    @pytest.mark.asyncio
    async def test_checkout_nonexistent_branch_fails(self, git_setup):
        """Checking out a nonexistent branch returns an error."""
        dispatcher, _, _, state = git_setup
        await dispatcher.dispatch(ToolCall(name="git", parameters={"action": "init"}))

        r = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "checkout", "branch": "nonexistent"})
        )
        assert r.status == ToolResultStatus.ERROR

    @pytest.mark.asyncio
    async def test_git_log(self, git_setup):
        """Git log returns commit history."""
        dispatcher, _, _, _ = git_setup

        r = await dispatcher.dispatch(ToolCall(name="git", parameters={"action": "log"}))
        assert r.status == ToolResultStatus.SUCCESS
        assert "commit" in r.output.lower() or "abc1234" in r.output
