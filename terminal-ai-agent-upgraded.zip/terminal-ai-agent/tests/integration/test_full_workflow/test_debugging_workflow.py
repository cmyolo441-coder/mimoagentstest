"""Integration tests: debugging workflow.

Simulates an agent debugging a failing test — reading files, searching
for errors, applying fixes, and re-running to verify.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResultStatus


# ── Helpers ───────────────────────────────────────────────────────────

def _make_read_tool(file_contents: dict[str, str]) -> MagicMock:
    tool = MagicMock()
    tool.name = "filesystem.read"
    tool.category = "filesystem"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "filesystem.read", "parameters": {}}

    async def _execute(**kwargs):
        path = kwargs.get("path", "")
        content = file_contents.get(path)
        if content is None:
            return ToolResultBuilder.err(f"File not found: {path}", exit_code=2)
        return ToolResultBuilder.ok(content)

    tool.run = AsyncMock(side_effect=_execute)
    return tool


def _make_edit_tool(file_contents: dict[str, str]) -> MagicMock:
    tool = MagicMock()
    tool.name = "filesystem.edit"
    tool.category = "filesystem"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "filesystem.edit", "parameters": {}}
    edits_applied: list[dict] = []

    async def _execute(**kwargs):
        path = kwargs.get("path", "")
        old = kwargs.get("old_text", kwargs.get("old", ""))
        new = kwargs.get("new_text", kwargs.get("new", ""))
        edits_applied.append({"path": path, "old": old, "new": new})
        if path in file_contents and old in file_contents[path]:
            file_contents[path] = file_contents[path].replace(old, new, 1)
            return ToolResultBuilder.ok("Edit applied")
        return ToolResultBuilder.err("Old text not found", exit_code=1)

    tool.run = AsyncMock(side_effect=_execute)
    tool._edits = edits_applied
    return tool


def _make_search_tool(file_contents: dict[str, str]) -> MagicMock:
    tool = MagicMock()
    tool.name = "search.code"
    tool.category = "search"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "search.code", "parameters": {}}

    async def _execute(**kwargs):
        query = kwargs.get("query", kwargs.get("pattern", ""))
        results = []
        for path, content in file_contents.items():
            for i, line in enumerate(content.splitlines(), 1):
                if query.lower() in line.lower():
                    results.append(f"{path}:{i}: {line}")
        return ToolResultBuilder.ok("\n".join(results) if results else "No matches")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


def _make_shell_tool(scenario: str = "pass") -> MagicMock:
    tool = MagicMock()
    tool.name = "shell.execute"
    tool.category = "shell"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "shell.execute", "parameters": {}}
    run_count = {"n": 0}

    async def _execute(**kwargs):
        run_count["n"] += 1
        cmd = kwargs.get("command", "")
        if "pytest" in cmd:
            if scenario == "fail_first" and run_count["n"] == 1:
                return ToolResultBuilder.ok(
                    "FAILED test_add.py::test_add - AssertionError: assert 3 == 4\n"
                    "===== 1 failed, 0 passed ====="
                )
            return ToolResultBuilder.ok("===== 5 passed =====")
        return ToolResultBuilder.ok("ok")

    tool.run = AsyncMock(side_effect=_execute)
    tool._run_count = run_count
    return tool


# ── Tests ─────────────────────────────────────────────────────────────

class TestDebuggingWorkflow:
    """Debugging workflow integration tests."""

    @pytest.fixture
    def buggy_project(self):
        """A project with a deliberate off-by-one bug."""
        files = {
            "calculator.py": (
                "def add(a, b):\n"
                "    return a + b + 1  # BUG: off-by-one\n"
            ),
            "test_calculator.py": (
                "from calculator import add\n\n"
                "def test_add():\n"
                "    assert add(1, 2) == 3\n"
            ),
        }
        return files

    @pytest.mark.asyncio
    async def test_read_failing_test_output(self, buggy_project):
        """Read the source and test files to understand the bug."""
        read_tool = _make_read_tool(buggy_project)
        registry = ToolRegistry()
        registry.register(read_tool)
        dispatcher = ToolDispatcher(registry)

        # Read the buggy source
        result = await dispatcher.dispatch(
            ToolCall(name="filesystem.read", parameters={"path": "calculator.py"})
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert "return a + b + 1" in result.output

    @pytest.mark.asyncio
    async def test_search_for_bug_pattern(self, buggy_project):
        """Search code for the suspicious pattern."""
        search_tool = _make_search_tool(buggy_project)
        registry = ToolRegistry()
        registry.register(search_tool)
        dispatcher = ToolDispatcher(registry)

        result = await dispatcher.dispatch(
            ToolCall(name="search.code", parameters={"query": "return a + b"})
        )
        assert result.status == ToolResultStatus.SUCCESS
        assert "calculator.py" in result.output

    @pytest.mark.asyncio
    async def test_apply_fix_and_verify(self, buggy_project):
        """Apply a fix and re-run tests."""
        read_tool = _make_read_tool(buggy_project)
        edit_tool = _make_edit_tool(buggy_project)
        shell_tool = _make_shell_tool(scenario="fail_first")
        registry = ToolRegistry()
        registry.register(read_tool)
        registry.register(edit_tool)
        registry.register(shell_tool)
        dispatcher = ToolDispatcher(registry)

        # Step 1: Run tests (fail)
        test_result = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "pytest test_calculator.py"})
        )
        assert "FAILED" in test_result.output

        # Step 2: Read source
        read_result = await dispatcher.dispatch(
            ToolCall(name="filesystem.read", parameters={"path": "calculator.py"})
        )
        assert read_result.status == ToolResultStatus.SUCCESS

        # Step 3: Apply fix
        fix_result = await dispatcher.dispatch(
            ToolCall(
                name="filesystem.edit",
                parameters={
                    "path": "calculator.py",
                    "old_text": "return a + b + 1  # BUG: off-by-one",
                    "new_text": "return a + b",
                },
            )
        )
        assert fix_result.status == ToolResultStatus.SUCCESS
        assert len(edit_tool._edits) == 1

        # Step 4: Re-run tests (pass)
        verify_result = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "pytest test_calculator.py"})
        )
        assert verify_result.status == ToolResultStatus.SUCCESS
        assert "passed" in verify_result.output

    @pytest.mark.asyncio
    async def test_multi_step_debug_with_multiple_edits(self, buggy_project):
        """Debug scenario requiring multiple edits."""
        buggy_project["calculator.py"] = (
            "def add(a, b):\n"
            "    return a + b + 1  # BUG\n\n"
            "def multiply(a, b):\n"
            "    return a * b + 1  # BUG\n"
        )

        edit_tool = _make_edit_tool(buggy_project)
        shell_tool = _make_shell_tool()
        registry = ToolRegistry()
        registry.register(edit_tool)
        registry.register(shell_tool)
        dispatcher = ToolDispatcher(registry)

        # Fix both bugs
        for old, new in [
            ("return a + b + 1  # BUG", "return a + b"),
            ("return a * b + 1  # BUG", "return a * b"),
        ]:
            result = await dispatcher.dispatch(
                ToolCall(
                    name="filesystem.edit",
                    parameters={"path": "calculator.py", "old_text": old, "new_text": new},
                )
            )
            assert result.status == ToolResultStatus.SUCCESS

        assert len(edit_tool._edits) == 2

        # Verify tests pass
        result = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "pytest"})
        )
        assert result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_debug_with_import_error(self):
        """Debug an import error workflow."""
        files = {
            "app.py": "from utils import helper\nprint(helper())\n",
            "utils.py": "# missing helper function\n",
        }
        read_tool = _make_read_tool(files)
        edit_tool = _make_edit_tool(files)
        shell_tool = _make_shell_tool()
        registry = ToolRegistry()
        registry.register(read_tool)
        registry.register(edit_tool)
        registry.register(shell_tool)
        dispatcher = ToolDispatcher(registry)

        # Read the file causing the error
        result = await dispatcher.dispatch(
            ToolCall(name="filesystem.read", parameters={"path": "utils.py"})
        )
        assert result.status == ToolResultStatus.SUCCESS

        # Add the missing function
        fix_result = await dispatcher.dispatch(
            ToolCall(
                name="filesystem.edit",
                parameters={
                    "path": "utils.py",
                    "old_text": "# missing helper function",
                    "new_text": "def helper():\n    return 'fixed'",
                },
            )
        )
        assert fix_result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_debug_preserves_surrounding_code(self, buggy_project):
        """Verify that edits don't corrupt surrounding code."""
        buggy_project["module.py"] = (
            "import os\n\n"
            "CONSTANT = 42\n\n"
            "def buggy():\n"
            "    return None  # should return value\n\n"
            "def helper():\n"
            "    return True\n"
        )
        edit_tool = _make_edit_tool(buggy_project)
        registry = ToolRegistry()
        registry.register(edit_tool)
        dispatcher = ToolDispatcher(registry)

        result = await dispatcher.dispatch(
            ToolCall(
                name="filesystem.edit",
                parameters={
                    "path": "module.py",
                    "old_text": "    return None  # should return value",
                    "new_text": "    return 'fixed'",
                },
            )
        )
        assert result.status == ToolResultStatus.SUCCESS

        # Verify surrounding code intact
        content = buggy_project["module.py"]
        assert "import os" in content
        assert "CONSTANT = 42" in content
        assert "def helper" in content
        assert "return True" in content
