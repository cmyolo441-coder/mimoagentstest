"""Integration tests: full file-creation workflow.

Tests the end-to-end flow from receiving a file-creation goal through
tool dispatch, filesystem writes, and verification — without hitting a
real LLM.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import (
    LLMResponse,
    SafetyLevel,
    SessionStatus,
    ToolCall,
    ToolResult,
    ToolResultStatus,
)


# ── Helpers ───────────────────────────────────────────────────────────

def _mock_filesystem_tool(name: str = "filesystem.write") -> MagicMock:
    """Create a mock filesystem tool that records writes."""
    tool = MagicMock()
    tool.name = name
    tool.category = "filesystem"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": name, "description": "Write file", "parameters": {}}

    async def _execute(**kwargs):
        path = kwargs.get("path", "")
        content = kwargs.get("content", "")
        return ToolResultBuilder.ok(
            f"Wrote {len(content)} bytes to {path}",
            path=path,
            bytes_written=len(content),
        )

    tool.run = AsyncMock(side_effect=_execute)
    tool.execute = AsyncMock(side_effect=_execute)
    return tool


def _mock_read_tool() -> MagicMock:
    tool = MagicMock()
    tool.name = "filesystem.read"
    tool.category = "filesystem"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "filesystem.read", "description": "Read file", "parameters": {}}

    async def _execute(**kwargs):
        return ToolResultBuilder.ok("file content here")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


def _mock_shell_tool() -> MagicMock:
    tool = MagicMock()
    tool.name = "shell.execute"
    tool.category = "shell"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "shell.execute", "description": "Run command", "parameters": {}}

    async def _execute(**kwargs):
        return ToolResultBuilder.ok("command output")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


# ── Tests ─────────────────────────────────────────────────────────────

class TestFileCreationWorkflow:
    """End-to-end file creation workflow tests."""

    @pytest.fixture
    def registry_with_fs(self) -> tuple[ToolRegistry, MagicMock]:
        """Registry with filesystem write + read tools."""
        registry = ToolRegistry()
        write_tool = _mock_filesystem_tool()
        read_tool = _mock_read_tool()
        registry.register(write_tool)
        registry.register(read_tool)
        return registry, write_tool

    @pytest.mark.asyncio
    async def test_single_file_creation(self, registry_with_fs):
        """Create a single file through the dispatcher."""
        registry, write_tool = registry_with_fs
        dispatcher = ToolDispatcher(registry)

        call = ToolCall(
            name="filesystem.write",
            parameters={"path": "src/main.py", "content": "print('hello')\n"},
        )
        result = await dispatcher.dispatch(call)

        assert result.status == ToolResultStatus.SUCCESS
        write_tool.run.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_multiple_file_creation_sequence(self, registry_with_fs):
        """Create multiple files in sequence (simulating a project scaffold)."""
        registry, write_tool = registry_with_fs
        dispatcher = ToolDispatcher(registry)

        files = [
            ("src/__init__.py", ""),
            ("src/main.py", "def main(): pass\n"),
            ("tests/test_main.py", "def test_main(): assert True\n"),
            ("pyproject.toml", "[project]\nname = 'test'\n"),
        ]

        results = []
        for path, content in files:
            call = ToolCall(
                name="filesystem.write",
                parameters={"path": path, "content": content},
            )
            result = await dispatcher.dispatch(call)
            results.append(result)

        assert all(r.status == ToolResultStatus.SUCCESS for r in results)
        assert len(results) == 4
        assert write_tool.run.await_count == 4

    @pytest.mark.asyncio
    async def test_create_then_read_workflow(self, registry_with_fs):
        """Create a file then read it back through the dispatcher."""
        registry, write_tool = registry_with_fs
        read_tool = registry.get("filesystem.read")
        dispatcher = ToolDispatcher(registry)

        # Write
        write_call = ToolCall(
            name="filesystem.write",
            parameters={"path": "config.json", "content": '{"key": "value"}'},
        )
        write_result = await dispatcher.dispatch(write_call)
        assert write_result.status == ToolResultStatus.SUCCESS

        # Read
        read_call = ToolCall(name="filesystem.read", parameters={"path": "config.json"})
        read_result = await dispatcher.dispatch(read_call)
        assert read_result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_file_creation_with_shell_verification(self):
        """Create a file, then verify via shell command."""
        registry = ToolRegistry()
        write_tool = _mock_filesystem_tool()
        shell_tool = _mock_shell_tool()
        registry.register(write_tool)
        registry.register(shell_tool)
        dispatcher = ToolDispatcher(registry)

        # Create file
        write_call = ToolCall(
            name="filesystem.write",
            parameters={"path": "output.txt", "content": "hello world"},
        )
        write_result = await dispatcher.dispatch(write_call)
        assert write_result.status == ToolResultStatus.SUCCESS

        # Verify with shell
        verify_call = ToolCall(
            name="shell.execute",
            parameters={"command": "cat output.txt"},
        )
        verify_result = await dispatcher.dispatch(verify_call)
        assert verify_result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_file_creation_with_error_recovery(self):
        """Simulate a write failure then retry succeeds."""
        registry = ToolRegistry()
        write_tool = _mock_filesystem_tool()

        call_count = 0
        original_run = write_tool.run

        async def flaky_execute(**kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return ToolResultBuilder.err("Permission denied", exit_code=13)
            return ToolResultBuilder.ok("Success on retry")

        write_tool.run = AsyncMock(side_effect=flaky_execute)
        registry.register(write_tool)
        dispatcher = ToolDispatcher(registry)

        # First attempt fails
        call = ToolCall(name="filesystem.write", parameters={"path": "/root/test", "content": "x"})
        result1 = await dispatcher.dispatch(call)
        assert result1.status == ToolResultStatus.ERROR

        # Retry succeeds
        result2 = await dispatcher.dispatch(call)
        assert result2.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_unknown_tool_returns_error(self):
        """Dispatching an unknown tool returns an error result."""
        registry = ToolRegistry()
        dispatcher = ToolDispatcher(registry)

        call = ToolCall(name="nonexistent.tool", parameters={})
        result = await dispatcher.dispatch(call)

        assert result.status == ToolResultStatus.ERROR
        assert "Unknown tool" in result.error

    @pytest.mark.asyncio
    async def test_full_scaffold_workflow(self):
        """Simulate a full project scaffolding workflow."""
        registry = ToolRegistry()
        write_tool = _mock_filesystem_tool()
        shell_tool = _mock_shell_tool()
        registry.register(write_tool)
        registry.register(shell_tool)
        dispatcher = ToolDispatcher(registry)

        # Step 1: Create directory structure files
        scaffold_files = [
            ("myproject/__init__.py", ""),
            ("myproject/app.py", "from flask import Flask\napp = Flask(__name__)\n"),
            ("myproject/models.py", "# Database models\n"),
            ("myproject/routes.py", "# API routes\n"),
            ("requirements.txt", "flask>=2.0\nsqlalchemy>=1.4\n"),
            ("Dockerfile", "FROM python:3.11-slim\nCOPY . /app\n"),
        ]

        for path, content in scaffold_files:
            result = await dispatcher.dispatch(
                ToolCall(name="filesystem.write", parameters={"path": path, "content": content})
            )
            assert result.status == ToolResultStatus.SUCCESS

        # Step 2: Run pip install (simulated)
        result = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "pip install -r requirements.txt"})
        )
        assert result.status == ToolResultStatus.SUCCESS

        # Verify all tools were called the expected number of times
        assert write_tool.run.await_count == 6
        assert shell_tool.run.await_count == 1
