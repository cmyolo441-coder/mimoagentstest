"""Integration tests: git ↔ code tool interaction.

Tests workflows that combine git operations with code analysis
tools — e.g., commit code, then check for issues.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResultStatus


# ── Helpers ───────────────────────────────────────────────────────────

def _make_git_tool() -> MagicMock:
    tool = MagicMock()
    tool.name = "git"
    tool.category = "git"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "git", "parameters": {}}
    state = {"staged": [], "committed": 0, "branch": "main"}

    async def _execute(**kwargs):
        action = kwargs.get("action", "")
        if action == "add":
            files = kwargs.get("files", [])
            state["staged"].extend(files)
            return ToolResultBuilder.ok(f"Staged {len(files)} files")
        if action == "commit":
            state["committed"] += 1
            state["staged"].clear()
            return ToolResultBuilder.ok(f"[{state['branch']}] committed")
        if action == "diff":
            return ToolResultBuilder.ok("--- a/file.py\n+++ b/file.py\n@@ -1 +1 @@\n-old\n+new")
        if action == "log":
            return ToolResultBuilder.ok("abc1234 feat: add auth\ndef5678 fix: typo")
        if action == "blame":
            return ToolResultBuilder.ok("abc1234 (dev 2024-01-01) def main():")
        return ToolResultBuilder.ok("")

    tool.run = AsyncMock(side_effect=_execute)
    tool._state = state
    return tool


def _make_code_analysis_tool() -> MagicMock:
    """Mock code analysis tool that checks for issues."""
    tool = MagicMock()
    tool.name = "code.analyze"
    tool.category = "code"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "code.analyze", "parameters": {}}
    issues_db: dict[str, list[str]] = {}

    async def _execute(**kwargs):
        path = kwargs.get("path", kwargs.get("file", ""))
        issues = issues_db.get(path, [])
        if issues:
            return ToolResultBuilder.ok(f"Found {len(issues)} issues:\n" + "\n".join(issues))
        return ToolResultBuilder.ok("No issues found")

    tool.run = AsyncMock(side_effect=_execute)
    tool._issues = issues_db
    return tool


def _make_write_tool() -> MagicMock:
    tool = MagicMock()
    tool.name = "filesystem.write"
    tool.category = "filesystem"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "filesystem.write", "parameters": {}}

    async def _execute(**kwargs):
        return ToolResultBuilder.ok(f"Wrote {kwargs.get('path', '?')}")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


def _make_lint_tool() -> MagicMock:
    tool = MagicMock()
    tool.name = "code.lint"
    tool.category = "code"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "code.lint", "parameters": {}}

    async def _execute(**kwargs):
        path = kwargs.get("path", kwargs.get("file", ""))
        # Simulate: some files have lint issues
        if "messy" in path:
            return ToolResultBuilder.ok(f"{path}:1: W0611 unused import\n{path}:3: E302 expected 2 blank lines")
        return ToolResultBuilder.ok(f"{path}: All checks passed")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


# ── Tests ─────────────────────────────────────────────────────────────

class TestGitToCode:
    """Git ↔ code tool integration tests."""

    @pytest.fixture
    def setup(self):
        registry = ToolRegistry()
        git_tool = _make_git_tool()
        code_tool = _make_code_analysis_tool()
        write_tool = _make_write_tool()
        lint_tool = _make_lint_tool()
        registry.register(git_tool)
        registry.register(code_tool)
        registry.register(write_tool)
        registry.register(lint_tool)
        dispatcher = ToolDispatcher(registry)
        return dispatcher, git_tool, code_tool, write_tool, lint_tool

    @pytest.mark.asyncio
    async def test_write_lint_commit_workflow(self, setup):
        """Write code → lint → fix → commit."""
        dispatcher, git_tool, _, write_tool, lint_tool = setup

        # Write messy code
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "messy.py", "content": "import os\nimport sys\n\ndef foo(): pass\n"})
        )

        # Lint it
        lint_result = await dispatcher.dispatch(
            ToolCall(name="code.lint", parameters={"path": "messy.py"})
        )
        assert lint_result.status == ToolResultStatus.SUCCESS
        assert "W0611" in lint_result.output

        # Stage and commit
        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "add", "files": ["messy.py"]})
        )
        commit_result = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "commit", "message": "Add messy module"})
        )
        assert commit_result.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_analyze_then_commit(self, setup):
        """Analyze code for issues, then commit clean code."""
        dispatcher, git_tool, code_tool, _, _ = setup

        code_tool._issues["clean.py"] = []

        # Analyze clean code
        r1 = await dispatcher.dispatch(
            ToolCall(name="code.analyze", parameters={"path": "clean.py"})
        )
        assert "No issues" in r1.output

        # Commit
        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "add", "files": ["clean.py"]})
        )
        r2 = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "commit", "message": "Add clean module"})
        )
        assert r2.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_diff_then_analyze(self, setup):
        """Check git diff then analyze the changed file."""
        dispatcher, _, code_tool, _, _ = setup

        # Get diff
        diff_result = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "diff"})
        )
        assert diff_result.status == ToolResultStatus.SUCCESS
        assert "+++" in diff_result.output

        # Analyze the file
        code_tool._issues["file.py"] = ["Line 5: missing type hint"]
        analyze_result = await dispatcher.dispatch(
            ToolCall(name="code.analyze", parameters={"path": "file.py"})
        )
        assert analyze_result.status == ToolResultStatus.SUCCESS
        assert "missing type hint" in analyze_result.output

    @pytest.mark.asyncio
    async def test_git_log_then_blame(self, setup):
        """Check git log then blame a specific file."""
        dispatcher, _, _, _, _ = setup

        log_result = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "log"})
        )
        assert log_result.status == ToolResultStatus.SUCCESS

        blame_result = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "blame"})
        )
        assert blame_result.status == ToolResultStatus.SUCCESS
        assert "abc1234" in blame_result.output

    @pytest.mark.asyncio
    async def test_lint_clean_file_passes(self, setup):
        """Lint a clean file — no issues reported."""
        dispatcher, _, _, _, lint_tool = setup

        r = await dispatcher.dispatch(
            ToolCall(name="code.lint", parameters={"path": "clean_module.py"})
        )
        assert r.status == ToolResultStatus.SUCCESS
        assert "All checks passed" in r.output

    @pytest.mark.asyncio
    async def test_write_multiple_then_commit_all(self, setup):
        """Write multiple files then commit them all together."""
        dispatcher, git_tool, _, _, _ = setup

        files = ["module_a.py", "module_b.py", "module_c.py"]
        for f in files:
            await dispatcher.dispatch(
                ToolCall(name="filesystem.write", parameters={"path": f, "content": f"# {f}\n"})
            )

        await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "add", "files": files})
        )
        r = await dispatcher.dispatch(
            ToolCall(name="git", parameters={"action": "commit", "message": "Add modules"})
        )
        assert r.status == ToolResultStatus.SUCCESS
        assert git_tool._state["committed"] == 1
