"""Integration tests: shell ↔ filesystem tool interaction.

Verifies that shell commands and filesystem tools work together
seamlessly — e.g., running a command that creates a file, then
reading it back.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResultStatus


# ── Helpers ───────────────────────────────────────────────────────────

def _make_shell_tool(virtual_fs: dict[str, str] | None = None) -> MagicMock:
    """Shell tool that can interact with a virtual filesystem."""
    fs = virtual_fs if virtual_fs is not None else {}
    tool = MagicMock()
    tool.name = "shell.execute"
    tool.category = "shell"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "shell.execute", "parameters": {}}
    commands: list[str] = []

    async def _execute(**kwargs):
        cmd = kwargs.get("command", "")
        commands.append(cmd)

        # Simulate common commands
        if cmd.startswith("echo "):
            content = cmd[5:].strip("'\"")
            # echo with redirect
            if " > " in cmd:
                parts = cmd.split(" > ")
                target = parts[1].strip()
                content = parts[0][5:].strip("'\"")
                fs[target] = content
                return ToolResultBuilder.ok("")
            return ToolResultBuilder.ok(content)

        if cmd.startswith("cat "):
            path = cmd[4:].strip()
            content = fs.get(path)
            if content is not None:
                return ToolResultBuilder.ok(content)
            return ToolResultBuilder.err(f"cat: {path}: No such file or directory", exit_code=1)

        if cmd.startswith("wc -l "):
            path = cmd[6:].strip()
            content = fs.get(path, "")
            lines = len(content.splitlines())
            return ToolResultBuilder.ok(f" {lines} {path}")

        if cmd.startswith("mkdir -p "):
            return ToolResultBuilder.ok("")

        if cmd.startswith("ls"):
            return ToolResultBuilder.ok("\n".join(fs.keys()) if fs else "")

        if cmd.startswith("touch "):
            path = cmd[6:].strip()
            fs.setdefault(path, "")
            return ToolResultBuilder.ok("")

        if cmd.startswith("grep "):
            parts = cmd.split()
            if len(parts) >= 3:
                pattern = parts[1].strip("'\"")
                path = parts[2]
                content = fs.get(path, "")
                matches = [l for l in content.splitlines() if pattern in l]
                return ToolResultBuilder.ok("\n".join(matches) if matches else "")
            return ToolResultBuilder.ok("")

        return ToolResultBuilder.ok("")

    tool.run = AsyncMock(side_effect=_execute)
    tool._commands = commands
    tool._fs = fs
    return tool


def _make_write_tool(virtual_fs: dict[str, str]) -> MagicMock:
    tool = MagicMock()
    tool.name = "filesystem.write"
    tool.category = "filesystem"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "filesystem.write", "parameters": {}}

    async def _execute(**kwargs):
        path = kwargs.get("path", "")
        content = kwargs.get("content", "")
        virtual_fs[path] = content
        return ToolResultBuilder.ok(f"Wrote {len(content)} bytes to {path}")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


def _make_read_tool(virtual_fs: dict[str, str]) -> MagicMock:
    tool = MagicMock()
    tool.name = "filesystem.read"
    tool.category = "filesystem"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "filesystem.read", "parameters": {}}

    async def _execute(**kwargs):
        path = kwargs.get("path", "")
        content = virtual_fs.get(path)
        if content is not None:
            return ToolResultBuilder.ok(content)
        return ToolResultBuilder.err(f"File not found: {path}", exit_code=2)

    tool.run = AsyncMock(side_effect=_execute)
    return tool


# ── Tests ─────────────────────────────────────────────────────────────

class TestShellToFilesystem:
    """Shell → filesystem integration tests."""

    @pytest.mark.asyncio
    async def test_echo_redirect_then_read(self):
        """Shell echo with redirect creates a file, then read it."""
        fs: dict[str, str] = {}
        shell = _make_shell_tool(fs)
        read_tool = _make_read_tool(fs)
        registry = ToolRegistry()
        registry.register(shell)
        registry.register(read_tool)
        dispatcher = ToolDispatcher(registry)

        # Shell creates file via redirect
        r1 = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "echo 'hello world' > output.txt"})
        )
        assert r1.status == ToolResultStatus.SUCCESS
        assert "output.txt" in fs

        # Filesystem read
        r2 = await dispatcher.dispatch(
            ToolCall(name="filesystem.read", parameters={"path": "output.txt"})
        )
        assert r2.status == ToolResultStatus.SUCCESS
        assert "hello world" in r2.output

    @pytest.mark.asyncio
    async def test_write_then_cat(self):
        """Filesystem write then shell cat reads the same content."""
        fs: dict[str, str] = {}
        shell = _make_shell_tool(fs)
        write_tool = _make_write_tool(fs)
        registry = ToolRegistry()
        registry.register(shell)
        registry.register(write_tool)
        dispatcher = ToolDispatcher(registry)

        # Write via filesystem
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "data.csv", "content": "a,b,c\n1,2,3\n"})
        )

        # Read via shell
        r = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "cat data.csv"})
        )
        assert r.status == ToolResultStatus.SUCCESS
        assert "a,b,c" in r.output

    @pytest.mark.asyncio
    async def test_write_then_grep(self):
        """Write a file then use grep to search it."""
        fs: dict[str, str] = {}
        shell = _make_shell_tool(fs)
        write_tool = _make_write_tool(fs)
        registry = ToolRegistry()
        registry.register(shell)
        registry.register(write_tool)
        dispatcher = ToolDispatcher(registry)

        log_content = "INFO: started\nERROR: connection failed\nINFO: retrying\nERROR: timeout\n"
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "app.log", "content": log_content})
        )

        r = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "grep ERROR app.log"})
        )
        assert r.status == ToolResultStatus.SUCCESS
        assert "ERROR" in r.output

    @pytest.mark.asyncio
    async def test_mkdir_then_write(self):
        """Create directory with shell, then write file."""
        fs: dict[str, str] = {}
        shell = _make_shell_tool(fs)
        write_tool = _make_write_tool(fs)
        registry = ToolRegistry()
        registry.register(shell)
        registry.register(write_tool)
        dispatcher = ToolDispatcher(registry)

        # mkdir
        r1 = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "mkdir -p src/utils"})
        )
        assert r1.status == ToolResultStatus.SUCCESS

        # write into the directory
        r2 = await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "src/utils/helpers.py", "content": "def help(): pass\n"})
        )
        assert r2.status == ToolResultStatus.SUCCESS
        assert "src/utils/helpers.py" in fs

    @pytest.mark.asyncio
    async def test_touch_then_write(self):
        """Touch a file then overwrite with content."""
        fs: dict[str, str] = {}
        shell = _make_shell_tool(fs)
        write_tool = _make_write_tool(fs)
        registry = ToolRegistry()
        registry.register(shell)
        registry.register(write_tool)
        dispatcher = ToolDispatcher(registry)

        await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "touch config.toml"})
        )
        assert "config.toml" in fs

        await dispatcher.dispatch(
            ToolCall(
                name="filesystem.write",
                parameters={"path": "config.toml", "content": "[database]\nurl = 'sqlite:///app.db'\n"},
            )
        )
        assert fs["config.toml"].startswith("[database]")

    @pytest.mark.asyncio
    async def test_write_then_wc(self):
        """Write a file and count lines with wc."""
        fs: dict[str, str] = {}
        shell = _make_shell_tool(fs)
        write_tool = _make_write_tool(fs)
        registry = ToolRegistry()
        registry.register(shell)
        registry.register(write_tool)
        dispatcher = ToolDispatcher(registry)

        lines = "\n".join(f"line {i}" for i in range(10))
        await dispatcher.dispatch(
            ToolCall(name="filesystem.write", parameters={"path": "data.txt", "content": lines})
        )

        r = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "wc -l data.txt"})
        )
        assert r.status == ToolResultStatus.SUCCESS
        assert "10" in r.output

    @pytest.mark.asyncio
    async def test_multi_file_pipeline(self):
        """Complex pipeline: create multiple files, then list them."""
        fs: dict[str, str] = {}
        shell = _make_shell_tool(fs)
        write_tool = _make_write_tool(fs)
        registry = ToolRegistry()
        registry.register(shell)
        registry.register(write_tool)
        dispatcher = ToolDispatcher(registry)

        files = {
            "src/a.py": "# module a\n",
            "src/b.py": "# module b\n",
            "tests/test_a.py": "# test a\n",
            "README.md": "# Project\n",
        }
        for path, content in files.items():
            await dispatcher.dispatch(
                ToolCall(name="filesystem.write", parameters={"path": path, "content": content})
            )

        r = await dispatcher.dispatch(
            ToolCall(name="shell.execute", parameters={"command": "ls"})
        )
        assert r.status == ToolResultStatus.SUCCESS
        for path in files:
            assert path in r.output
