"""Integration tests: search → edit workflow.

Tests the pattern: search for code patterns, then apply targeted edits
to the found locations.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

_src = Path(__file__).resolve().parents[4] / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.tools.dispatcher import ToolDispatcher
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.result import ToolResultBuilder
from terminal_agent.types import SafetyLevel, ToolCall, ToolResultStatus


# ── Helpers ───────────────────────────────────────────────────────────

def _make_search_tool(files: dict[str, str]) -> MagicMock:
    tool = MagicMock()
    tool.name = "search.regex"
    tool.category = "search"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "search.regex", "parameters": {}}

    async def _execute(**kwargs):
        import re
        pattern = kwargs.get("pattern", kwargs.get("query", ""))
        results = []
        for path, content in files.items():
            for i, line in enumerate(content.splitlines(), 1):
                if re.search(pattern, line, re.IGNORECASE):
                    results.append(f"{path}:{i}: {line.strip()}")
        if results:
            return ToolResultBuilder.ok("\n".join(results))
        return ToolResultBuilder.ok("No matches found")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


def _make_edit_tool(files: dict[str, str]) -> MagicMock:
    tool = MagicMock()
    tool.name = "filesystem.edit"
    tool.category = "filesystem"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "filesystem.edit", "parameters": {}}
    edits: list[dict] = []

    async def _execute(**kwargs):
        path = kwargs.get("path", "")
        old = kwargs.get("old_text", kwargs.get("old", ""))
        new = kwargs.get("new_text", kwargs.get("new", ""))
        edits.append({"path": path, "old": old, "new": new})
        if path in files and old in files[path]:
            files[path] = files[path].replace(old, new, 1)
            return ToolResultBuilder.ok("Edit applied")
        return ToolResultBuilder.err("Text not found", exit_code=1)

    tool.run = AsyncMock(side_effect=_execute)
    tool._edits = edits
    return tool


def _make_replace_tool(files: dict[str, str]) -> MagicMock:
    """Bulk search-and-replace tool."""
    tool = MagicMock()
    tool.name = "search.replace"
    tool.category = "search"
    tool.min_safety_level = SafetyLevel.UNRESTRICTED
    tool.get_schema.return_value = {"name": "search.replace", "parameters": {}}

    async def _execute(**kwargs):
        import re
        pattern = kwargs.get("pattern", "")
        replacement = kwargs.get("replacement", kwargs.get("replace", ""))
        path = kwargs.get("path", kwargs.get("file", ""))
        content = files.get(path, "")
        new_content, count = re.subn(pattern, replacement, content)
        if count > 0:
            files[path] = new_content
            return ToolResultBuilder.ok(f"Replaced {count} occurrence(s)")
        return ToolResultBuilder.ok("No replacements made")

    tool.run = AsyncMock(side_effect=_execute)
    return tool


# ── Tests ─────────────────────────────────────────────────────────────

class TestSearchToEdit:
    """Search → edit workflow integration tests."""

    @pytest.fixture
    def codebase(self):
        return {
            "app.py": (
                "import os\n"
                "import sys\n\n"
                "def process_data(data):\n"
                "    result = []\n"
                "    for item in data:\n"
                "        result.append(item * 2)\n"
                "    return result\n\n"
                "def old_function():\n"
                "    return None\n"
            ),
            "utils.py": (
                "def old_helper():\n"
                "    return 'old value'\n\n"
                "def format_output(data):\n"
                "    return str(data)\n"
            ),
            "config.py": (
                "DEBUG = True\n"
                "DATABASE_URL = 'sqlite:///old.db'\n"
                "SECRET_KEY = 'hardcoded-secret'\n"
            ),
        }

    @pytest.mark.asyncio
    async def test_find_and_rename_function(self, codebase):
        """Search for a function name and rename it."""
        search = _make_search_tool(codebase)
        edit = _make_edit_tool(codebase)
        registry = ToolRegistry()
        registry.register(search)
        registry.register(edit)
        dispatcher = ToolDispatcher(registry)

        # Search for old_function
        search_result = await dispatcher.dispatch(
            ToolCall(name="search.regex", parameters={"pattern": r"old_function"})
        )
        assert search_result.status == ToolResultStatus.SUCCESS
        assert "app.py" in search_result.output

        # Rename it
        edit_result = await dispatcher.dispatch(
            ToolCall(
                name="filesystem.edit",
                parameters={"path": "app.py", "old_text": "def old_function():", "new_text": "def new_function():"},
            )
        )
        assert edit_result.status == ToolResultStatus.SUCCESS
        assert "def new_function():" in codebase["app.py"]

    @pytest.mark.asyncio
    async def test_find_all_print_statements_and_remove(self, codebase):
        """Find all print statements and remove them."""
        codebase["debug.py"] = "print('starting')\nx = 1\nprint(f'x = {x}')\nprint('done')\n"
        search = _make_search_tool(codebase)
        replace = _make_replace_tool(codebase)
        registry = ToolRegistry()
        registry.register(search)
        registry.register(replace)
        dispatcher = ToolDispatcher(registry)

        # Search for print statements
        search_result = await dispatcher.dispatch(
            ToolCall(name="search.regex", parameters={"pattern": r"print\("})
        )
        assert search_result.status == ToolResultStatus.SUCCESS
        assert "debug.py" in search_result.output

        # Replace all print lines (use .* to match any print line)
        replace_result = await dispatcher.dispatch(
            ToolCall(
                name="search.replace",
                parameters={"path": "debug.py", "pattern": r"print\(.*\)\n?", "replacement": ""},
            )
        )
        assert replace_result.status == ToolResultStatus.SUCCESS
        assert "Replaced" in replace_result.output

    @pytest.mark.asyncio
    async def test_search_then_edit_multiple_files(self, codebase):
        """Search across files, then edit each match."""
        codebase["a.py"] = "TODO: fix this\ncode = 1\nTODO: fix that\n"
        codebase["b.py"] = "# TODO: another fix\nvalue = 42\n"

        search = _make_search_tool(codebase)
        edit = _make_edit_tool(codebase)
        registry = ToolRegistry()
        registry.register(search)
        registry.register(edit)
        dispatcher = ToolDispatcher(registry)

        # Search for TODO
        search_result = await dispatcher.dispatch(
            ToolCall(name="search.regex", parameters={"pattern": "TODO"})
        )
        assert "a.py" in search_result.output
        assert "b.py" in search_result.output

        # Fix TODOs in both files
        for path, old, new in [
            ("a.py", "TODO: fix this", "# FIXED: was todo"),
            ("a.py", "TODO: fix that", "# FIXED: was todo"),
            ("b.py", "# TODO: another fix", "# FIXED: was todo"),
        ]:
            r = await dispatcher.dispatch(
                ToolCall(name="filesystem.edit", parameters={"path": path, "old_text": old, "new_text": new})
            )
            assert r.status == ToolResultStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_replace_hardcoded_values(self, codebase):
        """Find and replace hardcoded configuration values."""
        search = _make_search_tool(codebase)
        edit = _make_edit_tool(codebase)
        registry = ToolRegistry()
        registry.register(search)
        registry.register(edit)
        dispatcher = ToolDispatcher(registry)

        # Find hardcoded secret
        search_result = await dispatcher.dispatch(
            ToolCall(name="search.regex", parameters={"pattern": "SECRET_KEY"})
        )
        assert "config.py" in search_result.output

        # Replace with env var reference
        edit_result = await dispatcher.dispatch(
            ToolCall(
                name="filesystem.edit",
                parameters={
                    "path": "config.py",
                    "old_text": "SECRET_KEY = 'hardcoded-secret'",
                    "new_text": "SECRET_KEY = os.environ.get('SECRET_KEY')",
                },
            )
        )
        assert edit_result.status == ToolResultStatus.SUCCESS
        assert "os.environ" in codebase["config.py"]

    @pytest.mark.asyncio
    async def test_search_no_results_no_edit(self, codebase):
        """Search that finds nothing should not trigger any edits."""
        search = _make_search_tool(codebase)
        edit = _make_edit_tool(codebase)
        registry = ToolRegistry()
        registry.register(search)
        registry.register(edit)
        dispatcher = ToolDispatcher(registry)

        search_result = await dispatcher.dispatch(
            ToolCall(name="search.regex", parameters={"pattern": "NONEXISTENT_SYMBOL_XYZ"})
        )
        assert "No matches" in search_result.output
        assert len(edit._edits) == 0

    @pytest.mark.asyncio
    async def test_replace_tool_bulk_operation(self, codebase):
        """Use the replace tool for bulk find-and-replace."""
        replace = _make_replace_tool(codebase)
        registry = ToolRegistry()
        registry.register(replace)
        dispatcher = ToolDispatcher(registry)

        # Replace 'old' with 'new' in config
        r = await dispatcher.dispatch(
            ToolCall(
                name="search.replace",
                parameters={"path": "config.py", "pattern": "old\\.db", "replacement": "new.db"},
            )
        )
        assert r.status == ToolResultStatus.SUCCESS
        assert "new.db" in codebase["config.py"]
        assert "old.db" not in codebase["config.py"]
