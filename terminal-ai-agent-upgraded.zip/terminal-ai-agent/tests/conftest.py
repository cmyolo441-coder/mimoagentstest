"""Shared fixtures for Terminal Agent test suite."""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

# Ensure the src package is importable
_src = Path(__file__).resolve().parent.parent / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from terminal_agent.types import (
    SafetyLevel,
    ToolCall,
    ToolResult,
    ToolResultStatus,
    LLMResponse,
    Memory,
    MemoryCategory,
    Plan,
    PlanStep,
    Session,
    SessionStatus,
    ProviderConfig,
)

# Patch ToolResult to include 'truncated' attribute and classmethods
# used by the dispatcher.
_original_tool_result_init = ToolResult.__init__

def _patched_tool_result_init(self, *args, **kwargs):
    _original_tool_result_init(self, *args, **kwargs)
    if not hasattr(self, 'truncated'):
        self.truncated = False

ToolResult.__init__ = _patched_tool_result_init

# Add classmethods that the dispatcher expects
@staticmethod
def _tr_success(output="", **kw):
    return ToolResult(status=ToolResultStatus.SUCCESS, output=output, **kw)

@staticmethod
def _tr_failure(error="", **kw):
    return ToolResult(status=ToolResultStatus.FAILURE, error=error, exit_code=kw.pop("exit_code", 1), **kw)

@staticmethod
def _tr_error(error="", exit_code=1, **kw):
    return ToolResult(status=ToolResultStatus.ERROR, error=error, exit_code=exit_code, **kw)

@staticmethod
def _tr_timeout(error="Operation timed out", **kw):
    return ToolResult(status=ToolResultStatus.TIMEOUT, error=error, exit_code=kw.pop("exit_code", 124), **kw)

@staticmethod
def _tr_blocked(reason="", **kw):
    return ToolResult(status=ToolResultStatus.BLOCKED, error=reason, **kw)

ToolResult.success = _tr_success
ToolResult.failure = _tr_failure
ToolResult.error = _tr_error
ToolResult.timeout = _tr_timeout
ToolResult.blocked = _tr_blocked


# ── Event loop ────────────────────────────────────────────────────────

@pytest.fixture
def event_loop():
    """Provide a fresh event loop for each test."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


# ── Temporary directories ─────────────────────────────────────────────

@pytest.fixture
def project_dir(tmp_path: Path) -> Path:
    """Create a minimal project directory with common marker files."""
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "test-proj"\nversion = "0.1.0"\n'
    )
    (tmp_path / "requirements.txt").write_text("requests>=2.28\npytest>=7.0\n")
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "__init__.py").write_text("")
    (tmp_path / "src" / "main.py").write_text(
        'def main():\n    print("hello")\n\nif __name__ == "__main__":\n    main()\n'
    )
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_main.py").write_text(
        "def test_main():\n    assert True\n"
    )
    (tmp_path / ".gitignore").write_text("__pycache__/\n*.pyc\n")
    return tmp_path


@pytest.fixture
def sample_python_file(tmp_path: Path) -> Path:
    """Create a sample Python file for code analysis tests."""
    code = '''"""Sample module for testing."""

import os
import sys
from pathlib import Path

MAX_RETRIES = 3
DEFAULT_TIMEOUT = 30


class ConfigManager:
    """Manages application configuration."""

    def __init__(self, path: str = "config.toml"):
        self.path = Path(path)
        self._data: dict = {}

    def load(self) -> dict:
        """Load configuration from file."""
        if not self.path.exists():
            raise FileNotFoundError(f"Config not found: {self.path}")
        return self._data

    @staticmethod
    def validate(data: dict) -> bool:
        """Validate configuration data."""
        return bool(data)


def create_client(url: str, timeout: int = DEFAULT_TIMEOUT) -> dict:
    """Create an API client."""
    return {"url": url, "timeout": timeout}


async def fetch_data(client: dict, endpoint: str) -> str:
    """Fetch data from API."""
    return f"data from {endpoint}"


def helper():
    pass
'''
    path = tmp_path / "sample.py"
    path.write_text(code)
    return path


# ── Tool fixtures ─────────────────────────────────────────────────────

@pytest.fixture
def tool_call_simple() -> ToolCall:
    """A simple tool call for testing."""
    return ToolCall(
        name="shell.execute",
        parameters={"command": "echo hello"},
    )


@pytest.fixture
def tool_result_ok() -> ToolResult:
    """A successful tool result."""
    return ToolResult(
        status=ToolResultStatus.SUCCESS,
        output="hello\n",
        exit_code=0,
    )


@pytest.fixture
def tool_result_error() -> ToolResult:
    """A failed tool result."""
    return ToolResult(
        status=ToolResultStatus.ERROR,
        error="command not found",
        exit_code=1,
    )


# ── LLM fixtures ─────────────────────────────────────────────────────

@pytest.fixture
def sample_llm_response() -> LLMResponse:
    """A sample successful LLM response."""
    return LLMResponse(
        content="Here is the answer.",
        tool_calls=[],
        finish_reason="stop",
        tokens_in=100,
        tokens_out=20,
        cost=0.0005,
        latency_ms=250.0,
        provider="openai",
        model="gpt-4o",
    )


@pytest.fixture
def sample_tool_call_response() -> LLMResponse:
    """An LLM response that includes tool calls."""
    return LLMResponse(
        content="",
        tool_calls=[
            ToolCall(
                id="call_abc123",
                name="shell.execute",
                parameters={"command": "ls -la"},
            )
        ],
        finish_reason="tool_calls",
        tokens_in=50,
        tokens_out=30,
        cost=0.0003,
        provider="openai",
        model="gpt-4o",
    )


@pytest.fixture
def provider_config_openai() -> ProviderConfig:
    """OpenAI provider configuration."""
    return ProviderConfig(
        provider="openai",
        model="gpt-4o",
        api_key="test-key-12345",
        temperature=0.0,
        max_tokens=4096,
        timeout=120,
    )


@pytest.fixture
def provider_config_anthropic() -> ProviderConfig:
    """Anthropic provider configuration."""
    return ProviderConfig(
        provider="anthropic",
        model="claude-3-5-sonnet-20241022",
        api_key="test-key-anthropic",
        temperature=0.0,
        max_tokens=4096,
        timeout=120,
    )


# ── Config fixtures ───────────────────────────────────────────────────

@pytest.fixture
def sample_config_dict() -> dict[str, Any]:
    """A valid configuration dict for testing."""
    return {
        "config_version": 1,
        "active_profile": "",
        "llm": {
            "provider": "openai",
            "model": "gpt-4o",
            "api_key": "",
            "base_url": None,
            "organization": None,
            "temperature": 0.0,
            "max_tokens": 4096,
            "timeout": 120,
            "max_retries": 3,
            "retry_delay": 1.0,
            "stream": True,
            "fallback_providers": [],
            "providers": {},
        },
        "memory": {
            "backend": "chroma",
            "embedding_model": "text-embedding-3-small",
            "embedding_dimensions": 1536,
            "short_term_turns": 20,
            "working_memory_files": 10,
            "long_term_memories_per_query": 5,
            "consolidation_interval": 3600,
            "decay_rate": 0.1,
            "max_memory_size": 10000,
            "vector_db_path": "",
            "enable_semantic_search": True,
        },
        "safety": {
            "level": 2,
            "blocked_commands": ["rm -rf /"],
            "blocked_paths": ["/etc/shadow"],
            "confirm_destructive": True,
            "confirm_writes": False,
            "confirm_executions": False,
            "sandbox_mode": False,
            "max_output_size": 100000,
            "audit_log": True,
        },
        "tools": {
            "enabled_categories": [],
            "disabled_categories": [],
            "shell": {
                "timeout": 300,
                "max_output": 100000,
                "allow_background": True,
                "allow_sudo": False,
                "allowed_commands": [],
                "blocked_commands": [],
            },
            "filesystem": {
                "max_read_size": 1000000,
                "backup_before_edit": True,
                "allowed_paths": [],
                "blocked_paths": [],
            },
        },
        "cache": {
            "backend": "memory",
            "max_size": 1000,
            "ttl": 3600,
            "eviction_policy": "lru",
            "disk_path": "",
            "enable_llm_cache": True,
            "enable_tool_cache": True,
        },
        "logging": {
            "level": "INFO",
            "format": "structured",
            "file": "",
            "max_file_size": 10000000,
            "backup_count": 5,
            "console": True,
            "colorize": True,
            "trace_llm_calls": False,
            "trace_tool_calls": False,
        },
        "ui": {
            "theme": "dark",
            "verbosity": "normal",
            "show_progress": True,
            "show_plan": True,
            "show_cost": True,
            "show_token_usage": False,
            "code_theme": "monokai",
            "spinner_style": "dots",
            "max_display_lines": 500,
            "pager": "auto",
        },
        "git": {
            "auto_commit": False,
            "commit_message_style": "conventional",
            "branch_prefix": "agent/",
            "default_branch": "main",
            "sign_commits": False,
            "auto_push": False,
            "stash_before_switch": True,
        },
        "testing": {
            "default_framework": "auto",
            "coverage_threshold": 80.0,
            "run_on_save": False,
            "parallel": True,
            "timeout": 300,
            "fail_fast": False,
            "verbose": True,
        },
        "cost": {
            "max_cost_per_task": 5.0,
            "warning_threshold": 0.8,
            "track_costs": True,
            "currency": "USD",
            "budget_period": "task",
            "daily_budget": 50.0,
            "monthly_budget": 500.0,
        },
        "plugin": {
            "enabled": True,
            "directories": [],
            "enabled_plugins": [],
            "disabled_plugins": [],
            "auto_discover": True,
            "sandbox_plugins": True,
        },
        "mcp": {
            "enabled": True,
            "servers": {},
            "default_timeout": 30,
            "retry_policy": "exponential",
            "max_retries": 3,
        },
        "performance": {
            "max_parallel_tools": 4,
            "default_timeout": 120,
            "enable_caching": True,
            "enable_streaming": True,
            "context_window_reserve": 1000,
            "max_concurrent_sessions": 1,
        },
        "export": {
            "default_format": "json",
            "output_directory": "exports",
            "include_traces": True,
            "include_metrics": True,
            "compress": False,
        },
    }


# ── Memory fixtures ───────────────────────────────────────────────────

@pytest.fixture
def sample_memory() -> Memory:
    """A sample memory object."""
    return Memory(
        id="mem-001",
        category=MemoryCategory.TASK,
        content="Use sorted() for non-destructive sorting in Python",
        relevance_score=0.9,
        access_count=5,
        metadata={"created_at": 1000.0},
    )


@pytest.fixture
def sample_plan() -> Plan:
    """A sample plan with three steps."""
    return Plan(
        goal="Build a REST API",
        steps=[
            PlanStep(id="step_1", description="Set up project structure", status=SessionStatus.PENDING),
            PlanStep(id="step_2", description="Implement endpoints", dependencies=["step_1"], status=SessionStatus.PENDING),
            PlanStep(id="step_3", description="Write tests", dependencies=["step_2"], status=SessionStatus.PENDING),
        ],
    )


# ── Mock factories ────────────────────────────────────────────────────

@pytest.fixture
def mock_llm_provider():
    """Create a mock LLM provider with standard responses."""
    provider = AsyncMock()
    provider.provider_id = "openai"
    provider.config = ProviderConfig(
        provider="openai",
        model="gpt-4o",
        api_key="test-key",
        temperature=0.0,
        max_tokens=4096,
    )
    provider.send_prompt = AsyncMock(return_value=LLMResponse(
        content="Test response",
        tool_calls=[],
        finish_reason="stop",
        tokens_in=100,
        tokens_out=50,
        cost=0.001,
        provider="openai",
        model="gpt-4o",
    ))
    provider.validate_config = AsyncMock(return_value=True)
    provider.close = AsyncMock()
    provider.get_model_info = MagicMock(return_value=MagicMock(
        max_context_tokens=128000,
        max_output_tokens=16384,
    ))
    return provider
