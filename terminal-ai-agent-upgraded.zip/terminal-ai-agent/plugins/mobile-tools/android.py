"""Android development manager.

Provides Android build, test, and deployment capabilities via Gradle
and Android Debug Bridge (adb).
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class AndroidManager:
    """Manages Android development tasks.

    Args:
        sdk_path: Path to the Android SDK.
        java_home: Path to the JDK.
    """

    def __init__(self, sdk_path: str = "", java_home: str = "") -> None:
        self._sdk_path = sdk_path or os.environ.get("ANDROID_HOME", os.environ.get("ANDROID_SDK_ROOT", ""))
        self._java_home = java_home or os.environ.get("JAVA_HOME", "")

    async def build(
        self,
        project_path: str,
        variant: str = "debug",
        tasks: list[str] | None = None,
        clean: bool = False,
    ) -> dict[str, Any]:
        """Build an Android project using Gradle.

        Args:
            project_path: Path to the project root.
            variant: Build variant (debug or release).
            tasks: Custom Gradle tasks.
            clean: Run clean before build.

        Returns:
            Build result with status, output, and APK path.
        """
        project = Path(project_path).expanduser().resolve()
        if not project.exists():
            return {"error": f"Project path not found: {project_path}"}

        gradlew = project / "gradlew"
        if not gradlew.exists():
            return {"error": "gradlew not found. Is this an Android/Gradle project?"}

        # Build command
        cmd = [str(gradlew)]
        if clean:
            cmd.append("clean")

        if tasks:
            cmd.extend(tasks)
        else:
            cmd.append(f"assemble{variant.capitalize()}")

        cmd.append("--stacktrace")

        # Set environment
        env = os.environ.copy()
        if self._sdk_path:
            env["ANDROID_HOME"] = self._sdk_path
        if self._java_home:
            env["JAVA_HOME"] = self._java_home

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=str(project),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()

            output = stdout.decode(errors="replace")
            error_output = stderr.decode(errors="replace")

            # Find APK output
            apk_path = self._find_apk(project, variant)

            if proc.returncode != 0:
                return {
                    "success": False,
                    "error": error_output[-5000:] if error_output else "Build failed",
                    "output": output[-5000:],
                    "returncode": proc.returncode,
                }

            return {
                "success": True,
                "variant": variant,
                "apk_path": str(apk_path) if apk_path else None,
                "output": output[-2000:],
            }

        except FileNotFoundError:
            return {"error": "gradlew not executable. Run: chmod +x gradlew"}
        except Exception as exc:
            return {"error": str(exc)}

    async def deploy(
        self,
        app_path: str,
        device_id: str | None = None,
    ) -> dict[str, Any]:
        """Deploy an APK to a device or emulator.

        Args:
            app_path: Path to the APK file.
            device_id: Target device ID.

        Returns:
            Deployment result.
        """
        apk = Path(app_path).expanduser().resolve()
        if not apk.exists():
            return {"error": f"APK not found: {app_path}"}

        adb = self._get_adb_path()
        cmd = [adb]
        if device_id:
            cmd.extend(["-s", device_id])
        cmd.extend(["install", "-r", str(apk)])

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()

            output = stdout.decode(errors="replace") + stderr.decode(errors="replace")

            if proc.returncode != 0:
                return {"success": False, "error": output, "returncode": proc.returncode}

            return {
                "success": True,
                "device_id": device_id or "default",
                "apk": str(apk),
                "output": output.strip(),
            }

        except FileNotFoundError:
            return {"error": "adb not found. Ensure Android SDK platform-tools are in PATH."}
        except Exception as exc:
            return {"error": str(exc)}

    async def list_devices(self) -> dict[str, Any]:
        """List connected Android devices and emulators."""
        adb = self._get_adb_path()
        try:
            proc = await asyncio.create_subprocess_exec(
                adb, "devices", "-l",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()
            lines = stdout.decode(errors="replace").strip().splitlines()

            devices = []
            for line in lines[1:]:
                if line.strip():
                    parts = line.split()
                    if len(parts) >= 2:
                        devices.append({
                            "id": parts[0],
                            "status": parts[1],
                            "info": " ".join(parts[2:]) if len(parts) > 2 else "",
                        })

            return {"devices": devices, "count": len(devices)}

        except FileNotFoundError:
            return {"error": "adb not found."}

    def _get_adb_path(self) -> str:
        """Get the adb executable path."""
        if self._sdk_path:
            candidate = Path(self._sdk_path) / "platform-tools" / "adb"
            if candidate.exists():
                return str(candidate)
        return "adb"

    @staticmethod
    def _find_apk(project: Path, variant: str) -> Path | None:
        """Find the built APK file."""
        pattern = f"**/*-{variant}.apk"
        matches = list(project.glob(pattern))
        return matches[0] if matches else None
