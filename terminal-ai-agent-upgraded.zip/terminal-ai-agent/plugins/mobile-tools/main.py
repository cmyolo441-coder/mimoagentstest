"""Mobile tools plugin — Android and iOS development tools.

Provides tools for building, testing, and deploying mobile applications
across Android and iOS platforms.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.plugins.api import PluginBase, PluginContext

from .android import AndroidManager
from .ios import IOSManager

logger = logging.getLogger(__name__)


class MobileToolsPlugin(PluginBase):
    """Plugin providing mobile development tools.

    Tools:
        android_build: Build Android projects using Gradle.
        ios_build: Build iOS projects using xcodebuild.
        device_deploy: Deploy apps to connected devices or emulators.
    """

    name = "mobile-tools"
    version = "1.0.0"

    def __init__(self) -> None:
        self._context: PluginContext | None = None
        self._android: AndroidManager | None = None
        self._ios: IOSManager | None = None

    def activate(self, context: PluginContext | None = None) -> None:
        """Initialize the mobile tools plugin."""
        self._context = context or PluginContext()
        cfg = self._context.config if self._context else {}
        self._android = AndroidManager(
            sdk_path=cfg.get("android_sdk_path", ""),
            java_home=cfg.get("java_home", ""),
        )
        self._ios = IOSManager(
            xcode_path=cfg.get("xcode_path", "/Applications/Xcode.app"),
        )
        if self._context:
            self._context.log.info("Mobile tools plugin activated")

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions."""
        return [
            {
                "name": "android_build",
                "description": "Build an Android project using Gradle. Supports debug and release builds.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "project_path": {
                            "type": "string",
                            "description": "Path to the Android project root (containing build.gradle).",
                        },
                        "variant": {
                            "type": "string",
                            "description": "Build variant (debug, release).",
                            "default": "debug",
                        },
                        "tasks": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Gradle tasks to run (default: assembleDebug or assembleRelease).",
                        },
                        "clean": {
                            "type": "boolean",
                            "description": "Run clean before building.",
                            "default": False,
                        },
                    },
                    "required": ["project_path"],
                },
                "returns": "Build result with output path and status.",
            },
            {
                "name": "ios_build",
                "description": "Build an iOS project using xcodebuild.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "project_path": {
                            "type": "string",
                            "description": "Path to the .xcodeproj or .xcworkspace file.",
                        },
                        "scheme": {
                            "type": "string",
                            "description": "Xcode scheme to build.",
                        },
                        "configuration": {
                            "type": "string",
                            "description": "Build configuration (Debug, Release).",
                            "default": "Debug",
                        },
                        "sdk": {
                            "type": "string",
                            "description": "Target SDK (iphonesimulator, iphoneos).",
                            "default": "iphonesimulator",
                        },
                        "clean": {
                            "type": "boolean",
                            "description": "Run clean before building.",
                            "default": False,
                        },
                    },
                    "required": ["project_path", "scheme"],
                },
                "returns": "Build result with output path and status.",
            },
            {
                "name": "device_deploy",
                "description": "Deploy a built app to a connected device or emulator.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "platform": {
                            "type": "string",
                            "description": "Target platform (android, ios).",
                        },
                        "app_path": {
                            "type": "string",
                            "description": "Path to the built app (APK, AAB, or IPA).",
                        },
                        "device_id": {
                            "type": "string",
                            "description": "Target device/emulator ID. Uses default if omitted.",
                        },
                    },
                    "required": ["platform", "app_path"],
                },
                "returns": "Deployment result with device info and status.",
            },
        ]

    async def handle_tool(self, tool_name: str, parameters: dict[str, Any]) -> Any:
        """Dispatch tool calls."""
        handlers = {
            "android_build": self._android_build,
            "ios_build": self._ios_build,
            "device_deploy": self._device_deploy,
        }
        handler = handlers.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        return await handler(**parameters)

    async def _android_build(
        self,
        project_path: str,
        variant: str = "debug",
        tasks: list[str] | None = None,
        clean: bool = False,
    ) -> dict[str, Any]:
        """Build an Android project."""
        assert self._android is not None
        return await self._android.build(
            project_path, variant=variant, tasks=tasks, clean=clean
        )

    async def _ios_build(
        self,
        project_path: str,
        scheme: str,
        configuration: str = "Debug",
        sdk: str = "iphonesimulator",
        clean: bool = False,
    ) -> dict[str, Any]:
        """Build an iOS project."""
        assert self._ios is not None
        return await self._ios.build(
            project_path, scheme=scheme, configuration=configuration,
            sdk=sdk, clean=clean
        )

    async def _device_deploy(
        self,
        platform: str,
        app_path: str,
        device_id: str | None = None,
    ) -> dict[str, Any]:
        """Deploy to a device."""
        if platform == "android":
            assert self._android is not None
            return await self._android.deploy(app_path, device_id=device_id)
        elif platform == "ios":
            assert self._ios is not None
            return await self._ios.deploy(app_path, device_id=device_id)
        else:
            return {"error": f"Unsupported platform: {platform}. Use 'android' or 'ios'."}

    def cleanup(self) -> None:
        """Release resources."""
        if self._context:
            self._context.log.info("Mobile tools plugin cleaned up")
        self._android = None
        self._ios = None
        self._context = None
