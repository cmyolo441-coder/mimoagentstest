"""Tests for the mobile-tools plugin."""

from __future__ import annotations

import pytest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from terminal_agent.plugins.api import PluginContext

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from main import MobileToolsPlugin
from android import AndroidManager
from ios import IOSManager


@pytest.fixture
def plugin():
    p = MobileToolsPlugin()
    p.activate(PluginContext())
    return p


class TestMobileToolsPlugin:
    def test_tools_registered(self, plugin: MobileToolsPlugin):
        names = {t["name"] for t in plugin.get_tools()}
        assert names == {"android_build", "ios_build", "device_deploy"}

    def test_tool_schemas_valid(self, plugin: MobileToolsPlugin):
        for tool in plugin.get_tools():
            assert "name" in tool
            assert "description" in tool
            assert "parameters" in tool

    @pytest.mark.asyncio
    async def test_unknown_tool(self, plugin: MobileToolsPlugin):
        with pytest.raises(ValueError, match="Unknown tool"):
            await plugin.handle_tool("nonexistent", {})

    def test_cleanup(self, plugin: MobileToolsPlugin):
        plugin.cleanup()
        assert plugin._android is None
        assert plugin._ios is None


class TestAndroidManager:
    def test_init_defaults(self):
        mgr = AndroidManager()
        assert isinstance(mgr._sdk_path, str)

    def test_init_custom(self):
        mgr = AndroidManager(sdk_path="/opt/android-sdk", java_home="/usr/lib/jvm/17")
        assert mgr._sdk_path == "/opt/android-sdk"
        assert mgr._java_home == "/usr/lib/jvm/17"

    @pytest.mark.asyncio
    async def test_build_project_not_found(self):
        mgr = AndroidManager()
        result = await mgr.build("/nonexistent/project")
        assert "error" in result
        assert "not found" in result["error"]

    @pytest.mark.asyncio
    async def test_build_no_gradlew(self, tmp_path: Path):
        mgr = AndroidManager()
        result = await mgr.build(str(tmp_path))
        assert "error" in result
        assert "gradlew" in result["error"]

    @pytest.mark.asyncio
    async def test_deploy_apk_not_found(self):
        mgr = AndroidManager()
        result = await mgr.deploy("/nonexistent/app.apk")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_list_devices_adb_not_found(self):
        mgr = AndroidManager(sdk_path="")
        with patch("asyncio.create_subprocess_exec", side_effect=FileNotFoundError):
            result = await mgr.list_devices()
            assert "error" in result

    def test_find_apk_no_match(self, tmp_path: Path):
        result = AndroidManager._find_apk(tmp_path, "debug")
        assert result is None

    def test_find_apk_found(self, tmp_path: Path):
        apk_dir = tmp_path / "app" / "build" / "outputs" / "apk" / "debug"
        apk_dir.mkdir(parents=True)
        apk = apk_dir / "app-debug.apk"
        apk.write_bytes(b"fake apk")
        result = AndroidManager._find_apk(tmp_path, "debug")
        assert result is not None
        assert result.name == "app-debug.apk"


class TestIOSManager:
    def test_init_defaults(self):
        mgr = IOSManager()
        assert mgr._xcode_path == "/Applications/Xcode.app"

    def test_init_custom(self):
        mgr = IOSManager(xcode_path="/Applications/Xcode-beta.app")
        assert mgr._xcode_path == "/Applications/Xcode-beta.app"

    @pytest.mark.asyncio
    async def test_build_project_not_found(self):
        mgr = IOSManager()
        result = await mgr.build("/nonexistent/project.xcodeproj", scheme="App")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_build_no_project_file(self, tmp_path: Path):
        mgr = IOSManager()
        result = await mgr.build(str(tmp_path), scheme="App")
        assert "error" in result
        assert ".xcodeproj" in result["error"]

    @pytest.mark.asyncio
    async def test_deploy_app_not_found(self):
        mgr = IOSManager()
        result = await mgr.deploy("/nonexistent/App.app")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_list_simulators_not_found(self):
        mgr = IOSManager()
        with patch("asyncio.create_subprocess_exec", side_effect=FileNotFoundError):
            result = await mgr.list_simulators()
            assert "error" in result

    def test_find_derived_data_no_dir(self):
        with patch("pathlib.Path.home", return_value=Path("/nonexistent")):
            result = IOSManager._find_derived_data("MyApp")
            assert result is None
