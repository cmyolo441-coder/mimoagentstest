"""iOS development manager.

Provides iOS build and deployment capabilities via xcodebuild
and simulators/connected devices.
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class IOSManager:
    """Manages iOS development tasks.

    Args:
        xcode_path: Path to Xcode.app.
    """

    def __init__(self, xcode_path: str = "/Applications/Xcode.app") -> None:
        self._xcode_path = xcode_path

    async def build(
        self,
        project_path: str,
        scheme: str,
        configuration: str = "Debug",
        sdk: str = "iphonesimulator",
        clean: bool = False,
    ) -> dict[str, Any]:
        """Build an iOS project using xcodebuild.

        Args:
            project_path: Path to .xcodeproj or .xcworkspace.
            scheme: Xcode scheme to build.
            configuration: Build configuration (Debug, Release).
            sdk: Target SDK (iphonesimulator, iphoneos).
            clean: Run clean before build.

        Returns:
            Build result with status and output.
        """
        project = Path(project_path).expanduser().resolve()
        if not project.exists():
            return {"error": f"Project not found: {project_path}"}

        # Determine project type
        if project.suffix == ".xcworkspace":
            cmd = ["xcodebuild", "-workspace", str(project)]
        elif project.suffix == ".xcodeproj":
            cmd = ["xcodebuild", "-project", str(project)]
        else:
            # Look for project files in directory
            xcworkspace = list(project.glob("*.xcworkspace"))
            xcodeproj = list(project.glob("*.xcodeproj"))
            if xcworkspace:
                cmd = ["xcodebuild", "-workspace", str(xcworkspace[0])]
            elif xcodeproj:
                cmd = ["xcodebuild", "-project", str(xcodeproj[0])]
            else:
                return {"error": "No .xcodeproj or .xcworkspace found in project directory"}

        cmd.extend([
            "-scheme", scheme,
            "-configuration", configuration,
            "-sdk", sdk,
            "CODE_SIGN_IDENTITY=",
            "CODE_SIGNING_REQUIRED=NO",
            "CODE_SIGNING_ALLOWED=NO",
        ])

        if clean:
            # Run clean first
            clean_cmd = cmd + ["clean"]
            await self._run_xcodebuild(clean_cmd)

        try:
            result = await self._run_xcodebuild(cmd)
            if result["returncode"] != 0:
                return {
                    "success": False,
                    "error": result["stderr"][-5000:],
                    "output": result["stdout"][-5000:],
                    "returncode": result["returncode"],
                }

            # Find built product
            derived_data = self._find_derived_data(scheme)

            return {
                "success": True,
                "scheme": scheme,
                "configuration": configuration,
                "sdk": sdk,
                "output": result["stdout"][-2000:],
                "derived_data": str(derived_data) if derived_data else None,
            }

        except Exception as exc:
            return {"error": str(exc)}

    async def deploy(
        self,
        app_path: str,
        device_id: str | None = None,
    ) -> dict[str, Any]:
        """Deploy an app to an iOS simulator.

        Args:
            app_path: Path to the .app bundle.
            device_id: Simulator device ID.

        Returns:
            Deployment result.
        """
        app = Path(app_path).expanduser().resolve()
        if not app.exists():
            return {"error": f"App bundle not found: {app_path}"}

        if device_id:
            cmd = ["xcrun", "simctl", "install", device_id, str(app)]
        else:
            # Use booted simulator
            cmd = ["xcrun", "simctl", "install", "booted", str(app)]

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()

            if proc.returncode != 0:
                return {
                    "success": False,
                    "error": stderr.decode(errors="replace"),
                    "returncode": proc.returncode,
                }

            return {
                "success": True,
                "device_id": device_id or "booted",
                "app": str(app),
            }

        except FileNotFoundError:
            return {"error": "xcrun not found. Ensure Xcode command-line tools are installed."}
        except Exception as exc:
            return {"error": str(exc)}

    async def list_simulators(self) -> dict[str, Any]:
        """List available iOS simulators."""
        try:
            proc = await asyncio.create_subprocess_exec(
                "xcrun", "simctl", "list", "devices", "--json",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()

            import json
            data = json.loads(stdout.decode(errors="replace"))

            simulators = []
            for runtime, devices in data.get("devices", {}).items():
                for device in devices:
                    simulators.append({
                        "name": device.get("name", ""),
                        "id": device.get("udid", ""),
                        "state": device.get("state", ""),
                        "runtime": runtime,
                    })

            return {"simulators": simulators, "count": len(simulators)}

        except (FileNotFoundError, json.JSONDecodeError) as exc:
            return {"error": str(exc)}

    async def _run_xcodebuild(self, cmd: list[str]) -> dict[str, Any]:
        """Run an xcodebuild command."""
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        return {
            "stdout": stdout.decode(errors="replace"),
            "stderr": stderr.decode(errors="replace"),
            "returncode": proc.returncode or 0,
        }

    @staticmethod
    def _find_derived_data(scheme: str) -> Path | None:
        """Find the derived data directory for a scheme."""
        home = Path.home()
        derived = home / "Library" / "Developer" / "Xcode" / "DerivedData"
        if not derived.exists():
            return None

        for entry in derived.iterdir():
            if entry.is_dir() and scheme.lower().replace(" ", "_") in entry.name.lower():
                build_products = entry / "Build" / "Products"
                if build_products.exists():
                    return build_products

        return None
