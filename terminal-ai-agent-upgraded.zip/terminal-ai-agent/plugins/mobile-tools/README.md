# mobile-tools

Mobile development tools for Android and iOS.

## Tools

### `android_build`

Build an Android project using Gradle.

**Parameters:**
- `project_path` (string, required) — Path to Android project root.
- `variant` (string) — Build variant: `debug` or `release`.
- `tasks` (array) — Custom Gradle tasks.
- `clean` (boolean) — Run clean before building.

**Returns:** Build status, output, and APK path.

### `ios_build`

Build an iOS project using xcodebuild.

**Parameters:**
- `project_path` (string, required) — Path to `.xcodeproj` or `.xcworkspace`.
- `scheme` (string, required) — Xcode scheme to build.
- `configuration` (string) — `Debug` or `Release`.
- `sdk` (string) — `iphonesimulator` or `iphoneos`.
- `clean` (boolean) — Run clean before building.

**Returns:** Build status, output, and derived data path.

### `device_deploy`

Deploy a built app to a connected device or emulator.

**Parameters:**
- `platform` (string, required) — `android` or `ios`.
- `app_path` (string, required) — Path to APK or .app bundle.
- `device_id` (string) — Target device/emulator ID.

**Returns:** Deployment status and device info.

## Configuration

```toml
[plugins.mobile-tools]
android_sdk_path = "/path/to/android-sdk"
java_home = "/path/to/jdk"
xcode_path = "/Applications/Xcode.app"
```

## Environment Variables

- `ANDROID_HOME` / `ANDROID_SDK_ROOT` — Android SDK path
- `JAVA_HOME` — JDK path

## Testing

```bash
cd plugins/mobile-tools
python -m pytest tests/ -v
```
