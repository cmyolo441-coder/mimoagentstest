"""Monitoring tools plugin — Prometheus and Grafana integration.

Provides tools for querying Prometheus metrics, managing Grafana
dashboards, and checking alert status.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.plugins.api import PluginBase, PluginContext

from .prometheus import PrometheusManager
from .grafana import GrafanaManager

logger = logging.getLogger(__name__)


class MonitoringToolsPlugin(PluginBase):
    """Plugin providing monitoring and observability tools.

    Tools:
        prometheus_query: Query Prometheus for metrics and time series data.
        grafana_dashboard: List, get, and create Grafana dashboards.
        alert_check: Check firing and pending alerts from Prometheus/Alertmanager.
    """

    name = "monitoring-tools"
    version = "1.0.0"

    def __init__(self) -> None:
        self._context: PluginContext | None = None
        self._prometheus: PrometheusManager | None = None
        self._grafana: GrafanaManager | None = None

    def activate(self, context: PluginContext | None = None) -> None:
        """Initialize the monitoring tools plugin."""
        self._context = context or PluginContext()
        cfg = self._context.config if self._context else {}
        self._prometheus = PrometheusManager(
            url=cfg.get("prometheus_url", "http://localhost:9090"),
            timeout=cfg.get("timeout", 30),
        )
        self._grafana = GrafanaManager(
            url=cfg.get("grafana_url", "http://localhost:3000"),
            api_key=cfg.get("grafana_api_key", ""),
        )
        if self._context:
            self._context.log.info("Monitoring tools plugin activated")

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions."""
        return [
            {
                "name": "prometheus_query",
                "description": "Query Prometheus for metrics. Supports instant queries, range queries, and metric metadata.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "PromQL query expression.",
                        },
                        "action": {
                            "type": "string",
                            "description": "Query type: instant, range, metadata, targets.",
                            "default": "instant",
                        },
                        "start": {
                            "type": "string",
                            "description": "Range query start time (RFC3339 or Unix timestamp).",
                        },
                        "end": {
                            "type": "string",
                            "description": "Range query end time.",
                        },
                        "step": {
                            "type": "string",
                            "description": "Range query step (e.g., '15s', '1m', '1h').",
                            "default": "15s",
                        },
                        "metric": {
                            "type": "string",
                            "description": "Metric name for metadata queries.",
                        },
                    },
                    "required": [],
                },
                "returns": "Query results, time series data, or metadata.",
            },
            {
                "name": "grafana_dashboard",
                "description": "Manage Grafana dashboards — list, get details, search, or create dashboards.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "description": "Action: list, get, search, create.",
                            "default": "list",
                        },
                        "uid": {
                            "type": "string",
                            "description": "Dashboard UID for get action.",
                        },
                        "query": {
                            "type": "string",
                            "description": "Search query for search action.",
                        },
                        "dashboard_json": {
                            "type": "object",
                            "description": "Dashboard JSON model for create action.",
                        },
                        "folder_uid": {
                            "type": "string",
                            "description": "Folder UID for create action.",
                        },
                    },
                    "required": [],
                },
                "returns": "Dashboard list, details, or creation result.",
            },
            {
                "name": "alert_check",
                "description": "Check firing and pending alerts from Prometheus Alertmanager.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "source": {
                            "type": "string",
                            "description": "Alert source: prometheus or alertmanager.",
                            "default": "prometheus",
                        },
                        "state": {
                            "type": "string",
                            "description": "Filter by alert state (firing, pending, inactive).",
                        },
                        "silenced": {
                            "type": "boolean",
                            "description": "Include silenced alerts.",
                            "default": False,
                        },
                    },
                    "required": [],
                },
                "returns": "List of alerts with state, labels, annotations, and timing.",
            },
        ]

    async def handle_tool(self, tool_name: str, parameters: dict[str, Any]) -> Any:
        """Dispatch tool calls."""
        handlers = {
            "prometheus_query": self._prometheus_query,
            "grafana_dashboard": self._grafana_dashboard,
            "alert_check": self._alert_check,
        }
        handler = handlers.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        return await handler(**parameters)

    async def _prometheus_query(
        self,
        query: str = "",
        action: str = "instant",
        start: str | None = None,
        end: str | None = None,
        step: str = "15s",
        metric: str | None = None,
    ) -> dict[str, Any]:
        """Query Prometheus."""
        assert self._prometheus is not None
        return await self._prometheus.query(
            query=query, action=action, start=start, end=end,
            step=step, metric=metric
        )

    async def _grafana_dashboard(
        self,
        action: str = "list",
        uid: str | None = None,
        query: str | None = None,
        dashboard_json: dict[str, Any] | None = None,
        folder_uid: str | None = None,
    ) -> dict[str, Any]:
        """Manage Grafana dashboards."""
        assert self._grafana is not None
        return await self._grafana.manage(
            action=action, uid=uid, query=query,
            dashboard_json=dashboard_json, folder_uid=folder_uid
        )

    async def _alert_check(
        self,
        source: str = "prometheus",
        state: str | None = None,
        silenced: bool = False,
    ) -> dict[str, Any]:
        """Check alerts."""
        assert self._prometheus is not None
        return await self._prometheus.check_alerts(
            source=source, state=state, silenced=silenced
        )

    def cleanup(self) -> None:
        """Release resources."""
        if self._context:
            self._context.log.info("Monitoring tools plugin cleaned up")
        self._prometheus = None
        self._grafana = None
        self._context = None
