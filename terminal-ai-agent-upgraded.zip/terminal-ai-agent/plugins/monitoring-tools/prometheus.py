"""Prometheus manager — query metrics, check alerts, and inspect targets.

Wraps the Prometheus HTTP API for instant queries, range queries,
metric metadata, target discovery, and alert inspection.
"""

from __future__ import annotations

import logging
import time
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class PrometheusManager:
    """Manages Prometheus API interactions.

    Args:
        url: Prometheus server URL.
        timeout: Request timeout in seconds.
    """

    def __init__(self, url: str = "http://localhost:9090", timeout: int = 30) -> None:
        self._url = url.rstrip("/")
        self._timeout = timeout

    async def query(
        self,
        query: str = "",
        action: str = "instant",
        start: str | None = None,
        end: str | None = None,
        step: str = "15s",
        metric: str | None = None,
    ) -> dict[str, Any]:
        """Execute a Prometheus query.

        Args:
            query: PromQL expression.
            action: Query type (instant, range, metadata, targets).
            start: Range start (RFC3339 or Unix timestamp).
            end: Range end.
            step: Range step interval.
            metric: Metric name for metadata queries.

        Returns:
            Query result dictionary.
        """
        actions = {
            "instant": self._instant_query,
            "range": self._range_query,
            "metadata": self._metadata,
            "targets": self._targets,
            "label_values": self._label_values,
        }

        handler = actions.get(action)
        if handler is None:
            return {"error": f"Unknown action: {action}. Available: {list(actions.keys())}"}

        return await handler(query=query, start=start, end=end, step=step, metric=metric)

    async def check_alerts(
        self,
        source: str = "prometheus",
        state: str | None = None,
        silenced: bool = False,
    ) -> dict[str, Any]:
        """Check alerts from Prometheus or Alertmanager.

        Args:
            source: Alert source (prometheus or alertmanager).
            state: Filter by state (firing, pending, inactive).
            silenced: Include silenced alerts.

        Returns:
            Alert list with state, labels, and annotations.
        """
        if source == "alertmanager":
            return await self._alertmanager_alerts(silenced=silenced)

        # Prometheus alerts
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(f"{self._url}/api/v1/alerts")
                resp.raise_for_status()
                data = resp.json()

            if data.get("status") != "success":
                return {"error": f"Prometheus error: {data.get('error', 'Unknown')}"}

            alerts = data.get("data", {}).get("alerts", [])

            # Filter by state
            if state:
                alerts = [a for a in alerts if a.get("state", "").lower() == state.lower()]

            # Filter silenced
            if not silenced:
                alerts = [a for a in alerts if not a.get("silenced")]

            formatted = []
            for alert in alerts:
                formatted.append({
                    "name": alert.get("labels", {}).get("alertname", ""),
                    "state": alert.get("state", ""),
                    "severity": alert.get("labels", {}).get("severity", ""),
                    "summary": alert.get("annotations", {}).get("summary", ""),
                    "description": alert.get("annotations", {}).get("description", ""),
                    "labels": alert.get("labels", {}),
                    "active_at": alert.get("activeAt", ""),
                    "value": alert.get("value", ""),
                })

            return {
                "alerts": formatted,
                "count": len(formatted),
                "source": "prometheus",
            }

        except httpx.HTTPError as exc:
            return {"error": f"Failed to connect to Prometheus: {exc}"}

    async def _instant_query(self, **kwargs: Any) -> dict[str, Any]:
        """Execute an instant PromQL query."""
        query = kwargs.get("query", "")
        if not query:
            return {"error": "query parameter is required for instant queries"}

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(
                    f"{self._url}/api/v1/query",
                    params={"query": query, "time": kwargs.get("start", "")},
                )
                resp.raise_for_status()
                data = resp.json()

            if data.get("status") != "success":
                return {"error": f"Query error: {data.get('error', 'Unknown')}"}

            result_data = data.get("data", {})
            result_type = result_data.get("resultType", "")
            results = result_data.get("result", [])

            formatted = []
            for r in results[:100]:
                entry = {"metric": r.get("metric", {})}
                if result_type == "vector":
                    entry["value"] = r.get("value", [])
                elif result_type == "matrix":
                    entry["values"] = r.get("values", [])[:50]
                formatted.append(entry)

            return {
                "result_type": result_type,
                "results": formatted,
                "count": len(formatted),
            }

        except httpx.HTTPError as exc:
            return {"error": f"Prometheus connection error: {exc}"}

    async def _range_query(self, **kwargs: Any) -> dict[str, Any]:
        """Execute a range PromQL query."""
        query = kwargs.get("query", "")
        start = kwargs.get("start")
        end = kwargs.get("end")
        step = kwargs.get("step", "15s")

        if not query:
            return {"error": "query parameter is required for range queries"}
        if not start or not end:
            return {"error": "start and end parameters are required for range queries"}

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(
                    f"{self._url}/api/v1/query_range",
                    params={"query": query, "start": start, "end": end, "step": step},
                )
                resp.raise_for_status()
                data = resp.json()

            if data.get("status") != "success":
                return {"error": f"Query error: {data.get('error', 'Unknown')}"}

            result_data = data.get("data", {})
            results = result_data.get("result", [])

            formatted = []
            for r in results[:50]:
                formatted.append({
                    "metric": r.get("metric", {}),
                    "values": r.get("values", [])[:200],
                })

            return {
                "result_type": result_data.get("resultType", ""),
                "results": formatted,
                "series_count": len(formatted),
            }

        except httpx.HTTPError as exc:
            return {"error": f"Prometheus connection error: {exc}"}

    async def _metadata(self, **kwargs: Any) -> dict[str, Any]:
        """Get metric metadata."""
        metric = kwargs.get("metric", "")

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                params = {}
                if metric:
                    params["metric"] = metric
                resp = await client.get(f"{self._url}/api/v1/metadata", params=params)
                resp.raise_for_status()
                data = resp.json()

            if data.get("status") != "success":
                return {"error": f"Metadata error: {data.get('error', 'Unknown')}"}

            metadata = data.get("data", {})
            return {
                "metadata": metadata,
                "metric_count": len(metadata),
            }

        except httpx.HTTPError as exc:
            return {"error": f"Prometheus connection error: {exc}"}

    async def _targets(self, **kwargs: Any) -> dict[str, Any]:
        """Get scrape targets."""
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(f"{self._url}/api/v1/targets")
                resp.raise_for_status()
                data = resp.json()

            if data.get("status") != "success":
                return {"error": f"Targets error: {data.get('error', 'Unknown')}"}

            targets_data = data.get("data", {})
            active = targets_data.get("activeTargets", [])
            dropped = targets_data.get("droppedTargets", [])

            return {
                "active_targets": [
                    {
                        "url": t.get("scrapeUrl", ""),
                        "health": t.get("health", ""),
                        "labels": t.get("labels", {}),
                        "last_scrape": t.get("lastScrape", ""),
                    }
                    for t in active[:100]
                ],
                "active_count": len(active),
                "dropped_count": len(dropped),
            }

        except httpx.HTTPError as exc:
            return {"error": f"Prometheus connection error: {exc}"}

    async def _label_values(self, **kwargs: Any) -> dict[str, Any]:
        """Get label values."""
        metric = kwargs.get("metric", "")

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(f"{self._url}/api/v1/label/__name__/values")
                resp.raise_for_status()
                data = resp.json()

            if data.get("status") != "success":
                return {"error": f"Label values error: {data.get('error', 'Unknown')}"}

            values = data.get("data", [])
            if metric:
                values = [v for v in values if metric.lower() in v.lower()]

            return {
                "values": values[:500],
                "count": len(values),
            }

        except httpx.HTTPError as exc:
            return {"error": f"Prometheus connection error: {exc}"}

    async def _alertmanager_alerts(self, silenced: bool = False) -> dict[str, Any]:
        """Get alerts from Alertmanager."""
        # Alertmanager typically runs on port 9093
        am_url = self._url.replace(":9090", ":9093")

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(f"{am_url}/api/v2/alerts")
                resp.raise_for_status()
                alerts = resp.json()

            formatted = []
            for alert in alerts:
                if not silenced and alert.get("status", {}).get("inhibitedBy"):
                    continue
                formatted.append({
                    "name": alert.get("labels", {}).get("alertname", ""),
                    "state": alert.get("status", {}).get("state", ""),
                    "severity": alert.get("labels", {}).get("severity", ""),
                    "receivers": [r.get("name", "") for r in alert.get("receivers", [])],
                    "starts_at": alert.get("startsAt", ""),
                    "ends_at": alert.get("endsAt", ""),
                    "labels": alert.get("labels", {}),
                    "annotations": alert.get("annotations", {}),
                })

            return {
                "alerts": formatted,
                "count": len(formatted),
                "source": "alertmanager",
            }

        except httpx.HTTPError as exc:
            return {"error": f"Alertmanager connection error: {exc}"}
