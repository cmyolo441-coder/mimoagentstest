# monitoring-tools

Monitoring and observability tools for Prometheus and Grafana.

## Tools

### `prometheus_query`

Query Prometheus for metrics and time series data.

**Parameters:**
- `query` (string) — PromQL expression.
- `action` (string) — `instant`, `range`, `metadata`, `targets`.
- `start` / `end` (string) — Time range for range queries.
- `step` (string) — Step interval (default: `15s`).
- `metric` (string) — Metric name for metadata queries.

**Returns:** Query results, time series data, metadata, or target list.

### `grafana_dashboard`

Manage Grafana dashboards.

**Parameters:**
- `action` (string) — `list`, `get`, `search`, `create`, `delete`, `datasources`, `annotations`.
- `uid` (string) — Dashboard UID.
- `query` (string) — Search query.
- `dashboard_json` (object) — Dashboard model for creation.
- `folder_uid` (string) — Target folder.

**Returns:** Dashboard list, details, or operation result.

### `alert_check`

Check firing and pending alerts.

**Parameters:**
- `source` (string) — `prometheus` or `alertmanager`.
- `state` (string) — Filter by state (firing, pending, inactive).
- `silenced` (boolean) — Include silenced alerts.

**Returns:** Alert list with state, labels, annotations, and timing.

## Configuration

```toml
[plugins.monitoring-tools]
prometheus_url = "http://localhost:9090"
grafana_url = "http://localhost:3000"
grafana_api_key = "your-api-key"
timeout = 30
```

## Dependencies

- `httpx` — Async HTTP client

## Testing

```bash
cd plugins/monitoring-tools
python -m pytest tests/ -v
```
