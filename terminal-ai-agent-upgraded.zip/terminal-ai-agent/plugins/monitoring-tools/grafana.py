"""Grafana manager — dashboard management, data source queries, and annotations.

Wraps the Grafana HTTP API for listing, searching, creating, and
managing dashboards and data sources.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class GrafanaManager:
    """Manages Grafana API interactions.

    Args:
        url: Grafana server URL.
        api_key: Grafana API key for authentication.
    """

    def __init__(self, url: str = "http://localhost:3000", api_key: str = "") -> None:
        self._url = url.rstrip("/")
        self._api_key = api_key

    def _headers(self) -> dict[str, str]:
        """Build request headers with authentication."""
        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        return headers

    async def manage(
        self,
        action: str = "list",
        uid: str | None = None,
        query: str | None = None,
        dashboard_json: dict[str, Any] | None = None,
        folder_uid: str | None = None,
    ) -> dict[str, Any]:
        """Manage Grafana dashboards.

        Args:
            action: Operation (list, get, search, create, delete).
            uid: Dashboard UID.
            query: Search query.
            dashboard_json: Dashboard model for creation.
            folder_uid: Target folder for creation.

        Returns:
            Operation result.
        """
        actions = {
            "list": self._list_dashboards,
            "get": self._get_dashboard,
            "search": self._search,
            "create": self._create_dashboard,
            "delete": self._delete_dashboard,
            "datasources": self._list_datasources,
            "annotations": self._get_annotations,
        }

        handler = actions.get(action)
        if handler is None:
            return {"error": f"Unknown action: {action}. Available: {list(actions.keys())}"}

        return await handler(
            uid=uid, query=query, dashboard_json=dashboard_json, folder_uid=folder_uid
        )

    async def _list_dashboards(self, **kwargs: Any) -> dict[str, Any]:
        """List all dashboards."""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(
                    f"{self._url}/api/search",
                    headers=self._headers(),
                    params={"type": "dash-db"},
                )
                resp.raise_for_status()
                dashboards = resp.json()

            return {
                "dashboards": [
                    {
                        "uid": d.get("uid", ""),
                        "title": d.get("title", ""),
                        "uri": d.get("uri", ""),
                        "url": d.get("url", ""),
                        "folder_title": d.get("folderTitle", ""),
                        "tags": d.get("tags", []),
                    }
                    for d in dashboards[:100]
                ],
                "count": len(dashboards),
            }

        except httpx.HTTPError as exc:
            return {"error": f"Grafana connection error: {exc}"}

    async def _get_dashboard(self, **kwargs: Any) -> dict[str, Any]:
        """Get a dashboard by UID."""
        uid = kwargs.get("uid")
        if not uid:
            return {"error": "uid parameter is required"}

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(
                    f"{self._url}/api/dashboards/uid/{uid}",
                    headers=self._headers(),
                )
                resp.raise_for_status()
                data = resp.json()

            dashboard = data.get("dashboard", {})
            return {
                "uid": dashboard.get("uid", ""),
                "title": dashboard.get("title", ""),
                "tags": dashboard.get("tags", []),
                "panels": [
                    {
                        "id": p.get("id"),
                        "title": p.get("title", ""),
                        "type": p.get("type", ""),
                    }
                    for p in dashboard.get("panels", [])
                ],
                "panel_count": len(dashboard.get("panels", [])),
                "version": dashboard.get("version"),
            }

        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                return {"error": f"Dashboard not found: {uid}"}
            return {"error": f"Grafana error: {exc}"}
        except httpx.HTTPError as exc:
            return {"error": f"Grafana connection error: {exc}"}

    async def _search(self, **kwargs: Any) -> dict[str, Any]:
        """Search dashboards and folders."""
        query = kwargs.get("query", "")

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(
                    f"{self._url}/api/search",
                    headers=self._headers(),
                    params={"query": query, "type": "dash-db"},
                )
                resp.raise_for_status()
                results = resp.json()

            return {
                "results": [
                    {
                        "uid": r.get("uid", ""),
                        "title": r.get("title", ""),
                        "url": r.get("url", ""),
                        "type": r.get("type", ""),
                        "tags": r.get("tags", []),
                    }
                    for r in results[:50]
                ],
                "count": len(results),
            }

        except httpx.HTTPError as exc:
            return {"error": f"Grafana connection error: {exc}"}

    async def _create_dashboard(self, **kwargs: Any) -> dict[str, Any]:
        """Create or update a dashboard."""
        dashboard_json = kwargs.get("dashboard_json")
        folder_uid = kwargs.get("folder_uid", "")

        if not dashboard_json:
            return {"error": "dashboard_json parameter is required"}

        payload = {
            "dashboard": dashboard_json,
            "folderUid": folder_uid,
            "overwrite": True,
        }

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    f"{self._url}/api/dashboards/db",
                    headers=self._headers(),
                    json=payload,
                )
                resp.raise_for_status()
                data = resp.json()

            return {
                "success": True,
                "uid": data.get("uid", ""),
                "url": data.get("url", ""),
                "version": data.get("version"),
                "status": data.get("status", ""),
            }

        except httpx.HTTPStatusError as exc:
            return {"error": f"Failed to create dashboard: {exc.response.text}"}
        except httpx.HTTPError as exc:
            return {"error": f"Grafana connection error: {exc}"}

    async def _delete_dashboard(self, **kwargs: Any) -> dict[str, Any]:
        """Delete a dashboard by UID."""
        uid = kwargs.get("uid")
        if not uid:
            return {"error": "uid parameter is required"}

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.delete(
                    f"{self._url}/api/dashboards/uid/{uid}",
                    headers=self._headers(),
                )
                resp.raise_for_status()
                data = resp.json()

            return {
                "success": True,
                "uid": uid,
                "title": data.get("title", ""),
                "message": data.get("message", ""),
            }

        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                return {"error": f"Dashboard not found: {uid}"}
            return {"error": f"Failed to delete dashboard: {exc}"}
        except httpx.HTTPError as exc:
            return {"error": f"Grafana connection error: {exc}"}

    async def _list_datasources(self, **kwargs: Any) -> dict[str, Any]:
        """List configured data sources."""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(
                    f"{self._url}/api/datasources",
                    headers=self._headers(),
                )
                resp.raise_for_status()
                datasources = resp.json()

            return {
                "datasources": [
                    {
                        "id": ds.get("id"),
                        "uid": ds.get("uid", ""),
                        "name": ds.get("name", ""),
                        "type": ds.get("type", ""),
                        "url": ds.get("url", ""),
                        "is_default": ds.get("isDefault", False),
                    }
                    for ds in datasources
                ],
                "count": len(datasources),
            }

        except httpx.HTTPError as exc:
            return {"error": f"Grafana connection error: {exc}"}

    async def _get_annotations(self, **kwargs: Any) -> dict[str, Any]:
        """Get dashboard annotations."""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(
                    f"{self._url}/api/annotations",
                    headers=self._headers(),
                    params={"limit": 50},
                )
                resp.raise_for_status()
                annotations = resp.json()

            return {
                "annotations": [
                    {
                        "id": a.get("id"),
                        "text": a.get("text", ""),
                        "dashboard_uid": a.get("dashboardUid", ""),
                        "time": a.get("time"),
                        "tags": a.get("tags", []),
                    }
                    for a in annotations[:50]
                ],
                "count": len(annotations),
            }

        except httpx.HTTPError as exc:
            return {"error": f"Grafana connection error: {exc}"}
