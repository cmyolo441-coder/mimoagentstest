"""Tests for the monitoring-tools plugin."""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from terminal_agent.plugins.api import PluginContext

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from main import MonitoringToolsPlugin
from prometheus import PrometheusManager
from grafana import GrafanaManager


@pytest.fixture
def plugin():
    p = MonitoringToolsPlugin()
    p.activate(PluginContext())
    return p


class TestMonitoringToolsPlugin:
    def test_tools_registered(self, plugin: MonitoringToolsPlugin):
        names = {t["name"] for t in plugin.get_tools()}
        assert names == {"prometheus_query", "grafana_dashboard", "alert_check"}

    def test_tool_schemas_valid(self, plugin: MonitoringToolsPlugin):
        for tool in plugin.get_tools():
            assert "name" in tool
            assert "description" in tool
            assert "parameters" in tool

    @pytest.mark.asyncio
    async def test_unknown_tool(self, plugin: MonitoringToolsPlugin):
        with pytest.raises(ValueError, match="Unknown tool"):
            await plugin.handle_tool("nonexistent", {})

    def test_cleanup(self, plugin: MonitoringToolsPlugin):
        plugin.cleanup()
        assert plugin._prometheus is None
        assert plugin._grafana is None


class TestPrometheusManager:
    def test_init_defaults(self):
        mgr = PrometheusManager()
        assert mgr._url == "http://localhost:9090"
        assert mgr._timeout == 30

    def test_init_custom(self):
        mgr = PrometheusManager(url="http://prometheus:9090", timeout=10)
        assert mgr._url == "http://prometheus:9090"
        assert mgr._timeout == 10

    @pytest.mark.asyncio
    async def test_instant_query_success(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "success",
            "data": {
                "resultType": "vector",
                "result": [
                    {"metric": {"__name__": "up"}, "value": [1234567890, "1"]}
                ],
            },
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient.get", new_callable=AsyncMock, return_value=mock_response):
            mgr = PrometheusManager()
            result = await mgr.query(query="up", action="instant")

        assert result["result_type"] == "vector"
        assert result["count"] == 1

    @pytest.mark.asyncio
    async def test_instant_query_no_query(self):
        mgr = PrometheusManager()
        result = await mgr.query(action="instant")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_range_query_no_params(self):
        mgr = PrometheusManager()
        result = await mgr.query(query="up", action="range")
        assert "error" in result
        assert "start" in result["error"]

    @pytest.mark.asyncio
    async def test_unknown_action(self):
        mgr = PrometheusManager()
        result = await mgr.query(action="unknown")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_connection_error(self):
        with patch("httpx.AsyncClient.get", new_callable=AsyncMock, side_effect=Exception("Connection refused")):
            mgr = PrometheusManager()
            result = await mgr.query(query="up", action="instant")
            assert "error" in result

    @pytest.mark.asyncio
    async def test_check_alerts_success(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "success",
            "data": {
                "alerts": [
                    {
                        "labels": {"alertname": "HighCPU", "severity": "warning"},
                        "state": "firing",
                        "annotations": {"summary": "CPU usage high"},
                        "activeAt": "2024-01-01T00:00:00Z",
                        "value": "95",
                    }
                ]
            },
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient.get", new_callable=AsyncMock, return_value=mock_response):
            mgr = PrometheusManager()
            result = await mgr.check_alerts()

        assert result["count"] == 1
        assert result["alerts"][0]["name"] == "HighCPU"
        assert result["alerts"][0]["state"] == "firing"


class TestGrafanaManager:
    def test_init_defaults(self):
        mgr = GrafanaManager()
        assert mgr._url == "http://localhost:3000"
        assert mgr._api_key == ""

    def test_init_custom(self):
        mgr = GrafanaManager(url="http://grafana:3000", api_key="test-key")
        assert mgr._url == "http://grafana:3000"
        assert mgr._api_key == "test-key"

    def test_headers_with_key(self):
        mgr = GrafanaManager(api_key="test-key")
        headers = mgr._headers()
        assert headers["Authorization"] == "Bearer test-key"

    def test_headers_without_key(self):
        mgr = GrafanaManager()
        headers = mgr._headers()
        assert "Authorization" not in headers

    @pytest.mark.asyncio
    async def test_list_dashboards_success(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = [
            {"uid": "abc", "title": "Test Dashboard", "url": "/d/abc", "folderTitle": "General", "tags": []}
        ]
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient.get", new_callable=AsyncMock, return_value=mock_response):
            mgr = GrafanaManager()
            result = await mgr.manage(action="list")

        assert result["count"] == 1
        assert result["dashboards"][0]["uid"] == "abc"

    @pytest.mark.asyncio
    async def test_get_dashboard_no_uid(self):
        mgr = GrafanaManager()
        result = await mgr.manage(action="get")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_create_dashboard_no_json(self):
        mgr = GrafanaManager()
        result = await mgr.manage(action="create")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_delete_dashboard_no_uid(self):
        mgr = GrafanaManager()
        result = await mgr.manage(action="delete")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_unknown_action(self):
        mgr = GrafanaManager()
        result = await mgr.manage(action="unknown")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_search_success(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = [
            {"uid": "abc", "title": "Found Dashboard", "url": "/d/abc", "type": "dash-db", "tags": ["test"]}
        ]
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient.get", new_callable=AsyncMock, return_value=mock_response):
            mgr = GrafanaManager()
            result = await mgr.manage(action="search", query="test")

        assert result["count"] == 1
        assert result["results"][0]["title"] == "Found Dashboard"
