"""Parquet handler — read, query, and inspect Apache Parquet files.

Uses pyarrow for efficient columnar data access with support for
predicate pushdown and column pruning.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class ParquetHandler:
    """Handles Parquet file operations.

    Supports reading with column selection, row filtering, schema
    inspection, and format conversion.
    """

    async def read(self, path: str, action: str = "read", **kwargs: Any) -> dict[str, Any]:
        """Read and process a Parquet file.

        Args:
            path: Path to the Parquet file.
            action: Operation (read, schema, metadata, sample).
            **kwargs: Action-specific parameters.

        Returns:
            Result dictionary.
        """
        file_path = Path(path).expanduser().resolve()
        if not file_path.exists():
            return {"error": f"File not found: {path}"}

        try:
            import pyarrow.parquet as pq
            parquet_file = pq.ParquetFile(str(file_path))
        except ImportError:
            return {"error": "pyarrow is required. Install with: pip install pyarrow"}
        except Exception as exc:
            return {"error": f"Failed to read Parquet file: {exc}"}

        actions = {
            "read": self._read_data,
            "schema": self._read_schema,
            "metadata": self._read_metadata,
            "sample": self._read_sample,
        }

        handler = actions.get(action)
        if handler is None:
            return {"error": f"Unknown action: {action}. Available: {list(actions.keys())}"}

        return handler(parquet_file, file_path, **kwargs)

    def _read_data(self, pf: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Read Parquet data with optional column selection and filtering."""
        import pandas as pd

        columns = kwargs.get("columns")
        filter_expr = kwargs.get("filter_expr")
        limit = kwargs.get("limit")

        try:
            df = pf.read(columns=columns).to_pandas()
        except Exception as exc:
            return {"error": f"Failed to read columns: {exc}"}

        if filter_expr:
            try:
                df = df.query(filter_expr)
            except Exception as exc:
                return {"error": f"Invalid filter expression: {exc}"}

        total_rows = len(df)
        if limit:
            df = df.head(limit)

        return {
            "data": df.to_dict(orient="records"),
            "columns": list(df.columns),
            "row_count": len(df),
            "total_rows": total_rows,
        }

    def _read_schema(self, pf: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Read the Parquet file schema."""
        schema = pf.schema

        fields = []
        for i in range(len(schema)):
            field = schema.field(i)
            fields.append({
                "name": field.name,
                "type": str(field.type),
                "nullable": field.nullable,
            })

        return {
            "fields": fields,
            "column_count": len(fields),
            "metadata": {k.decode(): v.decode() for k, v in (schema.metadata or {}).items()},
        }

    def _read_metadata(self, pf: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Read Parquet file metadata."""
        metadata = pf.metadata

        row_groups = []
        for i in range(metadata.num_row_groups):
            rg = metadata.row_group(i)
            columns = []
            for j in range(rg.num_columns):
                col = rg.column(j)
                columns.append({
                    "name": col.path_in_schema,
                    "num_values": col.num_values,
                    "compressed_size": col.total_compressed_size,
                    "uncompressed_size": col.total_uncompressed_size,
                })
            row_groups.append({
                "index": i,
                "num_rows": rg.num_rows,
                "total_byte_size": rg.total_byte_size,
                "columns": columns,
            })

        return {
            "num_rows": metadata.num_rows,
            "num_row_groups": metadata.num_row_groups,
            "num_columns": metadata.num_columns,
            "created_by": metadata.created_by,
            "format_version": metadata.format_version,
            "total_byte_size": metadata.serialized_size,
            "row_groups": row_groups,
        }

    def _read_sample(self, pf: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Read a sample of the Parquet data."""
        limit = kwargs.get("limit", 10)
        columns = kwargs.get("columns")

        try:
            table = pf.read(columns=columns)
            df = table.slice(0, min(limit, table.num_rows)).to_pandas()
        except Exception as exc:
            return {"error": f"Failed to read sample: {exc}"}

        return {
            "data": df.to_dict(orient="records"),
            "columns": list(df.columns),
            "sample_size": len(df),
            "total_rows": pf.metadata.num_rows,
        }

    async def convert(
        self,
        path: str,
        output_path: str,
        output_format: str = "csv",
        columns: list[str] | None = None,
    ) -> dict[str, Any]:
        """Convert Parquet to another format.

        Args:
            path: Input Parquet file path.
            output_path: Output file path.
            output_format: Target format (csv, json, excel).
            columns: Columns to include.

        Returns:
            Conversion result.
        """
        file_path = Path(path).expanduser().resolve()
        if not file_path.exists():
            return {"error": f"File not found: {path}"}

        try:
            import pyarrow.parquet as pq
            import pandas as pd

            df = pq.read_table(str(file_path), columns=columns).to_pandas()

            out = Path(output_path).expanduser()
            if output_format == "csv":
                df.to_csv(str(out), index=False)
            elif output_format == "json":
                df.to_json(str(out), orient="records", indent=2)
            elif output_format == "excel":
                df.to_excel(str(out), index=False)
            else:
                return {"error": f"Unsupported format: {output_format}"}

            return {
                "success": True,
                "output_path": str(out),
                "format": output_format,
                "row_count": len(df),
            }
        except ImportError:
            return {"error": "pyarrow is required. Install with: pip install pyarrow"}
        except Exception as exc:
            return {"error": f"Conversion failed: {exc}"}
