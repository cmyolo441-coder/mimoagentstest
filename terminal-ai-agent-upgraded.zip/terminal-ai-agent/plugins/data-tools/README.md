# data-tools

Data processing tools for CSV, JSON, Parquet, and Excel files.

## Tools

### `csv_process`

Read, filter, aggregate, and write CSV files.

**Parameters:**
- `path` (string, required) — Path to CSV file.
- `action` (string) — `read`, `filter`, `aggregate`, `describe`, `convert`.
- `columns` (array) — Columns to select.
- `filter_expr` (string) — Filter expression (e.g., `age > 30`).
- `sort_by` (string) — Column to sort by.
- `limit` (integer) — Max rows to return.
- `output_path` / `output_format` — For conversion.

### `json_transform`

Transform, query, and validate JSON data.

**Parameters:**
- `path` (string, required) — Path to JSON file.
- `action` (string) — `read`, `query`, `flatten`, `merge`, `validate`.
- `query` (string) — Dot-notation query (e.g., `users.*.name`).
- `schema` (object) — JSON Schema for validation.

### `parquet_read`

Read and query Apache Parquet files.

**Parameters:**
- `path` (string, required) — Path to Parquet file.
- `action` (string) — `read`, `schema`, `metadata`, `sample`.
- `columns` (array) — Columns to select.
- `filter_expr` (string) — Row filter.
- `limit` (integer) — Max rows.

### `excel_convert`

Read Excel files and convert between formats.

**Parameters:**
- `path` (string, required) — Path to Excel file.
- `action` (string) — `read`, `sheets`, `convert`, `describe`.
- `sheet` (string/integer) — Sheet name or index.
- `output_format` (string) — Target format (csv, json, parquet).

## Configuration

```toml
[plugins.data-tools]
# No additional configuration required
```

## Dependencies

- `pandas` — Data processing
- `openpyxl` — Excel support
- `pyarrow` — Parquet support

## Testing

```bash
cd plugins/data-tools
python -m pytest tests/ -v
```
