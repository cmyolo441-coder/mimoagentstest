"""Data tools plugin — CSV, JSON, Parquet, and Excel processing."""

from __future__ import annotations

from .main import DataToolsPlugin

__all__ = ["DataToolsPlugin"]
__version__ = "1.0.0"
