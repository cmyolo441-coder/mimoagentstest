"""JSON handler — transform, query, flatten, and validate JSON data.

Provides dot-notation querying, data flattening, merging, and
JSON Schema validation.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class JSONHandler:
    """Handles JSON file operations.

    Supports reading, querying with dot-notation paths, flattening
    nested structures, merging files, and schema validation.
    """

    async def transform(self, path: str, action: str = "read", **kwargs: Any) -> dict[str, Any]:
        """Transform JSON data.

        Args:
            path: Path to the JSON file.
            action: Operation (read, query, flatten, merge, validate).
            **kwargs: Action-specific parameters.

        Returns:
            Result dictionary.
        """
        file_path = Path(path).expanduser().resolve()
        if not file_path.exists():
            return {"error": f"File not found: {path}"}

        try:
            data = json.loads(file_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            return {"error": f"Invalid JSON: {exc}"}
        except Exception as exc:
            return {"error": f"Failed to read file: {exc}"}

        actions = {
            "read": self._read,
            "query": self._query,
            "flatten": self._flatten,
            "merge": self._merge,
            "validate": self._validate,
        }

        handler = actions.get(action)
        if handler is None:
            return {"error": f"Unknown action: {action}. Available: {list(actions.keys())}"}

        return handler(data, file_path, **kwargs)

    def _read(self, data: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Read JSON data with optional depth limit."""
        limit = kwargs.get("limit")

        if isinstance(data, list) and limit:
            data = data[:limit]

        return {
            "data": data,
            "type": type(data).__name__,
            "size": len(data) if isinstance(data, (list, dict)) else 1,
        }

    def _query(self, data: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Query JSON data using dot-notation paths."""
        query = kwargs.get("query", "")
        if not query:
            return {"error": "Query parameter is required"}

        result = self._resolve_path(data, query)
        return {
            "query": query,
            "result": result,
            "type": type(result).__name__ if result is not None else "null",
            "count": len(result) if isinstance(result, list) else None,
        }

    def _flatten(self, data: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Flatten nested JSON into dot-notation keys."""
        output_path = kwargs.get("output_path")

        flat = self._flatten_dict(data)

        if output_path:
            out = Path(output_path).expanduser()
            out.write_text(json.dumps(flat, indent=2, ensure_ascii=False), encoding="utf-8")
            return {"success": True, "output_path": str(out), "key_count": len(flat)}

        return {"data": flat, "key_count": len(flat)}

    def _merge(self, data: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Merge JSON data with another dataset."""
        other = kwargs.get("data")
        if other is None:
            return {"error": "data parameter is required for merge action"}

        output_path = kwargs.get("output_path")

        if isinstance(data, dict) and isinstance(other, dict):
            merged = {**data, **other}
        elif isinstance(data, list) and isinstance(other, list):
            merged = data + other
        else:
            return {"error": f"Cannot merge {type(data).__name__} with {type(other).__name__}"}

        if output_path:
            out = Path(output_path).expanduser()
            out.write_text(json.dumps(merged, indent=2, ensure_ascii=False), encoding="utf-8")
            return {"success": True, "output_path": str(out), "size": len(merged)}

        return {"data": merged, "size": len(merged)}

    def _validate(self, data: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Validate JSON data against a schema."""
        schema = kwargs.get("schema")
        if schema is None:
            return {"error": "schema parameter is required for validate action"}

        try:
            import jsonschema
            jsonschema.validate(instance=data, schema=schema)
            return {"valid": True, "errors": []}
        except ImportError:
            # Basic validation without jsonschema
            return self._basic_validate(data, schema)
        except Exception as exc:
            return {"valid": False, "errors": [str(exc)]}

    def _basic_validate(self, data: Any, schema: dict[str, Any]) -> dict[str, Any]:
        """Basic schema validation without jsonschema library."""
        errors = []
        schema_type = schema.get("type")

        if schema_type == "object" and not isinstance(data, dict):
            errors.append(f"Expected object, got {type(data).__name__}")
        elif schema_type == "array" and not isinstance(data, list):
            errors.append(f"Expected array, got {type(data).__name__}")

        if isinstance(data, dict) and "required" in schema:
            for field in schema["required"]:
                if field not in data:
                    errors.append(f"Missing required field: {field}")

        return {"valid": len(errors) == 0, "errors": errors}

    def _resolve_path(self, data: Any, path: str) -> Any:
        """Resolve a dot-notation path against data."""
        parts = path.replace("[*", ".*").replace("[", ".").replace("]", "").split(".")
        current = data

        for part in parts:
            if part == "*":
                if isinstance(current, list):
                    return current
                return None
            elif isinstance(current, dict):
                current = current.get(part)
            elif isinstance(current, list):
                try:
                    idx = int(part)
                    current = current[idx] if 0 <= idx < len(current) else None
                except ValueError:
                    return None
            else:
                return None

            if current is None:
                return None

        return current

    def _flatten_dict(self, data: Any, prefix: str = "", sep: str = ".") -> dict[str, Any]:
        """Recursively flatten a nested dictionary."""
        items: dict[str, Any] = {}

        if isinstance(data, dict):
            for key, value in data.items():
                new_key = f"{prefix}{sep}{key}" if prefix else key
                if isinstance(value, (dict, list)):
                    items.update(self._flatten_dict(value, new_key, sep))
                else:
                    items[new_key] = value
        elif isinstance(data, list):
            for i, value in enumerate(data):
                new_key = f"{prefix}[{i}]"
                if isinstance(value, (dict, list)):
                    items.update(self._flatten_dict(value, new_key, sep))
                else:
                    items[new_key] = value
        else:
            items[prefix] = data

        return items
