"""CSV handler — read, filter, aggregate, and write CSV files.

Uses pandas for efficient data processing with support for large files
via chunked reading.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class CSVHandler:
    """Handles CSV file operations.

    Supports reading, filtering, aggregation, description, and format
    conversion for CSV files.
    """

    async def process(self, path: str, action: str = "read", **kwargs: Any) -> dict[str, Any]:
        """Process a CSV file.

        Args:
            path: Path to the CSV file.
            action: Operation to perform (read, filter, aggregate, describe, convert).
            **kwargs: Additional parameters for the action.

        Returns:
            Result dictionary with data or metadata.
        """
        file_path = Path(path).expanduser().resolve()
        if not file_path.exists():
            return {"error": f"File not found: {path}"}

        import pandas as pd

        try:
            df = pd.read_csv(file_path)
        except Exception as exc:
            return {"error": f"Failed to read CSV: {exc}"}

        actions = {
            "read": self._read,
            "filter": self._filter,
            "aggregate": self._aggregate,
            "describe": self._describe,
            "convert": self._convert,
        }

        handler = actions.get(action)
        if handler is None:
            return {"error": f"Unknown action: {action}. Available: {list(actions.keys())}"}

        return handler(df, file_path, **kwargs)

    def _read(self, df: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Read CSV with optional column selection and row limit."""
        columns = kwargs.get("columns")
        limit = kwargs.get("limit")
        sort_by = kwargs.get("sort_by")
        ascending = kwargs.get("ascending", True)

        if columns:
            available = [c for c in columns if c in df.columns]
            df = df[available]

        if sort_by and sort_by in df.columns:
            df = df.sort_values(sort_by, ascending=ascending)

        if limit:
            df = df.head(limit)

        return {
            "data": df.to_dict(orient="records"),
            "columns": list(df.columns),
            "row_count": len(df),
            "total_rows": len(df),
        }

    def _filter(self, df: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Filter rows using a query expression."""
        filter_expr = kwargs.get("filter_expr")
        columns = kwargs.get("columns")
        limit = kwargs.get("limit")

        if filter_expr:
            try:
                df = df.query(filter_expr)
            except Exception as exc:
                return {"error": f"Invalid filter expression: {exc}"}

        if columns:
            available = [c for c in columns if c in df.columns]
            df = df[available]

        if limit:
            df = df.head(limit)

        return {
            "data": df.to_dict(orient="records"),
            "columns": list(df.columns),
            "row_count": len(df),
        }

    def _aggregate(self, df: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Provide aggregate statistics."""
        columns = kwargs.get("columns")

        if columns:
            available = [c for c in columns if c in df.columns]
            df = df[available]

        numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
        stats = {}
        for col in numeric_cols:
            stats[col] = {
                "count": int(df[col].count()),
                "mean": float(df[col].mean()) if df[col].count() > 0 else None,
                "min": float(df[col].min()) if df[col].count() > 0 else None,
                "max": float(df[col].max()) if df[col].count() > 0 else None,
                "sum": float(df[col].sum()) if df[col].count() > 0 else None,
                "std": float(df[col].std()) if df[col].count() > 1 else None,
            }

        return {
            "statistics": stats,
            "numeric_columns": numeric_cols,
            "all_columns": list(df.columns),
            "row_count": len(df),
        }

    def _describe(self, df: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Describe the CSV file structure."""
        dtypes = {col: str(dtype) for col, dtype in df.dtypes.items()}
        null_counts = df.isnull().sum().to_dict()

        return {
            "columns": list(df.columns),
            "dtypes": dtypes,
            "null_counts": {k: int(v) for k, v in null_counts.items()},
            "row_count": len(df),
            "column_count": len(df.columns),
            "memory_usage_bytes": int(df.memory_usage(deep=True).sum()),
            "sample": df.head(5).to_dict(orient="records"),
        }

    def _convert(self, df: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Convert CSV to another format."""
        output_path = kwargs.get("output_path")
        output_format = kwargs.get("output_format", "json")

        if not output_path:
            output_path = str(file_path.with_suffix(f".{output_format}"))

        try:
            if output_format == "json":
                df.to_json(output_path, orient="records", indent=2)
            elif output_format == "parquet":
                df.to_parquet(output_path, index=False)
            elif output_format == "excel":
                df.to_excel(output_path, index=False)
            else:
                return {"error": f"Unsupported format: {output_format}"}

            return {
                "success": True,
                "output_path": output_path,
                "format": output_format,
                "row_count": len(df),
            }
        except Exception as exc:
            return {"error": f"Conversion failed: {exc}"}
