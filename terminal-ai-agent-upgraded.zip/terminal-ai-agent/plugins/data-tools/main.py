"""Data tools plugin — process and transform data files.

Provides tools for reading, transforming, and converting data in
CSV, JSON, Parquet, and Excel formats.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.plugins.api import PluginBase, PluginContext

from .csv_handler import CSVHandler
from .json_handler import JSONHandler
from .parquet_handler import ParquetHandler
from .excel_handler import ExcelHandler

logger = logging.getLogger(__name__)


class DataToolsPlugin(PluginBase):
    """Plugin providing data processing tools.

    Tools:
        csv_process: Read, filter, aggregate, and write CSV files.
        json_transform: Transform, filter, and query JSON data.
        parquet_read: Read and query Parquet files.
        excel_convert: Read Excel files and convert between formats.
    """

    name = "data-tools"
    version = "1.0.0"

    def __init__(self) -> None:
        self._context: PluginContext | None = None
        self._csv: CSVHandler | None = None
        self._json: JSONHandler | None = None
        self._parquet: ParquetHandler | None = None
        self._excel: ExcelHandler | None = None

    def activate(self, context: PluginContext | None = None) -> None:
        """Initialize the data tools plugin."""
        self._context = context or PluginContext()
        self._csv = CSVHandler()
        self._json = JSONHandler()
        self._parquet = ParquetHandler()
        self._excel = ExcelHandler()
        if self._context:
            self._context.log.info("Data tools plugin activated")

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions."""
        return [
            {
                "name": "csv_process",
                "description": "Read, filter, aggregate, and write CSV files. Supports column selection, row filtering, sorting, and aggregation.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path to the CSV file.",
                        },
                        "action": {
                            "type": "string",
                            "description": "Action: read, filter, aggregate, describe, convert.",
                            "default": "read",
                        },
                        "columns": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Columns to select.",
                        },
                        "filter_expr": {
                            "type": "string",
                            "description": "Filter expression (e.g., 'age > 30', 'name == \"Alice\"').",
                        },
                        "sort_by": {
                            "type": "string",
                            "description": "Column to sort by.",
                        },
                        "ascending": {
                            "type": "boolean",
                            "description": "Sort order.",
                            "default": True,
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum rows to return.",
                        },
                        "output_path": {
                            "type": "string",
                            "description": "Output file path for convert action.",
                        },
                        "output_format": {
                            "type": "string",
                            "description": "Output format for convert (json, parquet, excel).",
                        },
                    },
                    "required": ["path"],
                },
                "returns": "Processed data, statistics, or conversion result.",
            },
            {
                "name": "json_transform",
                "description": "Transform, filter, and query JSON data. Supports JSONPath-like queries and data reshaping.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path to the JSON file.",
                        },
                        "action": {
                            "type": "string",
                            "description": "Action: read, query, flatten, merge, validate.",
                            "default": "read",
                        },
                        "query": {
                            "type": "string",
                            "description": "Dot-notation query path (e.g., 'users.*.name').",
                        },
                        "data": {
                            "description": "Inline JSON data for merge/validate actions.",
                        },
                        "schema": {
                            "type": "object",
                            "description": "JSON Schema for validate action.",
                        },
                        "output_path": {
                            "type": "string",
                            "description": "Output file path.",
                        },
                    },
                    "required": ["path"],
                },
                "returns": "Queried/transformed data or validation result.",
            },
            {
                "name": "parquet_read",
                "description": "Read and query Apache Parquet files. Supports column selection, row filtering, and metadata inspection.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path to the Parquet file.",
                        },
                        "action": {
                            "type": "string",
                            "description": "Action: read, schema, metadata, sample.",
                            "default": "read",
                        },
                        "columns": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Columns to select.",
                        },
                        "filter_expr": {
                            "type": "string",
                            "description": "Row filter expression.",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum rows to return.",
                        },
                        "output_path": {
                            "type": "string",
                            "description": "Output path for conversion.",
                        },
                        "output_format": {
                            "type": "string",
                            "description": "Output format (csv, json, excel).",
                        },
                    },
                    "required": ["path"],
                },
                "returns": "Parquet data, schema, or metadata.",
            },
            {
                "name": "excel_convert",
                "description": "Read Excel files and convert between formats. Supports multi-sheet workbooks.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path to the Excel file.",
                        },
                        "action": {
                            "type": "string",
                            "description": "Action: read, sheets, convert, describe.",
                            "default": "read",
                        },
                        "sheet": {
                            "description": "Sheet name (string) or index (integer).",
                        },
                        "columns": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Columns to select.",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum rows to return.",
                        },
                        "output_path": {
                            "type": "string",
                            "description": "Output file path.",
                        },
                        "output_format": {
                            "type": "string",
                            "description": "Output format (csv, json, parquet).",
                        },
                    },
                    "required": ["path"],
                },
                "returns": "Excel data, sheet list, or conversion result.",
            },
        ]

    async def handle_tool(self, tool_name: str, parameters: dict[str, Any]) -> Any:
        """Dispatch tool calls."""
        handlers = {
            "csv_process": self._csv_process,
            "json_transform": self._json_transform,
            "parquet_read": self._parquet_read,
            "excel_convert": self._excel_convert,
        }
        handler = handlers.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        return await handler(**parameters)

    async def _csv_process(self, path: str, action: str = "read", **kwargs: Any) -> dict[str, Any]:
        """Process CSV files."""
        assert self._csv is not None
        return await self._csv.process(path, action=action, **kwargs)

    async def _json_transform(self, path: str, action: str = "read", **kwargs: Any) -> dict[str, Any]:
        """Transform JSON data."""
        assert self._json is not None
        return await self._json.transform(path, action=action, **kwargs)

    async def _parquet_read(self, path: str, action: str = "read", **kwargs: Any) -> dict[str, Any]:
        """Read Parquet files."""
        assert self._parquet is not None
        return await self._parquet.read(path, action=action, **kwargs)

    async def _excel_convert(self, path: str, action: str = "read", **kwargs: Any) -> dict[str, Any]:
        """Read and convert Excel files."""
        assert self._excel is not None
        return await self._excel.process(path, action=action, **kwargs)

    def cleanup(self) -> None:
        """Release resources."""
        if self._context:
            self._context.log.info("Data tools plugin cleaned up")
        self._csv = None
        self._json = None
        self._parquet = None
        self._excel = None
        self._context = None
