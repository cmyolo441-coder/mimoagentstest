"""Tests for the data-tools plugin."""

from __future__ import annotations

import json
import pytest
from pathlib import Path

from terminal_agent.plugins.api import PluginContext

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from main import DataToolsPlugin
from csv_handler import CSVHandler
from json_handler import JSONHandler
from parquet_handler import ParquetHandler
from excel_handler import ExcelHandler


@pytest.fixture
def plugin():
    p = DataToolsPlugin()
    p.activate(PluginContext())
    return p


@pytest.fixture
def sample_csv(tmp_path: Path) -> Path:
    f = tmp_path / "data.csv"
    f.write_text("name,age,city\nAlice,30,NYC\nBob,25,LA\nCharlie,35,Chicago\nDiana,28,NYC\n")
    return f


@pytest.fixture
def sample_json(tmp_path: Path) -> Path:
    f = tmp_path / "data.json"
    f.write_text(json.dumps({
        "users": [
            {"name": "Alice", "age": 30, "city": "NYC"},
            {"name": "Bob", "age": 25, "city": "LA"},
        ],
        "count": 2,
    }))
    return f


class TestDataToolsPlugin:
    def test_tools_registered(self, plugin: DataToolsPlugin):
        names = {t["name"] for t in plugin.get_tools()}
        assert names == {"csv_process", "json_transform", "parquet_read", "excel_convert"}

    def test_tool_schemas_valid(self, plugin: DataToolsPlugin):
        for tool in plugin.get_tools():
            assert "name" in tool
            assert "parameters" in tool

    @pytest.mark.asyncio
    async def test_unknown_tool(self, plugin: DataToolsPlugin):
        with pytest.raises(ValueError, match="Unknown tool"):
            await plugin.handle_tool("nonexistent", {})

    def test_cleanup(self, plugin: DataToolsPlugin):
        plugin.cleanup()
        assert plugin._csv is None


class TestCSVHandler:
    @pytest.mark.asyncio
    async def test_read(self, sample_csv: Path):
        handler = CSVHandler()
        result = await handler.process(str(sample_csv), action="read")
        assert result["row_count"] == 4
        assert len(result["data"]) == 4
        assert "name" in result["columns"]

    @pytest.mark.asyncio
    async def test_read_with_columns(self, sample_csv: Path):
        handler = CSVHandler()
        result = await handler.process(str(sample_csv), action="read", columns=["name", "age"])
        assert result["columns"] == ["name", "age"]

    @pytest.mark.asyncio
    async def test_read_with_limit(self, sample_csv: Path):
        handler = CSVHandler()
        result = await handler.process(str(sample_csv), action="read", limit=2)
        assert result["row_count"] == 2

    @pytest.mark.asyncio
    async def test_filter(self, sample_csv: Path):
        handler = CSVHandler()
        result = await handler.process(str(sample_csv), action="filter", filter_expr="age > 28")
        assert result["row_count"] == 2

    @pytest.mark.asyncio
    async def test_describe(self, sample_csv: Path):
        handler = CSVHandler()
        result = await handler.process(str(sample_csv), action="describe")
        assert result["row_count"] == 4
        assert result["column_count"] == 3
        assert "name" in result["columns"]

    @pytest.mark.asyncio
    async def test_aggregate(self, sample_csv: Path):
        handler = CSVHandler()
        result = await handler.process(str(sample_csv), action="aggregate")
        assert "statistics" in result
        assert "age" in result["statistics"]
        assert result["statistics"]["age"]["mean"] == 29.5

    @pytest.mark.asyncio
    async def test_convert_to_json(self, sample_csv: Path, tmp_path: Path):
        handler = CSVHandler()
        out = tmp_path / "output.json"
        result = await handler.process(
            str(sample_csv), action="convert",
            output_path=str(out), output_format="json"
        )
        assert result["success"] is True
        assert out.exists()

    @pytest.mark.asyncio
    async def test_file_not_found(self):
        handler = CSVHandler()
        result = await handler.process("/nonexistent/file.csv")
        assert "error" in result


class TestJSONHandler:
    @pytest.mark.asyncio
    async def test_read(self, sample_json: Path):
        handler = JSONHandler()
        result = await handler.transform(str(sample_json), action="read")
        assert result["type"] == "dict"
        assert result["data"]["count"] == 2

    @pytest.mark.asyncio
    async def test_query(self, sample_json: Path):
        handler = JSONHandler()
        result = await handler.transform(str(sample_json), action="query", query="users.*.name")
        assert result["result"] == ["Alice", "Bob"]

    @pytest.mark.asyncio
    async def test_flatten(self, sample_json: Path):
        handler = JSONHandler()
        result = await handler.transform(str(sample_json), action="flatten")
        assert "data" in result
        assert "users[0].name" in result["data"]

    @pytest.mark.asyncio
    async def test_validate_success(self, sample_json: Path):
        handler = JSONHandler()
        schema = {
            "type": "object",
            "required": ["users", "count"],
            "properties": {
                "users": {"type": "array"},
                "count": {"type": "number"},
            },
        }
        result = await handler.transform(str(sample_json), action="validate", schema=schema)
        assert result["valid"] is True

    @pytest.mark.asyncio
    async def test_validate_failure(self, sample_json: Path):
        handler = JSONHandler()
        schema = {"type": "object", "required": ["nonexistent"]}
        result = await handler.transform(str(sample_json), action="validate", schema=schema)
        assert result["valid"] is False

    @pytest.mark.asyncio
    async def test_file_not_found(self):
        handler = JSONHandler()
        result = await handler.transform("/nonexistent/file.json")
        assert "error" in result


class TestParquetHandler:
    @pytest.mark.asyncio
    async def test_read_not_found(self):
        handler = ParquetHandler()
        result = await handler.read("/nonexistent/file.parquet")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_read_sample(self, tmp_path: Path):
        try:
            import pyarrow
            import pandas as pd
        except ImportError:
            pytest.skip("pyarrow not installed")

        df = pd.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})
        parquet_path = tmp_path / "test.parquet"
        df.to_parquet(str(parquet_path), index=False)

        handler = ParquetHandler()
        result = await handler.read(str(parquet_path), action="sample", limit=2)
        assert result["sample_size"] == 2
        assert result["total_rows"] == 3

    @pytest.mark.asyncio
    async def test_read_schema(self, tmp_path: Path):
        try:
            import pyarrow
            import pandas as pd
        except ImportError:
            pytest.skip("pyarrow not installed")

        df = pd.DataFrame({"a": [1, 2], "b": ["x", "y"]})
        parquet_path = tmp_path / "test.parquet"
        df.to_parquet(str(parquet_path), index=False)

        handler = ParquetHandler()
        result = await handler.read(str(parquet_path), action="schema")
        assert result["column_count"] == 2
        names = {f["name"] for f in result["fields"]}
        assert names == {"a", "b"}


class TestExcelHandler:
    @pytest.mark.asyncio
    async def test_read_not_found(self):
        handler = ExcelHandler()
        result = await handler.process("/nonexistent/file.xlsx")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_sheets(self, tmp_path: Path):
        try:
            import openpyxl
        except ImportError:
            pytest.skip("openpyxl not installed")

        wb = openpyxl.Workbook()
        wb.active.title = "Sheet1"
        wb.create_sheet("Sheet2")
        xlsx_path = tmp_path / "test.xlsx"
        wb.save(str(xlsx_path))
        wb.close()

        handler = ExcelHandler()
        result = await handler.process(str(xlsx_path), action="sheets")
        assert result["count"] == 2
        names = {s["name"] for s in result["sheets"]}
        assert "Sheet1" in names
        assert "Sheet2" in names

    @pytest.mark.asyncio
    async def test_read_sheet(self, tmp_path: Path):
        try:
            import openpyxl
        except ImportError:
            pytest.skip("openpyxl not installed")

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["name", "age"])
        ws.append(["Alice", 30])
        ws.append(["Bob", 25])
        xlsx_path = tmp_path / "test.xlsx"
        wb.save(str(xlsx_path))
        wb.close()

        handler = ExcelHandler()
        result = await handler.process(str(xlsx_path), action="read")
        assert result["row_count"] == 2
        assert result["columns"] == ["name", "age"]
