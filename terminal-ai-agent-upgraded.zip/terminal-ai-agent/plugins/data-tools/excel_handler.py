"""Excel handler — read, inspect, and convert Excel workbooks.

Uses openpyxl for .xlsx files with support for multi-sheet workbooks,
column selection, and format conversion.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class ExcelHandler:
    """Handles Excel file operations.

    Supports reading specific sheets, column selection, sheet listing,
    description, and conversion to other formats.
    """

    async def process(self, path: str, action: str = "read", **kwargs: Any) -> dict[str, Any]:
        """Process an Excel file.

        Args:
            path: Path to the Excel file.
            action: Operation (read, sheets, convert, describe).
            **kwargs: Action-specific parameters.

        Returns:
            Result dictionary.
        """
        file_path = Path(path).expanduser().resolve()
        if not file_path.exists():
            return {"error": f"File not found: {path}"}

        try:
            import openpyxl
            wb = openpyxl.load_workbook(str(file_path), read_only=True, data_only=True)
        except ImportError:
            return {"error": "openpyxl is required. Install with: pip install openpyxl"}
        except Exception as exc:
            return {"error": f"Failed to open Excel file: {exc}"}

        actions = {
            "read": self._read,
            "sheets": self._list_sheets,
            "convert": self._convert,
            "describe": self._describe,
        }

        handler = actions.get(action)
        if handler is None:
            wb.close()
            return {"error": f"Unknown action: {action}. Available: {list(actions.keys())}"}

        try:
            return handler(wb, file_path, **kwargs)
        finally:
            wb.close()

    def _read(self, wb: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Read data from a specific sheet."""
        import pandas as pd

        sheet = kwargs.get("sheet", 0)
        columns = kwargs.get("columns")
        limit = kwargs.get("limit")

        try:
            if isinstance(sheet, int):
                sheet_names = wb.sheetnames
                if sheet >= len(sheet_names):
                    return {"error": f"Sheet index {sheet} out of range. Available: {len(sheet_names)} sheets"}
                sheet = sheet_names[sheet]

            df = pd.read_excel(str(file_path), sheet_name=sheet)
        except Exception as exc:
            return {"error": f"Failed to read sheet: {exc}"}

        if columns:
            available = [c for c in columns if c in df.columns]
            df = df[available]

        if limit:
            df = df.head(limit)

        return {
            "data": df.to_dict(orient="records"),
            "columns": list(df.columns),
            "row_count": len(df),
            "sheet": sheet,
        }

    def _list_sheets(self, wb: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """List all sheets in the workbook."""
        sheets = []
        for name in wb.sheetnames:
            ws = wb[name]
            sheets.append({
                "name": name,
                "max_row": ws.max_row,
                "max_column": ws.max_column,
            })

        return {
            "sheets": sheets,
            "count": len(sheets),
        }

    def _describe(self, wb: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Describe the Excel file structure."""
        import pandas as pd

        sheet = kwargs.get("sheet", 0)

        try:
            if isinstance(sheet, int):
                sheet = wb.sheetnames[sheet]

            df = pd.read_excel(str(file_path), sheet_name=sheet)
        except Exception as exc:
            return {"error": f"Failed to read sheet: {exc}"}

        dtypes = {col: str(dtype) for col, dtype in df.dtypes.items()}
        null_counts = df.isnull().sum().to_dict()

        return {
            "sheet": sheet,
            "columns": list(df.columns),
            "dtypes": dtypes,
            "null_counts": {k: int(v) for k, v in null_counts.items()},
            "row_count": len(df),
            "column_count": len(df.columns),
            "all_sheets": wb.sheetnames,
            "sample": df.head(5).to_dict(orient="records"),
        }

    def _convert(self, wb: Any, file_path: Path, **kwargs: Any) -> dict[str, Any]:
        """Convert Excel to another format."""
        import pandas as pd

        sheet = kwargs.get("sheet", 0)
        output_path = kwargs.get("output_path")
        output_format = kwargs.get("output_format", "csv")

        try:
            if isinstance(sheet, int):
                sheet_names = wb.sheetnames
                if sheet >= len(sheet_names):
                    return {"error": f"Sheet index {sheet} out of range"}
                sheet = sheet_names[sheet]

            df = pd.read_excel(str(file_path), sheet_name=sheet)
        except Exception as exc:
            return {"error": f"Failed to read sheet: {exc}"}

        if not output_path:
            output_path = str(file_path.with_suffix(f".{output_format}"))

        try:
            out = Path(output_path).expanduser()
            if output_format == "csv":
                df.to_csv(str(out), index=False)
            elif output_format == "json":
                df.to_json(str(out), orient="records", indent=2)
            elif output_format == "parquet":
                df.to_parquet(str(out), index=False)
            else:
                return {"error": f"Unsupported format: {output_format}. Use csv, json, or parquet."}

            return {
                "success": True,
                "output_path": str(out),
                "format": output_format,
                "sheet": sheet,
                "row_count": len(df),
            }
        except Exception as exc:
            return {"error": f"Conversion failed: {exc}"}
