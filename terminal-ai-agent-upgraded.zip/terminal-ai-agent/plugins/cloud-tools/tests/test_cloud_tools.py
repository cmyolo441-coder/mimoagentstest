"""Tests for the cloud-tools plugin."""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from terminal_agent.plugins.api import PluginContext

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from main import CloudToolsPlugin
from aws import AWSManager
from gcp import GCPManager
from azure import AzureManager


@pytest.fixture
def plugin():
    p = CloudToolsPlugin()
    p.activate(PluginContext())
    return p


class TestCloudToolsPlugin:
    def test_tools_registered(self, plugin: CloudToolsPlugin):
        names = {t["name"] for t in plugin.get_tools()}
        assert names == {"aws_cli", "gcp_cli", "azure_cli"}

    def test_tool_schemas_valid(self, plugin: CloudToolsPlugin):
        for tool in plugin.get_tools():
            assert "name" in tool
            assert "parameters" in tool
            params = tool["parameters"]
            assert "required" in params
            assert "service" in params["required"]
            assert "action" in params["required"]

    @pytest.mark.asyncio
    async def test_unknown_tool(self, plugin: CloudToolsPlugin):
        with pytest.raises(ValueError, match="Unknown tool"):
            await plugin.handle_tool("nonexistent", {})

    def test_cleanup(self, plugin: CloudToolsPlugin):
        plugin.cleanup()
        assert plugin._aws is None
        assert plugin._gcp is None
        assert plugin._azure is None


class TestAWSManager:
    def test_init_defaults(self):
        mgr = AWSManager()
        assert mgr._region == "us-east-1"
        assert mgr._profile == "default"

    def test_init_custom(self):
        mgr = AWSManager(region="eu-west-1", profile="production")
        assert mgr._region == "eu-west-1"
        assert mgr._profile == "production"

    def test_action_map_ec2(self):
        amap = AWSManager._get_action_map("ec2")
        assert "list_instances" in amap
        assert amap["list_instances"] == "describe_instances"

    def test_action_map_s3(self):
        amap = AWSManager._get_action_map("s3")
        assert "list_buckets" in amap

    def test_action_map_unknown(self):
        amap = AWSManager._get_action_map("unknown_service")
        assert amap == {}

    @pytest.mark.asyncio
    async def test_unknown_action(self):
        mgr = AWSManager()
        # Force CLI fallback by setting session to None
        mgr._session = None
        with patch.object(mgr, "_execute_cli", new_callable=AsyncMock, return_value={"error": "mock"}):
            result = await mgr.execute("ec2", "unknown_action", {})
            # Should return error about unknown action
            assert "error" in result or "available_actions" in result

    @pytest.mark.asyncio
    async def test_execute_cli_not_found(self):
        mgr = AWSManager()
        with patch("asyncio.create_subprocess_exec", side_effect=FileNotFoundError):
            result = await mgr._execute_cli("ec2", "list_instances", {}, "us-east-1")
            assert "error" in result
            assert "AWS CLI" in result["error"]


class TestGCPManager:
    def test_init(self):
        mgr = GCPManager(project="my-project")
        assert mgr._project == "my-project"

    def test_action_map_compute(self):
        amap = GCPManager._get_action_map("compute")
        assert "list_instances" in amap

    def test_action_map_storage(self):
        amap = GCPManager._get_action_map("storage")
        assert "list_buckets" in amap

    @pytest.mark.asyncio
    async def test_unknown_action(self):
        mgr = GCPManager()
        result = await mgr.execute("compute", "unknown_action", {})
        assert "error" in result

    @pytest.mark.asyncio
    async def test_cli_not_found(self):
        mgr = GCPManager()
        with patch("asyncio.create_subprocess_exec", side_effect=FileNotFoundError):
            result = await mgr._execute_cli("compute", "list_instances", {}, zone="us-central1-a")
            assert "error" in result
            assert "gcloud" in result["error"]


class TestAzureManager:
    def test_init(self):
        mgr = AzureManager(subscription="sub-123")
        assert mgr._subscription == "sub-123"

    def test_action_map_vm(self):
        amap = AzureManager._get_action_map("vm")
        assert "list_vms" in amap

    def test_action_map_resource_group(self):
        amap = AzureManager._get_action_map("resource-group")
        assert "list_groups" in amap

    @pytest.mark.asyncio
    async def test_unknown_action(self):
        mgr = AzureManager()
        result = await mgr.execute("vm", "unknown_action", {})
        assert "error" in result

    @pytest.mark.asyncio
    async def test_cli_not_found(self):
        mgr = AzureManager()
        with patch("asyncio.create_subprocess_exec", side_effect=FileNotFoundError):
            result = await mgr._execute_cli("vm", "list_vms", {})
            assert "error" in result
            assert "az" in result["error"]
