"""Google Cloud Platform resource manager.

Provides a high-level interface for common GCP operations across
Compute Engine, Cloud Storage, and Cloud Functions. Falls back to
gcloud CLI when client libraries are not available.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

logger = logging.getLogger(__name__)


class GCPManager:
    """Manages GCP resources via client libraries or CLI fallback.

    Args:
        project: GCP project ID.
    """

    def __init__(self, project: str = "") -> None:
        self._project = project

    async def execute(
        self,
        service: str,
        action: str,
        parameters: dict[str, Any],
        zone: str | None = None,
    ) -> dict[str, Any]:
        """Execute a GCP operation.

        Args:
            service: GCP service (compute, storage, functions).
            action: Action to perform.
            parameters: Service-specific parameters.
            zone: Zone override for compute operations.

        Returns:
            Operation result dictionary.
        """
        method_map = self._get_action_map(service)
        method_name = method_map.get(action)
        if method_name is None:
            return {
                "error": f"Unknown action '{action}' for service '{service}'",
                "available_actions": list(method_map.keys()),
            }

        # Try client libraries first
        try:
            return await self._execute_client(service, action, parameters, zone=zone)
        except ImportError:
            logger.warning("GCP client library not available, falling back to gcloud CLI")
            return await self._execute_cli(service, action, parameters, zone=zone)
        except Exception as exc:
            return {"error": str(exc), "service": service, "action": action}

    async def _execute_client(
        self, service: str, action: str, parameters: dict[str, Any],
        zone: str | None = None
    ) -> dict[str, Any]:
        """Execute via GCP client libraries."""
        if service == "compute":
            return await self._compute_action(action, parameters, zone=zone)
        elif service == "storage":
            return await self._storage_action(action, parameters)
        else:
            raise ImportError(f"No client handler for service: {service}")

    async def _compute_action(
        self, action: str, parameters: dict[str, Any], zone: str | None = None
    ) -> dict[str, Any]:
        """Execute Compute Engine operations."""
        from google.cloud import compute_v1

        effective_zone = zone or "us-central1-a"

        if action == "list_instances":
            client = compute_v1.InstancesClient()
            loop = asyncio.get_event_loop()
            request = compute_v1.ListInstancesRequest(
                project=self._project, zone=effective_zone
            )
            result = await loop.run_in_executor(
                None, lambda: list(client.list(request=request))
            )
            instances = [
                {"name": i.name, "status": i.status, "zone": effective_zone}
                for i in result
            ]
            return {"success": True, "instances": instances, "count": len(instances)}

        raise ValueError(f"Unsupported compute action: {action}")

    async def _storage_action(self, action: str, parameters: dict[str, Any]) -> dict[str, Any]:
        """Execute Cloud Storage operations."""
        from google.cloud import storage

        client = storage.Client(project=self._project)
        loop = asyncio.get_event_loop()

        if action == "list_buckets":
            buckets = await loop.run_in_executor(None, lambda: list(client.list_buckets()))
            return {
                "success": True,
                "buckets": [{"name": b.name} for b in buckets],
                "count": len(buckets),
            }

        if action == "list_objects":
            bucket_name = parameters.get("bucket", "")
            bucket = client.bucket(bucket_name)
            prefix = parameters.get("prefix", "")
            blobs = await loop.run_in_executor(
                None, lambda: list(bucket.list_blobs(prefix=prefix))
            )
            return {
                "success": True,
                "objects": [{"name": b.name, "size": b.size} for b in blobs[:1000]],
                "count": len(blobs),
            }

        raise ValueError(f"Unsupported storage action: {action}")

    async def _execute_cli(
        self, service: str, action: str, parameters: dict[str, Any],
        zone: str | None = None
    ) -> dict[str, Any]:
        """Execute via gcloud CLI."""
        cmd = self._build_cli_command(service, action, parameters, zone=zone)

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                return {"error": stderr.decode().strip(), "returncode": proc.returncode}
            try:
                result = json.loads(stdout.decode())
            except json.JSONDecodeError:
                result = stdout.decode().strip()
            return {"success": True, "result": result}
        except FileNotFoundError:
            return {"error": "gcloud CLI not found. Install Google Cloud SDK."}

    def _build_cli_command(
        self, service: str, action: str, parameters: dict[str, Any],
        zone: str | None = None
    ) -> list[str]:
        """Build gcloud CLI command."""
        cmd = ["gcloud"]

        action_map = {
            ("compute", "list_instances"): ["compute", "instances", "list"],
            ("compute", "list_disks"): ["compute", "disks", "list"],
            ("storage", "list_buckets"): ["storage", "buckets", "list"],
            ("storage", "list_objects"): ["storage", "objects", "list"],
        }

        subcmd = action_map.get((service, action))
        if subcmd:
            cmd.extend(subcmd)
        else:
            cmd.extend([service, action.replace("_", "-")])

        if self._project:
            cmd.extend(["--project", self._project])
        if zone:
            cmd.extend(["--zone", zone])

        for key, value in parameters.items():
            if key not in ("bucket",):
                cmd.extend([f"--{key.replace('_', '-')}", str(value)])

        if service == "storage" and action == "list_objects":
            bucket = parameters.get("bucket", "")
            if bucket:
                cmd = ["gcloud", "storage", "objects", "list", f"gs://{bucket}"]

        cmd.extend(["--format", "json"])
        return cmd

    @staticmethod
    def _get_action_map(service: str) -> dict[str, str]:
        """Map friendly action names to method names."""
        maps: dict[str, dict[str, str]] = {
            "compute": {
                "list_instances": "list_instances",
                "list_disks": "list_disks",
                "list_zones": "list_zones",
            },
            "storage": {
                "list_buckets": "list_buckets",
                "list_objects": "list_objects",
            },
            "functions": {
                "list_functions": "list_functions",
                "describe_function": "get_function",
            },
        }
        return maps.get(service, {})
