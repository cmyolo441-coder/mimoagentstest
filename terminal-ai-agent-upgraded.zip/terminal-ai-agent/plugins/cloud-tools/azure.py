"""Azure resource manager.

Provides a high-level interface for common Azure operations across
Virtual Machines, Storage Accounts, and Resource Groups. Falls back
to Azure CLI when SDK libraries are not available.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

logger = logging.getLogger(__name__)


class AzureManager:
    """Manages Azure resources via SDK or CLI fallback.

    Args:
        subscription: Azure subscription ID.
    """

    def __init__(self, subscription: str = "") -> None:
        self._subscription = subscription
        self._credential: Any = None

    def _get_credential(self) -> Any:
        """Get or create Azure credential."""
        if self._credential is None:
            try:
                from azure.identity import DefaultAzureCredential
                self._credential = DefaultAzureCredential()
            except ImportError:
                logger.warning("azure-identity not installed, falling back to Azure CLI")
        return self._credential

    async def execute(
        self,
        service: str,
        action: str,
        parameters: dict[str, Any],
        resource_group: str | None = None,
    ) -> dict[str, Any]:
        """Execute an Azure operation.

        Args:
            service: Azure service (vm, storage, resource-group).
            action: Action to perform.
            parameters: Service-specific parameters.
            resource_group: Resource group filter.

        Returns:
            Operation result dictionary.
        """
        method_map = self._get_action_map(service)
        method_name = method_map.get(action)
        if method_name is None:
            return {
                "error": f"Unknown action '{action}' for service '{service}'",
                "available_actions": list(method_map.keys()),
            }

        credential = self._get_credential()
        if credential is not None and self._subscription:
            try:
                return await self._execute_sdk(
                    service, action, parameters, resource_group=resource_group
                )
            except ImportError:
                logger.warning("Azure SDK not available, falling back to CLI")
            except Exception as exc:
                return {"error": str(exc), "service": service, "action": action}

        return await self._execute_cli(service, action, parameters, resource_group=resource_group)

    async def _execute_sdk(
        self, service: str, action: str, parameters: dict[str, Any],
        resource_group: str | None = None
    ) -> dict[str, Any]:
        """Execute via Azure SDK."""
        if service in ("vm", "compute"):
            return await self._vm_action(action, parameters, resource_group=resource_group)
        elif service in ("resource-group", "resource_groups"):
            return await self._resource_group_action(action, parameters)
        elif service == "storage":
            return await self._storage_action(action, parameters, resource_group=resource_group)
        raise ImportError(f"No SDK handler for service: {service}")

    async def _vm_action(
        self, action: str, parameters: dict[str, Any],
        resource_group: str | None = None
    ) -> dict[str, Any]:
        """Execute Virtual Machine operations."""
        from azure.mgmt.compute import ComputeManagementClient

        client = ComputeManagementClient(self._get_credential(), self._subscription)
        loop = asyncio.get_event_loop()

        if action == "list_vms":
            if resource_group:
                vms = await loop.run_in_executor(
                    None, lambda: list(client.virtual_machines.list(resource_group))
                )
            else:
                vms = await loop.run_in_executor(
                    None, lambda: list(client.virtual_machines.list_all())
                )
            return {
                "success": True,
                "vms": [
                    {"name": vm.name, "location": vm.location, "vm_size": vm.hardware_profile.vm_size if vm.hardware_profile else None}
                    for vm in vms
                ],
                "count": len(vms),
            }

        raise ValueError(f"Unsupported VM action: {action}")

    async def _resource_group_action(self, action: str, parameters: dict[str, Any]) -> dict[str, Any]:
        """Execute Resource Group operations."""
        from azure.mgmt.resource import ResourceManagementClient

        client = ResourceManagementClient(self._get_credential(), self._subscription)
        loop = asyncio.get_event_loop()

        if action == "list_groups":
            groups = await loop.run_in_executor(
                None, lambda: list(client.resource_groups.list())
            )
            return {
                "success": True,
                "groups": [{"name": g.name, "location": g.location} for g in groups],
                "count": len(groups),
            }

        raise ValueError(f"Unsupported resource-group action: {action}")

    async def _storage_action(
        self, action: str, parameters: dict[str, Any],
        resource_group: str | None = None
    ) -> dict[str, Any]:
        """Execute Storage Account operations."""
        from azure.mgmt.storage import StorageManagementClient

        client = StorageManagementClient(self._get_credential(), self._subscription)
        loop = asyncio.get_event_loop()

        if action == "list_storage_accounts":
            if resource_group:
                accounts = await loop.run_in_executor(
                    None, lambda: list(client.storage_accounts.list_by_resource_group(resource_group))
                )
            else:
                accounts = await loop.run_in_executor(
                    None, lambda: list(client.storage_accounts.list())
                )
            return {
                "success": True,
                "accounts": [{"name": a.name, "location": a.location, "kind": str(a.kind)} for a in accounts],
                "count": len(accounts),
            }

        raise ValueError(f"Unsupported storage action: {action}")

    async def _execute_cli(
        self, service: str, action: str, parameters: dict[str, Any],
        resource_group: str | None = None
    ) -> dict[str, Any]:
        """Execute via Azure CLI."""
        cmd = self._build_cli_command(service, action, parameters, resource_group=resource_group)

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                return {"error": stderr.decode().strip(), "returncode": proc.returncode}
            try:
                result = json.loads(stdout.decode())
            except json.JSONDecodeError:
                result = stdout.decode().strip()
            return {"success": True, "result": result}
        except FileNotFoundError:
            return {"error": "Azure CLI (az) not found. Install Azure CLI."}

    def _build_cli_command(
        self, service: str, action: str, parameters: dict[str, Any],
        resource_group: str | None = None
    ) -> list[str]:
        """Build Azure CLI command."""
        cmd = ["az"]

        action_map = {
            ("vm", "list_vms"): ["vm", "list"],
            ("resource-group", "list_groups"): ["group", "list"],
            ("storage", "list_storage_accounts"): ["storage", "account", "list"],
        }

        subcmd = action_map.get((service, action))
        if subcmd:
            cmd.extend(subcmd)
        else:
            cmd.extend([service, action.replace("_", "-")])

        if resource_group:
            cmd.extend(["--resource-group", resource_group])

        cmd.extend(["--output", "json"])
        return cmd

    @staticmethod
    def _get_action_map(service: str) -> dict[str, str]:
        """Map friendly action names to method names."""
        maps: dict[str, dict[str, str]] = {
            "vm": {"list_vms": "list_vms"},
            "compute": {"list_vms": "list_vms"},
            "resource-group": {"list_groups": "list_groups"},
            "resource_groups": {"list_groups": "list_groups"},
            "storage": {"list_storage_accounts": "list_storage_accounts"},
        }
        return maps.get(service, {})
