# cloud-tools

Cloud resource management for AWS, Google Cloud, and Azure.

## Tools

### `aws_cli`

Execute AWS operations across EC2, S3, Lambda, and IAM.

**Parameters:**
- `service` (string, required) — AWS service (ec2, s3, lambda, iam).
- `action` (string, required) — Action (list_instances, list_buckets, etc.).
- `parameters` (object) — Service-specific parameters.
- `region` (string) — Region override.

### `gcp_cli`

Execute Google Cloud operations across Compute, Storage, and Functions.

**Parameters:**
- `service` (string, required) — GCP service (compute, storage, functions).
- `action` (string, required) — Action (list_instances, list_buckets, etc.).
- `parameters` (object) — Service-specific parameters.
- `zone` (string) — Zone override.

### `azure_cli`

Execute Azure operations across VMs, Storage, and Resource Groups.

**Parameters:**
- `service` (string, required) — Azure service (vm, storage, resource-group).
- `action` (string, required) — Action (list_vms, list_storage_accounts, etc.).
- `parameters` (object) — Service-specific parameters.
- `resource_group` (string) — Resource group filter.

## Configuration

```toml
[plugins.cloud-tools]
aws_region = "us-east-1"
aws_profile = "default"
gcp_project = "my-project"
azure_subscription = "subscription-id"
```

## Dependencies

- `boto3` — AWS SDK
- `google-cloud-compute` — GCP Compute
- `azure-mgmt-resource` — Azure Resource Management
- `azure-identity` — Azure authentication

All tools have CLI fallback when SDKs are not installed.

## Testing

```bash
cd plugins/cloud-tools
python -m pytest tests/ -v
```
