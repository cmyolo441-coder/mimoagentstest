"""Cloud tools plugin — manage resources across AWS, GCP, and Azure.

Provides a unified interface for common cloud operations: listing resources,
managing instances, querying costs, and running cloud CLI commands.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.plugins.api import PluginBase, PluginContext

from .aws import AWSManager
from .gcp import GCPManager
from .azure import AzureManager

logger = logging.getLogger(__name__)

_PROVIDERS = ("aws", "gcp", "azure")


class CloudToolsPlugin(PluginBase):
    """Plugin providing cloud resource management tools.

    Tools:
        aws_cli: Execute AWS operations (list instances, S3 buckets, etc.).
        gcp_cli: Execute GCP operations (list instances, storage, etc.).
        azure_cli: Execute Azure operations (list resources, VMs, etc.).
    """

    name = "cloud-tools"
    version = "1.0.0"

    def __init__(self) -> None:
        self._context: PluginContext | None = None
        self._aws: AWSManager | None = None
        self._gcp: GCPManager | None = None
        self._azure: AzureManager | None = None

    def activate(self, context: PluginContext | None = None) -> None:
        """Initialize cloud tool managers."""
        self._context = context or PluginContext()
        cfg = self._context.config if self._context else {}
        self._aws = AWSManager(
            region=cfg.get("aws_region", "us-east-1"),
            profile=cfg.get("aws_profile", "default"),
        )
        self._gcp = GCPManager(
            project=cfg.get("gcp_project", ""),
        )
        self._azure = AzureManager(
            subscription=cfg.get("azure_subscription", ""),
        )
        if self._context:
            self._context.log.info("Cloud tools plugin activated")

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions."""
        return [
            {
                "name": "aws_cli",
                "description": "Execute AWS cloud operations. Supports EC2, S3, Lambda, IAM, and more.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "service": {
                            "type": "string",
                            "description": "AWS service name (e.g., ec2, s3, lambda, iam).",
                        },
                        "action": {
                            "type": "string",
                            "description": "Action to perform (e.g., list_instances, list_buckets).",
                        },
                        "parameters": {
                            "type": "object",
                            "description": "Service-specific parameters.",
                        },
                        "region": {
                            "type": "string",
                            "description": "AWS region override.",
                        },
                    },
                    "required": ["service", "action"],
                },
                "returns": "Operation result as a dictionary.",
            },
            {
                "name": "gcp_cli",
                "description": "Execute Google Cloud operations. Supports Compute, Storage, Cloud Functions, and more.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "service": {
                            "type": "string",
                            "description": "GCP service name (e.g., compute, storage, functions).",
                        },
                        "action": {
                            "type": "string",
                            "description": "Action to perform (e.g., list_instances, list_buckets).",
                        },
                        "parameters": {
                            "type": "object",
                            "description": "Service-specific parameters.",
                        },
                        "zone": {
                            "type": "string",
                            "description": "GCP zone override.",
                        },
                    },
                    "required": ["service", "action"],
                },
                "returns": "Operation result as a dictionary.",
            },
            {
                "name": "azure_cli",
                "description": "Execute Azure operations. Supports Virtual Machines, Storage, Resource Groups, and more.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "service": {
                            "type": "string",
                            "description": "Azure service name (e.g., vm, storage, resource-group).",
                        },
                        "action": {
                            "type": "string",
                            "description": "Action to perform (e.g., list_vms, list_storage_accounts).",
                        },
                        "parameters": {
                            "type": "object",
                            "description": "Service-specific parameters.",
                        },
                        "resource_group": {
                            "type": "string",
                            "description": "Azure resource group filter.",
                        },
                    },
                    "required": ["service", "action"],
                },
                "returns": "Operation result as a dictionary.",
            },
        ]

    async def handle_tool(self, tool_name: str, parameters: dict[str, Any]) -> Any:
        """Dispatch tool calls to the appropriate cloud manager."""
        handlers = {
            "aws_cli": self._aws_handler,
            "gcp_cli": self._gcp_handler,
            "azure_cli": self._azure_handler,
        }
        handler = handlers.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        return await handler(**parameters)

    async def _aws_handler(
        self,
        service: str,
        action: str,
        parameters: dict[str, Any] | None = None,
        region: str | None = None,
    ) -> dict[str, Any]:
        """Handle AWS operations."""
        assert self._aws is not None
        return await self._aws.execute(service, action, parameters or {}, region=region)

    async def _gcp_handler(
        self,
        service: str,
        action: str,
        parameters: dict[str, Any] | None = None,
        zone: str | None = None,
    ) -> dict[str, Any]:
        """Handle GCP operations."""
        assert self._gcp is not None
        return await self._gcp.execute(service, action, parameters or {}, zone=zone)

    async def _azure_handler(
        self,
        service: str,
        action: str,
        parameters: dict[str, Any] | None = None,
        resource_group: str | None = None,
    ) -> dict[str, Any]:
        """Handle Azure operations."""
        assert self._azure is not None
        return await self._azure.execute(service, action, parameters or {}, resource_group=resource_group)

    def cleanup(self) -> None:
        """Release resources."""
        if self._context:
            self._context.log.info("Cloud tools plugin cleaned up")
        self._aws = None
        self._gcp = None
        self._azure = None
        self._context = None
