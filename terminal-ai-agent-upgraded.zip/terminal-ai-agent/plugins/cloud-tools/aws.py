"""AWS resource manager.

Provides a high-level interface for common AWS operations across
EC2, S3, Lambda, and IAM services. Falls back to subprocess CLI
when boto3 is not available.
"""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
from typing import Any

logger = logging.getLogger(__name__)


class AWSManager:
    """Manages AWS resources via boto3 or CLI fallback.

    Args:
        region: Default AWS region.
        profile: AWS CLI profile name.
    """

    def __init__(self, region: str = "us-east-1", profile: str = "default") -> None:
        self._region = region
        self._profile = profile
        self._session: Any = None

    def _get_session(self) -> Any:
        """Get or create a boto3 session."""
        if self._session is None:
            try:
                import boto3
                self._session = boto3.Session(
                    profile_name=self._profile,
                    region_name=self._region,
                )
            except ImportError:
                logger.warning("boto3 not installed, falling back to AWS CLI")
        return self._session

    async def execute(
        self,
        service: str,
        action: str,
        parameters: dict[str, Any],
        region: str | None = None,
    ) -> dict[str, Any]:
        """Execute an AWS operation.

        Args:
            service: AWS service (ec2, s3, lambda, iam).
            action: Action to perform.
            parameters: Service-specific parameters.
            region: Region override.

        Returns:
            Operation result dictionary.
        """
        effective_region = region or self._region

        # Try boto3 first
        session = self._get_session()
        if session is not None:
            return await self._execute_boto3(session, service, action, parameters, effective_region)

        # Fallback to CLI
        return await self._execute_cli(service, action, parameters, effective_region)

    async def _execute_boto3(
        self, session: Any, service: str, action: str,
        parameters: dict[str, Any], region: str
    ) -> dict[str, Any]:
        """Execute via boto3."""
        try:
            client = session.client(service, region_name=region)
        except Exception as exc:
            return {"error": f"Failed to create {service} client: {exc}"}

        # Map friendly actions to boto3 methods
        method_map = self._get_action_map(service)
        method_name = method_map.get(action)
        if method_name is None:
            return {"error": f"Unknown action '{action}' for service '{service}'", "available_actions": list(method_map.keys())}

        method = getattr(client, method_name, None)
        if method is None:
            return {"error": f"Method '{method_name}' not found on {service} client"}

        try:
            # Run blocking boto3 call in thread
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, lambda: method(**parameters))
            # Remove ResponseMetadata if present
            result.pop("ResponseMetadata", None)
            return {"success": True, "service": service, "action": action, "result": result}
        except Exception as exc:
            return {"error": str(exc), "service": service, "action": action}

    async def _execute_cli(
        self, service: str, action: str,
        parameters: dict[str, Any], region: str
    ) -> dict[str, Any]:
        """Execute via AWS CLI subprocess."""
        cmd = ["aws", service, action.replace("_", "-"), "--region", region, "--output", "json"]
        for key, value in parameters.items():
            if isinstance(value, bool):
                if value:
                    cmd.append(f"--{key.replace('_', '-')}")
            else:
                cmd.extend([f"--{key.replace('_', '-')}", str(value)])

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                return {"error": stderr.decode().strip(), "returncode": proc.returncode}
            return {"success": True, "result": json.loads(stdout.decode())}
        except FileNotFoundError:
            return {"error": "AWS CLI not found. Install with: pip install awscli"}
        except json.JSONDecodeError:
            return {"success": True, "result": stdout.decode().strip()}

    @staticmethod
    def _get_action_map(service: str) -> dict[str, str]:
        """Map friendly action names to boto3 method names."""
        maps: dict[str, dict[str, str]] = {
            "ec2": {
                "list_instances": "describe_instances",
                "start_instance": "start_instances",
                "stop_instance": "stop_instances",
                "terminate_instance": "terminate_instances",
                "list_security_groups": "describe_security_groups",
                "list_vpcs": "describe_vpcs",
            },
            "s3": {
                "list_buckets": "list_buckets",
                "list_objects": "list_objects_v2",
                "create_bucket": "create_bucket",
                "delete_bucket": "delete_bucket",
                "get_object": "get_object",
                "put_object": "put_object",
            },
            "lambda": {
                "list_functions": "list_functions",
                "invoke": "invoke",
                "create_function": "create_function",
                "delete_function": "delete_function",
            },
            "iam": {
                "list_users": "list_users",
                "list_roles": "list_roles",
                "list_policies": "list_policies",
                "get_user": "get_user",
            },
        }
        return maps.get(service, {})
