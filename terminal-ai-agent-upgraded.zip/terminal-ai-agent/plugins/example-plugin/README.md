# example-plugin

Reference implementation demonstrating the Terminal Agent plugin API.

## Purpose

This plugin serves as a starting point and documentation resource for plugin developers. It shows how to:

- Define a plugin class extending `PluginBase`
- Register tools with proper JSON Schema parameters
- Implement lifecycle hooks (`before_tool`, `after_tool`)
- Handle configuration
- Write tests

## Tools

### `echo`

Echoes back the provided message. Useful for testing plugin connectivity.

**Parameters:**
- `message` (string, required) — The message to echo back.

**Returns:** The original message as a string.

### `add_numbers`

Adds two numbers together.

**Parameters:**
- `a` (number, required) — The first number.
- `b` (number, required) — The second number.

**Returns:** The sum of `a` and `b`.

## Configuration

```toml
[plugins.example-plugin]
debug = false
max_message_length = 10000
```

## Development

```bash
# Run tests
cd plugins/example-plugin
python -m pytest tests/ -v
```

## Creating Your Own Plugin

1. Copy this directory and rename it
2. Update `manifest.toml` with your plugin's metadata
3. Modify `main.py` to implement your tools
4. Add implementation modules as needed
5. Write tests in `tests/`
6. Update this README
