"""Tests for the example plugin."""

from __future__ import annotations

import pytest

from terminal_agent.plugins.api import PluginContext

# Adjust import path for direct test execution
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from main import ExamplePlugin
from tools import validate_message, validate_numbers
from config import ExamplePluginConfig


@pytest.fixture
def plugin():
    """Create and activate an ExamplePlugin instance."""
    p = ExamplePlugin()
    p.activate(PluginContext())
    return p


class TestExamplePlugin:
    """Tests for ExamplePlugin main class."""

    def test_tools_registered(self, plugin: ExamplePlugin):
        tools = plugin.get_tools()
        names = {t["name"] for t in tools}
        assert "echo" in names
        assert "add_numbers" in names

    def test_tool_schemas_valid(self, plugin: ExamplePlugin):
        for tool in plugin.get_tools():
            assert "name" in tool
            assert "description" in tool
            assert "parameters" in tool
            params = tool["parameters"]
            assert params.get("type") == "object"
            assert "properties" in params

    @pytest.mark.asyncio
    async def test_echo(self, plugin: ExamplePlugin):
        result = await plugin.handle_tool("echo", {"message": "hello"})
        assert result == "hello"

    @pytest.mark.asyncio
    async def test_echo_empty(self, plugin: ExamplePlugin):
        result = await plugin.handle_tool("echo", {"message": ""})
        assert result == ""

    @pytest.mark.asyncio
    async def test_add_numbers_int(self, plugin: ExamplePlugin):
        result = await plugin.handle_tool("add_numbers", {"a": 3, "b": 4})
        assert result == 7.0

    @pytest.mark.asyncio
    async def test_add_numbers_float(self, plugin: ExamplePlugin):
        result = await plugin.handle_tool("add_numbers", {"a": 1.5, "b": 2.5})
        assert result == 4.0

    @pytest.mark.asyncio
    async def test_add_numbers_negative(self, plugin: ExamplePlugin):
        result = await plugin.handle_tool("add_numbers", {"a": -1, "b": -2})
        assert result == -3.0

    @pytest.mark.asyncio
    async def test_unknown_tool(self, plugin: ExamplePlugin):
        with pytest.raises(ValueError, match="Unknown tool"):
            await plugin.handle_tool("nonexistent", {})

    def test_cleanup(self, plugin: ExamplePlugin):
        plugin.cleanup()
        assert plugin._context is None

    def test_hooks_registered(self, plugin: ExamplePlugin):
        hooks = plugin.get_hooks()
        assert "before_tool" in hooks
        assert "after_tool" in hooks


class TestTools:
    """Tests for tool utility functions."""

    def test_validate_message_valid(self):
        assert validate_message("hello") == "hello"

    def test_validate_message_strips(self):
        assert validate_message("  hello  ") == "hello"

    def test_validate_message_empty_raises(self):
        with pytest.raises(ValueError, match="must not be empty"):
            validate_message("")

    def test_validate_message_whitespace_raises(self):
        with pytest.raises(ValueError, match="must not be empty"):
            validate_message("   ")

    def test_validate_message_type_raises(self):
        with pytest.raises(TypeError, match="Expected string"):
            validate_message(123)  # type: ignore

    def test_validate_numbers_valid(self):
        a, b = validate_numbers(1, 2)
        assert a == 1.0
        assert b == 2.0

    def test_validate_numbers_string_raises(self):
        with pytest.raises(TypeError, match="must be numeric"):
            validate_numbers("a", 1)

    def test_validate_numbers_none_raises(self):
        with pytest.raises(TypeError, match="must be numeric"):
            validate_numbers(None, 1)


class TestConfig:
    """Tests for plugin configuration."""

    def test_defaults(self):
        cfg = ExamplePluginConfig()
        assert cfg.debug is False
        assert cfg.max_message_length == 10_000

    def test_from_dict(self):
        cfg = ExamplePluginConfig.from_dict({"debug": True, "max_message_length": 500})
        assert cfg.debug is True
        assert cfg.max_message_length == 500

    def test_from_dict_ignores_unknown(self):
        cfg = ExamplePluginConfig.from_dict({"unknown_key": "value"})
        assert cfg.debug is False

    def test_to_dict(self):
        cfg = ExamplePluginConfig(debug=True)
        d = cfg.to_dict()
        assert d["debug"] is True
        assert d["max_message_length"] == 10_000
