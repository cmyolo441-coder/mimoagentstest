"""Example plugin — reference implementation for Terminal Agent plugin developers."""

from __future__ import annotations

from .main import ExamplePlugin

__all__ = ["ExamplePlugin"]
__version__ = "1.0.0"
