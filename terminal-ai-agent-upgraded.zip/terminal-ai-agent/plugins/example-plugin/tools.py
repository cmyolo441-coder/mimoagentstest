"""Example plugin tool utilities.

Provides helper functions for the example plugin tools.
"""

from __future__ import annotations

from typing import Any


def validate_message(message: str) -> str:
    """Validate and sanitize the echo message.

    Args:
        message: Raw input message.

    Returns:
        Sanitized message string.

    Raises:
        ValueError: If message is empty or not a string.
    """
    if not isinstance(message, str):
        raise TypeError(f"Expected string, got {type(message).__name__}")
    if not message.strip():
        raise ValueError("Message must not be empty")
    return message


def validate_numbers(a: Any, b: Any) -> tuple[float, float]:
    """Validate that both inputs are numeric.

    Args:
        a: First value.
        b: Second value.

    Returns:
        Tuple of validated float values.

    Raises:
        TypeError: If either value is not numeric.
    """
    try:
        return float(a), float(b)
    except (TypeError, ValueError) as exc:
        raise TypeError(f"Both arguments must be numeric: {exc}") from exc
