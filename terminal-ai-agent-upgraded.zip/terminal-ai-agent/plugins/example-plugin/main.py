"""Example plugin — reference implementation for Terminal Agent.

Demonstrates the plugin API with two simple tools: echo and add_numbers.
Use this as a starting point when building your own plugins.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.plugins.api import PluginBase, PluginContext

logger = logging.getLogger(__name__)


class ExamplePlugin(PluginBase):
    """Reference plugin demonstrating the Terminal Agent plugin API.

    Provides two example tools:
    - echo: Returns the input message unchanged.
    - add_numbers: Adds two numbers together.
    """

    name = "example-plugin"
    version = "1.0.0"

    def __init__(self) -> None:
        self._context: PluginContext | None = None

    def activate(self, context: PluginContext | None = None) -> None:
        """Initialize the plugin.

        Args:
            context: Plugin context providing config, logging, and data store.
        """
        self._context = context or PluginContext()
        self._context.log.info("Example plugin activated")

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions provided by this plugin."""
        return [
            {
                "name": "echo",
                "description": "Echo back the provided message. Useful for testing plugin connectivity.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "message": {
                            "type": "string",
                            "description": "The message to echo back.",
                        },
                    },
                    "required": ["message"],
                },
                "returns": "The original message as a string.",
            },
            {
                "name": "add_numbers",
                "description": "Add two numbers together and return the result.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "a": {
                            "type": "number",
                            "description": "The first number.",
                        },
                        "b": {
                            "type": "number",
                            "description": "The second number.",
                        },
                    },
                    "required": ["a", "b"],
                },
                "returns": "The sum of a and b.",
            },
        ]

    def get_hooks(self) -> dict[str, Any]:
        """Return hook handlers provided by this plugin."""
        return {
            "before_tool": self._before_tool,
            "after_tool": self._after_tool,
        }

    async def handle_tool(self, tool_name: str, parameters: dict[str, Any]) -> Any:
        """Dispatch a tool call to the appropriate handler.

        Args:
            tool_name: Name of the tool to invoke.
            parameters: Tool parameters.

        Returns:
            Tool result.

        Raises:
            ValueError: If the tool name is unknown.
        """
        handlers = {
            "echo": self._echo,
            "add_numbers": self._add_numbers,
        }
        handler = handlers.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        return await handler(**parameters)

    async def _echo(self, message: str) -> str:
        """Echo back the provided message.

        Args:
            message: The message to echo.

        Returns:
            The original message.
        """
        if self._context:
            self._context.log.debug("Echo: %s", message)
        return message

    async def _add_numbers(self, a: float, b: float) -> float:
        """Add two numbers.

        Args:
            a: First number.
            b: Second number.

        Returns:
            The sum of a and b.
        """
        result = a + b
        if self._context:
            self._context.log.debug("add_numbers(%s, %s) = %s", a, b, result)
        return result

    def _before_tool(self, tool_name: str, parameters: dict[str, Any]) -> dict[str, Any]:
        """Hook: log before tool execution."""
        if self._context:
            self._context.log.info("Before tool: %s", tool_name)
        return parameters

    def _after_tool(
        self, tool_name: str, parameters: dict[str, Any], result: Any
    ) -> Any:
        """Hook: log after tool execution."""
        if self._context:
            self._context.log.info("After tool: %s -> %s", tool_name, result)
        return result

    def cleanup(self) -> None:
        """Release resources."""
        if self._context:
            self._context.log.info("Example plugin cleaned up")
        self._context = None
