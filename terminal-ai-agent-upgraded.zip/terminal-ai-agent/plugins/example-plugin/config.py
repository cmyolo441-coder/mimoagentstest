"""Example plugin configuration schema and defaults."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ExamplePluginConfig:
    """Configuration schema for the example plugin.

    Attributes:
        debug: Enable debug logging for this plugin.
        max_message_length: Maximum allowed message length for echo.
    """

    debug: bool = False
    max_message_length: int = 10_000

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExamplePluginConfig":
        """Create config from a dictionary, ignoring unknown keys."""
        known_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in known_fields}
        return cls(**filtered)

    def to_dict(self) -> dict[str, Any]:
        """Serialize config to a dictionary."""
        return {
            "debug": self.debug,
            "max_message_length": self.max_message_length,
        }


DEFAULTS: dict[str, Any] = ExamplePluginConfig().to_dict()
