"""Web tools plugin — web scraping and browser automation for Terminal Agent."""

from __future__ import annotations

from .main import WebToolsPlugin

__all__ = ["WebToolsPlugin"]
__version__ = "1.0.0"
