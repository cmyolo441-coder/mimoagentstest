"""Browser controller module — headless browser automation via Playwright."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


class BrowserController:
    """Controls a headless browser for interactive web tasks.

    Wraps Playwright to provide navigation, interaction, and screenshot
    capabilities. Falls back gracefully if Playwright is not installed.

    Args:
        headless: Run browser in headless mode.
    """

    def __init__(self, headless: bool = True) -> None:
        self._headless = headless
        self._playwright: Any = None
        self._browser: Any = None
        self._page: Any = None

    async def _ensure_browser(self) -> Any:
        """Lazily launch the browser on first use."""
        if self._browser is not None:
            return self._page

        try:
            from playwright.async_api import async_playwright
        except ImportError as exc:
            raise RuntimeError(
                "Playwright is required for browser tools. "
                "Install with: pip install playwright && playwright install chromium"
            ) from exc

        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(headless=self._headless)
        context = await self._browser.new_context()
        self._page = await context.new_page()
        return self._page

    async def navigate(self, url: str, wait_for: str | None = None) -> dict[str, Any]:
        """Navigate to a URL.

        Args:
            url: The URL to navigate to.
            wait_for: Optional CSS selector to wait for before returning.

        Returns:
            Dictionary with page title, URL, and status.
        """
        page = await self._ensure_browser()
        response = await page.goto(url, wait_until="domcontentloaded")

        if wait_for:
            try:
                await page.wait_for_selector(wait_for, timeout=10_000)
            except Exception as exc:
                logger.warning("Timeout waiting for selector '%s': %s", wait_for, exc)

        title = await page.title()
        return {
            "url": page.url,
            "title": title,
            "status": response.status if response else None,
        }

    async def click(self, selector: str) -> dict[str, Any]:
        """Click an element on the current page.

        Args:
            selector: CSS selector of the element to click.

        Returns:
            Dictionary with click result and new page state.
        """
        page = await self._ensure_browser()
        await page.click(selector, timeout=5_000)
        await page.wait_for_load_state("domcontentloaded")

        return {
            "clicked": selector,
            "url": page.url,
            "title": await page.title(),
        }

    async def screenshot(
        self, path: str = "screenshot.png", full_page: bool = False
    ) -> dict[str, Any]:
        """Capture a screenshot of the current page.

        Args:
            path: File path to save the screenshot.
            full_page: Whether to capture the full scrollable page.

        Returns:
            Dictionary with the saved file path and page dimensions.
        """
        page = await self._ensure_browser()
        await page.screenshot(path=path, full_page=full_page)

        viewport = page.viewport_size or {"width": 0, "height": 0}
        return {
            "path": path,
            "width": viewport.get("width", 0),
            "height": viewport.get("height", 0),
            "full_page": full_page,
        }

    async def get_content(self) -> str:
        """Get the current page HTML content."""
        page = await self._ensure_browser()
        return await page.content()

    async def type_text(self, selector: str, text: str) -> dict[str, Any]:
        """Type text into an input element.

        Args:
            selector: CSS selector of the input element.
            text: Text to type.

        Returns:
            Confirmation dictionary.
        """
        page = await self._ensure_browser()
        await page.fill(selector, text)
        return {"typed": text, "selector": selector}

    def close(self) -> None:
        """Close the browser and clean up resources."""
        if self._browser:
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(self._browser.close())
                else:
                    loop.run_until_complete(self._browser.close())
            except Exception:
                pass
            self._browser = None
            self._page = None
        if self._playwright:
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(self._playwright.stop())
                else:
                    loop.run_until_complete(self._playwright.stop())
            except Exception:
                pass
            self._playwright = None
