# web-tools

Web scraping and browser automation tools for Terminal Agent.

## Tools

### `web_scrape`

Fetch a URL and extract text content. Optionally filter with a CSS selector.

**Parameters:**
- `url` (string, required) — The URL to fetch.
- `selector` (string) — CSS selector to filter elements.
- `extract_links` (boolean) — Include hyperlinks in output.

**Returns:** Extracted text, title, links, and status code.

### `browser_navigate`

Navigate the headless browser to a URL.

**Parameters:**
- `url` (string, required) — The URL to navigate to.
- `wait_for` (string) — CSS selector to wait for before returning.

**Returns:** Page title, URL, and HTTP status.

### `browser_click`

Click an element on the current browser page.

**Parameters:**
- `selector` (string, required) — CSS selector of the element to click.

**Returns:** Click confirmation and new page state.

### `browser_screenshot`

Capture a screenshot of the current browser page.

**Parameters:**
- `path` (string) — File path to save the screenshot.
- `full_page` (boolean) — Capture the full scrollable page.

**Returns:** File path and page dimensions.

## Configuration

```toml
[plugins.web-tools]
timeout = 30
user_agent = "TerminalAgent/1.0"
headless = true
```

## Dependencies

- `requests` — HTTP client
- `beautifulsoup4` — HTML parsing
- `httpx` — Async HTTP client
- `playwright` — Browser automation (optional, install separately)

```bash
pip install requests beautifulsoup4 httpx playwright
playwright install chromium
```

## Usage Examples

```bash
# Scrape a page
terminal-agent tools call web_scrape '{"url": "https://example.com"}'

# Scrape with CSS selector
terminal-agent tools call web_scrape '{"url": "https://news.ycombinator.com", "selector": ".titleline"}'

# Browser automation
terminal-agent tools call browser_navigate '{"url": "https://example.com"}'
terminal-agent tools call browser_click '{"selector": "a.link"}'
terminal-agent tools call browser_screenshot '{"path": "page.png"}'
```

## Testing

```bash
cd plugins/web-tools
python -m pytest tests/ -v
```
