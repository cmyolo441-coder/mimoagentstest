"""Web scraper module — fetch and extract content from web pages."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urljoin

import httpx
from bs4 import BeautifulSoup, Tag

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = 30
_DEFAULT_USER_AGENT = "TerminalAgent/1.0"


@dataclass
class ScrapedContent:
    """Result of a web scraping operation."""
    url: str
    title: str = ""
    text: str = ""
    links: list[dict[str, str]] = field(default_factory=list)
    status_code: int = 200
    content_type: str = ""


class WebScraper:
    """Fetches web pages and extracts structured content.

    Args:
        timeout: Request timeout in seconds.
        user_agent: User-Agent header value.
    """

    def __init__(
        self,
        timeout: int = _DEFAULT_TIMEOUT,
        user_agent: str = _DEFAULT_USER_AGENT,
    ) -> None:
        self._timeout = timeout
        self._user_agent = user_agent
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Lazy-initialize the HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=self._timeout,
                headers={"User-Agent": self._user_agent},
                follow_redirects=True,
            )
        return self._client

    async def scrape(
        self,
        url: str,
        selector: str | None = None,
        extract_links: bool = False,
    ) -> dict[str, Any]:
        """Fetch a URL and extract content.

        Args:
            url: The URL to fetch.
            selector: Optional CSS selector to filter elements.
            extract_links: Whether to include hyperlinks in output.

        Returns:
            Dictionary with keys: url, title, text, links, status_code.
        """
        client = await self._get_client()
        response = await client.get(url)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")
        title_tag = soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else ""

        if selector:
            elements = soup.select(selector)
            text = "\n".join(el.get_text(separator="\n", strip=True) for el in elements)
        else:
            # Remove script and style elements
            for tag in soup(["script", "style", "nav", "footer", "header"]):
                tag.decompose()
            text = soup.get_text(separator="\n", strip=True)

        links: list[dict[str, str]] = []
        if extract_links:
            for a in soup.find_all("a", href=True):
                if isinstance(a, Tag):
                    href = a.get("href", "")
                    if isinstance(href, str):
                        links.append({
                            "text": a.get_text(strip=True),
                            "url": urljoin(url, href),
                        })

        return {
            "url": str(response.url),
            "title": title,
            "text": text[:50_000],  # Truncate very long pages
            "links": links[:500],
            "status_code": response.status_code,
            "content_type": response.headers.get("content-type", ""),
        }

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None
