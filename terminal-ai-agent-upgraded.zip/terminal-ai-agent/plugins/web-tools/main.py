"""Web tools plugin — web scraping and browser automation.

Provides tools for fetching web pages, extracting content via CSS selectors,
and controlling a headless browser for interactive tasks.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.plugins.api import PluginBase, PluginContext

from .scraper import WebScraper
from .browser import BrowserController

logger = logging.getLogger(__name__)


class WebToolsPlugin(PluginBase):
    """Plugin providing web scraping and browser automation tools.

    Tools:
        web_scrape: Fetch a URL and extract text or selected elements.
        browser_navigate: Navigate a headless browser to a URL.
        browser_click: Click an element on the current page.
        browser_screenshot: Capture a screenshot of the current page.
    """

    name = "web-tools"
    version = "1.0.0"

    def __init__(self) -> None:
        self._context: PluginContext | None = None
        self._scraper: WebScraper | None = None
        self._browser: BrowserController | None = None

    def activate(self, context: PluginContext | None = None) -> None:
        """Initialize the web tools plugin.

        Args:
            context: Plugin context providing config and logging.
        """
        self._context = context or PluginContext()
        cfg = self._context.config if self._context else {}
        self._scraper = WebScraper(
            timeout=cfg.get("timeout", 30),
            user_agent=cfg.get("user_agent", "TerminalAgent/1.0"),
        )
        self._browser = BrowserController(
            headless=cfg.get("headless", True),
        )
        self._context.log.info("Web tools plugin activated")

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions."""
        return [
            {
                "name": "web_scrape",
                "description": "Fetch a URL and extract text content. Optionally filter with a CSS selector.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "The URL to fetch.",
                        },
                        "selector": {
                            "type": "string",
                            "description": "Optional CSS selector to filter elements.",
                        },
                        "extract_links": {
                            "type": "boolean",
                            "description": "Whether to include links in the output.",
                            "default": False,
                        },
                    },
                    "required": ["url"],
                },
                "returns": "Extracted text content as a string.",
            },
            {
                "name": "browser_navigate",
                "description": "Navigate the headless browser to a URL and wait for the page to load.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "The URL to navigate to.",
                        },
                        "wait_for": {
                            "type": "string",
                            "description": "Optional CSS selector to wait for before returning.",
                        },
                    },
                    "required": ["url"],
                },
                "returns": "Page title and status information.",
            },
            {
                "name": "browser_click",
                "description": "Click an element on the current browser page.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "selector": {
                            "type": "string",
                            "description": "CSS selector of the element to click.",
                        },
                    },
                    "required": ["selector"],
                },
                "returns": "Result of the click action.",
            },
            {
                "name": "browser_screenshot",
                "description": "Capture a screenshot of the current browser page.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "File path to save the screenshot.",
                        },
                        "full_page": {
                            "type": "boolean",
                            "description": "Capture the full scrollable page.",
                            "default": False,
                        },
                    },
                    "required": [],
                },
                "returns": "Path to the saved screenshot file.",
            },
        ]

    async def handle_tool(self, tool_name: str, parameters: dict[str, Any]) -> Any:
        """Dispatch tool calls to handlers."""
        handlers = {
            "web_scrape": self._web_scrape,
            "browser_navigate": self._browser_navigate,
            "browser_click": self._browser_click,
            "browser_screenshot": self._browser_screenshot,
        }
        handler = handlers.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        return await handler(**parameters)

    async def _web_scrape(
        self,
        url: str,
        selector: str | None = None,
        extract_links: bool = False,
    ) -> dict[str, Any]:
        """Scrape a web page."""
        assert self._scraper is not None
        return await self._scraper.scrape(url, selector=selector, extract_links=extract_links)

    async def _browser_navigate(
        self, url: str, wait_for: str | None = None
    ) -> dict[str, Any]:
        """Navigate browser to URL."""
        assert self._browser is not None
        return await self._browser.navigate(url, wait_for=wait_for)

    async def _browser_click(self, selector: str) -> dict[str, Any]:
        """Click an element."""
        assert self._browser is not None
        return await self._browser.click(selector)

    async def _browser_screenshot(
        self, path: str = "screenshot.png", full_page: bool = False
    ) -> dict[str, Any]:
        """Take a screenshot."""
        assert self._browser is not None
        return await self._browser.screenshot(path, full_page=full_page)

    def cleanup(self) -> None:
        """Release browser and scraper resources."""
        if self._browser:
            self._browser.close()
        if self._context:
            self._context.log.info("Web tools plugin cleaned up")
        self._scraper = None
        self._browser = None
        self._context = None
