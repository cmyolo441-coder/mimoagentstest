"""Tests for the web-tools plugin."""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from terminal_agent.plugins.api import PluginContext

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from main import WebToolsPlugin
from scraper import WebScraper, ScrapedContent
from browser import BrowserController


@pytest.fixture
def plugin():
    """Create and activate a WebToolsPlugin instance."""
    p = WebToolsPlugin()
    p.activate(PluginContext())
    return p


class TestWebToolsPlugin:
    """Tests for WebToolsPlugin main class."""

    def test_tools_registered(self, plugin: WebToolsPlugin):
        tools = plugin.get_tools()
        names = {t["name"] for t in tools}
        assert names == {"web_scrape", "browser_navigate", "browser_click", "browser_screenshot"}

    def test_tool_schemas_valid(self, plugin: WebToolsPlugin):
        for tool in plugin.get_tools():
            assert "name" in tool
            assert "description" in tool
            assert "parameters" in tool
            params = tool["parameters"]
            assert params.get("type") == "object"
            assert "properties" in params

    @pytest.mark.asyncio
    async def test_unknown_tool(self, plugin: WebToolsPlugin):
        with pytest.raises(ValueError, match="Unknown tool"):
            await plugin.handle_tool("nonexistent", {})

    def test_cleanup(self, plugin: WebToolsPlugin):
        plugin.cleanup()
        assert plugin._context is None


class TestWebScraper:
    """Tests for the WebScraper class."""

    def test_init_defaults(self):
        scraper = WebScraper()
        assert scraper._timeout == 30
        assert scraper._user_agent == "TerminalAgent/1.0"

    def test_init_custom(self):
        scraper = WebScraper(timeout=10, user_agent="CustomBot/2.0")
        assert scraper._timeout == 10
        assert scraper._user_agent == "CustomBot/2.0"

    @pytest.mark.asyncio
    async def test_scrape_mocked(self):
        scraper = WebScraper()

        mock_response = MagicMock()
        mock_response.text = "<html><head><title>Test</title></head><body><p>Hello</p></body></html>"
        mock_response.url = "https://example.com"
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/html"}

        with patch.object(scraper, "_get_client") as mock_get_client:
            mock_client = AsyncMock()
            mock_client.get = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await scraper.scrape("https://example.com")

        assert result["url"] == "https://example.com"
        assert result["title"] == "Test"
        assert "Hello" in result["text"]
        assert result["status_code"] == 200

    @pytest.mark.asyncio
    async def test_scrape_with_selector(self):
        scraper = WebScraper()

        mock_response = MagicMock()
        mock_response.text = (
            "<html><head><title>Test</title></head>"
            "<body><p class='a'>Alpha</p><p class='b'>Beta</p></body></html>"
        )
        mock_response.url = "https://example.com"
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/html"}

        with patch.object(scraper, "_get_client") as mock_get_client:
            mock_client = AsyncMock()
            mock_client.get = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await scraper.scrape("https://example.com", selector="p.a")

        assert "Alpha" in result["text"]
        assert "Beta" not in result["text"]

    @pytest.mark.asyncio
    async def test_scrape_extract_links(self):
        scraper = WebScraper()

        mock_response = MagicMock()
        mock_response.text = (
            '<html><head><title>Test</title></head>'
            '<body><a href="/page1">Link 1</a><a href="https://other.com">Link 2</a></body></html>'
        )
        mock_response.url = "https://example.com"
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/html"}

        with patch.object(scraper, "_get_client") as mock_get_client:
            mock_client = AsyncMock()
            mock_client.get = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await scraper.scrape("https://example.com", extract_links=True)

        assert len(result["links"]) == 2
        urls = {l["url"] for l in result["links"]}
        assert "https://example.com/page1" in urls
        assert "https://other.com" in urls


class TestBrowserController:
    """Tests for the BrowserController class."""

    def test_init_defaults(self):
        ctrl = BrowserController()
        assert ctrl._headless is True
        assert ctrl._browser is None
        assert ctrl._page is None

    def test_init_visible(self):
        ctrl = BrowserController(headless=False)
        assert ctrl._headless is False

    def test_close_no_browser(self):
        ctrl = BrowserController()
        ctrl.close()  # Should not raise

    @pytest.mark.asyncio
    async def test_ensure_browser_no_playwright(self):
        ctrl = BrowserController()
        with patch.dict("sys.modules", {"playwright.async_api": None}):
            with pytest.raises(RuntimeError, match="Playwright is required"):
                await ctrl._ensure_browser()
