"""Vulnerability scanner — static analysis for security issues.

Scans source code for common vulnerability patterns including injection
flaws, insecure configurations, and hardcoded secrets. Uses regex-based
pattern matching for portability without heavy dependencies.
"""

from __future__ import annotations

import ast
import logging
import math
import os
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_SEVERITY_ORDER = {"low": 0, "medium": 1, "high": 2, "critical": 3}

# Common vulnerability patterns
_VULN_PATTERNS: list[dict[str, Any]] = [
    {
        "id": "SEC-001",
        "name": "SQL Injection",
        "pattern": re.compile(r"""(?:execute|cursor\.execute|raw|rawquery)\s*\(\s*(?:f['""]|['""].*%s|['""].*\+|.*\.format\s*\()""", re.IGNORECASE),
        "severity": "critical",
        "description": "Potential SQL injection via string formatting in query.",
        "fix": "Use parameterized queries instead of string formatting.",
    },
    {
        "id": "SEC-002",
        "name": "Command Injection",
        "pattern": re.compile(r"""(?:os\.system|os\.popen|subprocess\.call|subprocess\.run)\s*\(\s*(?:f['""]|['""].*\+|.*\.format\s*\()"""),
        "severity": "critical",
        "description": "Potential command injection via string concatenation in subprocess call.",
        "fix": "Use subprocess with a list of arguments, avoid shell=True with user input.",
    },
    {
        "id": "SEC-003",
        "name": "Eval Usage",
        "pattern": re.compile(r"""\b(?:eval|exec)\s*\("""),
        "severity": "high",
        "description": "Use of eval/exec can execute arbitrary code.",
        "fix": "Avoid eval/exec. Use ast.literal_eval for safe evaluation of literals.",
    },
    {
        "id": "SEC-004",
        "name": "Hardcoded Password",
        "pattern": re.compile(r"""(?:password|passwd|pwd|secret|token|api_key)\s*=\s*['""][^'""]{4,}['""]""", re.IGNORECASE),
        "severity": "high",
        "description": "Hardcoded credential detected.",
        "fix": "Use environment variables or a secrets manager.",
    },
    {
        "id": "SEC-005",
        "name": "Insecure Hash",
        "pattern": re.compile(r"""\b(?:md5|sha1)\s*\(""", re.IGNORECASE),
        "severity": "medium",
        "description": "Use of weak hash algorithm (MD5/SHA1).",
        "fix": "Use SHA-256 or stronger for security-sensitive hashing.",
    },
    {
        "id": "SEC-006",
        "name": "Insecure Random",
        "pattern": re.compile(r"""\brandom\.(?:random|randint|choice|randrange)\b"""),
        "severity": "medium",
        "description": "Use of non-cryptographic random for potentially sensitive value.",
        "fix": "Use secrets module for security-sensitive random values.",
    },
    {
        "id": "SEC-007",
        "name": "Debug Mode",
        "pattern": re.compile(r"""(?:DEBUG\s*=\s*True|app\.run\([^)]*debug\s*=\s*True)"""),
        "severity": "medium",
        "description": "Debug mode enabled — may expose sensitive information.",
        "fix": "Disable debug mode in production.",
    },
    {
        "id": "SEC-008",
        "name": "Insecure Deserialization",
        "pattern": re.compile(r"""\bpickle\.(?:loads?|Unpickler)\s*\("""),
        "severity": "high",
        "description": "Pickle deserialization can execute arbitrary code.",
        "fix": "Use JSON or other safe serialization formats. Never unpickle untrusted data.",
    },
    {
        "id": "SEC-009",
        "name": "XSS via Markup",
        "pattern": re.compile(r"""\bMarkup\s*\(\s*(?:f['""]|['""].*\+|.*\.format\s*\()"""),
        "severity": "high",
        "description": "Potential XSS via unescaped HTML markup.",
        "fix": "Use template auto-escaping or markupsafe.escape().",
    },
    {
        "id": "SEC-010",
        "name": "TLS Verification Disabled",
        "pattern": re.compile(r"""(?:verify\s*=\s*False|CERT_NONE|ssl\.CERT_NONE)"""),
        "severity": "high",
        "description": "TLS certificate verification disabled.",
        "fix": "Always verify TLS certificates in production.",
    },
]

# Secret detection patterns
_SECRET_PATTERNS: list[dict[str, Any]] = [
    {
        "name": "AWS Access Key",
        "pattern": re.compile(r"""(?<![A-Z0-9])[A-Z0-9]{20}(?![A-Z0-9])"""),
        "confidence": 0.8,
    },
    {
        "name": "AWS Secret Key",
        "pattern": re.compile(r"""(?i)aws.{0,20}['""][A-Za-z0-9/+=]{40}['""]"""),
        "confidence": 0.9,
    },
    {
        "name": "Generic API Key",
        "pattern": re.compile(r"""(?i)(?:api[_-]?key|apikey|api[_-]?secret)\s*[:=]\s*['""][A-Za-z0-9_\-]{16,}['""]"""),
        "confidence": 0.85,
    },
    {
        "name": "Private Key",
        "pattern": re.compile(r"""-----BEGIN\s+(?:RSA|EC|DSA|OPENSSH)?\s*PRIVATE KEY-----"""),
        "confidence": 0.99,
    },
    {
        "name": "JWT Token",
        "pattern": re.compile(r"""eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"""),
        "confidence": 0.9,
    },
    {
        "name": "Generic Secret",
        "pattern": re.compile(r"""(?i)(?:secret|token|password|credential)\s*[:=]\s*['""][A-Za-z0-9_\-]{8,}['""]"""),
        "confidence": 0.7,
    },
]

_BINARY_EXTENSIONS = frozenset({
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".woff", ".woff2",
    ".ttf", ".eot", ".pyc", ".pyo", ".so", ".dll", ".exe", ".bin",
    ".zip", ".tar", ".gz", ".bz2", ".7z", ".pdf", ".mp3", ".mp4",
})

_SKIP_DIRS = frozenset({
    ".git", "__pycache__", "node_modules", ".venv", "venv", "env",
    ".tox", ".mypy_cache", ".pytest_cache", "dist", "build",
})


class VulnerabilityScanner:
    """Scans source code for security vulnerabilities and secrets.

    Args:
        severity_threshold: Minimum severity to report (low, medium, high, critical).
    """

    def __init__(self, severity_threshold: str = "medium") -> None:
        self._threshold = _SEVERITY_ORDER.get(severity_threshold.lower(), 1)

    async def scan(
        self,
        path: str,
        severity: str = "medium",
        language: str | None = None,
    ) -> dict[str, Any]:
        """Scan files for security vulnerabilities.

        Args:
            path: File or directory to scan.
            severity: Minimum severity to report.
            language: Programming language hint.

        Returns:
            Dictionary with findings, summary, and scan metadata.
        """
        target = Path(path).expanduser().resolve()
        if not target.exists():
            return {"error": f"Path not found: {path}"}

        threshold = _SEVERITY_ORDER.get(severity.lower(), self._threshold)
        findings: list[dict[str, Any]] = []
        files_scanned = 0

        files = self._collect_files(target)
        for file_path in files:
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
            except (OSError, PermissionError):
                continue

            files_scanned += 1
            for line_num, line in enumerate(content.splitlines(), 1):
                for pattern_def in _VULN_PATTERNS:
                    sev = _SEVERITY_ORDER.get(pattern_def["severity"], 0)
                    if sev < threshold:
                        continue
                    if pattern_def["pattern"].search(line):
                        findings.append({
                            "id": pattern_def["id"],
                            "name": pattern_def["name"],
                            "severity": pattern_def["severity"],
                            "file": str(file_path),
                            "line": line_num,
                            "code": line.strip()[:200],
                            "description": pattern_def["description"],
                            "fix": pattern_def["fix"],
                        })

        # Deduplicate by file+line+id
        seen = set()
        unique: list[dict[str, Any]] = []
        for f in findings:
            key = (f["file"], f["line"], f["id"])
            if key not in seen:
                seen.add(key)
                unique.append(f)

        return {
            "findings": unique,
            "summary": self._summarize(unique),
            "files_scanned": files_scanned,
            "severity_threshold": severity,
        }

    async def scan_secrets(
        self,
        path: str,
        exclude_patterns: list[str] | None = None,
        entropy_threshold: float = 4.5,
    ) -> dict[str, Any]:
        """Scan for hardcoded secrets and high-entropy strings.

        Args:
            path: File or directory to scan.
            exclude_patterns: Glob patterns to exclude.
            entropy_threshold: Minimum entropy for flagging strings.

        Returns:
            Dictionary with detected secrets and metadata.
        """
        target = Path(path).expanduser().resolve()
        if not target.exists():
            return {"error": f"Path not found: {path}"}

        exclude_set = set(exclude_patterns or [])
        findings: list[dict[str, Any]] = []
        files_scanned = 0

        files = self._collect_files(target)
        for file_path in files:
            # Check exclude patterns
            rel = str(file_path.relative_to(target)) if file_path.is_relative_to(target) else str(file_path)
            if any(file_path.match(p) for p in exclude_set):
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
            except (OSError, PermissionError):
                continue

            files_scanned += 1
            for line_num, line in enumerate(content.splitlines(), 1):
                # Check secret patterns
                for pattern_def in _SECRET_PATTERNS:
                    match = pattern_def["pattern"].search(line)
                    if match:
                        findings.append({
                            "type": pattern_def["name"],
                            "file": str(file_path),
                            "line": line_num,
                            "match": match.group()[:60] + "..." if len(match.group()) > 60 else match.group(),
                            "confidence": pattern_def["confidence"],
                        })

                # Check high-entropy strings
                for match in re.finditer(r"""['""]([A-Za-z0-9_\-]{16,})['""]""", line):
                    value = match.group(1)
                    entropy = self._shannon_entropy(value)
                    if entropy >= entropy_threshold:
                        findings.append({
                            "type": "High-Entropy String",
                            "file": str(file_path),
                            "line": line_num,
                            "match": value[:40] + "..." if len(value) > 40 else value,
                            "entropy": round(entropy, 2),
                            "confidence": min(0.5 + (entropy - entropy_threshold) / 4, 0.95),
                        })

        return {
            "findings": findings,
            "summary": {
                "total": len(findings),
                "by_type": dict(Counter(f["type"] for f in findings)),
            },
            "files_scanned": files_scanned,
        }

    def _collect_files(self, target: Path) -> list[Path]:
        """Collect scannable files from target path."""
        if target.is_file():
            return [target]

        files: list[Path] = []
        for root, dirs, filenames in os.walk(target):
            dirs[:] = [d for d in dirs if d not in _SKIP_DIRS]
            for name in filenames:
                p = Path(root) / name
                if p.suffix.lower() not in _BINARY_EXTENSIONS:
                    files.append(p)
        return files

    @staticmethod
    def _shannon_entropy(data: str) -> float:
        """Calculate Shannon entropy of a string."""
        if not data:
            return 0.0
        counter = Counter(data)
        length = len(data)
        return -sum(
            (count / length) * math.log2(count / length)
            for count in counter.values()
        )

    @staticmethod
    def _summarize(findings: list[dict[str, Any]]) -> dict[str, Any]:
        """Generate a summary of findings."""
        return {
            "total": len(findings),
            "by_severity": dict(Counter(f["severity"] for f in findings)),
            "by_type": dict(Counter(f["name"] for f in findings)),
        }
