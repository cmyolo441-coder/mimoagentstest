"""Tests for the security-tools plugin."""

from __future__ import annotations

import pytest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from terminal_agent.plugins.api import PluginContext

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from main import SecurityToolsPlugin
from scanner import VulnerabilityScanner
from auditor import DependencyAuditor


@pytest.fixture
def plugin():
    p = SecurityToolsPlugin()
    p.activate(PluginContext())
    return p


@pytest.fixture
def sample_python_file(tmp_path: Path) -> Path:
    f = tmp_path / "sample.py"
    f.write_text(
        'import os\n'
        'password = "supersecret123"\n'
        'os.system(f"echo {user_input}")\n'
        'cursor.execute(f"SELECT * FROM users WHERE id={user_id}")\n'
        'result = eval(some_string)\n'
        'import hashlib\n'
        'hash_val = hashlib.md5(data).hexdigest()\n'
    )
    return f


@pytest.fixture
def sample_requirements(tmp_path: Path) -> Path:
    f = tmp_path / "requirements.txt"
    f.write_text("django==3.1.0\nrequests==2.20.0\nflask==1.0\npyyaml==4.1\n")
    return f


class TestSecurityToolsPlugin:
    def test_tools_registered(self, plugin: SecurityToolsPlugin):
        names = {t["name"] for t in plugin.get_tools()}
        assert names == {"vulnerability_scan", "dependency_audit", "secret_scan"}

    def test_tool_schemas_valid(self, plugin: SecurityToolsPlugin):
        for tool in plugin.get_tools():
            assert "name" in tool
            assert "description" in tool
            assert "parameters" in tool

    @pytest.mark.asyncio
    async def test_unknown_tool(self, plugin: SecurityToolsPlugin):
        with pytest.raises(ValueError, match="Unknown tool"):
            await plugin.handle_tool("nonexistent", {})

    def test_cleanup(self, plugin: SecurityToolsPlugin):
        plugin.cleanup()
        assert plugin._scanner is None


class TestVulnerabilityScanner:
    @pytest.mark.asyncio
    async def test_scan_finds_vulns(self, sample_python_file: Path):
        scanner = VulnerabilityScanner()
        result = await scanner.scan(str(sample_python_file), severity="low")

        assert result["files_scanned"] == 1
        assert len(result["findings"]) > 0

        names = {f["name"] for f in result["findings"]}
        assert "SQL Injection" in names
        assert "Command Injection" in names
        assert "Eval Usage" in names
        assert "Hardcoded Password" in names
        assert "Insecure Hash" in names

    @pytest.mark.asyncio
    async def test_scan_severity_filter(self, sample_python_file: Path):
        scanner = VulnerabilityScanner()
        result_low = await scanner.scan(str(sample_python_file), severity="low")
        result_high = await scanner.scan(str(sample_python_file), severity="high")

        assert len(result_low["findings"]) >= len(result_high["findings"])

    @pytest.mark.asyncio
    async def test_scan_nonexistent_path(self):
        scanner = VulnerabilityScanner()
        result = await scanner.scan("/nonexistent/path")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_scan_directory(self, tmp_path: Path):
        (tmp_path / "a.py").write_text('eval("code")')
        (tmp_path / "b.py").write_text('password = "secret123"')
        (tmp_path / "skip.bin").write_bytes(b"\x00\x01\x02")

        scanner = VulnerabilityScanner()
        result = await scanner.scan(str(tmp_path), severity="low")
        assert result["files_scanned"] == 2

    @pytest.mark.asyncio
    async def test_scan_secrets(self, sample_python_file: Path):
        scanner = VulnerabilityScanner()
        result = await scanner.scan_secrets(str(sample_python_file))
        assert result["files_scanned"] == 1
        # Should find the hardcoded password
        types = {f["type"] for f in result["findings"]}
        assert any("Secret" in t or "Password" in t or "Generic" in t for t in types)

    @pytest.mark.asyncio
    async def test_scan_secrets_private_key(self, tmp_path: Path):
        f = tmp_path / "key.pem"
        f.write_text("-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEA...\n-----END RSA PRIVATE KEY-----\n")

        scanner = VulnerabilityScanner()
        result = await scanner.scan_secrets(str(f))
        types = {f["type"] for f in result["findings"]}
        assert "Private Key" in types

    def test_shannon_entropy(self):
        scanner = VulnerabilityScanner()
        assert scanner._shannon_entropy("") == 0.0
        assert scanner._shannon_entropy("aaaa") == 0.0
        assert scanner._shannon_entropy("abcd") > 1.0
        assert scanner._shannon_entropy("aB3$xK9!") > scanner._shannon_entropy("aaaa")


class TestDependencyAuditor:
    @pytest.mark.asyncio
    async def test_audit_python(self, sample_requirements: Path):
        auditor = DependencyAuditor()
        result = await auditor.audit(str(sample_requirements), ecosystem="python")

        assert result["ecosystem"] == "python"
        assert result["dependencies_scanned"] == 4
        assert len(result["vulnerabilities"]) > 0

        packages = {v["package"] for v in result["vulnerabilities"]}
        assert "django" in packages
        assert "pyyaml" in packages

    @pytest.mark.asyncio
    async def test_audit_auto_detect(self, sample_requirements: Path):
        auditor = DependencyAuditor()
        result = await auditor.audit(str(sample_requirements))
        assert result["ecosystem"] == "python"

    @pytest.mark.asyncio
    async def test_audit_node(self, tmp_path: Path):
        pkg = tmp_path / "package.json"
        pkg.write_text('{"dependencies": {"lodash": "3.0.0", "express": "4.18.0"}}')

        auditor = DependencyAuditor()
        result = await auditor.audit(str(tmp_path), ecosystem="node")
        assert result["ecosystem"] == "node"
        assert result["dependencies_scanned"] == 2

    @pytest.mark.asyncio
    async def test_audit_nonexistent(self):
        auditor = DependencyAuditor()
        result = await auditor.audit("/nonexistent/path")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_audit_unknown_ecosystem(self, tmp_path: Path):
        (tmp_path / "random.txt").write_text("nothing here")
        auditor = DependencyAuditor()
        result = await auditor.audit(str(tmp_path))
        assert "error" in result
