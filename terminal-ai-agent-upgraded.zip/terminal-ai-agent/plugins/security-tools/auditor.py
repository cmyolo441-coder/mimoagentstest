"""Dependency auditor — checks project dependencies for known CVEs.

Supports Python (pip), Node.js (npm), Go (go.mod), and Rust (Cargo.toml)
ecosystems. Uses the OSV database via subprocess when available, with
regex-based fallback for offline scanning.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Ecosystem detection heuristics
_ECOSYSTEM_FILES: dict[str, list[str]] = {
    "python": ["requirements.txt", "requirements*.txt", "Pipfile", "pyproject.toml", "setup.py"],
    "node": ["package.json", "package-lock.json", "yarn.lock"],
    "go": ["go.mod", "go.sum"],
    "rust": ["Cargo.toml", "Cargo.lock"],
}

# Known vulnerable package patterns (offline fallback)
_KNOWN_VULNERABLE: dict[str, list[dict[str, Any]]] = {
    "python": [
        {"package": "django", "version_pattern": r"^([12]\.|3\.[0-1]\.)", "cve": "CVE-2021-33203", "severity": "high", "fix": ">=3.2.4"},
        {"package": "flask", "version_pattern": r"^[01]\.", "cve": "CVE-2023-30861", "severity": "medium", "fix": ">=2.3.2"},
        {"package": "requests", "version_pattern": r"^2\.(?:1[0-9]|2[0-0])\.", "cve": "CVE-2023-32681", "severity": "medium", "fix": ">=2.31.0"},
        {"package": "pyyaml", "version_pattern": r"^[0-4]\.", "cve": "CVE-2020-14343", "severity": "high", "fix": ">=5.4"},
        {"package": "pillow", "version_pattern": r"^(?:[1-8]\.|9\.[0-3]\.)", "cve": "CVE-2023-44271", "severity": "high", "fix": ">=10.0.0"},
        {"package": "cryptography", "version_pattern": r"^(?:[0-3]\.|4[0-1]\.)", "cve": "CVE-2023-49083", "severity": "medium", "fix": ">=41.0.6"},
    ],
    "node": [
        {"package": "minimist", "version_pattern": r"^1\.[01]\.", "cve": "CVE-2021-44906", "severity": "high", "fix": ">=1.2.6"},
        {"package": "lodash", "version_pattern": r"^[0-3]\.", "cve": "CVE-2021-23337", "severity": "high", "fix": ">=4.17.21"},
        {"package": "axios", "version_pattern": r"^0\.(?:[0-9]|1[0-9]|2[0-6])\.", "cve": "CVE-2023-45857", "severity": "medium", "fix": ">=1.6.0"},
    ],
    "go": [],
    "rust": [],
}


class DependencyAuditor:
    """Audits project dependencies for known security vulnerabilities.

    Detects the package ecosystem from project files, parses dependency
    lists, and checks each against known vulnerability databases.
    """

    async def audit(
        self,
        path: str,
        ecosystem: str | None = None,
        include_dev: bool = False,
    ) -> dict[str, Any]:
        """Audit project dependencies.

        Args:
            path: Path to project directory or requirements file.
            ecosystem: Package ecosystem (auto-detected if None).
            include_dev: Whether to include dev dependencies.

        Returns:
            Dictionary with vulnerabilities, dependency count, and metadata.
        """
        target = Path(path).expanduser().resolve()
        if not target.exists():
            return {"error": f"Path not found: {path}"}

        # Detect ecosystem
        if ecosystem is None:
            ecosystem = self._detect_ecosystem(target)
        if ecosystem is None:
            return {"error": "Could not detect package ecosystem. Specify ecosystem parameter."}

        # Parse dependencies
        deps = await self._parse_dependencies(target, ecosystem, include_dev=include_dev)
        if not deps:
            return {"error": f"No dependencies found for {ecosystem}", "ecosystem": ecosystem}

        # Check for vulnerabilities
        vulns = self._check_vulnerabilities(deps, ecosystem)

        # Try OSV API for more comprehensive check
        osv_vulns = await self._check_osv(deps, ecosystem)
        vulns.extend(osv_vulns)

        # Deduplicate
        seen = set()
        unique_vulns: list[dict[str, Any]] = []
        for v in vulns:
            key = (v.get("package"), v.get("cve"))
            if key not in seen:
                seen.add(key)
                unique_vulns.append(v)

        return {
            "ecosystem": ecosystem,
            "dependencies_scanned": len(deps),
            "vulnerabilities": unique_vulns,
            "summary": {
                "total_vulns": len(unique_vulns),
                "critical": sum(1 for v in unique_vulns if v.get("severity") == "critical"),
                "high": sum(1 for v in unique_vulns if v.get("severity") == "high"),
                "medium": sum(1 for v in unique_vulns if v.get("severity") == "medium"),
                "low": sum(1 for v in unique_vulns if v.get("severity") == "low"),
            },
        }

    def _detect_ecosystem(self, target: Path) -> str | None:
        """Detect the package ecosystem from project files."""
        search_dir = target if target.is_dir() else target.parent
        for ecosystem, files in _ECOSYSTEM_FILES.items():
            for pattern in files:
                matches = list(search_dir.glob(pattern))
                if matches:
                    return ecosystem
        return None

    async def _parse_dependencies(
        self, target: Path, ecosystem: str, include_dev: bool = False
    ) -> list[dict[str, str]]:
        """Parse dependency files into a list of {name, version}."""
        if ecosystem == "python":
            return await self._parse_python_deps(target, include_dev=include_dev)
        elif ecosystem == "node":
            return await self._parse_node_deps(target, include_dev=include_dev)
        elif ecosystem == "go":
            return await self._parse_go_deps(target)
        elif ecosystem == "rust":
            return await self._parse_rust_deps(target)
        return []

    async def _parse_python_deps(
        self, target: Path, include_dev: bool = False
    ) -> list[dict[str, str]]:
        """Parse Python requirements files."""
        deps: list[dict[str, str]] = []
        search_dir = target if target.is_dir() else target.parent

        # requirements.txt
        for req_file in sorted(search_dir.glob("requirements*.txt")):
            if not include_dev and "dev" in req_file.name.lower():
                continue
            content = req_file.read_text(encoding="utf-8", errors="ignore")
            for line in content.splitlines():
                line = line.strip()
                if line and not line.startswith("#") and not line.startswith("-"):
                    match = re.match(r"^([a-zA-Z0-9_.-]+)\s*(?:[>=<!~]+\s*([^\s,;]+))?", line)
                    if match:
                        deps.append({"name": match.group(1).lower(), "version": match.group(2) or "unknown"})

        # pyproject.toml
        pyproject = search_dir / "pyproject.toml"
        if pyproject.exists():
            content = pyproject.read_text(encoding="utf-8")
            for match in re.finditer(r"""['""]([a-zA-Z0-9_.-]+)(?:\s*[>=<!~]+\s*([^'""]+))?['""]""", content):
                deps.append({"name": match.group(1).lower(), "version": match.group(2) or "unknown"})

        return deps

    async def _parse_node_deps(
        self, target: Path, include_dev: bool = False
    ) -> list[dict[str, str]]:
        """Parse Node.js package.json."""
        search_dir = target if target.is_dir() else target.parent
        pkg_file = search_dir / "package.json"
        if not pkg_file.exists():
            return []

        try:
            pkg = json.loads(pkg_file.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return []

        deps: list[dict[str, str]] = []
        for name, version in pkg.get("dependencies", {}).items():
            deps.append({"name": name, "version": version.lstrip("^~>=<")})

        if include_dev:
            for name, version in pkg.get("devDependencies", {}).items():
                deps.append({"name": name, "version": version.lstrip("^~>=<")})

        return deps

    async def _parse_go_deps(self, target: Path) -> list[dict[str, str]]:
        """Parse Go go.mod."""
        search_dir = target if target.is_dir() else target.parent
        go_mod = search_dir / "go.mod"
        if not go_mod.exists():
            return []

        deps: list[dict[str, str]] = []
        content = go_mod.read_text(encoding="utf-8")
        for match in re.finditer(r"^\s+([^\s]+)\s+(v[^\s]+)", content, re.MULTILINE):
            deps.append({"name": match.group(1), "version": match.group(2)})

        return deps

    async def _parse_rust_deps(self, target: Path) -> list[dict[str, str]]:
        """Parse Rust Cargo.toml."""
        search_dir = target if target.is_dir() else target.parent
        cargo = search_dir / "Cargo.toml"
        if not cargo.exists():
            return []

        deps: list[dict[str, str]] = []
        content = cargo.read_text(encoding="utf-8")
        for match in re.finditer(r"""^\s*([a-zA-Z0-9_-]+)\s*=\s*['""]([^'""]+)['""]""", content, re.MULTILINE):
            deps.append({"name": match.group(1), "version": match.group(2)})

        return deps

    def _check_vulnerabilities(
        self, deps: list[dict[str, str]], ecosystem: str
    ) -> list[dict[str, Any]]:
        """Check dependencies against known vulnerable packages."""
        vulns: list[dict[str, Any]] = []
        known = _KNOWN_VULNERABLE.get(ecosystem, [])

        for dep in deps:
            name = dep["name"].lower()
            version = dep["version"]
            for vuln in known:
                if name == vuln["package"]:
                    if version != "unknown" and re.match(vuln["version_pattern"], version):
                        vulns.append({
                            "package": name,
                            "version": version,
                            "cve": vuln["cve"],
                            "severity": vuln["severity"],
                            "fix": vuln["fix"],
                            "source": "local-db",
                        })

        return vulns

    async def _check_osv(
        self, deps: list[dict[str, str]], ecosystem: str
    ) -> list[dict[str, Any]]:
        """Query the OSV vulnerability database."""
        ecosystem_map = {"python": "PyPI", "node": "npm", "go": "Go", "rust": "crates.io"}
        osv_ecosystem = ecosystem_map.get(ecosystem)
        if not osv_ecosystem:
            return []

        vulns: list[dict[str, Any]] = []
        try:
            import httpx
            async with httpx.AsyncClient(timeout=10) as client:
                for dep in deps[:50]:  # Limit to avoid rate limiting
                    payload = {
                        "package": {"name": dep["name"], "ecosystem": osv_ecosystem}
                    }
                    if dep["version"] != "unknown":
                        payload["version"] = dep["version"]

                    try:
                        resp = await client.post(
                            "https://api.osv.dev/v1/query",
                            json=payload,
                        )
                        if resp.status_code == 200:
                            data = resp.json()
                            for vuln_data in data.get("vulns", []):
                                vulns.append({
                                    "package": dep["name"],
                                    "version": dep["version"],
                                    "cve": vuln_data.get("id", ""),
                                    "severity": self._extract_osv_severity(vuln_data),
                                    "summary": vuln_data.get("summary", ""),
                                    "source": "osv",
                                })
                    except Exception:
                        continue
        except ImportError:
            logger.debug("httpx not available, skipping OSV check")

        return vulns

    @staticmethod
    def _extract_osv_severity(vuln_data: dict[str, Any]) -> str:
        """Extract severity from OSV vulnerability data."""
        for severity in vuln_data.get("severity", []):
            if severity.get("type") == "CVSS_V3":
                score_str = severity.get("score", "")
                try:
                    # Extract base score from CVSS vector
                    match = re.search(r"CVSS:3\.[01]/.*", score_str)
                    if match:
                        return "high"  # Simplified mapping
                except Exception:
                    pass
        # Check database_specific
        db = vuln_data.get("database_specific", {})
        severity = db.get("severity", "medium")
        return severity.lower() if isinstance(severity, str) else "medium"
