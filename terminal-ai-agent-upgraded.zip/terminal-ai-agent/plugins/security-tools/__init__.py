"""Security tools plugin — vulnerability scanning, dependency auditing, and secret detection."""

from __future__ import annotations

from .main import SecurityToolsPlugin

__all__ = ["SecurityToolsPlugin"]
__version__ = "1.0.0"
