"""Security tools plugin — vulnerability scanning, dependency auditing, and secret detection.

Provides tools for scanning codebases for known vulnerabilities, auditing
dependencies for security issues, and detecting hardcoded secrets.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.plugins.api import PluginBase, PluginContext

from .scanner import VulnerabilityScanner
from .auditor import DependencyAuditor

logger = logging.getLogger(__name__)


class SecurityToolsPlugin(PluginBase):
    """Plugin providing security scanning and auditing tools.

    Tools:
        vulnerability_scan: Scan code for known vulnerabilities and security issues.
        dependency_audit: Audit project dependencies for known CVEs.
        secret_scan: Detect hardcoded secrets, API keys, and credentials.
    """

    name = "security-tools"
    version = "1.0.0"

    def __init__(self) -> None:
        self._context: PluginContext | None = None
        self._scanner: VulnerabilityScanner | None = None
        self._auditor: DependencyAuditor | None = None

    def activate(self, context: PluginContext | None = None) -> None:
        """Initialize the security tools plugin."""
        self._context = context or PluginContext()
        cfg = self._context.config if self._context else {}
        self._scanner = VulnerabilityScanner(
            severity_threshold=cfg.get("severity_threshold", "medium"),
        )
        self._auditor = DependencyAuditor()
        if self._context:
            self._context.log.info("Security tools plugin activated")

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions."""
        return [
            {
                "name": "vulnerability_scan",
                "description": "Scan source code for security vulnerabilities using static analysis. Detects injection flaws, insecure patterns, and common security anti-patterns.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "File or directory path to scan.",
                        },
                        "severity": {
                            "type": "string",
                            "description": "Minimum severity to report (low, medium, high, critical).",
                            "default": "medium",
                        },
                        "language": {
                            "type": "string",
                            "description": "Programming language (auto-detected if omitted).",
                        },
                    },
                    "required": ["path"],
                },
                "returns": "List of detected vulnerabilities with severity, location, and description.",
            },
            {
                "name": "dependency_audit",
                "description": "Audit project dependencies for known CVEs and security advisories.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path to project directory or requirements file.",
                        },
                        "ecosystem": {
                            "type": "string",
                            "description": "Package ecosystem (python, node, go, rust). Auto-detected if omitted.",
                        },
                        "include_dev": {
                            "type": "boolean",
                            "description": "Include dev dependencies in the audit.",
                            "default": False,
                        },
                    },
                    "required": ["path"],
                },
                "returns": "List of vulnerable dependencies with CVE IDs, severity, and fix versions.",
            },
            {
                "name": "secret_scan",
                "description": "Scan codebase for hardcoded secrets, API keys, tokens, passwords, and other sensitive data.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "File or directory path to scan.",
                        },
                        "exclude_patterns": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Glob patterns to exclude from scanning.",
                        },
                        "entropy_threshold": {
                            "type": "number",
                            "description": "Entropy threshold for detecting high-entropy strings (0-8).",
                            "default": 4.5,
                        },
                    },
                    "required": ["path"],
                },
                "returns": "List of detected secrets with file location, type, and confidence.",
            },
        ]

    async def handle_tool(self, tool_name: str, parameters: dict[str, Any]) -> Any:
        """Dispatch tool calls."""
        handlers = {
            "vulnerability_scan": self._vulnerability_scan,
            "dependency_audit": self._dependency_audit,
            "secret_scan": self._secret_scan,
        }
        handler = handlers.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        return await handler(**parameters)

    async def _vulnerability_scan(
        self,
        path: str,
        severity: str = "medium",
        language: str | None = None,
    ) -> dict[str, Any]:
        """Scan code for vulnerabilities."""
        assert self._scanner is not None
        return await self._scanner.scan(path, severity=severity, language=language)

    async def _dependency_audit(
        self,
        path: str,
        ecosystem: str | None = None,
        include_dev: bool = False,
    ) -> dict[str, Any]:
        """Audit dependencies for CVEs."""
        assert self._auditor is not None
        return await self._auditor.audit(path, ecosystem=ecosystem, include_dev=include_dev)

    async def _secret_scan(
        self,
        path: str,
        exclude_patterns: list[str] | None = None,
        entropy_threshold: float = 4.5,
    ) -> dict[str, Any]:
        """Scan for hardcoded secrets."""
        assert self._scanner is not None
        return await self._scanner.scan_secrets(
            path, exclude_patterns=exclude_patterns, entropy_threshold=entropy_threshold
        )

    def cleanup(self) -> None:
        """Release resources."""
        if self._context:
            self._context.log.info("Security tools plugin cleaned up")
        self._scanner = None
        self._auditor = None
        self._context = None
