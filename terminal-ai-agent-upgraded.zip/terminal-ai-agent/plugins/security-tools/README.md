# security-tools

Security scanning, dependency auditing, and secret detection for Terminal Agent.

## Tools

### `vulnerability_scan`

Scan source code for security vulnerabilities using static analysis.

**Parameters:**
- `path` (string, required) — File or directory to scan.
- `severity` (string) — Minimum severity (low, medium, high, critical).
- `language` (string) — Programming language hint.

**Returns:** Findings with severity, location, description, and fix suggestions.

**Detects:**
- SQL injection via string formatting
- Command injection in subprocess calls
- Use of eval/exec
- Hardcoded credentials
- Insecure hash algorithms (MD5/SHA1)
- Non-cryptographic random usage
- Debug mode in production
- Insecure deserialization (pickle)
- Disabled TLS verification

### `dependency_audit`

Audit project dependencies for known CVEs.

**Parameters:**
- `path` (string, required) — Project directory or requirements file.
- `ecosystem` (string) — Package ecosystem (python, node, go, rust).
- `include_dev` (boolean) — Include dev dependencies.

**Returns:** Vulnerable packages with CVE IDs, severity, and fix versions.

**Supported ecosystems:** Python (pip), Node.js (npm), Go (go.mod), Rust (Cargo.toml).

### `secret_scan`

Detect hardcoded secrets, API keys, tokens, and high-entropy strings.

**Parameters:**
- `path` (string, required) — File or directory to scan.
- `exclude_patterns` (array) — Glob patterns to exclude.
- `entropy_threshold` (number) — Entropy threshold (0-8, default 4.5).

**Returns:** Detected secrets with type, location, and confidence score.

**Detects:**
- AWS access keys and secret keys
- Generic API keys and tokens
- Private keys (PEM format)
- JWT tokens
- High-entropy strings

## Configuration

```toml
[plugins.security-tools]
severity_threshold = "medium"
```

## Testing

```bash
cd plugins/security-tools
python -m pytest tests/ -v
```
