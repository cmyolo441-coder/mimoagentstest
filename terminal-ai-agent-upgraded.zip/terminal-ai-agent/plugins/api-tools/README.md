# api-tools

API client generation, OpenAPI parsing, and API testing tools for Terminal Agent.

## Tools

### `openapi_parse`

Parse an OpenAPI/Swagger specification and extract endpoint information.

**Parameters:**
- `spec_url` (string, required) — URL or file path to the spec (JSON or YAML).
- `filter_tag` (string) — Only return endpoints matching this tag.

**Returns:** Parsed API info: version, base URL, endpoints, schemas.

### `client_generate`

Generate a typed Python API client from an OpenAPI spec.

**Parameters:**
- `spec_url` (string, required) — URL or file path to the spec.
- `output_dir` (string) — Output directory (default: `./generated_client`).
- `client_name` (string) — Client class name (default: `ApiClient`).

**Returns:** Generated file paths and endpoint count.

### `api_test`

Send a test HTTP request to an API endpoint.

**Parameters:**
- `url` (string, required) — Endpoint URL.
- `method` (string) — HTTP method (default: `GET`).
- `headers` (object) — Request headers.
- `body` — Request body (JSON).
- `timeout` (integer) — Timeout in seconds (default: 30).

**Returns:** Status code, headers, body, timing.

## Configuration

```toml
[plugins.api-tools]
default_timeout = 30
```

## Dependencies

- `httpx` — Async HTTP client
- `pyyaml` — YAML parsing
- `jsonschema` — Schema validation
- `jinja2` — Code generation templates

## Testing

```bash
cd plugins/api-tools
python -m pytest tests/ -v
```
