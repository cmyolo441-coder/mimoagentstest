"""OpenAPI specification parser.

Parses OpenAPI 2.0 (Swagger) and 3.x specifications from URLs or local files,
extracting endpoints, schemas, parameters, and metadata.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
import yaml

logger = logging.getLogger(__name__)


class OpenAPIParser:
    """Parses OpenAPI/Swagger specifications into structured data.

    Supports both JSON and YAML formats, loaded from URLs or local files.
    Handles OpenAPI 2.0 (Swagger) and 3.x specifications.
    """

    async def parse(
        self, spec_url: str, filter_tag: str | None = None
    ) -> dict[str, Any]:
        """Parse an OpenAPI specification.

        Args:
            spec_url: URL or file path to the specification.
            filter_tag: Only include endpoints with this tag.

        Returns:
            Parsed specification with keys: info, base_url, endpoints, schemas.
        """
        raw = await self._load_spec(spec_url)
        spec = self._parse_content(raw)

        version = spec.get("openapi", spec.get("swagger", "unknown"))
        is_v2 = version.startswith("2")

        if is_v2:
            return self._parse_v2(spec, filter_tag=filter_tag)
        return self._parse_v3(spec, filter_tag=filter_tag)

    async def _load_spec(self, spec_url: str) -> str:
        """Load spec content from URL or file path."""
        parsed = urlparse(spec_url)

        if parsed.scheme in ("http", "https"):
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(spec_url)
                resp.raise_for_status()
                return resp.text

        path = Path(spec_url).expanduser()
        if not path.exists():
            raise FileNotFoundError(f"Spec file not found: {spec_url}")
        return path.read_text(encoding="utf-8")

    def _parse_content(self, content: str) -> dict[str, Any]:
        """Parse JSON or YAML content."""
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            return yaml.safe_load(content)

    def _parse_v2(
        self, spec: dict[str, Any], filter_tag: str | None = None
    ) -> dict[str, Any]:
        """Parse Swagger 2.0 specification."""
        info = spec.get("info", {})
        host = spec.get("host", "")
        base_path = spec.get("basePath", "")
        schemes = spec.get("schemes", ["https"])
        base_url = f"{schemes[0]}://{host}{base_path}" if host else ""

        endpoints = []
        for path, methods in spec.get("paths", {}).items():
            for method, operation in methods.items():
                if method in ("get", "post", "put", "delete", "patch", "head", "options"):
                    tags = operation.get("tags", [])
                    if filter_tag and filter_tag not in tags:
                        continue
                    endpoints.append({
                        "path": path,
                        "method": method.upper(),
                        "operation_id": operation.get("operationId", ""),
                        "summary": operation.get("summary", ""),
                        "description": operation.get("description", ""),
                        "tags": tags,
                        "parameters": self._extract_parameters_v2(operation.get("parameters", [])),
                        "responses": operation.get("responses", {}),
                    })

        return {
            "version": "2.0",
            "info": info,
            "base_url": base_url,
            "endpoints": endpoints,
            "definitions": spec.get("definitions", {}),
        }

    def _parse_v3(
        self, spec: dict[str, Any], filter_tag: str | None = None
    ) -> dict[str, Any]:
        """Parse OpenAPI 3.x specification."""
        info = spec.get("info", {})
        servers = spec.get("servers", [])
        base_url = servers[0].get("url", "") if servers else ""

        endpoints = []
        for path, methods in spec.get("paths", {}).items():
            for method, operation in methods.items():
                if method in ("get", "post", "put", "delete", "patch", "head", "options"):
                    tags = operation.get("tags", [])
                    if filter_tag and filter_tag not in tags:
                        continue
                    endpoints.append({
                        "path": path,
                        "method": method.upper(),
                        "operation_id": operation.get("operationId", ""),
                        "summary": operation.get("summary", ""),
                        "description": operation.get("description", ""),
                        "tags": tags,
                        "parameters": self._extract_parameters_v3(operation.get("parameters", [])),
                        "request_body": operation.get("requestBody"),
                        "responses": operation.get("responses", {}),
                    })

        return {
            "version": spec.get("openapi", "3.0"),
            "info": info,
            "base_url": base_url,
            "endpoints": endpoints,
            "components": spec.get("components", {}),
            "schemas": spec.get("components", {}).get("schemas", {}),
        }

    def _extract_parameters_v2(self, params: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Extract parameters from Swagger 2.0 operation."""
        result = []
        for p in params:
            result.append({
                "name": p.get("name", ""),
                "in": p.get("in", ""),
                "required": p.get("required", False),
                "type": p.get("type", p.get("schema", {}).get("$ref", "")),
                "description": p.get("description", ""),
            })
        return result

    def _extract_parameters_v3(self, params: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Extract parameters from OpenAPI 3.x operation."""
        result = []
        for p in params:
            schema = p.get("schema", {})
            result.append({
                "name": p.get("name", ""),
                "in": p.get("in", ""),
                "required": p.get("required", False),
                "type": schema.get("type", schema.get("$ref", "")),
                "description": p.get("description", ""),
            })
        return result
