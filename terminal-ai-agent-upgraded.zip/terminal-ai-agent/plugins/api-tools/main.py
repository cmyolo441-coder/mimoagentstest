"""API tools plugin — OpenAPI parsing, client generation, and API testing.

Provides tools for parsing OpenAPI specifications, generating typed API
clients, and testing API endpoints.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.plugins.api import PluginBase, PluginContext

from .openapi import OpenAPIParser
from .client_gen import ClientGenerator

logger = logging.getLogger(__name__)


class ApiToolsPlugin(PluginBase):
    """Plugin providing API development tools.

    Tools:
        openapi_parse: Parse an OpenAPI/Swagger spec and extract endpoints.
        client_generate: Generate a typed Python client from an OpenAPI spec.
        api_test: Send a test request to an API endpoint.
    """

    name = "api-tools"
    version = "1.0.0"

    def __init__(self) -> None:
        self._context: PluginContext | None = None
        self._parser: OpenAPIParser | None = None
        self._generator: ClientGenerator | None = None

    def activate(self, context: PluginContext | None = None) -> None:
        """Initialize the API tools plugin."""
        self._context = context or PluginContext()
        self._parser = OpenAPIParser()
        self._generator = ClientGenerator()
        if self._context:
            self._context.log.info("API tools plugin activated")

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions."""
        return [
            {
                "name": "openapi_parse",
                "description": "Parse an OpenAPI/Swagger specification and extract endpoint information, schemas, and metadata.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "spec_url": {
                            "type": "string",
                            "description": "URL or file path to the OpenAPI specification (JSON or YAML).",
                        },
                        "filter_tag": {
                            "type": "string",
                            "description": "Only return endpoints matching this tag.",
                        },
                    },
                    "required": ["spec_url"],
                },
                "returns": "Parsed API information including endpoints, methods, parameters, and schemas.",
            },
            {
                "name": "client_generate",
                "description": "Generate a typed Python API client from an OpenAPI specification.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "spec_url": {
                            "type": "string",
                            "description": "URL or file path to the OpenAPI specification.",
                        },
                        "output_dir": {
                            "type": "string",
                            "description": "Directory to write the generated client files.",
                            "default": "./generated_client",
                        },
                        "client_name": {
                            "type": "string",
                            "description": "Name for the generated client class.",
                            "default": "ApiClient",
                        },
                    },
                    "required": ["spec_url"],
                },
                "returns": "Generated client code and file paths.",
            },
            {
                "name": "api_test",
                "description": "Send a test HTTP request to an API endpoint and return the response.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "The endpoint URL to test.",
                        },
                        "method": {
                            "type": "string",
                            "description": "HTTP method (GET, POST, PUT, DELETE, PATCH).",
                            "default": "GET",
                        },
                        "headers": {
                            "type": "object",
                            "description": "Request headers.",
                        },
                        "body": {
                            "description": "Request body (JSON serializable).",
                        },
                        "timeout": {
                            "type": "integer",
                            "description": "Request timeout in seconds.",
                            "default": 30,
                        },
                    },
                    "required": ["url"],
                },
                "returns": "Response status, headers, body, and timing information.",
            },
        ]

    async def handle_tool(self, tool_name: str, parameters: dict[str, Any]) -> Any:
        """Dispatch tool calls."""
        handlers = {
            "openapi_parse": self._openapi_parse,
            "client_generate": self._client_generate,
            "api_test": self._api_test,
        }
        handler = handlers.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        return await handler(**parameters)

    async def _openapi_parse(
        self, spec_url: str, filter_tag: str | None = None
    ) -> dict[str, Any]:
        """Parse an OpenAPI specification."""
        assert self._parser is not None
        return await self._parser.parse(spec_url, filter_tag=filter_tag)

    async def _client_generate(
        self,
        spec_url: str,
        output_dir: str = "./generated_client",
        client_name: str = "ApiClient",
    ) -> dict[str, Any]:
        """Generate a Python API client."""
        assert self._generator is not None
        assert self._parser is not None
        spec = await self._parser.parse(spec_url)
        return await self._generator.generate(
            spec, output_dir=output_dir, client_name=client_name
        )

    async def _api_test(
        self,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: Any = None,
        timeout: int = 30,
    ) -> dict[str, Any]:
        """Send a test API request."""
        import httpx
        import time

        async with httpx.AsyncClient(timeout=timeout) as client:
            start = time.monotonic()
            response = await client.request(
                method=method, url=url, headers=headers, json=body
            )
            elapsed = time.monotonic() - start

        content_type = response.headers.get("content-type", "")
        if "json" in content_type:
            try:
                resp_body = response.json()
            except Exception:
                resp_body = response.text
        else:
            resp_body = response.text[:10_000]

        return {
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "body": resp_body,
            "elapsed_seconds": round(elapsed, 3),
            "url": str(response.url),
        }

    def cleanup(self) -> None:
        """Release resources."""
        if self._context:
            self._context.log.info("API tools plugin cleaned up")
        self._parser = None
        self._generator = None
        self._context = None
