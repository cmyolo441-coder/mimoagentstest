"""API client code generator.

Generates typed Python API client code from parsed OpenAPI specifications.
Uses Jinja2 templates to produce clean, well-documented client modules.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Jinja2 template for the generated client
_CLIENT_TEMPLATE = '''"""Auto-generated API client.

Generated from OpenAPI specification: {spec_title} v{spec_version}
DO NOT EDIT — regenerate with: terminal-agent tools call client_generate
"""

from __future__ import annotations

import httpx
from typing import Any, Optional


class {client_name}:
    """Client for {spec_title}.

    Base URL: {base_url}

    Auto-generated from OpenAPI spec. All methods return response data
    directly and raise httpx.HTTPStatusError on 4xx/5xx responses.
    """

    def __init__(
        self,
        base_url: str = "{base_url}",
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=headers or {{"Content-Type": "application/json"}},
            timeout=timeout,
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "{client_name}":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

{methods}
'''


_METHOD_TEMPLATE = '''
    async def {method_name}(self{params}) -> dict[str, Any]:
        """{summary}

{param_docs}
        Returns:
            Response data as a dictionary.
        """
        url = f"{{self.base_url}}{path}"
{request_body}
        response = await self._client.{http_method}(url{kwargs})
        response.raise_for_status()
        return response.json()
'''


class ClientGenerator:
    """Generates Python API client code from parsed OpenAPI specifications.

    Produces a single-module async client using httpx, with type hints
    and docstrings for each endpoint method.
    """

    async def generate(
        self,
        spec: dict[str, Any],
        output_dir: str = "./generated_client",
        client_name: str = "ApiClient",
    ) -> dict[str, Any]:
        """Generate client code from a parsed spec.

        Args:
            spec: Parsed OpenAPI specification (output of OpenAPIParser.parse).
            output_dir: Directory to write generated files.
            client_name: Name for the client class.

        Returns:
            Dictionary with generated file paths and endpoint count.
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        info = spec.get("info", {})
        base_url = spec.get("base_url", "")
        endpoints = spec.get("endpoints", [])

        methods = []
        for ep in endpoints:
            methods.append(self._generate_method(ep))

        code = _CLIENT_TEMPLATE.format(
            spec_title=info.get("title", "API"),
            spec_version=info.get("version", "0.0.0"),
            base_url=base_url,
            client_name=client_name,
            methods="".join(methods),
        )

        # Write main client file
        client_file = output_path / "client.py"
        client_file.write_text(code, encoding="utf-8")

        # Write __init__.py
        init_file = output_path / "__init__.py"
        init_file.write_text(
            f'"""Auto-generated API client for {info.get("title", "API")}."""\n\n'
            f"from .client import {client_name}\n\n__all__ = [\"{client_name}\"]\n",
            encoding="utf-8",
        )

        # Write models stub
        models_file = output_path / "models.py"
        models_file.write_text(
            '"""API data models (placeholder — extend as needed)."""\n\n'
            'from __future__ import annotations\n'
            'from dataclasses import dataclass\n'
            'from typing import Any\n',
            encoding="utf-8",
        )

        return {
            "output_dir": str(output_path),
            "files": [str(client_file), str(init_file), str(models_file)],
            "endpoint_count": len(endpoints),
            "client_name": client_name,
        }

    def _generate_method(self, endpoint: dict[str, Any]) -> str:
        """Generate a single method string for an endpoint."""
        method = endpoint.get("method", "GET").lower()
        path = endpoint.get("path", "")
        summary = endpoint.get("summary", f"{method.upper()} {path}")
        parameters = endpoint.get("parameters", [])
        request_body = endpoint.get("request_body")

        # Build parameter list
        path_params = [p for p in parameters if p.get("in") == "path"]
        query_params = [p for p in parameters if p.get("in") == "query"]
        header_params = [p for p in parameters if p.get("in") == "header"]

        params = []
        param_docs = []

        for p in path_params:
            name = self._sanitize_name(p["name"])
            params.append(f", {name}: str")
            param_docs.append(f"            {name}: {p.get('description', 'Path parameter.')}")

        if request_body:
            params.append(", body: dict[str, Any]")
            param_docs.append("            body: Request body.")

        for p in query_params:
            name = self._sanitize_name(p["name"])
            required = p.get("required", False)
            type_str = self._map_type(p.get("type", "string"))
            if required:
                params.append(f", {name}: {type_str}")
            else:
                params.append(f", {name}: {type_str} | None = None")
            param_docs.append(f"            {name}: {p.get('description', 'Query parameter.')}")

        params_str = "".join(params)
        param_docs_str = "\n".join(param_docs) if param_docs else "            (none)"

        # Build path substitution
        path_expr = path
        for p in path_params:
            pname = self._sanitize_name(p["name"])
            path_expr = path_expr.replace(f"{{{p['name']}}}", f"{{self.{pname}}}")
            # Fix: use the local variable, not self
            path_expr = path_expr.replace(f"{{self.{pname}}}", "{" + pname + "}")

        # Build kwargs
        kwargs_parts = []
        if query_params:
            qp_names = [self._sanitize_name(p["name"]) for p in query_params]
            kwargs_parts.append(
                "params={k: v for k, v in {"
                + ", ".join(f'"{p["name"]}": {self._sanitize_name(p["name"])}' for p in query_params)
                + "}.items() if v is not None}"
            )

        kwargs = ""
        if kwargs_parts:
            kwargs = ", " + ", ".join(kwargs_parts)

        request_body_code = ""
        if request_body:
            request_body_code = "        json_data = body\n"

        method_name = self._to_snake_case(endpoint.get("operation_id", "")) or \
                      f"{method}_{self._path_to_name(path)}"

        return _METHOD_TEMPLATE.format(
            method_name=method_name,
            params=params_str,
            summary=summary,
            param_docs=param_docs_str,
            path=f'"{path_expr}"',
            request_body=request_body_code,
            http_method=method,
            kwargs=kwargs,
        )

    @staticmethod
    def _sanitize_name(name: str) -> str:
        """Sanitize a parameter name for use as a Python identifier."""
        name = re.sub(r"[^a-zA-Z0-9_]", "_", name)
        if name and name[0].isdigit():
            name = "p_" + name
        return name or "param"

    @staticmethod
    def _to_snake_case(name: str) -> str:
        """Convert operationId to snake_case."""
        if not name:
            return ""
        s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", name)
        return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1).lower()

    @staticmethod
    def _path_to_name(path: str) -> str:
        """Convert a URL path to a method name."""
        parts = [p for p in path.split("/") if p and not p.startswith("{")]
        return "_".join(parts[-2:]) if parts else "endpoint"

    @staticmethod
    def _map_type(openapi_type: str) -> str:
        """Map OpenAPI type to Python type string."""
        mapping = {
            "string": "str",
            "integer": "int",
            "number": "float",
            "boolean": "bool",
            "array": "list",
            "object": "dict",
        }
        return mapping.get(openapi_type, "Any")
