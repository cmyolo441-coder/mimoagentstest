"""Tests for the api-tools plugin."""

from __future__ import annotations

import json
import pytest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from terminal_agent.plugins.api import PluginContext

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from main import ApiToolsPlugin
from openapi import OpenAPIParser
from client_gen import ClientGenerator


SAMPLE_SPEC_V3 = {
    "openapi": "3.0.0",
    "info": {"title": "Test API", "version": "1.0.0"},
    "servers": [{"url": "https://api.example.com/v1"}],
    "paths": {
        "/users": {
            "get": {
                "operationId": "listUsers",
                "summary": "List all users",
                "tags": ["users"],
                "parameters": [
                    {"name": "limit", "in": "query", "schema": {"type": "integer"}, "description": "Max results"}
                ],
                "responses": {"200": {"description": "Success"}},
            },
            "post": {
                "operationId": "createUser",
                "summary": "Create a user",
                "tags": ["users"],
                "requestBody": {
                    "content": {"application/json": {"schema": {"type": "object"}}}
                },
                "responses": {"201": {"description": "Created"}},
            },
        },
        "/users/{id}": {
            "get": {
                "operationId": "getUser",
                "summary": "Get a user by ID",
                "tags": ["users"],
                "parameters": [
                    {"name": "id", "in": "path", "required": True, "schema": {"type": "string"}}
                ],
                "responses": {"200": {"description": "Success"}},
            }
        },
    },
}

SAMPLE_SPEC_V2 = {
    "swagger": "2.0",
    "info": {"title": "Legacy API", "version": "0.1.0"},
    "host": "legacy.example.com",
    "basePath": "/api",
    "schemes": ["https"],
    "paths": {
        "/items": {
            "get": {
                "operationId": "getItems",
                "summary": "Get items",
                "tags": ["items"],
                "parameters": [],
                "responses": {"200": {"description": "OK"}},
            }
        }
    },
}


@pytest.fixture
def plugin():
    p = ApiToolsPlugin()
    p.activate(PluginContext())
    return p


class TestApiToolsPlugin:
    def test_tools_registered(self, plugin: ApiToolsPlugin):
        names = {t["name"] for t in plugin.get_tools()}
        assert names == {"openapi_parse", "client_generate", "api_test"}

    def test_tool_schemas_valid(self, plugin: ApiToolsPlugin):
        for tool in plugin.get_tools():
            assert "name" in tool
            assert "parameters" in tool

    @pytest.mark.asyncio
    async def test_unknown_tool(self, plugin: ApiToolsPlugin):
        with pytest.raises(ValueError, match="Unknown tool"):
            await plugin.handle_tool("nonexistent", {})

    def test_cleanup(self, plugin: ApiToolsPlugin):
        plugin.cleanup()
        assert plugin._parser is None


class TestOpenAPIParser:
    @pytest.mark.asyncio
    async def test_parse_v3(self, tmp_path: Path):
        spec_file = tmp_path / "spec.json"
        spec_file.write_text(json.dumps(SAMPLE_SPEC_V3))

        parser = OpenAPIParser()
        result = await parser.parse(str(spec_file))

        assert result["version"] == "3.0.0"
        assert result["info"]["title"] == "Test API"
        assert result["base_url"] == "https://api.example.com/v1"
        assert len(result["endpoints"]) == 3

    @pytest.mark.asyncio
    async def test_parse_v2(self, tmp_path: Path):
        spec_file = tmp_path / "spec.json"
        spec_file.write_text(json.dumps(SAMPLE_SPEC_V2))

        parser = OpenAPIParser()
        result = await parser.parse(str(spec_file))

        assert result["version"] == "2.0"
        assert result["base_url"] == "https://legacy.example.com/api"
        assert len(result["endpoints"]) == 1

    @pytest.mark.asyncio
    async def test_parse_yaml(self, tmp_path: Path):
        import yaml
        spec_file = tmp_path / "spec.yaml"
        spec_file.write_text(yaml.dump(SAMPLE_SPEC_V3))

        parser = OpenAPIParser()
        result = await parser.parse(str(spec_file))

        assert len(result["endpoints"]) == 3

    @pytest.mark.asyncio
    async def test_filter_tag(self, tmp_path: Path):
        spec_data = {
            **SAMPLE_SPEC_V3,
            "paths": {
                **SAMPLE_SPEC_V3["paths"],
                "/health": {
                    "get": {
                        "operationId": "healthCheck",
                        "summary": "Health check",
                        "tags": ["system"],
                        "responses": {"200": {"description": "OK"}},
                    }
                },
            },
        }
        spec_file = tmp_path / "spec.json"
        spec_file.write_text(json.dumps(spec_data))

        parser = OpenAPIParser()
        result = await parser.parse(str(spec_file), filter_tag="users")

        for ep in result["endpoints"]:
            assert "users" in ep["tags"]

    @pytest.mark.asyncio
    async def test_file_not_found(self):
        parser = OpenAPIParser()
        with pytest.raises(FileNotFoundError):
            await parser.parse("/nonexistent/spec.json")


class TestClientGenerator:
    @pytest.mark.asyncio
    async def test_generate(self, tmp_path: Path):
        spec_file = tmp_path / "spec.json"
        spec_file.write_text(json.dumps(SAMPLE_SPEC_V3))

        parser = OpenAPIParser()
        spec = await parser.parse(str(spec_file))

        output_dir = tmp_path / "generated"
        gen = ClientGenerator()
        result = await gen.generate(spec, output_dir=str(output_dir), client_name="TestClient")

        assert result["endpoint_count"] == 3
        assert result["client_name"] == "TestClient"
        assert len(result["files"]) == 3

        client_file = Path(result["files"][0])
        assert client_file.exists()
        code = client_file.read_text()
        assert "class TestClient" in code
        assert "async def" in code

    @pytest.mark.asyncio
    async def test_generate_method_names(self, tmp_path: Path):
        spec_file = tmp_path / "spec.json"
        spec_file.write_text(json.dumps(SAMPLE_SPEC_V3))

        parser = OpenAPIParser()
        spec = await parser.parse(str(spec_file))

        gen = ClientGenerator()
        result = await gen.generate(spec, output_dir=str(tmp_path / "gen"))
        code = Path(result["files"][0]).read_text()

        assert "list_users" in code
        assert "create_user" in code
        assert "get_user" in code
