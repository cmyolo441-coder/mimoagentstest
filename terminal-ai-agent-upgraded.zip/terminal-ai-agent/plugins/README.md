# Terminal Agent Plugins

Official plugin packages for Terminal Agent. Each plugin extends the agent with domain-specific tools and capabilities.

## Available Plugins

| Plugin | Description | Tools |
|--------|-------------|-------|
| [example-plugin](example-plugin/) | Reference implementation for plugin developers | `echo`, `add_numbers` |
| [web-tools](web-tools/) | Web scraping and browser automation | `web_scrape`, `browser_navigate`, `browser_click`, `browser_screenshot` |
| [api-tools](api-tools/) | API client generation and testing | `openapi_parse`, `client_generate`, `api_test` |
| [cloud-tools](cloud-tools/) | Cloud resource management (AWS, GCP, Azure) | `aws_cli`, `gcp_cli`, `azure_cli` |
| [security-tools](security-tools/) | Security scanning and auditing | `vulnerability_scan`, `dependency_audit`, `secret_scan` |
| [mobile-tools](mobile-tools/) | Mobile development tools (Android, iOS) | `android_build`, `ios_build`, `device_deploy` |
| [data-tools](data-tools/) | Data processing (CSV, JSON, Parquet, Excel) | `csv_process`, `json_transform`, `parquet_read`, `excel_convert` |
| [monitoring-tools](monitoring-tools/) | Monitoring and observability (Prometheus, Grafana) | `prometheus_query`, `grafana_dashboard`, `alert_check` |

## Quick Start

```bash
# List available plugins
terminal-agent plugins list

# Install a plugin
terminal-agent plugins install web-tools

# Enable a plugin
terminal-agent plugins enable web-tools

# Validate a plugin
terminal-agent plugins validate web-tools
```

## Plugin Structure

Each plugin follows this standard layout:

```
my-plugin/
├── manifest.toml        # Metadata and configuration
├── __init__.py          # Package initialization
├── main.py              # Entry point (PluginBase subclass)
├── <modules>.py         # Implementation modules
├── tests/
│   └── test_my_plugin.py
└── README.md
```

## Development

See the [example-plugin](example-plugin/) for a complete reference implementation. Key points:

1. Subclass `PluginBase` or `SimplePlugin` from `terminal_agent.plugins.api`
2. Implement `activate()` for initialization
3. Return tool definitions from `get_tools()`
4. Return hook handlers from `get_hooks()`
5. Clean up resources in `cleanup()`

## Testing

```bash
# Run tests for a specific plugin
cd plugins/web-tools && python -m pytest tests/ -v

# Run all plugin tests
for plugin in plugins/*/; do
    cd "$plugin" && python -m pytest tests/ -v && cd -
done
```

## Configuration

Plugins are configured in `~/.terminal-agent/config.toml`:

```toml
[plugins.web-tools]
timeout = 30
max_results = 100
user_agent = "TerminalAgent/1.0"

[plugins.cloud-tools]
aws_profile = "default"
gcp_project = "my-project"
azure_subscription = "..."
```
