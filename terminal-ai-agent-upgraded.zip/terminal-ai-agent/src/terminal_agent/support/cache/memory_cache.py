"""In-memory cache with TTL and eviction policy support.

Fastest cache tier — data lives in process memory and is lost on
restart.  Supports per-entry TTL, maximum size enforcement via
pluggable eviction policies, and thread-safe operations.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any

from terminal_agent.support.cache.eviction import (
    EvictionPolicy,
    LRUEviction,
    create_eviction_policy,
)

logger = logging.getLogger("terminal_agent.support.cache.memory_cache")


class _CacheEntry:
    """Internal wrapper holding value + metadata."""

    __slots__ = ("value", "expires_at", "size_bytes", "created_at", "access_count")

    def __init__(self, value: Any, ttl: float | None, size_bytes: int = 0) -> None:
        self.value = value
        self.expires_at = (time.monotonic() + ttl) if ttl else None
        self.size_bytes = size_bytes
        self.created_at = time.monotonic()
        self.access_count = 0

    @property
    def is_expired(self) -> bool:
        return self.expires_at is not None and time.monotonic() >= self.expires_at


class MemoryCache:
    """Thread-safe in-memory cache.

    Usage::

        cache = MemoryCache(max_size=500, eviction="lru")
        cache.set("key1", {"data": 42}, ttl=60)
        value = cache.get("key1")
    """

    def __init__(
        self,
        max_size: int = 1000,
        default_ttl: float | None = None,
        eviction: str | EvictionPolicy = "lru",
    ) -> None:
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._store: dict[str, _CacheEntry] = {}
        self._eviction: EvictionPolicy = (
            eviction if isinstance(eviction, EvictionPolicy)
            else create_eviction_policy(eviction)
        )
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0

    # ── Core operations ────────────────────────────────────────────────

    def get(self, key: str) -> Any | None:
        """Return cached value or ``None`` on miss/expiry."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._misses += 1
                return None
            if entry.is_expired:
                self._remove(key)
                self._misses += 1
                return None
            entry.access_count += 1
            self._eviction.record_access(key)
            self._hits += 1
            return entry.value

    def set(self, key: str, value: Any, ttl: float | None = None) -> None:
        """Store *value* under *key* with optional TTL override."""
        size_bytes = self._estimate_size(value)
        with self._lock:
            # If key exists, just update
            if key in self._store:
                self._store[key] = _CacheEntry(value, ttl or self._default_ttl, size_bytes)
                self._eviction.record_access(key)
                return
            # Evict if at capacity
            while len(self._store) >= self._max_size:
                evict_key = self._eviction.evict()
                if evict_key is None:
                    break
                self._store.pop(evict_key, None)
            self._store[key] = _CacheEntry(value, ttl or self._default_ttl, size_bytes)
            self._eviction.record_insert(key)

    def delete(self, key: str) -> bool:
        """Remove *key* from cache.  Returns True if it existed."""
        with self._lock:
            if key in self._store:
                self._remove(key)
                return True
            return False

    def has(self, key: str) -> bool:
        """Check if *key* exists and is not expired (without updating stats)."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return False
            if entry.is_expired:
                self._remove(key)
                return False
            return True

    def clear(self) -> None:
        """Remove all entries."""
        with self._lock:
            self._store.clear()
            self._eviction.clear()

    # ── Bulk ───────────────────────────────────────────────────────────

    def get_many(self, keys: list[str]) -> dict[str, Any]:
        """Return a dict of key→value for all hits."""
        result: dict[str, Any] = {}
        for key in keys:
            value = self.get(key)
            if value is not None:
                result[key] = value
        return result

    def set_many(self, items: dict[str, Any], ttl: float | None = None) -> None:
        """Store multiple key-value pairs."""
        for key, value in items.items():
            self.set(key, value, ttl)

    def delete_many(self, keys: list[str]) -> int:
        """Delete multiple keys.  Returns count of deleted entries."""
        return sum(1 for key in keys if self.delete(key))

    # ── Stats ──────────────────────────────────────────────────────────

    @property
    def size(self) -> int:
        """Current number of entries."""
        return len(self._store)

    @property
    def hit_rate(self) -> float:
        """Cache hit rate as a fraction [0.0, 1.0]."""
        total = self._hits + self._misses
        return self._hits / total if total else 0.0

    def stats(self) -> dict[str, Any]:
        """Return cache statistics."""
        with self._lock:
            return {
                "size": len(self._store),
                "max_size": self._max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self.hit_rate,
                "eviction_policy": type(self._eviction).__name__,
            }

    # ── Internals ──────────────────────────────────────────────────────

    def _remove(self, key: str) -> None:
        """Remove a key from store and eviction tracker (caller must hold lock)."""
        self._store.pop(key, None)
        self._eviction.remove(key)

    @staticmethod
    def _estimate_size(value: Any) -> int:
        """Rough byte estimate for memory accounting."""
        if isinstance(value, (str, bytes)):
            return len(value)
        if isinstance(value, (int, float)):
            return 8
        try:
            return len(str(value))
        except Exception:
            return 0

    def __repr__(self) -> str:
        return (
            f"MemoryCache(size={len(self._store)}, "
            f"max={self._max_size}, hit_rate={self.hit_rate:.1%})"
        )
