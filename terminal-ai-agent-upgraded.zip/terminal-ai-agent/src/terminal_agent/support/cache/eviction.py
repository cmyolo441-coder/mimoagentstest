"""Eviction strategies for cache stores.

Implements LRU (Least Recently Used), LFU (Least Frequently Used),
and FIFO (First In First Out) eviction policies.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from collections import OrderedDict
from typing import Any


class EvictionPolicy(ABC):
    """Base class for cache eviction policies."""

    @abstractmethod
    def record_access(self, key: str) -> None:
        """Record that *key* was accessed (read or write)."""

    @abstractmethod
    def record_insert(self, key: str) -> None:
        """Record that *key* was inserted."""

    @abstractmethod
    def evict(self) -> str | None:
        """Return the key that should be evicted, or None if empty."""

    @abstractmethod
    def remove(self, key: str) -> None:
        """Remove *key* from tracking (e.g. explicit delete)."""

    @abstractmethod
    def clear(self) -> None:
        """Reset all tracking state."""

    @abstractmethod
    def keys(self) -> list[str]:
        """Return all tracked keys in eviction order (evict-first last)."""


class LRUEviction(EvictionPolicy):
    """Least Recently Used eviction.

    Tracks access order via an ``OrderedDict``; the least-recently
    touched key is at the front and evicted first.
    """

    def __init__(self) -> None:
        self._order: OrderedDict[str, None] = OrderedDict()

    def record_access(self, key: str) -> None:
        if key in self._order:
            self._order.move_to_end(key)
        else:
            self._order[key] = None

    def record_insert(self, key: str) -> None:
        self._order[key] = None
        self._order.move_to_end(key)

    def evict(self) -> str | None:
        if not self._order:
            return None
        key, _ = self._order.popitem(last=False)
        return key

    def remove(self, key: str) -> None:
        self._order.pop(key, None)

    def clear(self) -> None:
        self._order.clear()

    def keys(self) -> list[str]:
        return list(self._order.keys())


class LFUEviction(EvictionPolicy):
    """Least Frequently Used eviction.

    Ties are broken by insertion order (oldest evicted first).
    """

    def __init__(self) -> None:
        self._freq: dict[str, int] = {}
        self._insert_order: list[str] = []

    def record_access(self, key: str) -> None:
        self._freq[key] = self._freq.get(key, 0) + 1

    def record_insert(self, key: str) -> None:
        self._freq[key] = self._freq.get(key, 0) + 1
        self._insert_order.append(key)

    def evict(self) -> str | None:
        if not self._freq:
            return None
        # Find the key with the lowest frequency, breaking ties by age
        min_freq = min(self._freq.values())
        for key in self._insert_order:
            if key in self._freq and self._freq[key] == min_freq:
                self.remove(key)
                return key
        return None

    def remove(self, key: str) -> None:
        self._freq.pop(key, None)
        try:
            self._insert_order.remove(key)
        except ValueError:
            pass

    def clear(self) -> None:
        self._freq.clear()
        self._insert_order.clear()

    def keys(self) -> list[str]:
        return [k for k in self._insert_order if k in self._freq]


class FIFOEviction(EvictionPolicy):
    """First In, First Out eviction.

    Oldest entry is evicted regardless of access frequency.
    """

    def __init__(self) -> None:
        self._queue: OrderedDict[str, None] = OrderedDict()

    def record_access(self, key: str) -> None:
        # FIFO does not reorder on access
        if key not in self._queue:
            self._queue[key] = None

    def record_insert(self, key: str) -> None:
        self._queue[key] = None

    def evict(self) -> str | None:
        if not self._queue:
            return None
        key, _ = self._queue.popitem(last=False)
        return key

    def remove(self, key: str) -> None:
        self._queue.pop(key, None)

    def clear(self) -> None:
        self._queue.clear()

    def keys(self) -> list[str]:
        return list(self._queue.keys())


# Factory
_EVICTION_POLICIES: dict[str, type[EvictionPolicy]] = {
    "lru": LRUEviction,
    "lfu": LFUEviction,
    "fifo": FIFOEviction,
}


def create_eviction_policy(name: str) -> EvictionPolicy:
    """Create an eviction policy by name.

    Raises:
        ValueError: If *name* is not a known policy.
    """
    cls = _EVICTION_POLICIES.get(name.lower())
    if cls is None:
        available = ", ".join(_EVICTION_POLICIES)
        raise ValueError(f"Unknown eviction policy '{name}'. Available: {available}")
    return cls()
