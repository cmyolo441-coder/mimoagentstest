"""Disk-based cache with TTL, size limits, and LRU eviction.

Persists cached data to the filesystem so it survives process
restarts.  Slower than MemoryCache but much larger capacity.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Any

from terminal_agent.constants import GLOBAL_CACHE_DIR
from terminal_agent.exceptions import PersistenceError

logger = logging.getLogger("terminal_agent.support.cache.disk_cache")

# Metadata file stored alongside each cache entry
_META_SUFFIX = ".meta"


class DiskCache:
    """File-system-backed cache.

    Each entry is stored as two files: ``<key_hash>.dat`` (the value,
    pickled as JSON) and ``<key_hash>.meta`` (TTL and access metadata).

    Usage::

        cache = DiskCache(max_size_mb=500)
        cache.set("key1", {"hello": "world"}, ttl=3600)
        value = cache.get("key1")
    """

    def __init__(
        self,
        cache_dir: Path | str | None = None,
        max_size_mb: int = 500,
        default_ttl: float | None = None,
    ) -> None:
        self._dir = Path(cache_dir) if cache_dir else GLOBAL_CACHE_DIR / "disk"
        self._dir.mkdir(parents=True, exist_ok=True)
        self._max_bytes = max_size_mb * 1024 * 1024
        self._default_ttl = default_ttl
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0

    # ── Core ───────────────────────────────────────────────────────────

    def get(self, key: str) -> Any | None:
        """Retrieve a cached value (returns None on miss or expiry)."""
        path, meta_path = self._paths(key)
        with self._lock:
            if not path.exists():
                self._misses += 1
                return None
            meta = self._read_meta(meta_path)
            if meta and meta.get("expires_at") and time.time() >= meta["expires_at"]:
                self._delete_files(path, meta_path)
                self._misses += 1
                return None
            # Update access time
            if meta:
                meta["last_access"] = time.time()
                meta["access_count"] = meta.get("access_count", 0) + 1
                self._write_meta(meta_path, meta)
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    value = json.load(fh)
                self._hits += 1
                return value
            except (OSError, json.JSONDecodeError) as exc:
                logger.warning("Failed to read cache entry %s: %s", key, exc)
                self._misses += 1
                return None

    def set(self, key: str, value: Any, ttl: float | None = None) -> None:
        """Store *value* under *key*."""
        path, meta_path = self._paths(key)
        effective_ttl = ttl if ttl is not None else self._default_ttl
        with self._lock:
            try:
                data = json.dumps(value, default=str, ensure_ascii=False)
            except (TypeError, ValueError) as exc:
                raise PersistenceError(f"Cannot serialize value for key '{key}': {exc}") from exc
            # Write data
            try:
                with open(path, "w", encoding="utf-8") as fh:
                    fh.write(data)
            except OSError as exc:
                raise PersistenceError(f"Failed to write cache entry: {exc}") from exc
            # Write metadata
            meta = {
                "key": key,
                "size_bytes": len(data.encode("utf-8")),
                "created_at": time.time(),
                "last_access": time.time(),
                "access_count": 0,
                "expires_at": (time.time() + effective_ttl) if effective_ttl else None,
            }
            self._write_meta(meta_path, meta)
            # Enforce size limit
            self._evict_if_needed()

    def delete(self, key: str) -> bool:
        """Remove a key.  Returns True if it existed."""
        path, meta_path = self._paths(key)
        with self._lock:
            if path.exists():
                self._delete_files(path, meta_path)
                return True
            return False

    def has(self, key: str) -> bool:
        """Check if key exists and is not expired."""
        path, meta_path = self._paths(key)
        with self._lock:
            if not path.exists():
                return False
            meta = self._read_meta(meta_path)
            if meta and meta.get("expires_at") and time.time() >= meta["expires_at"]:
                self._delete_files(path, meta_path)
                return False
            return True

    def clear(self) -> int:
        """Remove all cache entries.  Returns count removed."""
        with self._lock:
            removed = 0
            for f in self._dir.iterdir():
                if f.is_file():
                    f.unlink()
                    removed += 1
            return removed

    # ── Stats ──────────────────────────────────────────────────────────

    def stats(self) -> dict[str, Any]:
        """Return cache statistics."""
        with self._lock:
            total_size = 0
            count = 0
            for f in self._dir.iterdir():
                if f.is_file() and not f.name.endswith(_META_SUFFIX):
                    total_size += f.stat().st_size
                    count += 1
            return {
                "entries": count,
                "size_bytes": total_size,
                "max_bytes": self._max_bytes,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self._hits / (self._hits + self._misses) if (self._hits + self._misses) else 0.0,
            }

    # ── Internals ──────────────────────────────────────────────────────

    def _paths(self, key: str) -> tuple[Path, Path]:
        """Map a key to its data and metadata file paths."""
        h = hashlib.sha256(key.encode("utf-8")).hexdigest()[:24]
        base = self._dir / h
        return base.with_suffix(".dat"), base.with_suffix(".dat" + _META_SUFFIX)

    def _read_meta(self, meta_path: Path) -> dict[str, Any] | None:
        if not meta_path.exists():
            return None
        try:
            with open(meta_path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (OSError, json.JSONDecodeError):
            return None

    def _write_meta(self, meta_path: Path, meta: dict[str, Any]) -> None:
        try:
            with open(meta_path, "w", encoding="utf-8") as fh:
                json.dump(meta, fh)
        except OSError as exc:
            logger.warning("Failed to write meta %s: %s", meta_path, exc)

    @staticmethod
    def _delete_files(data_path: Path, meta_path: Path) -> None:
        data_path.unlink(missing_ok=True)
        meta_path.unlink(missing_ok=True)

    def _evict_if_needed(self) -> None:
        """Evict oldest-accessed entries until we're under the size limit."""
        entries: list[tuple[float, Path, Path]] = []
        for f in self._dir.iterdir():
            if f.is_file() and not f.name.endswith(_META_SUFFIX):
                meta_path = f.with_suffix(f.suffix + _META_SUFFIX)
                meta = self._read_meta(meta_path)
                last_access = meta.get("last_access", 0) if meta else 0
                entries.append((last_access, f, meta_path))
        total = sum(f.stat().st_size for _, f, _ in entries)
        if total <= self._max_bytes:
            return
        # Sort oldest first
        entries.sort(key=lambda e: e[0])
        for _, data_path, meta_path in entries:
            if total <= self._max_bytes:
                break
            size = data_path.stat().st_size
            self._delete_files(data_path, meta_path)
            total -= size

    def __repr__(self) -> str:
        return f"DiskCache(dir={self._dir}, max_mb={self._max_bytes // (1024*1024)})"
