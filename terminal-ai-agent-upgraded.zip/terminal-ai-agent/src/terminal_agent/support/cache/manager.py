"""Cache manager: unified interface over all cache tiers.

Provides a single facade that coordinates MemoryCache, DiskCache,
and DatabaseCache with automatic tier promotion/demotion, unified
invalidation, and warming.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.support.cache.memory_cache import MemoryCache
from terminal_agent.support.cache.disk_cache import DiskCache
from terminal_agent.support.cache.database_cache import DatabaseCache
from terminal_agent.support.cache.key_generator import KeyGenerator
from terminal_agent.support.cache.invalidation import InvalidationManager
from terminal_agent.support.cache.warming import CacheWarmer
from terminal_agent.support.persistence.database import Database

logger = logging.getLogger("terminal_agent.support.cache.manager")


class CacheManager:
    """Unified multi-tier cache.

    Read order: Memory → Disk → Database (returns on first hit).
    Writes propagate to all tiers.

    Usage::

        db = Database()
        db.initialize()
        cache = CacheManager(database=db)
        cache.set("key", {"data": 42}, ttl=3600)
        value = cache.get("key")
    """

    def __init__(
        self,
        database: Database | None = None,
        memory_max_size: int = 1000,
        disk_max_size_mb: int = 500,
        default_ttl: float | None = 3600.0,
        eviction: str = "lru",
    ) -> None:
        # ── Tiers ──────────────────────────────────────────────────────
        self._memory = MemoryCache(
            max_size=memory_max_size,
            default_ttl=default_ttl,
            eviction=eviction,
        )
        self._disk = DiskCache(max_size_mb=disk_max_size_mb, default_ttl=default_ttl)
        self._database = DatabaseCache(database, default_ttl=default_ttl) if database else None

        # ── Cross-cutting ──────────────────────────────────────────────
        self._key_gen = KeyGenerator()
        self._invalidation = InvalidationManager()
        self._invalidation.register_cache(self._memory)
        self._invalidation.register_cache(self._disk)
        if self._database:
            self._invalidation.register_cache(self._database)
        self._warmer = CacheWarmer(cache=self)

    # ── Properties ─────────────────────────────────────────────────────

    @property
    def key_generator(self) -> KeyGenerator:
        """Access the key generator for building cache keys."""
        return self._key_gen

    @property
    def invalidation(self) -> InvalidationManager:
        """Access the invalidation manager."""
        return self._invalidation

    @property
    def warmer(self) -> CacheWarmer:
        """Access the cache warmer."""
        return self._warmer

    @property
    def memory(self) -> MemoryCache:
        """Direct access to the memory cache tier."""
        return self._memory

    @property
    def disk(self) -> DiskCache:
        """Direct access to the disk cache tier."""
        return self._disk

    @property
    def database(self) -> DatabaseCache | None:
        """Direct access to the database cache tier (may be None)."""
        return self._database

    # ── Core operations ────────────────────────────────────────────────

    def get(self, key: str) -> Any | None:
        """Retrieve from the fastest available tier (promotes on hit)."""
        # L1: Memory
        value = self._memory.get(key)
        if value is not None:
            return value

        # L2: Disk
        value = self._disk.get(key)
        if value is not None:
            # Promote to memory
            self._memory.set(key, value)
            return value

        # L3: Database
        if self._database:
            value = self._database.get(key)
            if value is not None:
                # Promote to memory + disk
                self._memory.set(key, value)
                self._disk.set(key, value)
                return value

        return None

    def set(
        self,
        key: str,
        value: Any,
        ttl: float | None = None,
        *,
        tags: list[str] | None = None,
        tiers: str = "all",
    ) -> None:
        """Store in all cache tiers (or a subset).

        Args:
            key: Cache key.
            value: Value to cache.
            ttl: Time-to-live override.
            tags: Tags for the database tier.
            tiers: "all", "memory", "disk", "database", or comma-separated.
        """
        target_tiers = self._parse_tiers(tiers)
        if "memory" in target_tiers:
            self._memory.set(key, value, ttl)
        if "disk" in target_tiers:
            self._disk.set(key, value, ttl)
        if "database" in target_tiers and self._database:
            self._database.set(key, value, ttl, tags=tags)

    def delete(self, key: str) -> bool:
        """Delete from all tiers."""
        removed = False
        if self._memory.delete(key):
            removed = True
        if self._disk.delete(key):
            removed = True
        if self._database and self._database.delete(key):
            removed = True
        return removed

    def has(self, key: str) -> bool:
        """Check if key exists in any tier."""
        return self._memory.has(key) or self._disk.has(key) or (
            self._database.has(key) if self._database else False
        )

    def clear(self) -> None:
        """Clear all tiers."""
        self._memory.clear()
        self._disk.clear()
        if self._database:
            self._database.clear()

    # ── Stats ──────────────────────────────────────────────────────────

    def stats(self) -> dict[str, Any]:
        """Aggregated statistics across all tiers."""
        result: dict[str, Any] = {
            "memory": self._memory.stats(),
            "disk": self._disk.stats(),
        }
        if self._database:
            result["database"] = self._database.stats()
        return result

    # ── Lifecycle ──────────────────────────────────────────────────────

    def cleanup(self) -> None:
        """Run maintenance: expire stale entries, evict if over limits."""
        if self._database:
            expired = self._database.cleanup_expired()
            if expired:
                logger.info("Cleaned up %d expired database cache entries", expired)

    def shutdown(self) -> None:
        """Graceful shutdown of warming loop and caches."""
        self._warmer.stop()

    # ── Internals ──────────────────────────────────────────────────────

    @staticmethod
    def _parse_tiers(tiers: str) -> set[str]:
        if tiers == "all":
            return {"memory", "disk", "database"}
        return {t.strip() for t in tiers.split(",")}

    def __repr__(self) -> str:
        return (
            f"CacheManager(memory={self._memory!r}, disk={self._disk!r}, "
            f"database={self._database!r})"
        )
