"""Embedding service for the vector store subsystem.

Provides a unified interface for generating text embeddings,
separate from the memory engine's embedder (which adds caching
and memory-specific logic). This service is a lower-level API
for the vector store backends.
"""

from __future__ import annotations

import hashlib
import logging
from typing import Any

logger = logging.getLogger("terminal_agent.support.vector_store.embedding")


class EmbeddingService:
    """Generates text embeddings for vector storage.

    Supports multiple providers:
        - "openai": OpenAI text-embedding-3-small/large
        - "local": Hash-based pseudo-embeddings (fallback)
        - "sentence-transformers": Local transformer models

    Args:
        model: Embedding model identifier.
        dimensions: Output vector dimensions.
    """

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        dimensions: int = 1536,
    ) -> None:
        self._model = model
        self._dimensions = dimensions
        self._provider = self._detect_provider(model)
        self._client: Any = None

        logger.info("EmbeddingService: model=%s, dims=%d, provider=%s",
                     model, dimensions, self._provider)

    @staticmethod
    def _detect_provider(model: str) -> str:
        if model.startswith("text-embedding"):
            return "openai"
        if model.startswith("all-") or "sentence-transformers" in model:
            return "sentence-transformers"
        return "local"

    def embed(self, text: str) -> list[float]:
        """Generate embedding for a single text."""
        if not text.strip():
            return [0.0] * self._dimensions

        if self._provider == "openai":
            return self._embed_openai(text)
        elif self._provider == "sentence-transformers":
            return self._embed_st(text)
        return self._embed_local(text)

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts."""
        if not texts:
            return []
        if self._provider == "openai":
            return self._embed_openai_batch(texts)
        return [self.embed(t) for t in texts]

    def _embed_openai(self, text: str) -> list[float]:
        try:
            if self._client is None:
                import openai
                self._client = openai.OpenAI()
            response = self._client.embeddings.create(
                model=self._model,
                input=text,
                dimensions=self._dimensions,
            )
            return response.data[0].embedding
        except Exception as e:
            logger.warning("OpenAI embedding failed (%s), using local fallback", e)
            return self._embed_local(text)

    def _embed_openai_batch(self, texts: list[str]) -> list[list[float]]:
        try:
            if self._client is None:
                import openai
                self._client = openai.OpenAI()
            all_vectors: list[list[float]] = []
            for i in range(0, len(texts), 2048):
                batch = texts[i:i + 2048]
                response = self._client.embeddings.create(
                    model=self._model,
                    input=batch,
                    dimensions=self._dimensions,
                )
                all_vectors.extend([d.embedding for d in response.data])
            return all_vectors
        except Exception as e:
            logger.warning("OpenAI batch embedding failed (%s), using sequential", e)
            return [self._embed_openai(t) for t in texts]

    def _embed_st(self, text: str) -> list[float]:
        try:
            if not hasattr(self, "_st_model"):
                from sentence_transformers import SentenceTransformer
                self._st_model = SentenceTransformer(self._model)
            vector = self._st_model.encode(text, normalize_embeddings=True)
            return vector.tolist()
        except ImportError:
            logger.warning("sentence-transformers not installed, using local fallback")
            return self._embed_local(text)

    def _embed_local(self, text: str) -> list[float]:
        """Hash-based pseudo-embedding (deterministic, zero-dependency)."""
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        vector: list[float] = []
        seed_text = text
        while len(vector) < self._dimensions:
            h = hashlib.sha256(seed_text.encode("utf-8")).hexdigest()
            for i in range(0, len(h), 2):
                val = (int(h[i:i + 2], 16) / 127.5) - 1.0
                vector.append(val)
                if len(vector) >= self._dimensions:
                    break
            seed_text += "_pad"

        vector = vector[:self._dimensions]
        mag = sum(v * v for v in vector) ** 0.5
        if mag > 0:
            vector = [v / mag for v in vector]
        return vector

    @property
    def dimensions(self) -> int:
        return self._dimensions

    @property
    def model(self) -> str:
        return self._model
