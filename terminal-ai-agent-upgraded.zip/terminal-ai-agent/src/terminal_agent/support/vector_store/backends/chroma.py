"""ChromaDB vector store backend.

ChromaDB is the default backend — it runs locally, requires no external
services, and provides good performance for moderate-scale use cases.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("terminal_agent.support.vector_store.backends.chroma")


class Backend:
    """ChromaDB vector store backend.

    Args:
        path: Directory path for persistent storage. None = in-memory.
        collection: Default collection name.
    """

    def __init__(
        self,
        path: str | None = None,
        collection: str = "memories",
        **kwargs: Any,
    ) -> None:
        try:
            import chromadb
            from chromadb.config import Settings
        except ImportError:
            raise ImportError(
                "chromadb is required for the ChromaDB backend. "
                "Install with: pip install chromadb"
            )

        if path:
            self._client = chromadb.PersistentClient(
                path=path,
                settings=Settings(anonymized_telemetry=False),
            )
        else:
            self._client = chromadb.Client(
                settings=Settings(anonymized_telemetry=False),
            )

        self._collection = self._client.get_or_create_collection(
            name=collection,
            metadata={"hnsw:space": "cosine"},
        )
        logger.info("ChromaDB backend initialized (path=%s, collection=%s)", path, collection)

    def upsert(
        self,
        id: str,
        vector: list[float],
        metadata: dict[str, Any] | None = None,
        document: str = "",
    ) -> None:
        """Insert or update a vector entry."""
        self._collection.upsert(
            ids=[id],
            embeddings=[vector],
            metadatas=[metadata or {}],
            documents=[document],
        )

    def query(
        self,
        vector: list[float],
        top_k: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Search for similar vectors."""
        kwargs: dict[str, Any] = {
            "query_embeddings": [vector],
            "n_results": top_k,
        }
        if where:
            kwargs["where"] = where

        results = self._collection.query(**kwargs)

        # Flatten results (ChromaDB returns nested lists)
        items: list[dict[str, Any]] = []
        if results and results["ids"]:
            for i, doc_id in enumerate(results["ids"][0]):
                item: dict[str, Any] = {"id": doc_id}
                if results.get("documents") and results["documents"][0]:
                    item["document"] = results["documents"][0][i]
                if results.get("metadatas") and results["metadatas"][0]:
                    item["metadata"] = results["metadatas"][0][i]
                if results.get("distances") and results["distances"][0]:
                    # ChromaDB returns distances; convert to similarity
                    distance = results["distances"][0][i]
                    item["score"] = max(0.0, 1.0 - distance)
                items.append(item)

        return items

    def get(self, ids: list[str]) -> list[dict[str, Any]]:
        """Get entries by ID."""
        results = self._collection.get(ids=ids, include=["documents", "metadatas"])
        items: list[dict[str, Any]] = []
        if results and results["ids"]:
            for i, doc_id in enumerate(results["ids"]):
                item: dict[str, Any] = {"id": doc_id}
                if results.get("documents"):
                    item["document"] = results["documents"][i]
                if results.get("metadatas"):
                    item["metadata"] = results["metadatas"][i]
                items.append(item)
        return items

    def update_metadata(self, id: str, metadata: dict[str, Any]) -> None:
        """Update metadata for an existing entry."""
        self._collection.update(ids=[id], metadatas=[metadata])

    def delete(self, ids: list[str]) -> None:
        """Delete entries by ID."""
        self._collection.delete(ids=ids)

    def count(self) -> int:
        """Get total number of entries."""
        return self._collection.count()

    def persist(self) -> None:
        """Persist data (ChromaDB PersistentClient auto-persists)."""
        pass

    def close(self) -> None:
        """Release resources."""
        self._client = None
        self._collection = None

    def health(self) -> dict[str, Any]:
        """Health check info."""
        return {"collection": self._collection.name, "count": self.count()}
