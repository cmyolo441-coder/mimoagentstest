"""FAISS vector store backend.

FAISS (Facebook AI Similarity Search) provides high-performance
similarity search for large-scale vector datasets. Runs entirely
locally with no external dependencies beyond the faiss-cpu package.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger("terminal_agent.support.vector_store.backends.faiss")


class Backend:
    """FAISS vector store backend.

    Args:
        path: Directory for persistent storage. None = in-memory only.
        dimensions: Vector dimensions (required for index creation).
    """

    def __init__(
        self,
        path: str | None = None,
        dimensions: int = 1536,
        **kwargs: Any,
    ) -> None:
        try:
            import faiss
            import numpy as np
        except ImportError:
            raise ImportError(
                "faiss-cpu and numpy are required for the FAISS backend. "
                "Install with: pip install faiss-cpu numpy"
            )

        self._faiss = faiss
        self._np = np
        self._dimensions = dimensions
        self._path = Path(path) if path else None

        # Metadata stored separately (FAISS only stores vectors)
        self._metadata: dict[str, dict[str, Any]] = {}  # id -> {metadata, document}
        self._id_map: dict[int, str] = {}  # faiss_index -> id
        self._reverse_map: dict[str, int] = {}  # id -> faiss_index
        self._next_index: int = 0

        # Create or load index
        if self._path and (self._path / "index.faiss").exists():
            self._load()
        else:
            self._index = faiss.IndexFlatIP(dimensions)  # Inner product (cosine after normalization)

        logger.info("FAISS backend initialized (dims=%d, path=%s, entries=%d)",
                     dimensions, path, self._index.ntotal)

    def upsert(
        self,
        id: str,
        vector: list[float],
        metadata: dict[str, Any] | None = None,
        document: str = "",
    ) -> None:
        """Insert or update a vector entry."""
        import numpy as np

        # Normalize vector for cosine similarity
        vec = np.array([vector], dtype=np.float32)
        self._faiss.normalize_L2(vec)

        # If updating existing entry, we need to rebuild
        if id in self._reverse_map:
            old_idx = self._reverse_map[id]
            # FAISS IndexFlat doesn't support in-place update,
            # so we mark it and rebuild on next query or persist
            self._metadata[id] = {"metadata": metadata or {}, "document": document}
            # Replace vector in index (remove + add)
            self._remove_internal(id)

        # Add new entry
        idx = self._next_index
        self._next_index += 1
        self._index.add(vec)
        self._id_map[idx] = id
        self._reverse_map[id] = idx
        self._metadata[id] = {"metadata": metadata or {}, "document": document}

    def query(
        self,
        vector: list[float],
        top_k: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Search for similar vectors."""
        import numpy as np

        if self._index.ntotal == 0:
            return []

        vec = np.array([vector], dtype=np.float32)
        self._faiss.normalize_L2(vec)

        k = min(top_k, self._index.ntotal)
        distances, indices = self._index.search(vec, k)

        results: list[dict[str, Any]] = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < 0:
                continue
            entry_id = self._id_map.get(idx)
            if entry_id is None:
                continue

            meta_entry = self._metadata.get(entry_id, {})
            entry_metadata = meta_entry.get("metadata", {})

            # Apply metadata filter
            if where:
                if not self._matches_filter(entry_metadata, where):
                    continue

            results.append({
                "id": entry_id,
                "document": meta_entry.get("document", ""),
                "metadata": entry_metadata,
                "score": float(dist),  # Inner product score
            })

        return results

    def get(self, ids: list[str]) -> list[dict[str, Any]]:
        """Get entries by ID."""
        results: list[dict[str, Any]] = []
        for entry_id in ids:
            if entry_id in self._metadata:
                meta_entry = self._metadata[entry_id]
                results.append({
                    "id": entry_id,
                    "document": meta_entry.get("document", ""),
                    "metadata": meta_entry.get("metadata", {}),
                })
        return results

    def update_metadata(self, id: str, metadata: dict[str, Any]) -> None:
        """Update metadata for an existing entry."""
        if id in self._metadata:
            self._metadata[id]["metadata"].update(metadata)

    def delete(self, ids: list[str]) -> None:
        """Delete entries by ID."""
        for entry_id in ids:
            self._remove_internal(entry_id)

    def count(self) -> int:
        """Get total number of entries."""
        return len(self._metadata)

    def persist(self) -> None:
        """Save index and metadata to disk."""
        if self._path is None:
            return

        self._path.mkdir(parents=True, exist_ok=True)

        # Save FAISS index
        self._faiss.write_index(self._index, str(self._path / "index.faiss"))

        # Save metadata and mappings
        data = {
            "metadata": self._metadata,
            "id_map": {str(k): v for k, v in self._id_map.items()},
            "reverse_map": self._reverse_map,
            "next_index": self._next_index,
            "dimensions": self._dimensions,
        }
        with open(self._path / "metadata.json", "w") as f:
            json.dump(data, f)

        logger.info("FAISS index persisted to %s (%d entries)", self._path, len(self._metadata))

    def close(self) -> None:
        """Release resources."""
        self.persist()
        self._index = None

    def health(self) -> dict[str, Any]:
        return {
            "entries": self.count(),
            "dimensions": self._dimensions,
            "faiss_ntotal": self._index.ntotal if self._index else 0,
        }

    def _load(self) -> None:
        """Load index and metadata from disk."""
        import faiss as faiss_lib

        self._index = faiss_lib.read_index(str(self._path / "index.faiss"))

        meta_path = self._path / "metadata.json"
        if meta_path.exists():
            with open(meta_path) as f:
                data = json.load(f)
            self._metadata = data.get("metadata", {})
            self._id_map = {int(k): v for k, v in data.get("id_map", {}).items()}
            self._reverse_map = data.get("reverse_map", {})
            self._next_index = data.get("next_index", len(self._id_map))
            self._dimensions = data.get("dimensions", self._dimensions)

    def _remove_internal(self, entry_id: str) -> None:
        """Remove an entry from internal structures."""
        if entry_id in self._reverse_map:
            idx = self._reverse_map.pop(entry_id)
            self._id_map.pop(idx, None)
            self._metadata.pop(entry_id, None)

    @staticmethod
    def _matches_filter(metadata: dict[str, Any], where: dict[str, Any]) -> bool:
        """Check if metadata matches a filter."""
        for key, value in where.items():
            if key not in metadata:
                return False
            if isinstance(value, dict):
                op_value = value.get("$in")
                if op_value and metadata[key] not in op_value:
                    return False
            elif metadata[key] != value:
                return False
        return True
