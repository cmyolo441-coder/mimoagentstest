"""Qdrant vector store backend.

Qdrant supports both local (embedded) and cloud deployments.
It provides rich filtering, payload support, and good performance.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

logger = logging.getLogger("terminal_agent.support.vector_store.backends.qdrant")


class Backend:
    """Qdrant vector store backend.

    Args:
        path: Local storage path (for embedded mode). None = connect to server.
        url: Qdrant server URL (e.g., "http://localhost:6333").
        api_key: API key for Qdrant cloud.
        collection: Collection name.
        dimensions: Vector dimensions.
    """

    def __init__(
        self,
        path: str | None = None,
        url: str | None = None,
        api_key: str | None = None,
        collection: str = "memories",
        dimensions: int = 1536,
        **kwargs: Any,
    ) -> None:
        try:
            from qdrant_client import QdrantClient
            from qdrant_client.models import Distance, VectorParams
        except ImportError:
            raise ImportError(
                "qdrant-client is required for the Qdrant backend. "
                "Install with: pip install qdrant-client"
            )

        if path:
            self._client = QdrantClient(path=path)
        elif url:
            self._client = QdrantClient(url=url, api_key=api_key)
        else:
            # Default to local embedded
            self._client = QdrantClient(path=".qdrant_data")

        self._collection = collection
        self._dimensions = dimensions

        # Create collection if it doesn't exist
        collections = [c.name for c in self._client.get_collections().collections]
        if collection not in collections:
            self._client.create_collection(
                collection_name=collection,
                vectors_config=VectorParams(
                    size=dimensions,
                    distance=Distance.COSINE,
                ),
            )
            logger.info("Created Qdrant collection: %s", collection)

        logger.info("Qdrant backend initialized (collection=%s)", collection)

    def upsert(
        self,
        id: str,
        vector: list[float],
        metadata: dict[str, Any] | None = None,
        document: str = "",
    ) -> None:
        """Insert or update a vector entry."""
        from qdrant_client.models import PointStruct

        payload = dict(metadata or {})
        if document:
            payload["document"] = document

        point = PointStruct(
            id=self._to_point_id(id),
            vector=vector,
            payload=payload,
        )
        self._client.upsert(
            collection_name=self._collection,
            points=[point],
        )

    def query(
        self,
        vector: list[float],
        top_k: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Search for similar vectors."""
        from qdrant_client.models import Filter, FieldCondition, MatchValue

        query_filter = None
        if where:
            conditions = []
            for key, value in where.items():
                if isinstance(value, dict) and "$in" in value:
                    from qdrant_client.models import MatchAny
                    conditions.append(FieldCondition(
                        key=key,
                        match=MatchAny(value=value["$in"]),
                    ))
                else:
                    conditions.append(FieldCondition(
                        key=key,
                        match=MatchValue(value=value),
                    ))
            query_filter = Filter(must=conditions)

        results = self._client.search(
            collection_name=self._collection,
            query_vector=vector,
            limit=top_k,
            query_filter=query_filter,
        )

        items: list[dict[str, Any]] = []
        for result in results:
            payload = dict(result.payload or {})
            items.append({
                "id": str(result.id),
                "document": payload.pop("document", ""),
                "metadata": payload,
                "score": result.score,
            })

        return items

    def get(self, ids: list[str]) -> list[dict[str, Any]]:
        """Get entries by ID."""
        from qdrant_client.models import PointIdsList

        points = self._client.retrieve(
            collection_name=self._collection,
            ids=[self._to_point_id(i) for i in ids],
        )

        results: list[dict[str, Any]] = []
        for point in points:
            payload = dict(point.payload or {})
            results.append({
                "id": str(point.id),
                "document": payload.pop("document", ""),
                "metadata": payload,
            })
        return results

    def update_metadata(self, id: str, metadata: dict[str, Any]) -> None:
        """Update metadata for an existing entry."""
        from qdrant_client.models import PointIdsList, PayloadSchema

        # Qdrant supports set_payload for partial updates
        self._client.set_payload(
            collection_name=self._collection,
            payload=metadata,
            points=[self._to_point_id(id)],
        )

    def delete(self, ids: list[str]) -> None:
        """Delete entries by ID."""
        from qdrant_client.models import PointIdsList

        self._client.delete(
            collection_name=self._collection,
            points_selector=PointIdsList(
                points=[self._to_point_id(i) for i in ids],
            ),
        )

    def count(self) -> int:
        """Get total number of entries."""
        info = self._client.get_collection(self._collection)
        return info.points_count or 0

    def persist(self) -> None:
        """Qdrant handles persistence automatically."""
        pass

    def close(self) -> None:
        """Release resources."""
        self._client = None

    def health(self) -> dict[str, Any]:
        """Health check."""
        try:
            info = self._client.get_collection(self._collection)
            return {"status": "ok", "points": info.points_count}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    @staticmethod
    def _to_point_id(entry_id: str) -> int | str:
        """Convert entry ID to Qdrant-compatible point ID.

        Qdrant accepts either unsigned integers or UUIDs.
        We try int first, fall back to UUID hash.
        """
        try:
            return int(entry_id)
        except ValueError:
            # Use UUID5 for deterministic string → UUID mapping
            return str(uuid.uuid5(uuid.NAMESPACE_DNS, entry_id))
