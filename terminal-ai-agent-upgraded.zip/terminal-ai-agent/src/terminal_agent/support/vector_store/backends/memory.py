"""In-memory vector store backend.

Zero-dependency backend that stores everything in Python dicts
with brute-force cosine similarity search. Suitable for development,
testing, and small datasets (<10k vectors).

This backend is also used as the automatic fallback when other
backends are unavailable (missing dependencies).
"""

from __future__ import annotations

import logging
import math
from typing import Any

logger = logging.getLogger("terminal_agent.support.vector_store.backends.memory")


class Backend:
    """In-memory vector store backend.

    No external dependencies — pure Python with brute-force search.

    Args:
        dimensions: Vector dimensions (informational for this backend).
    """

    def __init__(self, dimensions: int = 1536, **kwargs: Any) -> None:
        self._dimensions = dimensions
        self._vectors: dict[str, list[float]] = {}  # id -> vector
        self._metadata: dict[str, dict[str, Any]] = {}  # id -> {metadata, document}
        logger.info("In-memory vector store initialized")

    def upsert(
        self,
        id: str,
        vector: list[float],
        metadata: dict[str, Any] | None = None,
        document: str = "",
    ) -> None:
        """Insert or update a vector entry."""
        self._vectors[id] = vector
        self._metadata[id] = {
            "metadata": metadata or {},
            "document": document,
        }

    def query(
        self,
        vector: list[float],
        top_k: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Search for similar vectors using brute-force cosine similarity."""
        if not self._vectors:
            return []

        # Compute similarities
        scored: list[tuple[float, str]] = []
        for entry_id, entry_vector in self._vectors.items():
            # Apply filter
            if where:
                entry_meta = self._metadata.get(entry_id, {}).get("metadata", {})
                if not self._matches_filter(entry_meta, where):
                    continue

            similarity = self._cosine_similarity(vector, entry_vector)
            scored.append((similarity, entry_id))

        # Sort by similarity descending
        scored.sort(reverse=True)

        # Return top_k
        results: list[dict[str, Any]] = []
        for score, entry_id in scored[:top_k]:
            meta_entry = self._metadata.get(entry_id, {})
            results.append({
                "id": entry_id,
                "document": meta_entry.get("document", ""),
                "metadata": meta_entry.get("metadata", {}),
                "score": score,
            })

        return results

    def get(self, ids: list[str]) -> list[dict[str, Any]]:
        """Get entries by ID."""
        results: list[dict[str, Any]] = []
        for entry_id in ids:
            if entry_id in self._metadata:
                meta_entry = self._metadata[entry_id]
                results.append({
                    "id": entry_id,
                    "document": meta_entry.get("document", ""),
                    "metadata": meta_entry.get("metadata", {}),
                })
        return results

    def update_metadata(self, id: str, metadata: dict[str, Any]) -> None:
        """Update metadata for an existing entry."""
        if id in self._metadata:
            self._metadata[id]["metadata"].update(metadata)

    def delete(self, ids: list[str]) -> None:
        """Delete entries by ID."""
        for entry_id in ids:
            self._vectors.pop(entry_id, None)
            self._metadata.pop(entry_id, None)

    def count(self) -> int:
        """Get total number of entries."""
        return len(self._vectors)

    def persist(self) -> None:
        """In-memory store has nothing to persist."""
        pass

    def close(self) -> None:
        """Release resources."""
        self._vectors.clear()
        self._metadata.clear()

    def health(self) -> dict[str, Any]:
        """Health check."""
        return {"status": "ok", "entries": len(self._vectors)}

    @staticmethod
    def _cosine_similarity(a: list[float], b: list[float]) -> float:
        """Compute cosine similarity between two vectors.

        Returns value in [-1, 1]. Returns 0.0 for zero vectors.
        """
        if len(a) != len(b):
            min_len = min(len(a), len(b))
            a = a[:min_len]
            b = b[:min_len]

        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(x * x for x in b))

        if norm_a == 0 or norm_b == 0:
            return 0.0

        return dot / (norm_a * norm_b)

    @staticmethod
    def _matches_filter(metadata: dict[str, Any], where: dict[str, Any]) -> bool:
        """Check if metadata matches a where filter."""
        for key, value in where.items():
            if key not in metadata:
                return False
            if isinstance(value, dict):
                if "$in" in value:
                    if metadata[key] not in value["$in"]:
                        return False
                elif "$gt" in value:
                    if not (metadata[key] > value["$gt"]):
                        return False
                elif "$lt" in value:
                    if not (metadata[key] < value["$lt"]):
                        return False
            elif metadata[key] != value:
                return False
        return True
