"""Milvus vector store backend.

Milvus is a high-performance vector database supporting both
standalone and distributed deployments.
"""

from __future__ import annotations

import logging
import json
from typing import Any

logger = logging.getLogger("terminal_agent.support.vector_store.backends.milvus")


class Backend:
    """Milvus vector store backend.

    Args:
        host: Milvus server host.
        port: Milvus server port.
        collection: Collection name.
        dimensions: Vector dimensions.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 19530,
        collection: str = "memories",
        dimensions: int = 1536,
        **kwargs: Any,
    ) -> None:
        try:
            from pymilvus import (
                connections,
                Collection,
                FieldSchema,
                CollectionSchema,
                DataType,
                utility,
            )
        except ImportError:
            raise ImportError(
                "pymilvus is required for the Milvus backend. "
                "Install with: pip install pymilvus"
            )

        self._pymilvus = __import__("pymilvus")

        # Connect
        connections.connect(alias="default", host=host, port=port)
        self._collection_name = collection
        self._dimensions = dimensions

        # Create collection if needed
        if not utility.has_collection(collection):
            fields = [
                FieldSchema(name="id", dtype=DataType.VARCHAR, is_primary=True, max_length=64),
                FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=dimensions),
                FieldSchema(name="document", dtype=DataType.VARCHAR, max_length=65535),
                FieldSchema(name="metadata_json", dtype=DataType.VARCHAR, max_length=65535),
            ]
            schema = CollectionSchema(fields=fields)
            col = Collection(name=collection, schema=schema)
            # Create index for vector field
            col.create_index(
                field_name="vector",
                index_params={"metric_type": "COSINE", "index_type": "IVF_FLAT", "params": {"nlist": 128}},
            )
            logger.info("Created Milvus collection: %s", collection)

        self._collection = Collection(collection)
        self._collection.load()

        logger.info("Milvus backend initialized (collection=%s, host=%s:%d)", collection, host, port)

    def upsert(
        self,
        id: str,
        vector: list[float],
        metadata: dict[str, Any] | None = None,
        document: str = "",
    ) -> None:
        """Insert or update a vector entry."""
        # Check if exists → delete first (Milvus doesn't have native upsert for all versions)
        try:
            self._collection.delete(f'id == "{id}"')
        except Exception:
            pass

        self._collection.insert([
            [id],
            [vector],
            [document],
            [json.dumps(metadata or {})],
        ])
        self._collection.flush()

    def query(
        self,
        vector: list[float],
        top_k: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Search for similar vectors."""
        search_params = {"metric_type": "COSINE", "params": {"nprobe": 16}}

        expr = None
        if where:
            expr = self._build_expr(where)

        results = self._collection.search(
            data=[vector],
            anns_field="vector",
            param=search_params,
            limit=top_k,
            expr=expr,
            output_fields=["document", "metadata_json"],
        )

        items: list[dict[str, Any]] = []
        if results:
            for hit in results[0]:
                entity = hit.entity
                meta_json = entity.get("metadata_json", "{}")
                try:
                    meta = json.loads(meta_json) if isinstance(meta_json, str) else meta_json
                except (json.JSONDecodeError, TypeError):
                    meta = {}

                items.append({
                    "id": hit.id,
                    "document": entity.get("document", ""),
                    "metadata": meta,
                    "score": hit.score,
                })

        return items

    def get(self, ids: list[str]) -> list[dict[str, Any]]:
        """Get entries by ID."""
        expr = f'id in {ids!r}'
        results = self._collection.query(
            expr=expr,
            output_fields=["document", "metadata_json"],
        )

        items: list[dict[str, Any]] = []
        for row in results:
            meta_json = row.get("metadata_json", "{}")
            try:
                meta = json.loads(meta_json) if isinstance(meta_json, str) else meta_json
            except (json.JSONDecodeError, TypeError):
                meta = {}
            items.append({
                "id": row["id"],
                "document": row.get("document", ""),
                "metadata": meta,
            })
        return items

    def update_metadata(self, id: str, metadata: dict[str, Any]) -> None:
        """Update metadata for an existing entry."""
        existing = self.get([id])
        if existing:
            old_meta = existing[0].get("metadata", {})
            old_meta.update(metadata)
            # Delete + re-insert (Milvus upsert)
            try:
                self._collection.delete(f'id == "{id}"')
            except Exception:
                pass
            # Need to re-fetch vector... This is a limitation
            self._collection.insert([
                [id],
                [[0.0] * self._dimensions],  # Placeholder — caller should re-upsert
                [existing[0].get("document", "")],
                [json.dumps(old_meta)],
            ])

    def delete(self, ids: list[str]) -> None:
        """Delete entries by ID."""
        expr = f'id in {ids!r}'
        self._collection.delete(expr)

    def count(self) -> int:
        """Get total number of entries."""
        self._collection.flush()
        return self._collection.num_entities

    def persist(self) -> None:
        """Milvus handles persistence automatically."""
        self._collection.flush()

    def close(self) -> None:
        """Release resources."""
        self._collection = None
        self._pymilvus.connections.disconnect("default")

    def health(self) -> dict[str, Any]:
        """Health check."""
        try:
            self._collection.flush()
            return {"status": "ok", "num_entities": self._collection.num_entities}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    @staticmethod
    def _build_expr(where: dict[str, Any]) -> str | None:
        """Build Milvus expression from where filter."""
        parts: list[str] = []
        for key, value in where.items():
            if isinstance(value, dict) and "$in" in value:
                values_str = ", ".join(f'"{v}"' for v in value["$in"])
                parts.append(f'{key} in [{values_str}]')
            else:
                parts.append(f'{key} == "{value}"')
        return " and ".join(parts) if parts else None
