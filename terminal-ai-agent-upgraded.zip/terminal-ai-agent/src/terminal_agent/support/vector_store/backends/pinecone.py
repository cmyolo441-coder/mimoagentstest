"""Pinecone vector store backend.

Pinecone is a fully managed cloud vector database. Requires an API key
and a Pinecone account. Best for production deployments that need
serverless scaling.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("terminal_agent.support.vector_store.backends.pinecone")


class Backend:
    """Pinecone vector store backend.

    Args:
        api_key: Pinecone API key (or set PINECONE_API_KEY env var).
        index_name: Name of the Pinecone index.
        namespace: Namespace within the index.
        environment: Pinecone environment (e.g., "us-east-1-aws").
    """

    def __init__(
        self,
        api_key: str | None = None,
        index_name: str = "terminal-agent",
        namespace: str = "memories",
        environment: str | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            from pinecone import Pinecone
        except ImportError:
            raise ImportError(
                "pinecone-client is required for the Pinecone backend. "
                "Install with: pip install pinecone-client"
            )

        import os
        api_key = api_key or os.environ.get("PINECONE_API_KEY")
        if not api_key:
            raise ValueError("Pinecone API key required (set PINECONE_API_KEY or pass api_key)")

        self._pc = Pinecone(api_key=api_key)
        self._index_name = index_name
        self._namespace = namespace

        # Connect to index
        self._index = self._pc.Index(index_name)
        logger.info("Pinecone backend initialized (index=%s, namespace=%s)", index_name, namespace)

    def upsert(
        self,
        id: str,
        vector: list[float],
        metadata: dict[str, Any] | None = None,
        document: str = "",
    ) -> None:
        """Insert or update a vector entry."""
        payload: dict[str, Any] = {
            "id": id,
            "values": vector,
            "metadata": metadata or {},
        }
        if document:
            payload["metadata"]["document"] = document

        self._index.upsert(vectors=[payload], namespace=self._namespace)

    def query(
        self,
        vector: list[float],
        top_k: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Search for similar vectors."""
        kwargs: dict[str, Any] = {
            "vector": vector,
            "top_k": top_k,
            "namespace": self._namespace,
            "include_metadata": True,
        }
        if where:
            kwargs["filter"] = where

        response = self._index.query(**kwargs)

        results: list[dict[str, Any]] = []
        for match in response.get("matches", []):
            metadata = match.get("metadata", {})
            results.append({
                "id": match["id"],
                "document": metadata.pop("document", ""),
                "metadata": metadata,
                "score": match.get("score", 0.0),
            })

        return results

    def get(self, ids: list[str]) -> list[dict[str, Any]]:
        """Get entries by ID."""
        response = self._index.fetch(ids=ids, namespace=self._namespace)
        results: list[dict[str, Any]] = []
        for entry_id, data in response.get("vectors", {}).items():
            metadata = data.get("metadata", {})
            results.append({
                "id": entry_id,
                "document": metadata.pop("document", ""),
                "metadata": metadata,
            })
        return results

    def update_metadata(self, id: str, metadata: dict[str, Any]) -> None:
        """Update metadata for an existing entry."""
        # Pinecone doesn't have a direct metadata update; use upsert
        existing = self.get([id])
        if existing:
            old_meta = existing[0].get("metadata", {})
            old_meta.update(metadata)
            # Re-fetch vector values from fetch
            response = self._index.fetch(ids=[id], namespace=self._namespace)
            vectors = response.get("vectors", {})
            if id in vectors:
                self.upsert(id=id, vector=vectors[id]["values"], metadata=old_meta)

    def delete(self, ids: list[str]) -> None:
        """Delete entries by ID."""
        self._index.delete(ids=ids, namespace=self._namespace)

    def count(self) -> int:
        """Get total number of entries."""
        stats = self._index.describe_index_stats()
        namespaces = stats.get("namespaces", {})
        ns = namespaces.get(self._namespace, {})
        return ns.get("vector_count", 0)

    def persist(self) -> None:
        """Pinecone is cloud-hosted; persistence is automatic."""
        pass

    def close(self) -> None:
        """Release resources."""
        self._index = None

    def health(self) -> dict[str, Any]:
        """Health check."""
        try:
            stats = self._index.describe_index_stats()
            return {"status": "ok", "total_vectors": stats.get("total_vector_count", 0)}
        except Exception as e:
            return {"status": "error", "error": str(e)}
