"""Vector store backend implementations.

Each backend implements a standard interface:
    - upsert(id, vector, metadata, document)
    - query(vector, top_k, where) -> list[dict]
    - get(ids) -> list[dict]
    - delete(ids)
    - count() -> int
    - persist()
    - close()
"""

from typing import Protocol, Any


class VectorStoreBackend(Protocol):
    """Protocol defining the standard vector store interface."""

    def upsert(
        self,
        id: str,
        vector: list[float],
        metadata: dict[str, Any] | None = None,
        document: str = "",
    ) -> None:
        """Insert or update a vector entry."""
        ...

    def query(
        self,
        vector: list[float],
        top_k: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Search for similar vectors."""
        ...

    def get(self, ids: list[str]) -> list[dict[str, Any]]:
        """Get entries by ID."""
        ...

    def delete(self, ids: list[str]) -> None:
        """Delete entries by ID."""
        ...

    def count(self) -> int:
        """Get total number of entries."""
        ...

    def persist(self) -> None:
        """Persist data to disk."""
        ...

    def close(self) -> None:
        """Release resources."""
        ...


__all__ = ["VectorStoreBackend"]
