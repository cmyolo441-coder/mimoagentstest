"""Weaviate vector store backend.

Weaviate supports both local (embedded) and cloud deployments,
with built-in vector search and optional module-based embeddings.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("terminal_agent.support.vector_store.backends.weaviate")


class Backend:
    """Weaviate vector store backend.

    Args:
        url: Weaviate server URL (e.g., "http://localhost:8080").
        api_key: API key for Weaviate cloud.
        class_name: Weaviate class name.
        dimensions: Vector dimensions.
    """

    def __init__(
        self,
        url: str = "http://localhost:8080",
        api_key: str | None = None,
        class_name: str = "Memory",
        dimensions: int = 1536,
        **kwargs: Any,
    ) -> None:
        try:
            import weaviate
        except ImportError:
            raise ImportError(
                "weaviate-client is required for the Weaviate backend. "
                "Install with: pip install weaviate-client"
            )

        # Build client
        auth = weaviate.auth.AuthApiKey(api_key) if api_key else None
        self._client = weaviate.Client(url=url, auth_client_secret=auth)
        self._class_name = class_name
        self._dimensions = dimensions

        # Create class if it doesn't exist
        if not self._client.schema.exists(class_name):
            schema = {
                "class": class_name,
                "vectorIndexConfig": {"distance": "cosine"},
                "properties": [
                    {"name": "document", "dataType": ["text"]},
                    {"name": "category", "dataType": ["text"]},
                    {"name": "metadata_json", "dataType": ["text"]},
                ],
            }
            self._client.schema.create_class(schema)
            logger.info("Created Weaviate class: %s", class_name)

        logger.info("Weaviate backend initialized (class=%s, url=%s)", class_name, url)

    def upsert(
        self,
        id: str,
        vector: list[float],
        metadata: dict[str, Any] | None = None,
        document: str = "",
    ) -> None:
        """Insert or update a vector entry."""
        import json

        data_object = {
            "document": document,
            "category": (metadata or {}).get("category", ""),
            "metadata_json": json.dumps(metadata or {}),
        }

        # Check if exists
        existing = self._client.data_object.get_by_id(id, class_name=self._class_name)
        if existing:
            self._client.data_object.update(
                class_name=self._class_name,
                uuid=id,
                data_object=data_object,
                vector=vector,
            )
        else:
            self._client.data_object.create(
                class_name=self._class_name,
                uuid=id,
                data_object=data_object,
                vector=vector,
            )

    def query(
        self,
        vector: list[float],
        top_k: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Search for similar vectors."""
        import json

        query = self._client.query.get(self._class_name, ["document", "category", "metadata_json"])
        query = query.with_near_vector({"vector": vector}).with_limit(top_k)

        if where:
            # Build Weaviate where filter
            filters = self._build_where_filter(where)
            if filters:
                query = query.with_where(filters)

        query = query.with_additional(["distance", "id"])
        result = query.do()

        items: list[dict[str, Any]] = []
        classes = result.get("data", {}).get("Get", {})
        objects = classes.get(self._class_name, [])
        for obj in objects:
            additional = obj.pop("_additional", {})
            meta_json = obj.pop("metadata_json", "{}")
            try:
                meta = json.loads(meta_json) if isinstance(meta_json, str) else meta_json
            except (json.JSONDecodeError, TypeError):
                meta = {}

            distance = additional.get("distance", 1.0)
            score = max(0.0, 1.0 - float(distance))

            items.append({
                "id": additional.get("id", ""),
                "document": obj.get("document", ""),
                "metadata": meta,
                "score": score,
            })

        return items

    def get(self, ids: list[str]) -> list[dict[str, Any]]:
        """Get entries by ID."""
        import json

        results: list[dict[str, Any]] = []
        for entry_id in ids:
            obj = self._client.data_object.get_by_id(
                entry_id,
                class_name=self._class_name,
                with_vector=False,
            )
            if obj:
                props = obj.get("properties", {})
                meta_json = props.pop("metadata_json", "{}")
                try:
                    meta = json.loads(meta_json) if isinstance(meta_json, str) else meta_json
                except (json.JSONDecodeError, TypeError):
                    meta = {}
                results.append({
                    "id": entry_id,
                    "document": props.get("document", ""),
                    "metadata": meta,
                })
        return results

    def update_metadata(self, id: str, metadata: dict[str, Any]) -> None:
        """Update metadata for an existing entry."""
        import json

        existing = self.get([id])
        if existing:
            old_meta = existing[0].get("metadata", {})
            old_meta.update(metadata)
            self._client.data_object.update(
                class_name=self._class_name,
                uuid=id,
                data_object={"metadata_json": json.dumps(old_meta)},
            )

    def delete(self, ids: list[str]) -> None:
        """Delete entries by ID."""
        for entry_id in ids:
            try:
                self._client.data_object.delete(entry_id, class_name=self._class_name)
            except Exception as e:
                logger.warning("Failed to delete Weaviate object %s: %s", entry_id, e)

    def count(self) -> int:
        """Get total number of entries."""
        result = self._client.query.aggregate(self._class_name).with_meta_count().do()
        try:
            return result["data"]["Aggregate"][self._class_name][0]["meta"]["count"]
        except (KeyError, IndexError):
            return 0

    def persist(self) -> None:
        """Weaviate handles persistence automatically."""
        pass

    def close(self) -> None:
        """Release resources."""
        self._client = None

    def health(self) -> dict[str, Any]:
        """Health check."""
        try:
            ready = self._client.is_ready()
            return {"status": "ok" if ready else "not_ready"}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    @staticmethod
    def _build_where_filter(where: dict[str, Any]) -> dict[str, Any] | None:
        """Convert generic where filter to Weaviate format."""
        if not where:
            return None

        operands: list[dict[str, Any]] = []
        for key, value in where.items():
            if isinstance(value, dict) and "$in" in value:
                # Weaviate doesn't have a direct $in; use OR
                for v in value["$in"]:
                    operands.append({
                        "path": [key],
                        "operator": "Equal",
                        "valueText": str(v),
                    })
            else:
                operands.append({
                    "path": [key],
                    "operator": "Equal",
                    "valueText": str(value),
                })

        if len(operands) == 1:
            return operands[0]
        return {"operator": "Or", "operands": operands}
