"""Vector store manager: backend selection and lifecycle.

Provides a factory for creating and managing vector store backends.
Handles backend selection, initialization, health checks, and
graceful fallback when a backend is unavailable.
"""

from __future__ import annotations

import logging
from typing import Any

from terminal_agent.constants import DEFAULT_VECTOR_BACKEND

logger = logging.getLogger("terminal_agent.support.vector_store.manager")


class VectorStoreManager:
    """Factory and manager for vector store backends.

    Usage::

        manager = VectorStoreManager()
        store = manager.get_backend("chroma", path="./vector.db")
        store.upsert(id="1", vector=[0.1, 0.2, ...], document="hello")
        results = store.query(vector=[0.1, 0.2, ...], top_k=5)
    """

    # Registry of backend names → module paths
    _BACKENDS: dict[str, str] = {
        "chroma": "terminal_agent.support.vector_store.backends.chroma",
        "faiss": "terminal_agent.support.vector_store.backends.faiss",
        "pinecone": "terminal_agent.support.vector_store.backends.pinecone",
        "qdrant": "terminal_agent.support.vector_store.backends.qdrant",
        "weaviate": "terminal_agent.support.vector_store.backends.weaviate",
        "milvus": "terminal_agent.support.vector_store.backends.milvus",
        "memory": "terminal_agent.support.vector_store.backends.memory",
    }

    def __init__(self) -> None:
        self._instances: dict[str, Any] = {}

    def get_backend(
        self,
        name: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """Get or create a vector store backend instance.

        Args:
            name: Backend name (chroma, faiss, pinecone, qdrant,
                  weaviate, milvus, memory). Defaults to config setting.
            **kwargs: Backend-specific configuration.

        Returns:
            A vector store backend instance implementing the standard interface.

        Raises:
            ValueError: If backend name is unknown.
            ImportError: If backend dependencies are not installed.
        """
        name = name or DEFAULT_VECTOR_BACKEND

        # Return cached instance
        if name in self._instances:
            return self._instances[name]

        # Create new instance
        backend = self._create_backend(name, **kwargs)
        self._instances[name] = backend
        return backend

    def _create_backend(self, name: str, **kwargs: Any) -> Any:
        """Create a new backend instance."""
        if name not in self._BACKENDS:
            available = ", ".join(self._BACKENDS.keys())
            raise ValueError(
                f"Unknown vector store backend: '{name}'. "
                f"Available: {available}"
            )

        module_path = self._BACKENDS[name]

        try:
            import importlib
            module = importlib.import_module(module_path)
        except ImportError as e:
            # Fall back to in-memory backend
            logger.warning(
                "Backend '%s' unavailable (%s), falling back to 'memory'",
                name, e,
            )
            if name != "memory":
                return self._create_backend("memory", **kwargs)
            raise

        # Get the backend class (expected to be named *Backend or *Store)
        backend_class = getattr(module, "Backend", None) or getattr(module, "Store", None)
        if backend_class is None:
            raise AttributeError(
                f"Backend module '{module_path}' must export 'Backend' or 'Store' class"
            )

        try:
            instance = backend_class(**kwargs)
        except ImportError as e:
            # Backend raised ImportError (e.g., missing dependency)
            logger.warning(
                "Backend '%s' init failed (%s), falling back to 'memory'",
                name, e,
            )
            if name != "memory":
                return self._create_backend("memory", **kwargs)
            raise

        logger.info("Created vector store backend: %s", name)
        return instance

    def list_backends(self) -> list[str]:
        """List all available backend names."""
        return list(self._BACKENDS.keys())

    def list_available_backends(self) -> list[str]:
        """List backends whose dependencies are installed."""
        available: list[str] = []
        for name in self._BACKENDS:
            try:
                self._create_backend(name)
                available.append(name)
            except (ImportError, ValueError):
                pass
        return available

    def health_check(self, name: str | None = None) -> dict[str, Any]:
        """Check health of a vector store backend.

        Returns:
            Dict with 'status', 'backend', 'details' keys.
        """
        name = name or DEFAULT_VECTOR_BACKEND
        try:
            backend = self.get_backend(name)
            details: dict[str, Any] = {}
            if hasattr(backend, "count"):
                details["count"] = backend.count()
            if hasattr(backend, "health"):
                details.update(backend.health())
            return {"status": "ok", "backend": name, "details": details}
        except Exception as e:
            return {"status": "error", "backend": name, "details": {"error": str(e)}}

    def shutdown(self) -> None:
        """Shut down all backends gracefully."""
        for name, instance in self._instances.items():
            try:
                if hasattr(instance, "persist"):
                    instance.persist()
                if hasattr(instance, "close"):
                    instance.close()
                logger.info("Shut down vector store backend: %s", name)
            except Exception as e:
                logger.warning("Error shutting down %s: %s", name, e)
        self._instances.clear()
