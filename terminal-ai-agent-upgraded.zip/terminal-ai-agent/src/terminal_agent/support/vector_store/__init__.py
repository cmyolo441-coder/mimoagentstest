"""Vector store subsystem for semantic search and embeddings.

Provides a unified interface over multiple vector database backends
(ChromaDB, FAISS, Pinecone, Qdrant, Weaviate, Milvus, in-memory).
"""

from terminal_agent.support.vector_store.manager import VectorStoreManager
from terminal_agent.support.vector_store.embedding import EmbeddingService

__all__ = [
    "VectorStoreManager",
    "EmbeddingService",
]
