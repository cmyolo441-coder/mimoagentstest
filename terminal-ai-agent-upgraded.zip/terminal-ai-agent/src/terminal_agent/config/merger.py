"""Configuration merging with clear precedence.

Precedence (highest wins):
    CLI flags  >  Environment variables  >  Project config  >  Global config

The merger produces a single dict that is then validated and converted
into an ``AgentConfig`` instance.
"""

from __future__ import annotations

import os
from typing import Any

from terminal_agent.constants import APP_NAME


# Prefix for environment variable overrides, e.g. ``TA_LLM_MODEL=gpt-4o``
_ENV_PREFIX = f"{APP_NAME.upper().replace('-', '_')}_"


class ConfigMerger:
    """Merge configuration from multiple sources with defined precedence."""

    # ── public API ───────────────────────────────────────────────────

    @staticmethod
    def merge(
        global_cfg: dict[str, Any] | None = None,
        project_cfg: dict[str, Any] | None = None,
        env_overrides: dict[str, Any] | None = None,
        cli_overrides: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Merge all config layers and return a single dict.

        Each layer is a nested dict matching the TOML structure.
        ``None`` layers are silently skipped.
        """
        result: dict[str, Any] = {}

        # Layer 1 — global config (lowest priority)
        if global_cfg:
            ConfigMerger._deep_merge(result, global_cfg)

        # Layer 2 — project config
        if project_cfg:
            ConfigMerger._deep_merge(result, project_cfg)

        # Layer 3 — environment variable overrides
        if env_overrides is None:
            env_overrides = ConfigMerger.read_env()
        if env_overrides:
            ConfigMerger._deep_merge(result, env_overrides)

        # Layer 4 — CLI overrides (highest priority)
        if cli_overrides:
            ConfigMerger._deep_merge(result, cli_overrides)

        return result

    # ── environment variables ────────────────────────────────────────

    @staticmethod
    def read_env(prefix: str = _ENV_PREFIX) -> dict[str, Any]:
        """Read config overrides from environment variables.

        Variables follow the pattern ``TA_SECTION_KEY=value``, e.g.::

            TA_LLM_PROVIDER=openai
            TA_LLM_MODEL=gpt-4o
            TA_SAFETY_LEVEL=3
            TA_COST_MAX_COST_PER_TASK=10.00

        The prefix (default ``TA_``) is stripped, the remainder is
        split on ``_`` to build the nested dict.
        """
        overrides: dict[str, Any] = {}
        prefix_upper = prefix.upper()

        for key, value in os.environ.items():
            if not key.startswith(prefix_upper):
                continue
            # Strip prefix, convert to lowercase
            rest = key[len(prefix_upper):].lower()
            parts = rest.split("__")  # double-underscore separates sections
            if len(parts) < 2:
                # Single-part keys go to "general" or are ignored
                continue

            section = parts[0]
            field = "__".join(parts[1:])
            coerced = ConfigMerger._coerce_env_value(value)

            if section not in overrides:
                overrides[section] = {}
            if isinstance(overrides[section], dict):
                overrides[section][field] = coerced

        return overrides

    # ── flat (dotted.key) overrides ──────────────────────────────────

    @staticmethod
    def flat_to_nested(flat: dict[str, Any]) -> dict[str, Any]:
        """Convert ``{"llm.model": "gpt-4o"}`` to ``{"llm": {"model": ...}}``."""
        result: dict[str, Any] = {}
        for dotted_key, value in flat.items():
            parts = dotted_key.split(".")
            current = result
            for part in parts[:-1]:
                current = current.setdefault(part, {})
            current[parts[-1]] = value
        return result

    # ── internals ────────────────────────────────────────────────────

    @staticmethod
    def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        """Recursively merge *override* into *base* (mutates *base*)."""
        for key, value in override.items():
            if (
                key in base
                and isinstance(base[key], dict)
                and isinstance(value, dict)
            ):
                ConfigMerger._deep_merge(base[key], value)
            else:
                base[key] = value
        return base

    @staticmethod
    def _coerce_env_value(value: str) -> Any:
        """Best-effort coercion of an env-var string to a Python type."""
        # Boolean
        if value.lower() in ("true", "yes", "1", "on"):
            return True
        if value.lower() in ("false", "no", "0", "off"):
            return False
        # None / null
        if value.lower() in ("none", "null", ""):
            return None
        # Int
        try:
            return int(value)
        except ValueError:
            pass
        # Float
        try:
            return float(value)
        except ValueError:
            pass
        # Comma-separated list
        if "," in value:
            return [v.strip() for v in value.split(",")]
        return value
