"""Configuration version migration.

When the config schema evolves, existing user configs need to be
upgraded without losing custom values.  Each migration is a function
that takes a config dict and returns the migrated dict.

Migrations are registered in ``MIGRATIONS`` keyed by the target version
number.  ``ConfigMigration.migrate()`` runs all migrations from the
user's current version to the latest.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from terminal_agent.exceptions import ConfigError

logger = logging.getLogger(__name__)

# Current config schema version
CURRENT_VERSION = 1

# Migration functions: version N transforms (N-1) → N
MigrationFn = Callable[[dict[str, Any]], dict[str, Any]]

MIGRATIONS: dict[int, MigrationFn] = {}


def _register(target_version: int) -> Callable[[MigrationFn], MigrationFn]:
    """Decorator to register a migration function."""
    def decorator(fn: MigrationFn) -> MigrationFn:
        MIGRATIONS[target_version] = fn
        return fn
    return decorator


# ── Example migrations ───────────────────────────────────────────────
# Uncomment and add real migrations as the schema evolves.

# @_register(target_version=2)
# def _migrate_v1_to_v2(cfg: dict[str, Any]) -> dict[str, Any]:
#     """Rename 'memory.vector_backend' → 'memory.backend'."""
#     mem = cfg.get("memory", {})
#     if "vector_backend" in mem:
#         mem["backend"] = mem.pop("vector_backend")
#     cfg["memory"] = mem
#     cfg["config_version"] = 2
#     return cfg


# @_register(target_version=3)
# def _migrate_v2_to_v3(cfg: dict[str, Any]) -> dict[str, Any]:
#     """Add 'performance' section with defaults."""
#     cfg.setdefault("performance", {
#         "max_parallel_tools": 4,
#         "default_timeout": 120,
#         "enable_caching": True,
#         "enable_streaming": True,
#         "context_window_reserve": 1000,
#         "max_concurrent_sessions": 1,
#     })
#     cfg["config_version"] = 3
#     return cfg


class ConfigMigration:
    """Apply schema migrations to a config dict."""

    # ── public API ───────────────────────────────────────────────────

    @staticmethod
    def get_current_version() -> int:
        """Return the latest schema version number."""
        return CURRENT_VERSION

    @staticmethod
    def migrate(cfg: dict[str, Any]) -> dict[str, Any]:
        """Migrate *cfg* from its stored version to the latest.

        If the config has no ``config_version`` key it is assumed to be
        version 0 (pre-versioning).  Each registered migration is
        applied in order.

        Returns the migrated config dict (a new dict; *cfg* is not
        mutated).
        """
        # Work on a shallow copy at the top level
        cfg = dict(cfg)
        current = cfg.get("config_version", 0)

        if current == CURRENT_VERSION:
            return cfg

        if current > CURRENT_VERSION:
            raise ConfigError(
                f"Config version {current} is newer than the supported "
                f"version {CURRENT_VERSION}.  Please upgrade terminal-agent."
            )

        # Apply migrations in order
        for target in sorted(MIGRATIONS.keys()):
            if target <= current:
                continue
            if target > CURRENT_VERSION:
                break
            logger.info("Migrating config from v%d to v%d", current, target)
            try:
                cfg = MIGRATIONS[target](cfg)
            except Exception as exc:
                raise ConfigError(
                    f"Migration v{current}→v{target} failed: {exc}"
                ) from exc
            current = target

        # Ensure the version key is set
        cfg["config_version"] = CURRENT_VERSION
        return cfg

    @staticmethod
    def needs_migration(cfg: dict[str, Any]) -> bool:
        """Return ``True`` if *cfg* needs migration."""
        return cfg.get("config_version", 0) < CURRENT_VERSION

    @staticmethod
    def get_pending_migrations(cfg: dict[str, Any]) -> list[int]:
        """Return a list of migration version numbers that would run."""
        current = cfg.get("config_version", 0)
        return sorted(v for v in MIGRATIONS if v > current and v <= CURRENT_VERSION)

    # ── helpers for writing migrations ───────────────────────────────

    @staticmethod
    def rename_key(
        cfg: dict[str, Any],
        section: str,
        old_key: str,
        new_key: str,
    ) -> None:
        """Rename a key within a section, preserving the value."""
        sec = cfg.get(section, {})
        if old_key in sec:
            sec[new_key] = sec.pop(old_key)
            cfg[section] = sec

    @staticmethod
    def move_key(
        cfg: dict[str, Any],
        old_section: str,
        new_section: str,
        key: str,
    ) -> None:
        """Move a key from one section to another."""
        old = cfg.get(old_section, {})
        if key in old:
            cfg.setdefault(new_section, {})[key] = old.pop(key)
            cfg[old_section] = old

    @staticmethod
    def add_default(
        cfg: dict[str, Any],
        section: str,
        key: str,
        default: Any,
    ) -> None:
        """Add a key with a default value if it doesn't exist."""
        cfg.setdefault(section, {}).setdefault(key, default)
