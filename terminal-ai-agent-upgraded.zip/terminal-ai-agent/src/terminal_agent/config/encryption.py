"""Encrypt and decrypt sensitive configuration values (API keys, tokens).

Uses Fernet symmetric encryption (AES-128-CBC with HMAC-SHA256) from the
``cryptography`` library.  The master key is derived from a user-provided
passphrase via PBKDF2-HMAC-SHA256 (480 000 iterations).

When no passphrase is configured, values are stored in plaintext with a
warning.  This keeps the system usable for quick starts while making it
easy to opt-in to encryption.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import secrets
from pathlib import Path
from typing import Any

from terminal_agent.constants import GLOBAL_KEY_DIR
from terminal_agent.exceptions import ConfigEncryptionError

logger = logging.getLogger(__name__)

# Fields that are considered sensitive and should be encrypted when
# encryption is available.  Matched against the flat dotted key path.
_SENSITIVE_KEYS = {
    "api_key",
    "token",
    "secret",
    "password",
    "private_key",
    "access_key",
    "secret_key",
}

# Salt file stored alongside the key
_SALT_FILE = GLOBAL_KEY_DIR / "salt.bin"
_KEY_FILE = GLOBAL_KEY_DIR / "master.key"

# PBKDF2 parameters
_KDF_ITERATIONS = 480_000
_KEY_LENGTH = 32  # 256 bits

# Prefix that marks an encrypted value in the config file
_ENCRYPTED_PREFIX = "enc:v1:"


class ConfigEncryption:
    """Manage encryption of sensitive config values."""

    def __init__(self, passphrase: str | None = None) -> None:
        self._fernet: Any = None
        self._enabled = False
        if passphrase:
            self._init_fernet(passphrase)

    # ── public API ───────────────────────────────────────────────────

    @property
    def enabled(self) -> bool:
        """Whether encryption is active."""
        return self._enabled

    def encrypt_value(self, plaintext: str) -> str:
        """Encrypt a single string value.

        Returns the ciphertext encoded as ``enc:v1:<base64>``.
        If encryption is not initialised, returns the plaintext unchanged.
        """
        if not self._enabled or self._fernet is None:
            return plaintext
        token = self._fernet.encrypt(plaintext.encode("utf-8"))
        return _ENCRYPTED_PREFIX + base64.urlsafe_b64encode(token).decode("ascii")

    def decrypt_value(self, stored: str) -> str:
        """Decrypt a single stored value.

        If the value does not carry the ``enc:v1:`` prefix it is
        returned as-is (assumes plaintext).
        """
        if not stored.startswith(_ENCRYPTED_PREFIX):
            return stored
        if self._fernet is None:
            raise ConfigEncryptionError(
                "Cannot decrypt value — master passphrase not provided"
            )
        try:
            raw = stored[len(_ENCRYPTED_PREFIX):]
            token = base64.urlsafe_b64decode(raw.encode("ascii"))
            return self._fernet.decrypt(token).decode("utf-8")
        except Exception as exc:
            raise ConfigEncryptionError(
                f"Failed to decrypt value: {exc}"
            ) from exc

    def encrypt_sensitive_fields(self, cfg: dict[str, Any]) -> dict[str, Any]:
        """Walk *cfg* and encrypt every field whose name is sensitive.

        Returns a new dict; the original is not mutated.
        """
        return self._walk_and_transform(cfg, self.encrypt_value)

    def decrypt_sensitive_fields(self, cfg: dict[str, Any]) -> dict[str, Any]:
        """Walk *cfg* and decrypt every encrypted sensitive field."""
        return self._walk_and_transform(cfg, self.decrypt_value)

    # ── key management ───────────────────────────────────────────────

    @staticmethod
    def generate_passphrase() -> str:
        """Generate a random 32-character passphrase."""
        return secrets.token_urlsafe(24)

    @staticmethod
    def init_from_passphrase(passphrase: str) -> ConfigEncryption:
        """Create an instance from a passphrase (interactive setup)."""
        return ConfigEncryption(passphrase=passphrase)

    @staticmethod
    def load_or_create(passphrase: str | None = None) -> ConfigEncryption:
        """Load existing key material or create new encryption context.

        If *passphrase* is ``None``, returns a no-op instance (encryption
        disabled).
        """
        if passphrase is None:
            return ConfigEncryption(passphrase=None)
        return ConfigEncryption(passphrase=passphrase)

    # ── internals ────────────────────────────────────────────────────

    def _init_fernet(self, passphrase: str) -> None:
        """Derive a Fernet key from *passphrase* via PBKDF2."""
        try:
            from cryptography.fernet import Fernet
            from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
            from cryptography.hazmat.primitives import hashes
        except ImportError as exc:
            raise ConfigEncryptionError(
                "The 'cryptography' package is required for config encryption. "
                "Install it with: pip install cryptography"
            ) from exc

        salt = self._load_or_create_salt()
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=_KEY_LENGTH,
            salt=salt,
            iterations=_KDF_ITERATIONS,
        )
        key = base64.urlsafe_b64encode(kdf.derive(passphrase.encode("utf-8")))
        self._fernet = Fernet(key)
        self._enabled = True

    @staticmethod
    def _load_or_create_salt() -> bytes:
        """Load the salt from disk, or create and persist a new one."""
        if _SALT_FILE.exists():
            return _SALT_FILE.read_bytes()
        GLOBAL_KEY_DIR.mkdir(parents=True, exist_ok=True)
        salt = os.urandom(16)
        _SALT_FILE.write_bytes(salt)
        # Restrict permissions to owner only
        try:
            os.chmod(_SALT_FILE, 0o600)
        except OSError:
            pass
        return salt

    @staticmethod
    def _is_sensitive_key(key: str) -> bool:
        """Check whether *key* looks like a sensitive field name."""
        lower = key.lower()
        return any(s in lower for s in _SENSITIVE_KEYS)

    def _walk_and_transform(
        self, obj: Any, transform: Any
    ) -> Any:
        """Recursively walk a nested dict/list structure.

        Apply *transform* to any string value whose key is sensitive.
        """
        if isinstance(obj, dict):
            result: dict[str, Any] = {}
            for k, v in obj.items():
                if isinstance(v, str) and self._is_sensitive_key(k):
                    result[k] = transform(v)
                elif isinstance(v, dict):
                    result[k] = self._walk_and_transform(v, transform)
                elif isinstance(v, list):
                    result[k] = [
                        self._walk_and_transform(i, transform) for i in v
                    ]
                else:
                    result[k] = v
            return result
        if isinstance(obj, list):
            return [self._walk_and_transform(i, transform) for i in obj]
        return obj
