"""Configuration profiles (dev, staging, prod, custom).

Profiles are stored as ``[profiles.<name>]`` sections inside the global
config file.  Each profile is a partial config dict that is overlaid on
top of the base config when activated.

Example ``config.toml``::

    [llm]
    provider = "openai"
    model = "gpt-4o"

    [profiles.dev]
    [profiles.dev.llm]
    model = "gpt-4o-mini"
    temperature = 0.3

    [profiles.prod]
    [profiles.prod.safety]
    level = 4
    sandbox_mode = true
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import tomli
import tomli_w

from terminal_agent.constants import GLOBAL_CONFIG_FILE
from terminal_agent.exceptions import ConfigError, ConfigFileNotFoundError

logger = logging.getLogger(__name__)

# Well-known profile names (for suggestions / auto-complete)
KNOWN_PROFILES = ("dev", "staging", "prod", "ci", "local")


class ProfileManager:
    """Manage named configuration profiles."""

    def __init__(self, config_path: Path | None = None) -> None:
        self._path = config_path or GLOBAL_CONFIG_FILE

    # ── public API ───────────────────────────────────────────────────

    def list_profiles(self) -> list[str]:
        """Return sorted list of profile names defined in the config file."""
        data = self._read_raw()
        return sorted(data.get("profiles", {}).keys())

    def get_profile(self, name: str) -> dict[str, Any]:
        """Return the raw dict for profile *name*.

        Raises ``ConfigError`` if the profile does not exist.
        """
        profiles = self._read_raw().get("profiles", {})
        if name not in profiles:
            raise ConfigError(
                f"Profile {name!r} not found. Available: {sorted(profiles.keys())}"
            )
        return profiles[name]

    def save_profile(self, name: str, overrides: dict[str, Any]) -> None:
        """Create or update a named profile."""
        data = self._read_raw()
        profiles = data.setdefault("profiles", {})
        profiles[name] = overrides
        self._write_raw(data)
        logger.info("Saved profile %r", name)

    def delete_profile(self, name: str) -> None:
        """Delete a named profile.

        Raises ``ConfigError`` if the profile does not exist.
        """
        data = self._read_raw()
        profiles = data.get("profiles", {})
        if name not in profiles:
            raise ConfigError(f"Profile {name!r} not found")
        del profiles[name]
        self._write_raw(data)
        logger.info("Deleted profile %r", name)

    def activate_profile(self, name: str) -> dict[str, Any]:
        """Return the profile's overrides, suitable for merging.

        This does *not* write the ``active_profile`` key — that is the
        ConfigManager's responsibility.
        """
        return self.get_profile(name)

    def create_default_profiles(self) -> None:
        """Write starter profiles if none exist yet."""
        data = self._read_raw()
        if data.get("profiles"):
            return  # already has profiles

        data["profiles"] = {
            "dev": {
                "llm": {"model": "gpt-4o-mini", "temperature": 0.3},
                "safety": {"level": 1, "confirm_destructive": False},
                "logging": {"level": "DEBUG"},
                "cost": {"max_cost_per_task": 1.00},
            },
            "staging": {
                "llm": {"model": "gpt-4o"},
                "safety": {"level": 2},
                "logging": {"level": "INFO"},
            },
            "prod": {
                "llm": {"model": "gpt-4o"},
                "safety": {"level": 4, "sandbox_mode": True},
                "logging": {"level": "WARNING"},
                "cost": {"max_cost_per_task": 20.00},
            },
        }
        self._write_raw(data)
        logger.info("Created default profiles: dev, staging, prod")

    # ── internals ────────────────────────────────────────────────────

    def _read_raw(self) -> dict[str, Any]:
        """Read the full TOML file as a dict (empty dict if missing)."""
        if not self._path.exists():
            return {}
        try:
            with open(self._path, "rb") as fh:
                return tomli.load(fh)
        except Exception as exc:
            raise ConfigError(f"Failed to read config file {self._path}: {exc}") from exc

    def _write_raw(self, data: dict[str, Any]) -> None:
        """Write the full dict back to the TOML file."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(self._path, "wb") as fh:
                tomli_w.dump(data, fh)
        except Exception as exc:
            raise ConfigError(f"Failed to write config file {self._path}: {exc}") from exc
