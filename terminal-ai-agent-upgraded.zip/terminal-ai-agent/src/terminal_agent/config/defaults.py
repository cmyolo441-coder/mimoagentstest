"""Default configuration values for Terminal Agent.

Every setting has a sensible default here so the agent works out of the
box with zero configuration.  Values are derived from ``constants.py``
where possible to avoid drift.
"""

from __future__ import annotations

from typing import Any

from terminal_agent.constants import (
    DEFAULT_CACHE_BACKEND,
    DEFAULT_CACHE_MAX_SIZE,
    DEFAULT_CACHE_TTL,
    DEFAULT_CONSOLIDATION_INTERVAL,
    DEFAULT_COST_WARNING_THRESHOLD,
    DEFAULT_DECAY_RATE,
    DEFAULT_EMBEDDING_DIMENSIONS,
    DEFAULT_EMBEDDING_MODEL,
    DEFAULT_FILESYSTEM_MAX_READ,
    DEFAULT_LLM_CALLS_PER_MINUTE,
    DEFAULT_LLM_MODEL,
    DEFAULT_LLM_PROVIDER,
    DEFAULT_LONG_TERM_MEMORIES_PER_QUERY,
    DEFAULT_MAX_COST_PER_TASK,
    DEFAULT_MAX_ITERATIONS,
    DEFAULT_MAX_MEMORY_SIZE,
    DEFAULT_MAX_RETRIES,
    DEFAULT_MAX_TOKENS,
    DEFAULT_RETRY_DELAY,
    DEFAULT_SAFETY_LEVEL,
    DEFAULT_SHELL_MAX_OUTPUT,
    DEFAULT_SHELL_TIMEOUT,
    DEFAULT_SHORT_TERM_TURNS,
    DEFAULT_TEMPERATURE,
    DEFAULT_TIMEOUT,
    DEFAULT_TOOL_CALLS_PER_MINUTE,
    DEFAULT_VECTOR_BACKEND,
    DEFAULT_WORKING_MEMORY_FILES,
    GLOBAL_CACHE_DIR,
    GLOBAL_CONFIG_FILE,
    GLOBAL_DIR,
    GLOBAL_KEY_DIR,
    GLOBAL_LOG_DIR,
    GLOBAL_VECTOR_DB_FILE,
)


def get_defaults() -> dict[str, Any]:
    """Return the full default config as a nested dict (TOML-compatible).

    This is the canonical source of truth for field defaults.  The
    dataclass defaults in ``schema.py`` mirror these values, but this
    dict is what gets written to disk when generating a fresh config.
    """
    return {
        "config_version": 1,
        "active_profile": "",
        "llm": {
            "provider": DEFAULT_LLM_PROVIDER,
            "model": DEFAULT_LLM_MODEL,
            "api_key": "",
            "base_url": None,
            "organization": None,
            "temperature": DEFAULT_TEMPERATURE,
            "max_tokens": DEFAULT_MAX_TOKENS,
            "timeout": DEFAULT_TIMEOUT,
            "max_retries": DEFAULT_MAX_RETRIES,
            "retry_delay": DEFAULT_RETRY_DELAY,
            "stream": True,
            "fallback_providers": [],
            "providers": {},
        },
        "memory": {
            "backend": DEFAULT_VECTOR_BACKEND,
            "embedding_model": DEFAULT_EMBEDDING_MODEL,
            "embedding_dimensions": DEFAULT_EMBEDDING_DIMENSIONS,
            "short_term_turns": DEFAULT_SHORT_TERM_TURNS,
            "working_memory_files": DEFAULT_WORKING_MEMORY_FILES,
            "long_term_memories_per_query": DEFAULT_LONG_TERM_MEMORIES_PER_QUERY,
            "consolidation_interval": DEFAULT_CONSOLIDATION_INTERVAL,
            "decay_rate": DEFAULT_DECAY_RATE,
            "max_memory_size": DEFAULT_MAX_MEMORY_SIZE,
            "vector_db_path": str(GLOBAL_VECTOR_DB_FILE),
            "enable_semantic_search": True,
        },
        "safety": {
            "level": DEFAULT_SAFETY_LEVEL,
            "blocked_commands": [
                "rm -rf /",
                "rm -rf /*",
                "dd if=/dev/zero",
                "dd if=/dev/random",
                ":(){ :|:& };:",
                "chmod -R 777 /",
                "mkfs",
                "> /dev/sda",
            ],
            "blocked_paths": [
                "/etc/shadow",
                "/etc/passwd",
                "/boot",
                "/proc/kcore",
            ],
            "confirm_destructive": True,
            "confirm_writes": False,
            "confirm_executions": False,
            "sandbox_mode": False,
            "max_output_size": DEFAULT_SHELL_MAX_OUTPUT,
            "audit_log": True,
        },
        "tools": {
            "enabled_categories": [],
            "disabled_categories": [],
            "shell": {
                "timeout": DEFAULT_SHELL_TIMEOUT,
                "max_output": DEFAULT_SHELL_MAX_OUTPUT,
                "allow_background": True,
                "allow_sudo": False,
                "allowed_commands": [],
                "blocked_commands": [],
            },
            "filesystem": {
                "max_read_size": DEFAULT_FILESYSTEM_MAX_READ,
                "backup_before_edit": True,
                "allowed_paths": [],
                "blocked_paths": [],
            },
        },
        "cache": {
            "backend": DEFAULT_CACHE_BACKEND,
            "max_size": DEFAULT_CACHE_MAX_SIZE,
            "ttl": DEFAULT_CACHE_TTL,
            "eviction_policy": "lru",
            "disk_path": str(GLOBAL_CACHE_DIR),
            "enable_llm_cache": True,
            "enable_tool_cache": True,
        },
        "logging": {
            "level": "INFO",
            "format": "structured",
            "file": str(GLOBAL_LOG_DIR / "agent.log"),
            "max_file_size": 10_000_000,
            "backup_count": 5,
            "console": True,
            "colorize": True,
            "trace_llm_calls": False,
            "trace_tool_calls": False,
        },
        "ui": {
            "theme": "dark",
            "verbosity": "normal",
            "show_progress": True,
            "show_plan": True,
            "show_cost": True,
            "show_token_usage": False,
            "code_theme": "monokai",
            "spinner_style": "dots",
            "max_display_lines": 500,
            "pager": "auto",
        },
        "git": {
            "auto_commit": False,
            "commit_message_style": "conventional",
            "branch_prefix": "agent/",
            "default_branch": "main",
            "sign_commits": False,
            "auto_push": False,
            "stash_before_switch": True,
        },
        "testing": {
            "default_framework": "auto",
            "coverage_threshold": 80.0,
            "run_on_save": False,
            "parallel": True,
            "timeout": 300,
            "fail_fast": False,
            "verbose": True,
        },
        "cost": {
            "max_cost_per_task": DEFAULT_MAX_COST_PER_TASK,
            "warning_threshold": DEFAULT_COST_WARNING_THRESHOLD,
            "track_costs": True,
            "currency": "USD",
            "budget_period": "task",
            "daily_budget": 50.00,
            "monthly_budget": 500.00,
        },
        "plugin": {
            "enabled": True,
            "directories": [],
            "enabled_plugins": [],
            "disabled_plugins": [],
            "auto_discover": True,
            "sandbox_plugins": True,
        },
        "mcp": {
            "enabled": True,
            "servers": {},
            "default_timeout": 30,
            "retry_policy": "exponential",
            "max_retries": 3,
        },
        "performance": {
            "max_parallel_tools": 4,
            "default_timeout": DEFAULT_TIMEOUT,
            "enable_caching": True,
            "enable_streaming": True,
            "context_window_reserve": 1000,
            "max_concurrent_sessions": 1,
        },
        "export": {
            "default_format": "json",
            "output_directory": "exports",
            "include_traces": True,
            "include_metrics": True,
            "compress": False,
        },
    }


def get_defaults_flat() -> dict[str, Any]:
    """Return defaults as a flat ``dotted.key → value`` mapping.

    Useful for CLI flag generation and environment variable lookups.
    """
    result: dict[str, Any] = {}

    def _flatten(prefix: str, obj: Any) -> None:
        if isinstance(obj, dict):
            for k, v in obj.items():
                _flatten(f"{prefix}.{k}" if prefix else k, v)
        else:
            result[prefix] = obj

    _flatten("", get_defaults())
    return result
