"""Configuration schema definitions for Terminal Agent.

Every config category is a frozen dataclass. ``AgentConfig`` is the
top-level container that holds them all.  Field names mirror the TOML
keys exactly so serialisation/deserialisation is lossless.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ── LLM ──────────────────────────────────────────────────────────────

@dataclass
class LLMProviderConfig:
    """Per-provider overrides (keyed by provider id)."""

    provider: str = ""
    model: str = ""
    api_key: str = ""
    base_url: str | None = None
    organization: str | None = None
    temperature: float = 0.0
    max_tokens: int = 4096
    timeout: int = 120
    max_retries: int = 3
    retry_delay: float = 1.0
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMConfig:
    """LLM engine settings."""

    provider: str = "openai"
    model: str = "gpt-4o"
    api_key: str = ""
    base_url: str | None = None
    organization: str | None = None
    temperature: float = 0.0
    max_tokens: int = 4096
    timeout: int = 120
    max_retries: int = 3
    retry_delay: float = 1.0
    stream: bool = True
    fallback_providers: list[str] = field(default_factory=list)
    providers: dict[str, LLMProviderConfig] = field(default_factory=dict)


# ── Memory ───────────────────────────────────────────────────────────

@dataclass
class MemoryConfig:
    """Memory engine settings."""

    backend: str = "chroma"
    embedding_model: str = "text-embedding-3-small"
    embedding_dimensions: int = 1536
    short_term_turns: int = 20
    working_memory_files: int = 10
    long_term_memories_per_query: int = 5
    consolidation_interval: int = 3600
    decay_rate: float = 0.1
    max_memory_size: int = 10000
    vector_db_path: str = ""
    enable_semantic_search: bool = True


# ── Safety ───────────────────────────────────────────────────────────

@dataclass
class SafetyConfig:
    """Safety guardrail settings."""

    level: int = 2
    blocked_commands: list[str] = field(default_factory=list)
    blocked_paths: list[str] = field(default_factory=list)
    confirm_destructive: bool = True
    confirm_writes: bool = False
    confirm_executions: bool = False
    sandbox_mode: bool = False
    max_output_size: int = 100_000
    audit_log: bool = True


# ── Tools ────────────────────────────────────────────────────────────

@dataclass
class ShellToolConfig:
    """Shell tool settings."""

    timeout: int = 300
    max_output: int = 100_000
    allow_background: bool = True
    allow_sudo: bool = False
    allowed_commands: list[str] = field(default_factory=list)
    blocked_commands: list[str] = field(default_factory=list)


@dataclass
class FilesystemToolConfig:
    """Filesystem tool settings."""

    max_read_size: int = 1_000_000
    backup_before_edit: bool = True
    allowed_paths: list[str] = field(default_factory=list)
    blocked_paths: list[str] = field(default_factory=list)


@dataclass
class ToolsConfig:
    """Tool registry settings."""

    enabled_categories: list[str] = field(default_factory=list)
    disabled_categories: list[str] = field(default_factory=list)
    shell: ShellToolConfig = field(default_factory=ShellToolConfig)
    filesystem: FilesystemToolConfig = field(default_factory=FilesystemToolConfig)


# ── Cache ────────────────────────────────────────────────────────────

@dataclass
class CacheConfig:
    """Cache layer settings."""

    backend: str = "memory"
    max_size: int = 1000
    ttl: int = 3600
    eviction_policy: str = "lru"
    disk_path: str = ""
    enable_llm_cache: bool = True
    enable_tool_cache: bool = True


# ── Logging ──────────────────────────────────────────────────────────

@dataclass
class LoggingConfig:
    """Logging settings."""

    level: str = "INFO"
    format: str = "structured"
    file: str = ""
    max_file_size: int = 10_000_000  # 10 MB
    backup_count: int = 5
    console: bool = True
    colorize: bool = True
    trace_llm_calls: bool = False
    trace_tool_calls: bool = False


# ── UI ───────────────────────────────────────────────────────────────

@dataclass
class UIConfig:
    """User interface settings."""

    theme: str = "dark"
    verbosity: str = "normal"  # quiet, normal, verbose, debug
    show_progress: bool = True
    show_plan: bool = True
    show_cost: bool = True
    show_token_usage: bool = False
    code_theme: str = "monokai"
    spinner_style: str = "dots"
    max_display_lines: int = 500
    pager: str = "auto"


# ── Git ──────────────────────────────────────────────────────────────

@dataclass
class GitConfig:
    """Git integration settings."""

    auto_commit: bool = False
    commit_message_style: str = "conventional"  # conventional, simple, detailed
    branch_prefix: str = "agent/"
    default_branch: str = "main"
    sign_commits: bool = False
    auto_push: bool = False
    stash_before_switch: bool = True


# ── Testing ──────────────────────────────────────────────────────────

@dataclass
class TestingConfig:
    """Testing settings."""

    default_framework: str = "auto"
    coverage_threshold: float = 80.0
    run_on_save: bool = False
    parallel: bool = True
    timeout: int = 300
    fail_fast: bool = False
    verbose: bool = True


# ── Cost ─────────────────────────────────────────────────────────────

@dataclass
class CostConfig:
    """Cost management settings."""

    max_cost_per_task: float = 5.00
    warning_threshold: float = 0.80
    track_costs: bool = True
    currency: str = "USD"
    budget_period: str = "task"  # task, daily, weekly, monthly
    daily_budget: float = 50.00
    monthly_budget: float = 500.00


# ── Plugin ───────────────────────────────────────────────────────────

@dataclass
class PluginConfig:
    """Plugin system settings."""

    enabled: bool = True
    directories: list[str] = field(default_factory=list)
    enabled_plugins: list[str] = field(default_factory=list)
    disabled_plugins: list[str] = field(default_factory=list)
    auto_discover: bool = True
    sandbox_plugins: bool = True


# ── MCP ──────────────────────────────────────────────────────────────

@dataclass
class MCPServerConfig:
    """Per-MCP-server configuration."""

    command: str = ""
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    timeout: int = 30
    enabled: bool = True


@dataclass
class MCPConfig:
    """MCP (Model Context Protocol) settings."""

    enabled: bool = True
    servers: dict[str, MCPServerConfig] = field(default_factory=dict)
    default_timeout: int = 30
    retry_policy: str = "exponential"
    max_retries: int = 3


# ── Performance ──────────────────────────────────────────────────────

@dataclass
class PerformanceConfig:
    """Performance tuning settings."""

    max_parallel_tools: int = 4
    default_timeout: int = 120
    enable_caching: bool = True
    enable_streaming: bool = True
    context_window_reserve: int = 1000
    max_concurrent_sessions: int = 1


# ── Export ───────────────────────────────────────────────────────────

@dataclass
class ExportConfig:
    """Export settings."""

    default_format: str = "json"
    output_directory: str = "exports"
    include_traces: bool = True
    include_metrics: bool = True
    compress: bool = False


# ── Top-level Agent Config ──────────────────────────────────────────

@dataclass
class AgentConfig:
    """Root configuration object — mirrors ``config.toml`` exactly."""

    config_version: int = 1
    active_profile: str = ""

    llm: LLMConfig = field(default_factory=LLMConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    safety: SafetyConfig = field(default_factory=SafetyConfig)
    tools: ToolsConfig = field(default_factory=ToolsConfig)
    cache: CacheConfig = field(default_factory=CacheConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    git: GitConfig = field(default_factory=GitConfig)
    testing: TestingConfig = field(default_factory=TestingConfig)
    cost: CostConfig = field(default_factory=CostConfig)
    plugin: PluginConfig = field(default_factory=PluginConfig)
    mcp: MCPConfig = field(default_factory=MCPConfig)
    performance: PerformanceConfig = field(default_factory=PerformanceConfig)
    export: ExportConfig = field(default_factory=ExportConfig)

    # ── helpers ──────────────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict (suitable for TOML writing)."""
        from dataclasses import fields, is_dataclass

        def _convert(obj: Any) -> Any:
            if is_dataclass(obj) and not isinstance(obj, type):
                return {f.name: _convert(getattr(obj, f.name)) for f in fields(obj)}
            if isinstance(obj, list):
                return [_convert(i) for i in obj]
            if isinstance(obj, dict):
                return {k: _convert(v) for k, v in obj.items()}
            return obj

        return _convert(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AgentConfig:
        """Deserialise from a plain dict (e.g. parsed TOML)."""
        from dataclasses import fields, is_dataclass

        def _build(klass: type, values: dict[str, Any]) -> Any:
            if not is_dataclass(klass):
                return values
            kw: dict[str, Any] = {}
            for f in fields(klass):
                if f.name not in values:
                    continue
                val = values[f.name]
                # Recurse into nested dataclass types
                ft = f.type
                # Resolve string annotations
                if isinstance(ft, str):
                    import sys
                    mod = sys.modules.get(klass.__module__, sys.modules[__name__])
                    ft = eval(ft, getattr(mod, "__dict__", {}), {klass.__name__: klass})
                if is_dataclass(ft) and isinstance(val, dict):
                    val = _build(ft, val)
                elif isinstance(ft, type) and issubclass(ft, list) and isinstance(val, list):
                    pass  # lists kept as-is
                # Handle dict values whose type hint is a dataclass
                if isinstance(val, dict) and f.name == "providers":
                    val = {
                        k: _build(LLMProviderConfig, v) if isinstance(v, dict) else v
                        for k, v in val.items()
                    }
                elif isinstance(val, dict) and f.name == "servers":
                    val = {
                        k: _build(MCPServerConfig, v) if isinstance(v, dict) else v
                        for k, v in val.items()
                    }
                kw[f.name] = val
            return klass(**kw)

        return _build(cls, data)
