"""Central configuration manager for Terminal Agent.

Loads, merges, validates, encrypts, watches, and provides access to the
unified configuration.  This is the single entry-point that all other
modules use::

    from terminal_agent.config import ConfigManager

    cfg = ConfigManager.get()
    model = cfg.llm.model
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import tomli
import tomli_w

from terminal_agent.config.defaults import get_defaults
from terminal_agent.config.encryption import ConfigEncryption
from terminal_agent.config.merger import ConfigMerger
from terminal_agent.config.migration import ConfigMigration
from terminal_agent.config.profiles import ProfileManager
from terminal_agent.config.schema import AgentConfig
from terminal_agent.config.validator import ConfigValidator
from terminal_agent.config.watcher import ConfigWatcher
from terminal_agent.constants import GLOBAL_CONFIG_FILE, PROJECT_CONFIG_FILE
from terminal_agent.exceptions import (
    ConfigError,
    ConfigFileNotFoundError,
    ConfigValidationError,
)

logger = logging.getLogger(__name__)


class ConfigManager:
    """Manage the full configuration lifecycle.

    Typical usage::

        # One-time setup (e.g. in CLI startup)
        ConfigManager.init(
            global_path=GLOBAL_CONFIG_FILE,
            project_path=PROJECT_CONFIG_FILE,
            cli_overrides={"llm": {"model": "gpt-4o-mini"}},
        )

        # Anywhere in the codebase
        cfg = ConfigManager.get()
        print(cfg.llm.model)

    The manager is a singleton; ``init()`` configures the shared
    instance, and ``get()`` returns it.
    """

    _instance: ConfigManager | None = None

    def __init__(
        self,
        global_path: Path | None = None,
        project_path: Path | None = None,
        cli_overrides: dict[str, Any] | None = None,
        env_overrides: dict[str, Any] | None = None,
        passphrase: str | None = None,
        profile: str | None = None,
        watch: bool = True,
    ) -> None:
        self._global_path = global_path or GLOBAL_CONFIG_FILE
        self._project_path = project_path or PROJECT_CONFIG_FILE
        self._cli_overrides = cli_overrides or {}
        self._env_overrides = env_overrides
        self._profile = profile or ""
        self._watch = watch

        # Sub-systems
        self._encryption = ConfigEncryption(passphrase=passphrase)
        self._merger = ConfigMerger()
        self._validator = ConfigValidator()
        self._migration = ConfigMigration()
        self._profiles = ProfileManager(config_path=self._global_path)
        self._watcher: ConfigWatcher | None = None

        # Current config (loaded on init)
        self._config: AgentConfig | None = None
        self._raw: dict[str, Any] = {}

        # Load immediately
        self.reload()

    # ── singleton API ────────────────────────────────────────────────

    @classmethod
    def init(
        cls,
        global_path: Path | None = None,
        project_path: Path | None = None,
        cli_overrides: dict[str, Any] | None = None,
        env_overrides: dict[str, Any] | None = None,
        passphrase: str | None = None,
        profile: str | None = None,
        watch: bool = True,
    ) -> ConfigManager:
        """Initialise (or re-initialise) the global ConfigManager instance."""
        cls._instance = cls(
            global_path=global_path,
            project_path=project_path,
            cli_overrides=cli_overrides,
            env_overrides=env_overrides,
            passphrase=passphrase,
            profile=profile,
            watch=watch,
        )
        return cls._instance

    @classmethod
    def get(cls) -> AgentConfig:
        """Return the current configuration.

        If ``init()`` has not been called, a default-config instance is
        created on the fly (useful for tests).
        """
        if cls._instance is None:
            cls._instance = cls()
        if cls._instance._config is None:
            raise ConfigError("Configuration has not been loaded")
        return cls._instance._config

    @classmethod
    def get_manager(cls) -> ConfigManager:
        """Return the singleton manager instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton (for testing)."""
        if cls._instance is not None:
            cls._instance.shutdown()
        cls._instance = None

    # ── lifecycle ────────────────────────────────────────────────────

    def reload(self) -> AgentConfig:
        """Re-load configuration from all sources.

        This is called automatically on init and by the file watcher
        when a config file changes.
        """
        # 1. Read sources
        global_cfg = self._read_toml(self._global_path)
        project_cfg = self._read_toml(self._project_path)

        # 2. Apply profile overlay if active
        profile_name = self._profile or global_cfg.get("active_profile", "")
        if profile_name:
            try:
                profile_cfg = self._profiles.get_profile(profile_name)
                # Profile overrides sit between project and env
                project_cfg = ConfigMerger._deep_merge(
                    dict(project_cfg), profile_cfg
                ) if project_cfg else profile_cfg
                logger.info("Applied profile: %s", profile_name)
            except ConfigError:
                logger.warning("Profile %r not found, skipping", profile_name)

        # 3. Decrypt sensitive fields in file-based configs
        if self._encryption.enabled:
            global_cfg = self._encryption.decrypt_sensitive_fields(global_cfg)
            project_cfg = self._encryption.decrypt_sensitive_fields(project_cfg)

        # 4. Merge all layers
        merged = ConfigMerger.merge(
            global_cfg=global_cfg,
            project_cfg=project_cfg,
            env_overrides=self._env_overrides,
            cli_overrides=self._cli_overrides,
        )

        # 5. Migrate if needed
        if ConfigMigration.needs_migration(merged):
            merged = ConfigMigration.migrate(merged)
            logger.info("Config migrated to version %d", merged.get("config_version"))

        # 6. Apply defaults for any missing keys
        merged = self._apply_defaults(merged)

        # 7. Validate
        ConfigValidator.validate_or_raise(merged)

        # 8. Build the typed config object
        self._raw = merged
        self._config = AgentConfig.from_dict(merged)

        # 9. Start file watcher if requested
        if self._watch and self._watcher is None:
            self._start_watcher()

        logger.debug("Configuration loaded: %s", self._config)
        return self._config

    def shutdown(self) -> None:
        """Clean up resources (stop watcher, clear state)."""
        if self._watcher is not None:
            self._watcher.stop()
            self._watcher = None

    # ── read / write ─────────────────────────────────────────────────

    def save(self, path: Path | None = None) -> None:
        """Write the current config to disk.

        Encrypts sensitive fields before writing.
        """
        if self._config is None:
            raise ConfigError("No configuration to save")
        target = path or self._global_path
        data = self._config.to_dict()
        if self._encryption.enabled:
            data = self._encryption.encrypt_sensitive_fields(data)
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "wb") as fh:
            tomli_w.dump(data, fh)
        logger.info("Configuration saved to %s", target)

    def get_raw(self) -> dict[str, Any]:
        """Return the raw merged config dict (for debugging / export)."""
        return dict(self._raw)

    # ── profiles ─────────────────────────────────────────────────────

    def list_profiles(self) -> list[str]:
        """List available profiles."""
        return self._profiles.list_profiles()

    def activate_profile(self, name: str) -> AgentConfig:
        """Switch to a named profile and reload."""
        self._profile = name
        return self.reload()

    def save_profile(self, name: str, overrides: dict[str, Any]) -> None:
        """Save a new profile."""
        self._profiles.save_profile(name, overrides)

    def delete_profile(self, name: str) -> None:
        """Delete a profile."""
        self._profiles.delete_profile(name)

    # ── per-field access helpers ─────────────────────────────────────

    def get_value(self, dotted_key: str, default: Any = None) -> Any:
        """Get a config value by dotted key path, e.g. ``'llm.model'``."""
        parts = dotted_key.split(".")
        obj: Any = self._raw
        for part in parts:
            if isinstance(obj, dict) and part in obj:
                obj = obj[part]
            else:
                return default
        return obj

    def set_value(self, dotted_key: str, value: Any) -> None:
        """Set a config value by dotted key path and reload."""
        parts = dotted_key.split(".")
        obj = self._raw
        for part in parts[:-1]:
            obj = obj.setdefault(part, {})
        obj[parts[-1]] = value
        # Re-validate and rebuild
        ConfigValidator.validate_or_raise(self._raw)
        self._config = AgentConfig.from_dict(self._raw)

    # ── encryption ───────────────────────────────────────────────────

    def encrypt_file(self, passphrase: str) -> None:
        """Re-encrypt sensitive fields in the global config file."""
        enc = ConfigEncryption(passphrase=passphrase)
        data = self._read_toml(self._global_path)
        encrypted = enc.encrypt_sensitive_fields(data)
        with open(self._global_path, "wb") as fh:
            tomli_w.dump(encrypted, fh)
        self._encryption = enc
        logger.info("Config file encrypted")

    def set_passphrase(self, passphrase: str) -> None:
        """Set or change the encryption passphrase and re-encrypt."""
        self.encrypt_file(passphrase)

    # ── introspection ────────────────────────────────────────────────

    def diff_from_defaults(self) -> dict[str, Any]:
        """Return only the keys that differ from defaults.

        Useful for ``config show --diff``.
        """
        defaults = get_defaults()
        return self._diff_dicts(defaults, self._raw)

    def explain(self, dotted_key: str) -> str:
        """Return a human-readable explanation of a config key."""
        # Simple lookup in the defaults with a description map
        descriptions = {
            "llm.provider": "The LLM provider to use (openai, anthropic, google, ollama, etc.)",
            "llm.model": "The model name (gpt-4o, claude-3-opus, gemini-pro, etc.)",
            "llm.temperature": "Sampling temperature (0.0 = deterministic, 2.0 = very creative)",
            "llm.max_tokens": "Maximum tokens in the LLM response",
            "llm.timeout": "Timeout in seconds for LLM API calls",
            "llm.max_retries": "Number of retries on transient LLM errors",
            "llm.stream": "Whether to stream LLM responses token-by-token",
            "memory.backend": "Vector store backend (chroma, faiss, pinecone, etc.)",
            "memory.embedding_model": "Model used to generate embeddings",
            "memory.short_term_turns": "Number of conversation turns to keep in short-term memory",
            "safety.level": "Safety level 0-5 (0=unrestricted, 5=review-only)",
            "safety.confirm_destructive": "Ask for confirmation before destructive actions",
            "cache.backend": "Cache backend (memory, disk, database)",
            "cache.ttl": "Cache time-to-live in seconds",
            "logging.level": "Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)",
            "ui.theme": "UI theme (dark, light, solarized, monokai, high_contrast)",
            "cost.max_cost_per_task": "Maximum USD cost allowed per task",
            "cost.warning_threshold": "Fraction of budget at which to warn (0.0-1.0)",
        }
        val = self.get_value(dotted_key)
        desc = descriptions.get(dotted_key, "No description available")
        return f"{dotted_key} = {val!r}\n{desc}"

    # ── internals ────────────────────────────────────────────────────

    def _start_watcher(self) -> None:
        """Start the file-system watcher in the background."""
        self._watcher = ConfigWatcher(
            on_change=self._on_file_change,
            watch_global=True,
            watch_project=True,
        )
        try:
            self._watcher.start()
        except Exception:
            logger.warning("Failed to start config watcher", exc_info=True)
            self._watcher = None

    def _on_file_change(self) -> None:
        """Called by the watcher when a config file is modified."""
        try:
            self.reload()
            logger.info("Configuration reloaded after file change")
        except Exception:
            logger.exception("Failed to reload configuration after file change")

    @staticmethod
    def _read_toml(path: Path) -> dict[str, Any]:
        """Read a TOML file and return its contents as a dict."""
        if not path.exists():
            return {}
        try:
            with open(path, "rb") as fh:
                return tomli.load(fh)
        except Exception as exc:
            raise ConfigError(f"Failed to parse {path}: {exc}") from exc

    @staticmethod
    def _apply_defaults(merged: dict[str, Any]) -> dict[str, Any]:
        """Deep-merge defaults under the user config so every key exists."""
        defaults = get_defaults()
        return ConfigMerger._deep_merge(defaults, merged)

    @staticmethod
    def _diff_dicts(
        base: dict[str, Any], current: dict[str, Any], prefix: str = ""
    ) -> dict[str, Any]:
        """Return keys in *current* that differ from *base*."""
        result: dict[str, Any] = {}
        all_keys = set(base) | set(current)
        for key in sorted(all_keys):
            dotted = f"{prefix}.{key}" if prefix else key
            base_val = base.get(key)
            cur_val = current.get(key)
            if isinstance(base_val, dict) and isinstance(cur_val, dict):
                sub = ConfigManager._diff_dicts(base_val, cur_val, dotted)
                result.update(sub)
            elif base_val != cur_val:
                result[dotted] = cur_val
        return result
