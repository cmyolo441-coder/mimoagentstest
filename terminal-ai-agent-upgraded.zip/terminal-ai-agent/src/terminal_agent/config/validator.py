"""Configuration validation.

Validates a merged config dict *before* it is turned into an
``AgentConfig``.  Returns a list of human-readable error strings.
An empty list means the config is valid.
"""

from __future__ import annotations

from typing import Any

from terminal_agent.constants import (
    DEFAULT_LLM_CALLS_PER_MINUTE,
    DEFAULT_TOOL_CALLS_PER_MINUTE,
    MAX_SAFETY_LEVEL,
    PROVIDER_ANTHROPIC,
    PROVIDER_AZURE,
    PROVIDER_BEDROCK,
    PROVIDER_COHERE,
    PROVIDER_CUSTOM,
    PROVIDER_DEEPSEEK,
    PROVIDER_GOOGLE,
    PROVIDER_GROQ,
    PROVIDER_LITELLM,
    PROVIDER_OLLAMA,
    PROVIDER_OPENAI,
    PROVIDER_TOGETHER,
)
from terminal_agent.exceptions import ConfigValidationError


# Accepted values for enum-like fields
_VALID_PROVIDERS = {
    PROVIDER_OPENAI,
    PROVIDER_ANTHROPIC,
    PROVIDER_GOOGLE,
    PROVIDER_OLLAMA,
    PROVIDER_LITELLM,
    PROVIDER_AZURE,
    PROVIDER_BEDROCK,
    PROVIDER_COHERE,
    PROVIDER_TOGETHER,
    PROVIDER_GROQ,
    PROVIDER_DEEPSEEK,
    PROVIDER_CUSTOM,
}

_VALID_SAFETY_LEVELS = set(range(MAX_SAFETY_LEVEL + 1))

_VALID_LOG_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}

_VALID_CACHE_BACKENDS = {"memory", "disk", "database"}

_VALID_CACHE_EVICTION = {"lru", "lfu", "fifo"}

_VALID_VECTOR_BACKENDS = {"chroma", "faiss", "pinecone", "qdrant", "weaviate", "milvus", "memory"}

_VALID_UI_THEMES = {"dark", "light", "solarized", "high_contrast", "monokai"}

_VALID_VERBOSITY = {"quiet", "normal", "verbose", "debug"}

_VALID_LOG_FORMATS = {"structured", "plain", "json"}

_VALID_COMMIT_STYLES = {"conventional", "simple", "detailed"}

_VALID_BUDGET_PERIODS = {"task", "daily", "weekly", "monthly"}

_VALID_EXPORT_FORMATS = {"json", "yaml", "csv", "markdown"}

_VALID_MCP_RETRY = {"exponential", "linear", "fixed"}

_VALID_SPINNER_STYLES = {"dots", "line", "arc", "bouncing_bar", "clock", "earth"}


class ConfigValidator:
    """Validate a merged config dict."""

    # ── public API ───────────────────────────────────────────────────

    @staticmethod
    def validate(cfg: dict[str, Any]) -> list[str]:
        """Return a list of validation errors (empty = valid)."""
        errors: list[str] = []

        ConfigValidator._check_top_level(cfg, errors)
        ConfigValidator._check_llm(cfg.get("llm", {}), errors)
        ConfigValidator._check_memory(cfg.get("memory", {}), errors)
        ConfigValidator._check_safety(cfg.get("safety", {}), errors)
        ConfigValidator._check_tools(cfg.get("tools", {}), errors)
        ConfigValidator._check_cache(cfg.get("cache", {}), errors)
        ConfigValidator._check_logging(cfg.get("logging", {}), errors)
        ConfigValidator._check_ui(cfg.get("ui", {}), errors)
        ConfigValidator._check_git(cfg.get("git", {}), errors)
        ConfigValidator._check_testing(cfg.get("testing", {}), errors)
        ConfigValidator._check_cost(cfg.get("cost", {}), errors)
        ConfigValidator._check_plugin(cfg.get("plugin", {}), errors)
        ConfigValidator._check_mcp(cfg.get("mcp", {}), errors)
        ConfigValidator._check_performance(cfg.get("performance", {}), errors)
        ConfigValidator._check_export(cfg.get("export", {}), errors)

        return errors

    @staticmethod
    def validate_or_raise(cfg: dict[str, Any]) -> None:
        """Validate and raise ``ConfigValidationError`` if anything is wrong."""
        errors = ConfigValidator.validate(cfg)
        if errors:
            raise ConfigValidationError(
                f"Configuration has {len(errors)} error(s)",
                details={"errors": errors},
            )

    # ── top-level ────────────────────────────────────────────────────

    @staticmethod
    def _check_top_level(cfg: dict[str, Any], errors: list[str]) -> None:
        version = cfg.get("config_version")
        if version is not None and not isinstance(version, int):
            errors.append("config_version must be an integer")
        if version is not None and version < 1:
            errors.append("config_version must be >= 1")

    # ── LLM ──────────────────────────────────────────────────────────

    @staticmethod
    def _check_llm(llm: dict[str, Any], errors: list[str]) -> None:
        if not llm:
            return
        _check_in_set(llm, "provider", _VALID_PROVIDERS, errors, section="llm")
        _check_float_range(llm, "temperature", 0.0, 2.0, errors, section="llm")
        _check_int_range(llm, "max_tokens", 1, 1_000_000, errors, section="llm")
        _check_int_range(llm, "timeout", 1, 3600, errors, section="llm")
        _check_int_range(llm, "max_retries", 0, 10, errors, section="llm")
        _check_float_range(llm, "retry_delay", 0.0, 60.0, errors, section="llm")

        # Validate per-provider overrides
        for name, pcfg in llm.get("providers", {}).items():
            if isinstance(pcfg, dict):
                _check_float_range(
                    pcfg, "temperature", 0.0, 2.0, errors, section=f"llm.providers.{name}"
                )
                _check_int_range(
                    pcfg, "max_tokens", 1, 1_000_000, errors, section=f"llm.providers.{name}"
                )

    # ── Memory ───────────────────────────────────────────────────────

    @staticmethod
    def _check_memory(mem: dict[str, Any], errors: list[str]) -> None:
        if not mem:
            return
        _check_in_set(mem, "backend", _VALID_VECTOR_BACKENDS, errors, section="memory")
        _check_int_range(mem, "short_term_turns", 1, 1000, errors, section="memory")
        _check_int_range(mem, "working_memory_files", 1, 100, errors, section="memory")
        _check_int_range(
            mem, "long_term_memories_per_query", 1, 50, errors, section="memory"
        )
        _check_int_range(mem, "consolidation_interval", 60, 86400, errors, section="memory")
        _check_float_range(mem, "decay_rate", 0.0, 1.0, errors, section="memory")
        _check_int_range(mem, "max_memory_size", 100, 1_000_000, errors, section="memory")

    # ── Safety ───────────────────────────────────────────────────────

    @staticmethod
    def _check_safety(safety: dict[str, Any], errors: list[str]) -> None:
        if not safety:
            return
        level = safety.get("level")
        if level is not None and level not in _VALID_SAFETY_LEVELS:
            errors.append(
                f"safety.level must be one of {sorted(_VALID_SAFETY_LEVELS)}, got {level!r}"
            )
        _check_int_range(safety, "max_output_size", 1000, 10_000_000, errors, section="safety")

    # ── Tools ────────────────────────────────────────────────────────

    @staticmethod
    def _check_tools(tools: dict[str, Any], errors: list[str]) -> None:
        if not tools:
            return
        shell = tools.get("shell", {})
        if shell:
            _check_int_range(shell, "timeout", 1, 86400, errors, section="tools.shell")
            _check_int_range(
                shell, "max_output", 1000, 100_000_000, errors, section="tools.shell"
            )
        fs = tools.get("filesystem", {})
        if fs:
            _check_int_range(
                fs, "max_read_size", 1000, 100_000_000, errors, section="tools.filesystem"
            )

    # ── Cache ────────────────────────────────────────────────────────

    @staticmethod
    def _check_cache(cache: dict[str, Any], errors: list[str]) -> None:
        if not cache:
            return
        _check_in_set(cache, "backend", _VALID_CACHE_BACKENDS, errors, section="cache")
        _check_int_range(cache, "max_size", 1, 1_000_000, errors, section="cache")
        _check_int_range(cache, "ttl", 0, 86400 * 30, errors, section="cache")
        _check_in_set(
            cache, "eviction_policy", _VALID_CACHE_EVICTION, errors, section="cache"
        )

    # ── Logging ──────────────────────────────────────────────────────

    @staticmethod
    def _check_logging(log: dict[str, Any], errors: list[str]) -> None:
        if not log:
            return
        _check_in_set(log, "level", _VALID_LOG_LEVELS, errors, section="logging")
        _check_in_set(log, "format", _VALID_LOG_FORMATS, errors, section="logging")
        _check_int_range(
            log, "max_file_size", 1000, 1_000_000_000, errors, section="logging"
        )
        _check_int_range(log, "backup_count", 0, 100, errors, section="logging")

    # ── UI ───────────────────────────────────────────────────────────

    @staticmethod
    def _check_ui(ui: dict[str, Any], errors: list[str]) -> None:
        if not ui:
            return
        _check_in_set(ui, "theme", _VALID_UI_THEMES, errors, section="ui")
        _check_in_set(ui, "verbosity", _VALID_VERBOSITY, errors, section="ui")
        _check_int_range(ui, "max_display_lines", 10, 100_000, errors, section="ui")
        _check_in_set(
            ui, "spinner_style", _VALID_SPINNER_STYLES, errors, section="ui"
        )

    # ── Git ──────────────────────────────────────────────────────────

    @staticmethod
    def _check_git(git: dict[str, Any], errors: list[str]) -> None:
        if not git:
            return
        _check_in_set(
            git, "commit_message_style", _VALID_COMMIT_STYLES, errors, section="git"
        )

    # ── Testing ──────────────────────────────────────────────────────

    @staticmethod
    def _check_testing(testing: dict[str, Any], errors: list[str]) -> None:
        if not testing:
            return
        _check_float_range(
            testing, "coverage_threshold", 0.0, 100.0, errors, section="testing"
        )
        _check_int_range(testing, "timeout", 1, 86400, errors, section="testing")

    # ── Cost ─────────────────────────────────────────────────────────

    @staticmethod
    def _check_cost(cost: dict[str, Any], errors: list[str]) -> None:
        if not cost:
            return
        _check_float_range(
            cost, "max_cost_per_task", 0.0, 100_000.0, errors, section="cost"
        )
        _check_float_range(
            cost, "warning_threshold", 0.0, 1.0, errors, section="cost"
        )
        _check_in_set(
            cost, "budget_period", _VALID_BUDGET_PERIODS, errors, section="cost"
        )
        _check_float_range(cost, "daily_budget", 0.0, 1_000_000.0, errors, section="cost")
        _check_float_range(
            cost, "monthly_budget", 0.0, 1_000_000.0, errors, section="cost"
        )

    # ── Plugin ───────────────────────────────────────────────────────

    @staticmethod
    def _check_plugin(plugin: dict[str, Any], errors: list[str]) -> None:
        # No numeric ranges to check; booleans are self-validating.
        pass

    # ── MCP ──────────────────────────────────────────────────────────

    @staticmethod
    def _check_mcp(mcp: dict[str, Any], errors: list[str]) -> None:
        if not mcp:
            return
        _check_int_range(mcp, "default_timeout", 1, 3600, errors, section="mcp")
        _check_in_set(mcp, "retry_policy", _VALID_MCP_RETRY, errors, section="mcp")
        _check_int_range(mcp, "max_retries", 0, 10, errors, section="mcp")

    # ── Performance ──────────────────────────────────────────────────

    @staticmethod
    def _check_performance(perf: dict[str, Any], errors: list[str]) -> None:
        if not perf:
            return
        _check_int_range(
            perf, "max_parallel_tools", 1, 64, errors, section="performance"
        )
        _check_int_range(
            perf, "default_timeout", 1, 86400, errors, section="performance"
        )
        _check_int_range(
            perf, "context_window_reserve", 0, 100_000, errors, section="performance"
        )
        _check_int_range(
            perf, "max_concurrent_sessions", 1, 100, errors, section="performance"
        )

    # ── Export ───────────────────────────────────────────────────────

    @staticmethod
    def _check_export(export: dict[str, Any], errors: list[str]) -> None:
        if not export:
            return
        _check_in_set(
            export, "default_format", _VALID_EXPORT_FORMATS, errors, section="export"
        )


# ── helper functions ─────────────────────────────────────────────────


def _check_in_set(
    d: dict[str, Any],
    key: str,
    valid: set[Any],
    errors: list[str],
    *,
    section: str = "",
) -> None:
    val = d.get(key)
    if val is not None and val not in valid:
        prefix = f"{section}." if section else ""
        errors.append(
            f"{prefix}{key} must be one of {sorted(valid)}, got {val!r}"
        )


def _check_int_range(
    d: dict[str, Any],
    key: str,
    lo: int,
    hi: int,
    errors: list[str],
    *,
    section: str = "",
) -> None:
    val = d.get(key)
    if val is None:
        return
    if not isinstance(val, int) or isinstance(val, bool):
        prefix = f"{section}." if section else ""
        errors.append(f"{prefix}{key} must be an integer, got {type(val).__name__}")
        return
    if val < lo or val > hi:
        prefix = f"{section}." if section else ""
        errors.append(f"{prefix}{key} must be between {lo} and {hi}, got {val}")


def _check_float_range(
    d: dict[str, Any],
    key: str,
    lo: float,
    hi: float,
    errors: list[str],
    *,
    section: str = "",
) -> None:
    val = d.get(key)
    if val is None:
        return
    if not isinstance(val, (int, float)) or isinstance(val, bool):
        prefix = f"{section}." if section else ""
        errors.append(f"{prefix}{key} must be a number, got {type(val).__name__}")
        return
    if val < lo or val > hi:
        prefix = f"{section}." if section else ""
        errors.append(f"{prefix}{key} must be between {lo} and {hi}, got {val}")
