"""Watch configuration files for live-reload.

Uses the ``watchdog`` library to monitor the global and project config
directories.  When a TOML config file changes the watcher invokes a
callback so the ``ConfigManager`` can re-load and re-validate.
"""

from __future__ import annotations

import logging
import threading
import time
from pathlib import Path
from typing import Any, Callable

from terminal_agent.constants import GLOBAL_CONFIG_FILE, PROJECT_CONFIG_FILE
from terminal_agent.exceptions import ConfigError

logger = logging.getLogger(__name__)

# Type alias for the reload callback
ReloadCallback = Callable[[], None]


class ConfigWatcher:
    """Monitor config files for changes and trigger a reload callback.

    Usage::

        watcher = ConfigWatcher(on_change=my_reload_func)
        watcher.start()
        # ... later ...
        watcher.stop()
    """

    def __init__(
        self,
        on_change: ReloadCallback | None = None,
        debounce_seconds: float = 1.0,
        watch_global: bool = True,
        watch_project: bool = True,
        extra_paths: list[Path] | None = None,
    ) -> None:
        self._on_change = on_change
        self._debounce = debounce_seconds
        self._observer: Any = None
        self._running = False
        self._lock = threading.Lock()
        self._last_trigger: float = 0.0

        # Build the set of directories to watch
        self._watch_dirs: set[Path] = set()
        if watch_global:
            self._watch_dirs.add(GLOBAL_CONFIG_FILE.parent)
        if watch_project:
            self._watch_dirs.add(PROJECT_CONFIG_FILE.parent)
        if extra_paths:
            for p in extra_paths:
                self._watch_dirs.add(p if p.is_dir() else p.parent)

    # ── public API ───────────────────────────────────────────────────

    def start(self) -> None:
        """Start watching in a background thread."""
        if self._running:
            return
        try:
            from watchdog.observers import Observer
            from watchdog.events import (
                FileSystemEventHandler,
                FileModifiedEvent,
                FileCreatedEvent,
            )
        except ImportError:
            logger.warning(
                "watchdog not installed — config file watching disabled. "
                "Install with: pip install watchdog"
            )
            return

        class _Handler(FileSystemEventHandler):
            """Internal handler that delegates to ConfigWatcher."""

            def __init__(self, watcher: ConfigWatcher) -> None:
                super().__init__()
                self._watcher = watcher

            def on_modified(self, event: FileModifiedEvent) -> None:  # type: ignore[override]
                self._watcher._maybe_trigger(event.src_path)

            def on_created(self, event: FileCreatedEvent) -> None:  # type: ignore[override]
                self._watcher._maybe_trigger(event.src_path)

        self._observer = Observer()
        handler = _Handler(self)
        for watch_dir in self._watch_dirs:
            if watch_dir.exists():
                self._observer.schedule(handler, str(watch_dir), recursive=False)
                logger.debug("Watching config directory: %s", watch_dir)

        self._observer.daemon = True
        self._observer.start()
        self._running = True
        logger.info("Config file watcher started")

    def stop(self) -> None:
        """Stop the watcher."""
        if not self._running or self._observer is None:
            return
        self._observer.stop()
        self._observer.join(timeout=5)
        self._running = False
        logger.info("Config file watcher stopped")

    @property
    def is_running(self) -> bool:
        return self._running

    def __enter__(self) -> ConfigWatcher:
        self.start()
        return self

    def __exit__(self, *_: Any) -> None:
        self.stop()

    # ── internals ────────────────────────────────────────────────────

    def _maybe_trigger(self, src_path: str) -> None:
        """Debounced trigger — only fires if the file is a TOML config."""
        path = Path(src_path)
        if path.suffix != ".toml":
            return

        now = time.monotonic()
        with self._lock:
            if now - self._last_trigger < self._debounce:
                return
            self._last_trigger = now

        logger.info("Config file changed: %s", path)
        if self._on_change is not None:
            try:
                self._on_change()
            except Exception:
                logger.exception("Error during config reload callback")
