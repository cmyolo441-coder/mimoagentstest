"""Configuration system for Terminal Agent.

Supports layered configuration with precedence:
    CLI flags > Environment variables > Project config > Global config

All config is TOML-based with encryption for sensitive values,
live file watching, named profiles, and version migration.
"""

from terminal_agent.config.manager import ConfigManager
from terminal_agent.config.schema import (
    AgentConfig,
    CacheConfig,
    CostConfig,
    ExportConfig,
    GitConfig,
    LLMConfig,
    LoggingConfig,
    MCPConfig,
    MemoryConfig,
    PerformanceConfig,
    PluginConfig,
    SafetyConfig,
    TestingConfig,
    ToolsConfig,
    UIConfig,
)
from terminal_agent.config.defaults import get_defaults, get_defaults_flat
from terminal_agent.config.merger import ConfigMerger
from terminal_agent.config.validator import ConfigValidator
from terminal_agent.config.encryption import ConfigEncryption
from terminal_agent.config.watcher import ConfigWatcher
from terminal_agent.config.profiles import ProfileManager
from terminal_agent.config.migration import ConfigMigration

__all__ = [
    # Manager
    "ConfigManager",
    # Schema
    "AgentConfig",
    "LLMConfig",
    "MemoryConfig",
    "SafetyConfig",
    "ToolsConfig",
    "CacheConfig",
    "LoggingConfig",
    "UIConfig",
    "GitConfig",
    "TestingConfig",
    "CostConfig",
    "PluginConfig",
    "MCPConfig",
    "PerformanceConfig",
    "ExportConfig",
    # Defaults
    "get_defaults",
    "get_defaults_flat",
    # Sub-systems
    "ConfigMerger",
    "ConfigValidator",
    "ConfigEncryption",
    "ConfigWatcher",
    "ProfileManager",
    "ConfigMigration",
]
