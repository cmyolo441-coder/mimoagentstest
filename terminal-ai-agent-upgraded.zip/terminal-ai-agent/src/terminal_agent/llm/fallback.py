"""Provider fallback chain.

Tries providers in order until one succeeds.  Supports configurable
retry strategies and automatic provider health tracking.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

from terminal_agent.exceptions import (
    LLMError,
    ProviderError,
    ProviderNotAvailableError,
    RateLimitError,
)
from terminal_agent.llm.base_provider import BaseProvider
from terminal_agent.types import LLMResponse

logger = logging.getLogger(__name__)


@dataclass
class ProviderHealth:
    """Tracks the health status of a single provider."""

    provider: BaseProvider
    consecutive_failures: int = 0
    last_failure_time: float = 0.0
    last_success_time: float = 0.0
    total_calls: int = 0
    total_failures: int = 0
    cooldown_seconds: float = 60.0
    disabled_until: float = 0.0

    @property
    def is_available(self) -> bool:
        """Return ``True`` if this provider is currently usable."""
        if self.disabled_until > time.monotonic():
            return False
        return True

    def record_success(self) -> None:
        """Mark a successful call."""
        self.consecutive_failures = 0
        self.last_success_time = time.monotonic()
        self.total_calls += 1
        self.disabled_until = 0.0

    def record_failure(self) -> None:
        """Mark a failed call and apply exponential backoff."""
        self.consecutive_failures += 1
        self.last_failure_time = time.monotonic()
        self.total_failures += 1
        self.total_calls += 1

        # Exponential backoff: 60s, 120s, 240s, ... capped at 1 hour
        backoff = min(
            self.cooldown_seconds * (2 ** (self.consecutive_failures - 1)),
            3600.0,
        )
        self.disabled_until = time.monotonic() + backoff
        logger.warning(
            "Provider %s failed (%d consecutive). Disabled for %.0fs.",
            self.provider.provider_id,
            self.consecutive_failures,
            backoff,
        )


class FallbackChain:
    """Execute LLM calls through an ordered list of providers.

    Parameters
    ----------
    providers : list[BaseProvider]
        Ordered list of providers to try.  The first provider is the primary;
        subsequent providers are fallbacks.
    max_retries_per_provider : int
        How many times to retry each provider before moving to the next.
    retry_delay : float
        Base delay (seconds) between retries of the same provider.
    """

    def __init__(
        self,
        providers: list[BaseProvider],
        *,
        max_retries_per_provider: int = 2,
        retry_delay: float = 1.0,
    ) -> None:
        if not providers:
            raise ValueError("At least one provider is required")
        self._health = [
            ProviderHealth(provider=p, cooldown_seconds=60.0) for p in providers
        ]
        self._max_retries = max_retries_per_provider
        self._retry_delay = retry_delay

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def primary(self) -> BaseProvider:
        """The first (primary) provider in the chain."""
        return self._health[0].provider

    @property
    def providers(self) -> list[BaseProvider]:
        """All providers in the chain."""
        return [h.provider for h in self._health]

    @property
    def active_provider(self) -> BaseProvider:
        """The first available provider."""
        for h in self._health:
            if h.is_available:
                return h.provider
        # All unavailable — return primary anyway
        return self._health[0].provider

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> LLMResponse:
        """Send a prompt, falling back through providers on failure.

        Tries each provider up to ``max_retries_per_provider`` times.
        If all providers fail, raises the last ``LLMError``.
        """
        last_error: Exception | None = None

        for health in self._health:
            if not health.is_available:
                logger.debug(
                    "Skipping unavailable provider %s",
                    health.provider.provider_id,
                )
                continue

            for attempt in range(1, self._max_retries + 1):
                try:
                    response = await health.provider.send_prompt(messages, **kwargs)
                    health.record_success()
                    return response
                except RateLimitError as exc:
                    logger.warning(
                        "Rate limited by %s (attempt %d/%d)",
                        health.provider.provider_id,
                        attempt,
                        self._max_retries,
                    )
                    last_error = exc
                    # Don't retry rate-limit on same provider; move to next
                    health.record_failure()
                    break
                except (ProviderError, ProviderNotAvailableError) as exc:
                    logger.warning(
                        "Provider %s failed (attempt %d/%d): %s",
                        health.provider.provider_id,
                        attempt,
                        self._max_retries,
                        exc,
                    )
                    last_error = exc
                    if attempt < self._max_retries:
                        await asyncio.sleep(self._retry_delay * attempt)
                except LLMError:
                    raise  # Don't catch application-level LLM errors
                except Exception as exc:
                    logger.error(
                        "Unexpected error from %s: %s",
                        health.provider.provider_id,
                        exc,
                    )
                    last_error = ProviderError(
                        f"Unexpected error from {health.provider.provider_id}: {exc}",
                    )
                    health.record_failure()
                    break

            health.record_failure()

        raise ProviderNotAvailableError(
            "All providers in fallback chain failed",
            details={"last_error": str(last_error) if last_error else None},
        )

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        """Send a prompt with streaming, falling back on failure.

        Note: if the primary provider starts streaming and then fails
        mid-stream, the fallback cannot transparently resume.  In that
        case the error propagates to the caller.
        """
        last_error: Exception | None = None

        for health in self._health:
            if not health.is_available:
                continue

            try:
                async for chunk in health.provider.send_prompt_streaming(
                    messages, **kwargs
                ):
                    yield chunk
                health.record_success()
                return
                # NOTE: once the first chunk is yielded, we're committed
                # to this provider.  If it fails mid-stream the caller
                # sees the error.
            except RateLimitError:
                last_error = RateLimitError(
                    f"Rate limited by {health.provider.provider_id}"
                )
                health.record_failure()
                continue
            except (ProviderError, ProviderNotAvailableError) as exc:
                last_error = exc
                health.record_failure()
                continue
            except LLMError:
                raise
            except Exception as exc:
                last_error = ProviderError(
                    f"Unexpected error from {health.provider.provider_id}: {exc}"
                )
                health.record_failure()
                continue

        raise ProviderNotAvailableError(
            "All providers in fallback chain failed for streaming",
            details={"last_error": str(last_error) if last_error else None},
        )

    # ------------------------------------------------------------------
    # Health queries
    # ------------------------------------------------------------------

    def get_health_report(self) -> list[dict[str, Any]]:
        """Return a health summary for each provider in the chain."""
        return [
            {
                "provider": h.provider.provider_id,
                "available": h.is_available,
                "consecutive_failures": h.consecutive_failures,
                "total_calls": h.total_calls,
                "total_failures": h.total_failures,
                "success_rate": (
                    (h.total_calls - h.total_failures) / h.total_calls
                    if h.total_calls > 0
                    else 1.0
                ),
                "cooldown_remaining": max(
                    0.0, h.disabled_until - time.monotonic()
                ),
            }
            for h in self._health
        ]

    def reset_health(self) -> None:
        """Reset all provider health stats."""
        for h in self._health:
            h.consecutive_failures = 0
            h.disabled_until = 0.0
