"""LLM Engine — provider abstraction, response parsing, cost tracking.

This module provides a unified interface for interacting with multiple LLM
providers (OpenAI, Anthropic, Google, Ollama, etc.) with support for
streaming, tool calling, rate limiting, token counting, cost tracking,
and automatic provider fallback.
"""

from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.cost_tracker import CostTracker, CostRecord
from terminal_agent.llm.engine import LLMEngine
from terminal_agent.llm.fallback import FallbackChain
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.llm.token_counter import TokenCounter

__all__ = [
    "BaseProvider",
    "ProviderCapabilities",
    "CostRecord",
    "CostTracker",
    "FallbackChain",
    "LLMEngine",
    "ResponseParser",
    "TokenCounter",
]
