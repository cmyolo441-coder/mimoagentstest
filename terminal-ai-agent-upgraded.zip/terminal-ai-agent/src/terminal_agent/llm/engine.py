"""Main LLM engine — provider management, call routing, streaming.

The engine is the single entry-point for all LLM interactions.  It owns
a :class:`FallbackChain` of providers, delegates to a
:class:`ResponseParser`, tracks costs via :class:`CostTracker`, and
enforces token budgets through :class:`TokenCounter`.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any, AsyncIterator, Callable

from terminal_agent.constants import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_DELAY,
    DEFAULT_TEMPERATURE,
    DEFAULT_TIMEOUT,
)
from terminal_agent.exceptions import (
    LLMError,
    ProviderError,
    ProviderNotAvailableError,
    RateLimitError,
    ResponseParseError,
    TokenLimitError,
)
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.cost_tracker import CostTracker
from terminal_agent.llm.fallback import FallbackChain
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.llm.token_counter import TokenCounter
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)


class LLMEngine:
    """Unified LLM interface with provider management and call routing.

    Parameters
    ----------
    providers : list[BaseProvider]
        Ordered list of providers (first = primary, rest = fallbacks).
    cost_tracker : CostTracker | None
        If provided, every call's cost is recorded.
    max_retries : int
        Retries per provider within the fallback chain.
    retry_delay : float
        Base delay between retries (seconds).
    """

    def __init__(
        self,
        providers: list[BaseProvider],
        *,
        cost_tracker: CostTracker | None = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_delay: float = DEFAULT_RETRY_DELAY,
    ) -> None:
        if not providers:
            raise ValueError("At least one provider is required")

        self._providers = {p.provider_id: p for p in providers}
        self._fallback = FallbackChain(
            providers,
            max_retries_per_provider=max_retries,
            retry_delay=retry_delay,
        )
        self._cost_tracker = cost_tracker or CostTracker()
        self._parser = ResponseParser()
        self._token_counter = TokenCounter(
            model=providers[0].config.model,
            provider=providers[0].provider_id,
        )
        self._default_temperature = providers[0].config.temperature
        self._default_max_tokens = providers[0].config.max_tokens
        self._on_response_callbacks: list[Callable[[LLMResponse], None]] = []

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def primary_provider(self) -> BaseProvider:
        """The primary (first) provider."""
        return self._fallback.primary

    @property
    def active_provider(self) -> BaseProvider:
        """The currently active provider (first available)."""
        return self._fallback.active_provider

    @property
    def cost_tracker(self) -> CostTracker:
        """The cost tracker instance."""
        return self._cost_tracker

    @property
    def token_counter(self) -> TokenCounter:
        """The token counter instance."""
        return self._token_counter

    @property
    def parser(self) -> ResponseParser:
        """The response parser instance."""
        return self._parser

    # ------------------------------------------------------------------
    # Provider management
    # ------------------------------------------------------------------

    def get_provider(self, provider_id: str) -> BaseProvider | None:
        """Return a provider by ID, or ``None`` if not registered."""
        return self._providers.get(provider_id)

    def add_provider(self, provider: BaseProvider) -> None:
        """Register a new provider and add it to the fallback chain."""
        self._providers[provider.provider_id] = provider
        self._fallback._health.append(
            self._fallback._health[0].__class__(provider=provider)
        )

    def switch_primary(self, provider_id: str) -> None:
        """Switch the primary provider by ID.

        Raises
        ------
        ProviderNotAvailableError
            If the provider is not registered.
        """
        provider = self._providers.get(provider_id)
        if provider is None:
            raise ProviderNotAvailableError(
                f"Provider '{provider_id}' is not registered",
            )
        # Rebuild fallback chain with new primary first
        all_providers = [provider] + [
            h.provider
            for h in self._fallback._health
            if h.provider.provider_id != provider_id
        ]
        self._fallback = FallbackChain(
            all_providers,
            max_retries_per_provider=self._fallback._max_retries,
            retry_delay=self._fallback._retry_delay,
        )
        self._token_counter = TokenCounter(
            model=provider.config.model,
            provider=provider.provider_id,
        )

    # ------------------------------------------------------------------
    # Core call methods
    # ------------------------------------------------------------------

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
        provider: str | None = None,
    ) -> LLMResponse:
        """Send a prompt and return a complete response.

        Parameters
        ----------
        messages : list[dict]
            Conversation messages.
        tools : list[dict] | None
            Tool/function definitions.
        temperature, max_tokens, stop, response_format, extra
            Optional overrides.
        provider : str | None
            Force a specific provider instead of using the fallback chain.

        Returns
        -------
        LLMResponse
            Parsed response.
        """
        temp = temperature if temperature is not None else self._default_temperature
        max_tok = max_tokens if max_tokens is not None else self._default_max_tokens

        # Token budget check
        self._token_counter.check_budget(messages, max_output_tokens=max_tok)

        start_time = time.monotonic()

        if provider:
            target = self._providers.get(provider)
            if target is None:
                raise ProviderNotAvailableError(
                    f"Provider '{provider}' is not registered"
                )
            response = await target.send_prompt(
                messages,
                tools=tools,
                temperature=temp,
                max_tokens=max_tok,
                stop=stop,
                response_format=response_format,
                extra=extra,
            )
        else:
            response = await self._fallback.send_prompt(
                messages,
                tools=tools,
                temperature=temp,
                max_tokens=max_tok,
                stop=stop,
                response_format=response_format,
                extra=extra,
            )

        elapsed_ms = (time.monotonic() - start_time) * 1000
        response.latency_ms = elapsed_ms

        # If provider didn't fill in usage, estimate it
        if response.tokens_in == 0:
            response.tokens_in = self._token_counter.count_messages(messages)
        if response.tokens_out == 0 and response.content:
            response.tokens_out = self._token_counter.count_text(response.content)

        # Calculate cost
        if response.cost == 0.0:
            in_rate, out_rate = self._token_counter.get_cost_rates()
            response.cost = (
                response.tokens_in * in_rate + response.tokens_out * out_rate
            )

        # Record cost
        self._cost_tracker.record(
            provider=response.provider or self.active_provider.provider_id,
            model=response.model or self.active_provider.config.model,
            tokens_in=response.tokens_in,
            tokens_out=response.tokens_out,
            cost_usd=response.cost,
            latency_ms=elapsed_ms,
        )

        # Fire callbacks
        for cb in self._on_response_callbacks:
            try:
                cb(response)
            except Exception:
                logger.debug("Response callback failed", exc_info=True)

        logger.debug(
            "LLM call: provider=%s model=%s tokens_in=%d tokens_out=%d "
            "cost=$%.6f latency=%.0fms",
            response.provider,
            response.model,
            response.tokens_in,
            response.tokens_out,
            response.cost,
            elapsed_ms,
        )

        return response

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
        provider: str | None = None,
    ) -> AsyncIterator[str]:
        """Send a prompt and yield streaming chunks.

        The caller assembles chunks into the final response.
        """
        temp = temperature if temperature is not None else self._default_temperature
        max_tok = max_tokens if max_tokens is not None else self._default_max_tokens

        self._token_counter.check_budget(messages, max_output_tokens=max_tok)

        if provider:
            target = self._providers.get(provider)
            if target is None:
                raise ProviderNotAvailableError(
                    f"Provider '{provider}' is not registered"
                )
            async for chunk in target.send_prompt_streaming(
                messages,
                tools=tools,
                temperature=temp,
                max_tokens=max_tok,
                stop=stop,
                response_format=response_format,
                extra=extra,
            ):
                yield chunk
        else:
            async for chunk in self._fallback.send_prompt_streaming(
                messages,
                tools=tools,
                temperature=temp,
                max_tokens=max_tok,
                stop=stop,
                response_format=response_format,
                extra=extra,
            ):
                yield chunk

    async def send_prompt_and_parse(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
        provider: str | None = None,
    ) -> LLMResponse:
        """Convenience: send prompt, parse response, and ensure tool calls are extracted.

        This is identical to :meth:`send_prompt` for well-behaved providers
        but adds an extra parsing pass for providers that return tool calls
        in non-standard formats.
        """
        response = await self.send_prompt(
            messages,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            stop=stop,
            response_format=response_format,
            extra=extra,
            provider=provider,
        )

        # If we got content but no tool calls, check if content contains
        # JSON-encoded tool calls (some models do this)
        if response.content and not response.tool_calls and tools:
            extracted = self._try_extract_tool_calls_from_text(
                response.content, tools
            )
            if extracted:
                response.tool_calls = extracted

        return response

    # ------------------------------------------------------------------
    # Streaming with full assembly
    # ------------------------------------------------------------------

    async def send_prompt_streaming_assembled(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
        provider: str | None = None,
        on_token: Callable[[str], None] | None = None,
    ) -> LLMResponse:
        """Stream a prompt and assemble the full response.

        Parameters
        ----------
        on_token : callable | None
            Called with each text delta as it arrives (for real-time display).

        Returns
        -------
        LLMResponse
            The assembled response after streaming completes.
        """
        temp = temperature if temperature is not None else self._default_temperature
        max_tok = max_tokens if max_tokens is not None else self._default_max_tokens

        self._token_counter.check_budget(messages, max_output_tokens=max_tok)

        start_time = time.monotonic()
        content_parts: list[str] = []
        usage: dict[str, int] = {}

        target_provider = provider or self.active_provider.provider_id

        async for chunk in self.send_prompt_streaming(
            messages,
            tools=tools,
            temperature=temp,
            max_tokens=max_tok,
            stop=stop,
            response_format=response_format,
            extra=extra,
            provider=provider,
        ):
            # Each provider's streaming yields different formats;
            # the engine normalises them to text deltas.
            if chunk:
                content_parts.append(chunk)
                if on_token:
                    on_token(chunk)

        elapsed_ms = (time.monotonic() - start_time) * 1000
        full_content = "".join(content_parts)

        # Estimate tokens
        tokens_in = self._token_counter.count_messages(messages)
        tokens_out = self._token_counter.count_text(full_content) if full_content else 0

        in_rate, out_rate = self._token_counter.get_cost_rates()
        cost = tokens_in * in_rate + tokens_out * out_rate

        self._cost_tracker.record(
            provider=target_provider,
            model=self.active_provider.config.model,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            cost_usd=cost,
            latency_ms=elapsed_ms,
        )

        return LLMResponse(
            content=full_content,
            tool_calls=[],
            finish_reason="stop",
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            cost=cost,
            latency_ms=elapsed_ms,
            provider=target_provider,
            model=self.active_provider.config.model,
        )

    # ------------------------------------------------------------------
    # Utility methods
    # ------------------------------------------------------------------

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        """Count tokens for the given messages."""
        return self._token_counter.count_messages(messages)

    def get_model_info(self) -> ProviderCapabilities:
        """Return capabilities for the active provider's model."""
        return self.active_provider.get_model_info()

    async def validate_all(self) -> dict[str, bool]:
        """Validate configuration for all registered providers.

        Returns a dict mapping provider_id → validation result.
        """
        results: dict[str, bool] = {}
        for pid, provider in self._providers.items():
            try:
                results[pid] = await provider.validate_config()
            except Exception:
                results[pid] = False
        return results

    def get_cost_summary(self) -> dict[str, Any]:
        """Return a cost summary from the tracker."""
        return self._cost_tracker.summary()

    def get_health_report(self) -> list[dict[str, Any]]:
        """Return provider health from the fallback chain."""
        return self._fallback.get_health_report()

    def on_response(self, callback: Callable[[LLMResponse], None]) -> None:
        """Register a callback that fires after every LLM response."""
        self._on_response_callbacks.append(callback)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close all providers and release resources."""
        for provider in self._providers.values():
            try:
                await provider.close()
            except Exception:
                logger.debug("Error closing provider %s", provider.provider_id, exc_info=True)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _try_extract_tool_calls_from_text(
        content: str,
        tools: list[dict[str, Any]],
    ) -> list:
        """Attempt to extract tool calls from text content.

        Some models (especially weaker ones) emit tool calls as JSON
        blocks in the text instead of using the proper tool_calls field.
        """
        from terminal_agent.types import ToolCall

        tool_names = {t.get("function", {}).get("name", "") for t in tools}

        # Try to find JSON blocks
        try:
            # Look for ```json ... ``` blocks
            import re

            json_blocks = re.findall(r"```json\s*(.*?)\s*```", content, re.DOTALL)
            for block in json_blocks:
                data = json.loads(block)
                if isinstance(data, dict) and "name" in data and data["name"] in tool_names:
                    return [ToolCall(name=data["name"], parameters=data.get("parameters", data.get("arguments", {})))]
                if isinstance(data, list):
                    calls = []
                    for item in data:
                        if isinstance(item, dict) and "name" in item and item["name"] in tool_names:
                            calls.append(ToolCall(name=item["name"], parameters=item.get("parameters", item.get("arguments", {}))))
                    if calls:
                        return calls
        except (json.JSONDecodeError, re.error):
            pass

        # Try direct JSON parse
        try:
            data = json.loads(content.strip())
            if isinstance(data, dict) and "name" in data and data["name"] in tool_names:
                return [ToolCall(name=data["name"], parameters=data.get("parameters", data.get("arguments", {})))]
        except (json.JSONDecodeError, ValueError):
            pass

        return []
