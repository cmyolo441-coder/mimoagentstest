"""Google Gemini message format converter.

Converts between the canonical internal message representation and
the Google Gemini API format.

Key differences from OpenAI:
- Messages are called ``contents`` with ``parts``
- Role is ``user`` or ``model`` (not ``assistant``)
- System message is ``systemInstruction``
- Tool calls use ``functionCall`` parts
- Tool results use ``functionResponse`` parts
"""

from __future__ import annotations

import json
from typing import Any


class GoogleFormat:
    """Converter for the Google Gemini API format."""

    # ------------------------------------------------------------------
    # Canonical → Google
    # ------------------------------------------------------------------

    @staticmethod
    def to_provider(
        messages: list[dict[str, Any]],
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Convert canonical messages to Google Gemini format.

        Returns
        -------
        tuple[str | None, list[dict]]
            ``(system_instruction, contents)``
        """
        system: str | None = None
        contents: list[dict[str, Any]] = []

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                if isinstance(content, str):
                    system = content
                elif isinstance(content, list):
                    system = "\n".join(
                        p.get("text", "") for p in content if isinstance(p, dict)
                    )
                continue

            # Map roles
            gemini_role = "user" if role == "user" else "model"

            # Assistant messages with tool calls
            if role == "assistant" and "tool_calls" in msg:
                parts: list[dict[str, Any]] = []
                if content:
                    parts.append({"text": content})
                for tc in msg["tool_calls"]:
                    func = tc.get("function", tc)
                    args = func.get("arguments", "{}")
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except json.JSONDecodeError:
                            args = {}
                    parts.append({
                        "functionCall": {
                            "name": func.get("name", ""),
                            "args": args,
                        }
                    })
                contents.append({"role": "model", "parts": parts})
                continue

            # Tool result messages
            if role == "tool":
                result_content = content if isinstance(content, str) else json.dumps(content)
                tool_name = msg.get("name", "")
                contents.append({
                    "role": "user",
                    "parts": [{
                        "functionResponse": {
                            "name": tool_name,
                            "response": {"result": result_content},
                        }
                    }],
                })
                continue

            # Regular messages
            if isinstance(content, str):
                contents.append({
                    "role": gemini_role,
                    "parts": [{"text": content}],
                })
            elif isinstance(content, list):
                parts = []
                for part in content:
                    if isinstance(part, dict):
                        if part.get("type") == "text":
                            parts.append({"text": part.get("text", "")})
                        elif part.get("type") == "image_url":
                            url = part.get("image_url", {}).get("url", "")
                            if url.startswith("data:"):
                                mime, _, b64 = url.partition(",")
                                mime = mime.split(":")[1].split(";")[0]
                                parts.append({
                                    "inlineData": {
                                        "mimeType": mime,
                                        "data": b64,
                                    }
                                })
                if parts:
                    contents.append({"role": gemini_role, "parts": parts})

        return system, contents

    # ------------------------------------------------------------------
    # Google → Canonical
    # ------------------------------------------------------------------

    @staticmethod
    def from_provider(
        contents: list[dict[str, Any]],
        system: str | None = None,
    ) -> list[dict[str, Any]]:
        """Convert Google Gemini format to canonical format.

        Parameters
        ----------
        contents : list[dict]
            Gemini ``contents`` array.
        system : str | None
            System instruction (if provided separately).
        """
        result: list[dict[str, Any]] = []

        if system:
            result.append({"role": "system", "content": system})

        for content in contents:
            role = content.get("role", "user")
            parts = content.get("parts", [])

            # Map Gemini role to canonical
            canonical_role = "user" if role == "user" else "assistant"

            text_parts: list[str] = []
            tool_calls: list[dict[str, Any]] = []
            tool_results: list[dict[str, Any]] = []

            for part in parts:
                if "text" in part:
                    text_parts.append(part["text"])
                elif "functionCall" in part:
                    fc = part["functionCall"]
                    tool_calls.append({
                        "id": fc.get("id", ""),
                        "type": "function",
                        "function": {
                            "name": fc.get("name", ""),
                            "arguments": json.dumps(fc.get("args", {})),
                        },
                    })
                elif "functionResponse" in part:
                    fr = part["functionResponse"]
                    tool_results.append({
                        "role": "tool",
                        "tool_call_id": fr.get("id", ""),
                        "name": fr.get("name", ""),
                        "content": json.dumps(fr.get("response", {})),
                    })

            if tool_calls:
                result.append({
                    "role": "assistant",
                    "content": "\n".join(text_parts),
                    "tool_calls": tool_calls,
                })
            elif text_parts:
                result.append({
                    "role": canonical_role,
                    "content": "\n".join(text_parts),
                })

            result.extend(tool_results)

        return result

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @staticmethod
    def format_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Format tool definitions for Google Gemini.

        Returns a ``functionDeclarations`` array.
        """
        func_decls: list[dict[str, Any]] = []
        for tool in tools:
            func = tool.get("function", tool)
            func_decls.append({
                "name": func.get("name", ""),
                "description": func.get("description", ""),
                "parameters": func.get("parameters", {}),
            })
        return [{"functionDeclarations": func_decls}]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def create_user_message(content: str) -> dict[str, Any]:
        """Create a user message."""
        return {"role": "user", "parts": [{"text": content}]}

    @staticmethod
    def create_model_message(content: str) -> dict[str, Any]:
        """Create a model message."""
        return {"role": "model", "parts": [{"text": content}]}

    @staticmethod
    def create_function_call(
        name: str, args: dict[str, Any]
    ) -> dict[str, Any]:
        """Create a function call part."""
        return {"functionCall": {"name": name, "args": args}}

    @staticmethod
    def create_function_response(
        name: str, response: dict[str, Any]
    ) -> dict[str, Any]:
        """Create a function response part."""
        return {"functionResponse": {"name": name, "response": response}}
