"""OpenAI message format converter.

Converts between the canonical internal message representation and
the OpenAI Chat Completions API format.

OpenAI format supports:
- System messages (as ``{"role": "system", ...}``)
- Multimodal content (text + image_url in content arrays)
- Tool calls in assistant messages
- Tool result messages (role: "tool")
- Function calling with JSON schema
"""

from __future__ import annotations

import json
from typing import Any


class OpenAIFormat:
    """Converter for the OpenAI Chat Completions message format."""

    # ------------------------------------------------------------------
    # Canonical → OpenAI
    # ------------------------------------------------------------------

    @staticmethod
    def to_provider(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert canonical messages to OpenAI format.

        The canonical format is already very close to OpenAI; this method
        mainly normalises edge cases.
        """
        result: list[dict[str, Any]] = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            out: dict[str, Any] = {"role": role}

            # Handle content
            if isinstance(content, str):
                out["content"] = content
            elif isinstance(content, list):
                # Already in multimodal format
                out["content"] = content
            else:
                out["content"] = str(content)

            # Handle tool calls
            if "tool_calls" in msg:
                out["tool_calls"] = msg["tool_calls"]

            # Handle tool_call_id (for tool result messages)
            if "tool_call_id" in msg:
                out["tool_call_id"] = msg["tool_call_id"]

            # Handle name field
            if "name" in msg:
                out["name"] = msg["name"]

            result.append(out)

        return result

    # ------------------------------------------------------------------
    # OpenAI → Canonical
    # ------------------------------------------------------------------

    @staticmethod
    def from_provider(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert OpenAI format messages to canonical format."""
        result: list[dict[str, Any]] = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            out: dict[str, Any] = {"role": role, "content": content}

            if "tool_calls" in msg:
                out["tool_calls"] = msg["tool_calls"]
            if "tool_call_id" in msg:
                out["tool_call_id"] = msg["tool_call_id"]
            if "name" in msg:
                out["name"] = msg["name"]

            result.append(out)

        return result

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @staticmethod
    def format_tools(
        tools: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Format tool definitions for OpenAI.

        Accepts tools in either OpenAI format (with ``function`` wrapper)
        or flat format (name, description, parameters directly).

        Returns tools in OpenAI format.
        """
        result: list[dict[str, Any]] = []
        for tool in tools:
            if "function" in tool:
                # Already in OpenAI format
                result.append(tool)
            else:
                # Flat format → wrap in function
                result.append({
                    "type": "function",
                    "function": {
                        "name": tool.get("name", ""),
                        "description": tool.get("description", ""),
                        "parameters": tool.get("parameters", {}),
                    },
                })
        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def create_system_message(content: str) -> dict[str, Any]:
        """Create a system message."""
        return {"role": "system", "content": content}

    @staticmethod
    def create_user_message(content: str | list[dict[str, Any]]) -> dict[str, Any]:
        """Create a user message."""
        return {"role": "user", "content": content}

    @staticmethod
    def create_assistant_message(
        content: str = "",
        tool_calls: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Create an assistant message."""
        msg: dict[str, Any] = {"role": "assistant", "content": content}
        if tool_calls:
            msg["tool_calls"] = tool_calls
        return msg

    @staticmethod
    def create_tool_result(
        tool_call_id: str,
        content: str,
        name: str = "",
    ) -> dict[str, Any]:
        """Create a tool result message."""
        msg: dict[str, Any] = {
            "role": "tool",
            "tool_call_id": tool_call_id,
            "content": content,
        }
        if name:
            msg["name"] = name
        return msg

    @staticmethod
    def create_image_message(
        text: str,
        image_url: str,
        detail: str = "auto",
    ) -> dict[str, Any]:
        """Create a multimodal user message with an image."""
        return {
            "role": "user",
            "content": [
                {"type": "text", "text": text},
                {
                    "type": "image_url",
                    "image_url": {"url": image_url, "detail": detail},
                },
            ],
        }
