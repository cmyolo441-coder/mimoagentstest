"""Anthropic message format converter.

Converts between the canonical internal message representation and
the Anthropic Messages API format.

Key differences from OpenAI:
- System message is a top-level ``system`` parameter, not a message
- Tool calls use ``tool_use`` content blocks
- Tool results use ``tool_result`` content blocks
- Content is always an array of typed blocks
"""

from __future__ import annotations

import json
from typing import Any


class AnthropicFormat:
    """Converter for the Anthropic Messages API format."""

    # ------------------------------------------------------------------
    # Canonical → Anthropic
    # ------------------------------------------------------------------

    @staticmethod
    def to_provider(
        messages: list[dict[str, Any]],
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Convert canonical messages to Anthropic format.

        Returns
        -------
        tuple[str | None, list[dict]]
            ``(system_message, chat_messages)``
        """
        system: str | None = None
        result: list[dict[str, Any]] = []

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                if isinstance(content, str):
                    system = content
                elif isinstance(content, list):
                    system = "\n".join(
                        p.get("text", "") for p in content if isinstance(p, dict)
                    )
                continue

            # Assistant messages with tool calls
            if role == "assistant" and "tool_calls" in msg:
                blocks: list[dict[str, Any]] = []
                if content:
                    blocks.append({"type": "text", "text": content})
                for tc in msg["tool_calls"]:
                    func = tc.get("function", tc)
                    args = func.get("arguments", "{}")
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except json.JSONDecodeError:
                            args = {}
                    blocks.append({
                        "type": "tool_use",
                        "id": tc.get("id", ""),
                        "name": func.get("name", ""),
                        "input": args,
                    })
                result.append({"role": "assistant", "content": blocks})
                continue

            # Tool result messages
            if role == "tool":
                tool_id = msg.get("tool_call_id", "")
                result_content = content if isinstance(content, str) else json.dumps(content)
                result.append({
                    "role": "user",
                    "content": [{
                        "type": "tool_result",
                        "tool_use_id": tool_id,
                        "content": result_content,
                    }],
                })
                continue

            # Regular messages
            if isinstance(content, str):
                result.append({"role": role, "content": content})
            elif isinstance(content, list):
                blocks = []
                for part in content:
                    if isinstance(part, dict):
                        if part.get("type") == "text":
                            blocks.append({"type": "text", "text": part.get("text", "")})
                        elif part.get("type") == "image_url":
                            url = part.get("image_url", {}).get("url", "")
                            if url.startswith("data:"):
                                mime, _, b64 = url.partition(",")
                                mime = mime.split(":")[1].split(";")[0]
                                blocks.append({
                                    "type": "image",
                                    "source": {
                                        "type": "base64",
                                        "media_type": mime,
                                        "data": b64,
                                    },
                                })
                if blocks:
                    result.append({"role": role, "content": blocks})
            else:
                result.append({"role": role, "content": str(content)})

        return system, result

    # ------------------------------------------------------------------
    # Anthropic → Canonical
    # ------------------------------------------------------------------

    @staticmethod
    def from_provider(
        messages: list[dict[str, Any]],
        system: str | None = None,
    ) -> list[dict[str, Any]]:
        """Convert Anthropic format messages to canonical format.

        Parameters
        ----------
        messages : list[dict]
            Anthropic-format messages.
        system : str | None
            System message (if provided separately).
        """
        result: list[dict[str, Any]] = []

        if system:
            result.append({"role": "system", "content": system})

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if isinstance(content, str):
                result.append({"role": role, "content": content})
                continue

            if isinstance(content, list):
                text_parts: list[str] = []
                tool_calls: list[dict[str, Any]] = []
                tool_results: list[dict[str, Any]] = []

                for block in content:
                    if not isinstance(block, dict):
                        continue
                    btype = block.get("type", "")
                    if btype == "text":
                        text_parts.append(block.get("text", ""))
                    elif btype == "tool_use":
                        tool_calls.append({
                            "id": block.get("id"),
                            "type": "function",
                            "function": {
                                "name": block.get("name", ""),
                                "arguments": json.dumps(block.get("input", {})),
                            },
                        })
                    elif btype == "tool_result":
                        tool_results.append({
                            "role": "tool",
                            "tool_call_id": block.get("tool_use_id", ""),
                            "content": block.get("content", ""),
                        })

                if tool_calls:
                    result.append({
                        "role": "assistant",
                        "content": "\n".join(text_parts),
                        "tool_calls": tool_calls,
                    })
                elif text_parts:
                    result.append({"role": role, "content": "\n".join(text_parts)})

                result.extend(tool_results)

        return result

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @staticmethod
    def format_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Format tool definitions for Anthropic.

        Converts OpenAI-style tools to Anthropic format.
        """
        result: list[dict[str, Any]] = []
        for tool in tools:
            func = tool.get("function", tool)
            result.append({
                "name": func.get("name", ""),
                "description": func.get("description", ""),
                "input_schema": func.get("parameters", func.get("input_schema", {})),
            })
        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def create_user_message(content: str) -> dict[str, Any]:
        """Create a user message."""
        return {"role": "user", "content": content}

    @staticmethod
    def create_assistant_message(
        content: str = "",
        tool_calls: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Create an assistant message."""
        if tool_calls:
            blocks: list[dict[str, Any]] = []
            if content:
                blocks.append({"type": "text", "text": content})
            for tc in tool_calls:
                func = tc.get("function", tc)
                args = func.get("arguments", "{}")
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {}
                blocks.append({
                    "type": "tool_use",
                    "id": tc.get("id", ""),
                    "name": func.get("name", ""),
                    "input": args,
                })
            return {"role": "assistant", "content": blocks}
        return {"role": "assistant", "content": content}

    @staticmethod
    def create_tool_result(tool_call_id: str, content: str) -> dict[str, Any]:
        """Create a tool result message."""
        return {
            "role": "user",
            "content": [{
                "type": "tool_result",
                "tool_use_id": tool_call_id,
                "content": content,
            }],
        }
