"""Message format converters.

Each format module converts between a canonical internal representation
and the provider-specific message format.  This allows the engine to
work with a single internal format while supporting provider-specific
quirks (system message handling, tool call formatting, multimodal
content, etc.).
"""

from terminal_agent.llm.formats.openai_format import OpenAIFormat
from terminal_agent.llm.formats.anthropic_format import AnthropicFormat
from terminal_agent.llm.formats.google_format import GoogleFormat
from terminal_agent.llm.formats.generic_format import GenericFormat

__all__ = [
    "OpenAIFormat",
    "AnthropicFormat",
    "GoogleFormat",
    "GenericFormat",
]
