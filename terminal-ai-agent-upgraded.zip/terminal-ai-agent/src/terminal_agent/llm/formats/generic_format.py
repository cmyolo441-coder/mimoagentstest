"""Generic message format converter.

Provides a universal message format that can be used as a common
interchange format between different providers.  This is useful for:
- Serialising messages to disk/database
- Passing messages between modules that don't know about provider specifics
- Testing and debugging

The generic format is a simplified version of the OpenAI format,
without provider-specific extensions.
"""

from __future__ import annotations

import json
from typing import Any


class GenericFormat:
    """Converter for the generic internal message format.

    The generic format is:

    .. code-block:: python

        {
            "role": "system" | "user" | "assistant" | "tool",
            "content": str,
            "tool_calls": list[dict] | None,  # assistant messages only
            "tool_call_id": str | None,        # tool messages only
            "name": str | None,                # optional speaker name
            "metadata": dict | None,           # arbitrary extra data
        }
    """

    # ------------------------------------------------------------------
    # Normalisation
    # ------------------------------------------------------------------

    @staticmethod
    def normalise(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Normalise a list of messages to the generic format.

        Handles various input shapes:
        - String content → kept as-is
        - List content → joined with newlines (text parts only)
        - Missing role → defaults to "user"
        - Extra fields → moved to ``metadata``
        """
        result: list[dict[str, Any]] = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            # Normalise content
            if isinstance(content, list):
                text_parts = []
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        text_parts.append(part.get("text", ""))
                    elif isinstance(part, str):
                        text_parts.append(part)
                content = "\n".join(text_parts)
            elif not isinstance(content, str):
                content = str(content) if content else ""

            out: dict[str, Any] = {"role": role, "content": content}

            # Preserve tool calls
            if "tool_calls" in msg:
                out["tool_calls"] = msg["tool_calls"]

            # Preserve tool_call_id
            if "tool_call_id" in msg:
                out["tool_call_id"] = msg["tool_call_id"]

            # Preserve name
            if "name" in msg:
                out["name"] = msg["name"]

            # Collect extra fields as metadata
            known_keys = {"role", "content", "tool_calls", "tool_call_id", "name", "metadata"}
            extras = {k: v for k, v in msg.items() if k not in known_keys}
            if extras:
                out["metadata"] = extras

            result.append(out)

        return result

    # ------------------------------------------------------------------
    # Conversion to specific formats
    # ------------------------------------------------------------------

    @staticmethod
    def to_openai(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert generic messages to OpenAI format."""
        from terminal_agent.llm.formats.openai_format import OpenAIFormat

        return OpenAIFormat.to_provider(messages)

    @staticmethod
    def to_anthropic(
        messages: list[dict[str, Any]],
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Convert generic messages to Anthropic format."""
        from terminal_agent.llm.formats.anthropic_format import AnthropicFormat

        return AnthropicFormat.to_provider(messages)

    @staticmethod
    def to_google(
        messages: list[dict[str, Any]],
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Convert generic messages to Google Gemini format."""
        from terminal_agent.llm.formats.google_format import GoogleFormat

        return GoogleFormat.to_provider(messages)

    # ------------------------------------------------------------------
    # Conversion from specific formats
    # ------------------------------------------------------------------

    @staticmethod
    def from_openai(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert OpenAI format messages to generic format."""
        return GenericFormat.normalise(messages)

    @staticmethod
    def from_anthropic(
        messages: list[dict[str, Any]],
        system: str | None = None,
    ) -> list[dict[str, Any]]:
        """Convert Anthropic format messages to generic format."""
        from terminal_agent.llm.formats.anthropic_format import AnthropicFormat

        return GenericFormat.normalise(
            AnthropicFormat.from_provider(messages, system=system)
        )

    @staticmethod
    def from_google(
        contents: list[dict[str, Any]],
        system: str | None = None,
    ) -> list[dict[str, Any]]:
        """Convert Google Gemini format messages to generic format."""
        from terminal_agent.llm.formats.google_format import GoogleFormat

        return GenericFormat.normalise(
            GoogleFormat.from_provider(contents, system=system)
        )

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    @staticmethod
    def to_json(messages: list[dict[str, Any]], indent: int = 2) -> str:
        """Serialise messages to a JSON string."""
        return json.dumps(GenericFormat.normalise(messages), indent=indent)

    @staticmethod
    def from_json(json_str: str) -> list[dict[str, Any]]:
        """Deserialise messages from a JSON string."""
        return json.loads(json_str)

    # ------------------------------------------------------------------
    # Message construction helpers
    # ------------------------------------------------------------------

    @staticmethod
    def create_system(content: str) -> dict[str, Any]:
        """Create a system message."""
        return {"role": "system", "content": content}

    @staticmethod
    def create_user(content: str) -> dict[str, Any]:
        """Create a user message."""
        return {"role": "user", "content": content}

    @staticmethod
    def create_assistant(
        content: str = "",
        tool_calls: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Create an assistant message."""
        msg: dict[str, Any] = {"role": "assistant", "content": content}
        if tool_calls:
            msg["tool_calls"] = tool_calls
        return msg

    @staticmethod
    def create_tool_result(
        tool_call_id: str,
        content: str,
        name: str = "",
    ) -> dict[str, Any]:
        """Create a tool result message."""
        msg: dict[str, Any] = {
            "role": "tool",
            "tool_call_id": tool_call_id,
            "content": content,
        }
        if name:
            msg["name"] = name
        return msg

    # ------------------------------------------------------------------
    # Inspection helpers
    # ------------------------------------------------------------------

    @staticmethod
    def extract_system(messages: list[dict[str, Any]]) -> str | None:
        """Extract the system message content, if present."""
        for msg in messages:
            if msg.get("role") == "system":
                content = msg.get("content", "")
                if isinstance(content, list):
                    return "\n".join(
                        p.get("text", "") for p in content if isinstance(p, dict)
                    )
                return content
        return None

    @staticmethod
    def extract_tool_calls(
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Extract all tool calls from assistant messages."""
        calls: list[dict[str, Any]] = []
        for msg in messages:
            if msg.get("role") == "assistant" and "tool_calls" in msg:
                calls.extend(msg["tool_calls"])
        return calls

    @staticmethod
    def get_last_user_message(
        messages: list[dict[str, Any]],
    ) -> str | None:
        """Return the content of the last user message."""
        for msg in reversed(messages):
            if msg.get("role") == "user":
                content = msg.get("content", "")
                if isinstance(content, str):
                    return content
                if isinstance(content, list):
                    return "\n".join(
                        p.get("text", "") for p in content if isinstance(p, dict)
                    )
        return None

    @staticmethod
    def estimate_tokens(messages: list[dict[str, Any]]) -> int:
        """Rough token count estimate (4 chars ≈ 1 token)."""
        total = 0
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                total += len(content)
            elif isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        total += len(part.get("text", ""))
            # Overhead per message
            total += 4
        return max(1, total // 4)
