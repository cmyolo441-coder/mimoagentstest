"""Parse raw LLM responses into structured ``LLMResponse`` objects.

Handles the differences between provider response formats and extracts:
- Text content
- Tool / function calls
- Reasoning / thinking traces
- Usage statistics
- Finish reasons
"""

from __future__ import annotations

import json
import re
from typing import Any

from terminal_agent.exceptions import ResponseParseError
from terminal_agent.types import LLMResponse, ToolCall


class ResponseParser:
    """Stateless parser that normalises provider-specific responses."""

    # Known finish reasons across providers
    _STOP_REASONS = {"stop", "end_turn", "complete", "finished", "STOP"}
    _LENGTH_REASONS = {"length", "max_tokens", "MAX_TOKENS"}
    _TOOL_REASONS = {"tool_calls", "function_call", "tool_use", "TOOL_CALLS"}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def parse_openai(self, data: dict[str, Any]) -> LLMResponse:
        """Parse an OpenAI-compatible chat completion response."""
        try:
            choice = data["choices"][0]
            message = choice.get("message", {})
            usage = data.get("usage", {})

            content = message.get("content") or ""
            reasoning = message.get("reasoning_content") or message.get("thinking") or None
            tool_calls = self._extract_openai_tool_calls(message.get("tool_calls", []))
            finish = choice.get("finish_reason", "stop")

            return LLMResponse(
                content=content,
                tool_calls=tool_calls,
                reasoning=reasoning,
                finish_reason=finish,
                tokens_in=usage.get("prompt_tokens", 0),
                tokens_out=usage.get("completion_tokens", 0),
                provider=data.get("_provider", "openai"),
                model=data.get("model", ""),
            )
        except (KeyError, IndexError, TypeError) as exc:
            raise ResponseParseError(
                f"Failed to parse OpenAI response: {exc}",
                details={"raw": data},
            ) from exc

    def parse_anthropic(self, data: dict[str, Any]) -> LLMResponse:
        """Parse an Anthropic Messages API response."""
        try:
            content_blocks = data.get("content", [])
            usage = data.get("usage", {})

            text_parts: list[str] = []
            reasoning_parts: list[str] = []
            tool_calls: list[ToolCall] = []

            for block in content_blocks:
                btype = block.get("type", "")
                if btype == "text":
                    text_parts.append(block.get("text", ""))
                elif btype == "thinking":
                    reasoning_parts.append(block.get("thinking", ""))
                elif btype == "tool_use":
                    tool_calls.append(
                        ToolCall(
                            id=block.get("id"),
                            name=block.get("name", ""),
                            parameters=block.get("input", {}),
                        )
                    )

            return LLMResponse(
                content="\n".join(text_parts),
                tool_calls=tool_calls,
                reasoning="\n".join(reasoning_parts) or None,
                finish_reason=data.get("stop_reason", "end_turn"),
                tokens_in=usage.get("input_tokens", 0),
                tokens_out=usage.get("output_tokens", 0),
                provider="anthropic",
                model=data.get("model", ""),
            )
        except (KeyError, TypeError) as exc:
            raise ResponseParseError(
                f"Failed to parse Anthropic response: {exc}",
                details={"raw": data},
            ) from exc

    def parse_google(self, data: dict[str, Any]) -> LLMResponse:
        """Parse a Google Gemini API response."""
        try:
            candidates = data.get("candidates", [])
            if not candidates:
                raise ResponseParseError("No candidates in Google response")

            candidate = candidates[0]
            parts = candidate.get("content", {}).get("parts", [])
            usage = data.get("usageMetadata", {})

            text_parts: list[str] = []
            reasoning_parts: list[str] = []
            tool_calls: list[ToolCall] = []

            for part in parts:
                if "text" in part:
                    # Check for thinking tags
                    txt = part["text"]
                    think_match = re.search(
                        r"<thinking>(.*?)</thinking>", txt, re.DOTALL
                    )
                    if think_match:
                        reasoning_parts.append(think_match.group(1).strip())
                        txt = txt[: think_match.start()] + txt[think_match.end() :]
                    if txt.strip():
                        text_parts.append(txt)
                elif "functionCall" in part:
                    fc = part["functionCall"]
                    tool_calls.append(
                        ToolCall(
                            id=fc.get("id"),
                            name=fc.get("name", ""),
                            parameters=fc.get("args", {}),
                        )
                    )

            finish = candidate.get("finishReason", "STOP")

            return LLMResponse(
                content="\n".join(text_parts),
                tool_calls=tool_calls,
                reasoning="\n".join(reasoning_parts) or None,
                finish_reason=finish,
                tokens_in=usage.get("promptTokenCount", 0),
                tokens_out=usage.get("candidatesTokenCount", 0),
                provider="google",
                model=data.get("model", ""),
            )
        except (KeyError, IndexError, TypeError) as exc:
            raise ResponseParseError(
                f"Failed to parse Google response: {exc}",
                details={"raw": data},
            ) from exc

    def parse_generic_openai(self, data: dict[str, Any]) -> LLMResponse:
        """Parse a generic OpenAI-compatible response (Ollama, vLLM, etc.)."""
        # Most OpenAI-compatible APIs follow the same schema.
        return self.parse_openai(data)

    def parse_ollama(self, data: dict[str, Any]) -> LLMResponse:
        """Parse an Ollama /api/chat response."""
        try:
            message = data.get("message", {})
            content = message.get("content", "")
            tool_calls = self._extract_openai_tool_calls(
                message.get("tool_calls", [])
            )

            return LLMResponse(
                content=content,
                tool_calls=tool_calls,
                finish_reason="stop" if data.get("done") else "length",
                tokens_in=data.get("prompt_eval_count", 0),
                tokens_out=data.get("eval_count", 0),
                provider="ollama",
                model=data.get("model", ""),
            )
        except (KeyError, TypeError) as exc:
            raise ResponseParseError(
                f"Failed to parse Ollama response: {exc}",
                details={"raw": data},
            ) from exc

    # ------------------------------------------------------------------
    # Streaming chunk parsers
    # ------------------------------------------------------------------

    def parse_openai_chunk(self, data: dict[str, Any]) -> dict[str, Any]:
        """Parse a single OpenAI SSE chunk.

        Returns a dict with keys: ``delta_content``, ``delta_tool_calls``,
        ``finish_reason``, ``usage``.
        """
        result: dict[str, Any] = {
            "delta_content": None,
            "delta_tool_calls": [],
            "finish_reason": None,
            "usage": None,
        }
        choices = data.get("choices", [])
        if choices:
            delta = choices[0].get("delta", {})
            result["delta_content"] = delta.get("content")
            if "tool_calls" in delta:
                result["delta_tool_calls"] = delta["tool_calls"]
            result["finish_reason"] = choices[0].get("finish_reason")
        if "usage" in data:
            result["usage"] = data["usage"]
        return result

    def parse_anthropic_chunk(self, event: str, data: dict[str, Any]) -> dict[str, Any]:
        """Parse a single Anthropic SSE event.

        Parameters
        ----------
        event : str
            The SSE event type (``content_block_delta``, ``message_stop``, etc.).
        data : dict
            The parsed JSON payload.

        Returns
        -------
        dict
            Keys: ``delta_content``, ``delta_tool_calls``, ``finish_reason``,
            ``delta_thinking``, ``usage``.
        """
        result: dict[str, Any] = {
            "delta_content": None,
            "delta_tool_calls": [],
            "delta_thinking": None,
            "finish_reason": None,
            "usage": None,
        }
        if event == "content_block_delta":
            delta = data.get("delta", {})
            dtype = delta.get("type", "")
            if dtype == "text_delta":
                result["delta_content"] = delta.get("text")
            elif dtype == "thinking_delta":
                result["delta_thinking"] = delta.get("thinking")
            elif dtype == "input_json_delta":
                result["delta_tool_calls"] = [delta]
        elif event == "message_stop":
            result["finish_reason"] = "end_turn"
        elif event == "message_delta":
            usage = data.get("usage", {})
            if usage:
                result["usage"] = usage
            stop = data.get("delta", {}).get("stop_reason")
            if stop:
                result["finish_reason"] = stop
        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_openai_tool_calls(raw: list[dict[str, Any]]) -> list[ToolCall]:
        """Convert raw OpenAI tool-call dicts into ``ToolCall`` objects."""
        calls: list[ToolCall] = []
        for tc in raw:
            func = tc.get("function", {})
            args = func.get("arguments", "{}")
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {}
            calls.append(
                ToolCall(
                    id=tc.get("id"),
                    name=func.get("name", ""),
                    parameters=args,
                )
            )
        return calls

    def is_complete(self, response: LLMResponse) -> bool:
        """Return ``True`` if the response indicates normal completion."""
        return response.finish_reason in self._STOP_REASONS

    def is_truncated(self, response: LLMResponse) -> bool:
        """Return ``True`` if the response hit a length limit."""
        return response.finish_reason in self._LENGTH_REASONS

    def has_tool_calls(self, response: LLMResponse) -> bool:
        """Return ``True`` if the response contains tool calls."""
        return len(response.tool_calls) > 0

    def merge_streaming_chunks(
        self,
        chunks: list[dict[str, Any]],
        *,
        provider: str = "openai",
    ) -> LLMResponse:
        """Assemble streaming chunks into a single ``LLMResponse``.

        This is a convenience for callers that accumulate chunks themselves
        instead of relying on the engine's streaming helper.
        """
        content_parts: list[str] = []
        thinking_parts: list[str] = []
        tool_calls_raw: dict[int, dict[str, Any]] = {}
        finish_reason: str | None = None
        usage: dict[str, int] = {}

        for chunk in chunks:
            if chunk.get("delta_content"):
                content_parts.append(chunk["delta_content"])
            if chunk.get("delta_thinking"):
                thinking_parts.append(chunk["delta_thinking"])
            if chunk.get("finish_reason"):
                finish_reason = chunk["finish_reason"]
            if chunk.get("usage"):
                usage = chunk["usage"]
            for tc_delta in chunk.get("delta_tool_calls", []):
                idx = tc_delta.get("index", 0)
                if idx not in tool_calls_raw:
                    tool_calls_raw[idx] = {"id": "", "function": {"name": "", "arguments": ""}}
                entry = tool_calls_raw[idx]
                if tc_delta.get("id"):
                    entry["id"] = tc_delta["id"]
                func = tc_delta.get("function", {})
                if func.get("name"):
                    entry["function"]["name"] = func["name"]
                if func.get("arguments"):
                    entry["function"]["arguments"] += func["arguments"]

        tool_calls = self._extract_openai_tool_calls(list(tool_calls_raw.values()))

        return LLMResponse(
            content="".join(content_parts),
            tool_calls=tool_calls,
            reasoning="".join(thinking_parts) or None,
            finish_reason=finish_reason or "stop",
            tokens_in=usage.get("prompt_tokens", 0),
            tokens_out=usage.get("completion_tokens", 0),
            provider=provider,
            model="",
        )
