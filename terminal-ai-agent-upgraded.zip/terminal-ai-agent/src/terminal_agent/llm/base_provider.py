"""Abstract base provider interface for LLM backends.

Every concrete provider (OpenAI, Anthropic, Google, Ollama, etc.) must
implement this interface.  The engine only talks to providers through
this contract, making the system fully model-agnostic.
"""

from __future__ import annotations

import abc
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import (
    ProviderError,
    ProviderNotAvailableError,
    RateLimitError,
    TokenLimitError,
)
from terminal_agent.types import LLMResponse, ProviderConfig, ToolCall


# ---------------------------------------------------------------------------
# Capability descriptor
# ---------------------------------------------------------------------------

@dataclass
class ProviderCapabilities:
    """Describes what a provider / model combination supports."""

    streaming: bool = True
    tool_calling: bool = True
    vision: bool = False
    json_mode: bool = False
    max_context_tokens: int = 128_000
    max_output_tokens: int = 4_096
    supports_system_message: bool = True
    supports_temperature: bool = True
    supports_seed: bool = False
    supports_stop_sequences: bool = True
    supports_parallel_tool_calls: bool = True
    supports_response_format: bool = False
    cost_per_input_token: float = 0.0
    cost_per_output_token: float = 0.0


# ---------------------------------------------------------------------------
# Rate-limiter helper (per-provider token bucket)
# ---------------------------------------------------------------------------

class _RateLimiter:
    """Simple async token-bucket rate limiter."""

    def __init__(self, calls_per_minute: int = 60, burst: int = 10):
        self._calls_per_minute = calls_per_minute
        self._burst = burst
        self._tokens = float(burst)
        self._last_refill = time.monotonic()
        self._lock: Any = None  # created lazily

    async def acquire(self) -> None:
        """Wait until a request slot is available."""
        import asyncio

        if self._lock is None:
            self._lock = asyncio.Lock()

        async with self._lock:
            now = time.monotonic()
            elapsed = now - self._last_refill
            self._tokens = min(
                self._burst,
                self._tokens + elapsed * (self._calls_per_minute / 60.0),
            )
            self._last_refill = now

            if self._tokens < 1.0:
                wait = (1.0 - self._tokens) / (self._calls_per_minute / 60.0)
                await asyncio.sleep(wait)
                self._tokens = 0.0
                self._last_refill = time.monotonic()
            else:
                self._tokens -= 1.0


# ---------------------------------------------------------------------------
# Abstract base provider
# ---------------------------------------------------------------------------

class BaseProvider(abc.ABC):
    """Contract every LLM provider must implement.

    Parameters
    ----------
    config : ProviderConfig
        Provider-level configuration (API key, base URL, model, etc.).
    http_client : httpx.AsyncClient | None
        Shared HTTP client.  If ``None`` the provider creates its own.
    """

    # Subclasses should set this to a stable identifier.
    provider_id: str = "base"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self.config = config
        self._http = http_client or httpx.AsyncClient(timeout=config.timeout)
        self._owns_client = http_client is None
        self._rate_limiter = _RateLimiter(
            calls_per_minute=60,
            burst=10,
        )

    # -- lifecycle -----------------------------------------------------------

    async def close(self) -> None:
        """Release resources (HTTP client, etc.)."""
        if self._owns_client:
            await self._http.aclose()

    # -- abstract interface --------------------------------------------------

    @abc.abstractmethod
    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        """Send a prompt and return a complete response.

        Parameters
        ----------
        messages : list[dict]
            Conversation messages in provider-native format.
        tools : list[dict] | None
            Tool/function definitions for tool calling.
        temperature, max_tokens, stop, response_format, extra
            Optional overrides.

        Returns
        -------
        LLMResponse
            Parsed response with content, tool calls, usage, etc.
        """
        ...

    @abc.abstractmethod
    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        """Send a prompt and yield response chunks as they arrive.

        The caller assembles chunks into the final response.  Each yielded
        value is a raw text delta (or a JSON-encoded tool-call delta).
        """
        ...

    @abc.abstractmethod
    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        """Return the token count for *messages* using this provider's tokenizer."""
        ...

    @abc.abstractmethod
    def get_model_info(self) -> ProviderCapabilities:
        """Return capability / limit metadata for the current model."""
        ...

    @abc.abstractmethod
    async def validate_config(self) -> bool:
        """Validate provider configuration (e.g. key, endpoint reachable).

        Raises
        ------
        ProviderNotAvailableError
            If the provider cannot be reached or the config is invalid.
        """
        ...

    # -- convenience ---------------------------------------------------------

    async def rate_limit(self) -> None:
        """Wait if needed to respect rate limits."""
        await self._rate_limiter.acquire()

    def _build_headers(self) -> dict[str, str]:
        """Default header builder — override for custom auth schemes."""
        return {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _handle_http_error(self, status: int, body: str) -> None:
        """Translate HTTP status codes into typed exceptions."""
        if status == 429:
            raise RateLimitError(
                f"Rate limited by {self.provider_id}",
                details={"status": status, "body": body},
            )
        if status == 401:
            raise ProviderNotAvailableError(
                f"Authentication failed for {self.provider_id}",
                details={"status": status},
            )
        if status in (502, 503, 504):
            raise ProviderNotAvailableError(
                f"{self.provider_id} is temporarily unavailable (HTTP {status})",
                details={"status": status, "body": body},
            )
        raise ProviderError(
            f"{self.provider_id} returned HTTP {status}: {body[:500]}",
            details={"status": status, "body": body},
        )

    def _handle_rate_limit_response(self, headers: dict[str, str]) -> None:
        """Inspect response headers for rate-limit signals."""
        retry_after = headers.get("retry-after") or headers.get("Retry-After")
        if retry_after:
            raise RateLimitError(
                f"Rate limited by {self.provider_id}, retry after {retry_after}s",
                details={"retry_after": retry_after},
            )
