"""Mistral AI API provider.

Supports Mistral Large, Small, Codestral, and all Mistral models
via the Mistral Chat Completions API.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import ProviderNotAvailableError
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)

_MODEL_CAPS: dict[str, dict[str, Any]] = {
    "mistral-large": {
        "max_context_tokens": 128_000,
        "max_output_tokens": 8_192,
        "cost_per_input_token": 2e-6,
        "cost_per_output_token": 6e-6,
    },
    "mistral-small": {
        "max_context_tokens": 128_000,
        "max_output_tokens": 8_192,
        "cost_per_input_token": 0.2e-6,
        "cost_per_output_token": 0.6e-6,
    },
    "codestral": {
        "max_context_tokens": 256_000,
        "max_output_tokens": 8_192,
        "cost_per_input_token": 0.3e-6,
        "cost_per_output_token": 0.9e-6,
    },
}


class MistralProvider(BaseProvider):
    """Mistral AI Chat Completions API provider.

    Parameters
    ----------
    config : ProviderConfig
        Must include ``api_key``.  ``base_url`` defaults to Mistral API.
    http_client : httpx.AsyncClient | None
        Shared HTTP client.
    """

    provider_id = "mistral"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        self._base_url = (config.base_url or "https://api.mistral.ai/v1").rstrip("/")
        self._parser = ResponseParser()
        self._api_key = config.api_key

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()
        payload: dict[str, Any] = {"model": self.config.model, "messages": messages, "stream": False}
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop:
            payload["stop"] = stop
        if tools:
            payload["tools"] = tools
        if response_format:
            payload["response_format"] = response_format
        if extra:
            payload.update(extra)

        headers = self._build_headers()
        headers["Authorization"] = f"Bearer {self._api_key}"

        resp = await self._http.post(f"{self._base_url}/chat/completions", headers=headers, json=payload)
        if resp.status_code != 200:
            self._handle_rate_limit_response(dict(resp.headers))
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        data["_provider"] = self.provider_id
        return self._parser.parse_openai(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()
        payload: dict[str, Any] = {"model": self.config.model, "messages": messages, "stream": True}
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop:
            payload["stop"] = stop
        if tools:
            payload["tools"] = tools
        if response_format:
            payload["response_format"] = response_format
        if extra:
            payload.update(extra)

        headers = self._build_headers()
        headers["Authorization"] = f"Bearer {self._api_key}"

        async with self._http.stream("POST", f"{self._base_url}/chat/completions", headers=headers, json=payload) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_rate_limit_response(dict(resp.headers))
                self._handle_http_error(resp.status_code, body.decode())
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    parsed = self._parser.parse_openai_chunk(chunk)
                    if parsed["delta_content"]:
                        yield parsed["delta_content"]
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter
        return TokenCounter(model=self.config.model, provider=self.provider_id).count_messages(messages)

    def get_model_info(self) -> ProviderCapabilities:
        caps = ProviderCapabilities(
            max_context_tokens=128_000,
            max_output_tokens=8_192,
            tool_calling=True,
            json_mode=True,
        )
        for prefix, info in _MODEL_CAPS.items():
            if self.config.model.startswith(prefix):
                for k, v in info.items():
                    if hasattr(caps, k):
                        setattr(caps, k, v)
                break
        return caps

    async def validate_config(self) -> bool:
        if not self._api_key:
            raise ProviderNotAvailableError("Mistral API key is not set")
        try:
            resp = await self._http.get(
                f"{self._base_url}/models",
                headers={"Authorization": f"Bearer {self._api_key}"},
                timeout=10.0,
            )
            return resp.status_code == 200
        except httpx.RequestError as exc:
            raise ProviderNotAvailableError(f"Cannot reach Mistral API: {exc}") from exc
