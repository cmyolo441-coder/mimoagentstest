"""Cohere API provider.

Supports Command, Command R, Command R+ models via the Cohere Chat API.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import ProviderNotAvailableError
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)


class CohereProvider(BaseProvider):
    """Cohere Chat API provider.

    Parameters
    ----------
    config : ProviderConfig
        Must include ``api_key``.  ``base_url`` defaults to the Cohere API.
    http_client : httpx.AsyncClient | None
        Shared HTTP client.
    """

    provider_id = "cohere"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        self._base_url = (config.base_url or "https://api.cohere.com/v2").rstrip("/")
        self._api_key = config.api_key

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()

        # Extract system message
        system = None
        chat_messages = []
        for msg in messages:
            if msg.get("role") == "system":
                system = msg.get("content", "")
            else:
                chat_messages.append(msg)

        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": chat_messages,
        }
        if system:
            payload["preamble"] = system
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop:
            payload["stop_sequences"] = stop
        if tools:
            cohere_tools = []
            for tool in tools:
                func = tool.get("function", tool)
                cohere_tools.append({
                    "name": func.get("name", ""),
                    "description": func.get("description", ""),
                    "parameter_definitions": self._convert_params(func.get("parameters", {})),
                })
            payload["tools"] = cohere_tools
        if extra:
            payload.update(extra)

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

        resp = await self._http.post(f"{self._base_url}/chat", headers=headers, json=payload)
        if resp.status_code != 200:
            self._handle_rate_limit_response(dict(resp.headers))
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        return self._parse_response(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()

        system = None
        chat_messages = []
        for msg in messages:
            if msg.get("role") == "system":
                system = msg.get("content", "")
            else:
                chat_messages.append(msg)

        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": chat_messages,
            "stream": True,
        }
        if system:
            payload["preamble"] = system
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop:
            payload["stop_sequences"] = stop
        if extra:
            payload.update(extra)

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

        async with self._http.stream("POST", f"{self._base_url}/chat", headers=headers, json=payload) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_rate_limit_response(dict(resp.headers))
                self._handle_http_error(resp.status_code, body.decode())
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                try:
                    chunk = json.loads(line[6:])
                    if chunk.get("type") == "content-delta":
                        text = chunk.get("delta", {}).get("message", {}).get("content", {}).get("text", "")
                        if text:
                            yield text
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter
        return TokenCounter(model=self.config.model, provider=self.provider_id)._count_heuristic(
            " ".join(m.get("content", "") for m in messages if isinstance(m.get("content"), str))
        )

    def get_model_info(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            max_context_tokens=128_000,
            max_output_tokens=4_096,
            tool_calling=True,
            vision=False,
            supports_seed=False,
            supports_response_format=False,
        )

    async def validate_config(self) -> bool:
        if not self._api_key:
            raise ProviderNotAvailableError("Cohere API key is not set")
        try:
            resp = await self._http.get(
                f"{self._base_url}/check-api-key",
                headers={"Authorization": f"Bearer {self._api_key}"},
                timeout=10.0,
            )
            return resp.status_code == 200
        except httpx.RequestError as exc:
            raise ProviderNotAvailableError(f"Cannot reach Cohere API: {exc}") from exc

    # -- helpers -------------------------------------------------------------

    def _parse_response(self, data: dict[str, Any]) -> LLMResponse:
        from terminal_agent.types import ToolCall

        message = data.get("message", {})
        content = message.get("content", [{}])
        text = content[0].get("text", "") if content else ""

        tool_calls = []
        for tc in message.get("tool_calls", []):
            tool_calls.append(ToolCall(
                id=tc.get("id"),
                name=tc.get("name", ""),
                parameters=tc.get("parameters", {}),
            ))

        usage = data.get("usage", {})

        return LLMResponse(
            content=text,
            tool_calls=tool_calls,
            finish_reason=message.get("finish_reason", "COMPLETE"),
            tokens_in=usage.get("tokens", {}).get("input_tokens", 0),
            tokens_out=usage.get("tokens", {}).get("output_tokens", 0),
            provider=self.provider_id,
            model=self.config.model,
        )

    @staticmethod
    def _convert_params(schema: dict[str, Any]) -> dict[str, Any]:
        """Convert JSON Schema properties to Cohere parameter_definitions."""
        properties = schema.get("properties", {})
        required = set(schema.get("required", []))
        result = {}
        for name, prop in properties.items():
            result[name] = {
                "description": prop.get("description", ""),
                "type": prop.get("type", "string"),
                "required": name in required,
            }
        return result
