"""Google Gemini API provider.

Supports Gemini 2.5 Pro, 2.0 Flash, 1.5 Pro, and all Gemini models via
the Google AI Generative Language API.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import ProviderNotAvailableError
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)

_MODEL_CAPS: dict[str, dict[str, Any]] = {
    "gemini-2.5-pro": {
        "max_context_tokens": 1_048_576,
        "max_output_tokens": 65_536,
        "vision": True,
        "cost_per_input_token": 1.25e-6,
        "cost_per_output_token": 10e-6,
    },
    "gemini-2.5-flash": {
        "max_context_tokens": 1_048_576,
        "max_output_tokens": 65_536,
        "vision": True,
        "cost_per_input_token": 0.15e-6,
        "cost_per_output_token": 0.6e-6,
    },
    "gemini-2.0-flash": {
        "max_context_tokens": 1_048_576,
        "max_output_tokens": 8_192,
        "vision": True,
        "cost_per_input_token": 0.1e-6,
        "cost_per_output_token": 0.4e-6,
    },
    "gemini-1.5-pro": {
        "max_context_tokens": 2_097_152,
        "max_output_tokens": 8_192,
        "vision": True,
        "cost_per_input_token": 1.25e-6,
        "cost_per_output_token": 5e-6,
    },
    "gemini-1.5-flash": {
        "max_context_tokens": 1_048_576,
        "max_output_tokens": 8_192,
        "vision": True,
        "cost_per_input_token": 0.075e-6,
        "cost_per_output_token": 0.3e-6,
    },
}


class GoogleProvider(BaseProvider):
    """Google Gemini API provider.

    Parameters
    ----------
    config : ProviderConfig
        Must include ``api_key``.  ``base_url`` defaults to the Google AI API.
    http_client : httpx.AsyncClient | None
        Shared HTTP client.
    """

    provider_id = "google"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        self._base_url = (
            config.base_url or "https://generativelanguage.googleapis.com"
        ).rstrip("/")
        self._parser = ResponseParser()
        self._api_key = config.api_key

    # -- abstract implementation ---------------------------------------------

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()

        system_msg, contents = self._convert_messages(messages)
        payload = self._build_payload(
            contents,
            system=system_msg,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            stop=stop,
            extra=extra,
        )

        model = self.config.model
        resp = await self._http.post(
            f"{self._base_url}/v1beta/models/{model}:generateContent",
            params={"key": self._api_key},
            headers={"Content-Type": "application/json"},
            json=payload,
        )

        if resp.status_code != 200:
            self._handle_rate_limit_response(dict(resp.headers))
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        return self._parser.parse_google(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()

        system_msg, contents = self._convert_messages(messages)
        payload = self._build_payload(
            contents,
            system=system_msg,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            stop=stop,
            extra=extra,
        )

        model = self.config.model
        async with self._http.stream(
            "POST",
            f"{self._base_url}/v1beta/models/{model}:streamGenerateContent",
            params={"key": self._api_key, "alt": "sse"},
            headers={"Content-Type": "application/json"},
            json=payload,
        ) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_rate_limit_response(dict(resp.headers))
                self._handle_http_error(resp.status_code, body.decode())

            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                try:
                    chunk = json.loads(data_str)
                    candidates = chunk.get("candidates", [])
                    if candidates:
                        parts = candidates[0].get("content", {}).get("parts", [])
                        for part in parts:
                            if "text" in part:
                                yield part["text"]
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter

        counter = TokenCounter(model=self.config.model, provider=self.provider_id)
        return counter.count_messages(messages)

    def get_model_info(self) -> ProviderCapabilities:
        caps = ProviderCapabilities()
        caps.supports_seed = False
        caps.supports_stop_sequences = True
        for prefix, info in _MODEL_CAPS.items():
            if self.config.model.startswith(prefix):
                for k, v in info.items():
                    if hasattr(caps, k):
                        setattr(caps, k, v)
                break
        return caps

    async def validate_config(self) -> bool:
        if not self._api_key:
            raise ProviderNotAvailableError("Google API key is not set")
        try:
            resp = await self._http.get(
                f"{self._base_url}/v1beta/models",
                params={"key": self._api_key},
                timeout=10.0,
            )
            if resp.status_code == 400 or resp.status_code == 403:
                raise ProviderNotAvailableError("Google API key is invalid")
            return resp.status_code == 200
        except httpx.RequestError as exc:
            raise ProviderNotAvailableError(
                f"Cannot reach Google API: {exc}"
            ) from exc

    # -- internal helpers ----------------------------------------------------

    @staticmethod
    def _convert_messages(
        messages: list[dict[str, Any]],
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Convert OpenAI-style messages to Gemini format."""
        system = None
        contents: list[dict[str, Any]] = []

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                if isinstance(content, str):
                    system = content
                elif isinstance(content, list):
                    system = "\n".join(
                        p.get("text", "") for p in content if isinstance(p, dict)
                    )
                continue

            # Map roles: user→user, assistant→model
            gemini_role = "user" if role == "user" else "model"

            if isinstance(content, str):
                contents.append({
                    "role": gemini_role,
                    "parts": [{"text": content}],
                })
            elif isinstance(content, list):
                parts = []
                for part in content:
                    if isinstance(part, dict):
                        if part.get("type") == "text":
                            parts.append({"text": part.get("text", "")})
                        elif part.get("type") == "image_url":
                            url = part.get("image_url", {}).get("url", "")
                            if url.startswith("data:"):
                                # Inline base64 image
                                mime, _, b64 = url.partition(",")
                                mime = mime.split(":")[1].split(";")[0]
                                parts.append({
                                    "inline_data": {
                                        "mime_type": mime,
                                        "data": b64,
                                    }
                                })
                if parts:
                    contents.append({"role": gemini_role, "parts": parts})

            # Handle tool calls in assistant messages
            tool_calls = msg.get("tool_calls", [])
            if tool_calls and role == "assistant":
                func_calls = []
                for tc in tool_calls:
                    func = tc.get("function", {})
                    args = func.get("arguments", "{}")
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except json.JSONDecodeError:
                            args = {}
                    func_calls.append({
                        "functionCall": {
                            "name": func.get("name", ""),
                            "args": args,
                        }
                    })
                if func_calls:
                    contents.append({"role": "model", "parts": func_calls})

            # Handle tool results
            if role == "tool":
                tool_id = msg.get("tool_call_id", "")
                result_content = content if isinstance(content, str) else json.dumps(content)
                contents.append({
                    "role": "user",
                    "parts": [{
                        "functionResponse": {
                            "name": msg.get("name", ""),
                            "response": {"result": result_content},
                        }
                    }],
                })

        return system, contents

    def _build_payload(
        self,
        contents: list[dict[str, Any]],
        *,
        system: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"contents": contents}

        if system:
            payload["systemInstruction"] = {"parts": [{"text": system}]}

        gen_config: dict[str, Any] = {}
        if temperature is not None:
            gen_config["temperature"] = temperature
        if max_tokens is not None:
            gen_config["maxOutputTokens"] = max_tokens
        if stop:
            gen_config["stopSequences"] = stop
        if gen_config:
            payload["generationConfig"] = gen_config

        if tools:
            func_decls = []
            for tool in tools:
                func = tool.get("function", tool)
                func_decls.append({
                    "name": func.get("name", ""),
                    "description": func.get("description", ""),
                    "parameters": func.get("parameters", {}),
                })
            payload["tools"] = [{"functionDeclarations": func_decls}]

        if extra:
            payload.update(extra)

        return payload
