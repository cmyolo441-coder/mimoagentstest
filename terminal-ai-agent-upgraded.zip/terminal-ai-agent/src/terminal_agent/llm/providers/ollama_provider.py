"""Ollama local model provider.

Connects to a local Ollama instance for running Llama, Mistral, Phi,
Qwen, CodeLlama, and any other locally-hosted model.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import ProviderNotAvailableError
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)


class OllamaProvider(BaseProvider):
    """Ollama local inference provider.

    Parameters
    ----------
    config : ProviderConfig
        ``base_url`` defaults to ``http://localhost:11434``.
        ``api_key`` is not required.
    http_client : httpx.AsyncClient | None
        Shared HTTP client.
    """

    provider_id = "ollama"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        self._base_url = (config.base_url or "http://localhost:11434").rstrip("/")
        self._parser = ResponseParser()

    # -- abstract implementation ---------------------------------------------

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()

        payload = self._build_payload(
            messages,
            tools=tools,
            temperature=temperature,
            stop=stop,
            response_format=response_format,
            extra=extra,
            stream=False,
        )

        resp = await self._http.post(
            f"{self._base_url}/api/chat",
            json=payload,
        )

        if resp.status_code != 200:
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        return self._parser.parse_ollama(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()

        payload = self._build_payload(
            messages,
            tools=tools,
            temperature=temperature,
            stop=stop,
            response_format=response_format,
            extra=extra,
            stream=True,
        )

        async with self._http.stream(
            "POST",
            f"{self._base_url}/api/chat",
            json=payload,
        ) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_http_error(resp.status_code, body.decode())

            async for line in resp.aiter_lines():
                if not line.strip():
                    continue
                try:
                    chunk = json.loads(line)
                    content = chunk.get("message", {}).get("content", "")
                    if content:
                        yield content
                    if chunk.get("done"):
                        break
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter

        counter = TokenCounter(model=self.config.model, provider=self.provider_id)
        return counter._count_heuristic(
            " ".join(m.get("content", "") for m in messages if isinstance(m.get("content"), str))
        )

    def get_model_info(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            streaming=True,
            tool_calling=True,
            vision=False,
            json_mode=True,
            max_context_tokens=32_768,
            max_output_tokens=4_096,
            supports_system_message=True,
            supports_temperature=True,
            supports_seed=False,
            supports_stop_sequences=True,
            supports_parallel_tool_calls=False,
            supports_response_format=False,
            cost_per_input_token=0.0,
            cost_per_output_token=0.0,
        )

    async def validate_config(self) -> bool:
        try:
            resp = await self._http.get(
                f"{self._base_url}/api/tags",
                timeout=5.0,
            )
            if resp.status_code != 200:
                raise ProviderNotAvailableError(
                    f"Ollama returned HTTP {resp.status_code}"
                )
            return True
        except httpx.RequestError as exc:
            raise ProviderNotAvailableError(
                f"Cannot reach Ollama at {self._base_url}: {exc}"
            ) from exc

    # -- internal helpers ----------------------------------------------------

    def _build_payload(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
        stream: bool = False,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": messages,
            "stream": stream,
        }

        options: dict[str, Any] = {}
        if temperature is not None:
            options["temperature"] = temperature
        if stop:
            options["stop"] = stop
        if options:
            payload["options"] = options

        if tools:
            # Ollama uses OpenAI-compatible tool format
            ollama_tools = []
            for tool in tools:
                func = tool.get("function", tool)
                ollama_tools.append({
                    "type": "function",
                    "function": {
                        "name": func.get("name", ""),
                        "description": func.get("description", ""),
                        "parameters": func.get("parameters", {}),
                    },
                })
            payload["tools"] = ollama_tools

        if response_format:
            payload["format"] = "json"

        if extra:
            payload.update(extra)

        return payload
