"""OpenAI API provider.

Supports GPT-4o, GPT-4, GPT-3.5-turbo, o1, o3, and all OpenAI-compatible models.
Uses the Chat Completions API with full streaming, tool calling, and JSON mode.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import (
    ProviderError,
    ProviderNotAvailableError,
    RateLimitError,
    ResponseParseError,
)
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)

# Default capabilities by model family
_MODEL_CAPS: dict[str, dict[str, Any]] = {
    "gpt-4o": {
        "max_context_tokens": 128_000,
        "max_output_tokens": 16_384,
        "vision": True,
        "json_mode": True,
        "supports_seed": True,
        "cost_per_input_token": 2.5e-6,
        "cost_per_output_token": 10e-6,
    },
    "gpt-4o-mini": {
        "max_context_tokens": 128_000,
        "max_output_tokens": 16_384,
        "vision": True,
        "json_mode": True,
        "supports_seed": True,
        "cost_per_input_token": 0.15e-6,
        "cost_per_output_token": 0.6e-6,
    },
    "gpt-4-turbo": {
        "max_context_tokens": 128_000,
        "max_output_tokens": 4_096,
        "vision": True,
        "json_mode": True,
        "cost_per_input_token": 10e-6,
        "cost_per_output_token": 30e-6,
    },
    "o1": {
        "max_context_tokens": 200_000,
        "max_output_tokens": 100_000,
        "supports_system_message": False,
        "supports_temperature": False,
        "cost_per_input_token": 15e-6,
        "cost_per_output_token": 60e-6,
    },
    "o3": {
        "max_context_tokens": 200_000,
        "max_output_tokens": 100_000,
        "supports_system_message": False,
        "supports_temperature": False,
        "cost_per_input_token": 10e-6,
        "cost_per_output_token": 40e-6,
    },
    "o3-mini": {
        "max_context_tokens": 200_000,
        "max_output_tokens": 100_000,
        "supports_system_message": False,
        "supports_temperature": False,
        "cost_per_input_token": 1.1e-6,
        "cost_per_output_token": 4.4e-6,
    },
}


class OpenAIProvider(BaseProvider):
    """OpenAI Chat Completions API provider.

    Parameters
    ----------
    config : ProviderConfig
        Must include ``api_key``.  ``base_url`` defaults to the OpenAI API.
    http_client : httpx.AsyncClient | None
        Shared HTTP client.
    """

    provider_id = "openai"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        self._base_url = (config.base_url or "https://api.openai.com/v1").rstrip("/")
        self._parser = ResponseParser()
        self._api_key = config.api_key

    # -- abstract implementation ---------------------------------------------

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()

        payload = self._build_payload(
            messages,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            stop=stop,
            response_format=response_format,
            extra=extra,
            stream=False,
        )

        headers = self._build_headers()
        headers["Authorization"] = f"Bearer {self._api_key}"

        resp = await self._http.post(
            f"{self._base_url}/chat/completions",
            headers=headers,
            json=payload,
        )

        if resp.status_code != 200:
            self._handle_rate_limit_response(dict(resp.headers))
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        data["_provider"] = self.provider_id
        return self._parser.parse_openai(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()

        payload = self._build_payload(
            messages,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            stop=stop,
            response_format=response_format,
            extra=extra,
            stream=True,
        )

        headers = self._build_headers()
        headers["Authorization"] = f"Bearer {self._api_key}"

        async with self._http.stream(
            "POST",
            f"{self._base_url}/chat/completions",
            headers=headers,
            json=payload,
        ) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_rate_limit_response(dict(resp.headers))
                self._handle_http_error(resp.status_code, body.decode())

            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    parsed = self._parser.parse_openai_chunk(chunk)
                    if parsed["delta_content"]:
                        yield parsed["delta_content"]
                    # Tool call deltas are not yielded as text
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter

        counter = TokenCounter(model=self.config.model, provider=self.provider_id)
        return counter.count_messages(messages)

    def get_model_info(self) -> ProviderCapabilities:
        caps = ProviderCapabilities()
        # Find matching model caps
        for prefix, info in _MODEL_CAPS.items():
            if self.config.model.startswith(prefix):
                for k, v in info.items():
                    if hasattr(caps, k):
                        setattr(caps, k, v)
                break
        return caps

    async def validate_config(self) -> bool:
        if not self._api_key:
            raise ProviderNotAvailableError("OpenAI API key is not set")
        try:
            resp = await self._http.get(
                f"{self._base_url}/models",
                headers={"Authorization": f"Bearer {self._api_key}"},
                timeout=10.0,
            )
            if resp.status_code == 401:
                raise ProviderNotAvailableError("OpenAI API key is invalid")
            return resp.status_code == 200
        except httpx.RequestError as exc:
            raise ProviderNotAvailableError(
                f"Cannot reach OpenAI API: {exc}"
            ) from exc

    # -- internal helpers ----------------------------------------------------

    def _build_payload(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
        stream: bool = False,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": messages,
            "stream": stream,
        }

        model_info = self.get_model_info()

        if model_info.supports_temperature and temperature is not None:
            payload["temperature"] = temperature

        if max_tokens is not None:
            # o-series models use max_completion_tokens
            if self.config.model.startswith(("o1", "o3", "o4")):
                payload["max_completion_tokens"] = max_tokens
            else:
                payload["max_tokens"] = max_tokens

        if stop and model_info.supports_stop_sequences:
            payload["stop"] = stop

        if tools:
            payload["tools"] = tools
            if model_info.supports_parallel_tool_calls:
                payload["parallel_tool_calls"] = True

        if response_format and model_info.json_mode:
            payload["response_format"] = response_format

        if extra:
            payload.update(extra)

        return payload
