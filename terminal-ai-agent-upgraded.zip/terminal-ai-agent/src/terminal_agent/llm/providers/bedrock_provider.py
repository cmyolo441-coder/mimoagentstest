"""AWS Bedrock provider.

Connects to AWS Bedrock for Claude, Llama, Mistral, and other models
hosted on AWS infrastructure. Uses AWS Signature V4 for authentication.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
from datetime import datetime, timezone
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import ProviderNotAvailableError
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)


class BedrockProvider(BaseProvider):
    """AWS Bedrock provider.

    Parameters
    ----------
    config : ProviderConfig
        ``api_key`` should be ``access_key:secret_key`` format.
        ``base_url`` is the Bedrock endpoint URL.
        ``organization`` is the AWS region (default ``us-east-1``).
    http_client : httpx.AsyncClient | None
        Shared HTTP client.
    """

    provider_id = "bedrock"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        self._region = config.organization or "us-east-1"
        self._base_url = config.base_url or f"https://bedrock-runtime.{self._region}.amazonaws.com"
        self._parser = ResponseParser()
        self._access_key, _, self._secret_key = (config.api_key or "").partition(":")

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()

        # Bedrock uses the Converse API for Claude and other models
        payload = self._build_converse_payload(
            messages, tools=tools, temperature=temperature,
            max_tokens=max_tokens, stop=stop, extra=extra,
        )

        model_id = self.config.model
        url = f"{self._base_url}/model/{model_id}/converse"
        headers = self._sign_request("POST", url, json.dumps(payload))

        resp = await self._http.post(url, headers=headers, json=payload)
        if resp.status_code != 200:
            self._handle_rate_limit_response(dict(resp.headers))
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        return self._parse_converse_response(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()

        payload = self._build_converse_payload(
            messages, tools=tools, temperature=temperature,
            max_tokens=max_tokens, stop=stop, extra=extra,
        )

        model_id = self.config.model
        url = f"{self._base_url}/model/{model_id}/converse-stream"
        headers = self._sign_request("POST", url, json.dumps(payload))

        async with self._http.stream("POST", url, headers=headers, json=payload) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_rate_limit_response(dict(resp.headers))
                self._handle_http_error(resp.status_code, body.decode())
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                try:
                    chunk = json.loads(line[6:])
                    if "contentBlockDelta" in chunk:
                        delta = chunk["contentBlockDelta"].get("delta", {})
                        text = delta.get("text", "")
                        if text:
                            yield text
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter
        return TokenCounter(model=self.config.model, provider=self.provider_id).count_messages(messages)

    def get_model_info(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            max_context_tokens=200_000,
            max_output_tokens=4_096,
            vision=True,
            tool_calling=True,
        )

    async def validate_config(self) -> bool:
        if not self._access_key or not self._secret_key:
            raise ProviderNotAvailableError("AWS credentials are not set (use access_key:secret_key)")
        return True

    # -- internal helpers ----------------------------------------------------

    def _build_converse_payload(
        self, messages: list[dict[str, Any]], **kwargs: Any
    ) -> dict[str, Any]:
        # Convert to Bedrock Converse format
        converse_messages = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, str):
                converse_messages.append({"role": role, "content": [{"text": content}]})
            else:
                converse_messages.append(msg)

        payload: dict[str, Any] = {"messages": converse_messages}
        inference_config: dict[str, Any] = {}
        if kwargs.get("temperature") is not None:
            inference_config["temperature"] = kwargs["temperature"]
        if kwargs.get("max_tokens") is not None:
            inference_config["maxTokens"] = kwargs["max_tokens"]
        if kwargs.get("stop"):
            inference_config["stopSequences"] = kwargs["stop"]
        if inference_config:
            payload["inferenceConfig"] = inference_config

        if kwargs.get("tools"):
            tool_config = []
            for tool in kwargs["tools"]:
                func = tool.get("function", tool)
                tool_config.append({
                    "toolSpec": {
                        "name": func.get("name", ""),
                        "description": func.get("description", ""),
                        "inputSchema": {"json": func.get("parameters", {})},
                    }
                })
            payload["toolConfig"] = {"tools": tool_config}

        return payload

    def _parse_converse_response(self, data: dict[str, Any]) -> LLMResponse:
        from terminal_agent.types import ToolCall

        output = data.get("output", {})
        message = output.get("message", {})
        content_blocks = message.get("content", [])
        usage = data.get("usage", {})

        text_parts = []
        tool_calls = []
        for block in content_blocks:
            if "text" in block:
                text_parts.append(block["text"])
            elif "toolUse" in block:
                tu = block["toolUse"]
                tool_calls.append(ToolCall(id=tu.get("toolUseId"), name=tu.get("name", ""), parameters=tu.get("input", {})))

        stop_reason = data.get("stopReason", "end_turn")

        return LLMResponse(
            content="\n".join(text_parts),
            tool_calls=tool_calls,
            finish_reason=stop_reason,
            tokens_in=usage.get("inputTokens", 0),
            tokens_out=usage.get("outputTokens", 0),
            provider=self.provider_id,
            model=self.config.model,
        )

    def _sign_request(self, method: str, url: str, body: str) -> dict[str, str]:
        """Sign a request using AWS Signature V4."""
        now = datetime.now(timezone.utc)
        datestamp = now.strftime("%Y%m%d")
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")

        parsed = httpx.URL(url)
        host = parsed.host
        uri = parsed.path or "/"

        payload_hash = hashlib.sha256(body.encode()).hexdigest()

        headers = {
            "Content-Type": "application/json",
            "Host": host,
            "X-Amz-Date": amz_date,
            "X-Amz-Content-Sha256": payload_hash,
        }

        # Canonical request
        canonical_headers = "".join(f"{k.lower()}:{v}\n" for k, v in sorted(headers.items()))
        signed_headers = ";".join(k.lower() for k in sorted(headers))
        canonical_request = f"{method}\n{uri}\n\n{canonical_headers}\n{signed_headers}\n{payload_hash}"

        # String to sign
        credential_scope = f"{datestamp}/{self._region}/bedrock/aws4_request"
        string_to_sign = f"AWS4-HMAC-SHA256\n{amz_date}\n{credential_scope}\n{hashlib.sha256(canonical_request.encode()).hexdigest()}"

        # Signing key
        def _sign(key: bytes, msg: str) -> bytes:
            return hmac.new(key, msg.encode(), hashlib.sha256).digest()

        k_date = _sign(f"AWS4{self._secret_key}".encode(), datestamp)
        k_region = _sign(k_date, self._region)
        k_service = _sign(k_region, "bedrock")
        k_signing = _sign(k_service, "aws4_request")
        signature = hmac.new(k_signing, string_to_sign.encode(), hashlib.sha256).hexdigest()

        headers["Authorization"] = (
            f"AWS4-HMAC-SHA256 Credential={self._access_key}/{credential_scope}, "
            f"SignedHeaders={signed_headers}, Signature={signature}"
        )
        return headers
