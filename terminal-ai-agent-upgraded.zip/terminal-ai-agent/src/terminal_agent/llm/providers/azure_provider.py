"""Azure OpenAI Service provider.

Connects to Azure-hosted OpenAI models with Azure-specific authentication
and endpoint format.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import ProviderNotAvailableError
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)


class AzureProvider(BaseProvider):
    """Azure OpenAI Service provider.

    Parameters
    ----------
    config : ProviderConfig
        ``base_url`` should be the Azure endpoint (e.g. ``https://myresource.openai.azure.com``).
        ``api_key`` is the Azure API key.
        ``organization`` is used as the API version (default ``2024-06-01``).
    http_client : httpx.AsyncClient | None
        Shared HTTP client.
    """

    provider_id = "azure"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        self._base_url = (config.base_url or "").rstrip("/")
        self._api_key = config.api_key
        self._api_version = config.organization or "2024-06-01"
        self._parser = ResponseParser()

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()
        payload: dict[str, Any] = {"messages": messages}
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop:
            payload["stop"] = stop
        if tools:
            payload["tools"] = tools
        if response_format:
            payload["response_format"] = response_format
        if extra:
            payload.update(extra)

        headers = {"api-key": self._api_key, "Content-Type": "application/json"}
        url = f"{self._base_url}/openai/deployments/{self.config.model}/chat/completions"
        params = {"api-version": self._api_version}

        resp = await self._http.post(url, headers=headers, json=payload, params=params)
        if resp.status_code != 200:
            self._handle_rate_limit_response(dict(resp.headers))
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        data["_provider"] = self.provider_id
        return self._parser.parse_openai(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()
        payload: dict[str, Any] = {"messages": messages, "stream": True}
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop:
            payload["stop"] = stop
        if tools:
            payload["tools"] = tools
        if response_format:
            payload["response_format"] = response_format
        if extra:
            payload.update(extra)

        headers = {"api-key": self._api_key, "Content-Type": "application/json"}
        url = f"{self._base_url}/openai/deployments/{self.config.model}/chat/completions"
        params = {"api-version": self._api_version}

        async with self._http.stream("POST", url, headers=headers, json=payload, params=params) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_rate_limit_response(dict(resp.headers))
                self._handle_http_error(resp.status_code, body.decode())
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    parsed = self._parser.parse_openai_chunk(chunk)
                    if parsed["delta_content"]:
                        yield parsed["delta_content"]
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter
        return TokenCounter(model=self.config.model, provider=self.provider_id).count_messages(messages)

    def get_model_info(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            max_context_tokens=128_000,
            max_output_tokens=16_384,
            vision=True,
            json_mode=True,
            supports_seed=True,
        )

    async def validate_config(self) -> bool:
        if not self._base_url:
            raise ProviderNotAvailableError("Azure endpoint URL is not set")
        if not self._api_key:
            raise ProviderNotAvailableError("Azure API key is not set")
        try:
            headers = {"api-key": self._api_key}
            resp = await self._http.get(
                f"{self._base_url}/openai/models",
                headers=headers,
                params={"api-version": self._api_version},
                timeout=10.0,
            )
            return resp.status_code == 200
        except httpx.RequestError as exc:
            raise ProviderNotAvailableError(f"Cannot reach Azure OpenAI: {exc}") from exc
