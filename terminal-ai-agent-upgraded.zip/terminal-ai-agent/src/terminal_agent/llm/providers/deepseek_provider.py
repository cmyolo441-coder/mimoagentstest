"""DeepSeek API provider.

Supports DeepSeek Chat, DeepSeek Coder, DeepSeek Reasoner.
Uses the OpenAI-compatible API format.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import ProviderNotAvailableError
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)

_MODEL_CAPS: dict[str, dict[str, Any]] = {
    "deepseek-chat": {
        "max_context_tokens": 64_000,
        "max_output_tokens": 8_192,
        "cost_per_input_token": 0.14e-6,
        "cost_per_output_token": 0.28e-6,
    },
    "deepseek-coder": {
        "max_context_tokens": 128_000,
        "max_output_tokens": 8_192,
        "cost_per_input_token": 0.14e-6,
        "cost_per_output_token": 0.28e-6,
    },
    "deepseek-reasoner": {
        "max_context_tokens": 64_000,
        "max_output_tokens": 8_192,
        "cost_per_input_token": 0.55e-6,
        "cost_per_output_token": 2.19e-6,
    },
}


class DeepSeekProvider(BaseProvider):
    """DeepSeek API provider (OpenAI-compatible)."""

    provider_id = "deepseek"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        self._base_url = (config.base_url or "https://api.deepseek.com/v1").rstrip("/")
        self._parser = ResponseParser()
        self._api_key = config.api_key

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()
        payload = self._build_payload(messages, tools=tools, temperature=temperature,
                                       max_tokens=max_tokens, stop=stop,
                                       response_format=response_format, extra=extra, stream=False)
        headers = self._build_headers()
        headers["Authorization"] = f"Bearer {self._api_key}"

        resp = await self._http.post(f"{self._base_url}/chat/completions", headers=headers, json=payload)
        if resp.status_code != 200:
            self._handle_rate_limit_response(dict(resp.headers))
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        data["_provider"] = self.provider_id
        return self._parser.parse_openai(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()
        payload = self._build_payload(messages, tools=tools, temperature=temperature,
                                       max_tokens=max_tokens, stop=stop,
                                       response_format=response_format, extra=extra, stream=True)
        headers = self._build_headers()
        headers["Authorization"] = f"Bearer {self._api_key}"

        async with self._http.stream("POST", f"{self._base_url}/chat/completions",
                                      headers=headers, json=payload) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_rate_limit_response(dict(resp.headers))
                self._handle_http_error(resp.status_code, body.decode())

            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    parsed = self._parser.parse_openai_chunk(chunk)
                    if parsed["delta_content"]:
                        yield parsed["delta_content"]
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter
        counter = TokenCounter(model=self.config.model, provider=self.provider_id)
        return counter.count_messages(messages)

    def get_model_info(self) -> ProviderCapabilities:
        caps = ProviderCapabilities()
        for prefix, info in _MODEL_CAPS.items():
            if self.config.model.startswith(prefix):
                for k, v in info.items():
                    if hasattr(caps, k):
                        setattr(caps, k, v)
                break
        return caps

    async def validate_config(self) -> bool:
        if not self._api_key:
            raise ProviderNotAvailableError("DeepSeek API key is not set")
        try:
            resp = await self._http.get(
                f"{self._base_url}/models",
                headers={"Authorization": f"Bearer {self._api_key}"},
                timeout=10.0,
            )
            if resp.status_code == 401:
                raise ProviderNotAvailableError("DeepSeek API key is invalid")
            return resp.status_code == 200
        except httpx.RequestError as exc:
            raise ProviderNotAvailableError(f"Cannot reach DeepSeek API: {exc}") from exc

    def _build_payload(self, messages: list[dict[str, Any]], **kwargs: Any) -> dict[str, Any]:
        payload: dict[str, Any] = {"model": self.config.model, "messages": messages, "stream": kwargs.get("stream", False)}
        if kwargs.get("temperature") is not None:
            payload["temperature"] = kwargs["temperature"]
        if kwargs.get("max_tokens") is not None:
            payload["max_tokens"] = kwargs["max_tokens"]
        if kwargs.get("stop"):
            payload["stop"] = kwargs["stop"]
        if kwargs.get("tools"):
            payload["tools"] = kwargs["tools"]
        if kwargs.get("response_format"):
            payload["response_format"] = kwargs["response_format"]
        if kwargs.get("extra"):
            payload.update(kwargs["extra"])
        return payload
