"""LiteLLM proxy provider.

Routes through a LiteLLM proxy server, giving access to 100+ models
from various providers through a single OpenAI-compatible endpoint.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import ProviderNotAvailableError
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)


class LiteLLMProvider(BaseProvider):
    """LiteLLM proxy provider (OpenAI-compatible).

    Parameters
    ----------
    config : ProviderConfig
        ``base_url`` should point to the LiteLLM proxy (default ``http://localhost:4000``).
        ``api_key`` is the LiteLLM proxy key.
    http_client : httpx.AsyncClient | None
        Shared HTTP client.
    """

    provider_id = "litellm"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        self._base_url = (config.base_url or "http://localhost:4000/v1").rstrip("/")
        self._parser = ResponseParser()
        self._api_key = config.api_key

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()
        payload: dict[str, Any] = {"model": self.config.model, "messages": messages, "stream": False}
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop:
            payload["stop"] = stop
        if tools:
            payload["tools"] = tools
        if response_format:
            payload["response_format"] = response_format
        if extra:
            payload.update(extra)

        headers = self._build_headers()
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        resp = await self._http.post(f"{self._base_url}/chat/completions", headers=headers, json=payload)
        if resp.status_code != 200:
            self._handle_rate_limit_response(dict(resp.headers))
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        data["_provider"] = self.provider_id
        return self._parser.parse_openai(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()
        payload: dict[str, Any] = {"model": self.config.model, "messages": messages, "stream": True}
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop:
            payload["stop"] = stop
        if tools:
            payload["tools"] = tools
        if response_format:
            payload["response_format"] = response_format
        if extra:
            payload.update(extra)

        headers = self._build_headers()
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        async with self._http.stream("POST", f"{self._base_url}/chat/completions", headers=headers, json=payload) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_rate_limit_response(dict(resp.headers))
                self._handle_http_error(resp.status_code, body.decode())
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    parsed = self._parser.parse_openai_chunk(chunk)
                    if parsed["delta_content"]:
                        yield parsed["delta_content"]
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter
        return TokenCounter(model=self.config.model, provider=self.provider_id).count_messages(messages)

    def get_model_info(self) -> ProviderCapabilities:
        return ProviderCapabilities()  # LiteLLM proxies many models; use defaults

    async def validate_config(self) -> bool:
        try:
            headers = {}
            if self._api_key:
                headers["Authorization"] = f"Bearer {self._api_key}"
            resp = await self._http.get(f"{self._base_url}/models", headers=headers, timeout=10.0)
            return resp.status_code == 200
        except httpx.RequestError as exc:
            raise ProviderNotAvailableError(f"Cannot reach LiteLLM proxy: {exc}") from exc
