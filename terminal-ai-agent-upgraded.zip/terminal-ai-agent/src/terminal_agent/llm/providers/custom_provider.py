"""Custom OpenAI-compatible API provider.

Connects to any OpenAI-compatible API endpoint.  This is the universal
fallback for self-hosted models, API gateways, and non-standard providers.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import ProviderNotAvailableError
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)


class CustomProvider(BaseProvider):
    """Custom OpenAI-compatible API provider.

    Parameters
    ----------
    config : ProviderConfig
        ``base_url`` is **required** and should point to the API endpoint.
        ``api_key`` is optional (some endpoints don't need auth).
    http_client : httpx.AsyncClient | None
        Shared HTTP client.

    Notes
    -----
    This provider assumes the endpoint follows the OpenAI Chat Completions
    API format.  If the endpoint uses a different format, consider creating
    a dedicated provider class.
    """

    provider_id = "custom"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        if not config.base_url:
            raise ProviderNotAvailableError(
                "Custom provider requires a base_url in config"
            )
        self._base_url = config.base_url.rstrip("/")
        self._parser = ResponseParser()
        self._api_key = config.api_key

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()
        payload: dict[str, Any] = {"model": self.config.model, "messages": messages, "stream": False}
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop:
            payload["stop"] = stop
        if tools:
            payload["tools"] = tools
        if response_format:
            payload["response_format"] = response_format
        if extra:
            payload.update(extra)

        headers = self._build_headers()
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        resp = await self._http.post(f"{self._base_url}/chat/completions", headers=headers, json=payload)
        if resp.status_code != 200:
            self._handle_rate_limit_response(dict(resp.headers))
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        data["_provider"] = self.provider_id
        return self._parser.parse_openai(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()
        payload: dict[str, Any] = {"model": self.config.model, "messages": messages, "stream": True}
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if stop:
            payload["stop"] = stop
        if tools:
            payload["tools"] = tools
        if response_format:
            payload["response_format"] = response_format
        if extra:
            payload.update(extra)

        headers = self._build_headers()
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        async with self._http.stream("POST", f"{self._base_url}/chat/completions", headers=headers, json=payload) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_rate_limit_response(dict(resp.headers))
                self._handle_http_error(resp.status_code, body.decode())
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    parsed = self._parser.parse_openai_chunk(chunk)
                    if parsed["delta_content"]:
                        yield parsed["delta_content"]
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter
        return TokenCounter(model=self.config.model, provider=self.provider_id)._count_heuristic(
            " ".join(m.get("content", "") for m in messages if isinstance(m.get("content"), str))
        )

    def get_model_info(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            max_context_tokens=32_768,
            max_output_tokens=4_096,
            tool_calling=True,
            cost_per_input_token=0.0,
            cost_per_output_token=0.0,
        )

    async def validate_config(self) -> bool:
        try:
            headers = {}
            if self._api_key:
                headers["Authorization"] = f"Bearer {self._api_key}"
            resp = await self._http.get(f"{self._base_url}/models", headers=headers, timeout=5.0)
            if resp.status_code == 200:
                return True
            # Some endpoints don't have /models; try a health check
            resp2 = await self._http.get(f"{self._base_url}/health", headers=headers, timeout=5.0)
            return resp2.status_code == 200
        except httpx.RequestError as exc:
            raise ProviderNotAvailableError(
                f"Cannot reach custom endpoint at {self._base_url}: {exc}"
            ) from exc
