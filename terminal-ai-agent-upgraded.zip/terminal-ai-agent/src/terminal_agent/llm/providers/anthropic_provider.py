"""Anthropic (Claude) API provider.

Supports Claude Opus, Sonnet, Haiku, and all Claude 3.x/4 models via
the Messages API with streaming, tool calling, and extended thinking.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import httpx

from terminal_agent.exceptions import (
    ProviderError,
    ProviderNotAvailableError,
    ResponseParseError,
)
from terminal_agent.llm.base_provider import BaseProvider, ProviderCapabilities
from terminal_agent.llm.response_parser import ResponseParser
from terminal_agent.types import LLMResponse, ProviderConfig

logger = logging.getLogger(__name__)

_API_VERSION = "2023-06-01"

_MODEL_CAPS: dict[str, dict[str, Any]] = {
    "claude-opus-4": {
        "max_context_tokens": 200_000,
        "max_output_tokens": 32_000,
        "vision": True,
        "cost_per_input_token": 15e-6,
        "cost_per_output_token": 75e-6,
    },
    "claude-sonnet-4": {
        "max_context_tokens": 200_000,
        "max_output_tokens": 16_000,
        "vision": True,
        "cost_per_input_token": 3e-6,
        "cost_per_output_token": 15e-6,
    },
    "claude-3-5-sonnet": {
        "max_context_tokens": 200_000,
        "max_output_tokens": 8_192,
        "vision": True,
        "cost_per_input_token": 3e-6,
        "cost_per_output_token": 15e-6,
    },
    "claude-3-5-haiku": {
        "max_context_tokens": 200_000,
        "max_output_tokens": 8_192,
        "vision": True,
        "cost_per_input_token": 0.8e-6,
        "cost_per_output_token": 4e-6,
    },
    "claude-3-opus": {
        "max_context_tokens": 200_000,
        "max_output_tokens": 4_096,
        "vision": True,
        "cost_per_input_token": 15e-6,
        "cost_per_output_token": 75e-6,
    },
}


class AnthropicProvider(BaseProvider):
    """Anthropic Messages API provider.

    Parameters
    ----------
    config : ProviderConfig
        Must include ``api_key``.  ``base_url`` defaults to the Anthropic API.
    http_client : httpx.AsyncClient | None
        Shared HTTP client.
    """

    provider_id = "anthropic"

    def __init__(
        self,
        config: ProviderConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(config, http_client)
        self._base_url = (config.base_url or "https://api.anthropic.com").rstrip("/")
        self._parser = ResponseParser()
        self._api_key = config.api_key

    # -- abstract implementation ---------------------------------------------

    async def send_prompt(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> LLMResponse:
        await self.rate_limit()

        system_msg, chat_messages = self._extract_system(messages)
        payload = self._build_payload(
            chat_messages,
            system=system_msg,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            stop=stop,
            extra=extra,
            stream=False,
        )

        headers = self._build_headers()
        headers.update({
            "x-api-key": self._api_key,
            "anthropic-version": _API_VERSION,
        })

        resp = await self._http.post(
            f"{self._base_url}/v1/messages",
            headers=headers,
            json=payload,
        )

        if resp.status_code != 200:
            self._handle_rate_limit_response(dict(resp.headers))
            self._handle_http_error(resp.status_code, resp.text)

        data = resp.json()
        return self._parser.parse_anthropic(data)

    async def send_prompt_streaming(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        await self.rate_limit()

        system_msg, chat_messages = self._extract_system(messages)
        payload = self._build_payload(
            chat_messages,
            system=system_msg,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            stop=stop,
            extra=extra,
            stream=True,
        )

        headers = self._build_headers()
        headers.update({
            "x-api-key": self._api_key,
            "anthropic-version": _API_VERSION,
        })

        async with self._http.stream(
            "POST",
            f"{self._base_url}/v1/messages",
            headers=headers,
            json=payload,
        ) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                self._handle_rate_limit_response(dict(resp.headers))
                self._handle_http_error(resp.status_code, body.decode())

            event_type = ""
            async for line in resp.aiter_lines():
                if line.startswith("event: "):
                    event_type = line[7:].strip()
                    continue
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                try:
                    data = json.loads(data_str)
                    parsed = self._parser.parse_anthropic_chunk(event_type, data)
                    if parsed["delta_content"]:
                        yield parsed["delta_content"]
                    if parsed["delta_thinking"]:
                        # Yield thinking as structured marker
                        yield f"<thinking>{parsed['delta_thinking']}</thinking>"
                except json.JSONDecodeError:
                    continue

    def count_tokens(self, messages: list[dict[str, Any]]) -> int:
        from terminal_agent.llm.token_counter import TokenCounter

        counter = TokenCounter(model=self.config.model, provider=self.provider_id)
        return counter.count_messages(messages)

    def get_model_info(self) -> ProviderCapabilities:
        caps = ProviderCapabilities()
        caps.supports_seed = False
        caps.supports_response_format = False
        for prefix, info in _MODEL_CAPS.items():
            if self.config.model.startswith(prefix):
                for k, v in info.items():
                    if hasattr(caps, k):
                        setattr(caps, k, v)
                break
        return caps

    async def validate_config(self) -> bool:
        if not self._api_key:
            raise ProviderNotAvailableError("Anthropic API key is not set")
        # Anthropic doesn't have a simple /models endpoint;
        # validate by making a minimal request.
        try:
            headers = self._build_headers()
            headers.update({
                "x-api-key": self._api_key,
                "anthropic-version": _API_VERSION,
            })
            resp = await self._http.post(
                f"{self._base_url}/v1/messages",
                headers=headers,
                json={
                    "model": self.config.model,
                    "max_tokens": 1,
                    "messages": [{"role": "user", "content": "hi"}],
                },
                timeout=10.0,
            )
            if resp.status_code == 401:
                raise ProviderNotAvailableError("Anthropic API key is invalid")
            # 200 or 400 (bad request) both mean the key works
            return resp.status_code in (200, 400)
        except httpx.RequestError as exc:
            raise ProviderNotAvailableError(
                f"Cannot reach Anthropic API: {exc}"
            ) from exc

    # -- internal helpers ----------------------------------------------------

    @staticmethod
    def _extract_system(
        messages: list[dict[str, Any]],
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Pull out the system message from the message list."""
        system = None
        chat: list[dict[str, Any]] = []
        for msg in messages:
            if msg.get("role") == "system":
                content = msg.get("content", "")
                if isinstance(content, list):
                    content = "\n".join(
                        p.get("text", "") for p in content if isinstance(p, dict)
                    )
                system = content
            else:
                chat.append(msg)
        return system, chat

    def _build_payload(
        self,
        messages: list[dict[str, Any]],
        *,
        system: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        extra: dict[str, Any] | None = None,
        stream: bool = False,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": messages,
            "max_tokens": max_tokens or self.config.max_tokens,
            "stream": stream,
        }

        if system:
            payload["system"] = system
        if temperature is not None:
            payload["temperature"] = temperature
        if stop:
            payload["stop_sequences"] = stop
        if tools:
            # Convert OpenAI-style tools to Anthropic format
            anthropic_tools = []
            for tool in tools:
                func = tool.get("function", tool)
                anthropic_tools.append({
                    "name": func.get("name", ""),
                    "description": func.get("description", ""),
                    "input_schema": func.get("parameters", func.get("input_schema", {})),
                })
            payload["tools"] = anthropic_tools

        if extra:
            payload.update(extra)

        return payload
