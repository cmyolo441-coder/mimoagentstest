"""LLM provider implementations.

Each provider module exposes a class that inherits from
:class:`~terminal_agent.llm.base_provider.BaseProvider` and implements
the full provider interface (send_prompt, send_prompt_streaming,
count_tokens, get_model_info, validate_config).

Usage::

    from terminal_agent.llm.providers import get_provider_class, create_provider

    cls = get_provider_class("openai")
    provider = cls(config)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Type

from terminal_agent.exceptions import ProviderNotAvailableError

if TYPE_CHECKING:
    from terminal_agent.llm.base_provider import BaseProvider
    from terminal_agent.types import ProviderConfig


# ---------------------------------------------------------------------------
# Provider registry
# ---------------------------------------------------------------------------

_PROVIDER_MAP: dict[str, str] = {
    "openai": "terminal_agent.llm.providers.openai_provider:OpenAIProvider",
    "anthropic": "terminal_agent.llm.providers.anthropic_provider:AnthropicProvider",
    "google": "terminal_agent.llm.providers.google_provider:GoogleProvider",
    "ollama": "terminal_agent.llm.providers.ollama_provider:OllamaProvider",
    "litellm": "terminal_agent.llm.providers.litellm_provider:LiteLLMProvider",
    "azure": "terminal_agent.llm.providers.azure_provider:AzureProvider",
    "bedrock": "terminal_agent.llm.providers.bedrock_provider:BedrockProvider",
    "cohere": "terminal_agent.llm.providers.cohere_provider:CohereProvider",
    "together": "terminal_agent.llm.providers.together_provider:TogetherProvider",
    "groq": "terminal_agent.llm.providers.groq_provider:GroqProvider",
    "deepseek": "terminal_agent.llm.providers.deepseek_provider:DeepSeekProvider",
    "vllm": "terminal_agent.llm.providers.vllm_provider:VLLMProvider",
    "fireworks": "terminal_agent.llm.providers.fireworks_provider:FireworksProvider",
    "perplexity": "terminal_agent.llm.providers.perplexity_provider:PerplexityProvider",
    "mistral": "terminal_agent.llm.providers.mistral_provider:MistralProvider",
    "xai": "terminal_agent.llm.providers.xai_provider:XAIProvider",
    "custom": "terminal_agent.llm.providers.custom_provider:CustomProvider",
}


def get_provider_class(provider_id: str) -> Type[BaseProvider]:
    """Return the provider class for the given ID.

    Raises
    ------
    ProviderNotAvailableError
        If the provider ID is not registered.
    """
    path = _PROVIDER_MAP.get(provider_id)
    if path is None:
        raise ProviderNotAvailableError(
            f"Unknown provider: '{provider_id}'. "
            f"Available: {', '.join(sorted(_PROVIDER_MAP))}",
        )
    module_path, class_name = path.rsplit(":", 1)
    import importlib

    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def create_provider(
    provider_id: str,
    config: ProviderConfig,
    **kwargs: object,
) -> BaseProvider:
    """Instantiate a provider by ID.

    Parameters
    ----------
    provider_id : str
        Provider identifier (e.g. ``"openai"``).
    config : ProviderConfig
        Configuration for the provider.
    **kwargs
        Extra keyword arguments forwarded to the provider constructor.

    Returns
    -------
    BaseProvider
        A fully initialised provider instance.
    """
    cls = get_provider_class(provider_id)
    return cls(config, **kwargs)


def list_providers() -> list[str]:
    """Return all registered provider IDs."""
    return sorted(_PROVIDER_MAP.keys())


__all__ = [
    "get_provider_class",
    "create_provider",
    "list_providers",
]
