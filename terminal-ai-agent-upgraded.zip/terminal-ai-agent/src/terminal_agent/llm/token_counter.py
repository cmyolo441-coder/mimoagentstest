"""Token counting utilities.

Provides accurate token counting for different model families.
Falls back to a simple heuristic when no provider-specific tokenizer
is available.
"""

from __future__ import annotations

import json
from typing import Any

from terminal_agent.exceptions import TokenLimitError


# ---------------------------------------------------------------------------
# Model → token-limit mapping (context window sizes)
# ---------------------------------------------------------------------------

MODEL_CONTEXT_LIMITS: dict[str, int] = {
    # OpenAI
    "gpt-4o": 128_000,
    "gpt-4o-mini": 128_000,
    "gpt-4-turbo": 128_000,
    "gpt-4": 8_192,
    "gpt-4-32k": 32_768,
    "gpt-3.5-turbo": 16_385,
    "o1": 200_000,
    "o1-mini": 128_000,
    "o1-pro": 200_000,
    "o3": 200_000,
    "o3-mini": 200_000,
    "o4-mini": 200_000,
    # Anthropic
    "claude-opus-4-20250514": 200_000,
    "claude-sonnet-4-20250514": 200_000,
    "claude-3-5-sonnet-20241022": 200_000,
    "claude-3-5-haiku-20241022": 200_000,
    "claude-3-opus-20240229": 200_000,
    "claude-3-sonnet-20240229": 200_000,
    "claude-3-haiku-20240307": 200_000,
    # Google
    "gemini-2.5-pro": 1_048_576,
    "gemini-2.5-flash": 1_048_576,
    "gemini-2.0-flash": 1_048_576,
    "gemini-1.5-pro": 2_097_152,
    "gemini-1.5-flash": 1_048_576,
    "gemini-pro": 32_768,
    # Mistral
    "mistral-large-latest": 128_000,
    "mistral-small-latest": 128_000,
    "codestral-latest": 256_000,
    # DeepSeek
    "deepseek-chat": 64_000,
    "deepseek-coder": 128_000,
    "deepseek-reasoner": 64_000,
    # Groq (matches underlying model)
    "llama-3.3-70b-versatile": 128_000,
    "llama-3.1-8b-instant": 128_000,
    # Cohere
    "command-r-plus": 128_000,
    "command-r": 128_000,
}

# ---------------------------------------------------------------------------
# Cost-per-token tables (USD)
# ---------------------------------------------------------------------------

MODEL_COSTS: dict[str, tuple[float, float]] = {
    # (input_per_token, output_per_token)
    "gpt-4o": (2.5e-6, 10e-6),
    "gpt-4o-mini": (0.15e-6, 0.6e-6),
    "gpt-4-turbo": (10e-6, 30e-6),
    "gpt-4": (30e-6, 60e-6),
    "gpt-3.5-turbo": (0.5e-6, 1.5e-6),
    "o1": (15e-6, 60e-6),
    "o1-mini": (3e-6, 12e-6),
    "o3": (10e-6, 40e-6),
    "o3-mini": (1.1e-6, 4.4e-6),
    "claude-opus-4-20250514": (15e-6, 75e-6),
    "claude-sonnet-4-20250514": (3e-6, 15e-6),
    "claude-3-5-sonnet-20241022": (3e-6, 15e-6),
    "claude-3-5-haiku-20241022": (0.8e-6, 4e-6),
    "claude-3-opus-20240229": (15e-6, 75e-6),
    "claude-3-sonnet-20240229": (3e-6, 15e-6),
    "claude-3-haiku-20240307": (0.25e-6, 1.25e-6),
    "gemini-2.5-pro": (1.25e-6, 10e-6),
    "gemini-2.5-flash": (0.15e-6, 0.6e-6),
    "gemini-2.0-flash": (0.1e-6, 0.4e-6),
    "gemini-1.5-pro": (1.25e-6, 5e-6),
    "gemini-1.5-flash": (0.075e-6, 0.3e-6),
    "mistral-large-latest": (2e-6, 6e-6),
    "mistral-small-latest": (0.2e-6, 0.6e-6),
    "deepseek-chat": (0.14e-6, 0.28e-6),
    "deepseek-coder": (0.14e-6, 0.28e-6),
    "deepseek-reasoner": (0.55e-6, 2.19e-6),
    "command-r-plus": (2.5e-6, 10e-6),
    "command-r": (0.15e-6, 0.6e-6),
}


class TokenCounter:
    """Count tokens and enforce context-window limits.

    Parameters
    ----------
    model : str
        Model identifier (e.g. ``"gpt-4o"``).
    provider : str
        Provider identifier (e.g. ``"openai"``).
    """

    def __init__(self, model: str = "", provider: str = "") -> None:
        self.model = model
        self.provider = provider
        self._tiktoken_encoder: Any = None

    # ------------------------------------------------------------------
    # Token counting
    # ------------------------------------------------------------------

    def count_text(self, text: str) -> int:
        """Count tokens in a plain text string."""
        if self.provider in ("openai", "azure", "deepseek", "groq", "together"):
            return self._count_tiktoken(text)
        if self.provider == "anthropic":
            return self._count_anthropic_estimate(text)
        if self.provider == "google":
            return self._count_google_estimate(text)
        return self._count_heuristic(text)

    def count_messages(self, messages: list[dict[str, Any]]) -> int:
        """Count tokens across a list of chat messages.

        Includes per-message overhead tokens that providers add internally.
        """
        total = 0
        for msg in messages:
            # Per-message framing overhead
            total += 4  # <|start|>, role, <|message|>, <|end|>  (approx)
            role = msg.get("role", "user")
            total += self.count_text(role)

            content = msg.get("content", "")
            if isinstance(content, str):
                total += self.count_text(content)
            elif isinstance(content, list):
                # Multimodal content blocks
                for part in content:
                    if isinstance(part, dict):
                        if part.get("type") == "text":
                            total += self.count_text(part.get("text", ""))
                        elif part.get("type") == "image_url":
                            # Rough estimate: images cost ~85 tokens per tile
                            total += 85
                    elif isinstance(part, str):
                        total += self.count_text(part)

            # Tool calls in message
            for tc in msg.get("tool_calls", []):
                func = tc.get("function", {})
                total += self.count_text(func.get("name", ""))
                args = func.get("arguments", "{}")
                if isinstance(args, dict):
                    args = json.dumps(args)
                total += self.count_text(str(args))

            # Tool call ID
            if msg.get("tool_call_id"):
                total += self.count_text(str(msg["tool_call_id"]))

        total += 3  # priming tokens
        return total

    # ------------------------------------------------------------------
    # Context window management
    # ------------------------------------------------------------------

    def get_context_limit(self) -> int:
        """Return the context window size for the current model."""
        # Exact match
        if self.model in MODEL_CONTEXT_LIMITS:
            return MODEL_CONTEXT_LIMITS[self.model]
        # Prefix match (handles dated variants like claude-3-5-sonnet-20241022)
        for prefix, limit in MODEL_CONTEXT_LIMITS.items():
            if self.model.startswith(prefix.rsplit("-", 1)[0]):
                return limit
        return 128_000  # safe default

    def get_max_output_tokens(self) -> int:
        """Return a sensible default max output token count."""
        caps = {
            "openai": 16_384,
            "anthropic": 8_192,
            "google": 8_192,
            "google": 65_536,
            "ollama": 4_096,
            "deepseek": 8_192,
            "mistral": 8_192,
        }
        return caps.get(self.provider, 4_096)

    def check_budget(
        self,
        messages: list[dict[str, Any]],
        *,
        max_output_tokens: int = 4096,
    ) -> None:
        """Raise ``TokenLimitError`` if messages exceed the context window.

        Parameters
        ----------
        messages : list[dict]
            Messages to check.
        max_output_tokens : int
            Reserved for the model's response.

        Raises
        ------
        TokenLimitError
            If input tokens + reserved output > context limit.
        """
        input_tokens = self.count_messages(messages)
        limit = self.get_context_limit()
        if input_tokens + max_output_tokens > limit:
            raise TokenLimitError(
                f"Token budget exceeded: {input_tokens} input + "
                f"{max_output_tokens} reserved output > {limit} limit",
                details={
                    "input_tokens": input_tokens,
                    "max_output_tokens": max_output_tokens,
                    "context_limit": limit,
                },
            )

    # ------------------------------------------------------------------
    # Cost helpers
    # ------------------------------------------------------------------

    def get_cost_rates(self) -> tuple[float, float]:
        """Return ``(input_cost_per_token, output_cost_per_token)``."""
        if self.model in MODEL_COSTS:
            return MODEL_COSTS[self.model]
        # Prefix match
        for prefix, costs in MODEL_COSTS.items():
            if self.model.startswith(prefix.rsplit("-", 1)[0]):
                return costs
        return (0.0, 0.0)

    def estimate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Estimate the USD cost for a request."""
        in_rate, out_rate = self.get_cost_rates()
        return input_tokens * in_rate + output_tokens * out_rate

    # ------------------------------------------------------------------
    # Internal counting implementations
    # ------------------------------------------------------------------

    def _count_tiktoken(self, text: str) -> int:
        """Count tokens using tiktoken (for OpenAI-compatible models)."""
        try:
            import tiktoken  # type: ignore[import-untyped]

            if self._tiktoken_encoder is None:
                # Map model to encoding
                enc_name = "cl100k_base"
                if self.model.startswith("gpt-4o") or self.model.startswith("o"):
                    enc_name = "o200k_base"
                self._tiktoken_encoder = tiktoken.get_encoding(enc_name)
            return len(self._tiktoken_encoder.encode(text))
        except ImportError:
            return self._count_heuristic(text)

    @staticmethod
    def _count_anthropic_estimate(text: str) -> int:
        """Estimate tokens for Anthropic models (~3.5 chars per token)."""
        return max(1, len(text) // 4)

    @staticmethod
    def _count_google_estimate(text: str) -> int:
        """Estimate tokens for Google models (~4 chars per token)."""
        return max(1, len(text) // 4)

    @staticmethod
    def _count_heuristic(text: str) -> int:
        """Generic heuristic: ~4 characters per token for English text."""
        return max(1, len(text) // 4)
