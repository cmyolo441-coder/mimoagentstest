"""Track LLM usage costs per request and cumulatively.

Records every LLM call's token counts and USD cost, provides summary
statistics, and enforces per-task and per-session cost budgets.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.constants import DEFAULT_COST_WARNING_THRESHOLD, DEFAULT_MAX_COST_PER_TASK
from terminal_agent.exceptions import CostLimitError


@dataclass
class CostRecord:
    """A single cost entry for one LLM call."""

    timestamp: float
    provider: str
    model: str
    tokens_in: int
    tokens_out: int
    cost_usd: float
    latency_ms: float
    session_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class CostTracker:
    """Accumulate cost records and enforce budgets.

    Parameters
    ----------
    max_cost_per_task : float
        Hard cap in USD for a single task session.
    warning_threshold : float
        Fraction (0-1) of ``max_cost_per_task`` at which to emit warnings.
    """

    def __init__(
        self,
        max_cost_per_task: float = DEFAULT_MAX_COST_PER_TASK,
        warning_threshold: float = DEFAULT_COST_WARNING_THRESHOLD,
    ) -> None:
        self.max_cost_per_task = max_cost_per_task
        self.warning_threshold = warning_threshold
        self._records: list[CostRecord] = []
        self._total_cost: float = 0.0
        self._total_tokens_in: int = 0
        self._total_tokens_out: int = 0
        self._warning_fired: bool = False
        self._session_id: str | None = None

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------

    def record(
        self,
        provider: str,
        model: str,
        tokens_in: int,
        tokens_out: int,
        cost_usd: float,
        latency_ms: float = 0.0,
        *,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> CostRecord:
        """Record an LLM call's cost and check budget limits.

        Returns
        -------
        CostRecord
            The newly created record.

        Raises
        ------
        CostLimitError
            If cumulative cost exceeds ``max_cost_per_task``.
        """
        rec = CostRecord(
            timestamp=time.time(),
            provider=provider,
            model=model,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            cost_usd=cost_usd,
            latency_ms=latency_ms,
            session_id=session_id or self._session_id,
            metadata=metadata or {},
        )
        self._records.append(rec)
        self._total_cost += cost_usd
        self._total_tokens_in += tokens_in
        self._total_tokens_out += tokens_out

        self._check_budget()
        return rec

    # ------------------------------------------------------------------
    # Budget enforcement
    # ------------------------------------------------------------------

    def _check_budget(self) -> None:
        """Raise or warn if cost limits are exceeded."""
        if self._total_cost >= self.max_cost_per_task:
            raise CostLimitError(
                f"Cost budget exceeded: ${self._total_cost:.4f} >= "
                f"${self.max_cost_per_task:.2f}",
                details={
                    "total_cost": self._total_cost,
                    "max_cost": self.max_cost_per_task,
                },
            )
        if (
            not self._warning_fired
            and self._total_cost >= self.max_cost_per_task * self.warning_threshold
        ):
            self._warning_fired = True

    @property
    def is_near_limit(self) -> bool:
        """Return ``True`` if cumulative cost is above the warning threshold."""
        return self._total_cost >= self.max_cost_per_task * self.warning_threshold

    @property
    def is_over_limit(self) -> bool:
        """Return ``True`` if cumulative cost exceeds the hard cap."""
        return self._total_cost >= self.max_cost_per_task

    @property
    def budget_remaining(self) -> float:
        """Return the remaining budget in USD."""
        return max(0.0, self.max_cost_per_task - self._total_cost)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    @property
    def total_cost(self) -> float:
        """Cumulative USD cost."""
        return self._total_cost

    @property
    def total_tokens_in(self) -> int:
        """Cumulative input tokens."""
        return self._total_tokens_in

    @property
    def total_tokens_out(self) -> int:
        """Cumulative output tokens."""
        return self._total_tokens_out

    @property
    def total_tokens(self) -> int:
        """Cumulative total tokens (in + out)."""
        return self._total_tokens_in + self._total_tokens_out

    @property
    def call_count(self) -> int:
        """Number of recorded LLM calls."""
        return len(self._records)

    @property
    def records(self) -> list[CostRecord]:
        """All recorded cost entries (read-only view)."""
        return list(self._records)

    @property
    def average_latency_ms(self) -> float:
        """Average latency across all recorded calls."""
        if not self._records:
            return 0.0
        return sum(r.latency_ms for r in self._records) / len(self._records)

    def cost_by_model(self) -> dict[str, float]:
        """Aggregate cost per model."""
        by_model: dict[str, float] = {}
        for rec in self._records:
            by_model[rec.model] = by_model.get(rec.model, 0.0) + rec.cost_usd
        return by_model

    def cost_by_provider(self) -> dict[str, float]:
        """Aggregate cost per provider."""
        by_provider: dict[str, float] = {}
        for rec in self._records:
            by_provider[rec.provider] = by_provider.get(rec.provider, 0.0) + rec.cost_usd
        return by_provider

    def tokens_by_model(self) -> dict[str, int]:
        """Aggregate total tokens per model."""
        by_model: dict[str, int] = {}
        for rec in self._records:
            by_model[rec.model] = by_model.get(rec.model, 0) + rec.tokens_in + rec.tokens_out
        return by_model

    def summary(self) -> dict[str, Any]:
        """Return a summary dict suitable for logging or display."""
        return {
            "total_cost_usd": round(self._total_cost, 6),
            "budget_remaining_usd": round(self.budget_remaining, 6),
            "total_calls": self.call_count,
            "total_tokens_in": self._total_tokens_in,
            "total_tokens_out": self._total_tokens_out,
            "total_tokens": self.total_tokens,
            "average_latency_ms": round(self.average_latency_ms, 1),
            "cost_by_model": {k: round(v, 6) for k, v in self.cost_by_model().items()},
            "cost_by_provider": {k: round(v, 6) for k, v in self.cost_by_provider().items()},
            "near_limit": self.is_near_limit,
            "over_limit": self.is_over_limit,
        }

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    def set_session(self, session_id: str) -> None:
        """Bind the tracker to a session ID for subsequent records."""
        self._session_id = session_id

    def reset(self) -> None:
        """Clear all records and counters."""
        self._records.clear()
        self._total_cost = 0.0
        self._total_tokens_in = 0
        self._total_tokens_out = 0
        self._warning_fired = False

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_records(self) -> list[dict[str, Any]]:
        """Export all records as JSON-serialisable dicts."""
        return [
            {
                "timestamp": r.timestamp,
                "provider": r.provider,
                "model": r.model,
                "tokens_in": r.tokens_in,
                "tokens_out": r.tokens_out,
                "cost_usd": round(r.cost_usd, 6),
                "latency_ms": round(r.latency_ms, 1),
                "session_id": r.session_id,
                "metadata": r.metadata,
            }
            for r in self._records
        ]
