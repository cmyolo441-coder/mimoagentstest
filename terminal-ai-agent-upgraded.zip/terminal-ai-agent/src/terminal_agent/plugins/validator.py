"""Plugin validator — verify plugin structure, dependencies, and compatibility.

Performs structural validation, version compatibility checks, dependency
verification, and security scanning before a plugin is allowed to load.
"""

from __future__ import annotations

import ast
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from terminal_agent.plugins.discovery import DiscoveredPlugin, PluginManifest

logger = logging.getLogger(__name__)

SEMVER_PATTERN = re.compile(
    r"^(?P<major>0|[1-9]\d*)\.(?P<minor>0|[1-9]\d*)\.(?P<patch>0|[1-9]\d*)"
    r"(?:-(?P<prerelease>(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)"
    r"(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?"
    r"(?:\+(?P<buildmetadata>[0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$"
)

DANGEROUS_IMPORTS = frozenset({
    "subprocess",
    "shutil",
    "ctypes",
    "importlib",
    "compileall",
    "py_compile",
})

DANGEROUS_BUILTINS = frozenset({
    "eval",
    "exec",
    "compile",
    "__import__",
    "globals",
    "locals",
    "getattr",
    "setattr",
    "delattr",
})


@dataclass
class ValidationResult:
    """Result of a plugin validation."""
    valid: bool = True
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def add_error(self, message: str) -> None:
        self.errors.append(message)
        self.valid = False

    def add_warning(self, message: str) -> None:
        self.warnings.append(message)


class PluginValidator:
    """Validates plugin structure, metadata, and security.

    Performs multi-level validation:
    1. Structural: manifest fields, entry point existence
    2. Semantic: version format, dependency names
    3. Compatibility: agent version requirements
    4. Security: dangerous imports, code patterns
    """

    def __init__(
        self,
        agent_version: str = "1.0.0",
        allowed_imports: set[str] | None = None,
        security_scan: bool = True,
    ):
        self._agent_version = agent_version
        self._allowed_imports = allowed_imports or set()
        self._security_scan = security_scan

    def validate(self, discovered: DiscoveredPlugin) -> ValidationResult:
        """Run all validation checks on a discovered plugin.

        Args:
            discovered: The discovered plugin to validate.

        Returns:
            ValidationResult with errors and warnings.
        """
        result = ValidationResult()

        if not discovered.valid:
            for err in discovered.errors:
                result.add_error(err)
            return result

        manifest = discovered.manifest

        self._validate_manifest(manifest, result)
        self._validate_version(manifest.version, result)
        self._validate_entry_point(discovered.path, manifest, result)
        self._validate_dependencies(manifest, result)

        if manifest.min_agent_version:
            self._validate_compatibility(manifest.min_agent_version, result)

        if self._security_scan:
            self._scan_security(discovered.path, manifest, result)

        if result.valid:
            logger.debug("Plugin '%s' validation passed", manifest.name)
        else:
            logger.warning(
                "Plugin '%s' validation failed: %s", manifest.name, result.errors
            )

        return result

    def validate_manifest_data(self, data: dict[str, Any]) -> ValidationResult:
        """Validate raw manifest data (before parsing).

        Args:
            data: Raw manifest dictionary.

        Returns:
            ValidationResult with errors and warnings.
        """
        result = ValidationResult()

        required = ("name", "version")
        for field_name in required:
            if field_name not in data:
                result.add_error(f"Missing required field: '{field_name}'")

        if "name" in data:
            name = data["name"]
            if not isinstance(name, str) or not name.strip():
                result.add_error("Plugin name must be a non-empty string")
            elif not re.match(r"^[a-zA-Z][a-zA-Z0-9_-]*$", name):
                result.add_error(
                    "Plugin name must start with a letter and contain only "
                    "letters, digits, hyphens, and underscores"
                )

        if "version" in data:
            if not isinstance(data["version"], str):
                result.add_error("Version must be a string")
            elif not SEMVER_PATTERN.match(data["version"]):
                result.add_warning(
                    f"Version '{data['version']}' does not follow semver"
                )

        if "dependencies" in data:
            deps = data["dependencies"]
            if not isinstance(deps, list):
                result.add_error("Dependencies must be a list")
            else:
                for dep in deps:
                    if not isinstance(dep, str):
                        result.add_error(f"Dependency must be a string: {dep}")

        return result

    def _validate_manifest(self, manifest: PluginManifest, result: ValidationResult) -> None:
        """Validate manifest fields."""
        if not manifest.name or not manifest.name.strip():
            result.add_error("Plugin name is empty")

        if not manifest.version:
            result.add_error("Plugin version is missing")

        if manifest.tools:
            for i, tool in enumerate(manifest.tools):
                if not isinstance(tool, dict):
                    result.add_error(f"Tool definition {i} must be a dictionary")
                    continue
                if "name" not in tool:
                    result.add_error(f"Tool definition {i} missing 'name' field")
                if "description" not in tool:
                    result.add_warning(f"Tool definition {i} missing 'description' field")

    def _validate_version(self, version: str, result: ValidationResult) -> None:
        """Validate version format."""
        if not version:
            return
        if not SEMVER_PATTERN.match(version):
            result.add_warning(f"Version '{version}' is not valid semver")

    def _validate_entry_point(
        self, path: Path, manifest: PluginManifest, result: ValidationResult
    ) -> None:
        """Validate entry point exists and is valid Python."""
        entry = path / manifest.entry_point
        if not entry.is_file():
            result.add_error(f"Entry point '{manifest.entry_point}' not found")
            return

        try:
            source = entry.read_text(encoding="utf-8")
            ast.parse(source, filename=str(entry))
        except SyntaxError as exc:
            result.add_error(f"Syntax error in entry point: {exc}")
        except OSError as exc:
            result.add_warning(f"Cannot read entry point: {exc}")

    def _validate_dependencies(
        self, manifest: PluginManifest, result: ValidationResult
    ) -> None:
        """Validate dependency declarations."""
        for dep in manifest.dependencies:
            if not isinstance(dep, str) or not dep.strip():
                result.add_error("Empty dependency declaration")

    def _validate_compatibility(
        self, min_version: str, result: ValidationResult
    ) -> None:
        """Validate agent version compatibility."""
        if not SEMVER_PATTERN.match(min_version):
            result.add_warning(f"Invalid min_agent_version format: {min_version}")
            return

        try:
            min_parts = [int(x) for x in min_version.split(".")[:3]]
            agent_parts = [int(x) for x in self._agent_version.split(".")[:3]]

            if agent_parts < min_parts:
                result.add_error(
                    f"Plugin requires agent version >= {min_version}, "
                    f"but current version is {self._agent_version}"
                )
        except (ValueError, IndexError):
            result.add_warning("Could not compare versions")

    def _scan_security(
        self, path: Path, manifest: PluginManifest, result: ValidationResult
    ) -> None:
        """Scan plugin code for security concerns."""
        entry = path / manifest.entry_point
        if not entry.is_file():
            return

        try:
            source = entry.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(entry))
        except (SyntaxError, OSError):
            return

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name in DANGEROUS_IMPORTS:
                        result.add_warning(
                            f"Potentially dangerous import: {alias.name}"
                        )

            if isinstance(node, ast.ImportFrom):
                if node.module and node.module.split(".")[0] in DANGEROUS_IMPORTS:
                    result.add_warning(
                        f"Potentially dangerous import from: {node.module}"
                    )

            if isinstance(node, ast.Call):
                func_name = self._get_call_name(node)
                if func_name in DANGEROUS_BUILTINS:
                    result.add_warning(f"Potentially dangerous call: {func_name}()")

    def _get_call_name(self, node: ast.Call) -> str:
        """Extract function name from a call node."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        if isinstance(node.func, ast.Attribute):
            return node.func.attr
        return ""
