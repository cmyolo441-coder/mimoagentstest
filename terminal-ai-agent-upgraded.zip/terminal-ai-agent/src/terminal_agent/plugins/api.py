"""Plugin API — defined interface for plugin development.

Provides the base classes and utilities that plugin authors use
to create plugins, register tools, and interact with the agent.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass
class ToolDefinition:
    """Definition of a tool provided by a plugin."""
    name: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    required: list[str] = field(default_factory=list)
    returns: str = ""
    examples: list[dict[str, Any]] = field(default_factory=list)


class PluginBase(ABC):
    """Abstract base class for all plugins.

    Plugin authors should subclass this and implement the required methods.
    The lifecycle is: __init__ -> activate -> [tool calls / hooks] -> cleanup.
    """

    @abstractmethod
    def activate(self) -> None:
        """Called when the plugin is activated.

        Perform any initialization here. If this raises, the plugin
        will not be loaded.
        """

    def cleanup(self) -> None:
        """Called when the plugin is unloaded.

        Release resources, close connections, etc.
        """

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions provided by this plugin.

        Returns:
            List of tool definition dictionaries with keys:
            - name: Tool name
            - description: Human-readable description
            - parameters: JSON Schema for parameters
            - required: List of required parameter names
        """
        return []

    def get_hooks(self) -> dict[str, Callable[..., Any]]:
        """Return hook handlers provided by this plugin.

        Returns:
            Dictionary mapping hook names to handler functions.
            Supported hooks: before_tool, after_tool, on_error,
            on_start, on_stop.
        """
        return {}


class SimplePlugin(PluginBase):
    """A convenience base class for simple plugins.

    Provides a simpler interface where tools and hooks are declared
    as class attributes or methods with decorators.
    """

    def __init__(self) -> None:
        self._tools: list[dict[str, Any]] = []
        self._hooks: dict[str, Callable[..., Any]] = {}

    def activate(self) -> None:
        """Default activation (no-op)."""

    def register_tool(
        self,
        name: str,
        handler: Callable[..., Any],
        description: str = "",
        parameters: dict[str, Any] | None = None,
        required: list[str] | None = None,
    ) -> None:
        """Register a tool with the plugin.

        Args:
            name: Tool name.
            handler: Function to call when tool is invoked.
            description: Human-readable description.
            parameters: JSON Schema for parameters.
            required: Required parameter names.
        """
        self._tools.append({
            "name": name,
            "description": description,
            "parameters": parameters or {},
            "required": required or [],
            "_handler": handler,
        })

    def register_hook(self, hook_name: str, handler: Callable[..., Any]) -> None:
        """Register a hook handler.

        Args:
            hook_name: Hook name (before_tool, after_tool, on_error, etc.).
            handler: The handler function.
        """
        self._hooks[hook_name] = handler

    def get_tools(self) -> list[dict[str, Any]]:
        """Return registered tools."""
        return [
            {k: v for k, v in t.items() if not k.startswith("_")}
            for t in self._tools
        ]

    def get_hooks(self) -> dict[str, Callable[..., Any]]:
        """Return registered hooks."""
        return dict(self._hooks)


def tool(
    name: str,
    description: str = "",
    parameters: dict[str, Any] | None = None,
    required: list[str] | None = None,
) -> Callable[..., Any]:
    """Decorator to mark a method as a tool handler.

    Usage:
        class MyPlugin(SimplePlugin):
            @tool("greet", description="Say hello", parameters={"name": {"type": "string"}})
            def greet(self, name: str) -> str:
                return f"Hello, {name}!"
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        func._tool_definition = {
            "name": name,
            "description": description,
            "parameters": parameters or {},
            "required": required or [],
        }
        return func

    return decorator


def hook(hook_name: str) -> Callable[..., Any]:
    """Decorator to mark a method as a hook handler.

    Usage:
        class MyPlugin(SimplePlugin):
            @hook("after_tool")
            def log_tool_call(self, tool_name, result):
                print(f"Tool {tool_name} completed")
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        func._hook_name = hook_name
        return func

    return decorator


class PluginContext:
    """Context object provided to plugins during execution.

    Gives plugins access to agent capabilities without direct
    coupling to internal modules.
    """

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        logger_instance: logging.Logger | None = None,
    ):
        self._config = config or {}
        self._logger = logger_instance or logging.getLogger("plugin_context")
        self._data: dict[str, Any] = {}

    @property
    def config(self) -> dict[str, Any]:
        """Access plugin configuration."""
        return self._config

    @property
    def log(self) -> logging.Logger:
        """Access the plugin logger."""
        return self._logger

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value from the context data store."""
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set a value in the context data store."""
        self._data[key] = value

    def has(self, key: str) -> bool:
        """Check if a key exists in the context data store."""
        return key in self._data
