"""Plugin system for Terminal Agent.

Provides plugin discovery, loading, validation, sandboxing, and lifecycle
management for extending the agent with custom functionality.
"""

from __future__ import annotations

from terminal_agent.plugins.discovery import PluginDiscovery
from terminal_agent.plugins.loader import PluginLoader
from terminal_agent.plugins.validator import PluginValidator
from terminal_agent.plugins.sandbox import PluginSandbox
from terminal_agent.plugins.registry import PluginRegistry
from terminal_agent.plugins.api import PluginBase
from terminal_agent.plugins.lifecycle import PluginLifecycle
from terminal_agent.plugins.config import PluginConfig
from terminal_agent.plugins.dependencies import DependencyResolver
from terminal_agent.plugins.marketplace import PluginMarketplace

__all__ = [
    "PluginDiscovery",
    "PluginLoader",
    "PluginValidator",
    "PluginSandbox",
    "PluginRegistry",
    "PluginBase",
    "PluginLifecycle",
    "PluginConfig",
    "DependencyResolver",
    "PluginMarketplace",
]
