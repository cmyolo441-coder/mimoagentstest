"""Plugin discovery — scan directories for available plugins.

Scans configured plugin directories for valid plugin packages,
parses their manifests, and returns discovered plugin metadata.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

MANIFEST_FILENAME = "plugin.json"
ALT_MANIFEST_FILENAME = "manifest.json"


@dataclass
class PluginManifest:
    """Parsed plugin manifest."""
    name: str
    version: str
    author: str = ""
    description: str = ""
    entry_point: str = "main.py"
    dependencies: list[str] = field(default_factory=list)
    min_agent_version: str | None = None
    tools: list[dict[str, Any]] = field(default_factory=list)
    config_schema: dict[str, Any] = field(default_factory=dict)
    hooks: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    license: str = ""
    homepage: str = ""
    path: str = ""


@dataclass
class DiscoveredPlugin:
    """A discovered plugin with its manifest and path."""
    manifest: PluginManifest
    path: Path
    valid: bool = True
    errors: list[str] = field(default_factory=list)


class PluginDiscovery:
    """Discovers plugins by scanning configured directories.

    Supports multiple plugin directories, nested scanning, and
    filtering by tags or names.
    """

    def __init__(self, plugin_dirs: list[str | Path] | None = None):
        self._plugin_dirs: list[Path] = []
        if plugin_dirs:
            for d in plugin_dirs:
                self.add_directory(d)

    def add_directory(self, directory: str | Path) -> None:
        """Add a plugin directory to scan."""
        path = Path(directory).expanduser().resolve()
        if path.is_dir():
            self._plugin_dirs.append(path)
            logger.debug("Added plugin directory: %s", path)
        else:
            logger.warning("Plugin directory does not exist: %s", path)

    @property
    def directories(self) -> list[Path]:
        """Return the list of configured plugin directories."""
        return list(self._plugin_dirs)

    def discover(self, *, recursive: bool = True) -> list[DiscoveredPlugin]:
        """Scan all plugin directories and return discovered plugins.

        Args:
            recursive: If True, scan subdirectories for plugins.

        Returns:
            List of discovered plugins with parsed manifests.
        """
        discovered: list[DiscoveredPlugin] = []
        seen_names: set[str] = set()

        for plugin_dir in self._plugin_dirs:
            if not plugin_dir.is_dir():
                continue
            plugins = self._scan_directory(plugin_dir, recursive=recursive)
            for plugin in plugins:
                if plugin.manifest.name not in seen_names:
                    discovered.append(plugin)
                    seen_names.add(plugin.manifest.name)
                else:
                    logger.warning(
                        "Duplicate plugin '%s' found at %s (skipping)",
                        plugin.manifest.name,
                        plugin.path,
                    )

        logger.info("Discovered %d plugin(s)", len(discovered))
        return discovered

    def discover_single(self, path: str | Path) -> DiscoveredPlugin | None:
        """Discover a single plugin at a specific path.

        Args:
            path: Path to the plugin directory.

        Returns:
            Discovered plugin or None if not valid.
        """
        plugin_path = Path(path).expanduser().resolve()
        if not plugin_path.is_dir():
            logger.error("Plugin path is not a directory: %s", plugin_path)
            return None

        manifest_path = self._find_manifest(plugin_path)
        if manifest_path is None:
            logger.error("No manifest found at %s", plugin_path)
            return DiscoveredPlugin(
                manifest=PluginManifest(name="unknown", version="0.0.0"),
                path=plugin_path,
                valid=False,
                errors=["No plugin manifest found"],
            )

        return self._parse_manifest(manifest_path)

    def _scan_directory(
        self, directory: Path, *, recursive: bool
    ) -> list[DiscoveredPlugin]:
        """Scan a directory for plugins."""
        plugins: list[DiscoveredPlugin] = []

        if self._is_plugin_dir(directory):
            plugin = self._parse_manifest(
                directory / self._find_manifest_name(directory)
            )
            if plugin:
                plugins.append(plugin)
            return plugins

        for entry in sorted(directory.iterdir()):
            if not entry.is_dir():
                continue
            if entry.name.startswith((".", "_")):
                continue

            if self._is_plugin_dir(entry):
                manifest_name = self._find_manifest_name(entry)
                if manifest_name:
                    plugin = self._parse_manifest(entry / manifest_name)
                    if plugin:
                        plugins.append(plugin)
            elif recursive:
                plugins.extend(self._scan_directory(entry, recursive=True))

        return plugins

    def _is_plugin_dir(self, path: Path) -> bool:
        """Check if a directory looks like a plugin."""
        return (path / MANIFEST_FILENAME).is_file() or (
            path / ALT_MANIFEST_FILENAME
        ).is_file()

    def _find_manifest(self, path: Path) -> Path | None:
        """Find the manifest file in a plugin directory."""
        primary = path / MANIFEST_FILENAME
        if primary.is_file():
            return primary
        alt = path / ALT_MANIFEST_FILENAME
        if alt.is_file():
            return alt
        return None

    def _find_manifest_name(self, path: Path) -> str | None:
        """Return the manifest filename found in the directory."""
        if (path / MANIFEST_FILENAME).is_file():
            return MANIFEST_FILENAME
        if (path / ALT_MANIFEST_FILENAME).is_file():
            return ALT_MANIFEST_FILENAME
        return None

    def _parse_manifest(self, manifest_path: Path) -> DiscoveredPlugin:
        """Parse a plugin manifest file."""
        errors: list[str] = []
        try:
            with open(manifest_path, encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as exc:
            logger.error("Invalid JSON in %s: %s", manifest_path, exc)
            return DiscoveredPlugin(
                manifest=PluginManifest(name="unknown", version="0.0.0"),
                path=manifest_path.parent,
                valid=False,
                errors=[f"Invalid JSON: {exc}"],
            )
        except OSError as exc:
            logger.error("Cannot read %s: %s", manifest_path, exc)
            return DiscoveredPlugin(
                manifest=PluginManifest(name="unknown", version="0.0.0"),
                path=manifest_path.parent,
                valid=False,
                errors=[f"Cannot read manifest: {exc}"],
            )

        required_fields = ("name", "version")
        for field_name in required_fields:
            if field_name not in data:
                errors.append(f"Missing required field: {field_name}")

        manifest = PluginManifest(
            name=data.get("name", "unknown"),
            version=data.get("version", "0.0.0"),
            author=data.get("author", ""),
            description=data.get("description", ""),
            entry_point=data.get("entry_point", "main.py"),
            dependencies=data.get("dependencies", []),
            min_agent_version=data.get("min_agent_version"),
            tools=data.get("tools", []),
            config_schema=data.get("config_schema", {}),
            hooks=data.get("hooks", []),
            tags=data.get("tags", []),
            license=data.get("license", ""),
            homepage=data.get("homepage", ""),
            path=str(manifest_path.parent),
        )

        entry = manifest_path.parent / manifest.entry_point
        if not entry.is_file():
            errors.append(f"Entry point not found: {manifest.entry_point}")

        return DiscoveredPlugin(
            manifest=manifest,
            path=manifest_path.parent,
            valid=len(errors) == 0,
            errors=errors,
        )
