"""Plugin configuration — per-plugin settings management.

Handles loading, validating, and merging plugin-specific configuration
from global config, project config, and plugin defaults.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PluginSettings:
    """Configuration for a single plugin."""
    name: str
    enabled: bool = True
    config: dict[str, Any] = field(default_factory=dict)
    source: str = "default"


class PluginConfig:
    """Manages configuration for all plugins.

    Supports layered configuration: default -> global -> project -> override.
    Each plugin has its own config namespace and schema.
    """

    def __init__(self, global_config: dict[str, Any] | None = None):
        self._global_config = global_config or {}
        self._plugin_configs: dict[str, PluginSettings] = {}
        self._schemas: dict[str, dict[str, Any]] = {}

    def register_defaults(
        self,
        plugin_name: str,
        defaults: dict[str, Any],
        schema: dict[str, Any] | None = None,
    ) -> None:
        """Register default configuration for a plugin.

        Args:
            plugin_name: The plugin name.
            defaults: Default configuration values.
            schema: JSON Schema for the configuration.
        """
        if plugin_name not in self._plugin_configs:
            self._plugin_configs[plugin_name] = PluginSettings(
                name=plugin_name,
                config=dict(defaults),
                source="default",
            )
        else:
            existing = self._plugin_configs[plugin_name]
            for key, value in defaults.items():
                if key not in existing.config:
                    existing.config[key] = value

        if schema:
            self._schemas[plugin_name] = schema

        logger.debug("Registered defaults for plugin '%s'", plugin_name)

    def get(self, plugin_name: str, key: str, default: Any = None) -> Any:
        """Get a configuration value for a plugin.

        Args:
            plugin_name: The plugin name.
            key: The configuration key.
            default: Default value if key not found.

        Returns:
            The configuration value.
        """
        settings = self._plugin_configs.get(plugin_name)
        if settings is None:
            return default
        return settings.config.get(key, default)

    def get_all(self, plugin_name: str) -> dict[str, Any]:
        """Get all configuration for a plugin.

        Args:
            plugin_name: The plugin name.

        Returns:
            Complete configuration dictionary.
        """
        settings = self._plugin_configs.get(plugin_name)
        if settings is None:
            return {}
        return dict(settings.config)

    def set(self, plugin_name: str, key: str, value: Any) -> None:
        """Set a configuration value for a plugin.

        Args:
            plugin_name: The plugin name.
            key: The configuration key.
            value: The value to set.
        """
        if plugin_name not in self._plugin_configs:
            self._plugin_configs[plugin_name] = PluginSettings(name=plugin_name)

        self._plugin_configs[plugin_name].config[key] = value
        self._plugin_configs[plugin_name].source = "override"

    def merge_config(self, plugin_name: str, config: dict[str, Any], source: str = "merged") -> None:
        """Merge configuration into a plugin's settings.

        Args:
            plugin_name: The plugin name.
            config: Configuration to merge.
            source: Source identifier.
        """
        if plugin_name not in self._plugin_configs:
            self._plugin_configs[plugin_name] = PluginSettings(name=plugin_name)

        settings = self._plugin_configs[plugin_name]
        self._deep_merge(settings.config, config)
        settings.source = source

    def is_enabled(self, plugin_name: str) -> bool:
        """Check if a plugin is enabled."""
        settings = self._plugin_configs.get(plugin_name)
        if settings is None:
            return True
        return settings.enabled

    def set_enabled(self, plugin_name: str, enabled: bool) -> None:
        """Enable or disable a plugin."""
        if plugin_name not in self._plugin_configs:
            self._plugin_configs[plugin_name] = PluginSettings(name=plugin_name)
        self._plugin_configs[plugin_name].enabled = enabled

    def validate_config(self, plugin_name: str, config: dict[str, Any]) -> list[str]:
        """Validate configuration against a plugin's schema.

        Args:
            plugin_name: The plugin name.
            config: Configuration to validate.

        Returns:
            List of validation errors (empty if valid).
        """
        schema = self._schemas.get(plugin_name)
        if schema is None:
            return []

        errors: list[str] = []

        required = schema.get("required", [])
        for key in required:
            if key not in config:
                errors.append(f"Missing required config key: {key}")

        properties = schema.get("properties", {})
        for key, value in config.items():
            if key in properties:
                prop_schema = properties[key]
                expected_type = prop_schema.get("type")
                if expected_type:
                    type_map = {
                        "string": str,
                        "integer": int,
                        "number": (int, float),
                        "boolean": bool,
                        "array": list,
                        "object": dict,
                    }
                    expected = type_map.get(expected_type)
                    if expected and not isinstance(value, expected):
                        errors.append(
                            f"Config key '{key}' expected {expected_type}, "
                            f"got {type(value).__name__}"
                        )

                if "enum" in prop_schema and value not in prop_schema["enum"]:
                    errors.append(
                        f"Config key '{key}' must be one of {prop_schema['enum']}"
                    )

        return errors

    def load_from_file(self, path: str | Path) -> dict[str, Any]:
        """Load plugin configuration from a JSON file.

        Args:
            path: Path to the configuration file.

        Returns:
            Loaded configuration dictionary.
        """
        config_path = Path(path)
        if not config_path.is_file():
            logger.warning("Plugin config file not found: %s", config_path)
            return {}

        try:
            with open(config_path, encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
            logger.error("Plugin config file is not a dictionary: %s", config_path)
            return {}
        except (json.JSONDecodeError, OSError) as exc:
            logger.error("Failed to load plugin config from %s: %s", config_path, exc)
            return {}

    def export_config(self, plugin_name: str) -> dict[str, Any]:
        """Export plugin configuration for serialization."""
        settings = self._plugin_configs.get(plugin_name)
        if settings is None:
            return {}
        return {
            "name": settings.name,
            "enabled": settings.enabled,
            "config": dict(settings.config),
            "source": settings.source,
        }

    def list_plugins(self) -> list[str]:
        """List all configured plugin names."""
        return list(self._plugin_configs.keys())

    def _deep_merge(self, base: dict[str, Any], override: dict[str, Any]) -> None:
        """Deep merge override into base."""
        for key, value in override.items():
            if (
                key in base
                and isinstance(base[key], dict)
                and isinstance(value, dict)
            ):
                self._deep_merge(base[key], value)
            else:
                base[key] = value
