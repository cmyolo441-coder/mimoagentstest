"""Plugin marketplace — browse and install community plugins.

Provides a client interface for discovering, searching, and installing
plugins from a remote plugin registry/marketplace.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_REGISTRY_URL = "https://plugins.terminal-agent.dev/api/v1"


@dataclass
class MarketplacePlugin:
    """A plugin listing from the marketplace."""
    name: str
    version: str
    description: str = ""
    author: str = ""
    downloads: int = 0
    rating: float = 0.0
    tags: list[str] = field(default_factory=list)
    homepage: str = ""
    repository: str = ""
    license: str = ""
    min_agent_version: str = ""
    install_url: str = ""


@dataclass
class InstallResult:
    """Result of a plugin installation."""
    success: bool
    plugin_name: str
    version: str = ""
    message: str = ""
    install_path: str = ""


class PluginMarketplace:
    """Client for the plugin marketplace/registry.

    Supports searching, listing, and installing plugins from
    a remote registry with local caching.
    """

    def __init__(
        self,
        registry_url: str | None = None,
        install_dir: str | Path | None = None,
        cache_dir: str | Path | None = None,
    ):
        self._registry_url = registry_url or DEFAULT_REGISTRY_URL
        self._install_dir = Path(install_dir) if install_dir else Path.home() / ".terminal-agent" / "plugins"
        self._cache_dir = Path(cache_dir) if cache_dir else Path.home() / ".terminal-agent" / "cache" / "marketplace"
        self._cache: dict[str, Any] = {}

    @property
    def install_dir(self) -> Path:
        return self._install_dir

    def search(self, query: str, *, tags: list[str] | None = None, limit: int = 20) -> list[MarketplacePlugin]:
        """Search for plugins in the marketplace.

        Args:
            query: Search query string.
            tags: Filter by tags.
            limit: Maximum results.

        Returns:
            List of matching marketplace plugins.
        """
        params: dict[str, str] = {"q": query, "limit": str(limit)}
        if tags:
            params["tags"] = ",".join(tags)

        try:
            data = self._api_request("/plugins/search", params)
            return [self._parse_plugin(p) for p in data.get("plugins", [])]
        except Exception as exc:
            logger.error("Marketplace search failed: %s", exc)
            return []

    def list_plugins(
        self,
        *,
        category: str | None = None,
        sort: str = "popular",
        limit: int = 50,
    ) -> list[MarketplacePlugin]:
        """List plugins from the marketplace.

        Args:
            category: Filter by category.
            sort: Sort order (popular, newest, rating, name).
            limit: Maximum results.

        Returns:
            List of marketplace plugins.
        """
        params: dict[str, str] = {"sort": sort, "limit": str(limit)}
        if category:
            params["category"] = category

        try:
            data = self._api_request("/plugins", params)
            return [self._parse_plugin(p) for p in data.get("plugins", [])]
        except Exception as exc:
            logger.error("Marketplace listing failed: %s", exc)
            return []

    def get_plugin_info(self, name: str) -> MarketplacePlugin | None:
        """Get detailed information about a plugin.

        Args:
            name: Plugin name.

        Returns:
            Plugin info or None if not found.
        """
        try:
            data = self._api_request(f"/plugins/{name}")
            return self._parse_plugin(data)
        except Exception as exc:
            logger.error("Failed to get plugin info for '%s': %s", name, exc)
            return None

    def install(self, name: str, *, version: str | None = None) -> InstallResult:
        """Install a plugin from the marketplace.

        Args:
            name: Plugin name.
            version: Specific version (latest if None).

        Returns:
            InstallResult with success status and details.
        """
        info = self.get_plugin_info(name)
        if info is None:
            return InstallResult(
                success=False,
                plugin_name=name,
                message=f"Plugin '{name}' not found in marketplace",
            )

        target_version = version or info.version
        install_url = info.install_url

        if not install_url:
            return InstallResult(
                success=False,
                plugin_name=name,
                message="No install URL available",
            )

        install_path = self._install_dir / name
        try:
            self._install_dir.mkdir(parents=True, exist_ok=True)

            if install_path.exists():
                shutil.rmtree(install_path)

            self._download_and_extract(install_url, install_path)

            logger.info("Installed plugin '%s' v%s to %s", name, target_version, install_path)
            return InstallResult(
                success=True,
                plugin_name=name,
                version=target_version,
                message=f"Successfully installed {name} v{target_version}",
                install_path=str(install_path),
            )
        except Exception as exc:
            error_msg = f"Installation failed: {exc}"
            logger.error("Failed to install plugin '%s': %s", name, error_msg)
            if install_path.exists():
                shutil.rmtree(install_path, ignore_errors=True)
            return InstallResult(
                success=False,
                plugin_name=name,
                message=error_msg,
            )

    def uninstall(self, name: str) -> bool:
        """Uninstall a plugin.

        Args:
            name: Plugin name.

        Returns:
            True if uninstalled, False if not found.
        """
        install_path = self._install_dir / name
        if not install_path.exists():
            logger.warning("Plugin '%s' not found at %s", name, install_path)
            return False

        try:
            shutil.rmtree(install_path)
            logger.info("Uninstalled plugin '%s'", name)
            return True
        except OSError as exc:
            logger.error("Failed to uninstall plugin '%s': %s", name, exc)
            return False

    def installed_plugins(self) -> list[dict[str, Any]]:
        """List locally installed plugins.

        Returns:
            List of installed plugin info dictionaries.
        """
        plugins: list[dict[str, Any]] = []
        if not self._install_dir.is_dir():
            return plugins

        for entry in sorted(self._install_dir.iterdir()):
            if not entry.is_dir():
                continue
            manifest_path = entry / "plugin.json"
            if manifest_path.is_file():
                try:
                    with open(manifest_path, encoding="utf-8") as f:
                        data = json.load(f)
                    data["install_path"] = str(entry)
                    plugins.append(data)
                except (json.JSONDecodeError, OSError):
                    plugins.append({
                        "name": entry.name,
                        "version": "unknown",
                        "install_path": str(entry),
                    })

        return plugins

    def check_updates(self) -> list[dict[str, str]]:
        """Check for available updates for installed plugins.

        Returns:
            List of plugins with available updates.
        """
        updates: list[dict[str, str]] = []
        for plugin_info in self.installed_plugins():
            name = plugin_info.get("name", "")
            local_version = plugin_info.get("version", "")
            if not name:
                continue

            remote = self.get_plugin_info(name)
            if remote and remote.version != local_version:
                updates.append({
                    "name": name,
                    "current": local_version,
                    "available": remote.version,
                })

        return updates

    def _api_request(self, path: str, params: dict[str, str] | None = None) -> dict[str, Any]:
        """Make an API request to the marketplace."""
        url = f"{self._registry_url}{path}"
        if params:
            query = "&".join(f"{k}={v}" for k, v in params.items())
            url = f"{url}?{query}"

        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            logger.error("HTTP error from marketplace: %s %s", exc.code, exc.reason)
            raise
        except urllib.error.URLError as exc:
            logger.error("Cannot reach marketplace: %s", exc.reason)
            raise

    def _parse_plugin(self, data: dict[str, Any]) -> MarketplacePlugin:
        """Parse a plugin entry from API response."""
        return MarketplacePlugin(
            name=data.get("name", ""),
            version=data.get("version", ""),
            description=data.get("description", ""),
            author=data.get("author", ""),
            downloads=data.get("downloads", 0),
            rating=data.get("rating", 0.0),
            tags=data.get("tags", []),
            homepage=data.get("homepage", ""),
            repository=data.get("repository", ""),
            license=data.get("license", ""),
            min_agent_version=data.get("min_agent_version", ""),
            install_url=data.get("install_url", ""),
        )

    def _download_and_extract(self, url: str, dest: Path) -> None:
        """Download and extract a plugin archive."""
        archive_path = dest.parent / f"{dest.name}.tar.gz"
        try:
            urllib.request.urlretrieve(url, str(archive_path))
            shutil.unpack_archive(str(archive_path), str(dest))
        finally:
            if archive_path.exists():
                archive_path.unlink()
