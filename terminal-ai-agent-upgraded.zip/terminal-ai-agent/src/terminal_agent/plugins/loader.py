"""Plugin loader — load and initialize plugin modules.

Handles importing plugin Python modules, resolving entry points,
and instantiating plugin classes with proper error handling.
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Any

from terminal_agent.exceptions import PluginLoadError
from terminal_agent.plugins.discovery import DiscoveredPlugin, PluginManifest

logger = logging.getLogger(__name__)


class PluginModule:
    """Represents a loaded plugin module."""

    def __init__(
        self,
        manifest: PluginManifest,
        module: Any,
        plugin_class: Any | None = None,
        instance: Any | None = None,
    ):
        self.manifest = manifest
        self.module = module
        self.plugin_class = plugin_class
        self.instance = instance
        self.loaded = instance is not None

    def get_tools(self) -> list[dict[str, Any]]:
        """Return tool definitions from this plugin."""
        if self.instance and hasattr(self.instance, "get_tools"):
            return self.instance.get_tools()
        if hasattr(self.module, "TOOLS"):
            return self.module.TOOLS
        return []

    def get_hooks(self) -> dict[str, Any]:
        """Return hook handlers from this plugin."""
        if self.instance and hasattr(self.instance, "get_hooks"):
            return self.instance.get_hooks()
        hooks: dict[str, Any] = {}
        for hook_name in ("before_tool", "after_tool", "on_error", "on_start", "on_stop"):
            if hasattr(self.module, hook_name):
                hooks[hook_name] = getattr(self.module, hook_name)
        return hooks


class PluginLoader:
    """Loads plugin modules from discovered plugin paths.

    Supports hot-reloading, dependency injection, and error isolation
    so that one failing plugin does not affect others.
    """

    def __init__(self):
        self._loaded: dict[str, PluginModule] = {}
        self._failed: dict[str, str] = {}

    @property
    def loaded_plugins(self) -> dict[str, PluginModule]:
        """Return currently loaded plugins."""
        return dict(self._loaded)

    @property
    def failed_plugins(self) -> dict[str, str]:
        """Return plugins that failed to load with error messages."""
        return dict(self._failed)

    def load(self, discovered: DiscoveredPlugin) -> PluginModule | None:
        """Load a single plugin from a discovered plugin entry.

        Args:
            discovered: The discovered plugin to load.

        Returns:
            PluginModule if loaded successfully, None otherwise.
        """
        if not discovered.valid:
            logger.error(
                "Cannot load invalid plugin '%s': %s",
                discovered.manifest.name,
                discovered.errors,
            )
            self._failed[discovered.manifest.name] = "; ".join(discovered.errors)
            return None

        manifest = discovered.manifest
        name = manifest.name

        if name in self._loaded:
            logger.warning("Plugin '%s' already loaded, skipping", name)
            return self._loaded[name]

        try:
            module = self._import_module(discovered)
            if module is None:
                return None

            plugin_class = self._find_plugin_class(module)
            instance = None
            if plugin_class:
                try:
                    instance = plugin_class()
                except Exception as exc:
                    logger.error(
                        "Failed to instantiate plugin class for '%s': %s", name, exc
                    )
                    self._failed[name] = f"Instantiation failed: {exc}"
                    return None

            plugin_module = PluginModule(
                manifest=manifest,
                module=module,
                plugin_class=plugin_class,
                instance=instance,
            )
            self._loaded[name] = plugin_module
            logger.info("Loaded plugin '%s' v%s", name, manifest.version)
            return plugin_module

        except PluginLoadError:
            raise
        except Exception as exc:
            error_msg = f"Unexpected error loading plugin '{name}': {exc}"
            logger.exception(error_msg)
            self._failed[name] = error_msg
            return None

    def load_all(self, discovered_list: list[DiscoveredPlugin]) -> list[PluginModule]:
        """Load multiple plugins, skipping failures.

        Args:
            discovered_list: List of discovered plugins.

        Returns:
            List of successfully loaded plugins.
        """
        loaded: list[PluginModule] = []
        for discovered in discovered_list:
            result = self.load(discovered)
            if result is not None:
                loaded.append(result)
        return loaded

    def unload(self, name: str) -> bool:
        """Unload a plugin by name.

        Args:
            name: The plugin name to unload.

        Returns:
            True if unloaded, False if not found.
        """
        if name not in self._loaded:
            return False

        plugin = self._loaded[name]
        try:
            if plugin.instance and hasattr(plugin.instance, "cleanup"):
                plugin.instance.cleanup()
        except Exception as exc:
            logger.warning("Error during plugin '%s' cleanup: %s", name, exc)

        del self._loaded[name]
        logger.info("Unloaded plugin '%s'", name)
        return True

    def reload(self, name: str, discovered: DiscoveredPlugin) -> PluginModule | None:
        """Reload a plugin (unload then load).

        Args:
            name: The plugin name to reload.
            discovered: The discovered plugin entry.

        Returns:
            PluginModule if reloaded successfully, None otherwise.
        """
        self.unload(name)
        self._failed.pop(name, None)
        return self.load(discovered)

    def _import_module(self, discovered: DiscoveredPlugin) -> Any | None:
        """Import the plugin's entry point module."""
        manifest = discovered.manifest
        name = manifest.name
        entry_path = discovered.path / manifest.entry_point

        if not entry_path.is_file():
            error_msg = f"Entry point '{manifest.entry_point}' not found for plugin '{name}'"
            logger.error(error_msg)
            self._failed[name] = error_msg
            raise PluginLoadError(error_msg)

        module_name = f"terminal_agent_plugin_{name.replace('-', '_')}"

        try:
            spec = importlib.util.spec_from_file_location(
                module_name, str(entry_path)
            )
            if spec is None or spec.loader is None:
                error_msg = f"Cannot create module spec for plugin '{name}'"
                logger.error(error_msg)
                self._failed[name] = error_msg
                return None

            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
            return module

        except SyntaxError as exc:
            error_msg = f"Syntax error in plugin '{name}': {exc}"
            logger.error(error_msg)
            self._failed[name] = error_msg
            raise PluginLoadError(error_msg) from exc
        except ImportError as exc:
            error_msg = f"Import error in plugin '{name}': {exc}"
            logger.error(error_msg)
            self._failed[name] = error_msg
            raise PluginLoadError(error_msg) from exc
        except Exception as exc:
            error_msg = f"Error loading plugin '{name}': {exc}"
            logger.exception(error_msg)
            self._failed[name] = error_msg
            raise PluginLoadError(error_msg) from exc

    def _find_plugin_class(self, module: Any) -> Any | None:
        """Find the plugin class in a module."""
        for attr_name in ("Plugin", "PluginClass", "plugin_class"):
            cls = getattr(module, attr_name, None)
            if cls is not None and isinstance(cls, type):
                return cls

        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if (
                isinstance(attr, type)
                and attr_name != "__class__"
                and hasattr(attr, "activate")
            ):
                return attr

        return None
