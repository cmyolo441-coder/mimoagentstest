"""Plugin lifecycle — manage plugin state transitions.

Handles the full lifecycle of plugins: initialization, activation,
deactivation, and cleanup with proper ordering and error handling.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from terminal_agent.exceptions import PluginError
from terminal_agent.plugins.discovery import DiscoveredPlugin
from terminal_agent.plugins.loader import PluginLoader, PluginModule
from terminal_agent.plugins.registry import PluginRegistry
from terminal_agent.plugins.sandbox import PluginSandbox, SandboxConfig
from terminal_agent.plugins.validator import PluginValidator

logger = logging.getLogger(__name__)


class PluginState(str, Enum):
    """Plugin lifecycle states."""
    DISCOVERED = "discovered"
    VALIDATED = "validated"
    LOADED = "loaded"
    ACTIVATED = "activated"
    DEACTIVATED = "deactivated"
    FAILED = "failed"
    UNLOADED = "unloaded"


@dataclass
class PluginLifecycleInfo:
    """Tracks lifecycle state for a plugin."""
    name: str
    state: PluginState = PluginState.DISCOVERED
    discovered_at: float = 0.0
    loaded_at: float = 0.0
    activated_at: float = 0.0
    error: str | None = None
    transitions: list[tuple[float, PluginState, PluginState]] = field(
        default_factory=list
    )

    def transition(self, new_state: PluginState) -> None:
        """Record a state transition."""
        now = time.time()
        self.transitions.append((now, self.state, new_state))
        self.state = new_state

    @property
    def uptime(self) -> float | None:
        """Return uptime in seconds if activated, None otherwise."""
        if self.state == PluginState.ACTIVATED and self.activated_at:
            return time.time() - self.activated_at
        return None


class PluginLifecycle:
    """Manages the complete lifecycle of all plugins.

    Coordinates discovery, validation, loading, activation, and
    cleanup of plugins with proper error isolation and ordering.
    """

    def __init__(
        self,
        validator: PluginValidator | None = None,
        sandbox_config: SandboxConfig | None = None,
    ):
        self._loader = PluginLoader()
        self._registry = PluginRegistry()
        self._validator = validator or PluginValidator()
        self._sandbox = PluginSandbox(sandbox_config)
        self._lifecycle_info: dict[str, PluginLifecycleInfo] = {}

    @property
    def loader(self) -> PluginLoader:
        return self._loader

    @property
    def registry(self) -> PluginRegistry:
        return self._registry

    @property
    def sandbox(self) -> PluginSandbox:
        return self._sandbox

    def initialize_plugin(self, discovered: DiscoveredPlugin) -> bool:
        """Run the full initialization sequence for a plugin.

        Steps: validate -> load -> register -> activate.

        Args:
            discovered: The discovered plugin.

        Returns:
            True if plugin is fully activated, False otherwise.
        """
        name = discovered.manifest.name
        info = PluginLifecycleInfo(name=name, discovered_at=time.time())
        self._lifecycle_info[name] = info

        logger.info("Initializing plugin '%s'", name)

        # Step 1: Validate
        validation = self._validator.validate(discovered)
        if not validation.valid:
            info.transition(PluginState.FAILED)
            info.error = f"Validation failed: {validation.errors}"
            logger.error("Plugin '%s' validation failed: %s", name, validation.errors)
            return False
        if validation.warnings:
            for w in validation.warnings:
                logger.warning("Plugin '%s' warning: %s", name, w)
        info.transition(PluginState.VALIDATED)

        # Step 2: Load
        plugin_module = self._loader.load(discovered)
        if plugin_module is None:
            info.transition(PluginState.FAILED)
            info.error = "Load failed"
            logger.error("Plugin '%s' failed to load", name)
            return False
        info.transition(PluginState.LOADED)
        info.loaded_at = time.time()

        # Step 3: Register
        if not self._registry.register(plugin_module):
            info.transition(PluginState.FAILED)
            info.error = "Registration failed"
            logger.error("Plugin '%s' failed to register", name)
            return False

        # Step 4: Activate
        try:
            if plugin_module.instance and hasattr(plugin_module.instance, "activate"):
                with self._sandbox.execute():
                    plugin_module.instance.activate()
            info.transition(PluginState.ACTIVATED)
            info.activated_at = time.time()
            logger.info("Plugin '%s' activated successfully", name)
            return True
        except Exception as exc:
            info.transition(PluginState.FAILED)
            info.error = f"Activation failed: {exc}"
            logger.exception("Plugin '%s' activation failed", name)
            self._registry.unregister(name)
            return False

    def deactivate_plugin(self, name: str) -> bool:
        """Deactivate a plugin.

        Args:
            name: The plugin name.

        Returns:
            True if deactivated, False if not found.
        """
        plugin = self._registry.get_plugin(name)
        if plugin is None:
            return False

        info = self._lifecycle_info.get(name)
        if info:
            info.transition(PluginState.DEACTIVATED)

        try:
            if plugin.module.instance and hasattr(plugin.module.instance, "cleanup"):
                plugin.module.instance.cleanup()
        except Exception as exc:
            logger.warning("Error during plugin '%s' cleanup: %s", name, exc)

        self._registry.deactivate(name)
        logger.info("Deactivated plugin '%s'", name)
        return True

    def unload_plugin(self, name: str) -> bool:
        """Fully unload a plugin (deactivate + unregister + unload).

        Args:
            name: The plugin name.

        Returns:
            True if unloaded, False if not found.
        """
        self.deactivate_plugin(name)
        self._registry.unregister(name)
        self._loader.unload(name)

        info = self._lifecycle_info.get(name)
        if info:
            info.transition(PluginState.UNLOADED)

        logger.info("Unloaded plugin '%s'", name)
        return True

    def get_state(self, name: str) -> PluginState | None:
        """Get the current state of a plugin."""
        info = self._lifecycle_info.get(name)
        return info.state if info else None

    def get_lifecycle_info(self, name: str) -> PluginLifecycleInfo | None:
        """Get full lifecycle info for a plugin."""
        return self._lifecycle_info.get(name)

    def get_all_states(self) -> dict[str, PluginState]:
        """Get states of all tracked plugins."""
        return {name: info.state for name, info in self._lifecycle_info.items()}

    def deactivate_all(self) -> None:
        """Deactivate all plugins."""
        for name in list(self._registry.plugins.keys()):
            self.deactivate_plugin(name)

    def unload_all(self) -> None:
        """Unload all plugins."""
        for name in list(self._registry.plugins.keys()):
            self.unload_plugin(name)
