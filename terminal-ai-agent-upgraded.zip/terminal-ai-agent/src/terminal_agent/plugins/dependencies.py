"""Plugin dependencies — resolve and manage inter-plugin dependencies.

Handles dependency graph construction, topological ordering for
load sequencing, and circular dependency detection.
"""

from __future__ import annotations

import logging
from collections import defaultdict, deque
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class DependencyNode:
    """A node in the plugin dependency graph."""
    name: str
    version: str = ""
    dependencies: list[str] = field(default_factory=list)
    dependents: list[str] = field(default_factory=list)


class DependencyError(Exception):
    """Raised when dependency resolution fails."""
    pass


class DependencyResolver:
    """Resolves plugin dependencies and determines load order.

    Builds a dependency graph, detects cycles, and produces a
    topologically sorted load order.
    """

    def __init__(self):
        self._nodes: dict[str, DependencyNode] = {}
        self._adjacency: dict[str, set[str]] = defaultdict(set)
        self._reverse: dict[str, set[str]] = defaultdict(set)

    def add_plugin(self, name: str, version: str = "", dependencies: list[str] | None = None) -> None:
        """Add a plugin to the dependency graph.

        Args:
            name: Plugin name.
            version: Plugin version.
            dependencies: List of plugin names this plugin depends on.
        """
        deps = dependencies or []
        node = DependencyNode(name=name, version=version, dependencies=deps)
        self._nodes[name] = node

        for dep in deps:
            self._adjacency[name].add(dep)
            self._reverse[dep].add(name)
            if dep in self._nodes:
                self._nodes[dep].dependents.append(name)

    def resolve(self) -> list[str]:
        """Resolve dependencies and return topologically sorted load order.

        Returns:
            List of plugin names in the order they should be loaded.

        Raises:
            DependencyError: If circular dependencies are detected or
                required plugins are missing.
        """
        self._check_missing()
        cycles = self.find_cycles()
        if cycles:
            raise DependencyError(
                f"Circular dependencies detected: {cycles}"
            )
        return self._topological_sort()

    def find_cycles(self) -> list[list[str]]:
        """Find all circular dependency chains.

        Returns:
            List of cycles, where each cycle is a list of plugin names.
        """
        cycles: list[list[str]] = []
        visited: set[str] = set()
        in_stack: set[str] = set()
        path: list[str] = []

        def dfs(node: str) -> None:
            if node in in_stack:
                cycle_start = path.index(node)
                cycles.append(path[cycle_start:] + [node])
                return
            if node in visited:
                return

            visited.add(node)
            in_stack.add(node)
            path.append(node)

            for dep in self._adjacency.get(node, set()):
                dfs(dep)

            path.pop()
            in_stack.discard(node)

        for name in self._nodes:
            if name not in visited:
                dfs(name)

        return cycles

    def get_dependencies(self, name: str) -> set[str]:
        """Get all transitive dependencies of a plugin.

        Args:
            name: Plugin name.

        Returns:
            Set of all dependency names (including transitive).
        """
        result: set[str] = set()
        queue = deque(self._adjacency.get(name, set()))

        while queue:
            dep = queue.popleft()
            if dep in result:
                continue
            result.add(dep)
            for transitive in self._adjacency.get(dep, set()):
                if transitive not in result:
                    queue.append(transitive)

        return result

    def get_dependents(self, name: str) -> set[str]:
        """Get all plugins that depend on a given plugin.

        Args:
            name: Plugin name.

        Returns:
            Set of dependent plugin names (including transitive).
        """
        result: set[str] = set()
        queue = deque(self._reverse.get(name, set()))

        while queue:
            dep = queue.popleft()
            if dep in result:
                continue
            result.add(dep)
            for transitive in self._reverse.get(dep, set()):
                if transitive not in result:
                    queue.append(transitive)

        return result

    def can_unload(self, name: str) -> tuple[bool, list[str]]:
        """Check if a plugin can be safely unloaded.

        Args:
            name: Plugin name.

        Returns:
            Tuple of (can_unload, list_of_blocked_dependents).
        """
        dependents = self._reverse.get(name, set())
        blocking = [d for d in dependents if d in self._nodes]
        return len(blocking) == 0, blocking

    def get_load_order(self, plugins: list[str]) -> list[str]:
        """Get load order for a subset of plugins.

        Args:
            plugins: List of plugin names to include.

        Returns:
            Topologically sorted list.
        """
        plugin_set = set(plugins)
        in_degree: dict[str, int] = {p: 0 for p in plugin_set}

        for name in plugin_set:
            for dep in self._adjacency.get(name, set()):
                if dep in plugin_set:
                    in_degree[name] += 1

        queue = deque(p for p in plugin_set if in_degree[p] == 0)
        result: list[str] = []

        while queue:
            node = queue.popleft()
            result.append(node)
            for dependent in self._reverse.get(node, set()):
                if dependent in plugin_set:
                    in_degree[dependent] -= 1
                    if in_degree[dependent] == 0:
                        queue.append(dependent)

        if len(result) != len(plugin_set):
            raise DependencyError("Circular dependency detected in plugin subset")

        return result

    def _topological_sort(self) -> list[str]:
        """Perform topological sort on the full graph."""
        in_degree: dict[str, int] = {}
        for name in self._nodes:
            in_degree[name] = len(self._adjacency.get(name, set()))

        queue = deque(name for name, deg in in_degree.items() if deg == 0)
        result: list[str] = []

        while queue:
            node = queue.popleft()
            result.append(node)
            for dependent in self._reverse.get(node, set()):
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        return result

    def _check_missing(self) -> None:
        """Check for missing dependencies."""
        all_names = set(self._nodes.keys())
        for name, deps in self._adjacency.items():
            missing = deps - all_names
            if missing:
                raise DependencyError(
                    f"Plugin '{name}' has missing dependencies: {missing}"
                )

    def summary(self) -> dict[str, Any]:
        """Return a summary of the dependency graph."""
        return {
            "total_plugins": len(self._nodes),
            "plugins": {
                name: {
                    "version": node.version,
                    "dependencies": node.dependencies,
                    "dependents": node.dependents,
                }
                for name, node in self._nodes.items()
            },
        }
