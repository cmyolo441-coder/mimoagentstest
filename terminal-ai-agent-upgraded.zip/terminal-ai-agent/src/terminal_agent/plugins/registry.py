"""Plugin registry — track loaded plugins and their capabilities.

Maintains a central registry of all loaded plugins, their tools,
hooks, and metadata for runtime lookup and management.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

from terminal_agent.plugins.loader import PluginModule

logger = logging.getLogger(__name__)


@dataclass
class RegisteredPlugin:
    """A plugin entry in the registry."""
    name: str
    version: str
    module: PluginModule
    tools: dict[str, dict[str, Any]] = field(default_factory=dict)
    hooks: dict[str, list[Callable[..., Any]]] = field(default_factory=lambda: {
        "before_tool": [],
        "after_tool": [],
        "on_error": [],
        "on_start": [],
        "on_stop": [],
    })
    active: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)


class PluginRegistry:
    """Central registry for loaded plugins and their capabilities.

    Provides lookup by name, tool registration, hook management,
    and enumeration of all plugin-provided functionality.
    """

    def __init__(self):
        self._plugins: dict[str, RegisteredPlugin] = {}
        self._tool_index: dict[str, str] = {}  # tool_name -> plugin_name
        self._hooks: dict[str, list[tuple[str, Callable[..., Any]]]] = {
            "before_tool": [],
            "after_tool": [],
            "on_error": [],
            "on_start": [],
            "on_stop": [],
        }

    @property
    def plugins(self) -> dict[str, RegisteredPlugin]:
        """Return all registered plugins."""
        return dict(self._plugins)

    @property
    def active_plugins(self) -> dict[str, RegisteredPlugin]:
        """Return only active plugins."""
        return {n: p for n, p in self._plugins.items() if p.active}

    @property
    def all_tools(self) -> dict[str, dict[str, Any]]:
        """Return all tools from all active plugins."""
        tools: dict[str, dict[str, Any]] = {}
        for plugin in self._plugins.values():
            if plugin.active:
                tools.update(plugin.tools)
        return tools

    def register(self, plugin_module: PluginModule) -> bool:
        """Register a loaded plugin.

        Args:
            plugin_module: The loaded plugin module.

        Returns:
            True if registered, False if already registered.
        """
        name = plugin_module.manifest.name
        if name in self._plugins:
            logger.warning("Plugin '%s' already registered", name)
            return False

        tools = {}
        for tool_def in plugin_module.get_tools():
            tool_name = tool_def.get("name", "")
            if tool_name:
                full_name = f"plugin.{name}.{tool_name}"
                tools[full_name] = {**tool_def, "plugin": name, "full_name": full_name}
                self._tool_index[full_name] = name

        hooks: dict[str, list[Callable[..., Any]]] = {
            "before_tool": [],
            "after_tool": [],
            "on_error": [],
            "on_start": [],
            "on_stop": [],
        }
        plugin_hooks = plugin_module.get_hooks()
        for hook_name, handler in plugin_hooks.items():
            if hook_name in hooks and callable(handler):
                hooks[hook_name].append(handler)
                self._hooks[hook_name].append((name, handler))

        registered = RegisteredPlugin(
            name=name,
            version=plugin_module.manifest.version,
            module=plugin_module,
            tools=tools,
            hooks=hooks,
            metadata={
                "description": plugin_module.manifest.description,
                "author": plugin_module.manifest.author,
                "tags": plugin_module.manifest.tags,
            },
        )
        self._plugins[name] = registered
        logger.info(
            "Registered plugin '%s' v%s with %d tool(s)",
            name,
            plugin_module.manifest.version,
            len(tools),
        )
        return True

    def unregister(self, name: str) -> bool:
        """Unregister a plugin.

        Args:
            name: The plugin name to unregister.

        Returns:
            True if unregistered, False if not found.
        """
        if name not in self._plugins:
            return False

        plugin = self._plugins[name]

        for tool_name in plugin.tools:
            self._tool_index.pop(tool_name, None)

        for hook_name in self._hooks:
            self._hooks[hook_name] = [
                (n, h) for n, h in self._hooks[hook_name] if n != name
            ]

        del self._plugins[name]
        logger.info("Unregistered plugin '%s'", name)
        return True

    def get_plugin(self, name: str) -> RegisteredPlugin | None:
        """Get a registered plugin by name."""
        return self._plugins.get(name)

    def get_tool_owner(self, tool_name: str) -> str | None:
        """Get the plugin name that owns a tool."""
        return self._tool_index.get(tool_name)

    def get_tool_definition(self, tool_name: str) -> dict[str, Any] | None:
        """Get a tool definition by name."""
        owner = self._tool_index.get(tool_name)
        if owner and owner in self._plugins:
            return self._plugins[owner].tools.get(tool_name)
        return None

    def activate(self, name: str) -> bool:
        """Activate a plugin."""
        if name in self._plugins:
            self._plugins[name].active = True
            logger.info("Activated plugin '%s'", name)
            return True
        return False

    def deactivate(self, name: str) -> bool:
        """Deactivate a plugin."""
        if name in self._plugins:
            self._plugins[name].active = False
            logger.info("Deactivated plugin '%s'", name)
            return True
        return False

    def get_hooks(self, hook_name: str) -> list[tuple[str, Callable[..., Any]]]:
        """Get all handlers for a hook from active plugins."""
        if hook_name not in self._hooks:
            return []
        return [
            (name, handler)
            for name, handler in self._hooks[hook_name]
            if name in self._plugins and self._plugins[name].active
        ]

    def find_by_tag(self, tag: str) -> list[RegisteredPlugin]:
        """Find plugins by tag."""
        return [
            p
            for p in self._plugins.values()
            if tag in p.metadata.get("tags", [])
        ]

    def summary(self) -> dict[str, Any]:
        """Return a summary of all registered plugins."""
        return {
            "total": len(self._plugins),
            "active": sum(1 for p in self._plugins.values() if p.active),
            "total_tools": len(self._tool_index),
            "plugins": {
                name: {
                    "version": p.version,
                    "active": p.active,
                    "tools": len(p.tools),
                }
                for name, p in self._plugins.items()
            },
        }
