"""Plugin sandbox — isolate plugin execution from the host system.

Provides resource limits, restricted filesystem access, and
network isolation for plugin code execution.
"""

from __future__ import annotations

import builtins
import logging
import os
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Generator

logger = logging.getLogger(__name__)


@dataclass
class SandboxConfig:
    """Configuration for plugin sandboxing."""
    allowed_paths: list[str] = field(default_factory=list)
    blocked_paths: list[str] = field(default_factory=lambda: [
        "/etc", "/sys", "/proc", "/boot", "/dev",
    ])
    max_memory_mb: int = 256
    max_cpu_seconds: float = 30.0
    allow_network: bool = False
    allow_subprocess: bool = False
    env_vars: dict[str, str] = field(default_factory=dict)
    restrict_builtins: bool = True


class SandboxViolation(Exception):
    """Raised when a plugin violates sandbox restrictions."""
    pass


class _RestrictedModule:
    """A proxy that raises SandboxViolation on attribute access."""

    def __init__(self, name: str):
        self._name = name

    def __getattr__(self, item: str) -> Any:
        raise SandboxViolation(
            f"Access to '{self._name}.{item}' is blocked by sandbox"
        )


class PluginSandbox:
    """Executes plugin code within a restricted sandbox.

    Provides:
    - Path-based filesystem restrictions
    - Built-in function restrictions
    - Resource monitoring (time, memory)
    - Environment variable injection
    - Thread-based execution isolation
    """

    def __init__(self, config: SandboxConfig | None = None):
        self._config = config or SandboxConfig()
        self._original_builtins: dict[str, Any] = {}
        self._active = False

    @property
    def config(self) -> SandboxConfig:
        return self._config

    @property
    def is_active(self) -> bool:
        return self._active

    @contextmanager
    def execute(self) -> Generator[None, None, None]:
        """Context manager that activates sandbox restrictions.

        Usage:
            with sandbox.execute():
                # Plugin code runs here under restrictions
                plugin_instance.activate()
        """
        self._activate()
        try:
            yield
        finally:
            self._deactivate()

    def check_path(self, path: str | Path) -> bool:
        """Check if a path is accessible within the sandbox.

        Args:
            path: The path to check.

        Returns:
            True if accessible, False otherwise.
        """
        resolved = Path(path).expanduser().resolve()
        resolved_str = str(resolved)

        for blocked in self._config.blocked_paths:
            if resolved_str.startswith(blocked):
                logger.warning("Sandbox blocked path: %s", resolved_str)
                return False

        if self._config.allowed_paths:
            for allowed in self._config.allowed_paths:
                allowed_resolved = str(Path(allowed).expanduser().resolve())
                if resolved_str.startswith(allowed_resolved):
                    return True
            logger.warning("Sandbox path not in allowed list: %s", resolved_str)
            return False

        return True

    def check_time(self, start_time: float) -> bool:
        """Check if execution time is within limits.

        Args:
            start_time: The start time (from time.monotonic()).

        Returns:
            True if within limits, False if exceeded.
        """
        elapsed = time.monotonic() - start_time
        if elapsed > self._config.max_cpu_seconds:
            logger.warning(
                "Sandbox time limit exceeded: %.1fs > %.1fs",
                elapsed,
                self._config.max_cpu_seconds,
            )
            return False
        return True

    def _activate(self) -> None:
        """Activate sandbox restrictions."""
        if self._active:
            return

        self._original_builtins.clear()

        if self._config.restrict_builtins:
            for name in ("eval", "exec", "compile", "__import__"):
                if hasattr(builtins, name):
                    self._original_builtins[name] = getattr(builtins, name)
                    if not self._config.allow_subprocess and name in ("__import__"):
                        continue
                    setattr(builtins, name, self._make_restricted(name))

        old_environ = dict(os.environ)
        os.environ.update(self._config.env_vars)

        self._active = True
        logger.debug("Sandbox activated")

    def _deactivate(self) -> None:
        """Deactivate sandbox restrictions."""
        if not self._active:
            return

        for name, original in self._original_builtins.items():
            setattr(builtins, name, original)
        self._original_builtins.clear()

        self._active = False
        logger.debug("Sandbox deactivated")

    def _make_restricted(self, name: str) -> Any:
        """Create a restricted version of a built-in."""

        def restricted(*args: Any, **kwargs: Any) -> Any:
            raise SandboxViolation(
                f"Builtin '{name}' is restricted by plugin sandbox"
            )

        return restricted

    def run_with_limits(
        self,
        func: Any,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """Run a function within sandbox limits using a thread.

        Args:
            func: The function to run.
            *args: Positional arguments.
            **kwargs: Keyword arguments.

        Returns:
            The function's return value.

        Raises:
            SandboxViolation: If limits are exceeded.
            Exception: Any exception from the function.
        """
        result: list[Any] = [None]
        error: list[Exception | None] = [None]
        start_time = time.monotonic()

        def target() -> None:
            try:
                with self.execute():
                    result[0] = func(*args, **kwargs)
            except Exception as exc:
                error[0] = exc

        thread = threading.Thread(target=target, daemon=True)
        thread.start()
        thread.join(timeout=self._config.max_cpu_seconds)

        if thread.is_alive():
            logger.error("Plugin execution timed out")
            raise SandboxViolation(
                f"Plugin execution exceeded {self._config.max_cpu_seconds}s limit"
            )

        if error[0] is not None:
            raise error[0]

        return result[0]
