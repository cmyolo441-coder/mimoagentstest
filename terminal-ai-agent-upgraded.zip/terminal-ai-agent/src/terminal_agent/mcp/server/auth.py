"""MCP authentication — verify and authorize incoming MCP requests.

Provides token-based and API key authentication for the MCP server
to prevent unauthorized access to agent tools.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import secrets
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class AuthToken:
    """An authentication token."""
    token_hash: str
    client_name: str = ""
    scopes: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    expires_at: float | None = None
    enabled: bool = True


class MCPAuthenticator:
    """Handles authentication for MCP server requests.

    Supports API key and token-based authentication with
    scope-based authorization and token rotation.
    """

    def __init__(self, enabled: bool = False):
        self._enabled = enabled
        self._tokens: dict[str, AuthToken] = {}
        self._api_keys: dict[str, AuthToken] = {}

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    def add_token(
        self,
        token: str,
        client_name: str = "",
        scopes: list[str] | None = None,
        expires_in: float | None = None,
    ) -> None:
        """Add an authentication token.

        Args:
            token: The token string.
            client_name: Name of the client.
            scopes: Allowed scopes.
            expires_in: Token TTL in seconds.
        """
        token_hash = self._hash(token)
        self._tokens[token_hash] = AuthToken(
            token_hash=token_hash,
            client_name=client_name,
            scopes=scopes or ["*"],
            expires_at=time.time() + expires_in if expires_in else None,
        )
        logger.debug("Added auth token for client '%s'", client_name)

    def add_api_key(
        self,
        api_key: str,
        client_name: str = "",
        scopes: list[str] | None = None,
    ) -> None:
        """Add an API key.

        Args:
            api_key: The API key string.
            client_name: Name of the client.
            scopes: Allowed scopes.
        """
        key_hash = self._hash(api_key)
        self._api_keys[key_hash] = AuthToken(
            token_hash=key_hash,
            client_name=client_name,
            scopes=scopes or ["*"],
        )
        logger.debug("Added API key for client '%s'", client_name)

    def remove_token(self, token: str) -> bool:
        """Remove a token."""
        token_hash = self._hash(token)
        if token_hash in self._tokens:
            del self._tokens[token_hash]
            return True
        return False

    def remove_api_key(self, api_key: str) -> bool:
        """Remove an API key."""
        key_hash = self._hash(api_key)
        if key_hash in self._api_keys:
            del self._api_keys[key_hash]
            return True
        return False

    def verify(self, message: dict[str, Any]) -> bool:
        """Verify authentication for a JSON-RPC message.

        Args:
            message: The JSON-RPC message.

        Returns:
            True if authenticated, False otherwise.
        """
        if not self._enabled:
            return True

        params = message.get("params", {})
        token = params.get("_auth_token") or params.get("token")
        api_key = params.get("_api_key") or params.get("apiKey")

        if token:
            return self._verify_token(token)
        if api_key:
            return self._verify_api_key(api_key)

        headers = message.get("_headers", {})
        auth_header = headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            return self._verify_token(auth_header[7:])
        if auth_header.startswith("ApiKey "):
            return self._verify_api_key(auth_header[7:])

        logger.warning("No authentication provided")
        return False

    def check_scope(self, message: dict[str, Any], required_scope: str) -> bool:
        """Check if the authenticated client has a required scope.

        Args:
            message: The JSON-RPC message.
            required_scope: The required scope.

        Returns:
            True if scope is authorized.
        """
        if not self._enabled:
            return True

        params = message.get("params", {})
        token = params.get("_auth_token") or params.get("token")

        if token:
            token_hash = self._hash(token)
            auth_token = self._tokens.get(token_hash)
            if auth_token and auth_token.enabled:
                return "*" in auth_token.scopes or required_scope in auth_token.scopes

        return False

    def generate_token(self, client_name: str = "", scopes: list[str] | None = None) -> str:
        """Generate a new random authentication token.

        Args:
            client_name: Name of the client.
            scopes: Allowed scopes.

        Returns:
            The generated token string.
        """
        token = secrets.token_urlsafe(32)
        self.add_token(token, client_name, scopes)
        return token

    def _verify_token(self, token: str) -> bool:
        """Verify a bearer token."""
        token_hash = self._hash(token)
        auth_token = self._tokens.get(token_hash)

        if auth_token is None:
            logger.warning("Unknown token")
            return False

        if not auth_token.enabled:
            logger.warning("Disabled token for client '%s'", auth_token.client_name)
            return False

        if auth_token.expires_at and time.time() > auth_token.expires_at:
            logger.warning("Expired token for client '%s'", auth_token.client_name)
            return False

        return True

    def _verify_api_key(self, api_key: str) -> bool:
        """Verify an API key."""
        key_hash = self._hash(api_key)
        auth_token = self._api_keys.get(key_hash)

        if auth_token is None:
            logger.warning("Unknown API key")
            return False

        if not auth_token.enabled:
            logger.warning("Disabled API key for client '%s'", auth_token.client_name)
            return False

        return True

    def _hash(self, value: str) -> str:
        """Hash a sensitive value."""
        return hashlib.sha256(value.encode("utf-8")).hexdigest()
