"""MCP request handler — route and execute incoming MCP requests.

Handles dispatching of MCP protocol methods (tools/call, tools/list,
resources/list, etc.) to registered handlers.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from terminal_agent.mcp.server.registration import MCPToolRegistration

logger = logging.getLogger(__name__)


@dataclass
class RequestLog:
    """Log entry for a handled request."""
    method: str
    params: dict[str, Any]
    result: Any = None
    error: str | None = None
    duration_ms: float = 0.0
    timestamp: float = field(default_factory=time.time)


class MCPRequestHandler:
    """Routes and executes incoming MCP protocol requests.

    Handles the core MCP methods and delegates tool calls
    to registered tool handlers.
    """

    def __init__(self, registration: MCPToolRegistration | None = None):
        self._registration = registration or MCPToolRegistration()
        self._resource_handlers: dict[str, Callable[..., Any]] = {}
        self._prompt_handlers: dict[str, Callable[..., Any]] = {}
        self._request_log: list[RequestLog] = []

    @property
    def registration(self) -> MCPToolRegistration:
        return self._registration

    async def handle_list_tools(self, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Handle tools/list request.

        Returns:
            MCP tools/list response.
        """
        tools = self._registration.list_tools()
        return {"tools": tools}

    async def handle_call_tool(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle tools/call request.

        Args:
            params: Must contain 'name' and 'arguments'.

        Returns:
            MCP tools/call response with content blocks.
        """
        name = params.get("name", "")
        arguments = params.get("arguments", {})

        log_entry = RequestLog(method="tools/call", params=params)
        start = time.monotonic()

        try:
            handler = self._registration.get_handler(name)
            if handler is None:
                log_entry.error = f"Tool not found: {name}"
                return {
                    "content": [{"type": "text", "text": f"Tool not found: {name}"}],
                    "isError": True,
                }

            if asyncio.iscoroutinefunction(handler):
                result = await handler(arguments)
            else:
                result = handler(arguments)

            log_entry.duration_ms = (time.monotonic() - start) * 1000
            log_entry.result = result

            if isinstance(result, dict) and "content" in result:
                return result

            return {
                "content": [{"type": "text", "text": str(result)}],
                "isError": False,
            }

        except Exception as exc:
            log_entry.duration_ms = (time.monotonic() - start) * 1000
            log_entry.error = str(exc)
            logger.exception("Error calling tool '%s'", name)
            return {
                "content": [{"type": "text", "text": f"Error: {exc}"}],
                "isError": True,
            }
        finally:
            self._request_log.append(log_entry)

    async def handle_list_resources(
        self, params: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Handle resources/list request."""
        resources = [
            {"uri": uri, "name": name, "description": f"Resource: {name}"}
            for uri, name in self._resource_handlers.items()
        ]
        return {"resources": resources}

    async def handle_read_resource(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle resources/read request."""
        uri = params.get("uri", "")
        handler = self._resource_handlers.get(uri)
        if handler is None:
            raise ValueError(f"Resource not found: {uri}")

        if asyncio.iscoroutinefunction(handler):
            content = await handler(params)
        else:
            content = handler(params)

        return {
            "contents": [
                {"uri": uri, "text": str(content)}
            ]
        }

    async def handle_list_prompts(
        self, params: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Handle prompts/list request."""
        prompts = [
            {"name": name, "description": f"Prompt: {name}"}
            for name in self._prompt_handlers
        ]
        return {"prompts": prompts}

    async def handle_get_prompt(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle prompts/get request."""
        name = params.get("name", "")
        handler = self._prompt_handlers.get(name)
        if handler is None:
            raise ValueError(f"Prompt not found: {name}")

        if asyncio.iscoroutinefunction(handler):
            result = await handler(params)
        else:
            result = handler(params)

        if isinstance(result, dict):
            return result
        return {
            "description": f"Prompt: {name}",
            "messages": [
                {"role": "user", "content": {"type": "text", "text": str(result)}}
            ],
        }

    def register_resource(self, uri: str, handler: Callable[..., Any]) -> None:
        """Register a resource handler."""
        self._resource_handlers[uri] = handler

    def register_prompt(self, name: str, handler: Callable[..., Any]) -> None:
        """Register a prompt handler."""
        self._prompt_handlers[name] = handler

    def get_request_log(self, limit: int = 100) -> list[RequestLog]:
        """Get recent request log entries."""
        return self._request_log[-limit:]
