"""MCP tool registration — register agent tools for MCP exposure.

Manages which agent tools are exposed via the MCP server and
handles tool metadata translation for the MCP protocol.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass
class ExposedTool:
    """A tool exposed via the MCP server."""
    name: str
    description: str = ""
    input_schema: dict[str, Any] = field(default_factory=dict)
    handler: Callable[..., Any] | None = None
    tags: list[str] = field(default_factory=list)
    enabled: bool = True

    def to_mcp_format(self) -> dict[str, Any]:
        """Convert to MCP tools/list format."""
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


class MCPToolRegistration:
    """Manages registration of tools for MCP server exposure.

    Allows selective exposure of agent tools via the MCP protocol
    with filtering, naming, and metadata customization.
    """

    def __init__(self):
        self._tools: dict[str, ExposedTool] = {}
        self._aliases: dict[str, str] = {}

    @property
    def tool_count(self) -> int:
        return len([t for t in self._tools.values() if t.enabled])

    def register(
        self,
        name: str,
        handler: Callable[..., Any],
        description: str = "",
        input_schema: dict[str, Any] | None = None,
        tags: list[str] | None = None,
        alias: str | None = None,
    ) -> None:
        """Register a tool for MCP exposure.

        Args:
            name: Tool name (as exposed via MCP).
            handler: Async or sync callable to handle tool invocations.
            description: Human-readable description.
            input_schema: JSON Schema for tool parameters.
            tags: Tags for categorization.
            alias: Optional alias name.
        """
        tool = ExposedTool(
            name=name,
            description=description,
            input_schema=input_schema or {},
            handler=handler,
            tags=tags or [],
        )
        self._tools[name] = tool

        if alias:
            self._aliases[alias] = name

        logger.debug("Registered MCP tool: %s", name)

    def unregister(self, name: str) -> bool:
        """Unregister a tool.

        Args:
            name: Tool name.

        Returns:
            True if unregistered.
        """
        resolved = self._aliases.get(name, name)
        if resolved in self._tools:
            del self._tools[resolved]
            self._aliases = {a: n for a, n in self._aliases.items() if n != resolved}
            logger.debug("Unregistered MCP tool: %s", resolved)
            return True
        return False

    def get_tool(self, name: str) -> ExposedTool | None:
        """Get a tool by name or alias."""
        resolved = self._aliases.get(name, name)
        return self._tools.get(resolved)

    def get_handler(self, name: str) -> Callable[..., Any] | None:
        """Get the handler for a tool."""
        tool = self.get_tool(name)
        return tool.handler if tool else None

    def list_tools(self, *, tags: list[str] | None = None) -> list[dict[str, Any]]:
        """List all enabled tools in MCP format.

        Args:
            tags: Filter by tags (None = all).

        Returns:
            List of tool definitions in MCP format.
        """
        result: list[dict[str, Any]] = []
        for tool in self._tools.values():
            if not tool.enabled:
                continue
            if tags and not any(t in tool.tags for t in tags):
                continue
            result.append(tool.to_mcp_format())
        return result

    def enable(self, name: str) -> bool:
        """Enable a tool."""
        resolved = self._aliases.get(name, name)
        if resolved in self._tools:
            self._tools[resolved].enabled = True
            return True
        return False

    def disable(self, name: str) -> bool:
        """Disable a tool."""
        resolved = self._aliases.get(name, name)
        if resolved in self._tools:
            self._tools[resolved].enabled = False
            return True
        return False

    def clear(self) -> None:
        """Unregister all tools."""
        self._tools.clear()
        self._aliases.clear()

    def summary(self) -> dict[str, Any]:
        """Return registration summary."""
        return {
            "total": len(self._tools),
            "enabled": self.tool_count,
            "aliases": len(self._aliases),
            "tools": [t.name for t in self._tools.values() if t.enabled],
        }
