"""MCP rate limiter — control request rate for incoming MCP requests.

Implements token bucket and sliding window algorithms for
rate limiting MCP server requests per method and globally.
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class RateLimitConfig:
    """Configuration for a rate limit."""
    max_requests: int = 60
    window_seconds: float = 60.0
    burst_size: int = 10


@dataclass
class RateLimitState:
    """State for a rate limiter bucket."""
    tokens: float = 0.0
    last_refill: float = field(default_factory=time.time)
    request_times: list[float] = field(default_factory=list)
    total_requests: int = 0
    total_rejected: int = 0


class MCPRateLimiter:
    """Rate limiter for MCP server requests.

    Uses a token bucket algorithm for smooth rate limiting with
    burst support and per-method limits.
    """

    def __init__(
        self,
        default_config: RateLimitConfig | None = None,
        enabled: bool = True,
    ):
        self._enabled = enabled
        self._default_config = default_config or RateLimitConfig()
        self._method_configs: dict[str, RateLimitConfig] = {}
        self._global_state = RateLimitState(tokens=float(self._default_config.max_requests))
        self._method_states: dict[str, RateLimitState] = {}

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    def set_method_limit(self, method: str, config: RateLimitConfig) -> None:
        """Set a custom rate limit for a specific method.

        Args:
            method: The MCP method name.
            config: Rate limit configuration.
        """
        self._method_configs[method] = config
        self._method_states[method] = RateLimitState(tokens=float(config.max_requests))

    def allow(self, method: str = "") -> bool:
        """Check if a request is allowed under rate limits.

        Args:
            method: The MCP method name.

        Returns:
            True if the request is allowed, False if rate limited.
        """
        if not self._enabled:
            return True

        now = time.time()

        if not self._check_bucket(self._global_state, self._default_config, now):
            self._global_state.total_rejected += 1
            logger.warning("Global rate limit exceeded")
            return False

        if method and method in self._method_configs:
            config = self._method_configs[method]
            state = self._method_states[method]
            if not self._check_bucket(state, config, now):
                state.total_rejected += 1
                logger.warning("Rate limit exceeded for method '%s'", method)
                return False

        self._global_state.total_requests += 1
        if method in self._method_states:
            self._method_states[method].total_requests += 1

        return True

    def get_remaining(self, method: str = "") -> int:
        """Get remaining request capacity.

        Args:
            method: The MCP method name.

        Returns:
            Number of remaining requests in the current window.
        """
        self._refill(self._global_state, self._default_config)
        remaining = int(self._global_state.tokens)

        if method and method in self._method_states:
            config = self._method_configs[method]
            state = self._method_states[method]
            self._refill(state, config)
            remaining = min(remaining, int(state.tokens))

        return remaining

    def reset(self, method: str | None = None) -> None:
        """Reset rate limiter state.

        Args:
            method: Specific method to reset, or None for all.
        """
        if method is None:
            self._global_state = RateLimitState(
                tokens=float(self._default_config.max_requests)
            )
            for state in self._method_states.values():
                state.tokens = float(self._default_config.max_requests)
                state.request_times.clear()
        elif method in self._method_states:
            config = self._method_configs[method]
            self._method_states[method] = RateLimitState(
                tokens=float(config.max_requests)
            )

    def summary(self) -> dict[str, Any]:
        """Return rate limiter summary."""
        return {
            "enabled": self._enabled,
            "global": {
                "max_requests": self._default_config.max_requests,
                "window_seconds": self._default_config.window_seconds,
                "remaining": self.get_remaining(),
                "total_requests": self._global_state.total_requests,
                "total_rejected": self._global_state.total_rejected,
            },
            "methods": {
                method: {
                    "max_requests": config.max_requests,
                    "remaining": self.get_remaining(method),
                    "total_requests": self._method_states[method].total_requests,
                    "total_rejected": self._method_states[method].total_rejected,
                }
                for method, config in self._method_configs.items()
            },
        }

    def _check_bucket(
        self, state: RateLimitState, config: RateLimitConfig, now: float
    ) -> bool:
        """Check and consume a token from the bucket."""
        self._refill(state, config)

        if state.tokens >= 1.0:
            state.tokens -= 1.0
            state.request_times.append(now)
            cutoff = now - config.window_seconds
            state.request_times = [t for t in state.request_times if t > cutoff]
            return True

        return False

    def _refill(self, state: RateLimitState, config: RateLimitConfig) -> None:
        """Refill tokens based on elapsed time."""
        now = time.time()
        elapsed = now - state.last_refill
        refill_rate = config.max_requests / config.window_seconds
        tokens_to_add = elapsed * refill_rate
        state.tokens = min(
            float(config.max_requests) + config.burst_size,
            state.tokens + tokens_to_add,
        )
        state.last_refill = now
