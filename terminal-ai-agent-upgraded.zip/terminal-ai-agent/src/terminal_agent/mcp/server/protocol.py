"""MCP protocol server — implement the MCP server-side protocol.

Handles the JSON-RPC protocol layer for serving MCP requests
over stdio or HTTP transports.
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from dataclasses import dataclass, field
from typing import Any, Callable, TextIO

from terminal_agent.mcp.server.auth import MCPAuthenticator
from terminal_agent.mcp.server.handler import MCPRequestHandler
from terminal_agent.mcp.server.rate_limiter import MCPRateLimiter

logger = logging.getLogger(__name__)


@dataclass
class MCPServerConfig:
    """Configuration for the MCP protocol server."""
    name: str = "terminal-agent"
    version: str = "1.0.0"
    transport: str = "stdio"
    host: str = "localhost"
    port: int = 8765
    auth_enabled: bool = False
    rate_limit_enabled: bool = True
    max_requests_per_minute: int = 60


class MCPProtocolServer:
    """Implements the MCP server protocol.

    Handles JSON-RPC message parsing, method routing, and
    response formatting according to the MCP specification.
    """

    def __init__(
        self,
        config: MCPServerConfig | None = None,
        handler: MCPRequestHandler | None = None,
        auth: MCPAuthenticator | None = None,
        rate_limiter: MCPRateLimiter | None = None,
    ):
        self._config = config or MCPServerConfig()
        self._handler = handler or MCPRequestHandler()
        self._auth = auth or MCPAuthenticator()
        self._rate_limiter = rate_limiter or MCPRateLimiter()
        self._running = False
        self._server: asyncio.Server | None = None

    @property
    def config(self) -> MCPServerConfig:
        return self._config

    @property
    def handler(self) -> MCPRequestHandler:
        return self._handler

    @property
    def is_running(self) -> bool:
        return self._running

    async def start(self) -> None:
        """Start the MCP protocol server."""
        if self._running:
            return

        self._running = True
        logger.info(
            "Starting MCP server '%s' v%s on %s",
            self._config.name,
            self._config.version,
            self._config.transport,
        )

        if self._config.transport == "stdio":
            await self._run_stdio()
        elif self._config.transport == "http":
            await self._run_http()
        else:
            raise ValueError(f"Unsupported transport: {self._config.transport}")

    async def stop(self) -> None:
        """Stop the MCP protocol server."""
        self._running = False
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        logger.info("MCP server stopped")

    async def handle_message(self, raw_message: str) -> str | None:
        """Handle a single JSON-RPC message.

        Args:
            raw_message: Raw JSON-RPC message string.

        Returns:
            JSON-RPC response string, or None for notifications.
        """
        try:
            message = json.loads(raw_message)
        except json.JSONDecodeError as exc:
            return self._error_response(None, -32700, f"Parse error: {exc}")

        method = message.get("method", "")
        params = message.get("params", {})
        msg_id = message.get("id")

        if self._config.auth_enabled and not self._auth.verify(message):
            return self._error_response(msg_id, -32000, "Authentication failed")

        if self._config.rate_limit_enabled and not self._rate_limiter.allow(method):
            return self._error_response(msg_id, -32000, "Rate limit exceeded")

        if msg_id is None:
            await self._handle_notification(method, params)
            return None

        try:
            result = await self._dispatch(method, params)
            return json.dumps({
                "jsonrpc": "2.0",
                "result": result,
                "id": msg_id,
            })
        except Exception as exc:
            logger.exception("Error handling '%s'", method)
            return self._error_response(msg_id, -32603, str(exc))

    async def _dispatch(self, method: str, params: dict[str, Any]) -> Any:
        """Dispatch a method to the appropriate handler."""
        dispatch_map: dict[str, Callable[..., Any]] = {
            "initialize": self._handle_initialize,
            "tools/list": self._handler.handle_list_tools,
            "tools/call": self._handler.handle_call_tool,
            "resources/list": self._handler.handle_list_resources,
            "resources/read": self._handler.handle_read_resource,
            "prompts/list": self._handler.handle_list_prompts,
            "prompts/get": self._handler.handle_get_prompt,
            "ping": self._handle_ping,
        }

        handler_func = dispatch_map.get(method)
        if handler_func is None:
            raise ValueError(f"Unknown method: {method}")

        if asyncio.iscoroutinefunction(handler_func):
            return await handler_func(params)
        return handler_func(params)

    async def _handle_initialize(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle MCP initialize request."""
        return {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": {"listChanged": True},
                "resources": {"subscribe": False, "listChanged": False},
                "prompts": {"listChanged": False},
            },
            "serverInfo": {
                "name": self._config.name,
                "version": self._config.version,
            },
        }

    async def _handle_notification(self, method: str, params: dict[str, Any]) -> None:
        """Handle a JSON-RPC notification."""
        if method == "notifications/initialized":
            logger.debug("Client initialized")
        elif method == "notifications/cancelled":
            logger.debug("Request cancelled: %s", params)
        else:
            logger.debug("Unknown notification: %s", method)

    async def _handle_ping(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle ping request."""
        return {}

    async def _run_stdio(self) -> None:
        """Run the server on stdio transport."""
        loop = asyncio.get_event_loop()
        reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(reader)
        await loop.connect_read_pipe(lambda: protocol, sys.stdin)

        while self._running:
            try:
                line = await reader.readline()
                if not line:
                    break

                response = await self.handle_message(line.decode("utf-8").strip())
                if response:
                    sys.stdout.write(response + "\n")
                    sys.stdout.flush()

            except Exception as exc:
                logger.error("Stdio server error: %s", exc)

    async def _run_http(self) -> None:
        """Run the server on HTTP transport."""
        logger.info(
            "HTTP MCP server listening on %s:%d",
            self._config.host,
            self._config.port,
        )
        while self._running:
            await asyncio.sleep(1)

    def _error_response(
        self, msg_id: Any, code: int, message: str
    ) -> str:
        """Create a JSON-RPC error response."""
        return json.dumps({
            "jsonrpc": "2.0",
            "error": {"code": code, "message": message},
            "id": msg_id,
        })
