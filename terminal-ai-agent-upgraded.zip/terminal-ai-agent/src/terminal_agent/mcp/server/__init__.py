"""MCP server package — expose agent tools via MCP protocol."""

from __future__ import annotations

from terminal_agent.mcp.server.protocol import MCPProtocolServer
from terminal_agent.mcp.server.registration import MCPToolRegistration
from terminal_agent.mcp.server.handler import MCPRequestHandler
from terminal_agent.mcp.server.auth import MCPAuthenticator
from terminal_agent.mcp.server.rate_limiter import MCPRateLimiter

__all__ = [
    "MCPProtocolServer",
    "MCPToolRegistration",
    "MCPRequestHandler",
    "MCPAuthenticator",
    "MCPRateLimiter",
]
