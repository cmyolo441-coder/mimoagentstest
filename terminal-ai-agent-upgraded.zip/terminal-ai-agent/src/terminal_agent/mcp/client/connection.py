"""MCP connection — manage connections to MCP servers.

Handles establishing, maintaining, and closing connections to external
MCP servers using JSON-RPC over stdio or HTTP transports.
"""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

from terminal_agent.exceptions import MCPConnectionError

logger = logging.getLogger(__name__)


class TransportType(str, Enum):
    """MCP transport types."""
    STDIO = "stdio"
    HTTP = "http"
    SSE = "sse"


class ConnectionState(str, Enum):
    """Connection states."""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    CLOSED = "closed"


@dataclass
class MCPServerConfig:
    """Configuration for an MCP server connection."""
    name: str
    transport: TransportType = TransportType.STDIO
    command: str = ""
    args: list[str] = field(default_factory=list)
    url: str = ""
    env: dict[str, str] = field(default_factory=dict)
    timeout: float = 30.0
    max_retries: int = 3
    retry_delay: float = 1.0


@dataclass
class JSONRPCRequest:
    """JSON-RPC 2.0 request."""
    method: str
    params: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict[str, Any]:
        return {
            "jsonrpc": "2.0",
            "method": self.method,
            "params": self.params,
            "id": self.id,
        }


@dataclass
class JSONRPCResponse:
    """JSON-RPC 2.0 response."""
    id: str | None = None
    result: Any = None
    error: dict[str, Any] | None = None

    @property
    def is_error(self) -> bool:
        return self.error is not None


class MCPConnection:
    """Manages a connection to an MCP server.

    Supports stdio and HTTP transports with automatic reconnection,
    request/response correlation, and timeout handling.
    """

    def __init__(self, config: MCPServerConfig):
        self._config = config
        self._state = ConnectionState.DISCONNECTED
        self._process: subprocess.Popen | None = None
        self._pending: dict[str, asyncio.Future[JSONRPCResponse]] = {}
        self._callbacks: dict[str, Callable[..., Any]] = {}
        self._read_task: asyncio.Task[None] | None = None
        self._request_id: int = 0

    @property
    def config(self) -> MCPServerConfig:
        return self._config

    @property
    def state(self) -> ConnectionState:
        return self._state

    @property
    def is_connected(self) -> bool:
        return self._state == ConnectionState.CONNECTED

    async def connect(self) -> None:
        """Establish connection to the MCP server.

        Raises:
            MCPConnectionError: If connection fails.
        """
        if self._state == ConnectionState.CONNECTED:
            return

        self._state = ConnectionState.CONNECTING
        logger.info("Connecting to MCP server '%s' via %s", self._config.name, self._config.transport.value)

        try:
            if self._config.transport == TransportType.STDIO:
                await self._connect_stdio()
            elif self._config.transport in (TransportType.HTTP, TransportType.SSE):
                await self._connect_http()
            else:
                raise MCPConnectionError(f"Unsupported transport: {self._config.transport}")

            self._state = ConnectionState.CONNECTED
            logger.info("Connected to MCP server '%s'", self._config.name)

            await self._initialize()

        except Exception as exc:
            self._state = ConnectionState.DISCONNECTED
            raise MCPConnectionError(f"Failed to connect to '{self._config.name}': {exc}") from exc

    async def disconnect(self) -> None:
        """Close the connection to the MCP server."""
        if self._state in (ConnectionState.DISCONNECTED, ConnectionState.CLOSED):
            return

        self._state = ConnectionState.CLOSED

        if self._read_task and not self._read_task.done():
            self._read_task.cancel()
            try:
                await self._read_task
            except asyncio.CancelledError:
                pass

        if self._process:
            try:
                self._process.terminate()
                self._process.wait(timeout=5)
            except (subprocess.TimeoutExpired, ProcessLookupError):
                self._process.kill()
            self._process = None

        for future in self._pending.values():
            if not future.done():
                future.cancel()
        self._pending.clear()

        logger.info("Disconnected from MCP server '%s'", self._config.name)

    async def send_request(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> Any:
        """Send a JSON-RPC request and wait for the response.

        Args:
            method: The RPC method name.
            params: Method parameters.
            timeout: Request timeout in seconds.

        Returns:
            The result from the server.

        Raises:
            MCPConnectionError: If not connected or request fails.
        """
        if self._state != ConnectionState.CONNECTED:
            raise MCPConnectionError(f"Not connected (state: {self._state.value})")

        self._request_id += 1
        request = JSONRPCRequest(
            method=method,
            params=params or {},
            id=str(self._request_id),
        )

        future: asyncio.Future[JSONRPCResponse] = asyncio.get_event_loop().create_future()
        self._pending[request.id] = future

        try:
            await self._send_message(request.to_dict())
            response = await asyncio.wait_for(future, timeout=timeout or self._config.timeout)

            if response.is_error:
                error = response.error
                raise MCPConnectionError(
                    f"RPC error: {error.get('message', 'Unknown')} (code: {error.get('code', 0)})"
                )

            return response.result

        except asyncio.TimeoutError:
            self._pending.pop(request.id, None)
            raise MCPConnectionError(f"Request timed out: {method}")
        except MCPConnectionError:
            raise
        except Exception as exc:
            self._pending.pop(request.id, None)
            raise MCPConnectionError(f"Request failed: {exc}") from exc

    async def send_notification(self, method: str, params: dict[str, Any] | None = None) -> None:
        """Send a JSON-RPC notification (no response expected)."""
        if self._state != ConnectionState.CONNECTED:
            raise MCPConnectionError(f"Not connected (state: {self._state.value})")

        message = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
        }
        await self._send_message(message)

    def on(self, event: str, callback: Callable[..., Any]) -> None:
        """Register an event callback."""
        self._callbacks[event] = callback

    async def _initialize(self) -> None:
        """Send initialize request to the MCP server."""
        try:
            result = await self.send_request("initialize", {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {
                    "name": "terminal-agent",
                    "version": "1.0.0",
                },
            })
            logger.debug("MCP server '%s' initialized: %s", self._config.name, result)
            await self.send_notification("notifications/initialized")
        except MCPConnectionError:
            logger.warning("MCP server '%s' does not support initialize", self._config.name)

    async def _connect_stdio(self) -> None:
        """Connect via stdio transport."""
        try:
            env = {**dict(__import__("os").environ), **self._config.env}
            self._process = subprocess.Popen(
                [self._config.command, *self._config.args],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
            )
            self._read_task = asyncio.create_task(self._read_stdio())
        except FileNotFoundError as exc:
            raise MCPConnectionError(f"Command not found: {self._config.command}") from exc
        except Exception as exc:
            raise MCPConnectionError(f"Failed to start stdio process: {exc}") from exc

    async def _connect_http(self) -> None:
        """Connect via HTTP/SSE transport."""
        if not self._config.url:
            raise MCPConnectionError("No URL configured for HTTP transport")
        logger.debug("HTTP transport to %s (placeholder)", self._config.url)

    async def _read_stdio(self) -> None:
        """Read messages from stdio transport."""
        if not self._process or not self._process.stdout:
            return

        loop = asyncio.get_event_loop()
        try:
            while self._state == ConnectionState.CONNECTED:
                line = await loop.run_in_executor(
                    None, self._process.stdout.readline
                )
                if not line:
                    break

                try:
                    data = json.loads(line.decode("utf-8").strip())
                    self._handle_message(data)
                except json.JSONDecodeError:
                    logger.warning("Invalid JSON from MCP server: %s", line[:200])

        except Exception as exc:
            if self._state == ConnectionState.CONNECTED:
                logger.error("Error reading from MCP server: %s", exc)

    def _handle_message(self, data: dict[str, Any]) -> None:
        """Handle an incoming message from the server."""
        if "id" in data and ("result" in data or "error" in data):
            response = JSONRPCResponse(
                id=str(data["id"]),
                result=data.get("result"),
                error=data.get("error"),
            )
            future = self._pending.pop(str(data["id"]), None)
            if future and not future.done():
                future.set_result(response)
        elif "method" in data:
            callback = self._callbacks.get(data["method"])
            if callback:
                try:
                    callback(data.get("params", {}))
                except Exception as exc:
                    logger.error("Error in callback for '%s': %s", data["method"], exc)

    async def _send_message(self, message: dict[str, Any]) -> None:
        """Send a message to the MCP server."""
        if self._config.transport == TransportType.STDIO:
            await self._send_stdio(message)
        else:
            await self._send_http(message)

    async def _send_stdio(self, message: dict[str, Any]) -> None:
        """Send via stdio transport."""
        if not self._process or not self._process.stdin:
            raise MCPConnectionError("Process not running")

        data = json.dumps(message) + "\n"
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(
                None, self._process.stdin.write, data.encode("utf-8")
            )
            await loop.run_in_executor(None, self._process.stdin.flush)
        except (BrokenPipeError, OSError) as exc:
            self._state = ConnectionState.DISCONNECTED
            raise MCPConnectionError(f"Connection lost: {exc}") from exc

    async def _send_http(self, message: dict[str, Any]) -> None:
        """Send via HTTP transport."""
        logger.debug("HTTP send (placeholder): %s", message.get("method"))
