"""MCP connection health — monitor and maintain MCP server connections.

Provides health checks, automatic reconnection, and connection
quality tracking for MCP server connections.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

from terminal_agent.mcp.client.connection import MCPConnection, ConnectionState

logger = logging.getLogger(__name__)


class HealthStatus(str, Enum):
    """Health check results."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


@dataclass
class HealthCheckResult:
    """Result of a health check."""
    server_name: str
    status: HealthStatus
    latency_ms: float = 0.0
    message: str = ""
    timestamp: float = field(default_factory=time.time)


@dataclass
class ConnectionMetrics:
    """Metrics for a server connection."""
    server_name: str
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    total_latency_ms: float = 0.0
    last_check: float = 0.0
    consecutive_failures: int = 0
    uptime_start: float = 0.0
    reconnect_count: int = 0

    @property
    def success_rate(self) -> float:
        if self.total_requests == 0:
            return 1.0
        return self.successful_requests / self.total_requests

    @property
    def average_latency_ms(self) -> float:
        if self.successful_requests == 0:
            return 0.0
        return self.total_latency_ms / self.successful_requests


class MCPHealthMonitor:
    """Monitors health of MCP server connections.

    Performs periodic health checks, tracks connection metrics,
    and triggers automatic reconnection when needed.
    """

    def __init__(
        self,
        check_interval: float = 30.0,
        unhealthy_threshold: int = 3,
        reconnect_enabled: bool = True,
    ):
        self._check_interval = check_interval
        self._unhealthy_threshold = unhealthy_threshold
        self._reconnect_enabled = reconnect_enabled
        self._connections: dict[str, MCPConnection] = {}
        self._metrics: dict[str, ConnectionMetrics] = {}
        self._last_results: dict[str, HealthCheckResult] = {}
        self._monitor_task: asyncio.Task[None] | None = None
        self._callbacks: list[Callable[[HealthCheckResult], None]] = []
        self._running = False

    def register(self, connection: MCPConnection) -> None:
        """Register a connection for health monitoring."""
        name = connection.config.name
        self._connections[name] = connection
        self._metrics[name] = ConnectionMetrics(server_name=name)
        logger.debug("Registered health monitoring for '%s'", name)

    def unregister(self, server_name: str) -> None:
        """Unregister a connection from monitoring."""
        self._connections.pop(server_name, None)
        self._metrics.pop(server_name, None)
        self._last_results.pop(server_name, None)

    def on_health_change(self, callback: Callable[[HealthCheckResult], None]) -> None:
        """Register a callback for health status changes."""
        self._callbacks.append(callback)

    async def start(self) -> None:
        """Start the health monitoring loop."""
        if self._running:
            return
        self._running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        logger.info("Health monitor started (interval: %.1fs)", self._check_interval)

    async def stop(self) -> None:
        """Stop the health monitoring loop."""
        self._running = False
        if self._monitor_task and not self._monitor_task.done():
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        logger.info("Health monitor stopped")

    async def check(self, server_name: str) -> HealthCheckResult:
        """Perform a health check on a specific server.

        Args:
            server_name: The server to check.

        Returns:
            HealthCheckResult with status and metrics.
        """
        connection = self._connections.get(server_name)
        if connection is None:
            return HealthCheckResult(
                server_name=server_name,
                status=HealthStatus.UNKNOWN,
                message="Server not registered",
            )

        metrics = self._metrics.get(server_name)
        if metrics is None:
            metrics = ConnectionMetrics(server_name=server_name)
            self._metrics[server_name] = metrics

        metrics.total_requests += 1
        start_time = time.monotonic()

        try:
            if not connection.is_connected:
                raise Exception("Not connected")

            await connection.send_request("ping", timeout=5.0)

            latency = (time.monotonic() - start_time) * 1000
            metrics.successful_requests += 1
            metrics.total_latency_ms += latency
            metrics.consecutive_failures = 0
            metrics.last_check = time.time()

            status = HealthStatus.HEALTHY
            if latency > 5000:
                status = HealthStatus.DEGRADED

            result = HealthCheckResult(
                server_name=server_name,
                status=status,
                latency_ms=latency,
                message="OK",
            )

        except Exception as exc:
            latency = (time.monotonic() - start_time) * 1000
            metrics.failed_requests += 1
            metrics.consecutive_failures += 1
            metrics.last_check = time.time()

            if metrics.consecutive_failures >= self._unhealthy_threshold:
                status = HealthStatus.UNHEALTHY
            else:
                status = HealthStatus.DEGRADED

            result = HealthCheckResult(
                server_name=server_name,
                status=status,
                latency_ms=latency,
                message=str(exc),
            )

            if (
                self._reconnect_enabled
                and metrics.consecutive_failures >= self._unhealthy_threshold
            ):
                asyncio.create_task(self._attempt_reconnect(server_name))

        self._last_results[server_name] = result

        previous = self._last_results.get(server_name)
        if previous and previous.status != result.status:
            for cb in self._callbacks:
                try:
                    cb(result)
                except Exception:
                    pass

        return result

    async def check_all(self) -> dict[str, HealthCheckResult]:
        """Check health of all registered servers."""
        results: dict[str, HealthCheckResult] = {}
        for name in list(self._connections.keys()):
            results[name] = await self.check(name)
        return results

    def get_status(self, server_name: str) -> HealthStatus:
        """Get last known health status of a server."""
        result = self._last_results.get(server_name)
        return result.status if result else HealthStatus.UNKNOWN

    def get_metrics(self, server_name: str) -> ConnectionMetrics | None:
        """Get connection metrics for a server."""
        return self._metrics.get(server_name)

    def get_all_metrics(self) -> dict[str, ConnectionMetrics]:
        """Get metrics for all servers."""
        return dict(self._metrics)

    def summary(self) -> dict[str, Any]:
        """Return a summary of all monitored connections."""
        return {
            "total_servers": len(self._connections),
            "healthy": sum(
                1 for r in self._last_results.values()
                if r.status == HealthStatus.HEALTHY
            ),
            "degraded": sum(
                1 for r in self._last_results.values()
                if r.status == HealthStatus.DEGRADED
            ),
            "unhealthy": sum(
                1 for r in self._last_results.values()
                if r.status == HealthStatus.UNHEALTHY
            ),
            "servers": {
                name: {
                    "status": self._last_results[name].status.value
                    if name in self._last_results
                    else "unknown",
                    "success_rate": self._metrics[name].success_rate
                    if name in self._metrics
                    else 0.0,
                    "avg_latency_ms": self._metrics[name].average_latency_ms
                    if name in self._metrics
                    else 0.0,
                }
                for name in self._connections
            },
        }

    async def _monitor_loop(self) -> None:
        """Background monitoring loop."""
        while self._running:
            try:
                await self.check_all()
            except Exception as exc:
                logger.error("Health monitor error: %s", exc)
            await asyncio.sleep(self._check_interval)

    async def _attempt_reconnect(self, server_name: str) -> None:
        """Attempt to reconnect to an unhealthy server."""
        connection = self._connections.get(server_name)
        if connection is None:
            return

        metrics = self._metrics.get(server_name)
        if metrics:
            metrics.reconnect_count += 1

        logger.info("Attempting reconnect to '%s'", server_name)
        try:
            await connection.disconnect()
            await connection.connect()
            logger.info("Reconnected to '%s'", server_name)
        except Exception as exc:
            logger.error("Reconnect failed for '%s': %s", server_name, exc)
