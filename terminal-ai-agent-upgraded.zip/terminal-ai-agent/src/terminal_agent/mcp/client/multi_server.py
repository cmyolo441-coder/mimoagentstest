"""MCP multi-server — manage multiple MCP server connections.

Provides a unified interface for connecting to, managing, and
routing tool calls across multiple MCP servers simultaneously.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.exceptions import MCPConnectionError
from terminal_agent.mcp.client.connection import MCPConnection, MCPServerConfig, TransportType
from terminal_agent.mcp.client.discovery import MCPToolDiscovery, MCPToolInfo
from terminal_agent.mcp.client.health import MCPHealthMonitor, HealthStatus
from terminal_agent.mcp.client.result import MCPResultTranslator
from terminal_agent.mcp.client.tool_call import MCPToolCaller
from terminal_agent.types import ToolCall, ToolResult, ToolResultStatus

logger = logging.getLogger(__name__)


@dataclass
class ServerEntry:
    """An entry in the multi-server manager."""
    name: str
    config: MCPServerConfig
    connection: MCPConnection
    priority: int = 0
    enabled: bool = True


class MCPMultiServer:
    """Manages connections to multiple MCP servers.

    Provides unified tool discovery, health monitoring, and tool
    call routing across all connected servers with load balancing
    and failover support.
    """

    def __init__(self, health_check_interval: float = 30.0):
        self._servers: dict[str, ServerEntry] = {}
        self._discovery = MCPToolDiscovery()
        self._health = MCPHealthMonitor(check_interval=health_check_interval)
        self._caller = MCPToolCaller(self._discovery)
        self._translator = MCPResultTranslator()

    @property
    def discovery(self) -> MCPToolDiscovery:
        return self._discovery

    @property
    def health(self) -> MCPHealthMonitor:
        return self._health

    @property
    def connected_servers(self) -> list[str]:
        """List names of connected servers."""
        return [
            name
            for name, entry in self._servers.items()
            if entry.connection.is_connected and entry.enabled
        ]

    async def add_server(self, config: MCPServerConfig, priority: int = 0) -> bool:
        """Add and connect to an MCP server.

        Args:
            config: Server configuration.
            priority: Server priority (higher = preferred).

        Returns:
            True if connected successfully.
        """
        name = config.name
        if name in self._servers:
            logger.warning("Server '%s' already added", name)
            return False

        connection = MCPConnection(config)
        entry = ServerEntry(
            name=name,
            config=config,
            connection=connection,
            priority=priority,
        )
        self._servers[name] = entry

        try:
            await connection.connect()
            self._caller.register_connection(name, connection)
            self._health.register(connection)

            tools = await self._discovery.discover(connection)
            logger.info(
                "Added MCP server '%s' with %d tool(s)", name, len(tools)
            )
            return True

        except MCPConnectionError as exc:
            logger.error("Failed to connect to MCP server '%s': %s", name, exc)
            return False

    async def remove_server(self, name: str) -> bool:
        """Disconnect and remove an MCP server.

        Args:
            name: Server name.

        Returns:
            True if removed.
        """
        entry = self._servers.pop(name, None)
        if entry is None:
            return False

        self._health.unregister(name)
        self._caller.unregister_connection(name)
        self._discovery.remove_server(name)

        try:
            await entry.connection.disconnect()
        except Exception as exc:
            logger.warning("Error disconnecting '%s': %s", name, exc)

        logger.info("Removed MCP server '%s'", name)
        return True

    async def call_tool(self, tool_call: ToolCall) -> ToolResult:
        """Route a tool call to the appropriate MCP server.

        Args:
            tool_call: The tool call to execute.

        Returns:
            ToolResult from the server.
        """
        tool_info = self._discovery.get_tool(tool_call.name)
        if tool_info is None:
            return ToolResult(
                status=ToolResultStatus.ERROR,
                error=f"MCP tool not found: {tool_call.name}",
            )

        entry = self._servers.get(tool_info.server_name)
        if entry is None or not entry.enabled:
            return ToolResult(
                status=ToolResultStatus.ERROR,
                error=f"MCP server '{tool_info.server_name}' is not available",
            )

        return await self._caller.call(tool_call)

    async def discover_all_tools(self) -> list[MCPToolInfo]:
        """Discover tools from all connected servers.

        Returns:
            Combined list of all available tools.
        """
        all_tools: list[MCPToolInfo] = []
        for name, entry in self._servers.items():
            if entry.connection.is_connected and entry.enabled:
                tools = await self._discovery.discover(entry.connection)
                all_tools.extend(tools)
        return all_tools

    async def health_check_all(self) -> dict[str, HealthStatus]:
        """Check health of all servers.

        Returns:
            Dictionary mapping server names to health status.
        """
        results = await self._health.check_all()
        return {name: result.status for name, result in results.items()}

    def get_server(self, name: str) -> ServerEntry | None:
        """Get a server entry by name."""
        return self._servers.get(name)

    def enable_server(self, name: str) -> bool:
        """Enable a server."""
        entry = self._servers.get(name)
        if entry:
            entry.enabled = True
            return True
        return False

    def disable_server(self, name: str) -> bool:
        """Disable a server (keeps connection but stops routing)."""
        entry = self._servers.get(name)
        if entry:
            entry.enabled = False
            return True
        return False

    def get_tools_by_server(self) -> dict[str, list[dict[str, Any]]]:
        """Get all tools grouped by server."""
        result: dict[str, list[dict[str, Any]]] = {}
        for name in self._servers:
            tools = self._discovery.get_tools_for_server(name)
            result[name] = [t.to_agent_tool() for t in tools]
        return result

    async def shutdown(self) -> None:
        """Disconnect all servers and stop monitoring."""
        await self._health.stop()
        for name in list(self._servers.keys()):
            await self.remove_server(name)
        logger.info("MCP multi-server shut down")

    def summary(self) -> dict[str, Any]:
        """Return a summary of all servers and tools."""
        return {
            "total_servers": len(self._servers),
            "connected": len(self.connected_servers),
            "total_tools": self._discovery.tool_count,
            "health": self._health.summary(),
            "servers": {
                name: {
                    "connected": entry.connection.is_connected,
                    "enabled": entry.enabled,
                    "priority": entry.priority,
                    "tools": len(self._discovery.get_tools_for_server(name)),
                }
                for name, entry in self._servers.items()
            },
        }
