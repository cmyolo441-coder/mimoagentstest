"""MCP result translation — convert MCP responses to agent format.

Handles translation between MCP protocol response types and
the agent's internal tool result format.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.types import ToolResult, ToolResultStatus

logger = logging.getLogger(__name__)


@dataclass
class ContentBlock:
    """A translated content block."""
    type: str  # text, image, resource, error
    content: str = ""
    mime_type: str = ""
    uri: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


class MCPResultTranslator:
    """Translates MCP protocol responses into agent-compatible formats.

    Handles all MCP content types (text, image, resource, embeddedResource)
    and converts them to the agent's ToolResult format.
    """

    def translate(self, raw_result: Any) -> ToolResult:
        """Translate an MCP response to a ToolResult.

        Args:
            raw_result: Raw MCP response.

        Returns:
            Translated ToolResult.
        """
        if raw_result is None:
            return ToolResult(
                status=ToolResultStatus.SUCCESS,
                output="",
            )

        if isinstance(raw_result, dict):
            return self._translate_dict(raw_result)

        if isinstance(raw_result, list):
            return self._translate_list(raw_result)

        return ToolResult(
            status=ToolResultStatus.SUCCESS,
            output=str(raw_result),
        )

    def translate_content_blocks(self, raw_result: Any) -> list[ContentBlock]:
        """Translate MCP response into structured content blocks.

        Args:
            raw_result: Raw MCP response.

        Returns:
            List of ContentBlock objects.
        """
        blocks: list[ContentBlock] = []

        if isinstance(raw_result, dict):
            content = raw_result.get("content", [])
            if isinstance(content, list):
                for item in content:
                    block = self._parse_content_item(item)
                    if block:
                        blocks.append(block)
            elif isinstance(content, str):
                blocks.append(ContentBlock(type="text", content=content))

        elif isinstance(raw_result, list):
            for item in raw_result:
                block = self._parse_content_item(item)
                if block:
                    blocks.append(block)

        elif isinstance(raw_result, str):
            blocks.append(ContentBlock(type="text", content=raw_result))

        return blocks

    def extract_text(self, raw_result: Any) -> str:
        """Extract plain text from an MCP response.

        Args:
            raw_result: Raw MCP response.

        Returns:
            Concatenated text content.
        """
        blocks = self.translate_content_blocks(raw_result)
        text_parts = [b.content for b in blocks if b.type == "text" and b.content]
        return "\n".join(text_parts)

    def extract_images(self, raw_result: Any) -> list[dict[str, str]]:
        """Extract image references from an MCP response.

        Args:
            raw_result: Raw MCP response.

        Returns:
            List of image info dictionaries.
        """
        blocks = self.translate_content_blocks(raw_result)
        return [
            {"mime_type": b.mime_type, "uri": b.uri, "content": b.content}
            for b in blocks
            if b.type == "image"
        ]

    def is_error(self, raw_result: Any) -> bool:
        """Check if an MCP response indicates an error."""
        if isinstance(raw_result, dict):
            return raw_result.get("isError", False)
        return False

    def _translate_dict(self, data: dict[str, Any]) -> ToolResult:
        """Translate a dict MCP response."""
        is_error = data.get("isError", False)
        content = data.get("content", [])

        text_parts: list[str] = []
        if isinstance(content, list):
            for item in content:
                text = self._extract_text_from_item(item)
                if text:
                    text_parts.append(text)
        elif isinstance(content, str):
            text_parts.append(content)

        output = "\n".join(text_parts) if text_parts else ""

        return ToolResult(
            status=ToolResultStatus.ERROR if is_error else ToolResultStatus.SUCCESS,
            output=output,
            error=output if is_error else None,
            metadata={
                key: value
                for key, value in data.items()
                if key not in ("content", "isError")
            },
        )

    def _translate_list(self, items: list[Any]) -> ToolResult:
        """Translate a list MCP response."""
        text_parts: list[str] = []
        for item in items:
            text = self._extract_text_from_item(item)
            if text:
                text_parts.append(text)

        output = "\n".join(text_parts) if text_parts else str(items)
        return ToolResult(
            status=ToolResultStatus.SUCCESS,
            output=output,
        )

    def _parse_content_item(self, item: Any) -> ContentBlock | None:
        """Parse a single MCP content item."""
        if isinstance(item, str):
            return ContentBlock(type="text", content=item)

        if not isinstance(item, dict):
            return ContentBlock(type="text", content=str(item))

        item_type = item.get("type", "text")

        if item_type == "text":
            return ContentBlock(type="text", content=item.get("text", ""))
        elif item_type == "image":
            return ContentBlock(
                type="image",
                content=item.get("data", ""),
                mime_type=item.get("mimeType", ""),
            )
        elif item_type == "resource":
            resource = item.get("resource", {})
            return ContentBlock(
                type="resource",
                content=resource.get("text", ""),
                uri=resource.get("uri", ""),
                mime_type=resource.get("mimeType", ""),
            )
        else:
            return ContentBlock(type="text", content=str(item))

    def _extract_text_from_item(self, item: Any) -> str:
        """Extract text from a single content item."""
        if isinstance(item, str):
            return item
        if isinstance(item, dict):
            if item.get("type") == "text":
                return item.get("text", "")
            if item.get("type") == "resource":
                resource = item.get("resource", {})
                return resource.get("text", "")
        return ""
