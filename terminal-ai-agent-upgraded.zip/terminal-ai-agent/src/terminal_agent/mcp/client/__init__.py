"""MCP client package — connect to external MCP servers."""

from __future__ import annotations

from terminal_agent.mcp.client.connection import MCPConnection
from terminal_agent.mcp.client.discovery import MCPToolDiscovery
from terminal_agent.mcp.client.tool_call import MCPToolCaller
from terminal_agent.mcp.client.result import MCPResultTranslator
from terminal_agent.mcp.client.health import MCPHealthMonitor
from terminal_agent.mcp.client.multi_server import MCPMultiServer

__all__ = [
    "MCPConnection",
    "MCPToolDiscovery",
    "MCPToolCaller",
    "MCPResultTranslator",
    "MCPHealthMonitor",
    "MCPMultiServer",
]
