"""MCP tool call — forward tool calls to MCP servers.

Translates agent tool calls into MCP protocol requests and
routes them to the appropriate server.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.exceptions import MCPConnectionError, ToolExecutionError
from terminal_agent.mcp.client.connection import MCPConnection
from terminal_agent.mcp.client.discovery import MCPToolDiscovery, MCPToolInfo
from terminal_agent.types import ToolCall, ToolResult, ToolResultStatus

logger = logging.getLogger(__name__)


@dataclass
class CallRecord:
    """Record of an MCP tool call."""
    tool_name: str
    server_name: str
    parameters: dict[str, Any]
    result: Any = None
    error: str | None = None
    duration_ms: float = 0.0
    success: bool = False


class MCPToolCaller:
    """Routes tool calls to the appropriate MCP server.

    Resolves tool names to server connections, forwards calls,
    and translates results back into the agent's format.
    """

    def __init__(self, discovery: MCPToolDiscovery):
        self._discovery = discovery
        self._connections: dict[str, MCPConnection] = {}
        self._call_history: list[CallRecord] = []

    def register_connection(self, server_name: str, connection: MCPConnection) -> None:
        """Register a server connection for tool routing.

        Args:
            server_name: The server name.
            connection: The MCP connection.
        """
        self._connections[server_name] = connection
        logger.debug("Registered connection for server '%s'", server_name)

    def unregister_connection(self, server_name: str) -> None:
        """Unregister a server connection."""
        self._connections.pop(server_name, None)

    async def call(self, tool_call: ToolCall) -> ToolResult:
        """Execute an MCP tool call.

        Args:
            tool_call: The tool call from the agent.

        Returns:
            ToolResult with the server's response.
        """
        tool_info = self._discovery.get_tool(tool_call.name)
        if tool_info is None:
            return ToolResult(
                status=ToolResultStatus.ERROR,
                error=f"MCP tool not found: {tool_call.name}",
            )

        connection = self._connections.get(tool_info.server_name)
        if connection is None:
            return ToolResult(
                status=ToolResultStatus.ERROR,
                error=f"No connection to MCP server '{tool_info.server_name}'",
            )

        if not connection.is_connected:
            return ToolResult(
                status=ToolResultStatus.ERROR,
                error=f"MCP server '{tool_info.server_name}' is not connected",
            )

        record = CallRecord(
            tool_name=tool_call.name,
            server_name=tool_info.server_name,
            parameters=tool_call.parameters,
        )

        import time
        start = time.monotonic()

        try:
            result = await connection.send_request("tools/call", {
                "name": tool_info.name,
                "arguments": tool_call.parameters,
            })

            record.duration_ms = (time.monotonic() - start) * 1000
            record.result = result
            record.success = True

            return self._translate_result(result, tool_info)

        except MCPConnectionError as exc:
            record.duration_ms = (time.monotonic() - start) * 1000
            record.error = str(exc)
            self._call_history.append(record)

            logger.error("MCP tool call failed for '%s': %s", tool_call.name, exc)
            return ToolResult(
                status=ToolResultStatus.ERROR,
                error=str(exc),
                duration_ms=record.duration_ms,
            )
        except Exception as exc:
            record.duration_ms = (time.monotonic() - start) * 1000
            record.error = str(exc)
            self._call_history.append(record)

            logger.exception("Unexpected error calling MCP tool '%s'", tool_call.name)
            return ToolResult(
                status=ToolResultStatus.ERROR,
                error=f"Unexpected error: {exc}",
                duration_ms=record.duration_ms,
            )

    def get_call_history(self, limit: int = 100) -> list[CallRecord]:
        """Get recent call history."""
        return self._call_history[-limit:]

    def clear_history(self) -> None:
        """Clear call history."""
        self._call_history.clear()

    def _translate_result(self, raw: Any, tool_info: MCPToolInfo) -> ToolResult:
        """Translate MCP response to ToolResult."""
        if isinstance(raw, dict):
            content = raw.get("content", [])
            error = raw.get("isError", False)

            text_parts: list[str] = []
            for item in content:
                if isinstance(item, dict):
                    if item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                    elif item.get("type") == "image":
                        text_parts.append(f"[Image: {item.get('mimeType', 'unknown')}]")
                    elif item.get("type") == "resource":
                        text_parts.append(f"[Resource: {item.get('uri', 'unknown')}]")
                elif isinstance(item, str):
                    text_parts.append(item)

            output = "\n".join(text_parts) if text_parts else str(raw)

            return ToolResult(
                status=ToolResultStatus.ERROR if error else ToolResultStatus.SUCCESS,
                output=output,
                error=output if error else None,
            )

        return ToolResult(
            status=ToolResultStatus.SUCCESS,
            output=str(raw),
        )
