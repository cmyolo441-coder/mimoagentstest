"""MCP tool discovery — discover tools available on MCP servers.

Queries connected MCP servers for their available tools and
translates them into the agent's internal tool format.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from terminal_agent.mcp.client.connection import MCPConnection

logger = logging.getLogger(__name__)


@dataclass
class MCPToolInfo:
    """Information about a tool available on an MCP server."""
    name: str
    description: str = ""
    input_schema: dict[str, Any] = field(default_factory=dict)
    server_name: str = ""
    full_name: str = ""

    def to_agent_tool(self) -> dict[str, Any]:
        """Convert to agent tool definition format."""
        return {
            "name": self.full_name,
            "description": self.description,
            "parameters": self.input_schema,
            "source": "mcp",
            "server": self.server_name,
            "original_name": self.name,
        }


class MCPToolDiscovery:
    """Discovers tools available on connected MCP servers.

    Queries each server's tool list and registers them for use
    by the agent's tool dispatcher.
    """

    def __init__(self):
        self._tools: dict[str, MCPToolInfo] = {}
        self._server_tools: dict[str, list[str]] = {}

    @property
    def tools(self) -> dict[str, MCPToolInfo]:
        """All discovered tools."""
        return dict(self._tools)

    @property
    def tool_count(self) -> int:
        """Total number of discovered tools."""
        return len(self._tools)

    async def discover(self, connection: MCPConnection) -> list[MCPToolInfo]:
        """Discover tools from a connected MCP server.

        Args:
            connection: Connected MCP server.

        Returns:
            List of discovered tool info objects.
        """
        server_name = connection.config.name
        logger.info("Discovering tools from MCP server '%s'", server_name)

        try:
            result = await connection.send_request("tools/list", {})
        except Exception as exc:
            logger.error("Failed to discover tools from '%s': %s", server_name, exc)
            return []

        raw_tools = result.get("tools", []) if isinstance(result, dict) else []
        discovered: list[MCPToolInfo] = []
        tool_names: list[str] = []

        for raw in raw_tools:
            name = raw.get("name", "")
            if not name:
                continue

            full_name = f"mcp.{server_name}.{name}"
            info = MCPToolInfo(
                name=name,
                description=raw.get("description", ""),
                input_schema=raw.get("inputSchema", {}),
                server_name=server_name,
                full_name=full_name,
            )
            self._tools[full_name] = info
            tool_names.append(full_name)
            discovered.append(info)

        self._server_tools[server_name] = tool_names
        logger.info(
            "Discovered %d tool(s) from MCP server '%s'",
            len(discovered),
            server_name,
        )
        return discovered

    def get_tool(self, full_name: str) -> MCPToolInfo | None:
        """Get tool info by full name."""
        return self._tools.get(full_name)

    def get_tools_for_server(self, server_name: str) -> list[MCPToolInfo]:
        """Get all tools from a specific server."""
        tool_names = self._server_tools.get(server_name, [])
        return [self._tools[n] for n in tool_names if n in self._tools]

    def remove_server(self, server_name: str) -> int:
        """Remove all tools from a server.

        Returns:
            Number of tools removed.
        """
        tool_names = self._server_tools.pop(server_name, [])
        removed = 0
        for name in tool_names:
            if name in self._tools:
                del self._tools[name]
                removed += 1
        logger.info("Removed %d tool(s) from server '%s'", removed, server_name)
        return removed

    def search_tools(self, query: str) -> list[MCPToolInfo]:
        """Search tools by name or description.

        Args:
            query: Search query.

        Returns:
            Matching tools.
        """
        query_lower = query.lower()
        return [
            tool
            for tool in self._tools.values()
            if query_lower in tool.name.lower()
            or query_lower in tool.description.lower()
        ]

    def summary(self) -> dict[str, Any]:
        """Return a summary of discovered tools."""
        return {
            "total_tools": len(self._tools),
            "servers": {
                name: len(tools)
                for name, tools in self._server_tools.items()
            },
        }
