"""MCP (Model Context Protocol) — client and server implementations.

Provides both MCP client capabilities (connecting to external MCP servers)
and MCP server capabilities (exposing this agent's tools to external systems).
"""

from __future__ import annotations

from terminal_agent.mcp.client.connection import MCPConnection
from terminal_agent.mcp.client.discovery import MCPToolDiscovery
from terminal_agent.mcp.client.tool_call import MCPToolCaller
from terminal_agent.mcp.client.result import MCPResultTranslator
from terminal_agent.mcp.client.health import MCPHealthMonitor
from terminal_agent.mcp.client.multi_server import MCPMultiServer
from terminal_agent.mcp.server.protocol import MCPProtocolServer
from terminal_agent.mcp.server.registration import MCPToolRegistration
from terminal_agent.mcp.server.handler import MCPRequestHandler
from terminal_agent.mcp.server.auth import MCPAuthenticator
from terminal_agent.mcp.server.rate_limiter import MCPRateLimiter

__all__ = [
    "MCPConnection",
    "MCPToolDiscovery",
    "MCPToolCaller",
    "MCPResultTranslator",
    "MCPHealthMonitor",
    "MCPMultiServer",
    "MCPProtocolServer",
    "MCPToolRegistration",
    "MCPRequestHandler",
    "MCPAuthenticator",
    "MCPRateLimiter",
]
