# Frequently Asked Questions

## General

### What is Terminal Agent?

Terminal Agent is a fully autonomous AI agent that operates inside your terminal. You describe what you want in natural language, and it plans, executes, verifies, and learns until the task is complete.

### How is this different from GitHub Copilot / Cursor / Aider?

Terminal Agent is fully autonomous — it doesn't just suggest code, it executes complete multi-step tasks. It can run shell commands, manage git, install packages, run tests, manage databases, deploy infrastructure, and learn from its mistakes. It's a true agent, not an autocomplete tool.

### What can Terminal Agent do?

Anything a developer can do in a terminal:
- Write, edit, and refactor code in 15+ languages
- Run shell commands and manage processes
- Full git workflow (commit, branch, merge, rebase)
- Install and manage packages across 25+ package managers
- Query and migrate databases
- Build and run Docker containers
- Run tests and analyze results
- Generate documentation
- Manage infrastructure (Kubernetes, Terraform, CI/CD)
- And much more — 40+ built-in tools across 13 categories

### Is it safe?

Terminal Agent has a comprehensive safety system with 6 levels. The default (Standard) blocks dangerous commands, requires confirmation for destructive actions, restricts access to sensitive directories, and logs everything. See [SECURITY.md](SECURITY.md) for details.

## Installation

### What are the requirements?

- Python 3.10 or higher
- An LLM API key (OpenAI, Anthropic, Google) or a local model (Ollama)
- Linux, macOS, or Windows (WSL)

### How do I install it?

```bash
pip install terminal-agent
```

Or with pipx for isolation:
```bash
pipx install terminal-agent
```

### Can I use it without an internet connection?

Yes! Use Ollama with a local model:
```bash
terminal-agent config set llm.primary_provider ollama
terminal-agent config set llm.ollama.model llama3
```

## Configuration

### Where is the configuration file?

- Global: `~/.terminal-agent/config.toml`
- Project: `./.agent/project.toml`
- Environment variables: `TERMINAL_AGENT_*`
- CLI flags: `--flag value`

### How do I set my API key?

```bash
# Via config command
terminal-agent config set llm.openai.api_key "sk-..."

# Via environment variable
export TERMINAL_AGENT_LLM_OPENAI_API_KEY="sk-..."

# Via CLI flag
terminal-agent run --api-key "sk-..." "your task"
```

### Can I use multiple LLM providers?

Yes! Configure a primary provider and fallback chain:
```toml
[llm]
primary_provider = "openai"
primary_model = "gpt-4o"
fallback_providers = ["anthropic", "ollama"]
```

The agent will automatically fall back to the next provider if the primary fails.

## Usage

### How do I run a task?

```bash
# One-shot task
terminal-agent run "Create a REST API with Express and PostgreSQL"

# Interactive chat
terminal-agent chat

# Resume a previous session
terminal-agent sessions resume <session-id>
```

### Can I stop the agent while it's working?

Yes! Press `Ctrl+C` to gracefully stop the agent. It will save its current state and you can resume later.

### How does the agent know what to do?

The agent uses the ReAct (Reasoning + Acting) paradigm:
1. It analyzes your goal and creates a plan
2. For each step, it thinks about what to do, selects a tool, and executes it
3. It verifies the result and decides the next step
4. It repeats until the goal is achieved

### What if the agent makes a mistake?

The agent has a multi-level error recovery system:
1. **Immediate retry** — Try the same action again
2. **Modified retry** — Adjust parameters based on the error
3. **Alternative approach** — Try a different method
4. **Re-plan** — Generate a new plan considering the failure
5. **Ask user** — Describe the problem and ask for guidance
6. **Graceful abort** — Save state and explain what happened

## Memory

### Does the agent remember previous sessions?

Yes! The long-term memory system stores knowledge across sessions using vector embeddings. When you start a new task, the agent searches for relevant memories from past tasks.

### How does memory work?

Terminal Agent has three memory tiers:
1. **Short-term** — Current conversation (last 20 turns)
2. **Working** — Active files, current state, scratch pad
3. **Long-term** — Persistent knowledge stored with vector embeddings

### Can I clear the agent's memory?

```bash
# Clear all memories
terminal-agent memory clear

# Clear memories for a specific category
terminal-agent memory clear --category error

# Clear memories for a specific project
terminal-agent memory clear --project my-project
```

## Models

### Which models are supported?

Terminal Agent supports 15+ providers:
- **OpenAI**: GPT-4o, GPT-4, GPT-3.5-turbo, o1, o3
- **Anthropic**: Claude Opus, Sonnet, Haiku
- **Google**: Gemini Pro, Ultra, Flash
- **Ollama**: Any local model (Llama, Mistral, Phi, Qwen, etc.)
- **LiteLLM**: 100+ models via proxy
- **Azure OpenAI**: Enterprise deployments
- **AWS Bedrock**: Enterprise deployments
- **Groq**: Fast inference
- **DeepSeek**: DeepSeek Coder, V2, V3
- And more...

### How do I switch models?

```bash
# Change primary model
terminal-agent config set llm.primary_model "claude-opus-4-20250514"

# Change provider
terminal-agent config set llm.primary_provider "anthropic"

# Use a different model for a specific task
terminal-agent run --model gpt-4o "your task"
```

### Can I use different models for different tasks?

Yes! Configure multi-model routing:
```toml
[llm]
primary_provider = "openai"
primary_model = "gpt-4o"
code_model = "deepseek-coder"
secondary_model = "gpt-4o-mini"
embedding_model = "text-embedding-3-small"
```

## Cost

### How much does it cost?

Cost depends on the LLM provider and model used. Terminal Agent tracks token usage and cost per task. You can set budget limits:

```toml
[llm]
cost_limit_per_task = 5.00  # $5 per task
cost_warning_threshold = 0.80  # Warn at 80%
```

### How do I minimize costs?

1. Use a cheaper model for simple tasks (GPT-4o-mini, Claude Haiku)
2. Use Ollama with a local model for free inference
3. Enable caching to avoid redundant API calls
4. Set cost limits to prevent runaway spending
5. Use the secondary model for summarization and formatting

## Safety

### What safety levels are available?

| Level | Name | Description |
|-------|------|-------------|
| 0 | Unrestricted | No checks (dev only) |
| 1 | Minimal | Block catastrophic commands |
| 2 | Standard | Block destructive, confirm modifications (default) |
| 3 | Moderate | Confirm all writes and executions |
| 4 | Strict | Confirm everything, read-only default |
| 5 | Review | Plan only, no execution |

### Can I customize safety rules?

Yes! You can add custom blocked patterns, allowed paths, and more:

```toml
[safety]
level = 2
blocked_patterns = ["kubectl delete namespace"]
allowed_paths = ["/opt/myproject"]
```

## Troubleshooting

### The agent is not responding

1. Check your API key is set correctly
2. Check your internet connection
3. Check if the LLM provider is experiencing downtime
4. Try a different provider: `terminal-agent config set llm.primary_provider ollama`

### The agent is making mistakes

1. Provide more specific goals
2. Include relevant context in your request
3. Check if the safety level is appropriate
4. Review the agent's plan before execution
5. Use the TUI to see the agent's reasoning

### How do I report a bug?

1. Check existing [issues](https://github.com/terminal-agent/terminal-agent/issues)
2. Use the [bug report template](https://github.com/terminal-agent/terminal-agent/issues/new?template=bug_report.md)
3. Include your version, OS, Python version, and steps to reproduce

## Plugins

### Can I extend Terminal Agent?

Yes! Terminal Agent has a full plugin system. You can:
- Add new tools
- Add new LLM providers
- Add new memory backends
- Hook into lifecycle events
- Add new CLI subcommands
- Add new TUI screens

See the [Plugin Development Guide](docs/developer-guide/plugin-development.md).

### Where do I find plugins?

```bash
# List installed plugins
terminal-agent plugins list

# Search for plugins
terminal-agent plugins search "web scraping"

# Install a plugin
terminal-agent plugins install web-tools
```

## Contributing

### How can I contribute?

See [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines. In short:
1. Fork the repository
2. Create a feature branch
3. Make your changes with tests
4. Submit a pull request

### Where do I ask questions?

- [GitHub Discussions](https://github.com/terminal-agent/terminal-agent/discussions)
- [Discord](https://discord.gg/terminal-agent)
- [Stack Overflow](https://stackoverflow.com/questions/tagged/terminal-agent)
