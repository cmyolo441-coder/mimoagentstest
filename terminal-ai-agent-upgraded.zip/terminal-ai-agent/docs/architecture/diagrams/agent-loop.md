# Agent Loop Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                     AGENT LOOP                                   │
│                                                                  │
│  ┌──────────────┐                                               │
│  │  1. GOAL     │ Is the goal already achieved?                  │
│  │    CHECK     │──Yes──▶ COMPLETION SEQUENCE                    │
│  └──────┬───────┘                                               │
│         │ No                                                     │
│         ▼                                                       │
│  ┌──────────────┐                                               │
│  │  2. CONTEXT  │ Build prompt from:                             │
│  │   ASSEMBLY   │ ├── System prompt                              │
│  │              │ ├── Goal statement                             │
│  │              │ ├── Current plan                               │
│  │              │ ├── Relevant memories (top 5)                  │
│  │              │ ├── Working memory                             │
│  │              │ ├── Last 3 conversation turns                  │
│  │              │ └── Environment info                           │
│  └──────┬───────┘                                               │
│         ▼                                                       │
│  ┌──────────────┐                                               │
│  │  3. LLM      │ Send context to LLM provider                  │
│  │    CALL      │ Receive: thought + action OR completion        │
│  └──────┬───────┘                                               │
│         │                                                        │
│         ├──── Completion ────▶ COMPLETION SEQUENCE               │
│         │                                                        │
│         ▼                                                        │
│  ┌──────────────┐                                               │
│  │  4. SAFETY   │ Check:                                         │
│  │    CHECK     │ ├── Tool in allowed list?                      │
│  │              │ ├── Matches blocked pattern?                   │
│  │              │ ├── Accesses restricted path?                  │
│  │              │ └── Destructive potential?                     │
│  └──────┬───────┘                                               │
│         │                                                        │
│         ├── Unsafe ──▶ Request confirmation / Block              │
│         │                                                        │
│         ▼                                                        │
│  ┌──────────────┐                                               │
│  │  5. TOOL     │ Execute tool with parameters                   │
│  │  EXECUTION   │ Capture: output, exit code, duration           │
│  └──────┬───────┘                                               │
│         ▼                                                        │
│  ┌──────────────┐                                               │
│  │  6. RESULT   │ ├── Store raw output                           │
│  │   CAPTURE    │ ├── Compress if too long                       │
│  │              │ ├── Classify (success/failure)                 │
│  │              │ └── Extract errors                             │
│  └──────┬───────┘                                               │
│         ▼                                                        │
│  ┌──────────────┐                                               │
│  │  7. VERIFY   │ ├── Exit code = 0?                            │
│  │              │ ├── Output format correct?                     │
│  │              │ ├── Syntax valid?                              │
│  │              │ ├── Tests pass?                                │
│  │              │ └── Goal progress?                             │
│  └──────┬───────┘                                               │
│         │                                                        │
│         ├── Failed ──▶ ERROR RECOVERY                           │
│         │                                                        │
│         ▼                                                        │
│  ┌──────────────┐                                               │
│  │  8. MEMORY   │ ├── Short-term: add turn                      │
│  │   UPDATE     │ ├── Working: update state                     │
│  │              │ └── Long-term: store pattern                  │
│  └──────┬───────┘                                               │
│         ▼                                                        │
│  ┌──────────────┐                                               │
│  │  9. PROGRESS │ ├── Mark step status                          │
│  │   UPDATE     │ ├── Advance to next step                      │
│  │              │ └── Re-plan if needed                         │
│  └──────┬───────┘                                               │
│         ▼                                                        │
│  ┌──────────────┐                                               │
│  │ 10. LOOP     │ Goal done? ──▶ COMPLETE                       │
│  │  DECISION    │ Max iterations? ──▶ TIMEOUT                   │
│  │              │ Budget exceeded? ──▶ BUDGET                    │
│  │              │ Unrecoverable? ──▶ FAILURE                    │
│  │              │ User stop? ──▶ INTERRUPT                      │
│  │              │ None ──▶ Go to Step 1                         │
│  └──────────────┘                                               │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Error Recovery Flow

```
ERROR DETECTED
      │
      ▼
┌──────────────┐
│  Classify    │ What type of error?
│  Error       │
└──────┬───────┘
       │
       ▼
┌──────────────┐     ┌──────────────┐
│  Search      │────▶│  Known       │
│  Error       │ Yes │  Solution?   │
│  Memory      │     │  Apply it    │
└──────┬───────┘     └──────────────┘
       │ No
       ▼
┌──────────────┐
│  Level 1:    │ Same action, same params
│  Immediate   │ Max 2 attempts
│  Retry       │
└──────┬───────┘
       │ Failed
       ▼
┌──────────────┐
│  Level 2:    │ Same action, adjusted params
│  Modified    │ Max 2 attempts
│  Retry       │
└──────┬───────┘
       │ Failed
       ▼
┌──────────────┐
│  Level 3:    │ Different tool or method
│  Alternative │ Max 2 attempts
│  Approach    │
└──────┬───────┘
       │ Failed
       ▼
┌──────────────┐
│  Level 4:    │ New plan from current state
│  Re-Plan     │ Max 1 re-plan
└──────┬───────┘
       │ Failed
       ▼
┌──────────────┐
│  Level 5:    │ Describe problem
│  Ask User    │ Suggest solutions
└──────┬───────┘
       │ No guidance
       ▼
┌──────────────┐
│  Level 6:    │ Save state
│  Graceful    │ Explain what happened
│  Abort       │ Clean up resources
└──────────────┘
```
