# Memory Tiers Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                      MEMORY SYSTEM                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  TIER 1: SHORT-TERM MEMORY                                 │  │
│  │  ┌──────────────────────────────────────────────────────┐  │  │
│  │  │  Conversation History (last 20 turns)                │  │  │
│  │  │  ├── User messages                                   │  │  │
│  │  │  ├── Agent thoughts                                  │  │  │
│  │  │  ├── Tool calls and results                          │  │  │
│  │  │  ├── Verification outcomes                           │  │  │
│  │  │  └── Error messages                                  │  │  │
│  │  └──────────────────────────────────────────────────────┘  │  │
│  │  Persistence: Session only | Access: Direct                 │  │
│  └────────────────────────────────────────────────────────────┘  │
│                              │                                    │
│                              ▼                                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  TIER 2: WORKING MEMORY                                    │  │
│  │  ┌──────────────────────────────────────────────────────┐  │  │
│  │  │  Active State                                         │  │  │
│  │  │  ├── File contents (currently editing)               │  │  │
│  │  │  ├── Current plan and progress                       │  │  │
│  │  │  ├── Scratch pad (intermediate data)                 │  │  │
│  │  │  ├── Environment (OS, git, packages)                 │  │  │
│  │  │  └── Recent search results                           │  │  │
│  │  └──────────────────────────────────────────────────────┘  │  │
│  │  Persistence: Session only | Access: Direct                 │  │
│  └────────────────────────────────────────────────────────────┘  │
│                              │                                    │
│                              ▼                                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  TIER 3: LONG-TERM MEMORY                                  │  │
│  │  ┌──────────────────────────────────────────────────────┐  │  │
│  │  │  Vector Store (ChromaDB / FAISS / Pinecone)          │  │  │
│  │  │  ├── Task Memory: Past task outcomes                 │  │  │
│  │  │  ├── Error Memory: Errors and solutions              │  │  │
│  │  │  ├── Pattern Memory: Reusable patterns               │  │  │
│  │  │  ├── Preference Memory: User style                   │  │  │
│  │  │  ├── Project Memory: Project knowledge               │  │  │
│  │  │  ├── Tool Memory: Tool usage patterns                │  │  │
│  │  │  └── Environment Memory: System info                 │  │  │
│  │  └──────────────────────────────────────────────────────┘  │  │
│  │  Persistence: Permanent | Access: Semantic search           │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Memory Flow

```
User Input
    │
    ▼
┌──────────────┐
│ Context      │◀─── Recall from Long-Term (top 5)
│ Assembly     │◀─── Include Working Memory
│              │◀─── Include Short-Term (last 3 turns)
└──────┬───────┘
       │
       ▼
    LLM Call
       │
       ▼
┌──────────────┐
│ Memory       │──▶ Add to Short-Term
│ Update       │──▶ Update Working Memory
│              │──▶ Store in Long-Term (if pattern)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Session End  │──▶ Consolidate Long-Term Memories
│              │──▶ Decay Old Memories
│              │──▶ Remove Duplicates
└──────────────┘
```

## Consolidation Process

```
┌──────────────┐
│ Retrieve All │
│ Session      │
│ Memories     │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Group by     │
│ Similarity   │
│ (clustering) │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Merge/       │
│ Summarize    │
│ Clusters     │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Deduplicate  │
│ (>95% sim)   │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Decay Old    │
│ Memories     │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Update       │
│ Statistics   │
└──────────────┘
```
