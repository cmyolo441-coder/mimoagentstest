# Safety Layers Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                      SAFETY SYSTEM                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  LAYER 1: COMMAND PATTERN MATCHING                         │  │
│  │  ┌──────────────────────────────────────────────────────┐  │  │
│  │  │  Blocked Patterns                                    │  │  │
│  │  │  ├── rm -rf /          (catastrophic)                │  │  │
│  │  │  ├── fork bombs        (catastrophic)                │  │  │
│  │  │  ├── dd if=/dev/zero   (catastrophic)                │  │  │
│  │  │  ├── DROP DATABASE     (destructive)                 │  │  │
│  │  │  ├── git push --force  (destructive)                 │  │  │
│  │  │  └── Custom patterns   (user-defined)                │  │  │
│  │  └──────────────────────────────────────────────────────┘  │  │
│  └────────────────────────────────────────────────────────────┘  │
│                              │                                    │
│                              ▼                                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  LAYER 2: PATH ACCESS CONTROL                              │  │
│  │  ┌──────────────────────────────────────────────────────┐  │  │
│  │  │  Restricted Paths                                    │  │  │
│  │  │  ├── /etc, /boot, /sys, /dev  (system)              │  │  │
│  │  │  ├── ~/.ssh, ~/.aws, ~/.gnupg  (credentials)        │  │  │
│  │  │  ├── Other users' home dirs    (privacy)            │  │  │
│  │  │  └── Custom paths              (user-defined)       │  │  │
│  │  └──────────────────────────────────────────────────────┘  │  │
│  └────────────────────────────────────────────────────────────┘  │
│                              │                                    │
│                              ▼                                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  LAYER 3: DESTRUCTIVE ACTION DETECTION                     │  │
│  │  ┌──────────────────────────────────────────────────────┐  │  │
│  │  │  Detection Patterns                                  │  │  │
│  │  │  ├── File deletion (rm, unlink)                      │  │  │
│  │  │  ├── Table/database drops                            │  │  │
│  │  │  ├── Git force operations                            │  │  │
│  │  │  ├── Permission changes (chmod -R 777)               │  │  │
│  │  │  └── System service manipulation                     │  │  │
│  │  └──────────────────────────────────────────────────────┘  │  │
│  └────────────────────────────────────────────────────────────┘  │
│                              │                                    │
│                              ▼                                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  LAYER 4: CONFIRMATION PROMPTS                             │  │
│  │  ┌──────────────────────────────────────────────────────┐  │  │
│  │  │  Confirmation Dialog                                 │  │  │
│  │  │  ├── Show action to be taken                         │  │  │
│  │  │  ├── Show impact (files, resources)                  │  │  │
│  │  │  ├── Show risk level                                 │  │  │
│  │  │  └── Options: [Y]es [N]o [A]lways [D]iff             │  │  │
│  │  └──────────────────────────────────────────────────────┘  │  │
│  └────────────────────────────────────────────────────────────┘  │
│                              │                                    │
│                              ▼                                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  LAYER 5: AUDIT LOGGING                                    │  │
│  │  ┌──────────────────────────────────────────────────────┐  │  │
│  │  │  Audit Record                                        │  │  │
│  │  │  ├── Timestamp                                       │  │  │
│  │  │  ├── Tool and parameters                             │  │  │
│  │  │  ├── Safety decision                                 │  │  │
│  │  │  ├── Reason                                          │  │  │
│  │  │  └── User response                                   │  │  │
│  │  └──────────────────────────────────────────────────────┘  │  │
│  └────────────────────────────────────────────────────────────┘  │
│                              │                                    │
│                              ▼                                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  LAYER 6: EMERGENCY STOP                                   │  │
│  │  ┌──────────────────────────────────────────────────────┐  │  │
│  │  │  Ctrl+C                                              │  │  │
│  │  │  ├── Immediately stop current operation              │  │  │
│  │  │  ├── Save current state                              │  │  │
│  │  │  └── Allow resume later                              │  │  │
│  │  └──────────────────────────────────────────────────────┘  │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Safety Levels

```
Level 0: Unrestricted ─────────────────────────────────────────
         No checks, no confirmations, no blocking

Level 1: Minimal ──────────────────────────────────────────────
         Layer 1 (catastrophic patterns only)

Level 2: Standard (Default) ───────────────────────────────────
         Layer 1 (all patterns)
         Layer 2 (path restrictions)
         Layer 3 (destructive detection)
         Layer 4 (confirm destructive)
         Layer 5 (audit logging)

Level 3: Moderate ─────────────────────────────────────────────
         All Level 2
         Layer 4 (confirm all writes)

Level 4: Strict ───────────────────────────────────────────────
         All Level 3
         Layer 4 (confirm everything)
         Read-only by default

Level 5: Review ───────────────────────────────────────────────
         Plan only, no execution
         User approves each action
```
