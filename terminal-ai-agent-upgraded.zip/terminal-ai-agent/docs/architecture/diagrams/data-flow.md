# Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                      DATA FLOW                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  USER INPUT                                                      │
│  ┌──────────┐                                                   │
│  │  "Create │                                                   │
│  │   a REST │                                                   │
│  │   API"   │                                                   │
│  └────┬─────┘                                                   │
│       │                                                          │
│       ▼                                                          │
│  ┌──────────┐     ┌─────────────┐                               │
│  │  CLI /   │────▶│ ORCHESTRATOR│                               │
│  │  TUI     │     │             │                               │
│  └──────────┘     └──────┬──────┘                               │
│                          │                                       │
│              ┌───────────┼───────────┐                           │
│              │           │           │                           │
│              ▼           ▼           ▼                           │
│        ┌──────────┐ ┌────────┐ ┌──────────┐                    │
│        │  GOAL    │ │ CONTEXT│ │  PLAN    │                    │
│        │  PARSER  │ │ASSEMBLY│ │GENERATOR │                    │
│        └────┬─────┘ └───┬────┘ └────┬─────┘                    │
│             │           │           │                           │
│             └───────────┼───────────┘                           │
│                         │                                       │
│                         ▼                                       │
│              ┌──────────────────┐                               │
│              │    LLM ENGINE    │                               │
│              │                  │                               │
│              │  ┌────────────┐  │                               │
│              │  │  Provider  │  │  ◀── OpenAI/Anthropic/Google  │
│              │  │  (API)     │  │                               │
│              │  └────────────┘  │                               │
│              └────────┬─────────┘                               │
│                       │                                          │
│                       ▼                                          │
│              ┌──────────────────┐                               │
│              │  LLM RESPONSE    │                               │
│              │  ├── Thought     │                               │
│              │  ├── Tool Call   │                               │
│              │  └── Parameters  │                               │
│              └────────┬─────────┘                               │
│                       │                                          │
│                       ▼                                          │
│              ┌──────────────────┐                               │
│              │  SAFETY CHECK    │                               │
│              │  ├── Pattern?    │                               │
│              │  ├── Path?       │                               │
│              │  └── Destructive?│                               │
│              └────────┬─────────┘                               │
│                       │                                          │
│                       ▼                                          │
│              ┌──────────────────┐                               │
│              │ TOOL EXECUTION   │                               │
│              │                  │                               │
│              │ ┌──────────────┐ │                               │
│              │ │  Tool Code   │ │                               │
│              │ │  (async)     │ │                               │
│              │ └──────────────┘ │                               │
│              └────────┬─────────┘                               │
│                       │                                          │
│                       ▼                                          │
│              ┌──────────────────┐                               │
│              │  TOOL RESULT     │                               │
│              │  ├── Output      │──▶ Display to user            │
│              │  ├── Exit Code   │                               │
│              │  └── Duration    │                               │
│              └────────┬─────────┘                               │
│                       │                                          │
│                       ▼                                          │
│              ┌──────────────────┐                               │
│              │  VERIFICATION    │                               │
│              │  ├── Syntax?     │                               │
│              │  ├── Format?     │                               │
│              │  ├── Logic?      │                               │
│              │  └── Regression? │                               │
│              └────────┬─────────┘                               │
│                       │                                          │
│                       ▼                                          │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  MEMORY UPDATE                                            │   │
│  │  ├── Short-term: Add conversation turn                    │   │
│  │  ├── Working: Update active state                         │   │
│  │  └── Long-term: Store pattern (if found)                  │   │
│  │       ├── SQLite (metadata)                               │   │
│  │       └── Vector Store (embeddings)                       │   │
│  └──────────────────────────────────────────────────────────┘   │
│                       │                                          │
│                       ▼                                          │
│              ┌──────────────────┐                               │
│              │ PROGRESS CHECK   │                               │
│              │  ├── Done?       │──▶ COMPLETE                   │
│              │  ├── Failed?     │──▶ ERROR RECOVERY             │
│              │  └── Continue?   │──▶ LOOP (back to LLM)         │
│              └──────────────────┘                               │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Storage Data Flow

```
┌──────────────┐
│  Agent Data  │
└──────┬───────┘
       │
       ├──▶ ~/.terminal-agent/
       │    ├── agent.db          (sessions, turns, tool calls)
       │    ├── vector.db         (embeddings)
       │    ├── cache/            (cached responses)
       │    ├── logs/             (structured logs)
       │    ├── traces/           (execution traces)
       │    ├── backups/          (file backups)
       │    └── keys/             (encrypted API keys)
       │
       └──▶ .agent/
            ├── project.toml      (project config)
            ├── sessions/         (project sessions)
            └── state/            (working state)
```
