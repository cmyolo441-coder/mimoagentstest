# Module Dependencies Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    MODULE DEPENDENCIES                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  CLI ──────────┬──────────▶ Orchestrator                        │
│                ├──────────▶ Configuration                       │
│                └──────────▶ TUI                                  │
│                                                                  │
│  TUI ─────────┬──────────▶ Orchestrator                         │
│               └──────────▶ Configuration                        │
│                                                                  │
│  Configuration ──────────▶ (standalone)                         │
│                                                                  │
│  LLM Engine ──┬──────────▶ Configuration                       │
│               ├──────────▶ Cache                                │
│               ├──────────▶ Rate Limiter                         │
│               └──────────▶ Metrics                              │
│                                                                  │
│  Memory Engine ─┬────────▶ LLM Engine                           │
│                 ├────────▶ Vector Store                         │
│                 ├────────▶ Persistence                          │
│                 └────────▶ Cache                                │
│                                                                  │
│  Orchestrator ─┬─────────▶ LLM Engine                           │
│                ├─────────▶ Memory Engine                        │
│                ├─────────▶ Context Manager                      │
│                ├─────────▶ Prompt Manager                       │
│                ├─────────▶ Tool Registry                        │
│                ├─────────▶ Safety System                        │
│                ├─────────▶ Verification                         │
│                ├─────────▶ Error Recovery                       │
│                ├─────────▶ Self-Improvement                     │
│                ├─────────▶ Metrics                              │
│                └─────────▶ Logging                              │
│                                                                  │
│  Context Manager ─┬──────▶ Memory Engine                        │
│                   └──────▶ Prompt Manager                       │
│                                                                  │
│  Prompt Manager ──┬──────▶ Configuration                        │
│                   └──────▶ Self-Improvement                     │
│                                                                  │
│  Tool Registry ──┬───────▶ Safety System                        │
│                  ├───────▶ Verification                         │
│                  ├───────▶ Logging                              │
│                  └───────▶ Tracing                              │
│                                                                  │
│  Shell Tools ────┬───────▶ Safety System                        │
│                  └───────▶ Logging                              │
│                                                                  │
│  Filesystem Tools ─┬─────▶ Safety System                        │
│                    ├─────▶ Verification                         │
│                    ├─────▶ Differ                               │
│                    └─────▶ Logging                              │
│                                                                  │
│  Code Tools ─────┬───────▶ Filesystem Tools                     │
│                  └───────▶ Shell Tools                          │
│                                                                  │
│  Git Tools ──────┬───────▶ Shell Tools                          │
│                  ├───────▶ Code Tools                           │
│                  └───────▶ Safety System                        │
│                                                                  │
│  Package Manager ─┬──────▶ Shell Tools                          │
│                   ├──────▶ Network Tools                        │
│                   └──────▶ Safety System                        │
│                                                                  │
│  Database Tools ──┬──────▶ Shell Tools                          │
│                   └──────▶ Safety System                        │
│                                                                  │
│  Docker Tools ────┬──────▶ Shell Tools                          │
│                   ├──────▶ Network Tools                        │
│                   └──────▶ Safety System                        │
│                                                                  │
│  Network Tools ───┬──────▶ Safety System                        │
│                   ├──────▶ Cache                                │
│                   └──────▶ Rate Limiter                         │
│                                                                  │
│  Search Tools ────┬──────▶ Vector Store                         │
│                   ├──────▶ Network Tools                        │
│                   └──────▶ Code Tools                           │
│                                                                  │
│  Testing Tools ───┬──────▶ Shell Tools                          │
│                   ├──────▶ Code Tools                           │
│                   └──────▶ Verification                         │
│                                                                  │
│  Documentation ───┬──────▶ Code Tools                           │
│                   ├──────▶ Git Tools                            │
│                   └──────▶ Filesystem Tools                     │
│                                                                  │
│  DevOps Tools ────┬──────▶ Shell Tools                          │
│                   ├──────▶ Network Tools                        │
│                   └──────▶ Safety System                        │
│                                                                  │
│  Safety System ───┬──────▶ Configuration                        │
│                   └──────▶ Logging                              │
│                                                                  │
│  Verification ────┬──────▶ Shell Tools                          │
│                   ├──────▶ Code Tools                           │
│                   └──────▶ LLM Engine                           │
│                                                                  │
│  Self-Improvement ┬──────▶ Persistence                          │
│                   ├──────▶ LLM Engine                           │
│                   └──────▶ Metrics                              │
│                                                                  │
│  Error Recovery ──┬──────▶ Memory Engine                        │
│                   └──────▶ LLM Engine                           │
│                                                                  │
│  Persistence ─────────────▶ (standalone, SQLite)                │
│  Cache ───────────────────▶ (standalone)                        │
│  Vector Store ────────────▶ (standalone)                        │
│  Logging ─────────────────▶ (standalone)                        │
│  Tracing ────────┬────────▶ Persistence                         │
│                  └────────▶ Logging                             │
│  Metrics ─────────────────▶ (standalone)                        │
│  Rate Limiter ────────────▶ Configuration                       │
│                                                                  │
│  Plugin System ──┬────────▶ Tool Registry                       │
│                  ├────────▶ Configuration                       │
│                  └────────▶ Safety System                       │
│                                                                  │
│  MCP ────────────┬────────▶ Tool Registry                       │
│                  └────────▶ Network Tools                       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Dependency Layers

```
Layer 0 (Standalone):
  Configuration, Persistence, Cache, Vector Store, Logging,
  Metrics, Rate Limiter

Layer 1 (Depends on Layer 0):
  LLM Engine, Memory Engine, Safety System, Tracing

Layer 2 (Depends on Layer 1):
  Context Manager, Prompt Manager, Verification,
  Error Recovery, Self-Improvement

Layer 3 (Depends on Layer 2):
  Tool Registry, Shell Tools, Filesystem Tools, Code Tools,
  Git Tools, Network Tools, Search Tools

Layer 4 (Depends on Layer 3):
  Package Manager, Database Tools, Docker Tools,
  Testing Tools, Documentation Tools, DevOps Tools

Layer 5 (Depends on Layer 4):
  Orchestrator

Layer 6 (Depends on Layer 5):
  CLI, TUI
```
