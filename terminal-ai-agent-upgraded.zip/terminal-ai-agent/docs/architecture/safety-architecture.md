# Safety Architecture

Terminal Agent's safety system protects users from harmful operations through multiple layers of defense.

## Safety Levels

| Level | Name | Description |
|-------|------|-------------|
| 0 | Unrestricted | No safety checks (dev only) |
| 1 | Minimal | Block catastrophic commands |
| 2 | Standard | Block destructive, confirm modifications (default) |
| 3 | Moderate | Confirm all writes and executions |
| 4 | Strict | Confirm everything, read-only default |
| 5 | Review | Plan only, no execution |

## Defense Layers

```
┌─────────────────────────────────────────────────────┐
│  Layer 1: COMMAND PATTERN MATCHING                    │
│  Blocks known-dangerous command patterns              │
├─────────────────────────────────────────────────────┤
│  Layer 2: PATH ACCESS CONTROL                         │
│  Restricts access to sensitive directories             │
├─────────────────────────────────────────────────────┤
│  Layer 3: DESTRUCTIVE ACTION DETECTION                │
│  Identifies irreversible operations                   │
├─────────────────────────────────────────────────────┤
│  Layer 4: CONFIRMATION PROMPTS                        │
│  Requires user approval for risky actions             │
├─────────────────────────────────────────────────────┤
│  Layer 5: AUDIT LOGGING                               │
│  Records all safety decisions                         │
├─────────────────────────────────────────────────────┤
│  Layer 6: EMERGENCY STOP                              │
│  Immediate halt capability (Ctrl+C)                   │
└─────────────────────────────────────────────────────┘
```

## Layer 1: Command Pattern Matching

Blocked patterns are evaluated before execution:

### Catastrophic (Blocked at Level 1+)

```
rm -rf /
rm -rf /*
:(){ :|:& };:          # Fork bomb
dd if=/dev/zero of=/
mkfs.*
```

### Destructive (Blocked at Level 2+)

```
DROP DATABASE
DROP TABLE
DELETE FROM * WHERE 1=1
git push --force
git reset --hard
npm install -g *
```

### Custom Patterns

```toml
[safety]
blocked_patterns = ["kubectl delete namespace", "terraform destroy"]
```

## Layer 2: Path Access Control

Restricted paths by default:

| Path | Level 1-2 | Level 3+ |
|------|-----------|----------|
| `/etc` | Read-only | Blocked |
| `/boot` | Blocked | Blocked |
| `/sys` | Blocked | Blocked |
| `/dev` | Blocked | Blocked |
| `~/.ssh` | Blocked | Blocked |
| `~/.aws` | Blocked | Blocked |
| Other users' homes | Blocked | Blocked |

## Layer 3: Destructive Action Detection

The system identifies destructive operations:

```python
DESTRUCTIVE_PATTERNS = {
    "file_delete": r"rm\s+(-[rf]+\s+)?",
    "table_drop": r"DROP\s+TABLE",
    "database_drop": r"DROP\s+DATABASE",
    "git_force": r"git\s+push\s+.*--force",
    "chmod_recursive": r"chmod\s+-R\s+777",
}
```

## Layer 4: Confirmation Prompts

For actions requiring confirmation:

```
⚠️  Confirmation Required

Action: rm -rf build/ dist/
Impact: Delete 18 files (3.4MB)
Risk: Destructive, irreversible

[Y] Yes  [N] No  [A] Always allow  [D] Show diff
```

## Layer 5: Audit Logging

All safety decisions are logged:

```json
{
  "timestamp": "2025-01-15T10:30:00Z",
  "tool": "execute_command",
  "parameters": {"command": "rm -rf build/"},
  "decision": "confirm_required",
  "reason": "Destructive file deletion",
  "safety_level": 2,
  "user_response": "approved"
}
```

## Layer 6: Emergency Stop

`Ctrl+C` triggers immediate halt:
1. Current tool execution is terminated
2. State is saved
3. User can resume later

## Sandbox Mode

Run in isolated environment:

```toml
[safety]
sandbox_mode = true
```

Sandbox restrictions:
- Commands run in container
- File access limited to project
- Network restricted
- Resource limits enforced

## Safety Integration

Safety checks are integrated into the agent loop at Step 4:

```python
async def check_safety(self, tool_call: ToolCall) -> SafetyResult:
    # Layer 1: Pattern matching
    if self.pattern_matcher.is_blocked(tool_call):
        return SafetyResult(allowed=False, reason="Blocked pattern")

    # Layer 2: Path access
    if self.path_controller.is_restricted(tool_call):
        return SafetyResult(allowed=False, reason="Restricted path")

    # Layer 3: Destructive detection
    if self.destructive_detector.is_destructive(tool_call):
        if self.safety_level >= 2:
            return SafetyResult(
                allowed=False,
                reason="Destructive action",
                requires_confirmation=True,
            )

    # Layer 4: Confirmation
    if self.requires_confirmation(tool_call):
        confirmed = await self.prompt_user(tool_call)
        if not confirmed:
            return SafetyResult(allowed=False, reason="User denied")

    # Layer 5: Audit log
    self.audit_log.record(tool_call, SafetyResult(allowed=True))

    return SafetyResult(allowed=True)
```
