# Agent Loop

The agent loop is the heartbeat of Terminal Agent — the core cycle that drives all autonomous behavior.

## The Loop

```
┌──────────────┐
│  1. GOAL     │ Is the goal already achieved?
│    CHECK     │ If yes → COMPLETION
└──────┬───────┘
       │ No
       ▼
┌──────────────┐
│  2. CONTEXT  │ Build prompt: system + goal + plan +
│   ASSEMBLY   │ memories + history + environment
└──────┬───────┘
       ▼
┌──────────────┐
│  3. LLM      │ Send context to LLM, receive thought
│    CALL      │ + action (tool call) or completion
└──────┬───────┘
       ▼
┌──────────────┐
│  4. SAFETY   │ Check: tool allowed? blocked pattern?
│    CHECK     │ restricted path? destructive?
└──────┬───────┘
       ▼
┌──────────────┐
│  5. TOOL     │ Execute tool with parameters
│  EXECUTION   │ Capture output, exit code, duration
└──────┬───────┘
       ▼
┌──────────────┐
│  6. RESULT   │ Store output, classify result,
│   CAPTURE    │ extract errors, record side effects
└──────┬───────┘
       ▼
┌──────────────┐
│  7. VERIFY   │ Syntax? tests pass? build succeeds?
│              │ regression? semantic correctness?
└──────┬───────┘
       ▼
┌──────────────┐
│  8. MEMORY   │ Update short-term, working, and
│   UPDATE     │ long-term memory
└──────┬───────┘
       ▼
┌──────────────┐
│  9. PROGRESS │ Mark sub-goal status, re-plan if
│   UPDATE     │ needed, update display
└──────┬───────┘
       ▼
┌──────────────┐
│ 10. LOOP     │ Goal done? Max iterations? Budget?
│  DECISION    │ Error? Stop? → Continue loop
└──────────────┘
```

## Step Details

### Step 1: Goal Check

The orchestrator checks if the goal is already achieved:

```python
async def check_goal_achieved(self, goal: Goal, context: Context) -> bool:
    """Run verification checks specific to the goal type."""
    verification = self.verifier.check_completion(goal, context)
    return verification.passed
```

### Step 2: Context Assembly

The context manager builds the prompt:

```python
async def assemble_context(self, session: Session) -> Context:
    """Build context for the next LLM call."""
    return Context(
        system_prompt=self.prompt_manager.get_system_prompt(),
        goal=session.goal,
        plan=session.current_plan,
        memories=await self.memory.recall(session.goal, limit=5),
        history=session.get_recent_turns(limit=3),
        working_memory=session.working_memory,
        environment=self.environment.get_info(),
        safety_rules=self.safety.get_rules(),
    )
```

### Step 3: LLM Call

The LLM processes the context and returns a response:

```python
async def call_llm(self, context: Context) -> LLMResponse:
    """Send context to LLM and parse response."""
    messages = context.to_messages()
    response = await self.llm.complete(messages)
    return self.parser.parse(response)
```

The response contains:
- **Thought** — Reasoning about what to do next
- **Action** — Tool call with name and parameters
- **Completion** — Statement that the goal is done

### Step 4: Safety Check

Before executing any tool:

```python
async def check_safety(self, tool_call: ToolCall) -> SafetyResult:
    """Evaluate if the tool call is safe."""
    return await self.safety.evaluate(
        tool=tool_call.name,
        parameters=tool_call.parameters,
        level=self.config.safety_level,
    )
```

Safety checks:
- Is this tool in the allowed list?
- Does it match a blocked pattern?
- Does it access restricted paths?
- Does it have destructive potential?

### Step 5: Tool Execution

Execute the tool with timeout and resource limits:

```python
async def execute_tool(self, tool_call: ToolCall) -> ToolResult:
    """Execute a tool with safety wrappers."""
    tool = self.registry.get(tool_call.name)
    return await asyncio.wait_for(
        tool.execute(**tool_call.parameters),
        timeout=self.config.tool_timeout,
    )
```

### Step 6: Result Capture

Process and classify the result:

```python
async def capture_result(self, result: ToolResult) -> ProcessedResult:
    """Process raw tool output."""
    return ProcessedResult(
        output=self.compressor.compress(result.output),
        classification=self.classifier.classify(result),
        errors=self.error_extractor.extract(result),
        side_effects=self.side_effect_tracker.track(result),
    )
```

### Step 7: Verification

Check the result through multiple stages:

```python
async def verify(self, result: ProcessedResult, goal: Goal) -> Verification:
    """Run verification pipeline."""
    checks = [
        self.verifier.basic_checks(result),
        self.verifier.format_checks(result),
        self.verifier.logic_checks(result),
        self.verifier.quality_checks(result),
        self.verifier.regression_checks(result),
    ]
    results = await asyncio.gather(*checks)
    return Verification.from_results(results)
```

### Step 8: Memory Update

Update all memory tiers:

```python
async def update_memory(self, turn: Turn) -> None:
    """Update memory after a turn."""
    # Short-term: add to conversation
    self.short_term.add(turn)

    # Working: update active state
    self.working.update(turn.side_effects)

    # Long-term: store if pattern found
    if pattern := self.pattern_learner.extract(turn):
        await self.long_term.store(pattern)
```

### Step 9: Progress Update

Update plan and progress:

```python
async def update_progress(self, session: Session, result: Verification) -> None:
    """Update plan progress."""
    current_step = session.current_step
    if result.passed:
        current_step.status = "completed"
        session.advance_to_next_step()
    else:
        current_step.status = "failed"
        await self.re_planner.handle_failure(session, result)
```

### Step 10: Loop Decision

Check termination conditions:

```python
async def should_continue(self, session: Session) -> LoopDecision:
    """Determine if the loop should continue."""
    if session.goal_achieved:
        return LoopDecision.COMPLETE
    if session.iterations >= self.config.max_iterations:
        return LoopDecision.TIMEOUT
    if session.cost >= self.config.cost_limit:
        return LoopDecision.BUDGET
    if session.unrecoverable_error:
        return LoopDecision.FAILURE
    if session.user_requested_stop:
        return LoopDecision.INTERRUPT
    return LoopDecision.CONTINUE
```

## Completion Sequence

When the goal is achieved:

1. Generate final summary
2. List all files created/modified
3. List all commands executed
4. Show verification results
5. Save session to persistence
6. Run self-improvement analysis (background)
7. Present results to user

## Error Recovery

When a step fails, the recovery engine escalates through levels:

| Level | Strategy | Max Attempts |
|-------|----------|--------------|
| 1 | Immediate retry (same action) | 2 |
| 2 | Modified retry (adjusted params) | 2 |
| 3 | Alternative approach (different tool) | 2 |
| 4 | Re-plan (new plan from current state) | 1 |
| 5 | Ask user (describe problem, request guidance) | 1 |
| 6 | Graceful abort (save state, explain) | - |
