# Data Flow

How data moves through Terminal Agent's architecture.

## Complete Data Flow

```
User Input
    │
    ▼
┌─────────┐     ┌─────────────┐     ┌──────────┐
│  CLI /  │────▶│ Orchestrator │────▶│ Context  │
│  TUI    │     │             │     │ Manager  │
└─────────┘     └──────┬──────┘     └────┬─────┘
                       │                  │
                       │                  ▼
                       │           ┌──────────┐
                       │           │  Memory  │
                       │           │  Engine  │
                       │           └────┬─────┘
                       │                │
                       ▼                ▼
                ┌──────────┐     ┌──────────┐
                │   LLM    │◀───│  Prompt  │
                │  Engine  │     │  Manager │
                └────┬─────┘     └──────────┘
                     │
                     ▼
              ┌──────────────┐
              │    Safety    │
              │   Check      │
              └──────┬───────┘
                     │
                     ▼
              ┌──────────────┐
              │    Tool      │
              │  Execution   │
              └──────┬───────┘
                     │
                     ▼
              ┌──────────────┐
              │ Verification │
              └──────┬───────┘
                     │
                     ▼
              ┌──────────────┐
              │   Memory     │──▶ Persistence
              │   Update     │──▶ Vector Store
              └──────┬───────┘──▶ Cache
                     │
                     ▼
              ┌──────────────┐
              │   Progress   │──▶ Metrics
              │   Check      │──▶ Tracing
              └──────┬───────┘
                     │
                     ▼
              ┌──────────────┐
              │  Loop or     │──▶ User Output
              │  Complete    │
              └──────────────┘
```

## Data Types

### User Input

```python
@dataclass
class UserInput:
    text: str
    attachments: list[Attachment]  # Files, images
    session_id: str | None
    command: str | None  # CLI command
```

### Goal

```python
@dataclass
class Goal:
    description: str
    intent: str  # Parsed intent
    constraints: list[str]
    scope: str  # "simple", "moderate", "complex"
```

### Plan

```python
@dataclass
class Plan:
    goal: Goal
    steps: list[Step]
    dependencies: dict[int, list[int]]  # step -> prerequisites
    estimated_duration: float
    estimated_cost: float

@dataclass
class Step:
    id: int
    description: str
    status: str  # "pending", "in_progress", "completed", "failed"
    tool_hint: str | None
    result: ToolResult | None
```

### Context

```python
@dataclass
class Context:
    system_prompt: str
    goal: Goal
    plan: Plan
    memories: list[MemoryEntry]
    history: list[ConversationTurn]
    working_memory: WorkingMemory
    environment: EnvironmentInfo
    safety_rules: SafetyRules
    token_count: int
```

### LLM Response

```python
@dataclass
class LLMResponse:
    content: str  # Thought/reasoning
    tool_calls: list[ToolCall]
    tokens_in: int
    tokens_out: int
    cost: float
    model: str
    finish_reason: str

@dataclass
class ToolCall:
    id: str
    name: str
    parameters: dict
```

### Tool Result

```python
@dataclass
class ToolResult:
    output: str
    exit_code: int
    error: str
    duration: float
    files_modified: list[str]
    metadata: dict
```

### Verification

```python
@dataclass
class Verification:
    passed: bool
    checks: list[CheckResult]
    score: float  # 0.0 - 1.0

@dataclass
class CheckResult:
    name: str
    passed: bool
    reason: str
```

## Data Transformations

### User Input → Goal

```python
async def parse_goal(self, user_input: UserInput) -> Goal:
    """Parse user input into a structured goal."""
    response = await self.llm.complete([
        {"role": "system", "content": "Parse the user's goal..."},
        {"role": "user", "content": user_input.text},
    ])
    return Goal.from_llm_response(response)
```

### Goal → Plan

```python
async def generate_plan(self, goal: Goal, memories: list[MemoryEntry]) -> Plan:
    """Generate a multi-step plan."""
    # Check for matching patterns
    if patterns := await self.pattern_matcher.match(goal):
        return Plan.from_pattern(patterns[0], goal)

    # Generate new plan
    response = await self.llm.complete([
        {"role": "system", "content": "Create a plan..."},
        {"role": "user", "content": goal.description},
    ])
    return Plan.from_llm_response(response)
```

### Context → LLM Response

```python
async def call_llm(self, context: Context) -> LLMResponse:
    """Send context to LLM."""
    messages = context.to_messages()
    return await self.llm_engine.complete(messages)
```

### LLM Response → Tool Call

```python
def extract_tool_call(self, response: LLMResponse) -> ToolCall | None:
    """Extract tool call from LLM response."""
    if response.tool_calls:
        return response.tool_calls[0]
    return None
```

### Tool Call → Tool Result

```python
async def execute_tool(self, tool_call: ToolCall) -> ToolResult:
    """Execute a tool."""
    tool = self.registry.get(tool_call.name)
    return await tool.execute(**tool_call.parameters)
```

### Tool Result → Verification

```python
async def verify_result(self, result: ToolResult, goal: Goal) -> Verification:
    """Verify tool result."""
    checks = []
    checks.append(self.check_exit_code(result))
    checks.append(self.check_output_format(result))
    checks.append(self.check_goal_progress(result, goal))
    return Verification.from_checks(checks)
```

## Data Storage

### Session Data

```
~/.terminal-agent/
├── agent.db              # SQLite: sessions, turns, tool calls
├── vector.db             # Vector store: embeddings
├── cache/                # Cached responses
├── logs/                 # Structured logs
├── traces/               # Execution traces
├── backups/              # File backups
└── keys/                 # Encrypted API keys
```

### Project Data

```
.agent/
├── project.toml          # Project configuration
├── .agentignore          # Excluded files
├── sessions/             # Project sessions
└── state/                # Working state
```

## Data Privacy

- All data stored locally by default
- API keys encrypted at rest
- No telemetry without opt-in
- Cloud stores (Pinecone, etc.) are opt-in only
- Traces can be configured to exclude sensitive data
