# Context Engineering

How Terminal Agent assembles and manages the context window for LLM calls.

## Context Window Management

The context manager builds the prompt for each LLM call, ensuring it fits within the model's token limit.

## Assembly Algorithm

```
Step 1: Calculate total token budget for this model
Step 2: Reserve tokens for system prompt (fixed allocation)
Step 3: Reserve tokens for response (output tokens)
Step 4: Remaining tokens are the "context budget"
Step 5: Add components in priority order
Step 6: If over budget, compress in reverse priority
Step 7: Format into provider-specific message format
Step 8: Verify final token count is within limits
```

## Context Components

| Priority | Component | Always Included | Token Budget |
|----------|-----------|-----------------|--------------|
| 1 | System prompt | Yes | 2K-4K |
| 2 | Goal statement | Yes | 200-500 |
| 3 | Current plan | Yes | 500-2K |
| 4 | Environment info | Yes | 200-500 |
| 5 | Last 3 turns (full) | Yes | 5K-15K |
| 6 | Working memory | If relevant | 5K-20K |
| 7 | Current tool output | If discussing | 2K-10K |
| 8 | Long-term memories | Top 5 | 2K-5K |
| 9 | Summarized history | If available | 1K-3K |
| 10 | Few-shot examples | If helpful | 2K-5K |

## Token Budget Calculation

```python
async def calculate_budget(self, model: str) -> TokenBudget:
    """Calculate token budget for a model."""
    model_info = self.model_registry.get(model)
    total = model_info.context_window

    return TokenBudget(
        total=total,
        system_prompt=4000,  # Reserved
        response=4096,  # Reserved for output
        available=total - 4000 - 4096,  # For context
    )
```

## Context Assembly

```python
async def assemble(self, session: Session, budget: TokenBudget) -> Context:
    """Assemble context within budget."""
    components = []

    # Priority 1: System prompt (always included)
    system = self.prompt_manager.get_system_prompt()
    components.append(ContextComponent("system", system, priority=1))

    # Priority 2: Goal (always included)
    components.append(ContextComponent("goal", session.goal, priority=2))

    # Priority 3: Plan (always included)
    components.append(ContextComponent("plan", session.plan, priority=3))

    # Priority 4: Environment (always included)
    components.append(ContextComponent("env", session.environment, priority=4))

    # Priority 5: Recent turns
    recent = session.get_recent_turns(limit=3)
    components.append(ContextComponent("recent", recent, priority=5))

    # Priority 6: Working memory
    if session.working_memory.is_relevant():
        components.append(ContextComponent("working", session.working_memory, priority=6))

    # Priority 7: Current tool output
    if session.current_tool_output:
        components.append(ContextComponent("tool_output", session.current_tool_output, priority=7))

    # Priority 8: Long-term memories
    memories = await self.memory.recall(session.goal, limit=5)
    if memories:
        components.append(ContextComponent("memories", memories, priority=8))

    # Priority 9: Summarized history
    summary = session.get_history_summary()
    if summary:
        components.append(ContextComponent("summary", summary, priority=9))

    # Assemble within budget
    return self.fit_to_budget(components, budget)
```

## Compression Strategies

When context exceeds the budget:

### 1. Remove Lowest Priority

```python
def fit_to_budget(self, components: list[ContextComponent], budget: TokenBudget) -> Context:
    """Fit components to budget by removing lowest priority."""
    sorted_components = sorted(components, key=lambda c: c.priority, reverse=True)

    result = []
    used_tokens = 0

    for component in sorted_components:
        if used_tokens + component.token_count <= budget.available:
            result.append(component)
            used_tokens += component.token_count

    return Context(components=result)
```

### 2. Truncate Long Outputs

```python
def truncate_output(self, output: str, max_tokens: int) -> str:
    """Truncate output keeping head and tail."""
    if self.count_tokens(output) <= max_tokens:
        return output

    half = max_tokens // 2
    head = self.take_tokens(output, half)
    tail = self.take_tokens_rev(output, half)

    return f"{head}\n\n... [truncated] ...\n\n{tail}"
```

### 3. Summarize Old Turns

```python
async def summarize_turns(self, turns: list[Turn]) -> str:
    """Summarize old conversation turns."""
    return await self.llm.complete([
        {"role": "system", "content": "Summarize concisely:"},
        {"role": "user", "content": str(turns)},
    ])
```

### 4. Select Relevant Memories

```python
async def select_memories(self, goal: str, limit: int) -> list[MemoryEntry]:
    """Select most relevant memories."""
    return await self.memory.recall(goal, limit=limit)
```

## Provider-Specific Formatting

Different providers require different message formats:

### OpenAI Format

```python
messages = [
    {"role": "system", "content": system_prompt},
    {"role": "user", "content": user_message},
    {"role": "assistant", "content": assistant_message},
]
```

### Anthropic Format

```python
messages = [
    {"role": "user", "content": user_message},
    {"role": "assistant", "content": assistant_message},
]
# System prompt is a separate parameter
```

### Google Format

```python
messages = [
    {"role": "user", "parts": [{"text": user_message}]},
    {"role": "model", "parts": [{"text": assistant_message}]},
]
```

## Token Counting

Token counting uses provider-specific tokenizers:

```python
class TokenCounter:
    """Count tokens for different models."""

    def __init__(self):
        self._counters = {}

    def count(self, text: str, model: str) -> int:
        """Count tokens in text for a specific model."""
        counter = self._get_counter(model)
        return counter.encode(text)

    def _get_counter(self, model: str):
        if model not in self._counters:
            if "gpt" in model:
                self._counters[model] = tiktoken.encoding_for_model(model)
            else:
                self._counters[model] = tiktoken.get_encoding("cl100k_base")
        return self._counters[model]
```

## Context Utilization Monitoring

```python
@dataclass
class ContextUtilization:
    total_budget: int
    used_tokens: int
    utilization_pct: float
    components: dict[str, int]  # component -> token count

    def is_near_limit(self, threshold: float = 0.9) -> bool:
        return self.utilization_pct > threshold
```

## Best Practices

1. **Keep system prompt concise** — Every token counts
2. **Use working memory wisely** — Only include relevant files
3. **Summarize early** — Don't wait until context is full
4. **Monitor utilization** — Use `Ctrl+M` in TUI
5. **Adjust memory limits** — Reduce `short_term_turns` if needed
