# Architecture Overview

Terminal Agent is organized into four major layers with 22 functional modules and 18 support systems.

## Four-Layer Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INTERFACE LAYER                       │
│         CLI (click)  │  TUI (textual)  │  Config (toml)      │
├─────────────────────────────────────────────────────────────┤
│                    INTELLIGENCE LAYER                         │
│  Orchestrator │ LLM Engine │ Memory │ Context │ Prompts      │
├─────────────────────────────────────────────────────────────┤
│                    CAPABILITY LAYER                           │
│  Shell │ Filesystem │ Code │ Git │ Packages │ Database       │
│  Docker │ Network │ Search │ Testing │ Docs │ DevOps         │
├─────────────────────────────────────────────────────────────┤
│                    FOUNDATION LAYER                           │
│  Safety │ Verification │ Error Recovery │ Self-Improvement   │
│  Persistence │ Cache │ Logging │ Tracing │ Metrics           │
│  Plugins │ MCP │ Rate Limiting │ Notifications               │
└─────────────────────────────────────────────────────────────┘
```

## Layer 1: User Interface

| Component | Technology | Purpose |
|-----------|-----------|---------|
| CLI | Click | Command-line argument parsing, subcommand dispatch |
| TUI | Textual | Interactive terminal UI with panels, progress, themes |
| Configuration | TOML | Settings management, validation, encryption |

## Layer 2: Intelligence

| Component | Purpose |
|-----------|---------|
| Orchestrator | Plans, executes, and monitors the agent loop |
| LLM Engine | Communicates with 15+ LLM providers |
| Memory Engine | Three-tier memory with vector semantic search |
| Context Manager | Assembles and compresses context for LLM calls |
| Prompt Manager | Template library, prompt construction, optimization |

## Layer 3: Capability

| Category | Tools | Purpose |
|----------|-------|---------|
| Shell | 8 | Command execution, process management |
| Filesystem | 13 | File operations, search, metadata |
| Code | 19 | AST, refactoring, formatting, linting |
| Git | 18 | Full git integration |
| Package Manager | 25+ | Dependency management |
| Database | 10 | Query, migrate, backup |
| Docker | 9 | Container management |
| Network | 11 | HTTP, DNS, SSL, WebSocket |
| Search | 8 | Regex, semantic, symbol search |
| Testing | 10 | Run, parse, generate tests |
| Code Generation | 13 | Scaffolding, templates |
| Documentation | 11 | README, API docs, changelogs |
| DevOps | 15+ | K8s, Terraform, Ansible, CI/CD |

## Layer 4: Foundation

| System | Purpose |
|--------|---------|
| Safety | Command blocking, path restrictions, confirmations |
| Verification | Syntax, runtime, type, semantic checks |
| Error Recovery | 6-level recovery: retry → abort |
| Self-Improvement | Traces, patterns, prompt optimization |
| Persistence | SQLite database, file store |
| Caching | Memory, disk, database caches |
| Logging | Structured JSON with rotation |
| Tracing | Complete execution traces |
| Metrics | Counters, gauges, histograms |
| Rate Limiting | Token bucket, sliding window |
| Plugins | Discovery, loading, sandboxing |
| MCP | Model Context Protocol client/server |

## Design Principles

1. **Modularity First** — Self-contained modules with clear interfaces
2. **Safety by Default** — Start in safest mode, confirm destructive actions
3. **Verify Everything** — No action complete until verified
4. **Learn Continuously** — Extract patterns from every task
5. **Model Agnostic** — Works with any LLM provider
6. **Graceful Degradation** — Always find a way to continue
7. **Transparency** — User sees everything the agent does
8. **Performance Conscious** — Optimize tokens, cache, parallelize
9. **Extensible by Design** — Plugins for unlimited extension
10. **Developer Experience** — One command install, one file config

## Detailed Documentation

- [Agent Loop](agent-loop.md) — Core Think-Act-Observe cycle
- [Memory Architecture](memory-architecture.md) — Three-tier memory system
- [Tool Architecture](tool-architecture.md) — Tool registry and execution
- [Safety Architecture](safety-architecture.md) — Safety and security
- [Self-Improvement](self-improvement.md) — Learning and optimization
- [Data Flow](data-flow.md) — How data moves through the system
- [Context Engineering](context-engineering.md) — Context assembly and management
