# Self-Improvement Engine

Terminal Agent learns from every task it performs, continuously improving its performance.

## Overview

```
┌─────────────────────────────────────────────────────────┐
│                 SELF-IMPROVEMENT ENGINE                   │
├─────────────────────────────────────────────────────────┤
│  Trace Recorder  → Records every execution detail        │
│  Performance Analyzer  → Scores executions               │
│  Pattern Learner  → Extracts reusable patterns           │
│  Pattern Matcher  → Recognizes known patterns            │
│  Error Analyzer  → Finds common error solutions          │
│  Prompt Optimizer  → Tests prompt variations             │
│  Strategy Optimizer  → Analyzes planning effectiveness   │
│  Tool Optimizer  → Analyzes tool selection               │
│  A/B Tester  → Compares approaches                       │
│  Knowledge Distiller  → Extracts general knowledge       │
└─────────────────────────────────────────────────────────┘
```

## Trace Recording

Every execution is recorded in detail:

```python
@dataclass
class ExecutionTrace:
    session_id: str
    goal: str
    steps: list[StepTrace]
    total_tokens: int
    total_cost: float
    duration: float
    outcome: str  # "success", "failure", "partial"

@dataclass
class StepTrace:
    step_number: int
    thought: str
    action: ToolCall
    result: ToolResult
    verification: Verification
    duration: float
    tokens_used: int
```

## Performance Analysis

Each execution is scored:

```python
async def analyze_performance(self, trace: ExecutionTrace) -> PerformanceScore:
    """Score an execution on multiple dimensions."""
    return PerformanceScore(
        success_rate=self.calculate_success_rate(trace),
        efficiency=self.calculate_efficiency(trace),
        token_efficiency=self.calculate_token_efficiency(trace),
        cost_efficiency=self.calculate_cost_efficiency(trace),
        error_rate=self.calculate_error_rate(trace),
        verification_pass_rate=self.calculate_verification_rate(trace),
    )
```

## Pattern Learning

Patterns are extracted from successful tasks:

```python
async def learn_patterns(self, trace: ExecutionTrace) -> list[Pattern]:
    """Extract reusable patterns from a successful trace."""
    patterns = []

    # Extract tool usage patterns
    for step in trace.steps:
        if step.verification.passed:
            pattern = Pattern(
                type="tool_usage",
                context=step.thought,
                action=step.action,
                outcome=step.result,
                success=True,
            )
            patterns.append(pattern)

    # Extract planning patterns
    planning_pattern = Pattern(
        type="planning",
        goal_type=classify_goal(trace.goal),
        steps=[s.action for s in trace.steps],
        outcome=trace.outcome,
    )
    patterns.append(planning_pattern)

    return patterns
```

## Pattern Matching

When a new task arrives, known patterns are matched:

```python
async def match_patterns(self, goal: str) -> list[Pattern]:
    """Find patterns relevant to a new goal."""
    goal_embedding = await self.embedder.embed(goal)

    # Search pattern store
    matches = await self.pattern_store.search(
        query_vector=goal_embedding,
        limit=5,
        min_similarity=0.7,
    )

    return matches
```

## Error Analysis

Common errors and their solutions are learned:

```python
async def analyze_error(self, error: ErrorTrace) -> ErrorSolution:
    """Find a known solution for an error."""
    # Search error memory
    similar_errors = await self.error_memory.search(
        query=error.message,
        limit=3,
    )

    if similar_errors:
        # Return the most successful solution
        best = max(similar_errors, key=lambda e: e.solution_success_rate)
        return best.solution

    # No known solution
    return None
```

## Prompt Optimization

Prompts are continuously improved:

### A/B Testing Process

1. **Track effectiveness** of each prompt variation
2. **When sufficient data** (10+ uses), identify best performers
3. **Generate improved variations** using LLM
4. **A/B test** — 50% old, 50% new
5. **If new is 5%+ better**, adopt it
6. **Maintain history** for rollback

```python
async def optimize_prompt(self, prompt_name: str) -> Prompt | None:
    """Optimize a prompt through A/B testing."""
    current = self.prompt_manager.get(prompt_name)
    stats = self.metrics.get_prompt_stats(prompt_name)

    if stats.usage_count < 10:
        return None  # Not enough data

    # Generate improved variation
    improved = await self.llm.complete(
        f"Improve this prompt for better results:\n{current.template}\n"
        f"Current success rate: {stats.success_rate}%"
    )

    # A/B test
    winner = await self.ab_tester.test(
        name=prompt_name,
        variant_a=current,
        variant_b=improved,
        sample_size=20,
    )

    if winner == "b":
        return improved
    return None
```

## Strategy Optimization

Planning strategies are analyzed:

| Strategy | Success Rate | Best For |
|----------|-------------|----------|
| Linear | 85% | Simple, sequential tasks |
| Parallel | 78% | Independent subtasks |
| Incremental | 90% | Complex, evolving requirements |
| Template | 95% | Known patterns |

## Improvement Loop

```
After each task:
    │
    ▼
┌──────────────┐
│ Record Trace │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Score        │
│ Performance  │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Extract      │
│ Patterns     │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Update       │
│ Pattern      │
│ Library      │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Analyze for  │
│ Prompt       │
│ Improvements │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ A/B Test     │
│ Improvements │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Adopt if     │
│ Better       │
└──────────────┘
```

## Metrics

Improvement is tracked over time:

```python
@dataclass
class ImprovementMetrics:
    tasks_completed: int
    success_rate_trend: list[float]  # Rolling average
    average_steps_trend: list[float]
    average_cost_trend: list[float]
    patterns_learned: int
    prompts_optimized: int
    error_solutions_known: int
```
