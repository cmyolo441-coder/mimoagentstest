# Memory Architecture

Terminal Agent's three-tier memory system enables learning from past tasks.

## Three-Tier Design

```
┌─────────────────────────────────────────────────────────┐
│  Tier 1: SHORT-TERM MEMORY                              │
│  ├── Current conversation turns (last 20)               │
│  ├── Immediate context                                  │
│  ├── Session only (lost when session ends)              │
│  └── Access: Direct (always in context)                 │
├─────────────────────────────────────────────────────────┤
│  Tier 2: WORKING MEMORY                                 │
│  ├── Active file contents                               │
│  ├── Current plan and progress                          │
│  ├── Scratch pad, environment state                     │
│  └── Access: Direct (included in context assembly)      │
├─────────────────────────────────────────────────────────┤
│  Tier 3: LONG-TERM MEMORY                               │
│  ├── Persistent across sessions                         │
│  ├── Vector embeddings for semantic search              │
│  ├── 7 categories of knowledge                          │
│  └── Access: Semantic search (embedding similarity)     │
└─────────────────────────────────────────────────────────┘
```

## Tier 1: Short-Term Memory

### Storage

- Format: List of conversation turns
- Capacity: Last 20 turns (configurable)
- Persistence: Session only

### Content per Turn

```python
@dataclass
class ConversationTurn:
    role: str  # "user", "assistant", "system"
    content: str
    timestamp: float
    token_count: int
    tool_calls: list[ToolCall] | None
    tool_results: list[ToolResult] | None
```

### Summarization

When turns exceed the limit, older turns are summarized:

```python
async def summarize_old_turns(self, turns: list[Turn]) -> str:
    """Summarize old conversation turns."""
    summary_prompt = f"Summarize these conversation turns concisely:\n{turns}"
    return await self.llm.complete(summary_prompt)
```

## Tier 2: Working Memory

### Content

| Component | Description |
|-----------|-------------|
| Active Files | Contents of files being edited |
| Current Plan | Plan with step statuses |
| Scratch Pad | Intermediate calculations, notes |
| Environment | OS, Python version, git branch |
| Recent Outputs | Last few tool outputs |

### Update Frequency

Working memory is updated after every tool call:

```python
async def update_working_memory(self, result: ToolResult) -> None:
    """Update working memory with tool results."""
    if result.files_modified:
        for file in result.files_modified:
            self.working_memory.files[file] = await self.read_file(file)
    if result.environment_changed:
        self.working_memory.environment = await self.scan_environment()
```

## Tier 3: Long-Term Memory

### Categories

| Category | Content | Example |
|----------|---------|---------|
| Task | What was done, outcome | "Created REST API with Flask" |
| Error | Errors and solutions | "ImportError: pip install requests" |
| Pattern | Reusable solutions | "REST API: routes, models, tests" |
| Preference | User style | "Prefers pytest over unittest" |
| Project | Project knowledge | "This project uses TypeScript strict" |
| Tool | Tool patterns | "Use --force for new branch push" |
| Environment | System info | "Python 3.12, Ubuntu 22.04" |

### Storage

Long-term memory uses two storage systems:

1. **SQLite** — Structured metadata (category, timestamp, access count)
2. **Vector Store** — Embeddings for semantic search

```python
@dataclass
class MemoryEntry:
    id: str
    category: str
    content: str
    embedding: list[float]
    metadata: dict
    relevance: float
    access_count: int
    created_at: float
    last_accessed: float
```

### Vector Store Backends

| Backend | Type | Best For |
|---------|------|----------|
| ChromaDB | Local | Default, no dependencies |
| FAISS | Local | Large datasets, high performance |
| Pinecone | Cloud | Team collaboration |
| Qdrant | Local/Cloud | Balance of features |
| In-Memory | RAM | Testing |

## Memory Operations

### Store

```python
async def store(self, content: str, category: str, metadata: dict) -> str:
    """Store a new memory."""
    embedding = await self.embedder.embed(content)
    entry = MemoryEntry(
        id=generate_id(),
        category=category,
        content=content,
        embedding=embedding,
        metadata=metadata,
        relevance=1.0,
        access_count=0,
        created_at=time.time(),
        last_accessed=time.time(),
    )
    await self.db.insert(entry)
    await self.vector_store.upsert(entry)
    return entry.id
```

### Recall

```python
async def recall(self, query: str, limit: int = 5, category: str = None) -> list[MemoryEntry]:
    """Search for relevant memories."""
    query_embedding = await self.embedder.embed(query)
    results = await self.vector_store.search(
        query_vector=query_embedding,
        limit=limit,
        category=category,
    )
    # Update access counts
    for result in results:
        await self.db.update_access(result.id)
    return results
```

### Consolidation

Periodically, memories are consolidated:

1. **Group** — Cluster similar memories by embedding similarity
2. **Merge** — 2-3 similar memories become one
3. **Summarize** — 4+ memories become a summary
4. **Deduplicate** — Remove >95% similar memories
5. **Decay** — Reduce relevance of old, unused memories

### Decay Schedule

| Last Accessed | Relevance Reduction |
|---------------|---------------------|
| 30 days | -10% |
| 90 days | -25% |
| 180 days | -50% |
| 365 days | Archive |

## Embedding Models

| Model | Dimensions | Speed | Quality |
|-------|-----------|-------|---------|
| text-embedding-3-small | 1536 | Fast | Good |
| text-embedding-3-large | 3072 | Medium | Better |
| nomic-embed | 768 | Fast | Good |
| all-MiniLM-L6-v2 | 384 | Very Fast | Fair |

## Memory Search

Semantic search finds memories by meaning, not keywords:

```python
# Query: "How to handle database connections?"
# Finds memories about:
# - Connection pooling
# - SQLAlchemy setup
# - Database configuration
# - Connection error handling
```

## Integration with Agent Loop

Memory is used at three points in the agent loop:

1. **Context Assembly** — Top 5 relevant memories included in prompt
2. **Memory Update** — New memories stored after each turn
3. **Session End** — Consolidation and pattern extraction
