# Tool Architecture

Terminal Agent's tool system provides 40+ built-in tools across 13 categories.

## Tool Registry

All tools are registered in a central registry:

```python
class ToolRegistry:
    """Central registry for all tools."""

    def __init__(self):
        self._tools: dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        """Register a tool."""
        self._tools[tool.name] = tool

    def get(self, name: str) -> BaseTool:
        """Get a tool by name."""
        if name not in self._tools:
            raise ToolNotFoundError(f"Tool not found: {name}")
        return self._tools[name]

    def list_tools(self, category: str = None) -> list[BaseTool]:
        """List all tools, optionally filtered by category."""
        tools = list(self._tools.values())
        if category:
            tools = [t for t in tools if t.category == category]
        return tools
```

## Tool Base Class

Every tool extends `BaseTool`:

```python
class BaseTool(ABC):
    """Abstract base class for all tools."""

    name: str
    description: str
    category: str
    safety_level: str  # safe, moderate, destructive, dangerous

    @abstractmethod
    async def execute(self, **parameters) -> ToolResult:
        """Execute the tool."""
        ...

    @abstractmethod
    def get_schema(self) -> dict:
        """Return JSON Schema for parameters."""
        ...

    async def verify(self, result: ToolResult) -> bool:
        """Verify the tool's output."""
        return result.exit_code == 0
```

## Tool Result

```python
@dataclass
class ToolResult:
    output: str
    exit_code: int
    error: str = ""
    duration: float = 0.0
    files_modified: list[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
```

## Tool Dispatcher

The dispatcher routes tool calls to the correct tool:

```python
class ToolDispatcher:
    """Dispatches tool calls to the appropriate tool."""

    def __init__(self, registry: ToolRegistry, safety: SafetySystem):
        self.registry = registry
        self.safety = safety

    async def dispatch(self, tool_call: ToolCall) -> ToolResult:
        """Dispatch a tool call."""
        # Get the tool
        tool = self.registry.get(tool_call.name)

        # Safety check
        safety_result = await self.safety.evaluate(tool_call)
        if not safety_result.allowed:
            raise SafetyViolationError(safety_result.reason)

        # Execute with timeout
        result = await asyncio.wait_for(
            tool.execute(**tool_call.parameters),
            timeout=300.0,
        )

        # Verify
        await tool.verify(result)

        return result
```

## Tool Categories

### Shell Tools (8)

| Tool | Safety | Description |
|------|--------|-------------|
| `execute_command` | dangerous | Execute shell command |
| `execute_background` | dangerous | Background execution |
| `kill_process` | destructive | Kill a process |
| `list_processes` | safe | List running processes |
| `manage_environment` | moderate | Set env variables |
| `execute_pipeline` | dangerous | Execute command pipeline |
| `ssh_execute` | dangerous | Remote execution |
| `docker_execute` | dangerous | Execute in container |

### Filesystem Tools (13)

| Tool | Safety | Description |
|------|--------|-------------|
| `read_file` | safe | Read file contents |
| `write_file` | moderate | Write to file |
| `edit_file` | moderate | Edit file (search-replace) |
| `search_files` | safe | Search files |
| `move_file` | moderate | Move/rename file |
| `copy_file` | moderate | Copy file |
| `delete_file` | destructive | Delete file |
| `create_directory` | moderate | Create directory |
| `list_directory` | safe | List directory contents |
| `get_metadata` | safe | Get file metadata |
| `watch_file` | safe | Watch for changes |
| `compress` | moderate | Compress files |
| `create_temp` | moderate | Create temp files |

### Code Tools (19)

| Tool | Safety | Description |
|------|--------|-------------|
| `parse_ast` | safe | Parse code AST |
| `extract_symbols` | safe | Extract functions/classes |
| `find_references` | safe | Find symbol references |
| `rename_symbol` | moderate | Rename across files |
| `extract_function` | moderate | Extract to function |
| `inline_function` | moderate | Inline function |
| `move_code` | moderate | Move code between files |
| `format_code` | moderate | Format code |
| `lint_code` | safe | Lint code |
| `analyze_complexity` | safe | Measure complexity |
| `call_graph` | safe | Generate call graph |
| `detect_dead_code` | safe | Find unused code |
| `detect_smells` | safe | Code smell detection |
| `security_scan` | safe | Security analysis |
| `perf_analysis` | safe | Performance analysis |
| `dependency_analysis` | safe | Dependency analysis |
| `generate_types` | moderate | Generate type stubs |
| `convert_code` | moderate | Convert between languages |
| `generate_docs` | moderate | Generate documentation |

## Adding New Tools

See [Adding Tools](../developer-guide/adding-tools.md) for the complete guide.

## Tool Safety Classification

| Level | Description | Examples |
|-------|-------------|---------|
| `safe` | Read-only, no side effects | `read_file`, `search_files`, `parse_ast` |
| `moderate` | Write with backup | `write_file`, `edit_file`, `format_code` |
| `destructive` | Irreversible | `delete_file`, `drop_table`, `git_reset` |
| `dangerous` | System-level | `execute_command`, `docker_run`, `ssh_execute` |

## Tool Execution Pipeline

```
Tool Call
    │
    ▼
┌──────────────┐
│ Safety Check │ ── Block if unsafe
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Parameter   │ ── Validate against schema
│  Validation  │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Execution   │ ── Run with timeout
│  (async)     │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Result      │ ── Check exit code, output
│  Capture     │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Verification │ ── Syntax, format, logic checks
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   Logging    │ ── Record in trace
└──────────────┘
```
