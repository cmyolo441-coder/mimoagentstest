# Quick Start

Get Terminal Agent up and running in 5 minutes.

## Step 1: Install

```bash
pip install terminal-agent
```

## Step 2: Configure Your LLM

Set your API key (choose one):

```bash
# OpenAI
export TERMINAL_AGENT_LLM_OPENAI_API_KEY="sk-..."

# Anthropic
export TERMINAL_AGENT_LLM_ANTHROPIC_API_KEY="sk-ant-..."

# Or configure permanently
terminal-agent config set llm.openai.api_key "sk-..."
```

Or use a local model (free, no API key needed):

```bash
# First, install Ollama: https://ollama.ai
ollama pull llama3
terminal-agent config set llm.primary_provider ollama
```

## Step 3: Run Your First Task

```bash
terminal-agent run "Create a Python script that fetches the current weather for a given city using the OpenWeatherMap API"
```

Terminal Agent will:
1. Analyze your request
2. Create a plan
3. Write the code
4. Install any needed packages
5. Verify the result
6. Show you what was done

## Step 4: Try Interactive Mode

```bash
terminal-agent chat
```

This opens an interactive session where you can:
- Give tasks one at a time
- See the agent's reasoning in real-time
- Provide feedback and corrections
- Ask questions about the code

## Step 5: Explore

```bash
# See all available commands
terminal-agent --help

# List available tools
terminal-agent tools list

# Check system health
terminal-agent health

# View configuration
terminal-agent config show
```

## What Just Happened?

When you ran your first task, Terminal Agent:

1. **Parsed your goal** — Understood you wanted a weather API script
2. **Created a plan** — Broke it into steps (research API, write code, add error handling, etc.)
3. **Assembled context** — Gathered relevant information about your environment
4. **Called the LLM** — The model reasoned about the best approach
5. **Executed tools** — Created files, installed packages, ran commands
6. **Verified results** — Checked syntax, ran the script, validated output
7. **Stored memories** — Saved what it learned for future tasks

## Common First Tasks

Here are some great tasks to try:

### Create a Project
```bash
terminal-agent run "Create a FastAPI project with user authentication, PostgreSQL database, and Docker Compose setup"
```

### Fix a Bug
```bash
terminal-agent run "Look at src/app.py and fix the error handling — it's not catching database connection failures"
```

### Write Tests
```bash
terminal-agent run "Write comprehensive tests for the functions in src/utils.py"
```

### Refactor Code
```bash
terminal-agent run "Refactor the database connection code in src/db.py to use connection pooling"
```

### Add a Feature
```bash
terminal-agent run "Add rate limiting middleware to the API with configurable limits per endpoint"
```

## Next Steps

- [Your First Task](first-task.md) — Detailed walkthrough of a complete task
- [Configuration](configuration.md) — Customize Terminal Agent for your workflow
- [CLI Reference](../user-guide/cli-reference.md) — All commands and options
- [Tool Reference](../user-guide/tool-reference.md) — All 40+ available tools
