# Your First Task

This tutorial walks you through a complete task with Terminal Agent, explaining each step of the process.

## The Task

We'll ask Terminal Agent to create a simple CLI tool that converts CSV files to JSON format.

```bash
terminal-agent run "Create a Python CLI tool that converts CSV files to JSON. It should:
1. Accept input CSV file path and output JSON file path as arguments
2. Handle errors gracefully (file not found, invalid CSV)
3. Support optional pretty-printing
4. Include a --help flag
5. Write tests for all functionality"
```

## What Happens

### Phase 1: Goal Analysis

Terminal Agent first analyzes your request:

```
📋 Goal Analysis
├── Intent: Create a Python CLI tool for CSV to JSON conversion
├── Scope: Medium (single-purpose tool with tests)
├── Language: Python
├── Tools needed: filesystem, code, package_manager, testing
└── Estimated steps: 6-8
```

### Phase 2: Plan Generation

The agent creates a multi-step plan:

```
📝 Plan
├── 1. [pending] Analyze requirements and design the tool structure
├── 2. [pending] Create the main CLI script with argparse
├── 3. [pending] Implement CSV parsing and JSON conversion logic
├── 4. [pending] Add error handling for file operations
├── 5. [pending] Implement pretty-printing option
├── 6. [pending] Create test file with comprehensive tests
├── 7. [pending] Run tests and verify everything works
└── 8. [pending] Run the tool with sample data to verify end-to-end
```

### Phase 3: Execution

The agent begins executing each step:

#### Step 1: Analysis

The agent thinks:
> I need to create a Python CLI tool. I'll use argparse for the CLI interface,
> the csv module for parsing, and json for output. I'll structure it as a
> single file with a main function and helper functions.

#### Step 2: Create the Main Script

The agent uses the filesystem tool to create `csv_to_json.py`:

```python
#!/usr/bin/env python3
"""Convert CSV files to JSON format."""

import argparse
import csv
import json
import sys
from pathlib import Path


def csv_to_json(input_path: str, output_path: str, pretty: bool = False) -> None:
    """Convert a CSV file to JSON format.

    Args:
        input_path: Path to the input CSV file.
        output_path: Path to the output JSON file.
        pretty: Whether to pretty-print the JSON output.

    Raises:
        FileNotFoundError: If the input file does not exist.
        csv.Error: If the CSV file is malformed.
    """
    input_file = Path(input_path)
    if not input_file.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    if not input_file.suffix.lower() == '.csv':
        print(f"Warning: Input file does not have .csv extension: {input_path}")

    with open(input_file, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        rows = list(reader)

    indent = 2 if pretty else None
    with open(output_path, 'w', encoding='utf-8') as jsonfile:
        json.dump(rows, jsonfile, indent=indent, ensure_ascii=False)

    print(f"Converted {len(rows)} rows from {input_path} to {output_path}")


def main() -> None:
    """Main entry point for the CLI tool."""
    parser = argparse.ArgumentParser(
        description="Convert CSV files to JSON format."
    )
    parser.add_argument("input", help="Path to the input CSV file")
    parser.add_argument("output", help="Path to the output JSON file")
    parser.add_argument(
        "--pretty", "-p",
        action="store_true",
        help="Pretty-print the JSON output"
    )

    args = parser.parse_args()

    try:
        csv_to_json(args.input, args.output, args.pretty)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except csv.Error as e:
        print(f"Error reading CSV: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
```

#### Step 3-5: Implementation Details

The agent continues implementing features, verifying each step:

```
✅ Step 2: Created csv_to_json.py with CLI interface
✅ Step 3: Implemented CSV parsing and JSON conversion
✅ Step 4: Added error handling (FileNotFoundError, csv.Error)
✅ Step 5: Implemented --pretty flag with indentation
```

#### Step 6: Create Tests

The agent creates `test_csv_to_json.py`:

```python
"""Tests for csv_to_json tool."""

import json
import pytest
from csv_to_json import csv_to_json


class TestCsvToJson:
    """Tests for the csv_to_json function."""

    def test_basic_conversion(self, tmp_path):
        """Test basic CSV to JSON conversion."""
        csv_file = tmp_path / "test.csv"
        csv_file.write_text("name,age\nAlice,30\nBob,25")
        json_file = tmp_path / "output.json"

        csv_to_json(str(csv_file), str(json_file))

        result = json.loads(json_file.read_text())
        assert len(result) == 2
        assert result[0]["name"] == "Alice"
        assert result[0]["age"] == "30"

    def test_pretty_print(self, tmp_path):
        """Test pretty-printing option."""
        csv_file = tmp_path / "test.csv"
        csv_file.write_text("name,age\nAlice,30")
        json_file = tmp_path / "output.json"

        csv_to_json(str(csv_file), str(json_file), pretty=True)

        content = json_file.read_text()
        assert "\n" in content  # Pretty-printed JSON has newlines
        assert "  " in content  # And indentation

    def test_file_not_found(self, tmp_path):
        """Test error handling for missing input file."""
        json_file = tmp_path / "output.json"

        with pytest.raises(FileNotFoundError):
            csv_to_json("/nonexistent/file.csv", str(json_file))

    def test_empty_csv(self, tmp_path):
        """Test handling of empty CSV file."""
        csv_file = tmp_path / "empty.csv"
        csv_file.write_text("name,age\n")  # Header only
        json_file = tmp_path / "output.json"

        csv_to_json(str(csv_file), str(json_file))

        result = json.loads(json_file.read_text())
        assert result == []

    def test_special_characters(self, tmp_path):
        """Test handling of special characters."""
        csv_file = tmp_path / "special.csv"
        csv_file.write_text('name,city\n"O\'Brien","São Paulo"\n"Smith","東京"')
        json_file = tmp_path / "output.json"

        csv_to_json(str(csv_file), str(json_file))

        result = json.loads(json_file.read_text())
        assert result[0]["name"] == "O'Brien"
        assert result[0]["city"] == "São Paulo"
```

#### Step 7: Run Tests

```
🧪 Running tests...
tests/test_csv_to_json::test_basic_conversion        ✅ PASSED
tests/test_csv_to_json::test_pretty_print            ✅ PASSED
tests/test_csv_to_json::test_file_not_found          ✅ PASSED
tests/test_csv_to_json::test_empty_csv               ✅ PASSED
tests/test_csv_to_json::test_special_characters      ✅ PASSED

5 passed in 0.12s
```

#### Step 8: End-to-End Verification

The agent creates a sample CSV and runs the tool:

```bash
$ echo "name,age,city
> Alice,30,New York
> Bob,25,London
> Charlie,35,Tokyo" > sample.csv

$ python csv_to_json.py sample.csv output.json --pretty

Converted 3 rows from sample.csv to output.json

$ cat output.json
[
  {
    "name": "Alice",
    "age": "30",
    "city": "New York"
  },
  ...
]
```

### Phase 4: Completion

The agent presents the results:

```
✅ Task Complete!

📋 Summary:
├── Created: csv_to_json.py (CLI tool)
├── Created: test_csv_to_json.py (5 tests)
├── All tests passed
└── End-to-end verification successful

📝 Files created/modified:
├── csv_to_json.py (new)
└── test_csv_to_json.py (new)

🔧 Features implemented:
├── CSV to JSON conversion
├── CLI with argparse (--help, --pretty)
├── Error handling (file not found, invalid CSV)
├── Pretty-printing option
└── Comprehensive test suite

💡 Suggestions:
├── Consider adding --delimiter option for non-comma CSVs
├── Consider adding --encoding option for non-UTF-8 files
└── Consider adding support for reading from stdin
```

## Understanding the Process

### What the Agent Did

1. **Parsed your natural language request** into a structured goal
2. **Generated a multi-step plan** considering dependencies
3. **For each step**, it:
   - Thought about the best approach (Thought)
   - Selected a tool to use (Action)
   - Executed the tool (Tool Call)
   - Verified the result (Verification)
   - Stored what it learned (Memory Update)
4. **Verified the complete solution** by running all tests
5. **Reported results** with a clear summary

### How to Interact

During execution, you can:

- **Watch progress** — See each step as it happens
- **Interrupt** — Press `Ctrl+C` to stop (state is saved)
- **Provide feedback** — The agent will ask if it needs clarification
- **Resume later** — `terminal-agent sessions resume <id>`

### What the Agent Learned

The agent stored several memories:

- **Pattern**: "CLI tools with argparse follow a standard structure"
- **Error handling**: "FileNotFoundError is the common error for file CLI tools"
- **Testing**: "pytest with tmp_path fixture is effective for file operation tests"
- **Preference**: "User prefers comprehensive error handling and tests"

These memories will help the agent in future tasks.

## Next Steps

- [Configuration](configuration.md) — Customize the agent's behavior
- [CLI Reference](../user-guide/cli-reference.md) — All available commands
- [Memory System](../user-guide/memory-system.md) — How memory works
- [Safety System](../user-guide/safety-system.md) — Safety levels and rules
