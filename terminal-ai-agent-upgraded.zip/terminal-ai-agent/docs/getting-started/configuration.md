# Configuration

Terminal Agent is configured through TOML files, environment variables, and CLI flags. This guide covers the essential configuration options.

## Configuration Sources

Configuration is merged from multiple sources with the following precedence (highest wins):

1. **CLI flags** — `--flag value`
2. **Environment variables** — `TERMINAL_AGENT_*`
3. **Project config** — `./.agent/project.toml`
4. **Global config** — `~/.terminal-agent/config.toml`
5. **Defaults** — Built-in defaults

## Quick Configuration

### Set Your API Key

```bash
# OpenAI
terminal-agent config set llm.openai.api_key "sk-..."

# Anthropic
terminal-agent config set llm.anthropic.api_key "sk-ant-..."

# Or use environment variables
export TERMINAL_AGENT_LLM_OPENAI_API_KEY="sk-..."
```

### Choose Your Model

```bash
# Use GPT-4o (default)
terminal-agent config set llm.primary_provider openai
terminal-agent config set llm.primary_model gpt-4o

# Use Claude
terminal-agent config set llm.primary_provider anthropic
terminal-agent config set llm.primary_model claude-opus-4-20250514

# Use local Ollama
terminal-agent config set llm.primary_provider ollama
terminal-agent config set llm.ollama.model llama3
```

### Set Safety Level

```bash
# Standard (default) — blocks destructive commands, confirms modifications
terminal-agent config set safety.level 2

# Strict — confirms everything, read-only by default
terminal-agent config set safety.level 4
```

## Configuration File

The global configuration file is at `~/.terminal-agent/config.toml`:

```toml
[general]
log_level = "INFO"
theme = "dark"
safety_level = 2
auto_save_sessions = true

[llm]
primary_provider = "openai"
primary_model = "gpt-4o"
temperature = 0.7
max_tokens = 4096
timeout = 120
streaming = true
cost_limit_per_task = 5.00

[llm.openai]
api_key = "sk-..."

[memory]
short_term_turns = 20
long_term_memories_per_query = 5
vector_backend = "chroma"

[cache]
backend = "disk"
max_size = 1000
ttl = 3600

[tools]
shell_timeout = 300
confirm_delete = true
backup_before_edit = true

[safety]
level = 2
audit_log = true

[logging]
level = "INFO"
format = "json"
```

## Environment Variables

Any configuration option can be set via environment variables. The pattern is:

```
TERMINAL_AGENT_<SECTION>_<KEY>
```

Examples:

```bash
export TERMINAL_AGENT_LLM_PRIMARY_PROVIDER="anthropic"
export TERMINAL_AGENT_LLM_PRIMARY_MODEL="claude-opus-4-20250514"
export TERMINAL_AGENT_LLM_ANTHROPIC_API_KEY="sk-ant-..."
export TERMINAL_AGENT_SAFETY_LEVEL="3"
export TERMINAL_AGENT_GENERAL_LOG_LEVEL="DEBUG"
```

## CLI Flags

Override configuration for a single command:

```bash
terminal-agent run --model gpt-4o --temperature 0.3 "your task"
terminal-agent chat --safety-level 3
terminal-agent run --provider anthropic "your task"
```

## Managing Configuration

### View Current Configuration

```bash
# Show all configuration
terminal-agent config show

# Show a specific section
terminal-agent config show llm

# Show a specific value
terminal-agent config get llm.primary_model
```

### Set Values

```bash
terminal-agent config set <key> <value>

# Examples
terminal-agent config set llm.primary_model gpt-4o
terminal-agent config set safety.level 3
terminal-agent config set llm.temperature 0.5
```

### Reset to Defaults

```bash
# Reset a specific key
terminal-agent config reset llm.temperature

# Reset all configuration
terminal-agent config reset --all
```

### Configuration Profiles

Switch between different configurations:

```bash
# Create a profile
terminal-agent config profile create work --base standard

# Switch profiles
terminal-agent config profile use work

# List profiles
terminal-agent config profile list
```

## Project Configuration

Create a `.agent/project.toml` in your project root for project-specific settings:

```toml
# .agent/project.toml
[general]
safety_level = 3  # Stricter for this project

[tools]
# Only allow these tools for this project
enabled = ["filesystem", "code", "git", "testing"]

[llm]
# Use a specific model for this project
primary_model = "gpt-4o"
```

Project configuration overrides global configuration for that project.

## Sensitive Values

API keys and other sensitive values are encrypted at rest:

```bash
# Set a sensitive value (automatically encrypted)
terminal-agent config set llm.openai.api_key "sk-..."

# The stored value is encrypted
# ~/.terminal-agent/config.toml will show:
# api_key = "enc:AES256:..."
```

## Next Steps

- [Configuration Reference](../user-guide/configuration-reference.md) — All configuration options
- [CLI Reference](../user-guide/cli-reference.md) — All CLI commands
- [Troubleshooting](troubleshooting.md) — Common configuration issues
