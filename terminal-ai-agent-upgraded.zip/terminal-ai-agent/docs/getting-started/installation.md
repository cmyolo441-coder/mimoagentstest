# Installation

This guide walks you through installing Terminal Agent on your system.

## Requirements

| Requirement | Minimum | Recommended |
|-------------|---------|-------------|
| Python | 3.10 | 3.12 |
| OS | Linux, macOS, Windows (WSL) | Linux or macOS |
| RAM | 512 MB | 2 GB |
| Disk | 100 MB | 500 MB |
| Network | For cloud LLM providers | Broadband |

## Install with pip

The simplest way to install Terminal Agent:

```bash
pip install terminal-agent
```

Verify the installation:

```bash
terminal-agent --version
```

## Install with pipx (Recommended)

[pipx](https://pipx.pypa.io/) installs Terminal Agent in an isolated environment, avoiding dependency conflicts:

```bash
# Install pipx if you don't have it
pip install pipx
pipx ensurepath

# Install Terminal Agent
pipx install terminal-agent
```

## Install from Source

For development or the latest features:

```bash
git clone https://github.com/terminal-agent/terminal-agent.git
cd terminal-agent
pip install -e ".[dev]"
```

## Install with Docker

```bash
# Pull the image
docker pull terminal-agent/terminal-agent:latest

# Run a task
docker run -it --rm \
  -e TERMINAL_AGENT_LLM_OPENAI_API_KEY="sk-..." \
  -v $(pwd):/workspace \
  terminal-agent/terminal-agent:latest \
  run "your task here"

# Interactive mode
docker run -it --rm \
  -e TERMINAL_AGENT_LLM_OPENAI_API_KEY="sk-..." \
  -v $(pwd):/workspace \
  terminal-agent/terminal-agent:latest \
  chat
```

## Install from Package Managers

### macOS (Homebrew)

```bash
brew install terminal-agent
```

### Ubuntu/Debian (apt)

```bash
# Add the repository
curl -fsSL https://packages.terminal-agent.dev/gpg-key | sudo gpg --dearmor -o /usr/share/keyrings/terminal-agent.gpg
echo "deb [signed-by=/usr/share/keyrings/terminal-agent.gpg] https://packages.terminal-agent.dev/apt stable main" | sudo tee /etc/apt/sources.list.d/terminal-agent.list

# Install
sudo apt update
sudo apt install terminal-agent
```

### Windows (winget)

```powershell
winget install TerminalAgent
```

### Windows (Scoop)

```powershell
scoop install terminal-agent
```

## Post-Installation Setup

### 1. Set Up Your LLM Provider

Terminal Agent needs an LLM provider to function. Choose one:

#### OpenAI (Recommended for getting started)

```bash
export TERMINAL_AGENT_LLM_OPENAI_API_KEY="sk-..."
# or
terminal-agent config set llm.openai.api_key "sk-..."
```

#### Anthropic

```bash
export TERMINAL_AGENT_LLM_ANTHROPIC_API_KEY="sk-ant-..."
# or
terminal-agent config set llm.anthropic.api_key "sk-ant-..."
```

#### Ollama (Local, Free)

```bash
# Install Ollama: https://ollama.ai
ollama pull llama3

# Configure Terminal Agent
terminal-agent config set llm.primary_provider ollama
terminal-agent config set llm.ollama.model llama3
```

### 2. Run the Health Check

```bash
terminal-agent health
```

This verifies:
- Python version is compatible
- Configuration is valid
- LLM provider is reachable
- Required tools are available
- Database is initialized

### 3. Set Up Shell Completion

#### Bash

```bash
# Add to ~/.bashrc
eval "$(terminal-agent completion bash)"
```

#### Zsh

```bash
# Add to ~/.zshrc
eval "$(terminal-agent completion zsh)"
```

#### Fish

```bash
# Add to ~/.config/fish/config.fish
terminal-agent completion fish | source
```

### 4. (Optional) Configure Safety Level

The default safety level is 2 (Standard). To change:

```bash
# More permissive (for sandboxed environments)
terminal-agent config set safety.level 1

# More restrictive (for production environments)
terminal-agent config set safety.level 3
```

## Verify Installation

```bash
# Check version
terminal-agent --version

# Run health check
terminal-agent health

# List available tools
terminal-agent tools list

# List configured models
terminal-agent models list

# Run a simple test task
terminal-agent run "Create a file called hello.txt with the content 'Hello, World!'"
```

## Updating

```bash
# Update with pip
pip install --upgrade terminal-agent

# Update with pipx
pipx upgrade terminal-agent

# Update with the built-in command
terminal-agent update
```

## Uninstalling

```bash
# Uninstall with pip
pip uninstall terminal-agent

# Uninstall with pipx
pipx uninstall terminal-agent

# Remove data (optional)
rm -rf ~/.terminal-agent
```

## Platform-Specific Notes

### Linux

Terminal Agent works on all major Linux distributions. Ensure Python 3.10+ is installed:

```bash
python3 --version
```

If your system Python is older, use [pyenv](https://github.com/pyenv/pyenv):

```bash
pyenv install 3.12
pyenv global 3.12
```

### macOS

Terminal Agent works on macOS 11+ (Big Sur and later). Install Python via Homebrew if needed:

```bash
brew install python@3.12
```

### Windows

Terminal Agent works on Windows 10+ via WSL (Windows Subsystem for Linux):

```powershell
# Install WSL if not already installed
wsl --install

# Inside WSL, follow the Linux installation instructions
```

Native Windows support (without WSL) is experimental.

## Troubleshooting Installation

### "Python version not supported"

Terminal Agent requires Python 3.10 or higher. Check your version:

```bash
python3 --version
```

### "pip: command not found"

Use `pip3` instead:

```bash
pip3 install terminal-agent
```

### "Permission denied"

Don't use `sudo pip install`. Use pipx or a virtual environment:

```bash
pipx install terminal-agent
# or
python3 -m venv .venv
source .venv/bin/activate
pip install terminal-agent
```

### "Dependency conflict"

Use pipx to isolate Terminal Agent's dependencies:

```bash
pipx install terminal-agent
```

For more troubleshooting, see [Troubleshooting](troubleshooting.md).
