# Troubleshooting

Common issues and their solutions.

## Installation Issues

### "Python version not supported"

Terminal Agent requires Python 3.10 or higher.

```bash
python3 --version
```

If your version is older:
```bash
# Using pyenv
pyenv install 3.12
pyenv global 3.12

# Using conda
conda create -n terminal-agent python=3.12
conda activate terminal-agent
```

### "pip: command not found"

Use `pip3` instead:
```bash
pip3 install terminal-agent
```

### "Permission denied"

Never use `sudo pip install`. Use pipx or a virtual environment:
```bash
pipx install terminal-agent
# or
python3 -m venv .venv && source .venv/bin/activate && pip install terminal-agent
```

### "Dependency conflict"

Use pipx for isolated installation:
```bash
pip install pipx
pipx install terminal-agent
```

## Connection Issues

### "Could not connect to LLM provider"

1. **Check your API key**:
   ```bash
   terminal-agent config get llm.openai.api_key
   ```

2. **Check internet connectivity**:
   ```bash
   curl https://api.openai.com/v1/models -H "Authorization: Bearer $TERMINAL_AGENT_LLM_OPENAI_API_KEY"
   ```

3. **Check if the provider is down**:
   - OpenAI: https://status.openai.com
   - Anthropic: https://status.anthropic.com

4. **Try a different provider**:
   ```bash
   terminal-agent config set llm.primary_provider anthropic
   ```

### "Rate limit exceeded"

Terminal Agent has built-in rate limiting, but you may hit provider limits:

```toml
[rate_limiting]
llm_calls_per_minute = 30  # Reduce from default 60
```

Or wait a minute and try again.

### "Timeout waiting for LLM response"

Increase the timeout:
```bash
terminal-agent config set llm.timeout 300
```

Or use a faster model:
```bash
terminal-agent config set llm.primary_model gpt-4o-mini
```

## Configuration Issues

### "Configuration file not found"

Create the configuration directory and file:
```bash
mkdir -p ~/.terminal-agent
terminal-agent config set llm.openai.api_key "sk-..."
```

### "Invalid configuration value"

Validate your configuration:
```bash
terminal-agent config validate
```

### "API key not set"

Set your API key:
```bash
# Via config
terminal-agent config set llm.openai.api_key "sk-..."

# Via environment variable
export TERMINAL_AGENT_LLM_OPENAI_API_KEY="sk-..."

# Verify
terminal-agent health
```

## Runtime Issues

### "Tool execution failed"

1. **Check tool availability**:
   ```bash
   terminal-agent tools list
   ```

2. **Check safety level** (tool may be blocked):
   ```bash
   terminal-agent config get safety.level
   ```

3. **Check logs**:
   ```bash
   cat ~/.terminal-agent/logs/agent.log | tail -50
   ```

### "Safety violation: command blocked"

The safety system blocked a dangerous command. Options:

1. **Review the command** — Was it actually dangerous?
2. **Lower safety level** (if safe to do so):
   ```bash
   terminal-agent config set safety.level 1
   ```
3. **Add an exception**:
   ```toml
   [safety]
   allowed_patterns = ["specific-command-pattern"]
   ```

### "Agent seems stuck"

1. **Press `Ctrl+C`** to interrupt gracefully
2. **Check the logs** for what it's doing:
   ```bash
   tail -f ~/.terminal-agent/logs/agent.log
   ```
3. **Resume the session**:
   ```bash
   terminal-agent sessions resume <session-id>
   ```

### "Agent is making mistakes"

1. **Be more specific** in your task description
2. **Provide context** — mention relevant files, frameworks, conventions
3. **Use the TUI** to see the agent's reasoning:
   ```bash
   terminal-agent chat
   ```
4. **Lower temperature** for more deterministic output:
   ```bash
   terminal-agent config set llm.temperature 0.3
   ```

### "Out of memory"

Reduce memory usage:
```toml
[memory]
short_term_turns = 10  # Reduce from default 20
max_memory_size = 5000  # Reduce from default 10000

[cache]
max_size = 500  # Reduce from default 1000
```

## Performance Issues

### "Agent is slow"

1. **Use a faster model**:
   ```bash
   terminal-agent config set llm.primary_model gpt-4o-mini
   ```

2. **Use a local model** (no network latency):
   ```bash
   terminal-agent config set llm.primary_provider ollama
   ```

3. **Enable caching**:
   ```bash
   terminal-agent config set cache.backend disk
   ```

4. **Reduce context window**:
   ```bash
   terminal-agent config set memory.short_term_turns 10
   ```

### "High API costs"

1. **Set cost limits**:
   ```bash
   terminal-agent config set llm.cost_limit_per_task 1.00
   ```

2. **Use cheaper models**:
   ```bash
   terminal-agent config set llm.primary_model gpt-4o-mini
   ```

3. **Enable caching**:
   ```bash
   terminal-agent config set llm.cache_responses true
   ```

4. **Check cost breakdown**:
   ```bash
   terminal-agent metrics show
   ```

## TUI Issues

### "TUI not rendering correctly"

1. **Check terminal size** — Minimum 80x24
2. **Check terminal compatibility** — Use a modern terminal (iTerm2, Windows Terminal, Alacritty)
3. **Try a different theme**:
   ```bash
   terminal-agent config set general.theme light
   ```

### "Colors look wrong"

```bash
# Try high-contrast theme
terminal-agent config set general.theme high_contrast

# Or monochrome
terminal-agent config set general.theme monokai
```

## Plugin Issues

### "Plugin not loading"

1. **Check plugin directory**:
   ```bash
   terminal-agent plugins list
   ```

2. **Validate the plugin**:
   ```bash
   terminal-agent plugins validate <plugin-name>
   ```

3. **Check logs**:
   ```bash
   grep "plugin" ~/.terminal-agent/logs/agent.log
   ```

### "Plugin conflicts"

Disable conflicting plugins:
```bash
terminal-agent plugins disable <plugin-name>
```

## Database Issues

### "Database is locked"

Another Terminal Agent instance may be running:
```bash
# Check for running instances
ps aux | grep terminal-agent

# Kill if necessary
kill <pid>
```

### "Database corruption"

Reset the database:
```bash
# Backup first
cp ~/.terminal-agent/agent.db ~/.terminal-agent/agent.db.backup

# Reset
terminal-agent sessions clear --all
```

## Getting More Help

### Enable Debug Logging

```bash
terminal-agent config set general.log_level DEBUG
terminal-agent run "your task"
cat ~/.terminal-agent/logs/agent.log
```

### Run Health Check

```bash
terminal-agent health
```

### Check System Info

```bash
terminal-agent --version
python3 --version
uname -a  # OS info
```

### Report a Bug

If you've tried the above and still have issues:

1. Check [existing issues](https://github.com/terminal-agent/terminal-agent/issues)
2. Create a [bug report](https://github.com/terminal-agent/terminal-agent/issues/new?template=bug_report.md) with:
   - Terminal Agent version
   - Python version
   - Operating system
   - Steps to reproduce
   - Expected vs actual behavior
   - Relevant logs (with `DEBUG` logging enabled)
