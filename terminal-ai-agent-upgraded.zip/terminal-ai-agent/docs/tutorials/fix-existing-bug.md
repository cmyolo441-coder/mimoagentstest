# Tutorial: Fix an Existing Bug

Walk through finding and fixing a bug with Terminal Agent.

## The Task

The login endpoint in your API returns a 500 error when the email field is missing.

## Step 1: Describe the Bug

```bash
terminal-agent run "The login endpoint POST /api/auth/login returns a 500 Internal Server Error when the email field is missing from the request body. It should return a 400 Bad Request with a clear error message. Find and fix the bug."
```

## Step 2: Agent Investigates

The agent will:

1. **Find the login route** — Search for the endpoint
2. **Read the code** — Understand the current implementation
3. **Identify the issue** — Missing input validation
4. **Fix the bug** — Add proper validation
5. **Verify the fix** — Test the endpoint

## Step 3: Agent's Analysis

```
💭 Analysis:
The login endpoint in src/routes/auth.js doesn't validate the request body
before accessing req.body.email. When email is undefined, the database
query throws an error that isn't caught, resulting in a 500 error.

Fix: Add input validation before the database query.
```

## Step 4: The Fix

```javascript
// Before (buggy)
router.post('/login', async (req, res) => {
  const user = await User.findByEmail(req.body.email);
  // ...
});

// After (fixed)
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      error: 'Email and password are required'
    });
  }

  const user = await User.findByEmail(email);
  // ...
});
```

## Step 5: Verification

```
✅ Verification:
├── Syntax valid
├── Added validation for missing email
├── Added validation for missing password
├── Returns 400 with clear error message
└── Existing tests still pass
```

## What You Learned

- Terminal Agent can analyze existing code
- It identifies root causes, not just symptoms
- It verifies fixes don't break existing functionality
- It explains what was wrong and why

## Similar Tasks

```bash
# Find and fix security vulnerabilities
terminal-agent run "Review src/routes/ for SQL injection vulnerabilities and fix them"

# Fix performance issues
terminal-agent run "The /api/users endpoint is slow. Profile it and optimize"

# Fix type errors
terminal-agent run "Fix all TypeScript errors in src/models/"
```
