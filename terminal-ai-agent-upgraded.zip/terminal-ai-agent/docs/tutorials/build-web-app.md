# Tutorial: Build a Web Application

Walk through building a full-stack web application with Terminal Agent.

## The Task

Build a task management web app with:
- React frontend
- Node.js/Express backend
- PostgreSQL database
- User authentication
- Docker Compose setup

## Step 1: Start the Task

```bash
terminal-agent run "Create a full-stack task management application with:
- React frontend with a clean UI
- Node.js/Express REST API backend
- PostgreSQL database
- User registration and login with JWT authentication
- CRUD operations for tasks (create, read, update, delete)
- Docker Compose for the complete stack
- Include README with setup instructions"
```

## Step 2: Watch the Plan

Terminal Agent will create a plan:

```
📋 Plan
├── 1. [pending] Set up project structure
├── 2. [pending] Create database schema and migrations
├── 3. [pending] Build Express API with authentication
├── 4. [pending] Implement task CRUD endpoints
├── 5. [pending] Create React frontend
├── 6. [pending] Add authentication UI (login/register)
├── 7. [pending] Build task management UI
├── 8. [pending] Create Docker Compose configuration
├── 9. [pending] Write README documentation
└── 10. [pending] Test the complete application
```

## Step 3: Agent Executes

The agent will:

1. **Create project structure** — Directories, package.json, requirements
2. **Set up database** — PostgreSQL schema, migrations
3. **Build API** — Express routes, middleware, JWT auth
4. **Create frontend** — React components, API integration
5. **Docker setup** — Dockerfile, docker-compose.yml
6. **Documentation** — README with setup instructions

## Step 4: Review Results

The agent creates:

```
task-manager/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── services/
│   │   └── App.tsx
│   ├── package.json
│   └── Dockerfile
├── backend/
│   ├── src/
│   │   ├── routes/
│   │   ├── middleware/
│   │   ├── models/
│   │   └── index.ts
│   ├── package.json
│   └── Dockerfile
├── database/
│   └── migrations/
├── docker-compose.yml
└── README.md
```

## Step 5: Run the Application

```bash
cd task-manager
docker-compose up -d
# Frontend: http://localhost:3000
# Backend: http://localhost:5000
```

## What You Learned

- Terminal Agent can create complete multi-service applications
- It understands project structure conventions
- It handles Docker Compose configuration automatically
- It generates documentation for the project

## Next Steps

- Add more features: `terminal-agent run "Add task categories and due dates"`
- Add tests: `terminal-agent run "Write integration tests for the API"`
- Deploy: See [Deploy Application](deploy-application.md)
