# Tutorial: Database Migration

Walk through creating and running database migrations with Terminal Agent.

## The Task

Create a database migration to add a roles and permissions system.

## Step 1: Describe the Migration

```bash
terminal-agent run "Create a database migration to add a roles and permissions system:
- Create a 'roles' table (id, name, description)
- Create a 'permissions' table (id, name, description)
- Create a 'role_permissions' junction table
- Create a 'user_roles' junction table
- Add default roles (admin, user, moderator)
- Update the User model to support roles"
```

## Step 2: Agent Creates Migration

### Migration File

```python
# migrations/versions/003_add_roles_permissions.py

"""Add roles and permissions system.

Revision ID: 003
Revises: 002
Create Date: 2025-01-15 10:00:00
"""

from alembic import op
import sqlalchemy as sa

revision = '003'
down_revision = '002'

def upgrade():
    # Create roles table
    op.create_table(
        'roles',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('name', sa.String(50), unique=True, nullable=False),
        sa.Column('description', sa.String(255)),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now()),
    )

    # Create permissions table
    op.create_table(
        'permissions',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('name', sa.String(100), unique=True, nullable=False),
        sa.Column('description', sa.String(255)),
    )

    # Create role_permissions junction table
    op.create_table(
        'role_permissions',
        sa.Column('role_id', sa.Integer(), sa.ForeignKey('roles.id'), primary_key=True),
        sa.Column('permission_id', sa.Integer(), sa.ForeignKey('permissions.id'), primary_key=True),
    )

    # Create user_roles junction table
    op.create_table(
        'user_roles',
        sa.Column('user_id', sa.Integer(), sa.ForeignKey('users.id'), primary_key=True),
        sa.Column('role_id', sa.Integer(), sa.ForeignKey('roles.id'), primary_key=True),
        sa.Column('assigned_at', sa.DateTime(), server_default=sa.func.now()),
    )

    # Insert default roles
    op.execute("""
        INSERT INTO roles (name, description) VALUES
        ('admin', 'Full system access'),
        ('moderator', 'Can manage users and content'),
        ('user', 'Standard user access')
    """)

    # Insert default permissions
    op.execute("""
        INSERT INTO permissions (name, description) VALUES
        ('users:read', 'View user profiles'),
        ('users:write', 'Edit user profiles'),
        ('users:delete', 'Delete users'),
        ('content:read', 'View content'),
        ('content:write', 'Create and edit content'),
        ('content:delete', 'Delete content'),
        ('admin:access', 'Access admin panel')
    """)

    # Assign permissions to roles
    op.execute("""
        INSERT INTO role_permissions (role_id, permission_id)
        SELECT r.id, p.id FROM roles r, permissions p
        WHERE r.name = 'admin'
    """)

def downgrade():
    op.drop_table('user_roles')
    op.drop_table('role_permissions')
    op.drop_table('permissions')
    op.drop_table('roles')
```

## Step 3: Run Migration

```bash
# Apply migration
alembic upgrade head

# Check status
alembic current

# Rollback if needed
alembic downgrade -1
```

## Step 4: Verification

```
✅ Migration Complete:
├── roles table created (3 default roles)
├── permissions table created (7 default permissions)
├── role_permissions junction table created
├── user_roles junction table created
├── Default data inserted
└── Rollback script included
```

## What You Learned

- Terminal Agent creates complete migration files
- It handles both upgrade and downgrade
- It inserts default/seed data
- It creates proper foreign key relationships
