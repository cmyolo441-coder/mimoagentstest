# Tutorial: Set Up CI/CD

Walk through setting up CI/CD with Terminal Agent.

## The Task

Set up GitHub Actions CI/CD for a Python project.

## Step 1: Request CI/CD

```bash
terminal-agent run "Set up GitHub Actions CI/CD for this Python project. Include:
- Linting with ruff
- Type checking with mypy
- Unit tests with pytest
- Coverage reporting
- Integration tests on PR
- Automatic deployment to PyPI on tag push
- Dependabot for dependency updates"
```

## Step 2: Agent Creates Configuration

### CI Workflow

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: pip install ruff mypy
      - run: ruff check src/
      - run: ruff format --check src/
      - run: mypy src/

  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.10', '3.11', '3.12']
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - run: pip install -e ".[dev]"
      - run: pytest --cov=src --cov-report=xml
      - uses: codecov/codecov-action@v4
```

### Release Workflow

```yaml
# .github/workflows/release.yml
name: Release

on:
  push:
    tags:
      - 'v*'

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: pip install build
      - run: python -m build
      - uses: pypa/gh-action-pypi-publish@release/v1
```

### Dependabot

```yaml
# .github/dependabot.yml
version: 2
updates:
  - package-ecosystem: pip
    directory: "/"
    schedule:
      interval: weekly
  - package-ecosystem: github-actions
    directory: "/"
    schedule:
      interval: weekly
```

## Step 3: Verification

```
✅ CI/CD Setup Complete:
├── .github/workflows/ci.yml (lint + test)
├── .github/workflows/release.yml (PyPI publish)
├── .github/dependabot.yml (dependency updates)
└── All configurations validated
```

## What You Learned

- Terminal Agent creates complete CI/CD configurations
- It follows best practices for the platform
- It handles multiple environments and matrix testing
- It sets up automated releases
