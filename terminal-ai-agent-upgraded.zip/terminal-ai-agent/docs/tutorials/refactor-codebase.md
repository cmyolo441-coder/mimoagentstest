# Tutorial: Refactor a Codebase

Walk through refactoring code with Terminal Agent.

## The Task

Refactor a monolithic authentication module into a clean, extensible architecture using the Strategy pattern.

## Step 1: Describe the Refactoring

```bash
terminal-agent run "Refactor src/auth.js to use the Strategy pattern. Currently it has a giant switch statement for different auth methods (local, OAuth, SAML). Extract each method into a separate strategy class with a common interface. Make it easy to add new auth methods."
```

## Step 2: Agent Analyzes

```
💭 Analysis:
The current auth.js has:
- 500+ lines in a single file
- Switch statement with 3 auth methods
- Duplicate validation logic
- Hard to add new methods

Plan:
1. Define AuthStrategy interface
2. Extract LocalStrategy
3. Extract OAuthStrategy
4. Extract SAMLStrategy
5. Create StrategyFactory
6. Refactor main auth module
7. Update imports
8. Run tests
```

## Step 3: The Refactoring

### New Structure

```
src/
├── auth/
│   ├── index.ts              # Main auth module
│   ├── strategy.ts           # Strategy interface
│   ├── strategies/
│   │   ├── local.ts          # Local email/password
│   │   ├── oauth.ts          # OAuth 2.0
│   │   └── saml.ts           # SAML SSO
│   └── factory.ts            # Strategy factory
```

### Strategy Interface

```typescript
// src/auth/strategy.ts
export interface AuthStrategy {
  authenticate(credentials: AuthCredentials): Promise<AuthResult>;
  validateCredentials(credentials: AuthCredentials): boolean;
}
```

### Strategy Factory

```typescript
// src/auth/factory.ts
export class AuthStrategyFactory {
  private strategies: Map<string, AuthStrategy> = new Map();

  register(method: string, strategy: AuthStrategy): void {
    this.strategies.set(method, strategy);
  }

  get(method: string): AuthStrategy {
    const strategy = this.strategies.get(method);
    if (!strategy) throw new Error(`Unknown auth method: ${method}`);
    return strategy;
  }
}
```

## Step 4: Verification

```
✅ Verification:
├── All existing tests pass
├── New strategy classes are properly typed
├── Factory correctly instantiates strategies
├── Adding new auth method requires only:
│   1. Create new strategy class
│   2. Register in factory
└── Code is now modular and testable
```

## What You Learned

- Terminal Agent understands design patterns
- It preserves existing functionality while improving structure
- It creates proper interfaces and abstractions
- It verifies nothing breaks during refactoring
