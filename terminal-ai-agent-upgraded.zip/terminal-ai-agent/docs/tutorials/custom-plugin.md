# Tutorial: Build a Custom Plugin

Walk through building a custom Terminal Agent plugin.

## The Task

Create a plugin that adds web scraping capabilities.

## Step 1: Describe the Plugin

```bash
terminal-agent run "Create a Terminal Agent plugin called 'web-scraper' that:
- Provides a 'scrape_url' tool to extract content from URLs
- Provides a 'extract_links' tool to get all links from a page
- Provides a 'take_screenshot' tool to capture page screenshots
- Has proper error handling and timeout support
- Includes tests and documentation"
```

## Step 2: Agent Creates Plugin

### Plugin Structure

```
web-scraper/
├── manifest.toml
├── __init__.py
├── main.py
├── tools.py
├── config.py
├── tests/
│   └── test_web_scraper.py
└── README.md
```

### manifest.toml

```toml
[plugin]
name = "web-scraper"
version = "1.0.0"
author = "Terminal Agent User"
description = "Web scraping tools for Terminal Agent"
license = "MIT"
requires_terminal_agent = ">=0.1.0"

[dependencies]
packages = ["requests", "beautifulsoup4", "playwright"]

[tools]
provides = ["scrape_url", "extract_links", "take_screenshot"]

[hooks]
before_tool = false
after_tool = false
```

### main.py

```python
from terminal_agent.plugins.api import PluginBase, PluginContext
from web_scraper.tools import WebScraperTools

class WebScraperPlugin(PluginBase):
    name = "web-scraper"
    version = "1.0.0"

    async def initialize(self, context: PluginContext) -> None:
        self.context = context
        self.tools = WebScraperTools(context)

        context.register_tool("scrape_url", self.tools.scrape_url)
        context.register_tool("extract_links", self.tools.extract_links)
        context.register_tool("take_screenshot", self.tools.take_screenshot)

    async def cleanup(self) -> None:
        await self.tools.close()
```

### tools.py

```python
import requests
from bs4 import BeautifulSoup

class WebScraperTools:
    def __init__(self, context):
        self.context = context
        self.timeout = context.get_config("web-scraper").get("timeout", 30)

    async def scrape_url(self, url: str, selector: str = None) -> str:
        """Scrape content from a URL.

        Args:
            url: The URL to scrape.
            selector: Optional CSS selector to extract specific elements.

        Returns:
            Extracted text content.
        """
        response = requests.get(url, timeout=self.timeout)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")

        if selector:
            elements = soup.select(selector)
            return "\n".join(el.get_text(strip=True) for el in elements)

        return soup.get_text(strip=True)

    async def extract_links(self, url: str, filter_domain: bool = True) -> list[dict]:
        """Extract all links from a URL.

        Args:
            url: The URL to extract links from.
            filter_domain: If True, only return links from the same domain.

        Returns:
            List of dicts with 'url' and 'text' keys.
        """
        response = requests.get(url, timeout=self.timeout)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")
        links = []

        for a in soup.find_all("a", href=True):
            link_url = a["href"]
            link_text = a.get_text(strip=True)

            if filter_domain and not link_url.startswith(("http://", "https://")):
                continue

            links.append({"url": link_url, "text": link_text})

        return links

    async def take_screenshot(self, url: str, output_path: str = None) -> str:
        """Take a screenshot of a webpage.

        Args:
            url: The URL to screenshot.
            output_path: Where to save the screenshot.

        Returns:
            Path to the saved screenshot.
        """
        from playwright.async_api import async_playwright

        async with async_playwright() as p:
            browser = await p.chromium.launch()
            page = await browser.new_page()
            await page.goto(url)
            await page.screenshot(path=output_path, full_page=True)
            await browser.close()

        return output_path or "screenshot.png"

    async def close(self) -> None:
        pass
```

## Step 3: Install and Test

```bash
# Install the plugin
terminal-agent plugins install ./web-scraper

# Validate
terminal-agent plugins validate web-scraper

# Test
terminal-agent plugins test web-scraper

# Use it
terminal-agent run "Scrape the content from https://example.com"
```

## What You Learned

- Plugins follow a standard structure
- They register tools via the PluginContext
- They can have their own configuration
- They include tests and documentation
- They're installed with a single command
