# Tutorial: Write Tests

Walk through generating comprehensive tests with Terminal Agent.

## The Task

Write tests for an existing UserService class.

## Step 1: Request Tests

```bash
terminal-agent run "Write comprehensive pytest tests for src/services/user.py. Cover:
- Create user (success, duplicate email, invalid data)
- Get user by ID (success, not found)
- Update user (success, not found, invalid data)
- Delete user (success, not found)
- List users (with pagination)
- Edge cases and error handling"
```

## Step 2: Agent Analyzes

```
💭 Analysis:
UserService has 6 methods. I need to:
1. Read the service code to understand interfaces
2. Create test fixtures (mock database, sample data)
3. Write tests for each method
4. Cover happy path, error cases, and edge cases
5. Run tests to verify they pass
```

## Step 3: Generated Tests

```python
# tests/test_user_service.py

import pytest
from unittest.mock import AsyncMock, MagicMock
from src.services.user import UserService
from src.models.user import User

@pytest.fixture
def mock_db():
    """Mock database session."""
    return AsyncMock()

@pytest.fixture
def service(mock_db):
    """Create UserService with mock database."""
    return UserService(db=mock_db)

@pytest.fixture
def sample_user():
    """Sample user data."""
    return {
        "email": "test@example.com",
        "name": "Test User",
        "password": "securepassword123",
    }

class TestUserService:
    async def test_create_user_success(self, service, mock_db, sample_user):
        """Test successful user creation."""
        mock_db.execute.return_value = None
        result = await service.create_user(**sample_user)
        assert result.email == sample_user["email"]
        mock_db.commit.assert_called_once()

    async def test_create_user_duplicate_email(self, service, mock_db, sample_user):
        """Test creating user with duplicate email."""
        mock_db.execute.side_effect = IntegrityError("duplicate")
        with pytest.raises(ValueError, match="already exists"):
            await service.create_user(**sample_user)

    async def test_create_user_invalid_email(self, service):
        """Test creating user with invalid email."""
        with pytest.raises(ValueError, match="Invalid email"):
            await service.create_user(email="not-an-email", name="Test")

    async def test_get_user_success(self, service, mock_db, sample_user):
        """Test getting user by ID."""
        mock_db.get.return_value = User(id=1, **sample_user)
        result = await service.get_user(1)
        assert result.id == 1

    async def test_get_user_not_found(self, service, mock_db):
        """Test getting non-existent user."""
        mock_db.get.return_value = None
        with pytest.raises(ValueError, match="not found"):
            await service.get_user(999)

    async def test_update_user_success(self, service, mock_db, sample_user):
        """Test updating user."""
        mock_db.get.return_value = User(id=1, **sample_user)
        result = await service.update_user(1, name="Updated")
        assert result.name == "Updated"

    async def test_delete_user_success(self, service, mock_db, sample_user):
        """Test deleting user."""
        mock_db.get.return_value = User(id=1, **sample_user)
        await service.delete_user(1)
        mock_db.delete.assert_called_once()

    async def test_list_users_pagination(self, service, mock_db):
        """Test listing users with pagination."""
        mock_db.execute.return_value = [User(id=i) for i in range(10)]
        result = await service.list_users(page=2, per_page=10)
        assert len(result) == 10

    async def test_list_users_empty(self, service, mock_db):
        """Test listing users when none exist."""
        mock_db.execute.return_value = []
        result = await service.list_users()
        assert result == []
```

## Step 4: Run Tests

```
🧪 Running tests...
tests/test_user_service::TestUserService::test_create_user_success        ✅ PASSED
tests/test_user_service::TestUserService::test_create_user_duplicate_email ✅ PASSED
tests/test_user_service::TestUserService::test_create_user_invalid_email  ✅ PASSED
tests/test_user_service::TestUserService::test_get_user_success           ✅ PASSED
tests/test_user_service::TestUserService::test_get_user_not_found         ✅ PASSED
tests/test_user_service::TestUserService::test_update_user_success        ✅ PASSED
tests/test_user_service::TestUserService::test_delete_user_success        ✅ PASSED
tests/test_user_service::TestUserService::test_list_users_pagination      ✅ PASSED
tests/test_user_service::TestUserService::test_list_users_empty           ✅ PASSED

9 passed in 0.23s
Coverage: 94%
```

## What You Learned

- Terminal Agent reads existing code to understand interfaces
- It generates comprehensive test suites automatically
- It uses appropriate mocking strategies
- It covers happy path, error cases, and edge cases
- Tests are immediately runnable
