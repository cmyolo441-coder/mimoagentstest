# Adding Memory Backends

This guide walks through adding a new vector store backend for long-term memory.

## Backend Architecture

Every backend implements the `MemoryBackend` interface and lives in `src/terminal_agent/support/vector_store/backends/`.

## Step 1: Create the Backend

```python
# src/terminal_agent/support/vector_store/backends/my_backend.py

from terminal_agent.support.vector_store.manager import MemoryBackend, MemoryEntry, SearchResult

class MyBackend(MemoryBackend):
    """Custom vector store backend."""

    name = "my_backend"

    def __init__(self, config: dict):
        self.config = config
        self.client = None

    async def initialize(self) -> None:
        """Initialize the backend."""
        # Connect to your vector store
        self.client = await connect_to_store(self.config)

    async def store(self, entry: MemoryEntry) -> str:
        """Store a memory entry.

        Args:
            entry: The memory entry to store.

        Returns:
            The entry ID.
        """
        entry_id = generate_id()
        await self.client.upsert(
            id=entry_id,
            vector=entry.embedding,
            metadata={
                "content": entry.content,
                "category": entry.category,
                "timestamp": entry.timestamp,
                "relevance": entry.relevance,
            },
        )
        return entry_id

    async def search(
        self,
        query_vector: list[float],
        limit: int = 5,
        category: str | None = None,
        min_relevance: float = 0.0,
    ) -> list[SearchResult]:
        """Search for similar memories.

        Args:
            query_vector: The query embedding vector.
            limit: Maximum results to return.
            category: Optional category filter.
            min_relevance: Minimum relevance score.

        Returns:
            List of SearchResult objects.
        """
        filters = {}
        if category:
            filters["category"] = category
        if min_relevance > 0:
            filters["relevance"] = {"$gte": min_relevance}

        results = await self.client.query(
            vector=query_vector,
            limit=limit,
            filter=filters if filters else None,
        )

        return [
            SearchResult(
                id=r["id"],
                content=r["metadata"]["content"],
                score=r["score"],
                metadata=r["metadata"],
            )
            for r in results
        ]

    async def delete(self, entry_id: str) -> bool:
        """Delete a memory entry."""
        try:
            await self.client.delete(entry_id)
            return True
        except Exception:
            return False

    async def update(self, entry_id: str, entry: MemoryEntry) -> bool:
        """Update an existing memory entry."""
        try:
            await self.client.upsert(
                id=entry_id,
                vector=entry.embedding,
                metadata={
                    "content": entry.content,
                    "category": entry.category,
                    "timestamp": entry.timestamp,
                    "relevance": entry.relevance,
                },
            )
            return True
        except Exception:
            return False

    async def count(self, category: str | None = None) -> int:
        """Count stored memories."""
        filters = {"category": category} if category else None
        return await self.client.count(filter=filters)

    async def clear(self, category: str | None = None) -> int:
        """Clear memories. Returns count deleted."""
        if category:
            ids = await self.client.list_ids(filter={"category": category})
        else:
            ids = await self.client.list_ids()
        for entry_id in ids:
            await self.client.delete(entry_id)
        return len(ids)

    async def close(self) -> None:
        """Close the backend connection."""
        if self.client:
            await self.client.close()
```

## Step 2: Register the Backend

```python
# src/terminal_agent/support/vector_store/backends/__init__.py

from terminal_agent.support.vector_store.backends.my_backend import MyBackend

BACKENDS = {
    "chroma": ChromaBackend,
    "faiss": FaissBackend,
    "pinecone": PineconeBackend,
    "qdrant": QdrantBackend,
    "memory": MemoryBackend,
    "my_backend": MyBackend,
}
```

## Step 3: Add Configuration

```toml
# In config.toml
[memory]
vector_backend = "my_backend"

[memory.my_backend]
host = "localhost"
port = 8080
api_key = "..."
collection = "terminal-agent"
```

## Step 4: Write Tests

```python
# tests/unit/test_support/test_vector_store/test_my_backend.py

import pytest
from terminal_agent.support.vector_store.backends.my_backend import MyBackend

class TestMyBackend:
    @pytest.fixture
    async def backend(self):
        backend = MyBackend({"host": "localhost", "port": 8080})
        await backend.initialize()
        yield backend
        await backend.close()

    async def test_store_and_search(self, backend):
        entry = MemoryEntry(
            content="Test memory",
            embedding=[0.1] * 1536,
            category="test",
            relevance=1.0,
        )
        entry_id = await backend.store(entry)
        assert entry_id

        results = await backend.search(query_vector=[0.1] * 1536, limit=1)
        assert len(results) > 0
        assert results[0].content == "Test memory"

    async def test_delete(self, backend):
        entry = MemoryEntry(
            content="To delete",
            embedding=[0.1] * 1536,
            category="test",
            relevance=1.0,
        )
        entry_id = await backend.store(entry)
        assert await backend.delete(entry_id)

    async def test_count(self, backend):
        count = await backend.count()
        assert isinstance(count, int)
```

## Best Practices

1. **Connection management** — Initialize lazily, close gracefully
2. **Error handling** — Never raise from memory operations
3. **Batch operations** — Support bulk insert/update/delete
4. **Filtering** — Support category and relevance filters
5. **Persistence** — Ensure data survives restarts
6. **Performance** — Use indexes for fast similarity search
7. **Testing** — Test with the in-memory backend first
