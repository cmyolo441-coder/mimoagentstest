# Plugin Development

Complete guide to building plugins for Terminal Agent.

## Plugin Structure

```
my-plugin/
├── manifest.toml        # Plugin metadata
├── __init__.py          # Package init
├── main.py              # Entry point
├── tools.py             # Tool definitions (optional)
├── config.py            # Configuration schema (optional)
├── tests/
│   └── test_my_plugin.py
└── README.md
```

## manifest.toml

```toml
[plugin]
name = "my-plugin"
version = "1.0.0"
author = "Your Name"
description = "What this plugin does"
license = "MIT"
requires_terminal_agent = ">=0.1.0"

[dependencies]
packages = ["requests", "beautifulsoup4"]

[tools]
provides = ["tool_name_1", "tool_name_2"]

[hooks]
before_tool = true
after_tool = true
on_error = true
```

## Plugin Base Class

```python
# main.py

from terminal_agent.plugins.api import PluginBase, PluginContext

class MyPlugin(PluginBase):
    """My custom plugin."""

    name = "my-plugin"
    version = "1.0.0"

    async def initialize(self, context: PluginContext) -> None:
        """Called when the plugin is loaded.

        Args:
            context: Plugin context with registration methods.
        """
        self.context = context

        # Register tools
        context.register_tool("my_tool_1", self.tool_1)
        context.register_tool("my_tool_2", self.tool_2)

        # Register hooks
        context.register_hook("before_tool", self.before_tool)
        context.register_hook("after_tool", self.after_tool)

        # Access configuration
        self.config = context.get_config("my-plugin")

    async def tool_1(self, param1: str, param2: int = 10) -> str:
        """First tool implementation."""
        # Your tool logic
        return f"Result: {param1} * {param2}"

    async def tool_2(self, data: dict) -> dict:
        """Second tool implementation."""
        return {"processed": True, "data": data}

    async def before_tool(self, tool_name: str, parameters: dict) -> dict:
        """Hook called before any tool executes.

        Args:
            tool_name: Name of the tool about to execute.
            parameters: Tool parameters.

        Returns:
            Modified parameters (or original if no changes).
        """
        # Example: Add authentication header to API calls
        if tool_name == "http_request":
            parameters["headers"] = parameters.get("headers", {})
            parameters["headers"]["Authorization"] = f"Bearer {self.config['api_key']}"
        return parameters

    async def after_tool(self, tool_name: str, parameters: dict, result: dict) -> dict:
        """Hook called after any tool executes.

        Args:
            tool_name: Name of the tool that executed.
            parameters: Tool parameters.
            result: Tool result.

        Returns:
            Modified result (or original if no changes).
        """
        # Example: Log all tool executions
        self.context.logger.info(f"Tool {tool_name} completed")
        return result

    async def on_error(self, tool_name: str, error: Exception) -> bool:
        """Hook called when a tool fails.

        Args:
            tool_name: Name of the tool that failed.
            error: The exception.

        Returns:
            True to suppress the error, False to propagate.
        """
        # Example: Suppress specific errors
        if "rate limit" in str(error).lower():
            self.context.logger.warning("Rate limit hit, suppressing error")
            return True
        return False

    async def cleanup(self) -> None:
        """Called when the plugin is unloaded."""
        # Clean up resources
        pass
```

## Plugin API Reference

### PluginContext

| Method | Description |
|--------|-------------|
| `register_tool(name, func)` | Register a new tool |
| `register_hook(event, func)` | Register a lifecycle hook |
| `get_config(plugin_name)` | Get plugin configuration |
| `logger` | Plugin logger instance |
| `data_dir` | Plugin data directory |

### Hooks

| Hook | When | Args | Return |
|------|------|------|--------|
| `before_tool` | Before tool execution | `tool_name, parameters` | Modified parameters |
| `after_tool` | After tool execution | `tool_name, parameters, result` | Modified result |
| `on_error` | On tool error | `tool_name, error` | `True` to suppress |
| `on_session_start` | Session begins | `session_id` | None |
| `on_session_end` | Session ends | `session_id, summary` | None |
| `on_plan_created` | Plan generated | `plan` | None |

## Configuration Schema

```python
# config.py

from pydantic import BaseModel

class PluginConfig(BaseModel):
    """Configuration schema for my-plugin."""
    api_key: str = ""
    max_results: int = 10
    timeout: int = 30
    enabled_features: list[str] = ["default"]
```

Users configure in `config.toml`:

```toml
[plugins.my-plugin]
api_key = "..."
max_results = 20
timeout = 60
```

## Testing

```python
# tests/test_my_plugin.py

import pytest
from my_plugin.main import MyPlugin
from terminal_agent.plugins.api import PluginContext

class TestMyPlugin:
    @pytest.fixture
    async def plugin(self):
        plugin = MyPlugin()
        context = PluginContext(config={})
        await plugin.initialize(context)
        return plugin

    async def test_tool_1(self, plugin):
        result = await plugin.tool_1("hello", param2=5)
        assert "hello" in result
        assert "5" in result

    async def test_tool_2(self, plugin):
        result = await plugin.tool_2({"key": "value"})
        assert result["processed"] is True

    async def test_before_tool_hook(self, plugin):
        params = {"url": "http://example.com", "headers": {}}
        modified = await plugin.before_tool("http_request", params)
        assert "Authorization" in modified["headers"]
```

## Publishing

```bash
# Validate
terminal-agent plugins validate ./my-plugin

# Publish to marketplace
terminal-agent plugins publish ./my-plugin
```

## Best Practices

1. **Single purpose** — Each plugin does one thing well
2. **Error handling** — Never let exceptions escape the plugin
3. **Configuration** — Make behavior configurable
4. **Documentation** — Include a README with usage examples
5. **Testing** — Write tests for all tools and hooks
6. **Versioning** — Follow semantic versioning
7. **Dependencies** — Minimize external dependencies
8. **Security** — Validate all inputs, don't store secrets in code
