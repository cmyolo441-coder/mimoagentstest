# Adding LLM Providers

This guide walks through adding a new LLM provider to Terminal Agent.

## Provider Architecture

Every provider implements the `BaseProvider` interface and lives in `src/terminal_agent/llm/providers/`.

## Step 1: Create the Provider File

```python
# src/terminal_agent/llm/providers/my_provider.py

import httpx
from terminal_agent.llm.base_provider import BaseProvider, LLMResponse, StreamChunk
from terminal_agent.config.schema import LLMConfig

class MyProvider(BaseProvider):
    """My custom LLM provider."""

    name = "my_provider"
    supported_models = ["my-model-1", "my-model-2"]

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self.api_key = config.api_key
        self.base_url = config.base_url or "https://api.myprovider.com/v1"
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=config.timeout or 120.0,
        )

    async def complete(self, messages: list[dict], **kwargs) -> LLMResponse:
        """Send a completion request.

        Args:
            messages: List of message dicts with 'role' and 'content'.
            **kwargs: Additional parameters (temperature, max_tokens, etc.)

        Returns:
            LLMResponse with the completion.
        """
        payload = {
            "model": kwargs.get("model", self.config.primary_model),
            "messages": messages,
            "temperature": kwargs.get("temperature", self.config.temperature),
            "max_tokens": kwargs.get("max_tokens", self.config.max_tokens),
        }

        # Add tool definitions if provided
        if "tools" in kwargs:
            payload["tools"] = kwargs["tools"]

        response = await self.client.post("/chat/completions", json=payload)
        response.raise_for_status()
        data = response.json()

        # Parse response
        choice = data["choices"][0]
        message = choice["message"]

        return LLMResponse(
            content=message.get("content", ""),
            tool_calls=self._parse_tool_calls(message.get("tool_calls", [])),
            tokens_in=data["usage"]["prompt_tokens"],
            tokens_out=data["usage"]["completion_tokens"],
            cost=self._calculate_cost(data["usage"]),
            model=data["model"],
            finish_reason=choice["finish_reason"],
        )

    async def stream(self, messages: list[dict], **kwargs):
        """Stream a completion response.

        Args:
            messages: List of message dicts.
            **kwargs: Additional parameters.

        Yields:
            StreamChunk objects as tokens arrive.
        """
        payload = {
            "model": kwargs.get("model", self.config.primary_model),
            "messages": messages,
            "temperature": kwargs.get("temperature", self.config.temperature),
            "max_tokens": kwargs.get("max_tokens", self.config.max_tokens),
            "stream": True,
        }

        async with self.client.stream("POST", "/chat/completions", json=payload) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if line.startswith("data: "):
                    data = line[6:]
                    if data == "[DONE]":
                        break
                    chunk = self._parse_stream_chunk(data)
                    if chunk:
                        yield chunk

    def _parse_tool_calls(self, tool_calls: list[dict]) -> list[dict]:
        """Parse tool calls from the response."""
        parsed = []
        for tc in tool_calls:
            parsed.append({
                "id": tc["id"],
                "name": tc["function"]["name"],
                "arguments": tc["function"]["arguments"],
            })
        return parsed

    def _parse_stream_chunk(self, data: str) -> StreamChunk | None:
        """Parse a streaming chunk."""
        import json
        try:
            chunk = json.loads(data)
            delta = chunk["choices"][0]["delta"]
            return StreamChunk(
                content=delta.get("content", ""),
                tool_calls=delta.get("tool_calls"),
                finish_reason=chunk["choices"][0].get("finish_reason"),
            )
        except (json.JSONDecodeError, KeyError, IndexError):
            return None

    def _calculate_cost(self, usage: dict) -> float:
        """Calculate the cost of a request."""
        # Define pricing per model
        pricing = {
            "my-model-1": {"input": 0.01, "output": 0.03},
            "my-model-2": {"input": 0.005, "output": 0.015},
        }
        model = usage.get("model", self.config.primary_model)
        rates = pricing.get(model, {"input": 0.01, "output": 0.03})
        input_cost = usage["prompt_tokens"] * rates["input"] / 1_000_000
        output_cost = usage["completion_tokens"] * rates["output"] / 1_000_000
        return input_cost + output_cost

    async def close(self) -> None:
        """Close the HTTP client."""
        await self.client.aclose()
```

## Step 2: Register the Provider

```python
# src/terminal_agent/llm/providers/__init__.py

from terminal_agent.llm.providers.my_provider import MyProvider

PROVIDERS = {
    "openai": OpenAIProvider,
    "anthropic": AnthropicProvider,
    "google": GoogleProvider,
    # ... existing providers ...
    "my_provider": MyProvider,
}
```

## Step 3: Add Configuration

Add provider-specific config to the schema:

```python
# src/terminal_agent/config/schema.py

class MyProviderConfig(BaseModel):
    api_key: str | None = None
    base_url: str = "https://api.myprovider.com/v1"
    custom_param: str = "default"
```

## Step 4: Write Tests

```python
# tests/unit/test_llm/test_providers/test_my_provider.py

import pytest
from unittest.mock import AsyncMock, patch
from terminal_agent.llm.providers.my_provider import MyProvider

class TestMyProvider:
    @pytest.fixture
    def provider(self, config):
        return MyProvider(config)

    async def test_complete(self, provider):
        with patch.object(provider.client, "post") as mock:
            mock.return_value = MockResponse(
                status_code=200,
                json={
                    "choices": [{"message": {"content": "Hello!"}}],
                    "usage": {"prompt_tokens": 10, "completion_tokens": 5},
                    "model": "my-model-1",
                },
            )
            response = await provider.complete([{"role": "user", "content": "Hi"}])
            assert response.content == "Hello!"
            assert response.tokens_in == 10

    async def test_stream(self, provider):
        # Test streaming
        ...
```

## Step 5: Handle Provider-Specific Features

### Function Calling

If your provider supports function calling:

```python
async def complete(self, messages, **kwargs):
    if "tools" in kwargs:
        payload["tools"] = [
            {
                "type": "function",
                "function": {
                    "name": tool["name"],
                    "description": tool["description"],
                    "parameters": tool["schema"],
                },
            }
            for tool in kwargs["tools"]
        ]
```

### Vision/Multimodal

If your provider supports images:

```python
async def complete_with_image(self, messages, images, **kwargs):
    # Format messages with image content
    formatted = []
    for msg in messages:
        if msg["role"] == "user":
            content = [{"type": "text", "text": msg["content"]}]
            for img in images:
                content.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{img}"},
                })
            formatted.append({"role": "user", "content": content})
        else:
            formatted.append(msg)
    return await self.complete(formatted, **kwargs)
```

## Best Practices

1. **Error handling** — Map provider errors to standard error types
2. **Rate limiting** — Respect provider rate limits
3. **Retries** — Implement exponential backoff for transient errors
4. **Timeouts** — Use appropriate timeouts for requests
5. **Streaming** — Implement streaming for better UX
6. **Cost tracking** — Calculate and report costs accurately
7. **Token counting** — Report token usage accurately
8. **Cleanup** — Close HTTP clients properly
