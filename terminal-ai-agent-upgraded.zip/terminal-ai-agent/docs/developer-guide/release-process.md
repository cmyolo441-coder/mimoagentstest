# Release Process

How Terminal Agent releases are made.

## Release Schedule

| Version | Type | Cadence |
|---------|------|---------|
| Patch (0.1.x) | Bug fixes | As needed |
| Minor (0.x.0) | Features | Monthly |
| Major (x.0.0) | Breaking changes | Quarterly |

## Release Checklist

### Pre-Release

- [ ] All tests pass (`make test`)
- [ ] Linter passes (`make lint`)
- [ ] Type checker passes (`make type-check`)
- [ ] Coverage meets threshold (>90%)
- [ ] Documentation is updated
- [ ] CHANGELOG.md is updated
- [ ] Version is bumped in `pyproject.toml` and `version.py`
- [ ] Security audit passes (`make check-security`)
- [ ] Performance benchmarks pass

### Creating a Release

1. **Create a release branch:**
   ```bash
   git checkout -b release/v0.2.0
   ```

2. **Update version:**
   ```bash
   # pyproject.toml
   version = "0.2.0"
   
   # src/terminal_agent/version.py
   __version__ = "0.2.0"
   ```

3. **Update CHANGELOG.md:**
   - Move items from [Unreleased] to the new version
   - Add the release date
   - Update comparison links

4. **Run full test suite:**
   ```bash
   make test
   make lint
   make type-check
   make check-security
   ```

5. **Commit and push:**
   ```bash
   git add .
   git commit -m "chore: release v0.2.0"
   git push origin release/v0.2.0
   ```

6. **Create a Pull Request:**
   - Title: "Release v0.2.0"
   - Description: Link to CHANGELOG, highlight key changes
   - Wait for CI to pass
   - Get approval from maintainers

7. **Merge to main:**
   ```bash
   git checkout main
   git merge release/v0.2.0
   git push origin main
   ```

8. **Tag the release:**
   ```bash
   git tag -a v0.2.0 -m "Release v0.2.0"
   git push origin v0.2.0
   ```

9. **Create GitHub Release:**
   - Go to GitHub → Releases → New Release
   - Tag: v0.2.0
   - Title: "Terminal Agent v0.2.0"
   - Description: Copy from CHANGELOG.md
   - Upload assets (if any)

10. **Publish to PyPI:**
    ```bash
    make build
    make publish
    ```

### Post-Release

- [ ] Verify PyPI package is published
- [ ] Verify Docker image is built
- [ ] Verify documentation is updated
- [ ] Announce on social media
- [ ] Close related issues
- [ ] Delete the release branch

## CI/CD Pipeline

### On Every Push

1. Lint (Ruff)
2. Type check (MyPy)
3. Unit tests
4. Integration tests
5. Coverage report

### On Pull Request

1. All of the above
2. E2E tests
3. Security scan
4. Performance benchmarks

### On Tag (Release)

1. All of the above
2. Build package
3. Build Docker image
4. Publish to PyPI
5. Push Docker image
6. Create GitHub Release

## Hotfix Process

For critical bugs in released versions:

1. **Create hotfix branch from tag:**
   ```bash
   git checkout -b hotfix/v0.2.1 v0.2.0
   ```

2. **Fix the bug:**
   ```bash
   # Make changes
   git add .
   git commit -m "fix: critical bug description"
   ```

3. **Bump patch version:**
   ```bash
   # Update version to 0.2.1
   ```

4. **Test and release:**
   ```bash
   make test
   git tag -a v0.2.1 -m "Hotfix v0.2.1"
   git push origin v0.2.1
   ```

5. **Cherry-pick to main:**
   ```bash
   git checkout main
   git cherry-pick <hotfix-commit>
   git push origin main
   ```

## Version Scheme

Terminal Agent follows [Semantic Versioning](https://semver.org/):

- **MAJOR** — Incompatible API changes
- **MINOR** — New functionality (backwards compatible)
- **PATCH** — Bug fixes (backwards compatible)

Pre-release versions:
- `0.1.0a1` — Alpha
- `0.1.0b1` — Beta
- `0.1.0rc1` — Release candidate

## Release Automation

The release process is automated via GitHub Actions:

```yaml
# .github/workflows/release.yml
name: Release
on:
  push:
    tags:
      - 'v*'

jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - name: Build
        run: make build
      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
      - name: Create GitHub Release
        uses: softprops/action-gh-release@v1
```
