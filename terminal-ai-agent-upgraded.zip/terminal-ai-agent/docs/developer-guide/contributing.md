# Contributing (Developer)

This guide covers the technical details of contributing to Terminal Agent.

## Development Workflow

### 1. Fork and Clone

```bash
git clone https://github.com/YOUR_USERNAME/terminal-agent.git
cd terminal-agent
git remote add upstream https://github.com/terminal-agent/terminal-agent.git
```

### 2. Set Up Development Environment

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pre-commit install
```

### 3. Create a Branch

```bash
git checkout -b feature/my-feature
```

### 4. Make Changes

- Write code following our [Coding Standards](#coding-standards)
- Add tests for new functionality
- Update documentation if needed

### 5. Run Checks

```bash
make lint        # Linting
make type-check  # Type checking
make test        # Tests
make format      # Auto-format
```

### 6. Commit

```bash
git add .
git commit -m "feat(scope): description"
```

### 7. Push and PR

```bash
git push origin feature/my-feature
```

Then open a pull request on GitHub.

## Coding Standards

### Python Style

- **Formatter**: Ruff
- **Line length**: 100
- **Target**: Python 3.10
- **Type hints**: Required (mypy strict)
- **Docstrings**: Google style

### Imports

```python
# Standard library
import os
import sys
from pathlib import Path
from typing import Any, Optional

# Third-party
import pytest
from pydantic import BaseModel

# Local
from terminal_agent.tools.base_tool import BaseTool
from terminal_agent.tools.result import ToolResult
```

### Type Hints

```python
# Use modern syntax (Python 3.10+)
def process(items: list[str], config: dict[str, Any]) -> tuple[bool, str]:
    ...

# Optional
def get_name(user_id: int) -> str | None:
    ...
```

### Docstrings

```python
async def execute_tool(
    tool_name: str,
    parameters: dict[str, Any],
    timeout: float = 300.0,
) -> ToolResult:
    """Execute a tool by name with the given parameters.

    Args:
        tool_name: The registered name of the tool to execute.
        parameters: Parameters to pass to the tool.
        timeout: Maximum execution time in seconds.

    Returns:
        A ToolResult containing the output, exit code, and metadata.

    Raises:
        ToolNotFoundError: If the tool is not registered.
        ToolExecutionError: If the tool fails to execute.
        SafetyViolationError: If the tool call is blocked by safety rules.
    """
    ...
```

### Commit Messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
type(scope): description

[optional body]

[optional footer(s)]
```

Types:
- `feat` — New feature
- `fix` — Bug fix
- `docs` — Documentation
- `style` — Formatting (no code change)
- `refactor` — Code refactoring
- `test` — Tests
- `perf` — Performance
- `ci` — CI/CD
- `chore` — Maintenance

Examples:
```
feat(tools): add database migration tool
fix(memory): prevent duplicate memory entries
docs(api): update tool API reference
test(git): add integration tests for merge conflicts
```

## Code Review Process

### What Reviewers Look For

1. **Correctness** — Does the code work as intended?
2. **Tests** — Are there adequate tests?
3. **Style** — Does it follow coding standards?
4. **Documentation** — Are public APIs documented?
5. **Performance** — Are there obvious performance issues?
6. **Security** — Are there security concerns?
7. **Error handling** — Are errors handled gracefully?

### Addressing Feedback

1. Read the feedback carefully
2. Ask questions if something is unclear
3. Make requested changes
4. Push new commits (don't force-push during review)
5. Mark conversations as resolved

## Pull Request Template

```markdown
## Description
Brief description of changes.

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Unit tests added/updated
- [ ] Integration tests added/updated
- [ ] All tests pass

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
- [ ] CHANGELOG.md updated
```

## Issue Labels

| Label | Meaning |
|-------|---------|
| `bug` | Something isn't working |
| `enhancement` | New feature or improvement |
| `documentation` | Documentation needs update |
| `good first issue` | Good for newcomers |
| `help wanted` | Extra attention needed |
| `priority: high` | Urgent fix needed |
| `priority: low` | Nice to have |
