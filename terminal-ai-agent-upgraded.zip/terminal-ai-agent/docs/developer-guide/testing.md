# Testing

Guide for running and writing tests for Terminal Agent.

## Test Structure

```
tests/
├── conftest.py              # Shared fixtures
├── fixtures/                # Test data
│   ├── sample_projects/     # Sample project structures
│   ├── sample_files/        # Sample files
│   ├── sample_configs/      # Sample configurations
│   ├── sample_responses/    # LLM response fixtures
│   └── mock_servers/        # Mock API servers
├── unit/                    # Unit tests
├── integration/             # Integration tests
├── e2e/                     # End-to-end tests
├── chaos/                   # Chaos tests
├── performance/             # Performance tests
├── regression/              # Regression tests
└── benchmarks/              # Benchmarks
```

## Running Tests

### All Tests

```bash
make test
```

### Unit Tests

```bash
make test-unit
# or
pytest tests/unit/ -v
```

### Integration Tests

```bash
make test-integration
# or
pytest tests/integration/ -v
```

### End-to-End Tests

```bash
make test-e2e
# or
pytest tests/e2e/ -v
```

### With Coverage

```bash
make test-cov
# or
pytest --cov=terminal_agent --cov-report=html
```

### Specific Tests

```bash
# Specific file
pytest tests/unit/test_tools/test_filesystem/test_read.py

# Specific class
pytest tests/unit/test_tools/test_filesystem/test_read.py::TestReadFileTool

# Specific test
pytest tests/unit/test_tools/test_filesystem/test_read.py::TestReadFileTool::test_read_existing_file

# Pattern matching
pytest -k "test_read" -v
```

### Markers

```bash
# Run only unit tests
pytest -m unit

# Run only integration tests
pytest -m integration

# Skip slow tests
pytest -m "not slow"
```

## Writing Tests

### Unit Test Example

```python
import pytest
from terminal_agent.tools.filesystem.read import ReadFileTool

class TestReadFileTool:
    """Tests for the ReadFileTool."""

    @pytest.fixture
    def tool(self):
        """Create a ReadFileTool instance."""
        return ReadFileTool()

    async def test_read_existing_file(self, tool, tmp_path):
        """Test reading a file that exists."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello, World!")

        result = await tool.execute(path=str(test_file))

        assert result.exit_code == 0
        assert result.output == "Hello, World!"

    async def test_read_nonexistent_file(self, tool, tmp_path):
        """Test reading a file that does not exist."""
        result = await tool.execute(path=str(tmp_path / "missing.txt"))

        assert result.exit_code != 0
        assert "not found" in result.error.lower()

    @pytest.mark.parametrize("content", [
        "",
        "a" * 1000000,
        "Unicode: 你好世界 🌍",
        "Special: \n\t\r\0",
    ])
    async def test_read_various_content(self, tool, tmp_path, content):
        """Test reading files with various content types."""
        test_file = tmp_path / "test.txt"
        test_file.write_text(content)

        result = await tool.execute(path=str(test_file))

        assert result.exit_code == 0
        assert result.output == content
```

### Integration Test Example

```python
import pytest
from terminal_agent.tools.registry import ToolRegistry
from terminal_agent.tools.filesystem.read import ReadFileTool
from terminal_agent.tools.filesystem.write import WriteFileTool

class TestFileOperations:
    """Integration tests for file operations."""

    @pytest.fixture
    def registry(self):
        """Create a tool registry with filesystem tools."""
        registry = ToolRegistry()
        registry.register(ReadFileTool())
        registry.register(WriteFileTool())
        return registry

    async def test_write_then_read(self, registry, tmp_path):
        """Test writing a file and then reading it back."""
        test_file = tmp_path / "test.txt"

        # Write
        write_result = await registry.execute(
            "write_file",
            path=str(test_file),
            content="Hello, World!"
        )
        assert write_result.exit_code == 0

        # Read
        read_result = await registry.execute(
            "read_file",
            path=str(test_file)
        )
        assert read_result.exit_code == 0
        assert read_result.output == "Hello, World!"
```

### Using Fixtures

```python
# conftest.py
@pytest.fixture
def sample_project(tmp_path):
    """Create a sample project for testing."""
    project = tmp_path / "my-project"
    project.mkdir()
    (project / "src").mkdir()
    (project / "src" / "main.py").write_text("print('hello')")
    (project / "requirements.txt").write_text("flask==2.0.0")
    return project

@pytest.fixture
def mock_llm():
    """Create a mock LLM provider."""
    class MockProvider:
        async def complete(self, messages, **kwargs):
            return LLMResponse(
                content="Mock response",
                tool_calls=[],
                tokens_in=100,
                tokens_out=50,
            )
    return MockProvider()
```

### Async Tests

```python
import pytest

@pytest.mark.asyncio
async def test_async_operation():
    """Test an async operation."""
    result = await some_async_function()
    assert result == expected
```

## Mocking

### Mock LLM Responses

```python
from unittest.mock import AsyncMock, patch

@patch("terminal_agent.llm.engine.LLMEngine.complete")
async def test_with_mock_llm(mock_complete):
    mock_complete.return_value = LLMResponse(
        content="mocked response",
        tool_calls=[],
    )
    # Test code here
```

### Mock External Services

```python
@pytest.fixture
def mock_openai():
    with patch("httpx.AsyncClient.post") as mock:
        mock.return_value = MockResponse(
            status_code=200,
            json={"choices": [{"message": {"content": "test"}}]}
        )
        yield mock
```

## Performance Tests

```python
import time
import pytest

@pytest.mark.performance
async def test_tool_latency():
    """Verify tool execution latency is within bounds."""
    tool = ReadFileTool()

    start = time.monotonic()
    for _ in range(100):
        await tool.execute(path="/dev/null")
    elapsed = time.monotonic() - start

    assert elapsed < 1.0  # 100 calls in under 1 second
```

## Chaos Tests

```python
@pytest.mark.chaos
async def test_llm_timeout_recovery():
    """Test recovery when LLM times out."""
    # Simulate timeout
    with patch("terminal_agent.llm.engine.LLMEngine.complete") as mock:
        mock.side_effect = TimeoutError("Request timed out")

        # Verify recovery
        result = await orchestrator.run("test task")
        assert result.status == "recovered"
```

## CI/CD

Tests run automatically on:
- Every push to a branch
- Every pull request
- Nightly (full suite including chaos and performance)

See `.github/workflows/tests.yml` for the CI configuration.
