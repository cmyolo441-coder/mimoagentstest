# MCP Development

Guide for developing MCP (Model Context Protocol) clients and servers with Terminal Agent.

## MCP Overview

The Model Context Protocol enables:
- **Client** — Terminal Agent connects to external MCP servers
- **Server** — Terminal Agent exposes its tools via MCP

## Building an MCP Server

### Basic Server

```python
# my_mcp_server.py

from terminal_agent.mcp.server import MCPServer, ToolDefinition

server = MCPServer(name="my-tools", version="1.0.0")

@server.tool("greet")
async def greet(name: str) -> str:
    """Greet someone by name.

    Args:
        name: The name to greet.

    Returns:
        A greeting message.
    """
    return f"Hello, {name}!"

@server.tool("calculate")
async def calculate(expression: str) -> float:
    """Evaluate a mathematical expression.

    Args:
        expression: Math expression to evaluate.

    Returns:
        The result of the calculation.
    """
    return eval(expression)  # In production, use a safe evaluator

@server.tool("read_data")
async def read_data(path: str, format: str = "json") -> dict:
    """Read data from a file.

    Args:
        path: File path to read.
        format: Data format (json, csv, yaml).

    Returns:
        Parsed data.
    """
    import json
    with open(path) as f:
        if format == "json":
            return json.load(f)
        # Handle other formats...

if __name__ == "__main__":
    server.run(port=8080)
```

### Server with Authentication

```python
from terminal_agent.mcp.server import MCPServer, AuthConfig

server = MCPServer(
    name="my-tools",
    auth=AuthConfig(
        type="token",
        token="my-secret-token",
    ),
)

@server.tool("secure_tool")
async def secure_tool(data: str) -> str:
    """A tool that requires authentication."""
    return f"Processed: {data}"

server.run(port=8080)
```

### Server Configuration

```python
server = MCPServer(
    name="my-tools",
    version="1.0.0",
    description="Custom tools for Terminal Agent",
    rate_limit=60,  # requests per minute
    max_connections=10,
)
```

## Building an MCP Client

### Basic Client

```python
from terminal_agent.mcp.client import MCPClient

async def main():
    client = MCPClient(url="http://localhost:8080")

    # List available tools
    tools = await client.list_tools()
    for tool in tools:
        print(f"{tool.name}: {tool.description}")

    # Call a tool
    result = await client.call_tool("greet", {"name": "World"})
    print(result)  # "Hello, World!"

    await client.close()
```

### Client with Authentication

```python
client = MCPClient(
    url="http://localhost:8080",
    token="my-secret-token",
)
```

### Client with Retry

```python
client = MCPClient(
    url="http://localhost:8080",
    timeout=30,
    retries=3,
    retry_delay=1.0,
)
```

## Registering MCP Tools with Terminal Agent

### Via Configuration

```toml
[[mcp.servers]]
name = "my-tools"
url = "http://localhost:8080"
token = "my-secret-token"
prefix = "my"  # Tools will be named "my.greet", "my.calculate"
```

### Via CLI

```bash
terminal-agent mcp add http://localhost:8080 --name my-tools --token "my-secret"
```

## Protocol Details

### Tool Discovery

Request:
```json
{
  "jsonrpc": "2.0",
  "method": "tools/list",
  "id": 1
}
```

Response:
```json
{
  "jsonrpc": "2.0",
  "result": {
    "tools": [
      {
        "name": "greet",
        "description": "Greet someone by name",
        "inputSchema": {
          "type": "object",
          "properties": {
            "name": {"type": "string"}
          },
          "required": ["name"]
        }
      }
    ]
  },
  "id": 1
}
```

### Tool Execution

Request:
```json
{
  "jsonrpc": "2.0",
  "method": "tools/call",
  "params": {
    "name": "greet",
    "arguments": {"name": "World"}
  },
  "id": 2
}
```

Response:
```json
{
  "jsonrpc": "2.0",
  "result": {
    "content": [{"type": "text", "text": "Hello, World!"}],
    "isError": false
  },
  "id": 2
}
```

## Testing MCP Servers

```python
import pytest
from terminal_agent.mcp.client import MCPClient

@pytest.fixture
async def server():
    """Start a test server."""
    server = create_test_server()
    await server.start(port=8081)
    yield server
    await server.stop()

@pytest.fixture
async def client(server):
    """Create a test client."""
    client = MCPClient(url="http://localhost:8081")
    yield client
    await client.close()

async def test_list_tools(client):
    tools = await client.list_tools()
    assert len(tools) > 0
    assert any(t.name == "greet" for t in tools)

async def test_call_tool(client):
    result = await client.call_tool("greet", {"name": "World"})
    assert "Hello, World!" in str(result)

async def test_invalid_tool(client):
    with pytest.raises(ToolNotFoundError):
        await client.call_tool("nonexistent", {})
```

## Best Practices

1. **Schema validation** — Define clear input schemas for all tools
2. **Error handling** — Return meaningful error messages
3. **Authentication** — Always use auth in production
4. **Rate limiting** — Protect against abuse
5. **Timeouts** — Set appropriate timeouts for long-running tools
6. **Logging** — Log all tool calls for debugging
7. **Versioning** — Version your MCP server for compatibility
