# Architecture Overview (Developer)

This document describes Terminal Agent's architecture for developers who want to understand, contribute to, or extend the codebase.

## Source Structure

```
src/terminal_agent/
├── __init__.py              # Package init, version
├── __main__.py              # Entry point
├── version.py               # Version info
├── constants.py             # Global constants
├── exceptions.py            # Exception hierarchy
├── types.py                 # Type definitions
├── logging_config.py        # Logging setup
│
├── cli/                     # CLI layer
│   ├── app.py               # Main CLI app
│   ├── parser.py            # Argument parser
│   ├── commands/            # Subcommands
│   ├── completions/         # Shell completions
│   └── output.py            # Output formatting
│
├── tui/                     # TUI layer
│   ├── app.py               # TUI app
│   ├── themes/              # Color themes
│   ├── screens/             # UI screens
│   ├── widgets/             # UI components
│   ├── layouts/             # Layout managers
│   └── keybindings.py       # Keyboard shortcuts
│
├── config/                  # Configuration
│   ├── manager.py           # Config manager
│   ├── schema.py            # Config schema
│   ├── defaults.py          # Default values
│   ├── merger.py            # Config merging
│   ├── validator.py         # Validation
│   ├── encryption.py        # Secret encryption
│   ├── watcher.py           # File watching
│   └── profiles.py          # Config profiles
│
├── llm/                     # LLM engine
│   ├── engine.py            # Main engine
│   ├── base_provider.py     # Provider interface
│   ├── response_parser.py   # Response parsing
│   ├── token_counter.py     # Token counting
│   ├── cost_tracker.py      # Cost tracking
│   ├── providers/           # Provider implementations
│   ├── formats/             # Message formats
│   └── fallback.py          # Fallback chain
│
├── memory/                  # Memory system
│   ├── engine.py            # Memory engine
│   ├── short_term.py        # Conversation memory
│   ├── working_memory.py    # Active state
│   ├── long_term.py         # Persistent memory
│   ├── consolidator.py      # Memory consolidation
│   ├── compressor.py        # Memory compression
│   ├── embedder.py          # Embedding generation
│   ├── retriever.py         # Memory retrieval
│   └── categories/          # Memory categories
│
├── orchestrator/            # Agent orchestration
│   ├── core.py              # Core loop
│   ├── planner.py           # Plan generation
│   ├── executor.py          # Plan execution
│   ├── monitor.py           # Progress monitoring
│   ├── re_planner.py        # Re-planning
│   ├── session_manager.py   # Session lifecycle
│   └── parallel_executor.py # Parallel execution
│
├── context/                 # Context management
│   ├── manager.py           # Context manager
│   ├── assembler.py         # Context assembly
│   ├── compressor.py        # Context compression
│   └── token_budget.py      # Token budgeting
│
├── prompts/                 # Prompt management
│   ├── manager.py           # Prompt manager
│   ├── constructor.py       # Prompt construction
│   ├── optimizer.py         # Prompt optimization
│   └── templates/           # Prompt templates
│
├── tools/                   # Tool system
│   ├── registry.py          # Tool registry
│   ├── dispatcher.py        # Tool dispatcher
│   ├── base_tool.py         # Tool base class
│   ├── result.py            # Result types
│   ├── shell/               # Shell tools
│   ├── filesystem/          # Filesystem tools
│   ├── code/                # Code tools
│   ├── git/                 # Git tools
│   ├── package_manager/     # Package tools
│   ├── database/            # Database tools
│   ├── docker/              # Docker tools
│   ├── network/             # Network tools
│   ├── search/              # Search tools
│   ├── testing/             # Testing tools
│   ├── code_generation/     # Generation tools
│   ├── documentation/       # Doc tools
│   └── devops/              # DevOps tools
│
├── support/                 # Support systems
│   ├── safety/              # Safety guardrails
│   ├── verification/        # Verification engine
│   ├── self_improvement/    # Self-improvement
│   ├── error_recovery/      # Error recovery
│   ├── persistence/         # Database
│   ├── cache/               # Caching
│   ├── vector_store/        # Vector store
│   ├── logging/             # Logging
│   ├── tracing/             # Tracing
│   ├── metrics/             # Metrics
│   ├── rate_limiter/        # Rate limiting
│   ├── diff/                # Diff engine
│   └── notification/        # Notifications
│
├── plugins/                 # Plugin system
├── mcp/                     # MCP client/server
├── project/                 # Project analysis
└── utils/                   # Utility functions
```

## Key Abstractions

### Tool Interface

Every tool implements the `BaseTool` interface:

```python
from terminal_agent.tools.base_tool import BaseTool
from terminal_agent.tools.result import ToolResult

class MyTool(BaseTool):
    name = "my_tool"
    description = "Does something useful"
    category = "custom"
    safety_level = "moderate"  # safe, moderate, destructive, dangerous

    async def execute(self, **parameters) -> ToolResult:
        """Execute the tool with given parameters."""
        # Implementation
        return ToolResult(
            output="result",
            exit_code=0,
            duration=0.5,
        )

    def get_schema(self) -> dict:
        """Return the parameter schema for this tool."""
        return {
            "type": "object",
            "properties": {
                "param1": {"type": "string", "description": "First parameter"},
            },
            "required": ["param1"],
        }
```

### Provider Interface

Every LLM provider implements the `BaseProvider` interface:

```python
from terminal_agent.llm.base_provider import BaseProvider, LLMResponse

class MyProvider(BaseProvider):
    name = "my_provider"

    async def complete(self, messages: list[dict], **kwargs) -> LLMResponse:
        """Send a completion request."""
        # Implementation
        return LLMResponse(
            content="response text",
            tool_calls=[],
            tokens_in=100,
            tokens_out=50,
            cost=0.001,
        )

    async def stream(self, messages: list[dict], **kwargs):
        """Stream a completion response."""
        # Implementation
        yield "token1"
        yield "token2"
```

### Memory Backend Interface

Every memory backend implements the `MemoryBackend` interface:

```python
from terminal_agent.memory.long_term import MemoryBackend, MemoryEntry

class MyBackend(MemoryBackend):
    async def store(self, entry: MemoryEntry) -> str:
        """Store a memory entry. Returns entry ID."""
        ...

    async def search(self, query: str, limit: int = 5) -> list[MemoryEntry]:
        """Search for relevant memories."""
        ...

    async def delete(self, entry_id: str) -> bool:
        """Delete a memory entry."""
        ...
```

## Data Flow

```
User → CLI/TUI → Orchestrator → Context Manager → LLM Engine
                                              ↓
                                    Prompt Manager
                                              ↓
                                    LLM Provider (API)
                                              ↓
                                    Response Parser
                                              ↓
                                    Safety Check
                                              ↓
                                    Tool Dispatcher
                                              ↓
                                    Tool Execution
                                              ↓
                                    Verification
                                              ↓
                                    Memory Update
                                              ↓
                                    Progress Check
                                              ↓
                              Loop or Complete → User
```

## Concurrency Model

Terminal Agent uses Python's `asyncio` for concurrent operations:

- **LLM calls** — Async HTTP requests
- **Tool execution** — Async with timeouts
- **Memory operations** — Async database queries
- **Parallel steps** — `asyncio.gather` for independent tasks

## Error Handling

The exception hierarchy:

```python
TerminalAgentError           # Base exception
├── ConfigError              # Configuration issues
├── LLMError                 # LLM provider errors
│   ├── ProviderError        # Provider-specific error
│   ├── RateLimitError       # Rate limit exceeded
│   ├── TimeoutError         # Request timeout
│   └── AuthenticationError  # Auth failure
├── ToolError                # Tool execution errors
│   ├── ToolNotFoundError    # Tool not registered
│   ├── ToolExecutionError   # Tool failed
│   └── SafetyViolationError # Safety check failed
├── MemoryError              # Memory system errors
├── OrchestratorError        # Orchestration errors
└── PluginError              # Plugin errors
```

## Testing Strategy

- **Unit tests** — Test each module in isolation
- **Integration tests** — Test module interactions
- **E2E tests** — Test complete workflows
- **Chaos tests** — Test failure scenarios
- **Performance tests** — Measure latency and throughput

See [Testing](testing.md) for details.
