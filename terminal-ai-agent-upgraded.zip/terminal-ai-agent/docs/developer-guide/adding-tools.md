# Adding Tools

This guide walks through creating a new tool for Terminal Agent.

## Tool Architecture

Every tool implements the `BaseTool` interface and lives in `src/terminal_agent/tools/<category>/`.

## Step 1: Create the Tool File

Create a new file in the appropriate category:

```python
# src/terminal_agent/tools/my_category/my_tool.py

from terminal_agent.tools.base_tool import BaseTool
from terminal_agent.tools.result import ToolResult

class MyTool(BaseTool):
    """Tool that does something useful."""

    name = "my_tool"
    description = "Does something useful with the given input"
    category = "my_category"
    safety_level = "moderate"  # safe, moderate, destructive, dangerous

    async def execute(self, input_text: str, option: bool = False) -> ToolResult:
        """Execute the tool.

        Args:
            input_text: The text to process.
            option: An optional flag.

        Returns:
            ToolResult with the output.
        """
        try:
            # Your tool logic here
            result = process(input_text, option)

            return ToolResult(
                output=result,
                exit_code=0,
                duration=0.0,
            )
        except Exception as e:
            return ToolResult(
                output="",
                exit_code=1,
                error=str(e),
                duration=0.0,
            )

    def get_schema(self) -> dict:
        """Return the JSON Schema for this tool's parameters."""
        return {
            "type": "object",
            "properties": {
                "input_text": {
                    "type": "string",
                    "description": "The text to process",
                },
                "option": {
                    "type": "boolean",
                    "description": "An optional flag",
                    "default": False,
                },
            },
            "required": ["input_text"],
        }
```

## Step 2: Register the Tool

Add the tool to the category's `__init__.py`:

```python
# src/terminal_agent/tools/my_category/__init__.py

from terminal_agent.tools.my_category.my_tool import MyTool

__all__ = ["MyTool"]
```

Register in the tool registry:

```python
# src/terminal_agent/tools/registry.py

from terminal_agent.tools.my_category import MyTool

def register_default_tools(registry: ToolRegistry) -> None:
    # ... existing tools ...
    registry.register(MyTool())
```

## Step 3: Write Tests

```python
# tests/unit/test_tools/test_my_category/test_my_tool.py

import pytest
from terminal_agent.tools.my_category.my_tool import MyTool

class TestMyTool:
    @pytest.fixture
    def tool(self):
        return MyTool()

    async def test_basic_execution(self, tool):
        result = await tool.execute(input_text="hello")
        assert result.exit_code == 0
        assert "processed" in result.output.lower()

    async def test_with_option(self, tool):
        result = await tool.execute(input_text="hello", option=True)
        assert result.exit_code == 0

    async def test_error_handling(self, tool):
        result = await tool.execute(input_text="")
        assert result.exit_code != 0

    def test_schema(self, tool):
        schema = tool.get_schema()
        assert "input_text" in schema["properties"]
        assert "input_text" in schema["required"]
```

## Step 4: Add Safety Classification

Classify your tool's safety level:

- **safe** — Read-only, no side effects (e.g., `read_file`, `search`)
- **moderate** — Write operations with backup (e.g., `write_file`, `edit_file`)
- **destructive** — Irreversible operations (e.g., `delete_file`, `drop_table`)
- **dangerous** — System-level operations (e.g., `execute_command`)

```python
class MyTool(BaseTool):
    safety_level = "moderate"
```

## Step 5: Add Verification

Optionally add verification logic:

```python
class MyTool(BaseTool):
    async def verify(self, result: ToolResult) -> bool:
        """Verify the tool's output is correct."""
        if result.exit_code != 0:
            return False
        # Add custom verification
        return True
```

## Step 6: Update Documentation

Add your tool to the [Tool Reference](../user-guide/tool-reference.md).

## Complete Example

Here's a complete tool that fetches weather data:

```python
# src/terminal_agent/tools/network/weather.py

import httpx
from terminal_agent.tools.base_tool import BaseTool
from terminal_agent.tools.result import ToolResult

class WeatherTool(BaseTool):
    """Fetch current weather for a city."""

    name = "get_weather"
    description = "Get current weather for a specified city"
    category = "network"
    safety_level = "safe"

    async def execute(self, city: str, units: str = "metric") -> ToolResult:
        """Fetch weather data for a city.

        Args:
            city: City name (e.g., "London", "New York")
            units: Temperature units ("metric" or "imperial")

        Returns:
            ToolResult with weather information.
        """
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    "https://wttr.in/{city}",
                    params={"format": "3", "units": units},
                    timeout=10.0,
                )
                response.raise_for_status()

            return ToolResult(
                output=response.text.strip(),
                exit_code=0,
            )
        except httpx.HTTPError as e:
            return ToolResult(
                output="",
                exit_code=1,
                error=f"Failed to fetch weather: {e}",
            )

    def get_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "city": {
                    "type": "string",
                    "description": "City name",
                },
                "units": {
                    "type": "string",
                    "enum": ["metric", "imperial"],
                    "default": "metric",
                    "description": "Temperature units",
                },
            },
            "required": ["city"],
        }
```

## Best Practices

1. **Single responsibility** — Each tool does one thing well
2. **Clear naming** — Tool name should describe what it does
3. **Comprehensive schema** — Document all parameters
4. **Error handling** — Always return ToolResult, never raise exceptions
5. **Timeouts** — Use timeouts for network operations
6. **Idempotency** — Read tools should be idempotent
7. **Safety classification** — Accurately classify safety level
8. **Tests** — Write thorough tests for all paths
