# Development Setup

Set up your local development environment for Terminal Agent.

## Prerequisites

- Python 3.10+ (3.12 recommended)
- Git
- An LLM API key for testing

## Quick Setup

```bash
# Clone the repository
git clone https://github.com/terminal-agent/terminal-agent.git
cd terminal-agent

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate   # Windows

# Install in development mode
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install

# Verify setup
make test
```

## Using the Dev Script

```bash
./scripts/dev_setup.sh
```

This automates:
- Virtual environment creation
- Dependency installation
- Pre-commit hook setup
- Default configuration creation
- Initial test run

## Docker Development

```bash
# Build and start
docker-compose -f docker-compose.dev.yml up -d

# Run tests
docker-compose -f docker-compose.dev.yml exec agent make test

# Open shell
docker-compose -f docker-compose.dev.yml exec agent bash
```

## Makefile Commands

```bash
make help           # Show all commands
make test           # Run all tests
make test-unit      # Run unit tests only
make test-integration  # Run integration tests
make test-e2e       # Run end-to-end tests
make test-cov       # Run tests with coverage
make lint           # Run linter
make format         # Auto-format code
make type-check     # Run type checker
make build          # Build package
make clean          # Clean build artifacts
make docs           # Generate documentation
```

## IDE Setup

### VS Code

Install recommended extensions:
- Python
- Ruff
- MyPy Type Checker
- Python Test Explorer

Settings (`.vscode/settings.json`):
```json
{
    "python.defaultInterpreterPath": ".venv/bin/python",
    "python.linting.enabled": true,
    "python.linting.ruffEnabled": true,
    "python.formatting.provider": "none",
    "[python]": {
        "editor.defaultFormatter": "charliermarsh.ruff",
        "editor.formatOnSave": true,
        "editor.codeActionsOnSave": {
            "source.organizeImports": "explicit"
        }
    },
    "mypy-type-checker.args": ["--config-file", "pyproject.toml"]
}
```

### PyCharm

1. Open the project
2. Configure Python interpreter: `.venv/bin/python`
3. Enable Ruff as formatter
4. Enable MyPy as type checker

## Running Tests

```bash
# All tests
make test

# Unit tests
pytest tests/unit/ -v

# Integration tests
pytest tests/integration/ -v

# Specific test file
pytest tests/unit/test_tools/test_filesystem/test_read.py

# With coverage
pytest --cov=terminal_agent --cov-report=html

# Run specific test
pytest tests/unit/test_tools/test_filesystem/test_read.py::TestReadFileTool::test_read_existing_file
```

## Debugging

### Enable Debug Logging

```bash
export TERMINAL_AGENT_GENERAL_LOG_LEVEL=DEBUG
```

### Use Python Debugger

```python
import pdb; pdb.set_trace()  # Add breakpoint
```

### View Logs

```bash
tail -f ~/.terminal-agent/logs/agent.log
```

## Code Quality Tools

### Ruff (Linter + Formatter)

```bash
# Check
ruff check src/

# Fix
ruff check --fix src/

# Format
ruff format src/
```

### MyPy (Type Checker)

```bash
mypy src/
```

### Pre-commit Hooks

```bash
# Run all hooks
pre-commit run --all-files

# Run specific hook
pre-commit run ruff --all-files
```

## Project Structure

```
terminal-agent/
├── src/terminal_agent/    # Source code
├── tests/                 # Tests
│   ├── unit/              # Unit tests
│   ├── integration/       # Integration tests
│   ├── e2e/               # End-to-end tests
│   ├── chaos/             # Chaos tests
│   └── performance/       # Performance tests
├── docs/                  # Documentation
├── plugins/               # Built-in plugins
├── templates/             # Project templates
├── scripts/               # Build scripts
├── migrations/            # Database migrations
├── examples/              # Example code
├── pyproject.toml         # Project config
├── Makefile               # Build commands
└── Dockerfile             # Docker config
```

## Common Development Tasks

### Adding a New Dependency

```bash
# Add to pyproject.toml [project.dependencies]
# Then reinstall
pip install -e ".[dev]"
```

### Running a Specific LLM Provider

```bash
# Set up environment
export TERMINAL_AGENT_LLM_OPENAI_API_KEY="sk-..."

# Run with specific provider
terminal-agent run --provider openai "test task"
```

### Testing with Local Models

```bash
# Install Ollama
ollama pull llama3

# Configure
terminal-agent config set llm.primary_provider ollama
terminal-agent config set llm.ollama.model llama3
```
