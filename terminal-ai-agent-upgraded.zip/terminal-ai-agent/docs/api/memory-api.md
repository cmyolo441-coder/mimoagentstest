# Memory API Reference

API for the memory system.

## Memory Engine

```python
from terminal_agent.memory.engine import MemoryEngine

engine = MemoryEngine(config)

# Store a memory
entry_id = await engine.store(
    content="Created REST API with Flask",
    category="task",
    metadata={"project": "my-api"},
)

# Recall relevant memories
memories = await engine.recall(
    query="How to create an API?",
    limit=5,
    category="task",
)

# Search memories
results = await engine.search(
    query="Flask patterns",
    limit=10,
)

# Delete a memory
await engine.delete(entry_id)

# Get statistics
stats = await engine.stats()
```

## Memory Entry

```python
from terminal_agent.memory.long_term import MemoryEntry

entry = MemoryEntry(
    id="mem_123",
    category="task",
    content="Created REST API with Flask",
    embedding=[0.1, 0.2, ...],
    metadata={"project": "my-api"},
    relevance=1.0,
    access_count=0,
    created_at=1705334400.0,
    last_accessed=1705334400.0,
)
```

## Short-Term Memory

```python
from terminal_agent.memory.short_term import ShortTermMemory

stm = ShortTermMemory(max_turns=20)

# Add a turn
stm.add(ConversationTurn(
    role="user",
    content="Create an API",
    timestamp=time.time(),
    token_count=50,
))

# Get recent turns
turns = stm.get_recent(limit=3)

# Get all turns
all_turns = stm.get_all()

# Clear
stm.clear()
```

## Working Memory

```python
from terminal_agent.memory.working_memory import WorkingMemory

wm = WorkingMemory(max_files=10)

# Update file contents
wm.update_file("src/app.py", file_contents)

# Get file contents
contents = wm.get_file("src/app.py")

# Update plan
wm.update_plan(plan)

# Get plan
plan = wm.get_plan()

# Update scratch pad
wm.set_scratch("key", "value")

# Get scratch pad
value = wm.get_scratch("key")
```

## Vector Store

```python
from terminal_agent.support.vector_store.manager import VectorStoreManager

store = VectorStoreManager(backend="chroma", config={})

# Store a vector
entry_id = await store.upsert(
    id="vec_123",
    vector=[0.1, 0.2, ...],
    metadata={"content": "memory text", "category": "task"},
)

# Search similar vectors
results = await store.search(
    query_vector=[0.1, 0.2, ...],
    limit=5,
    category="task",
)

# Delete a vector
await store.delete("vec_123")

# Count entries
count = await store.count()
```

## Memory Consolidation

```python
from terminal_agent.memory.consolidator import MemoryConsolidator

consolidator = MemoryConsolidator(engine)

# Consolidate memories
await consolidator.consolidate()

# Decay old memories
await consolidator.decay(days_threshold=30)

# Remove duplicates
await consolidator.deduplicate(similarity_threshold=0.95)
```

## Memory Categories

```python
from terminal_agent.memory.categories import (
    TaskMemory,
    ErrorMemory,
    PatternMemory,
    PreferenceMemory,
    ProjectMemory,
    ToolMemory,
    EnvironmentMemory,
)

# Store in specific category
task = TaskMemory()
await task.store("Created API with Flask", metadata={})

error = ErrorMemory()
await error.store("ImportError: pip install requests", metadata={})
```
