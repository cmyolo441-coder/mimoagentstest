# CLI API Reference

Programmatic interface for the CLI module.

## Entry Point

```python
from terminal_agent.cli.app import main

# Run the CLI
main()
```

## Commands

### `run`

```python
from terminal_agent.cli.commands.run import RunCommand

cmd = RunCommand()
await cmd.execute(
    goal="Create a REST API",
    model="gpt-4o",
    provider="openai",
    temperature=0.7,
    safety_level=2,
    dry_run=False,
    streaming=True,
)
```

### `chat`

```python
from terminal_agent.cli.commands.chat import ChatCommand

cmd = ChatCommand()
await cmd.execute(
    model="gpt-4o",
    theme="dark",
    session_id=None,
)
```

### `config`

```python
from terminal_agent.cli.commands.config import ConfigCommand

cmd = ConfigCommand()
cmd.show(section="llm")
cmd.get("llm.primary_model")
cmd.set("llm.primary_model", "gpt-4o")
cmd.reset("llm.temperature")
cmd.validate()
```

### `sessions`

```python
from terminal_agent.cli.commands.sessions import SessionsCommand

cmd = SessionsCommand()
sessions = cmd.list(limit=10, status="completed")
session = cmd.show(session_id="abc123")
cmd.resume(session_id="abc123")
cmd.delete(session_id="abc123")
```

## Output Formatting

```python
from terminal_agent.cli.output import OutputFormatter

formatter = OutputFormatter()

# Colored output
formatter.success("Task completed!")
formatter.error("Something went wrong")
formatter.warning("Low memory")
formatter.info("Processing...")

# Structured output
formatter.table(headers=["Name", "Status"], rows=[["Task 1", "Done"]])
formatter.json({"key": "value"})
formatter.markdown("# Title\nContent")
```

## Shell Completion

```python
from terminal_agent.cli.completions.bash import generate_bash_completion
from terminal_agent.cli.completions.zsh import generate_zsh_completion
from terminal_agent.cli.completions.fish import generate_fish_completion

bash_script = generate_bash_completion()
zsh_script = generate_zsh_completion()
fish_script = generate_fish_completion()
```

## Argument Parser

```python
from terminal_agent.cli.parser import create_parser

parser = create_parser()
args = parser.parse_args(["run", "my goal", "--model", "gpt-4o"])
```
