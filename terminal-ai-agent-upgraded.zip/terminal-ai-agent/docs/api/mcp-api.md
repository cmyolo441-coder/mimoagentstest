# MCP API Reference

API for MCP client and server development.

## MCP Client

```python
from terminal_agent.mcp.client import MCPClient

# Create client
client = MCPClient(
    url="http://localhost:8080",
    token="my-secret",
    timeout=30,
    retries=3,
)

# List tools
tools = await client.list_tools()

# Call a tool
result = await client.call_tool("tool_name", {"param": "value"})

# Check health
healthy = await client.health_check()

# Close
await client.close()
```

## MCP Server

```python
from terminal_agent.mcp.server import MCPServer, ToolDefinition

# Create server
server = MCPServer(
    name="my-tools",
    version="1.0.0",
    rate_limit=60,
)

# Register tool with decorator
@server.tool("greet")
async def greet(name: str) -> str:
    """Greet someone.

    Args:
        name: Name to greet.

    Returns:
        Greeting message.
    """
    return f"Hello, {name}!"

# Register tool with definition
server.register_tool(ToolDefinition(
    name="calculate",
    description="Evaluate expression",
    input_schema={
        "type": "object",
        "properties": {
            "expression": {"type": "string"},
        },
        "required": ["expression"],
    },
    handler=lambda expression: eval(expression),
))

# Run server
server.run(host="0.0.0.0", port=8080)
```

## MCP Server with Auth

```python
from terminal_agent.mcp.server import MCPServer, AuthConfig

server = MCPServer(
    name="my-tools",
    auth=AuthConfig(
        type="token",
        token="my-secret",
    ),
)
```

## Tool Definition

```python
from terminal_agent.mcp.server import ToolDefinition

tool = ToolDefinition(
    name="my_tool",
    description="Does something",
    input_schema={
        "type": "object",
        "properties": {
            "param1": {
                "type": "string",
                "description": "First parameter",
            },
        },
        "required": ["param1"],
    },
    handler=my_handler_function,
)
```

## MCP Protocol Messages

### Tool List Request

```json
{
    "jsonrpc": "2.0",
    "method": "tools/list",
    "id": 1
}
```

### Tool Call Request

```json
{
    "jsonrpc": "2.0",
    "method": "tools/call",
    "params": {
        "name": "tool_name",
        "arguments": {"param": "value"}
    },
    "id": 2
}
```

### Success Response

```json
{
    "jsonrpc": "2.0",
    "result": {
        "content": [{"type": "text", "text": "result"}],
        "isError": false
    },
    "id": 2
}
```

### Error Response

```json
{
    "jsonrpc": "2.0",
    "error": {
        "code": -32000,
        "message": "Tool not found",
        "data": {"tool": "nonexistent"}
    },
    "id": 2
}
```

## Error Codes

| Code | Meaning |
|------|---------|
| -32700 | Parse error |
| -32600 | Invalid request |
| -32601 | Method not found |
| -32602 | Invalid params |
| -32603 | Internal error |
| -32000 | Tool not found |
| -32001 | Tool execution failed |
| -32002 | Authentication failed |
| -32003 | Rate limit exceeded |
