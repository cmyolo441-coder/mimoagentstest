# Plugin API Reference

API for developing plugins.

## Plugin Base

```python
from terminal_agent.plugins.api import PluginBase, PluginContext

class MyPlugin(PluginBase):
    name = "my-plugin"
    version = "1.0.0"

    async def initialize(self, context: PluginContext) -> None:
        """Called when the plugin is loaded."""
        self.context = context
        context.register_tool("my_tool", self.my_tool)

    async def cleanup(self) -> None:
        """Called when the plugin is unloaded."""
        pass
```

## PluginContext

```python
class PluginContext:
    """Context provided to plugins."""

    def register_tool(self, name: str, func: Callable) -> None:
        """Register a new tool."""

    def register_hook(self, event: str, func: Callable) -> None:
        """Register a lifecycle hook."""

    def get_config(self, plugin_name: str) -> dict:
        """Get plugin configuration."""

    @property
    def logger(self) -> Logger:
        """Plugin logger."""

    @property
    def data_dir(self) -> Path:
        """Plugin data directory."""
```

## Hooks

```python
# Available hooks:

async def before_tool(self, tool_name: str, parameters: dict) -> dict:
    """Called before any tool executes. Return modified parameters."""

async def after_tool(self, tool_name: str, parameters: dict, result: dict) -> dict:
    """Called after any tool executes. Return modified result."""

async def on_error(self, tool_name: str, error: Exception) -> bool:
    """Called when a tool fails. Return True to suppress error."""

async def on_session_start(self, session_id: str) -> None:
    """Called when a session starts."""

async def on_session_end(self, session_id: str, summary: dict) -> None:
    """Called when a session ends."""

async def on_plan_created(self, plan: dict) -> None:
    """Called when a plan is generated."""
```

## Plugin Manifest

```toml
[plugin]
name = "my-plugin"
version = "1.0.0"
author = "Author Name"
description = "Plugin description"
license = "MIT"
requires_terminal_agent = ">=0.1.0"

[dependencies]
packages = ["requests"]

[tools]
provides = ["tool_name"]

[hooks]
before_tool = true
after_tool = true
on_error = true
```

## Plugin Discovery

```python
from terminal_agent.plugins.discovery import PluginDiscovery

discovery = PluginDiscovery(directories=["~/.terminal-agent/plugins"])
plugins = discovery.scan()
```

## Plugin Loader

```python
from terminal_agent.plugins.loader import PluginLoader

loader = PluginLoader(sandbox=True)
plugin = await loader.load(plugin_path="/path/to/plugin")
```

## Plugin Registry

```python
from terminal_agent.plugins.registry import PluginRegistry

registry = PluginRegistry()
registry.register(plugin)
loaded = registry.get("my-plugin")
all_plugins = registry.list_plugins()
```
