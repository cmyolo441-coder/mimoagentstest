# Tool API Reference

API for developing and registering tools.

## Base Tool

```python
from terminal_agent.tools.base_tool import BaseTool
from terminal_agent.tools.result import ToolResult

class MyTool(BaseTool):
    name = "my_tool"
    description = "Does something useful"
    category = "custom"
    safety_level = "moderate"

    async def execute(self, **parameters) -> ToolResult:
        """Execute the tool."""
        return ToolResult(
            output="result",
            exit_code=0,
            duration=0.0,
        )

    def get_schema(self) -> dict:
        """Return JSON Schema for parameters."""
        return {
            "type": "object",
            "properties": {
                "param1": {"type": "string"},
            },
            "required": ["param1"],
        }
```

## ToolResult

```python
from terminal_agent.tools.result import ToolResult

result = ToolResult(
    output="file contents",      # Tool output
    exit_code=0,                 # Exit code (0 = success)
    error="",                    # Error message (if failed)
    duration=1.5,                # Execution time in seconds
    files_modified=["file.py"],  # Files that were changed
    metadata={"size": 1024},     # Additional metadata
)
```

## Tool Registry

```python
from terminal_agent.tools.registry import ToolRegistry

registry = ToolRegistry()

# Register a tool
registry.register(MyTool())

# Get a tool
tool = registry.get("my_tool")

# List tools
tools = registry.list_tools()
tools = registry.list_tools(category="custom")

# Check if tool exists
exists = registry.has("my_tool")
```

## Tool Dispatcher

```python
from terminal_agent.tools.dispatcher import ToolDispatcher

dispatcher = ToolDispatcher(registry=registry, safety=safety_system)

# Dispatch a tool call
result = await dispatcher.dispatch(ToolCall(
    id="call_1",
    name="my_tool",
    parameters={"param1": "value"},
))
```

## Tool Call

```python
from terminal_agent.types import ToolCall

call = ToolCall(
    id="call_1",
    name="my_tool",
    parameters={"param1": "value"},
)
```

## Safety Integration

```python
from terminal_agent.support.safety.guardrails import SafetySystem

safety = SafetySystem(level=2)

# Check if a tool call is safe
result = await safety.evaluate(tool_call)
if result.allowed:
    # Proceed with execution
    pass
else:
    # Handle safety violation
    print(result.reason)
```
