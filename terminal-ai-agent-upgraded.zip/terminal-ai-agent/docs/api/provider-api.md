# Provider API Reference

API for developing LLM providers.

## Base Provider

```python
from terminal_agent.llm.base_provider import BaseProvider, LLMResponse, StreamChunk

class MyProvider(BaseProvider):
    name = "my_provider"
    supported_models = ["my-model-1"]

    def __init__(self, config):
        super().__init__(config)

    async def complete(self, messages: list[dict], **kwargs) -> LLMResponse:
        """Send a completion request."""
        ...

    async def stream(self, messages: list[dict], **kwargs):
        """Stream a completion response."""
        yield StreamChunk(content="token", tool_calls=None, finish_reason=None)

    async def close(self) -> None:
        """Close the provider."""
        ...
```

## LLMResponse

```python
from terminal_agent.llm.base_provider import LLMResponse

response = LLMResponse(
    content="Hello, World!",           # Text content
    tool_calls=[                        # Tool calls (if any)
        {"id": "call_1", "name": "tool", "arguments": "{}"}
    ],
    tokens_in=100,                     # Input tokens
    tokens_out=50,                     # Output tokens
    cost=0.001,                        # Cost in dollars
    model="my-model-1",                # Model used
    finish_reason="stop",              # Why it stopped
)
```

## StreamChunk

```python
from terminal_agent.llm.base_provider import StreamChunk

chunk = StreamChunk(
    content="token text",              # Text chunk
    tool_calls=None,                   # Partial tool call
    finish_reason=None,                # "stop" when done
)
```

## Provider Registration

```python
from terminal_agent.llm.providers import PROVIDERS

PROVIDERS["my_provider"] = MyProvider
```

## Token Counter

```python
from terminal_agent.llm.token_counter import TokenCounter

counter = TokenCounter()
count = counter.count("Hello, World!", model="gpt-4o")
```

## Cost Tracker

```python
from terminal_agent.llm.cost_tracker import CostTracker

tracker = CostTracker()

# Record a call
tracker.record(
    model="gpt-4o",
    tokens_in=100,
    tokens_out=50,
    cost=0.001,
)

# Get totals
total_cost = tracker.total_cost
total_tokens = tracker.total_tokens
```

## Response Parser

```python
from terminal_agent.llm.response_parser import ResponseParser

parser = ResponseParser()

# Parse a response
parsed = parser.parse(raw_response)

# Extract tool calls
tool_calls = parser.extract_tool_calls(raw_response)
```

## Fallback Chain

```python
from terminal_agent.llm.fallback import FallbackChain

chain = FallbackChain(
    providers=["openai", "anthropic", "ollama"],
    config=config,
)

# Try providers in order
response = await chain.complete(messages)
```
