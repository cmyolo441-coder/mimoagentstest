# TUI Guide

The Terminal User Interface (TUI) provides an interactive, full-screen experience for working with Terminal Agent.

## Starting the TUI

```bash
# Start interactive chat (opens TUI)
terminal-agent chat

# With specific theme
terminal-agent chat --theme solarized

# Resume a session in TUI
terminal-agent chat --session-id abc123
```

## Layout

The TUI has several panels:

```
┌─────────────────────────────────────────────────────┐
│ Terminal Agent                    [dark] [safe: 2]  │
├─────────────────────────────────────────────────────┤
│                                                     │
│  🤖 Agent: I'll create a Python web server with    │
│     Flask. Let me start by setting up the project.  │
│                                                     │
│  💭 Thinking: The user wants a Flask server. I'll   │
│     create app.py with routes, requirements.txt,    │
│     and a basic test file.                          │
│                                                     │
│  🔧 Tool: write_file(path="app.py")                │
│  ✅ Result: File created successfully               │
│                                                     │
│  📝 Plan:                                            │
│  ✅ 1. Create Flask app with routes                 │
│  🔄 2. Add error handling                           │
│  ⬜ 3. Create requirements.txt                      │
│  ⬜ 4. Write tests                                  │
│                                                     │
├─────────────────────────────────────────────────────┤
│ > _                                                  │
└─────────────────────────────────────────────────────┘
```

## Screens

### Main Chat (default)

The primary conversation view where you interact with the agent.

**What's displayed:**
- Your messages
- Agent's thoughts and reasoning
- Tool calls and their results
- Current plan progress
- Streaming token output

### Plan View (`Ctrl+T`)

Shows the current plan with detailed status:

```
📋 Current Plan: Create Flask web server
├── ✅ 1. Create Flask app with routes (2.3s)
│   └── Created app.py with 3 endpoints
├── 🔄 2. Add error handling (in progress)
│   └── Adding try/except blocks...
├── ⬜ 3. Create requirements.txt
│   └── Depends on: step 2
└── ⬜ 4. Write tests
    └── Depends on: steps 1-3

Progress: ████████░░░░░░░░ 25%
Time: 00:02:34 | Tokens: 1,234 | Cost: $0.03
```

### History View (`Ctrl+R`)

Browse past sessions:

```
📚 Session History
├── 2025-01-15 14:30 | "Create REST API"          | ✅ 12 steps | $0.45
├── 2025-01-15 10:00 | "Fix auth bug"             | ✅ 5 steps  | $0.12
├── 2025-01-14 16:45 | "Refactor database layer"  | ❌ 8 steps  | $0.33
└── 2025-01-14 09:00 | "Write unit tests"         | ✅ 6 steps  | $0.18
```

### Metrics Dashboard (`Ctrl+M`)

Real-time metrics display:

```
📊 Metrics Dashboard
├── Token Usage: 12,456 / 128,000 (9.7%)
├── Cost: $0.23 / $5.00 limit
├── Cache Hit Rate: 73%
├── Tools Called: 8
│   ├── write_file: 3
│   ├── execute_command: 2
│   ├── read_file: 2
│   └── run_tests: 1
└── Time: 00:03:45
```

### Settings View (`Ctrl+,`)

Interactive configuration editor:

```
⚙️ Settings
├── LLM
│   ├── Provider: [openai ▼]
│   ├── Model: [gpt-4o ▼]
│   ├── Temperature: [0.7] (0.0 - 2.0)
│   └── Max Tokens: [4096]
├── Safety
│   ├── Level: [2 ▼] (0-5)
│   └── Confirm Delete: [✓]
├── Memory
│   ├── Short-term Turns: [20]
│   └── Vector Backend: [chroma ▼]
└── UI
    ├── Theme: [dark ▼]
    └── Streaming: [✓]
```

### Memory Browser (`Ctrl+K`)

Search and browse stored memories:

```
🧠 Memory Browser
├── 🔍 [Search memories...]
├── Recent
│   ├── Flask route patterns (2h ago)
│   ├── pytest fixture usage (1d ago)
│   └── Git merge strategy (3d ago)
├── Patterns
│   ├── REST API structure
│   ├── Error handling pattern
│   └── Database migration pattern
└── Errors
    ├── ImportError fix: add to requirements
    └── Port conflict: use 5001 instead
```

### Trace Viewer (`Ctrl+V`)

Step through execution traces:

```
🔍 Trace Viewer: Session abc123
├── Step 1 (0.0s)
│   ├── Thought: "I need to read the existing code first"
│   ├── Action: read_file(path="src/app.py")
│   ├── Result: (45 lines, 1.2KB)
│   └── Verification: ✅ File exists and is readable
├── Step 2 (1.2s)
│   ├── Thought: "I'll add error handling to the routes"
│   ├── Action: edit_file(path="src/app.py", changes=[...])
│   ├── Result: File updated
│   └── Verification: ✅ Syntax valid, no regressions
└── ...
```

## Keyboard Shortcuts

### Navigation

| Key | Action |
|-----|--------|
| `↑` / `↓` | Scroll up/down |
| `Page Up` / `Page Down` | Scroll by page |
| `Home` / `End` | Jump to start/end |
| `Tab` | Next panel |
| `Shift+Tab` | Previous panel |

### Actions

| Key | Action |
|-----|--------|
| `Enter` | Send message / Confirm |
| `Escape` | Cancel / Go back |
| `Ctrl+C` | Cancel current operation |
| `Ctrl+D` | Exit |
| `Ctrl+L` | Clear screen |
| `Ctrl+S` | Save session |
| `Ctrl+X` | Export session |
| `Ctrl+Z` | Undo last action |

### Views

| Key | Action |
|-----|--------|
| `Ctrl+T` | Toggle plan view |
| `Ctrl+M` | Toggle metrics |
| `Ctrl+R` | Search history |
| `Ctrl+K` | Memory browser |
| `Ctrl+V` | Trace viewer |
| `Ctrl+,` | Settings |
| `Ctrl+H` | Help |

### Editing

| Key | Action |
|-----|--------|
| `Ctrl+A` | Move to start of line |
| `Ctrl+E` | Move to end of line |
| `Ctrl+W` | Delete word backward |
| `Ctrl+U` | Delete to start of line |
| `Ctrl+K` | Delete to end of line |
| `Ctrl+Y` | Paste (yank) |

## Themes

Terminal Agent includes 5 built-in themes:

### Dark (default)
Dark background with bright text. Best for terminals with dark backgrounds.

### Light
Light background with dark text. Best for terminals with light backgrounds.

### Solarized
Based on the Solarized color scheme. Easy on the eyes for long sessions.

### Monokai
Based on the Monokai color scheme. Popular among developers.

### High Contrast
Maximum contrast for accessibility. Best for low-vision users or bright environments.

Switch themes:
```bash
# Via config
terminal-agent config set general.theme solarized

# Via TUI shortcut
Ctrl+, → UI → Theme → [select]
```

## Confirmation Dialogs

When the agent needs confirmation for a destructive action:

```
┌─────────────────────────────────────────────────────┐
│ ⚠️  Confirmation Required                           │
├─────────────────────────────────────────────────────┤
│                                                     │
│ The agent wants to execute:                         │
│                                                     │
│   rm -rf build/ dist/ *.egg-info                   │
│                                                     │
│ This will permanently delete the following:         │
│   • build/ (15 files, 2.3MB)                       │
│   • dist/ (3 files, 1.1MB)                         │
│   • *.egg-info (2 files)                           │
│                                                     │
│ [Y] Yes  [N] No  [A] Always allow for this session │
│ [D] Show diff  [S] Show full command                │
│                                                     │
└─────────────────────────────────────────────────────┘
```

## Streaming Output

As the agent generates code, tokens appear in real-time:

```
🤖 Agent: I'll create the Flask application...

```python
from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route('/api/health')
def health():
    return jsonify({"status": "healthy"})

@app.route('/api/users', methods=['GET'])
def get_users():
    # Token by token, the code appears...
```

## Resizing

The TUI adapts to terminal size:
- **Full size** (>120 cols): All panels visible
- **Medium size** (80-120 cols): Sidebar collapses
- **Small size** (<80 cols): Minimal layout

## Tips

1. **Use `Ctrl+T`** to check the plan frequently
2. **Use `Ctrl+M`** to monitor costs during long tasks
3. **Use `Ctrl+R`** to find and resume past sessions
4. **Use `Ctrl+K`** to search for relevant memories
5. **Press `Escape`** to cancel input without losing context
