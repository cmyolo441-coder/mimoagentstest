# MCP Integration

Terminal Agent supports the Model Context Protocol (MCP) for connecting to external tool servers and exposing its own tools.

## What is MCP?

The Model Context Protocol is a standard for AI-tool communication. It allows:
- **MCP Client** — Terminal Agent connects to external MCP servers to use their tools
- **MCP Server** — Terminal Agent exposes its own tools to external MCP clients

## MCP Client

### Connecting to an MCP Server

```bash
# Add an MCP server
terminal-agent mcp add https://mcp-server.example.com

# With authentication
terminal-agent mcp add https://mcp-server.example.com --token "my-token"

# List connected servers
terminal-agent mcp list

# Test connection
terminal-agent mcp test my-server
```

### Configuration

```toml
[mcp]
timeout = 30
retries = 3

[[mcp.servers]]
name = "filesystem-server"
url = "https://mcp.example.com/filesystem"
token = "my-token"

[[mcp.servers]]
name = "database-server"
url = "https://mcp.example.com/database"
token = "my-token"
```

### Using MCP Tools

MCP tools appear alongside built-in tools:

```bash
# List all tools (including MCP tools)
terminal-agent tools list

# Use an MCP tool in a task
terminal-agent run "Use the filesystem-server to list files in /data"
```

### Tool Name Conflict Resolution

If an MCP server provides a tool with the same name as a built-in tool:

```toml
[[mcp.servers]]
name = "my-server"
url = "https://mcp.example.com"
prefix = "ext"  # Tools will be named "ext.tool_name"
```

## MCP Server

Terminal Agent can expose its own tools via MCP.

### Starting the MCP Server

```bash
# Start the MCP server
terminal-agent mcp serve

# On a specific port
terminal-agent mcp serve --port 8080

# With authentication
terminal-agent mcp serve --token "my-secret"
```

### Configuration

```toml
[mcp.server]
enabled = true
port = 8080
host = "0.0.0.0"
token = "my-secret"
max_connections = 10
rate_limit = 60  # requests per minute
```

### Exposing Tools

Control which tools are exposed:

```toml
[mcp.server]
# Only expose these tools
exposed_tools = ["read_file", "write_file", "execute_command", "search_files"]

# Or exclude specific tools
excluded_tools = ["delete_file", "docker_run"]
```

## MCP Protocol Details

### Request Format

```json
{
  "jsonrpc": "2.0",
  "method": "tools/call",
  "params": {
    "name": "read_file",
    "arguments": {
      "path": "/path/to/file"
    }
  },
  "id": 1
}
```

### Response Format

```json
{
  "jsonrpc": "2.0",
  "result": {
    "content": [
      {
        "type": "text",
        "text": "file contents..."
      }
    ],
    "isError": false
  },
  "id": 1
}
```

### Tool Discovery

```json
{
  "jsonrpc": "2.0",
  "method": "tools/list",
  "id": 1
}
```

Response:

```json
{
  "jsonrpc": "2.0",
  "result": {
    "tools": [
      {
        "name": "read_file",
        "description": "Read file contents",
        "inputSchema": {
          "type": "object",
          "properties": {
            "path": {"type": "string", "description": "File path"}
          },
          "required": ["path"]
        }
      }
    ]
  },
  "id": 1
}
```

## Use Cases

### Shared Tool Server

Run a centralized MCP server that multiple Terminal Agent instances connect to:

```bash
# On the server
terminal-agent mcp serve --port 8080 --token "team-secret"

# On each client
terminal-agent mcp add http://server:8080 --token "team-secret"
```

### External Tool Integration

Connect to third-party MCP servers for specialized tools:

```bash
# Database management server
terminal-agent mcp add https://db-tools.example.com

# Cloud resource server
terminal-agent mcp add https://cloud-tools.example.com
```

### IDE Integration

IDEs can connect to Terminal Agent's MCP server to access its tools:

```json
// VS Code settings.json
{
  "mcp.servers": {
    "terminal-agent": {
      "url": "http://localhost:8080",
      "token": "my-secret"
    }
  }
}
```

## Security

### Authentication

Always use authentication in production:

```toml
[mcp.server]
token = "strong-random-secret"
```

### Rate Limiting

Protect against abuse:

```toml
[mcp.server]
rate_limit = 60  # requests per minute per client
```

### Tool Access Control

Only expose safe tools:

```toml
[mcp.server]
exposed_tools = ["read_file", "search_files", "list_directory"]
# Destructive tools are not exposed
```

## Troubleshooting

### Connection Refused

```bash
# Check if server is running
terminal-agent mcp list

# Test connection
terminal-agent mcp test my-server

# Check firewall
curl http://server:8080/health
```

### Tool Not Found

```bash
# List available MCP tools
terminal-agent mcp tools my-server

# Check if tool is exposed
terminal-agent mcp info my-server
```

### Authentication Failed

```bash
# Re-add with correct token
terminal-agent mcp remove my-server
terminal-agent mcp add http://server:8080 --token "correct-token"
```
