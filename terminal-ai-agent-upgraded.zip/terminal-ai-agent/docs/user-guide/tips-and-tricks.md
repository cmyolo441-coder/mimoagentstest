# Tips & Tricks

Get the most out of Terminal Agent with these practical tips.

## Writing Effective Tasks

### Be Specific

❌ "Fix the code"
✅ "Fix the authentication error in src/auth.py — the login endpoint returns 500 when the email field is missing"

❌ "Add tests"
✅ "Write pytest tests for the UserService class in src/services/user.py. Cover: create user, get user by ID, update user, delete user, and error cases for invalid input"

❌ "Make it better"
✅ "Refactor the database connection code in src/db.py to use connection pooling with SQLAlchemy. Add retry logic for transient connection failures"

### Provide Context

Include relevant information the agent needs:

```
"Add rate limiting to our Express API. We use:
- Express 4.x with TypeScript
- Redis for session storage
- The app is in src/app.ts
- Routes are in src/routes/
- We want 100 requests per minute per IP"
```

### Describe the Goal, Not the Steps

❌ "Open app.py, find line 42, change the variable name from x to user_count"
✅ "Rename the variable 'x' to 'user_count' in the loop in app.py — it's counting active users"

### Include Constraints

```
"Create a REST API for a todo app with:
- FastAPI framework
- SQLite database (no external dependencies)
- Pydantic models for validation
- Full CRUD operations
- Tests with pytest
- Docker Compose setup
- Must work on Python 3.10+"
```

## Workflow Tips

### Use Interactive Mode for Complex Tasks

```bash
terminal-agent chat
```

This lets you:
- See the agent's reasoning in real-time
- Provide feedback between steps
- Correct course if needed
- Ask questions

### Resume Interrupted Sessions

```bash
# List recent sessions
terminal-agent sessions list

# Resume a session
terminal-agent sessions resume abc123
```

### Use Dry Run to Preview Plans

```bash
terminal-agent run --dry-run "Set up a complete CI/CD pipeline"
```

This shows the plan without executing, so you can verify the approach.

### Chain Tasks

```bash
# First task
terminal-agent run "Create a FastAPI project with user authentication"

# Second task (builds on the first)
terminal-agent run "Add a rate limiting middleware to the API"

# Third task
terminal-agent run "Write integration tests for the auth and rate limiting"
```

### Use Project Configuration

Create `.agent/project.toml` in your project:

```toml
[general]
safety_level = 3

[llm]
primary_model = "gpt-4o"

[tools]
enabled = ["filesystem", "code", "git", "testing"]
```

This ensures consistent behavior for the project.

## Performance Tips

### Enable Caching

```bash
terminal-agent config set llm.cache_responses true
terminal-agent config set cache.backend disk
```

### Use Faster Models for Simple Tasks

```bash
terminal-agent config set llm.secondary_model gpt-4o-mini
```

The agent automatically uses the secondary model for formatting, summarization, etc.

### Reduce Context Size

```bash
terminal-agent config set memory.short_term_turns 10
terminal-agent config set memory.working_memory_files 5
```

### Use Local Models

For free, fast inference:

```bash
terminal-agent config set llm.primary_provider ollama
terminal-agent config set llm.ollama.model llama3
```

## Safety Tips

### Review Before Approving

When the agent asks for confirmation, review the action carefully:

```
⚠️ The agent wants to execute: rm -rf build/
[Y] Yes  [N] No  [D] Show diff  [S] Show full command
```

Press `D` to see what will be deleted, `S` to see the full command.

### Use Appropriate Safety Levels

```bash
# Daily development
terminal-agent config set safety.level 2

# Production environment
terminal-agent config set safety.level 4

# Exploring/learning
terminal-agent config set safety.level 5
```

### Enable Audit Logging

```bash
terminal-agent config set safety.audit_log true
```

Review the audit log:

```bash
terminal-agent traces list --type safety
```

## Memory Tips

### Let the Agent Learn

The more tasks you do, the better the agent gets. It learns:
- Your coding style
- Project conventions
- Common patterns
- Error solutions

### Review Memories

```bash
# See what the agent has learned
terminal-agent memory list --recent 7d

# Search for specific knowledge
terminal-agent memory search "database migration pattern"
```

### Export Important Memories

Back up your memory store:

```bash
terminal-agent memory export --output my-memories.json
```

### Clear Outdated Memories

```bash
# Clear memories older than 30 days
terminal-agent memory clear --older-than 30d

# Clear memories for a specific category
terminal-agent memory clear --category error
```

## Debugging Tips

### Enable Debug Logging

```bash
terminal-agent config set general.log_level DEBUG
terminal-agent run "your task"
cat ~/.terminal-agent/logs/agent.log
```

### View Execution Traces

```bash
# List traces
terminal-agent traces list

# View a specific trace
terminal-agent traces show abc123

# Compare two traces
terminal-agent traces compare abc123 def456
```

### Check System Health

```bash
terminal-agent health --full
```

### Use the TUI for Visibility

The TUI shows the agent's reasoning in real-time:

```bash
terminal-agent chat
```

## Productivity Tips

### Create Task Templates

Save common tasks as templates:

```bash
# templates/api-task.txt
Create a REST API for {{project_name}} with:
- {{framework}} framework
- {{database}} database
- CRUD operations for {{models}}
- Authentication with {{auth_method}}
- Tests with {{test_framework}}
- Docker setup
```

### Use Shell Aliases

```bash
# ~/.bashrc or ~/.zshrc
alias ta="terminal-agent"
alias tar="terminal-agent run"
alias tac="terminal-agent chat"
alias tas="terminal-agent sessions list"
alias tam="terminal-agent metrics show"
```

### Batch Operations

```bash
# Process multiple files
terminal-agent run "Format all Python files in src/ with black"

# Run multiple commands
terminal-agent run "Install pytest, run all tests, and generate a coverage report"
```

### Use Keyboard Shortcuts in TUI

| Shortcut | Action |
|----------|--------|
| `Ctrl+T` | Toggle plan view |
| `Ctrl+M` | Toggle metrics |
| `Ctrl+R` | Search history |
| `Ctrl+K` | Memory browser |
| `Ctrl+S` | Save session |
| `Ctrl+C` | Cancel operation |

## Common Patterns

### The Fix-Test Loop

```bash
terminal-agent run "The tests in test_api.py are failing. Fix the issues and make all tests pass."
```

### The Explore-Understand-Change Pattern

```bash
terminal-agent run "Explore the codebase structure, understand how authentication works, then add OAuth2 support."
```

### The Review-Improve Pattern

```bash
terminal-agent run "Review the code in src/ for security vulnerabilities and fix any issues found."
```

### The Document-Pattern

```bash
terminal-agent run "Generate comprehensive documentation for the API including README, API reference, and usage examples."
```
