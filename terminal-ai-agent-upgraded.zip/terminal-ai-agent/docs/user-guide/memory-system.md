# Memory System

Terminal Agent's three-tier memory system enables it to learn from past tasks and apply that knowledge to future ones.

## Overview

```
┌─────────────────────────────────────────────────────────┐
│                    MEMORY SYSTEM                         │
├─────────────────────────────────────────────────────────┤
│  Tier 1: SHORT-TERM MEMORY                              │
│  ├── Current conversation turns (last 20)               │
│  ├── Immediate context                                  │
│  └── Session only (lost when session ends)              │
├─────────────────────────────────────────────────────────┤
│  Tier 2: WORKING MEMORY                                 │
│  ├── Active file contents                               │
│  ├── Current plan and progress                          │
│  ├── Scratch pad                                        │
│  └── Session only                                       │
├─────────────────────────────────────────────────────────┤
│  Tier 3: LONG-TERM MEMORY                               │
│  ├── Persistent across sessions                         │
│  ├── Vector embeddings for semantic search              │
│  ├── 7 categories of knowledge                          │
│  └── Stored in database + vector store                  │
└─────────────────────────────────────────────────────────┘
```

## Tier 1: Short-Term Memory

Short-term memory holds the current conversation context.

### What's Stored

- User messages
- Agent thoughts and plans
- Tool calls and their results
- Verification outcomes
- Error messages and recovery attempts

### Configuration

```toml
[memory]
short_term_turns = 20  # Number of conversation turns to keep
```

### How It Works

1. Each conversation turn is added to short-term memory
2. When the limit is reached, older turns are summarized
3. Summarized turns are still available but in compressed form
4. The last 3 turns are always kept in full detail

## Tier 2: Working Memory

Working memory holds the active state for the current task.

### What's Stored

- Files currently being edited (contents)
- Current directory state
- Current plan and progress
- Scratch pad (intermediate calculations, notes)
- Active environment variables
- Current git branch and status
- Recent search results

### Configuration

```toml
[memory]
working_memory_files = 10  # Max files in working memory
```

### How It Works

1. When a file is read or edited, its contents are added to working memory
2. Working memory is included in every LLM context
3. Files are evicted when the limit is reached (LRU)
4. Working memory is cleared when the session ends

## Tier 3: Long-Term Memory

Long-term memory stores persistent knowledge across sessions.

### Memory Categories

| Category | What's Stored | Example |
|----------|---------------|---------|
| **Task** | What was done in each past task | "Created REST API with Flask, used SQLAlchemy" |
| **Error** | Errors encountered and solutions | "ImportError: install package with pip" |
| **Pattern** | Reusable code patterns | "REST API pattern: routes, models, tests" |
| **Preference** | User style preferences | "Prefers pytest over unittest" |
| **Project** | Project-specific knowledge | "This project uses TypeScript strict mode" |
| **Tool** | Tool usage patterns | "Use --force flag for git push to new branch" |
| **Environment** | System configuration | "Python 3.12, Ubuntu 22.04, Docker installed" |

### Configuration

```toml
[memory]
embedding_model = "text-embedding-3-small"
embedding_dimensions = 1536
vector_backend = "chroma"  # chroma, faiss, pinecone, qdrant, memory
long_term_memories_per_query = 5
consolidation_interval = 3600  # seconds
decay_rate = 0.1
max_memory_size = 10000
```

### How It Works

1. At the end of each session, memories are consolidated
2. Similar memories are merged or summarized
3. Each memory is embedded as a vector
4. When a new task starts, relevant memories are retrieved via semantic search
5. Memories decay over time if not accessed

## Memory Operations

### Storing Memories

Memories are stored automatically:

```python
# After a successful task
memory.store(
    category="task",
    content="Created a FastAPI project with JWT auth and PostgreSQL",
    metadata={"project": "my-api", "framework": "fastapi"}
)

# After fixing an error
memory.store(
    category="error",
    content="ModuleNotFoundError: install with 'pip install requests'",
    metadata={"error_type": "ImportError", "solution": "pip install"}
)
```

### Recalling Memories

```python
# Semantic search for relevant memories
memories = memory.recall(
    query="How to set up authentication?",
    category="pattern",  # Optional filter
    limit=5
)

# Search specific category
error_memories = memory.recall(
    query="database connection error",
    category="error"
)
```

### Searching Memories

```bash
# Via CLI
terminal-agent memory search "authentication patterns"
terminal-agent memory search --category error "import error"

# List all memories
terminal-agent memory list
terminal-agent memory list --category pattern
terminal-agent memory list --recent 7d

# Memory statistics
terminal-agent memory stats
```

### Clearing Memories

```bash
# Clear all memories
terminal-agent memory clear

# Clear specific category
terminal-agent memory clear --category error

# Clear memories for a project
terminal-agent memory clear --project my-project

# Clear old memories
terminal-agent memory clear --older-than 30d
```

### Exporting/Importing

```bash
# Export memories
terminal-agent memory export --output memories.json

# Import memories
terminal-agent memory import memories.json
```

## Memory Consolidation

Memories are consolidated periodically to maintain quality:

### Consolidation Process

1. **Group** — Similar memories are clustered by semantic similarity
2. **Merge** — 2-3 similar memories become one
3. **Summarize** — 4+ similar memories become a summary
4. **Deduplicate** — Memories with >95% similarity are merged
5. **Decay** — Old, unused memories have their relevance reduced
6. **Archive** — Memories not accessed in 365 days are archived

### Decay Schedule

| Last Accessed | Relevance Reduction |
|---------------|---------------------|
| 30 days | -10% |
| 90 days | -25% |
| 180 days | -50% |
| 365 days | Archive |

## Vector Store Backends

### ChromaDB (Default)

Local, no external dependencies. Best for most users.

```toml
[memory]
vector_backend = "chroma"
```

### FAISS

High-performance, local. Best for large memory stores.

```toml
[memory]
vector_backend = "faiss"
```

### Pinecone

Cloud-hosted. Best for team collaboration.

```toml
[memory]
vector_backend = "pinecone"

[memory.pinecone]
api_key = "..."
environment = "us-east1-gcp"
index_name = "terminal-agent"
```

### Qdrant

Local or cloud. Good balance of features and performance.

```toml
[memory]
vector_backend = "qdrant"

[memory.qdrant]
url = "http://localhost:6333"
```

### In-Memory

For testing and small datasets. No persistence.

```toml
[memory]
vector_backend = "memory"
```

## Context Assembly

The context manager uses memory to build prompts:

```
Context Window (128K tokens)
├── System Prompt (2K tokens) — Always included
├── Goal Statement (200 tokens) — Always included
├── Current Plan (500 tokens) — Always included
├── Environment Info (300 tokens) — Always included
├── Last 3 Turns (5K tokens) — Full detail
├── Working Memory (10K tokens) — Active files
├── Current Tool Output (5K tokens) — If relevant
├── Long-Term Memories (3K tokens) — Top 5 by similarity
├── Summarized History (2K tokens) — Older turns
└── Response Space (remaining tokens) — For LLM output
```

## Best Practices

1. **Be specific in tasks** — More specific tasks generate more useful memories
2. **Review memories periodically** — `terminal-agent memory list --recent 7d`
3. **Clear outdated memories** — Remove memories that are no longer relevant
4. **Use project-specific memories** — Different projects may have different conventions
5. **Export important memories** — Back up your memory store
