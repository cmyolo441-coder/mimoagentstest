# Cost Management

Terminal Agent tracks and manages LLM API costs to help you stay within budget.

## Cost Tracking

Every LLM call is tracked:

```bash
# View current session costs
terminal-agent metrics show

# View cost breakdown by model
terminal-agent metrics show --breakdown

# View historical costs
terminal-agent metrics session
```

### What's Tracked

| Metric | Description |
|--------|-------------|
| Tokens In | Input tokens sent to the LLM |
| Tokens Out | Output tokens received |
| Cost | Calculated cost per call |
| Cumulative | Total cost for the session |
| Per-Tool | Cost attributed to each tool |

## Cost Limits

### Per-Task Limit

Set a maximum cost per task:

```toml
[llm]
cost_limit_per_task = 5.00  # $5 per task
```

When the limit is reached:
1. The agent saves its current state
2. You're notified of the cost limit
3. You can choose to continue or stop

### Warning Threshold

Get warned before hitting the limit:

```toml
[llm]
cost_limit_per_task = 5.00
cost_warning_threshold = 0.80  # Warn at $4.00 (80%)
```

### Per-Session Limit

```toml
[llm]
cost_limit_per_session = 20.00  # $20 per session
```

## Cost Optimization Strategies

### 1. Use Cheaper Models for Simple Tasks

```toml
[llm]
primary_model = "gpt-4o"        # $5/1M input, $15/1M output
secondary_model = "gpt-4o-mini"  # $0.15/1M input, $0.60/1M output
```

The agent automatically uses the secondary model for:
- Summarization
- Formatting
- Simple text generation
- Commit messages

### 2. Enable Caching

Avoid redundant API calls:

```toml
[llm]
cache_responses = true
cache_ttl = 3600  # Cache for 1 hour

[cache]
backend = "disk"
max_size = 1000
```

### 3. Reduce Context Size

Smaller contexts = fewer tokens = lower cost:

```toml
[memory]
short_term_turns = 10  # Reduce from default 20
working_memory_files = 5  # Reduce from default 10
```

### 4. Use Local Models

Free inference with Ollama:

```toml
[llm]
primary_provider = "ollama"
primary_model = "llama3"
```

### 5. Set Temperature Lower

Lower temperature can produce more concise responses:

```toml
[llm]
temperature = 0.3  # More deterministic, often shorter
```

## Cost by Provider

| Provider | Model | Input (per 1M) | Output (per 1M) |
|----------|-------|----------------|-----------------|
| OpenAI | GPT-4o | $2.50 | $10.00 |
| OpenAI | GPT-4o-mini | $0.15 | $0.60 |
| Anthropic | Claude Opus | $15.00 | $75.00 |
| Anthropic | Claude Sonnet | $3.00 | $15.00 |
| Anthropic | Claude Haiku | $0.25 | $1.25 |
| Google | Gemini Pro | $1.25 | $5.00 |
| Google | Gemini Flash | $0.075 | $0.30 |
| Groq | Llama 3 70B | $0.59 | $0.79 |
| DeepSeek | DeepSeek V3 | $0.27 | $1.10 |
| Ollama | Any local model | Free | Free |

## Viewing Costs

### Current Session

```bash
terminal-agent metrics show
```

Output:
```
📊 Session Metrics
├── Tokens: 12,456 in / 3,200 out
├── Cost: $0.23
├── Cache Hits: 7 (73% hit rate)
├── Tools Called: 8
└── Duration: 00:03:45
```

### Historical Costs

```bash
terminal-agent metrics session --limit 30
```

### Cost by Model

```bash
terminal-agent metrics show --breakdown
```

### Export Cost Data

```bash
terminal-agent metrics export --format json > costs.json
```

## Budget Alerts

Configure email or webhook alerts:

```toml
[notifications]
webhook_url = "https://hooks.slack.com/..."

[notifications.budget]
daily_limit = 10.00
weekly_limit = 50.00
monthly_limit = 200.00
alert_threshold = 0.80
```

## Best Practices

1. **Set cost limits** — Always configure `cost_limit_per_task`
2. **Enable caching** — Reduces redundant API calls by 50-70%
3. **Use appropriate models** — Don't use GPT-4o for simple formatting
4. **Monitor regularly** — Check `terminal-agent metrics show` daily
5. **Use local models** — For sensitive data or free inference
6. **Optimize context** — Fewer tokens = lower cost
7. **Batch similar tasks** — Combine related tasks into one session
