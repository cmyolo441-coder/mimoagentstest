# CLI Reference

Complete reference for all Terminal Agent CLI commands.

## Global Options

```bash
terminal-agent [OPTIONS] COMMAND [ARGS]
```

| Option | Short | Description |
|--------|-------|-------------|
| `--version` | `-V` | Show version and exit |
| `--help` | `-h` | Show help and exit |
| `--config PATH` | `-c` | Path to configuration file |
| `--verbose` | `-v` | Enable verbose output |
| `--quiet` | `-q` | Suppress non-essential output |
| `--debug` | | Enable debug output |
| `--no-color` | | Disable colored output |
| `--safety-level N` | | Override safety level (0-5) |

## Commands

### `run` — Execute a Task

Run a one-shot task with the agent.

```bash
terminal-agent run [OPTIONS] GOAL
```

**Arguments:**
- `GOAL` — The task description in natural language

**Options:**

| Option | Short | Description |
|--------|-------|-------------|
| `--model MODEL` | `-m` | LLM model to use |
| `--provider PROVIDER` | `-p` | LLM provider to use |
| `--temperature FLOAT` | `-t` | Temperature (0.0-2.0) |
| `--max-tokens INT` | | Maximum response tokens |
| `--timeout INT` | | Task timeout in seconds |
| `--safety-level N` | `-s` | Safety level (0-5) |
| `--dry-run` | | Show plan without executing |
| `--no-stream` | | Disable streaming output |
| `--session-id ID` | | Resume a specific session |
| `--output FORMAT` | `-o` | Output format (text, json, markdown) |
| `--quiet` | `-q` | Suppress progress output |

**Examples:**

```bash
# Simple task
terminal-agent run "Create a hello world Python script"

# With specific model
terminal-agent run --model gpt-4o "Refactor the authentication module"

# Dry run (show plan only)
terminal-agent run --dry-run "Set up a CI/CD pipeline"

# Resume a session
terminal-agent run --session-id abc123 "Continue with the database setup"

# Quiet mode with JSON output
terminal-agent run -q -o json "Analyze code quality" > report.json
```

### `chat` — Interactive Chat

Start an interactive chat session with the agent.

```bash
terminal-agent chat [OPTIONS]
```

**Options:**

| Option | Short | Description |
|--------|-------|-------------|
| `--model MODEL` | `-m` | LLM model to use |
| `--provider PROVIDER` | `-p` | LLM provider to use |
| `--safety-level N` | `-s` | Safety level (0-5) |
| `--session-id ID` | | Resume a specific session |
| `--theme THEME` | `-t` | TUI theme (dark, light, solarized, monokai, high_contrast) |

**Chat Commands:**

While in chat mode, you can use these commands:

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/plan` | Show current plan |
| `/history` | Show conversation history |
| `/clear` | Clear the screen |
| `/save` | Save the current session |
| `/undo` | Undo the last action |
| `/redo` | Redo the last undone action |
| `/config` | Show/edit configuration |
| `/tools` | List available tools |
| `/memory` | Search memories |
| `/metrics` | Show session metrics |
| `/export` | Export session data |
| `/exit` | Exit the chat |

### `config` — Manage Configuration

View and modify Terminal Agent configuration.

```bash
terminal-agent config COMMAND [OPTIONS]
```

**Subcommands:**

#### `config show`

```bash
terminal-agent config show [SECTION]
```

Show all configuration or a specific section.

```bash
terminal-agent config show          # Show all
terminal-agent config show llm      # Show LLM section
terminal-agent config show safety   # Show safety section
```

#### `config get`

```bash
terminal-agent config get KEY
```

Get a specific configuration value.

```bash
terminal-agent config get llm.primary_model
terminal-agent config get safety.level
```

#### `config set`

```bash
terminal-agent config set KEY VALUE
```

Set a configuration value.

```bash
terminal-agent config set llm.primary_model gpt-4o
terminal-agent config set safety.level 3
terminal-agent config set llm.temperature 0.5
```

#### `config reset`

```bash
terminal-agent config reset [KEY]
```

Reset configuration to defaults.

```bash
terminal-agent config reset llm.temperature  # Reset one key
terminal-agent config reset --all            # Reset everything
```

#### `config validate`

```bash
terminal-agent config validate
```

Validate the current configuration.

#### `config profile`

```bash
terminal-agent config profile list           # List profiles
terminal-agent config profile create NAME    # Create profile
terminal-agent config profile use NAME       # Switch profile
terminal-agent config profile delete NAME    # Delete profile
```

### `sessions` — Manage Sessions

View and manage past sessions.

```bash
terminal-agent sessions COMMAND [OPTIONS]
```

**Subcommands:**

#### `sessions list`

```bash
terminal-agent sessions list [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--limit N` | Maximum sessions to show |
| `--status STATUS` | Filter by status (completed, failed, running) |
| `--format FORMAT` | Output format (table, json) |

#### `sessions show`

```bash
terminal-agent sessions show SESSION_ID
```

Show details of a specific session.

#### `sessions resume`

```bash
terminal-agent sessions resume SESSION_ID
```

Resume a paused or interrupted session.

#### `sessions delete`

```bash
terminal-agent sessions delete SESSION_ID
```

Delete a session and its associated data.

#### `sessions clear`

```bash
terminal-agent sessions clear [--all]
```

Clear old sessions.

#### `sessions export`

```bash
terminal-agent sessions export SESSION_ID [--format FORMAT]
```

Export a session's data.

### `history` — Command History

```bash
terminal-agent history [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--limit N` | Maximum entries to show |
| `--search TEXT` | Search history |
| `--format FORMAT` | Output format |

### `tools` — Manage Tools

```bash
terminal-agent tools COMMAND
```

**Subcommands:**

```bash
terminal-agent tools list              # List all tools
terminal-agent tools list --enabled    # List enabled tools only
terminal-agent tools info TOOL_NAME    # Show tool details
terminal-agent tools enable TOOL_NAME  # Enable a tool
terminal-agent tools disable TOOL_NAME # Disable a tool
terminal-agent tools test TOOL_NAME    # Test a tool
```

### `models` — Manage Models

```bash
terminal-agent models COMMAND
```

**Subcommands:**

```bash
terminal-agent models list             # List available models
terminal-agent models list --provider  # List by provider
terminal-agent models info MODEL       # Show model details
terminal-agent models test MODEL       # Test a model connection
```

### `plugins` — Manage Plugins

```bash
terminal-agent plugins COMMAND
```

**Subcommands:**

```bash
terminal-agent plugins list            # List installed plugins
terminal-agent plugins search QUERY    # Search for plugins
terminal-agent plugins install NAME    # Install a plugin
terminal-agent plugins uninstall NAME  # Uninstall a plugin
terminal-agent plugins enable NAME     # Enable a plugin
terminal-agent plugins disable NAME    # Disable a plugin
terminal-agent plugins info NAME       # Show plugin details
terminal-agent plugins validate NAME   # Validate a plugin
```

### `mcp` — Manage MCP Connections

```bash
terminal-agent mcp COMMAND
```

**Subcommands:**

```bash
terminal-agent mcp list                # List MCP servers
terminal-agent mcp add URL             # Add an MCP server
terminal-agent mcp remove NAME         # Remove an MCP server
terminal-agent mcp tools NAME          # List tools from an MCP server
terminal-agent mcp test NAME           # Test MCP connection
```

### `memory` — Manage Memory

```bash
terminal-agent memory COMMAND
```

**Subcommands:**

```bash
terminal-agent memory search QUERY     # Search memories
terminal-agent memory list [OPTIONS]   # List memories
terminal-agent memory stats            # Show memory statistics
terminal-agent memory clear [OPTIONS]  # Clear memories
terminal-agent memory export           # Export memories
terminal-agent memory import FILE      # Import memories
```

### `health` — System Health Check

```bash
terminal-agent health [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--full` | Run comprehensive check |
| `--fix` | Attempt to fix issues |

### `metrics` — View Metrics

```bash
terminal-agent metrics COMMAND
```

**Subcommands:**

```bash
terminal-agent metrics show            # Show current metrics
terminal-agent metrics session         # Show session metrics
terminal-agent metrics export          # Export metrics
```

### `traces` — View Execution Traces

```bash
terminal-agent traces COMMAND
```

**Subcommands:**

```bash
terminal-agent traces list             # List traces
terminal-agent traces show TRACE_ID    # Show a trace
terminal-agent traces compare ID1 ID2  # Compare two traces
terminal-agent traces export TRACE_ID  # Export a trace
```

### `update` — Self Update

```bash
terminal-agent update [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--check` | Check for updates without installing |
| `--version VER` | Install a specific version |

### `export` — Export Data

```bash
terminal-agent export [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--format FORMAT` | Export format (json, yaml, markdown) |
| `--output PATH` | Output file path |
| `--include-traces` | Include execution traces |
| `--include-memories` | Include memories |

### `import` — Import Data

```bash
terminal-agent import FILE [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--type TYPE` | Import type (memories, config, session) |

## Shell Completion

Generate shell completion scripts:

```bash
# Bash
terminal-agent completion bash >> ~/.bashrc

# Zsh
terminal-agent completion zsh >> ~/.zshrc

# Fish
terminal-agent completion fish > ~/.config/fish/completions/terminal-agent.fish
```

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | General error |
| 2 | Misuse of shell command |
| 3 | Task failed (unrecoverable error) |
| 4 | Safety violation |
| 5 | Budget exceeded |
| 6 | Timeout |
| 126 | Permission denied |
| 127 | Command not found |
| 130 | Interrupted (Ctrl+C) |
