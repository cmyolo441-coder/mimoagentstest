# Configuration Reference

Complete reference for all Terminal Agent configuration options.

## Configuration File Location

- **Global**: `~/.terminal-agent/config.toml`
- **Project**: `./.agent/project.toml`
- **Local overrides**: `~/.terminal-agent/config.local.toml` (not version-controlled)

## Precedence Order

1. CLI flags (highest priority)
2. Environment variables
3. Project config (`./.agent/project.toml`)
4. Global config (`~/.terminal-agent/config.toml`)
5. Built-in defaults (lowest priority)

---

## `[general]` — General Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `log_level` | string | `"INFO"` | Logging level: `DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL` |
| `theme` | string | `"dark"` | TUI theme: `dark`, `light`, `solarized`, `monokai`, `high_contrast` |
| `safety_level` | int | `2` | Safety level (0-5) |
| `confirm_destructive` | bool | `true` | Require confirmation for destructive actions |
| `auto_save_sessions` | bool | `true` | Automatically save sessions |
| `max_session_duration` | int | `3600` | Maximum session duration in seconds |
| `telemetry` | bool | `false` | Send anonymous usage telemetry |

**Environment variables:**
```bash
TERMINAL_AGENT_GENERAL_LOG_LEVEL=DEBUG
TERMINAL_AGENT_GENERAL_THEME=light
TERMINAL_AGENT_GENERAL_SAFETY_LEVEL=3
```

---

## `[llm]` — LLM Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `primary_provider` | string | `"openai"` | Primary LLM provider |
| `primary_model` | string | `"gpt-4o"` | Primary model name |
| `fallback_providers` | list | `[]` | Fallback provider chain |
| `temperature` | float | `0.7` | Sampling temperature (0.0-2.0) |
| `max_tokens` | int | `4096` | Maximum response tokens |
| `timeout` | int | `120` | Request timeout in seconds |
| `streaming` | bool | `true` | Enable streaming responses |
| `cache_responses` | bool | `true` | Cache LLM responses |
| `cache_ttl` | int | `3600` | Cache time-to-live in seconds |
| `max_retries` | int | `3` | Maximum retry attempts |
| `retry_delay` | float | `1.0` | Delay between retries in seconds |
| `cost_limit_per_task` | float | `5.00` | Maximum cost per task in dollars |
| `cost_warning_threshold` | float | `0.80` | Warn at this fraction of cost limit |
| `code_model` | string | `null` | Model for code-specific tasks |
| `secondary_model` | string | `null` | Model for simpler tasks |
| `embedding_model` | string | `"text-embedding-3-small"` | Model for embeddings |

**Environment variables:**
```bash
TERMINAL_AGENT_LLM_PRIMARY_PROVIDER=anthropic
TERMINAL_AGENT_LLM_PRIMARY_MODEL=claude-opus-4-20250514
TERMINAL_AGENT_LLM_TEMPERATURE=0.5
```

---

## `[llm.openai]` — OpenAI Provider

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `api_key` | string | `null` | OpenAI API key (encrypted at rest) |
| `organization` | string | `null` | OpenAI organization ID |
| `base_url` | string | `"https://api.openai.com/v1"` | API base URL |

**Environment variables:**
```bash
TERMINAL_AGENT_LLM_OPENAI_API_KEY=sk-...
OPENAI_API_KEY=sk-...  # Also recognized
```

---

## `[llm.anthropic]` — Anthropic Provider

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `api_key` | string | `null` | Anthropic API key (encrypted at rest) |
| `base_url` | string | `"https://api.anthropic.com"` | API base URL |

**Environment variables:**
```bash
TERMINAL_AGENT_LLM_ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_API_KEY=sk-ant-...  # Also recognized
```

---

## `[llm.google]` — Google Provider

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `api_key` | string | `null` | Google AI API key (encrypted at rest) |

**Environment variables:**
```bash
TERMINAL_AGENT_LLM_GOOGLE_API_KEY=...
GOOGLE_API_KEY=...  # Also recognized
```

---

## `[llm.ollama]` — Ollama Provider (Local)

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `base_url` | string | `"http://localhost:11434"` | Ollama server URL |
| `model` | string | `"llama3"` | Model name |

---

## `[llm.azure]` — Azure OpenAI Provider

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `api_key` | string | `null` | Azure API key (encrypted at rest) |
| `endpoint` | string | `null` | Azure endpoint URL |
| `api_version` | string | `"2024-02-01"` | API version |
| `deployment` | string | `null` | Deployment name |

---

## `[memory]` — Memory Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `short_term_turns` | int | `20` | Number of conversation turns to keep |
| `working_memory_files` | int | `10` | Max files in working memory |
| `long_term_memories_per_query` | int | `5` | Memories retrieved per query |
| `embedding_model` | string | `"text-embedding-3-small"` | Embedding model |
| `embedding_dimensions` | int | `1536` | Embedding vector dimensions |
| `vector_backend` | string | `"chroma"` | Vector store: `chroma`, `faiss`, `pinecone`, `qdrant`, `memory` |
| `consolidation_interval` | int | `3600` | Memory consolidation interval (seconds) |
| `decay_rate` | float | `0.1` | Memory relevance decay rate |
| `max_memory_size` | int | `10000` | Maximum stored memories |

---

## `[cache]` — Cache Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `backend` | string | `"disk"` | Cache backend: `memory`, `disk`, `database` |
| `max_size` | int | `1000` | Maximum cache entries |
| `ttl` | int | `3600` | Cache TTL in seconds |
| `eviction` | string | `"lru"` | Eviction strategy: `lru`, `lfu`, `fifo` |

---

## `[tools]` — Tool Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `enabled` | list | (all) | List of enabled tool categories |
| `shell_timeout` | int | `300` | Shell command timeout (seconds) |
| `shell_max_output` | int | `100000` | Max shell output characters |
| `filesystem_max_read` | int | `1000000` | Max file read size (bytes) |
| `confirm_delete` | bool | `true` | Confirm file deletions |
| `backup_before_edit` | bool | `true` | Backup files before editing |

---

## `[safety]` — Safety Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `level` | int | `2` | Safety level (0-5) |
| `blocked_patterns` | list | `[]` | Additional blocked command patterns |
| `allowed_paths` | list | `[]` | Additional allowed paths |
| `blocked_paths` | list | `[]` | Additional blocked paths |
| `sandbox_mode` | bool | `false` | Run in sandboxed environment |
| `audit_log` | bool | `true` | Log all safety decisions |

---

## `[rate_limiting]` — Rate Limiting

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `llm_calls_per_minute` | int | `60` | LLM API calls per minute |
| `tool_calls_per_minute` | int | `120` | Tool executions per minute |
| `burst_allowance` | int | `10` | Allowed burst above sustained rate |

---

## `[logging]` — Logging Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `level` | string | `"INFO"` | Log level |
| `format` | string | `"json"` | Log format: `json`, `text` |
| `file` | string | `"~/.terminal-agent/logs/agent.log"` | Log file path |
| `max_size` | int | `10485760` | Max log file size (bytes, 10MB) |
| `backup_count` | int | `5` | Number of rotated log files |
| `console` | bool | `true` | Also log to console |

---

## `[plugins]` — Plugin Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `enabled` | bool | `true` | Enable plugin system |
| `directories` | list | `["~/.terminal-agent/plugins"]` | Plugin directories |
| `auto_discover` | bool | `true` | Auto-discover plugins |
| `sandbox` | bool | `true` | Run plugins in sandbox |

---

## `[mcp]` — MCP Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `servers` | list | `[]` | MCP server configurations |
| `timeout` | int | `30` | MCP request timeout (seconds) |
| `retries` | int | `3` | MCP retry attempts |

---

## `[export]` — Export Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `format` | string | `"json"` | Default export format: `json`, `yaml`, `markdown` |
| `include_traces` | bool | `true` | Include execution traces in exports |
| `include_memories` | bool | `false` | Include memories in exports |

---

## Full Example Configuration

```toml
[general]
log_level = "INFO"
theme = "dark"
safety_level = 2
confirm_destructive = true
auto_save_sessions = true
max_session_duration = 3600
telemetry = false

[llm]
primary_provider = "openai"
primary_model = "gpt-4o"
fallback_providers = ["anthropic", "ollama"]
temperature = 0.7
max_tokens = 4096
timeout = 120
streaming = true
cache_responses = true
cache_ttl = 3600
max_retries = 3
retry_delay = 1.0
cost_limit_per_task = 5.00
cost_warning_threshold = 0.80
code_model = "deepseek-coder"
secondary_model = "gpt-4o-mini"
embedding_model = "text-embedding-3-small"

[llm.openai]
api_key = "sk-..."
organization = "org-..."

[llm.anthropic]
api_key = "sk-ant-..."

[llm.ollama]
base_url = "http://localhost:11434"
model = "llama3"

[memory]
short_term_turns = 20
working_memory_files = 10
long_term_memories_per_query = 5
embedding_model = "text-embedding-3-small"
embedding_dimensions = 1536
vector_backend = "chroma"
consolidation_interval = 3600
decay_rate = 0.1
max_memory_size = 10000

[cache]
backend = "disk"
max_size = 1000
ttl = 3600
eviction = "lru"

[tools]
enabled = ["shell", "filesystem", "code", "git", "package_manager",
           "database", "docker", "network", "search", "testing",
           "code_generation", "documentation", "devops"]
shell_timeout = 300
shell_max_output = 100000
filesystem_max_read = 1000000
confirm_delete = true
backup_before_edit = true

[safety]
level = 2
blocked_patterns = []
allowed_paths = []
blocked_paths = []
sandbox_mode = false
audit_log = true

[rate_limiting]
llm_calls_per_minute = 60
tool_calls_per_minute = 120
burst_allowance = 10

[logging]
level = "INFO"
format = "json"
file = "~/.terminal-agent/logs/agent.log"
max_size = 10485760
backup_count = 5
console = true

[plugins]
enabled = true
directories = ["~/.terminal-agent/plugins"]
auto_discover = true
sandbox = true

[mcp]
servers = []
timeout = 30
retries = 3

[export]
format = "json"
include_traces = true
include_memories = false
```
