# Plugin System

Terminal Agent's plugin system allows you to extend its capabilities with custom tools, providers, and more.

## Overview

Plugins can:
- Register new tools
- Add new LLM providers
- Add new memory backends
- Hook into lifecycle events
- Add CLI subcommands
- Add TUI screens

## Managing Plugins

### List Installed Plugins

```bash
terminal-agent plugins list
```

### Search for Plugins

```bash
terminal-agent plugins search "web scraping"
```

### Install a Plugin

```bash
terminal-agent plugins install web-tools
```

### Uninstall a Plugin

```bash
terminal-agent plugins uninstall web-tools
```

### Enable/Disable Plugins

```bash
terminal-agent plugins enable web-tools
terminal-agent plugins disable web-tools
```

### Validate a Plugin

```bash
terminal-agent plugins validate web-tools
```

## Plugin Structure

Each plugin is a directory with the following structure:

```
my-plugin/
├── manifest.toml        # Plugin metadata and configuration
├── __init__.py          # Python package init
├── main.py              # Entry point
├── tools.py             # Tool definitions (optional)
├── config.py            # Configuration schema (optional)
├── tests/
│   └── test_my_plugin.py
└── README.md
```

### manifest.toml

```toml
[plugin]
name = "my-plugin"
version = "1.0.0"
author = "Your Name"
description = "A custom plugin for Terminal Agent"
license = "MIT"
requires_terminal_agent = ">=0.1.0"

[dependencies]
packages = ["requests", "beautifulsoup4"]

[tools]
provides = ["web_scrape", "api_call"]

[hooks]
before_tool = true
after_tool = true
on_error = true
```

### main.py

```python
from terminal_agent.plugins.api import PluginBase, PluginContext

class MyPlugin(PluginBase):
    """Custom plugin for Terminal Agent."""

    name = "my-plugin"
    version = "1.0.0"

    async def initialize(self, context: PluginContext) -> None:
        """Called when the plugin is loaded."""
        self.context = context
        # Register tools
        context.register_tool("web_scrape", self.web_scrape)
        context.register_tool("api_call", self.api_call)

    async def web_scrape(self, url: str, selector: str = None) -> str:
        """Scrape content from a web page."""
        import requests
        from bs4 import BeautifulSoup

        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")

        if selector:
            elements = soup.select(selector)
            return "\n".join(el.get_text() for el in elements)
        return soup.get_text()

    async def api_call(self, url: str, method: str = "GET", 
                       data: dict = None, headers: dict = None) -> dict:
        """Make an API call."""
        import requests

        response = requests.request(method, url, json=data, headers=headers)
        return {
            "status": response.status_code,
            "headers": dict(response.headers),
            "body": response.json() if response.headers.get("content-type", "").startswith("application/json") else response.text,
        }

    async def cleanup(self) -> None:
        """Called when the plugin is unloaded."""
        pass
```

## Built-in Plugins

Terminal Agent ships with several example plugins:

### web-tools

Web scraping and browser automation.

```bash
terminal-agent plugins install web-tools
```

Tools: `web_scrape`, `browser_navigate`, `browser_click`, `browser_screenshot`

### api-tools

API client generation and testing.

```bash
terminal-agent plugins install api-tools
```

Tools: `openapi_parse`, `client_generate`, `api_test`

### cloud-tools

Cloud resource management (AWS, GCP, Azure).

```bash
terminal-agent plugins install cloud-tools
```

Tools: `aws_cli`, `gcp_cli`, `azure_cli`

### security-tools

Security scanning and auditing.

```bash
terminal-agent plugins install security-tools
```

Tools: `vulnerability_scan`, `dependency_audit`, `secret_scan`

### data-tools

Data processing (CSV, JSON, Parquet, Excel).

```bash
terminal-agent plugins install data-tools
```

Tools: `csv_process`, `json_transform`, `parquet_read`, `excel_convert`

## Plugin Configuration

Plugins can define their own configuration:

```toml
# In ~/.terminal-agent/config.toml
[plugins.my-plugin]
api_key = "..."
max_results = 10
timeout = 30
```

## Plugin Hooks

Plugins can hook into lifecycle events:

```python
class MyPlugin(PluginBase):
    async def before_tool(self, tool_name: str, parameters: dict) -> dict:
        """Called before any tool executes."""
        # Modify parameters, log, or block
        return parameters

    async def after_tool(self, tool_name: str, parameters: dict, result: dict) -> dict:
        """Called after any tool executes."""
        # Post-process results, log, or alert
        return result

    async def on_error(self, tool_name: str, error: Exception) -> bool:
        """Called when a tool fails."""
        # Return True to suppress the error, False to propagate
        return False
```

## Plugin Sandbox

By default, plugins run in a sandbox with restricted permissions:

```toml
[plugins]
sandbox = true  # Default
```

Sandbox restrictions:
- Limited file system access
- No network access (unless explicitly allowed)
- No subprocess execution
- Resource limits (CPU, memory)

Disable sandbox for trusted plugins:

```toml
[plugins.my-trusted-plugin]
sandbox = false
```

## Plugin Marketplace

Browse and install community plugins:

```bash
# Search marketplace
terminal-agent plugins search "database"

# Install from marketplace
terminal-agent plugins install community/db-tools

# Publish your plugin
terminal-agent plugins publish ./my-plugin
```

## Best Practices

1. **Validate plugins** before installing: `terminal-agent plugins validate`
2. **Use sandbox mode** for untrusted plugins
3. **Pin plugin versions** in production
4. **Write tests** for your plugins
5. **Document your plugin** with a README
6. **Follow the plugin API** — don't import internal modules
7. **Handle errors gracefully** — plugins should not crash the agent
