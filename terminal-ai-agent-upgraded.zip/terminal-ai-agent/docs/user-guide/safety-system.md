# Safety System

Terminal Agent's safety system protects your system from harmful operations while allowing productive work.

## Safety Levels

| Level | Name | Description | Use Case |
|-------|------|-------------|----------|
| 0 | Unrestricted | No safety checks | Development/testing only |
| 1 | Minimal | Block catastrophic commands | Sandboxed environments |
| 2 | Standard | Block destructive, confirm modifications | **Default** |
| 3 | Moderate | Confirm all writes and executions | Shared environments |
| 4 | Strict | Confirm everything, read-only default | Production environments |
| 5 | Review | Plan only, no execution | Auditing and learning |

### Setting the Safety Level

```bash
# Via config
terminal-agent config set safety.level 2

# Via CLI flag
terminal-agent run --safety-level 3 "your task"

# Via environment variable
export TERMINAR_AGENT_SAFETY_LEVEL=2
```

## What Each Level Allows

### Level 0 — Unrestricted

- No command blocking
- No confirmation prompts
- No path restrictions
- **Never use in production**

### Level 1 — Minimal

**Blocked:**
- Recursive deletion of root/system directories
- Fork bombs
- Disk overwrite commands (dd if=/dev/zero)
- Bootloader modification
- Kernel module manipulation

**Allowed without confirmation:** Everything else

### Level 2 — Standard (Default)

**Blocked (same as Level 1):**
- All catastrophic commands

**Requires confirmation:**
- File/directory deletions
- Database write operations (INSERT, UPDATE, DELETE, DROP)
- Git force operations (push --force, reset --hard)
- Package manager global installs
- System service manipulation
- File permission changes

**Path restrictions:**
- `/etc`, `/boot`, `/sys`, `/dev` — restricted
- Other users' home directories — restricted
- SSH keys and credentials — restricted

### Level 3 — Moderate

**All Level 2 protections plus:**
- All file writes require confirmation
- All command executions require confirmation
- All package installations require confirmation

### Level 4 — Strict

**All Level 3 protections plus:**
- Everything that modifies anything requires confirmation
- Read-only by default
- Must explicitly opt in for each tool category

### Level 5 — Review

- Plans only, no execution
- Shows what would be done
- User must approve each action individually

## Blocked Command Patterns

### Always Blocked (Level 1+)

```
rm -rf /
rm -rf /*
rm -rf ~
:(){ :|:& };:          # Fork bomb
dd if=/dev/zero of=/
mkfs.*
fdisk /dev/sda
chmod -R 777 /
chown -R root /
```

### Blocked at Level 2+

```
DROP DATABASE
DROP TABLE
DELETE FROM * WHERE 1=1
git push --force
git reset --hard
npm install -g *
pip install --break-system-packages
systemctl stop *
systemctl disable *
```

### Custom Patterns

Add your own blocked patterns:

```toml
[safety]
blocked_patterns = [
    "kubectl delete namespace",
    "aws s3 rm --recursive",
    "terraform destroy",
]
```

## Path Restrictions

### Restricted Paths

| Path | Access |
|------|--------|
| `/etc` | Read-only |
| `/boot` | Blocked |
| `/sys` | Blocked |
| `/dev` | Blocked |
| `/proc` | Read-only |
| `~/.ssh` | Blocked |
| `~/.aws` | Blocked |
| `~/.gnupg` | Blocked |
| Other users' homes | Blocked |

### Custom Path Rules

```toml
[safety]
allowed_paths = ["/opt/myproject", "/data/shared"]
blocked_paths = ["/opt/myproject/secrets"]
```

## Confirmation Prompts

When a destructive action requires confirmation:

```
⚠️  Confirmation Required

The agent wants to execute:
  rm -rf build/ dist/ *.egg-info

This will permanently delete:
  • build/ (15 files, 2.3MB)
  • dist/ (3 files, 1.1MB)
  • *.egg-info (2 files)

[Y] Yes, proceed
[N] No, cancel
[A] Always allow for this session
[D] Show detailed diff
[S] Show full command
```

## Sandbox Mode

Run the agent in an isolated environment:

```toml
[safety]
sandbox_mode = true
```

Sandbox mode:
- Runs commands in a container or restricted environment
- Limits file system access to the current project
- Blocks network access (except configured endpoints)
- Limits resource usage (CPU, memory, disk)

## Audit Logging

All safety decisions are logged:

```toml
[safety]
audit_log = true
```

View audit log:

```bash
terminal-agent traces list --type safety
terminal-agent traces show <trace-id>
```

Audit log entries include:
- Timestamp
- Action attempted
- Safety decision (allowed/blocked/confirmed)
- Reason for decision
- User response (if confirmation was required)

## Emergency Stop

Press `Ctrl+C` at any time to:
1. Immediately stop the current operation
2. Save the current state
3. Allow you to resume later

## Best Practices

1. **Use Level 2 (default)** for daily work
2. **Use Level 3** for shared or production environments
3. **Use Level 4** when working with critical systems
4. **Review confirmation prompts** before approving
5. **Enable audit logging** for accountability
6. **Add custom patterns** for your specific risks
7. **Use sandbox mode** for untrusted tasks
