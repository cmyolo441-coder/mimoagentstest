# Tool Reference

Terminal Agent includes 40+ built-in tools across 13 categories. This reference documents every tool.

## Tool Categories

| Category | Tools | Description |
|----------|-------|-------------|
| Shell | 8 | Command execution, process management |
| Filesystem | 13 | File operations, search, metadata |
| Code | 19 | AST, refactoring, formatting, linting |
| Git | 18 | Full git integration |
| Package Manager | 25+ | Dependency management |
| Database | 10 | Query, migrate, backup |
| Docker | 9 | Container management |
| Network | 11 | HTTP, DNS, SSL, WebSocket |
| Search | 8 | Regex, semantic, symbol search |
| Testing | 10 | Run, parse, generate tests |
| Code Generation | 13 | Scaffolding, templates |
| Documentation | 11 | README, API docs, changelogs |
| DevOps | 15+ | K8s, Terraform, Ansible, CI/CD |

---

## Shell Tools

### `execute_command`

Execute a shell command.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `command` | string | Yes | Shell command to execute |
| `cwd` | string | No | Working directory |
| `env` | dict | No | Environment variables |
| `timeout` | int | No | Timeout in seconds (default: 300) |
| `capture` | bool | No | Capture output (default: true) |

**Returns:** stdout, stderr, exit_code, duration

### `execute_background`

Execute a command in the background.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `command` | string | Yes | Command to execute |
| `cwd` | string | No | Working directory |
| `env` | dict | No | Environment variables |

**Returns:** pid

### `kill_process`

Kill a running process.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `pid` | int | Yes | Process ID |
| `signal` | string | No | Signal to send (default: SIGTERM) |

### `list_processes`

List running processes.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `filter` | string | No | Filter by name or pattern |

---

## Filesystem Tools

### `read_file`

Read file contents.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `path` | string | Yes | File path |
| `offset` | int | No | Start line (1-indexed) |
| `limit` | int | No | Max lines to read |
| `encoding` | string | No | File encoding (default: utf-8) |

### `write_file`

Write content to a file.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `path` | string | Yes | File path |
| `content` | string | Yes | Content to write |
| `encoding` | string | No | File encoding |
| `backup` | bool | No | Create backup (default: true) |

### `edit_file`

Edit a file using search-and-replace.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `path` | string | Yes | File path |
| `old_text` | string | Yes | Text to find |
| `new_text` | string | Yes | Replacement text |

### `search_files`

Search for files by name or content.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `pattern` | string | Yes | Search pattern (glob or regex) |
| `path` | string | No | Directory to search |
| `content` | string | No | Search file contents |
| `file_type` | string | No | Filter by file type |

### `list_directory`

List directory contents.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `path` | string | Yes | Directory path |
| `recursive` | bool | No | List recursively |
| `pattern` | string | No | Filter pattern |
| `show_hidden` | bool | No | Include hidden files |

### `move_file`, `copy_file`, `delete_file`

File management operations.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `source` | string | Yes | Source path |
| `destination` | string | No | Destination path (for move/copy) |
| `recursive` | bool | No | Apply to directories |

### `get_file_metadata`

Get file metadata.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `path` | string | Yes | File path |

**Returns:** size, created, modified, permissions, encoding, type

---

## Code Tools

### `parse_ast`

Parse code into an abstract syntax tree.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `code` | string | Yes | Source code |
| `language` | string | Yes | Programming language |

### `extract_symbols`

Extract functions, classes, and variables from code.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `path` | string | Yes | File path |
| `symbol_type` | string | No | Filter: function, class, variable |

### `find_references`

Find all references to a symbol.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `symbol` | string | Yes | Symbol name |
| `path` | string | No | Directory to search |

### `rename_symbol`

Rename a symbol across files.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `old_name` | string | Yes | Current symbol name |
| `new_name` | string | Yes | New symbol name |
| `path` | string | No | Directory scope |

### `format_code`

Format code according to language standards.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `path` | string | Yes | File path |
| `formatter` | string | No | Specific formatter to use |

### `lint_code`

Lint code and report issues.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `path` | string | Yes | File path |
| `linter` | string | No | Specific linter to use |
| `fix` | bool | No | Auto-fix issues |

### `analyze_complexity`

Measure code complexity.

**Parameters:**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `path` | string | Yes | File path |

**Returns:** cyclomatic complexity, cognitive complexity, maintainability index

---

## Git Tools

### `git_status`, `git_add`, `git_commit`, `git_push`, `git_pull`

Standard git operations.

### `git_branch`, `git_merge`, `git_rebase`, `git_stash`

Branch management.

### `git_log`, `git_diff`, `git_blame`

History and inspection.

### `git_bisect`

Binary search for bug-introducing commits.

---

## Package Manager Tools

### `detect_package_manager`

Auto-detect the package manager for the current project.

### `install_package`, `uninstall_package`, `update_package`

Package management operations.

### `list_packages`, `search_packages`

Package discovery.

---

## Database Tools

### `db_connect`, `db_query`, `db_execute`

Database operations.

### `db_describe_schema`, `db_list_tables`

Schema inspection.

### `db_migrate`, `db_seed`

Migration and seeding.

---

## Docker Tools

### `docker_build`, `docker_run`, `docker_stop`

Container lifecycle.

### `docker_compose_up`, `docker_compose_down`

Compose operations.

### `docker_logs`, `docker_exec`

Inspection and execution.

---

## Network Tools

### `http_request`

Make HTTP requests.

### `check_dns`, `check_ssl`, `check_port`

Network diagnostics.

### `websocket_connect`, `grpc_call`, `graphql_query`

Protocol-specific clients.

---

## Search Tools

### `regex_search`

Search files using regex patterns.

### `semantic_search`

Search using vector embeddings.

### `symbol_search`, `definition_search`, `reference_search`

Code-aware search.

### `web_search`

Search the web.

---

## Testing Tools

### `run_tests`

Run tests using any framework.

### `parse_test_results`

Parse test output.

### `generate_tests`

Generate test files for existing code.

### `analyze_coverage`

Generate and analyze coverage reports.

---

## Tool Configuration

Tools can be enabled/disabled in configuration:

```toml
[tools]
enabled = ["shell", "filesystem", "code", "git", "testing"]
shell_timeout = 300
confirm_delete = true
```

## Tool Safety

Each tool is evaluated by the safety system before execution. Tools are classified as:

- **Safe** — Read-only operations (read_file, list_directory, search)
- **Moderate** — Write operations with backup (write_file, edit_file)
- **Destructive** — Irreversible operations (delete_file, drop_table)
- **Dangerous** — System-level operations (execute_command, docker_run)

The safety level determines what requires confirmation.
