# Multi-Model Configuration

Terminal Agent supports using multiple LLM models for different purposes, optimizing for quality, speed, and cost.

## Model Roles

| Role | Purpose | Recommended Models |
|------|---------|-------------------|
| **Primary** | Main reasoning and planning | GPT-4o, Claude Opus, Gemini Ultra |
| **Code** | Code generation and analysis | DeepSeek Coder, CodeLlama, GPT-4o |
| **Secondary** | Simple tasks (formatting, summarization) | GPT-4o-mini, Claude Haiku, Gemini Flash |
| **Embedding** | Memory embeddings | text-embedding-3-small, nomic-embed |
| **Local** | Offline and sensitive operations | Llama 3, Mistral, Phi |

## Configuration

### Single Model (Simple)

```toml
[llm]
primary_provider = "openai"
primary_model = "gpt-4o"
```

### Multi-Model (Recommended)

```toml
[llm]
primary_provider = "openai"
primary_model = "gpt-4o"

# For code-specific tasks
code_provider = "deepseek"
code_model = "deepseek-coder"

# For simpler tasks (cheaper, faster)
secondary_provider = "openai"
secondary_model = "gpt-4o-mini"

# For embeddings
embedding_model = "text-embedding-3-small"

# Fallback chain
fallback_providers = ["anthropic", "ollama"]
```

### Model Switching

The orchestrator automatically routes tasks to the appropriate model:

| Task Type | Model Used |
|-----------|------------|
| Planning and reasoning | Primary |
| Code generation | Code model |
| Summarization | Secondary |
| Formatting | Secondary |
| Memory embedding | Embedding model |
| Error analysis | Primary |
| Commit messages | Secondary |

## Provider Configuration

### OpenAI

```toml
[llm.openai]
api_key = "sk-..."
organization = "org-..."
base_url = "https://api.openai.com/v1"
```

### Anthropic

```toml
[llm.anthropic]
api_key = "sk-ant-..."
base_url = "https://api.anthropic.com"
```

### Google Gemini

```toml
[llm.google]
api_key = "..."
```

### Ollama (Local)

```toml
[llm.ollama]
base_url = "http://localhost:11434"
model = "llama3"
```

### DeepSeek

```toml
[llm.deepseek]
api_key = "..."
base_url = "https://api.deepseek.com"
```

### Groq (Fast Inference)

```toml
[llm.groq]
api_key = "..."
```

### Azure OpenAI

```toml
[llm.azure]
api_key = "..."
endpoint = "https://my-resource.openai.azure.com"
api_version = "2024-02-01"
deployment = "gpt-4o"
```

### AWS Bedrock

```toml
[llm.bedrock]
region = "us-east-1"
model_id = "anthropic.claude-3-5-sonnet-20241022-v2:0"
```

### Custom OpenAI-Compatible

```toml
[llm.custom]
api_key = "..."
base_url = "https://my-api.example.com/v1"
model = "my-model"
```

## Provider Fallback

If the primary provider fails, Terminal Agent tries the next one:

```toml
[llm]
primary_provider = "openai"
fallback_providers = ["anthropic", "groq", "ollama"]
```

Fallback triggers:
- API timeout
- Rate limit exceeded
- Provider error (5xx)
- Authentication failure

## Per-Task Model Override

Override the model for a specific task:

```bash
# Use a specific model
terminal-agent run --model claude-opus-4-20250514 "your task"

# Use a specific provider
terminal-agent run --provider anthropic "your task"

# Use local model
terminal-agent run --provider ollama --model llama3 "your task"
```

## Cost Optimization

### Strategy 1: Use Cheaper Models for Simple Tasks

```toml
[llm]
primary_model = "gpt-4o"        # Complex tasks
secondary_model = "gpt-4o-mini"  # Simple tasks
```

### Strategy 2: Use Local Models for Sensitive Data

```toml
[llm]
primary_provider = "ollama"
primary_model = "llama3"
```

### Strategy 3: Set Cost Limits

```toml
[llm]
cost_limit_per_task = 5.00
cost_warning_threshold = 0.80
```

## Provider Comparison

| Provider | Speed | Cost | Quality | Local |
|----------|-------|------|---------|-------|
| OpenAI | Fast | Medium | High | No |
| Anthropic | Medium | Medium | High | No |
| Google | Fast | Low | High | No |
| Groq | Very Fast | Low | Medium | No |
| DeepSeek | Fast | Low | High (code) | No |
| Ollama | Variable | Free | Variable | Yes |

## Best Practices

1. **Start with one provider** — Get comfortable before adding more
2. **Use fallbacks** — Always configure at least one fallback
3. **Match model to task** — Use cheaper models for simple tasks
4. **Monitor costs** — Check `terminal-agent metrics show` regularly
5. **Use local models for sensitive data** — Keeps data on your machine
6. **Test provider switching** — Verify fallback works before relying on it
