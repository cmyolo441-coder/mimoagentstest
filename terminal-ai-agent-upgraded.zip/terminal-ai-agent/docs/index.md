# Terminal Agent Documentation

Welcome to the official documentation for **Terminal Agent** — the most powerful terminal-based autonomous AI agent.

## Quick Navigation

### Getting Started

New to Terminal Agent? Start here.

- [Installation](getting-started/installation.md) — Install Terminal Agent on your system
- [Quick Start](getting-started/quickstart.md) — Get up and running in 5 minutes
- [Your First Task](getting-started/first-task.md) — Walk through your first autonomous task
- [Configuration](getting-started/configuration.md) — Set up your LLM provider and preferences
- [Troubleshooting](getting-started/troubleshooting.md) — Common issues and solutions

### User Guide

Comprehensive guide for daily use.

- [CLI Reference](user-guide/cli-reference.md) — All commands, flags, and options
- [TUI Guide](user-guide/tui-guide.md) — Interactive terminal interface
- [Configuration Reference](user-guide/configuration-reference.md) — Every configuration option
- [Tool Reference](user-guide/tool-reference.md) — All 40+ built-in tools
- [Memory System](user-guide/memory-system.md) — Three-tier memory explained
- [Safety System](user-guide/safety-system.md) — Safety levels and guardrails
- [Plugin System](user-guide/plugin-system.md) — Extending Terminal Agent
- [MCP Integration](user-guide/mcp-integration.md) — Model Context Protocol
- [Multi-Model](user-guide/multi-model.md) — Using multiple LLM providers
- [Cost Management](user-guide/cost-management.md) — Tracking and controlling costs
- [Tips & Tricks](user-guide/tips-and-tricks.md) — Get the most out of Terminal Agent

### Developer Guide

For contributors and extenders.

- [Architecture Overview](developer-guide/architecture.md) — How Terminal Agent is built
- [Contributing](developer-guide/contributing.md) — How to contribute
- [Development Setup](developer-guide/development-setup.md) — Set up your dev environment
- [Testing](developer-guide/testing.md) — Running and writing tests
- [Adding Tools](developer-guide/adding-tools.md) — Create new tools
- [Adding Providers](developer-guide/adding-providers.md) — Add LLM providers
- [Adding Memory Backends](developer-guide/adding-memory-backends.md) — Custom memory stores
- [Plugin Development](developer-guide/plugin-development.md) — Build plugins
- [MCP Development](developer-guide/mcp-development.md) — MCP client and server
- [Release Process](developer-guide/release-process.md) — How releases are made

### Architecture

Deep dives into system design.

- [Overview](architecture/overview.md) — Four-layer architecture
- [Agent Loop](architecture/agent-loop.md) — Core Think-Act-Observe cycle
- [Memory Architecture](architecture/memory-architecture.md) — Three-tier memory system
- [Tool Architecture](architecture/tool-architecture.md) — Tool registry and execution
- [Safety Architecture](architecture/safety-architecture.md) — Safety and security
- [Self-Improvement](architecture/self-improvement.md) — Learning and optimization
- [Data Flow](architecture/data-flow.md) — How data moves through the system
- [Context Engineering](architecture/context-engineering.md) — Context assembly and management

### Architecture Diagrams

Visual representations of the system.

- [System Overview](architecture/diagrams/system-overview.md)
- [Agent Loop](architecture/diagrams/agent-loop.md)
- [Memory Tiers](architecture/diagrams/memory-tiers.md)
- [Tool Registry](architecture/diagrams/tool-registry.md)
- [Safety Layers](architecture/diagrams/safety-layers.md)
- [Data Flow](architecture/diagrams/data-flow.md)
- [Module Dependencies](architecture/diagrams/module-dependencies.md)

### API Reference

Programmatic interfaces.

- [CLI API](api/cli-api.md) — CLI module interfaces
- [Tool API](api/tool-api.md) — Tool development API
- [Plugin API](api/plugin-api.md) — Plugin development API
- [Memory API](api/memory-api.md) — Memory system API
- [Provider API](api/provider-api.md) — LLM provider API
- [MCP API](api/mcp-api.md) — MCP client and server API

### Tutorials

Step-by-step guides for real-world tasks.

- [Build a Web App](tutorials/build-web-app.md) — Create a full-stack web application
- [Fix a Bug](tutorials/fix-existing-bug.md) — Find and fix bugs in existing code
- [Refactor Code](tutorials/refactor-codebase.md) — Refactor for better architecture
- [Write Tests](tutorials/write-tests.md) — Generate comprehensive test suites
- [Set Up CI/CD](tutorials/setup-ci-cd.md) — Configure continuous integration
- [Deploy](tutorials/deploy-application.md) — Deploy to production
- [Database Migration](tutorials/database-migration.md) — Create and run migrations
- [Custom Plugin](tutorials/custom-plugin.md) — Build a custom plugin

### Other Resources

- [FAQ](faq.md) — Frequently asked questions
- [CHANGELOG](../CHANGELOG.md) — Version history
- [ROADMAP](../ROADMAP.md) — Future plans
- [CONTRIBUTING](../CONTRIBUTING.md) — How to contribute
- [SECURITY](../SECURITY.md) — Security policy
- [CODE_OF_CONDUCT](../CODE_OF_CONDUCT.md) — Community guidelines

## Documentation by Role

### I'm a New User
1. [Installation](getting-started/installation.md)
2. [Quick Start](getting-started/quickstart.md)
3. [Your First Task](getting-started/first-task.md)
4. [CLI Reference](user-guide/cli-reference.md)

### I'm a Daily User
1. [TUI Guide](user-guide/tui-guide.md)
2. [Tool Reference](user-guide/tool-reference.md)
3. [Memory System](user-guide/memory-system.md)
4. [Tips & Tricks](user-guide/tips-and-tricks.md)

### I'm a Power User
1. [Configuration Reference](user-guide/configuration-reference.md)
2. [Multi-Model](user-guide/multi-model.md)
3. [Plugin System](user-guide/plugin-system.md)
4. [MCP Integration](user-guide/mcp-integration.md)

### I'm a Contributor
1. [Development Setup](developer-guide/development-setup.md)
2. [Architecture Overview](developer-guide/architecture.md)
3. [Contributing](developer-guide/contributing.md)
4. [Testing](developer-guide/testing.md)

### I'm Building Extensions
1. [Plugin Development](developer-guide/plugin-development.md)
2. [Adding Tools](developer-guide/adding-tools.md)
3. [Adding Providers](developer-guide/adding-providers.md)
4. [Tool API](api/tool-api.md)
