# FAQ

Frequently asked questions about Terminal Agent.

## General

### What is Terminal Agent?

Terminal Agent is a fully autonomous AI agent that operates inside your terminal. It accepts goals in natural language, creates plans, executes them using 40+ built-in tools, verifies results, recovers from errors, and learns from every task.

### How is this different from GitHub Copilot / Cursor / Aider?

Terminal Agent is fully autonomous — it doesn't just suggest code, it executes complete multi-step tasks. It can run commands, manage git, install packages, run tests, manage databases, and deploy infrastructure. It's a true agent, not an autocomplete tool.

### What can it do?

Anything a developer can do in a terminal: write code (15+ languages), run commands, manage git (25+ package managers), query databases, build Docker containers, run tests, generate documentation, and manage infrastructure.

### Is it safe?

Yes. Terminal Agent has a 6-level safety system. The default (Level 2) blocks dangerous commands, requires confirmation for destructive actions, restricts sensitive directories, and logs everything. See [Safety System](user-guide/safety-system.md).

## Installation

### What are the requirements?

- Python 3.10+
- An LLM API key (OpenAI, Anthropic, Google) or local model (Ollama)
- Linux, macOS, or Windows (WSL)

### How do I install it?

```bash
pip install terminal-agent
```

Or with pipx: `pipx install terminal-agent`

### Can I use it offline?

Yes! Use Ollama with a local model:
```bash
terminal-agent config set llm.primary_provider ollama
terminal-agent config set llm.ollama.model llama3
```

## Configuration

### Where is the config file?

- Global: `~/.terminal-agent/config.toml`
- Project: `./.agent/project.toml`

### How do I set my API key?

```bash
terminal-agent config set llm.openai.api_key "sk-..."
# or
export TERMINAL_AGENT_LLM_OPENAI_API_KEY="sk-..."
```

### Can I use multiple providers?

Yes! Configure a primary and fallback chain:
```toml
[llm]
primary_provider = "openai"
fallback_providers = ["anthropic", "ollama"]
```

## Usage

### How do I run a task?

```bash
terminal-agent run "Create a REST API with Express and PostgreSQL"
```

### Can I stop the agent?

Yes! Press `Ctrl+C` to stop gracefully. State is saved and you can resume later.

### What if it makes a mistake?

The agent has 6-level error recovery: retry → modified retry → alternative approach → re-plan → ask user → graceful abort. You can also undo actions.

### Does it remember previous sessions?

Yes! Long-term memory stores knowledge across sessions using vector embeddings. The agent learns your style, patterns, and preferences.

## Models

### Which models are supported?

15+ providers: OpenAI (GPT-4o), Anthropic (Claude), Google (Gemini), Ollama (local), LiteLLM (100+ models), Azure, Bedrock, Groq, DeepSeek, and more.

### How do I switch models?

```bash
terminal-agent config set llm.primary_model "claude-opus-4-20250514"
terminal-agent config set llm.primary_provider "anthropic"
```

### Can I use different models for different tasks?

Yes! Configure multi-model routing:
```toml
[llm]
primary_model = "gpt-4o"
code_model = "deepseek-coder"
secondary_model = "gpt-4o-mini"
```

## Cost

### How much does it cost?

Cost depends on the LLM provider. Terminal Agent tracks costs and you can set limits:
```toml
[llm]
cost_limit_per_task = 5.00
```

### How do I minimize costs?

1. Use cheaper models for simple tasks
2. Use Ollama (free local inference)
3. Enable caching
4. Set cost limits

## Safety

### What safety levels are available?

| Level | Name | Description |
|-------|------|-------------|
| 0 | Unrestricted | No checks (dev only) |
| 1 | Minimal | Block catastrophic commands |
| 2 | Standard | Block destructive, confirm modifications (default) |
| 3 | Moderate | Confirm all writes and executions |
| 4 | Strict | Confirm everything, read-only default |
| 5 | Review | Plan only, no execution |

### Can I customize safety rules?

Yes! Add custom blocked patterns, allowed paths, and more in `config.toml`.

## Plugins

### Can I extend Terminal Agent?

Yes! Build plugins to add new tools, providers, memory backends, and more. See [Plugin Development](developer-guide/plugin-development.md).

### Where do I find plugins?

```bash
terminal-agent plugins search "web scraping"
terminal-agent plugins install web-tools
```

## Troubleshooting

### The agent is not responding

1. Check your API key
2. Check internet connectivity
3. Check provider status
4. Try a different provider

### The agent is making mistakes

1. Be more specific in your task
2. Provide more context
3. Use the TUI to see reasoning
4. Lower temperature: `terminal-agent config set llm.temperature 0.3`

### How do I enable debug logging?

```bash
terminal-agent config set general.log_level DEBUG
```

## Contributing

### How can I contribute?

See [CONTRIBUTING.md](../CONTRIBUTING.md). Fork, branch, code, test, PR!

### Where do I ask questions?

- [GitHub Discussions](https://github.com/terminal-agent/terminal-agent/discussions)
- [Discord](https://discord.gg/terminal-agent)
- [Stack Overflow](https://stackoverflow.com/questions/tagged/terminal-agent)
