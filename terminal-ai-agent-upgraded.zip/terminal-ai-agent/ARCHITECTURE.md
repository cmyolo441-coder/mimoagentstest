# Architecture

This document provides a comprehensive overview of Terminal Agent's architecture. For detailed documentation on each subsystem, see the [architecture docs](docs/architecture/overview.md).

## Table of Contents

- [System Overview](#system-overview)
- [Four-Layer Architecture](#four-layer-architecture)
- [Core Agent Loop](#core-agent-loop)
- [Module Map](#module-map)
- [Data Flow](#data-flow)
- [Design Principles](#design-principles)

## System Overview

Terminal Agent is organized into four major layers, each with clearly defined responsibilities and interfaces. The architecture prioritizes modularity, safety, extensibility, and performance.

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INTERFACE LAYER                       │
│         CLI (click)  │  TUI (textual)  │  Config (toml)      │
├─────────────────────────────────────────────────────────────┤
│                    INTELLIGENCE LAYER                         │
│  Orchestrator │ LLM Engine │ Memory │ Context │ Prompts      │
├─────────────────────────────────────────────────────────────┤
│                    CAPABILITY LAYER                           │
│  Shell │ Filesystem │ Code │ Git │ Packages │ Database       │
│  Docker │ Network │ Search │ Testing │ Docs │ DevOps         │
├─────────────────────────────────────────────────────────────┤
│                    FOUNDATION LAYER                           │
│  Safety │ Verification │ Error Recovery │ Self-Improvement   │
│  Persistence │ Cache │ Logging │ Tracing │ Metrics           │
│  Plugins │ MCP │ Rate Limiting │ Notifications               │
└─────────────────────────────────────────────────────────────┘
```

## Four-Layer Architecture

### Layer 1: User Interface

The user-facing layer handles all input and output.

| Component | Purpose |
|-----------|---------|
| **CLI** | Command-line argument parsing, subcommand dispatch, shell completion |
| **TUI** | Interactive terminal UI with panels, progress, themes, keyboard shortcuts |
| **Configuration** | TOML config files, environment variables, CLI flag overrides |

### Layer 2: Intelligence

The brain of the agent — planning, reasoning, and memory.

| Component | Purpose |
|-----------|---------|
| **Orchestrator** | Plans, executes, and monitors the agent loop |
| **LLM Engine** | Communicates with language models (15+ providers) |
| **Memory Engine** | Three-tier memory: short-term, working, long-term |
| **Context Manager** | Assembles and compresses context for LLM calls |
| **Prompt Manager** | Template library, prompt construction, optimization |

### Layer 3: Capability

The hands of the agent — tools that interact with the environment.

| Category | Tools |
|----------|-------|
| **Shell** | Command execution, background processes, SSH, Docker exec |
| **Filesystem** | Read, write, edit, search, move, copy, delete, metadata |
| **Code** | AST parsing, refactoring, formatting, linting, analysis |
| **Git** | Full git integration (commit, branch, merge, rebase, etc.) |
| **Packages** | 25+ package managers (npm, pip, cargo, go, maven, etc.) |
| **Database** | PostgreSQL, MySQL, SQLite, MongoDB, Redis, Elasticsearch |
| **Docker** | Images, containers, compose, volumes, networks |
| **Network** | HTTP, DNS, SSL, WebSocket, gRPC, GraphQL |
| **Search** | Regex, semantic, fuzzy, symbol, web search |
| **Testing** | Run, parse, generate for 15+ test frameworks |
| **Generation** | Project scaffolding, boilerplate, templates |
| **Docs** | README, API docs, changelog, docstrings |
| **DevOps** | Kubernetes, Terraform, Ansible, CI/CD, cloud |

### Layer 4: Foundation

The backbone — cross-cutting concerns that support all other layers.

| System | Purpose |
|--------|---------|
| **Safety** | Command blocking, path restrictions, confirmations, sandboxing |
| **Verification** | Syntax, runtime, type, schema, build, test, semantic checks |
| **Error Recovery** | 6-level recovery: retry, modify, alternative, re-plan, ask, abort |
| **Self-Improvement** | Trace recording, pattern learning, prompt optimization |
| **Persistence** | SQLite database, file store, vector store |
| **Caching** | Memory, disk, database caches with LRU/LFU eviction |
| **Logging** | Structured JSON logging with rotation |
| **Tracing** | Complete execution traces for replay and analysis |
| **Metrics** | Counters, gauges, histograms, timers |
| **Rate Limiting** | Token bucket, sliding window, per-provider limits |
| **Plugins** | Discovery, loading, sandboxing, lifecycle |
| **MCP** | Model Context Protocol client and server |
| **Notifications** | Console, desktop, webhook notifications |

## Core Agent Loop

The agent follows a Think → Act → Observe → Verify cycle:

```
┌──────────────┐
│  1. GOAL     │ Is the goal already achieved?
│    CHECK     │ If yes → COMPLETION
└──────┬───────┘
       │ No
       ▼
┌──────────────┐
│  2. CONTEXT  │ Build prompt: system + goal + plan +
│   ASSEMBLY   │ memories + history + environment
└──────┬───────┘
       ▼
┌──────────────┐
│  3. LLM      │ Send context to LLM, receive thought
│    CALL      │ + action (tool call) or completion
└──────┬───────┘
       ▼
┌──────────────┐
│  4. SAFETY   │ Check: tool allowed? blocked pattern?
│    CHECK     │ restricted path? destructive?
└──────┬───────┘
       ▼
┌──────────────┐
│  5. TOOL     │ Execute tool with parameters
│  EXECUTION   │ Capture output, exit code, duration
└──────┬───────┘
       ▼
┌──────────────┐
│  6. RESULT   │ Store output, classify result,
│   CAPTURE    │ extract errors, record side effects
└──────┬───────┘
       ▼
┌──────────────┐
│  7. VERIFY   │ Syntax? tests pass? build succeeds?
│              │ regression? semantic correctness?
└──────┬───────┘
       ▼
┌──────────────┐
│  8. MEMORY   │ Update short-term, working, and
│   UPDATE     │ long-term memory
└──────┬───────┘
       ▼
┌──────────────┐
│  9. PROGRESS │ Mark sub-goal status, re-plan if
│   UPDATE     │ needed, update display
└──────┬───────┘
       ▼
┌──────────────┐
│ 10. LOOP     │ Goal done? Max iterations? Budget?
│  DECISION    │ Error? Stop? → Continue loop
└──────────────┘
```

## Module Map

### 22 Functional Modules

| # | Module | Files | Purpose |
|---|--------|-------|---------|
| 1 | CLI Layer | 25-30 | Argument parsing, subcommand dispatch |
| 2 | TUI Layer | 40-50 | Interactive terminal UI |
| 3 | Configuration | 20-25 | Settings management, validation, encryption |
| 4 | LLM Engine | 45-55 | Model communication, 15+ providers |
| 5 | Memory Engine | 35-40 | Three-tier memory with vector search |
| 6 | Orchestrator | 30-35 | Planning, execution, monitoring |
| 7 | Shell Tools | 20-25 | Command execution, process management |
| 8 | Filesystem Tools | 25-30 | File operations, search, metadata |
| 9 | Code Tools | 50-60 | AST, refactoring, formatting, linting |
| 10 | Git Tools | 20-25 | Full git integration |
| 11 | Package Manager | 35-40 | 25+ package managers |
| 12 | Database Tools | 25-30 | 10+ database systems |
| 13 | Docker Tools | 20-25 | Container management |
| 14 | Network Tools | 20-25 | HTTP, DNS, SSL, WebSocket |
| 15 | Search Tools | 15-20 | Regex, semantic, symbol search |
| 16 | Testing Tools | 25-30 | 15+ test frameworks |
| 17 | Code Generation | 30-35 | Scaffolding, boilerplate, templates |
| 18 | Documentation | 15-20 | README, API docs, changelogs |
| 19 | DevOps Tools | 30-35 | K8s, Terraform, Ansible, CI/CD |
| 20 | Project Analysis | 15-20 | Detection, statistics, architecture |
| 21 | Context Manager | 15-20 | Token budget, assembly, compression |
| 22 | Prompt Manager | 20-25 | Templates, construction, optimization |

### 18 Support Systems

| # | System | Files | Purpose |
|---|--------|-------|---------|
| 1 | Safety Guardrails | 15-20 | Command blocking, path control, audit |
| 2 | Verification Engine | 20-25 | Syntax, runtime, type, semantic checks |
| 3 | Self-Improvement | 30-35 | Traces, patterns, prompt optimization |
| 4 | Project Analyzer | 15-20 | Language/framework/build detection |
| 5 | Error Analyzer | 15-20 | Classification, recovery strategies |
| 6 | Plugin System | 25-30 | Discovery, loading, sandboxing |
| 7 | MCP Client | 10-15 | External MCP server connections |
| 8 | MCP Server | 10-15 | Expose agent tools via MCP |
| 9 | Logging | 10-15 | Structured logging with rotation |
| 10 | Tracing | 15-20 | Execution traces for replay |
| 11 | Persistence | 15-20 | SQLite database, migrations |
| 12 | File Store | 10-15 | Backups, exports, templates |
| 13 | Vector Store | 20-25 | Embeddings, semantic search |
| 14 | Caching | 15-20 | Memory, disk, database caches |
| 15 | Rate Limiter | 10-15 | Token bucket, sliding window |
| 16 | Metrics | 15-20 | Counters, gauges, histograms |
| 17 | Differ | 10-15 | Diff generation, three-way merge |
| 18 | Notifications | 10-15 | Console, desktop, webhook |

## Data Flow

```
User Input
    │
    ▼
┌─────────┐     ┌─────────────┐     ┌──────────┐
│  CLI /  │────▶│ Orchestrator │────▶│ Context  │
│  TUI    │     │             │     │ Manager  │
└─────────┘     └──────┬──────┘     └────┬─────┘
                       │                  │
                       │                  ▼
                       │           ┌──────────┐
                       │           │  Memory  │
                       │           │  Engine  │
                       │           └────┬─────┘
                       │                │
                       ▼                ▼
                ┌──────────┐     ┌──────────┐
                │   LLM    │◀───│  Prompt  │
                │  Engine  │     │  Manager │
                └────┬─────┘     └──────────┘
                     │
                     ▼
              ┌──────────────┐
              │    Safety    │
              │   Check      │
              └──────┬───────┘
                     │
                     ▼
              ┌──────────────┐
              │    Tool      │
              │  Execution   │
              └──────┬───────┘
                     │
                     ▼
              ┌──────────────┐
              │ Verification │
              └──────┬───────┘
                     │
                     ▼
              ┌──────────────┐
              │   Memory     │──▶ Persistence
              │   Update     │──▶ Vector Store
              └──────┬───────┘──▶ Cache
                     │
                     ▼
              ┌──────────────┐
              │   Progress   │──▶ Metrics
              │   Check      │──▶ Tracing
              └──────┬───────┘
                     │
                     ▼
              ┌──────────────┐
              │  Loop or     │──▶ User Output
              │  Complete    │
              └──────────────┘
```

## Design Principles

1. **Modularity First** — Every component is self-contained with clear interfaces. Any module can be replaced without breaking others.

2. **Safety by Default** — The agent starts in the safest mode. Destructive actions require confirmation. Every action is logged.

3. **Verify Everything** — No action is considered complete until its result is verified through multiple stages.

4. **Learn Continuously** — Every task generates data that is analyzed to improve future performance.

5. **Model Agnostic** — Works with any LLM provider. Switching providers changes a config setting, not the architecture.

6. **Graceful Degradation** — If a tool fails, try an alternative. If the LLM is slow, use caching. The agent never crashes.

7. **Transparency** — The user can see everything the agent is thinking, planning, doing, and observing.

8. **Performance Conscious** — Token usage is optimized. Caching reduces redundant calls. Parallel execution speeds up independent tasks.

9. **Extensible by Design** — New tools, providers, and memory backends can be added via plugins without modifying core code.

10. **Developer Experience** — Installation is one command. Configuration is one file. Usage is one sentence.

## Detailed Documentation

- [Architecture Overview](docs/architecture/overview.md) — Complete system architecture
- [Agent Loop](docs/architecture/agent-loop.md) — Core loop deep dive
- [Memory Architecture](docs/architecture/memory-architecture.md) — Three-tier memory system
- [Tool Architecture](docs/architecture/tool-architecture.md) — Tool registry and execution
- [Safety Architecture](docs/architecture/safety-architecture.md) — Safety and security systems
- [Self-Improvement](docs/architecture/self-improvement.md) — Learning and optimization
- [Data Flow](docs/architecture/data-flow.md) — Complete data flow documentation
- [Context Engineering](docs/architecture/context-engineering.md) — Context assembly and management
