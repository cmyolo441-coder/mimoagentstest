---
name: Question
about: Ask a question about the project
title: "[QUESTION] "
labels: question
assignees: ''
---

## Question

A clear and concise question.

## Context

Provide context about what you're trying to achieve.

## What I've Tried

Describe what you've already tried or researched.

## Environment

- OS: [e.g., Ubuntu 22.04]
- Version: [e.g., 1.0.0]
- Python: [e.g., 3.12]

## Additional Context

Add any other context about the question here.
